/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BillingBillingViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#data_filter_expression BillingBillingView#data_filter_expression}
    */
    readonly dataFilterExpression?: BillingBillingViewDataFilterExpression;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#description BillingBillingView#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#name BillingBillingView#name}
    */
    readonly name: string;
    /**
    * An array of strings that define the billing view's source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#source_views BillingBillingView#source_views}
    */
    readonly sourceViews: string[];
    /**
    * An array of key-value pairs associated to the billing view being created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#tags BillingBillingView#tags}
    */
    readonly tags?: BillingBillingViewTags[] | cdktn.IResolvable;
}
export interface BillingBillingViewDataFilterExpressionDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#key BillingBillingView#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#values BillingBillingView#values}
    */
    readonly values?: string[];
}
export declare function billingBillingViewDataFilterExpressionDimensionsToTerraform(struct?: BillingBillingViewDataFilterExpressionDimensions | cdktn.IResolvable): any;
export declare function billingBillingViewDataFilterExpressionDimensionsToHclTerraform(struct?: BillingBillingViewDataFilterExpressionDimensions | cdktn.IResolvable): any;
export declare class BillingBillingViewDataFilterExpressionDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBillingViewDataFilterExpressionDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: BillingBillingViewDataFilterExpressionDimensions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BillingBillingViewDataFilterExpressionTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#key BillingBillingView#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#values BillingBillingView#values}
    */
    readonly values?: string[];
}
export declare function billingBillingViewDataFilterExpressionTagsToTerraform(struct?: BillingBillingViewDataFilterExpressionTags | cdktn.IResolvable): any;
export declare function billingBillingViewDataFilterExpressionTagsToHclTerraform(struct?: BillingBillingViewDataFilterExpressionTags | cdktn.IResolvable): any;
export declare class BillingBillingViewDataFilterExpressionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBillingViewDataFilterExpressionTags | cdktn.IResolvable | undefined;
    set internalValue(value: BillingBillingViewDataFilterExpressionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BillingBillingViewDataFilterExpressionTimeRange {
    /**
    * The time in ISO 8601 format, UTC time (YYYY-MM-DDTHH:MM:SSZ).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#begin_date_inclusive BillingBillingView#begin_date_inclusive}
    */
    readonly beginDateInclusive?: string;
    /**
    * The time in ISO 8601 format, UTC time (YYYY-MM-DDTHH:MM:SSZ).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#end_date_inclusive BillingBillingView#end_date_inclusive}
    */
    readonly endDateInclusive?: string;
}
export declare function billingBillingViewDataFilterExpressionTimeRangeToTerraform(struct?: BillingBillingViewDataFilterExpressionTimeRange | cdktn.IResolvable): any;
export declare function billingBillingViewDataFilterExpressionTimeRangeToHclTerraform(struct?: BillingBillingViewDataFilterExpressionTimeRange | cdktn.IResolvable): any;
export declare class BillingBillingViewDataFilterExpressionTimeRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBillingViewDataFilterExpressionTimeRange | cdktn.IResolvable | undefined;
    set internalValue(value: BillingBillingViewDataFilterExpressionTimeRange | cdktn.IResolvable | undefined);
    private _beginDateInclusive?;
    get beginDateInclusive(): string;
    set beginDateInclusive(value: string);
    resetBeginDateInclusive(): void;
    get beginDateInclusiveInput(): string | undefined;
    private _endDateInclusive?;
    get endDateInclusive(): string;
    set endDateInclusive(value: string);
    resetEndDateInclusive(): void;
    get endDateInclusiveInput(): string | undefined;
}
export interface BillingBillingViewDataFilterExpression {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#dimensions BillingBillingView#dimensions}
    */
    readonly dimensions?: BillingBillingViewDataFilterExpressionDimensions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#tags BillingBillingView#tags}
    */
    readonly tags?: BillingBillingViewDataFilterExpressionTags;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#time_range BillingBillingView#time_range}
    */
    readonly timeRange?: BillingBillingViewDataFilterExpressionTimeRange;
}
export declare function billingBillingViewDataFilterExpressionToTerraform(struct?: BillingBillingViewDataFilterExpression | cdktn.IResolvable): any;
export declare function billingBillingViewDataFilterExpressionToHclTerraform(struct?: BillingBillingViewDataFilterExpression | cdktn.IResolvable): any;
export declare class BillingBillingViewDataFilterExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingBillingViewDataFilterExpression | cdktn.IResolvable | undefined;
    set internalValue(value: BillingBillingViewDataFilterExpression | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): BillingBillingViewDataFilterExpressionDimensionsOutputReference;
    putDimensions(value: BillingBillingViewDataFilterExpressionDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | BillingBillingViewDataFilterExpressionDimensions | undefined;
    private _tags;
    get tags(): BillingBillingViewDataFilterExpressionTagsOutputReference;
    putTags(value: BillingBillingViewDataFilterExpressionTags): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BillingBillingViewDataFilterExpressionTags | undefined;
    private _timeRange;
    get timeRange(): BillingBillingViewDataFilterExpressionTimeRangeOutputReference;
    putTimeRange(value: BillingBillingViewDataFilterExpressionTimeRange): void;
    resetTimeRange(): void;
    get timeRangeInput(): cdktn.IResolvable | BillingBillingViewDataFilterExpressionTimeRange | undefined;
}
export interface BillingBillingViewTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#key BillingBillingView#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#value BillingBillingView#value}
    */
    readonly value?: string;
}
export declare function billingBillingViewTagsToTerraform(struct?: BillingBillingViewTags | cdktn.IResolvable): any;
export declare function billingBillingViewTagsToHclTerraform(struct?: BillingBillingViewTags | cdktn.IResolvable): any;
export declare class BillingBillingViewTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingBillingViewTags | cdktn.IResolvable | undefined;
    set internalValue(value: BillingBillingViewTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BillingBillingViewTagsList extends cdktn.ComplexList {
    internalValue?: BillingBillingViewTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingBillingViewTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view awscc_billing_billing_view}
*/
export declare class BillingBillingView extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_billing_billing_view";
    /**
    * Generates CDKTN code for importing a BillingBillingView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BillingBillingView to import
    * @param importFromId The id of the existing BillingBillingView that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BillingBillingView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/billing_billing_view awscc_billing_billing_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BillingBillingViewConfig
    */
    constructor(scope: Construct, id: string, config: BillingBillingViewConfig);
    get arn(): string;
    get billingViewType(): string;
    get createdAt(): number;
    private _dataFilterExpression;
    get dataFilterExpression(): BillingBillingViewDataFilterExpressionOutputReference;
    putDataFilterExpression(value: BillingBillingViewDataFilterExpression): void;
    resetDataFilterExpression(): void;
    get dataFilterExpressionInput(): cdktn.IResolvable | BillingBillingViewDataFilterExpression | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerAccountId(): string;
    private _sourceViews?;
    get sourceViews(): string[];
    set sourceViews(value: string[]);
    get sourceViewsInput(): string[] | undefined;
    private _tags;
    get tags(): BillingBillingViewTagsList;
    putTags(value: BillingBillingViewTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BillingBillingViewTags[] | undefined;
    get updatedAt(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
