/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CassandraKeyspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether client-side timestamps are enabled (true) or disabled (false) for all tables in the keyspace. To add a Region to a single-Region keyspace with at least one table, the value must be set to true. After you enabled client-side timestamps for a table, you can?t disable it again.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#client_side_timestamps_enabled CassandraKeyspace#client_side_timestamps_enabled}
    */
    readonly clientSideTimestampsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name for Cassandra keyspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#keyspace_name CassandraKeyspace#keyspace_name}
    */
    readonly keyspaceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#replication_specification CassandraKeyspace#replication_specification}
    */
    readonly replicationSpecification?: CassandraKeyspaceReplicationSpecification;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#tags CassandraKeyspace#tags}
    */
    readonly tags?: CassandraKeyspaceTags[] | cdktn.IResolvable;
}
export interface CassandraKeyspaceReplicationSpecification {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#region_list CassandraKeyspace#region_list}
    */
    readonly regionList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#replication_strategy CassandraKeyspace#replication_strategy}
    */
    readonly replicationStrategy?: string;
}
export declare function cassandraKeyspaceReplicationSpecificationToTerraform(struct?: CassandraKeyspaceReplicationSpecification | cdktn.IResolvable): any;
export declare function cassandraKeyspaceReplicationSpecificationToHclTerraform(struct?: CassandraKeyspaceReplicationSpecification | cdktn.IResolvable): any;
export declare class CassandraKeyspaceReplicationSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraKeyspaceReplicationSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraKeyspaceReplicationSpecification | cdktn.IResolvable | undefined);
    private _regionList?;
    get regionList(): string[];
    set regionList(value: string[]);
    resetRegionList(): void;
    get regionListInput(): string[] | undefined;
    private _replicationStrategy?;
    get replicationStrategy(): string;
    set replicationStrategy(value: string);
    resetReplicationStrategy(): void;
    get replicationStrategyInput(): string | undefined;
}
export interface CassandraKeyspaceTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#key CassandraKeyspace#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#value CassandraKeyspace#value}
    */
    readonly value?: string;
}
export declare function cassandraKeyspaceTagsToTerraform(struct?: CassandraKeyspaceTags | cdktn.IResolvable): any;
export declare function cassandraKeyspaceTagsToHclTerraform(struct?: CassandraKeyspaceTags | cdktn.IResolvable): any;
export declare class CassandraKeyspaceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CassandraKeyspaceTags | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraKeyspaceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CassandraKeyspaceTagsList extends cdktn.ComplexList {
    internalValue?: CassandraKeyspaceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CassandraKeyspaceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace awscc_cassandra_keyspace}
*/
export declare class CassandraKeyspace extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cassandra_keyspace";
    /**
    * Generates CDKTN code for importing a CassandraKeyspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CassandraKeyspace to import
    * @param importFromId The id of the existing CassandraKeyspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CassandraKeyspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cassandra_keyspace awscc_cassandra_keyspace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CassandraKeyspaceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CassandraKeyspaceConfig);
    private _clientSideTimestampsEnabled?;
    get clientSideTimestampsEnabled(): boolean | cdktn.IResolvable;
    set clientSideTimestampsEnabled(value: boolean | cdktn.IResolvable);
    resetClientSideTimestampsEnabled(): void;
    get clientSideTimestampsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _keyspaceName?;
    get keyspaceName(): string;
    set keyspaceName(value: string);
    resetKeyspaceName(): void;
    get keyspaceNameInput(): string | undefined;
    private _replicationSpecification;
    get replicationSpecification(): CassandraKeyspaceReplicationSpecificationOutputReference;
    putReplicationSpecification(value: CassandraKeyspaceReplicationSpecification): void;
    resetReplicationSpecification(): void;
    get replicationSpecificationInput(): cdktn.IResolvable | CassandraKeyspaceReplicationSpecification | undefined;
    private _tags;
    get tags(): CassandraKeyspaceTagsList;
    putTags(value: CassandraKeyspaceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CassandraKeyspaceTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
