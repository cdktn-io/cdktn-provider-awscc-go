/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComprehendDocumentClassifierConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#data_access_role_arn ComprehendDocumentClassifier#data_access_role_arn}
    */
    readonly dataAccessRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#document_classifier_name ComprehendDocumentClassifier#document_classifier_name}
    */
    readonly documentClassifierName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#input_data_config ComprehendDocumentClassifier#input_data_config}
    */
    readonly inputDataConfig: ComprehendDocumentClassifierInputDataConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#language_code ComprehendDocumentClassifier#language_code}
    */
    readonly languageCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#mode ComprehendDocumentClassifier#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#model_kms_key_id ComprehendDocumentClassifier#model_kms_key_id}
    */
    readonly modelKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#model_policy ComprehendDocumentClassifier#model_policy}
    */
    readonly modelPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#output_data_config ComprehendDocumentClassifier#output_data_config}
    */
    readonly outputDataConfig?: ComprehendDocumentClassifierOutputDataConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#tags ComprehendDocumentClassifier#tags}
    */
    readonly tags?: ComprehendDocumentClassifierTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#version_name ComprehendDocumentClassifier#version_name}
    */
    readonly versionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#volume_kms_key_id ComprehendDocumentClassifier#volume_kms_key_id}
    */
    readonly volumeKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#vpc_config ComprehendDocumentClassifier#vpc_config}
    */
    readonly vpcConfig?: ComprehendDocumentClassifierVpcConfig;
}
export interface ComprehendDocumentClassifierInputDataConfigAugmentedManifests {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#attribute_names ComprehendDocumentClassifier#attribute_names}
    */
    readonly attributeNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#s3_uri ComprehendDocumentClassifier#s3_uri}
    */
    readonly s3Uri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#split ComprehendDocumentClassifier#split}
    */
    readonly split?: string;
}
export declare function comprehendDocumentClassifierInputDataConfigAugmentedManifestsToTerraform(struct?: ComprehendDocumentClassifierInputDataConfigAugmentedManifests | cdktn.IResolvable): any;
export declare function comprehendDocumentClassifierInputDataConfigAugmentedManifestsToHclTerraform(struct?: ComprehendDocumentClassifierInputDataConfigAugmentedManifests | cdktn.IResolvable): any;
export declare class ComprehendDocumentClassifierInputDataConfigAugmentedManifestsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendDocumentClassifierInputDataConfigAugmentedManifests | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendDocumentClassifierInputDataConfigAugmentedManifests | cdktn.IResolvable | undefined);
    private _attributeNames?;
    get attributeNames(): string[];
    set attributeNames(value: string[]);
    resetAttributeNames(): void;
    get attributeNamesInput(): string[] | undefined;
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    resetS3Uri(): void;
    get s3UriInput(): string | undefined;
    private _split?;
    get split(): string;
    set split(value: string);
    resetSplit(): void;
    get splitInput(): string | undefined;
}
export declare class ComprehendDocumentClassifierInputDataConfigAugmentedManifestsList extends cdktn.ComplexList {
    internalValue?: ComprehendDocumentClassifierInputDataConfigAugmentedManifests[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendDocumentClassifierInputDataConfigAugmentedManifestsOutputReference;
}
export interface ComprehendDocumentClassifierInputDataConfigDocumentReaderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#document_read_action ComprehendDocumentClassifier#document_read_action}
    */
    readonly documentReadAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#document_read_mode ComprehendDocumentClassifier#document_read_mode}
    */
    readonly documentReadMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#feature_types ComprehendDocumentClassifier#feature_types}
    */
    readonly featureTypes?: string[];
}
export declare function comprehendDocumentClassifierInputDataConfigDocumentReaderConfigToTerraform(struct?: ComprehendDocumentClassifierInputDataConfigDocumentReaderConfig | cdktn.IResolvable): any;
export declare function comprehendDocumentClassifierInputDataConfigDocumentReaderConfigToHclTerraform(struct?: ComprehendDocumentClassifierInputDataConfigDocumentReaderConfig | cdktn.IResolvable): any;
export declare class ComprehendDocumentClassifierInputDataConfigDocumentReaderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendDocumentClassifierInputDataConfigDocumentReaderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendDocumentClassifierInputDataConfigDocumentReaderConfig | cdktn.IResolvable | undefined);
    private _documentReadAction?;
    get documentReadAction(): string;
    set documentReadAction(value: string);
    resetDocumentReadAction(): void;
    get documentReadActionInput(): string | undefined;
    private _documentReadMode?;
    get documentReadMode(): string;
    set documentReadMode(value: string);
    resetDocumentReadMode(): void;
    get documentReadModeInput(): string | undefined;
    private _featureTypes?;
    get featureTypes(): string[];
    set featureTypes(value: string[]);
    resetFeatureTypes(): void;
    get featureTypesInput(): string[] | undefined;
}
export interface ComprehendDocumentClassifierInputDataConfigDocuments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#s3_uri ComprehendDocumentClassifier#s3_uri}
    */
    readonly s3Uri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#test_s3_uri ComprehendDocumentClassifier#test_s3_uri}
    */
    readonly testS3Uri?: string;
}
export declare function comprehendDocumentClassifierInputDataConfigDocumentsToTerraform(struct?: ComprehendDocumentClassifierInputDataConfigDocuments | cdktn.IResolvable): any;
export declare function comprehendDocumentClassifierInputDataConfigDocumentsToHclTerraform(struct?: ComprehendDocumentClassifierInputDataConfigDocuments | cdktn.IResolvable): any;
export declare class ComprehendDocumentClassifierInputDataConfigDocumentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendDocumentClassifierInputDataConfigDocuments | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendDocumentClassifierInputDataConfigDocuments | cdktn.IResolvable | undefined);
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    resetS3Uri(): void;
    get s3UriInput(): string | undefined;
    private _testS3Uri?;
    get testS3Uri(): string;
    set testS3Uri(value: string);
    resetTestS3Uri(): void;
    get testS3UriInput(): string | undefined;
}
export interface ComprehendDocumentClassifierInputDataConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#augmented_manifests ComprehendDocumentClassifier#augmented_manifests}
    */
    readonly augmentedManifests?: ComprehendDocumentClassifierInputDataConfigAugmentedManifests[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#data_format ComprehendDocumentClassifier#data_format}
    */
    readonly dataFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#document_reader_config ComprehendDocumentClassifier#document_reader_config}
    */
    readonly documentReaderConfig?: ComprehendDocumentClassifierInputDataConfigDocumentReaderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#document_type ComprehendDocumentClassifier#document_type}
    */
    readonly documentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#documents ComprehendDocumentClassifier#documents}
    */
    readonly documents?: ComprehendDocumentClassifierInputDataConfigDocuments;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#label_delimiter ComprehendDocumentClassifier#label_delimiter}
    */
    readonly labelDelimiter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#s3_uri ComprehendDocumentClassifier#s3_uri}
    */
    readonly s3Uri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#test_s3_uri ComprehendDocumentClassifier#test_s3_uri}
    */
    readonly testS3Uri?: string;
}
export declare function comprehendDocumentClassifierInputDataConfigToTerraform(struct?: ComprehendDocumentClassifierInputDataConfig | cdktn.IResolvable): any;
export declare function comprehendDocumentClassifierInputDataConfigToHclTerraform(struct?: ComprehendDocumentClassifierInputDataConfig | cdktn.IResolvable): any;
export declare class ComprehendDocumentClassifierInputDataConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendDocumentClassifierInputDataConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendDocumentClassifierInputDataConfig | cdktn.IResolvable | undefined);
    private _augmentedManifests;
    get augmentedManifests(): ComprehendDocumentClassifierInputDataConfigAugmentedManifestsList;
    putAugmentedManifests(value: ComprehendDocumentClassifierInputDataConfigAugmentedManifests[] | cdktn.IResolvable): void;
    resetAugmentedManifests(): void;
    get augmentedManifestsInput(): cdktn.IResolvable | ComprehendDocumentClassifierInputDataConfigAugmentedManifests[] | undefined;
    private _dataFormat?;
    get dataFormat(): string;
    set dataFormat(value: string);
    resetDataFormat(): void;
    get dataFormatInput(): string | undefined;
    private _documentReaderConfig;
    get documentReaderConfig(): ComprehendDocumentClassifierInputDataConfigDocumentReaderConfigOutputReference;
    putDocumentReaderConfig(value: ComprehendDocumentClassifierInputDataConfigDocumentReaderConfig): void;
    resetDocumentReaderConfig(): void;
    get documentReaderConfigInput(): cdktn.IResolvable | ComprehendDocumentClassifierInputDataConfigDocumentReaderConfig | undefined;
    private _documentType?;
    get documentType(): string;
    set documentType(value: string);
    resetDocumentType(): void;
    get documentTypeInput(): string | undefined;
    private _documents;
    get documents(): ComprehendDocumentClassifierInputDataConfigDocumentsOutputReference;
    putDocuments(value: ComprehendDocumentClassifierInputDataConfigDocuments): void;
    resetDocuments(): void;
    get documentsInput(): cdktn.IResolvable | ComprehendDocumentClassifierInputDataConfigDocuments | undefined;
    private _labelDelimiter?;
    get labelDelimiter(): string;
    set labelDelimiter(value: string);
    resetLabelDelimiter(): void;
    get labelDelimiterInput(): string | undefined;
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    resetS3Uri(): void;
    get s3UriInput(): string | undefined;
    private _testS3Uri?;
    get testS3Uri(): string;
    set testS3Uri(value: string);
    resetTestS3Uri(): void;
    get testS3UriInput(): string | undefined;
}
export interface ComprehendDocumentClassifierOutputDataConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#kms_key_id ComprehendDocumentClassifier#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#s3_uri ComprehendDocumentClassifier#s3_uri}
    */
    readonly s3Uri?: string;
}
export declare function comprehendDocumentClassifierOutputDataConfigToTerraform(struct?: ComprehendDocumentClassifierOutputDataConfig | cdktn.IResolvable): any;
export declare function comprehendDocumentClassifierOutputDataConfigToHclTerraform(struct?: ComprehendDocumentClassifierOutputDataConfig | cdktn.IResolvable): any;
export declare class ComprehendDocumentClassifierOutputDataConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendDocumentClassifierOutputDataConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendDocumentClassifierOutputDataConfig | cdktn.IResolvable | undefined);
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    resetS3Uri(): void;
    get s3UriInput(): string | undefined;
}
export interface ComprehendDocumentClassifierTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#key ComprehendDocumentClassifier#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#value ComprehendDocumentClassifier#value}
    */
    readonly value?: string;
}
export declare function comprehendDocumentClassifierTagsToTerraform(struct?: ComprehendDocumentClassifierTags | cdktn.IResolvable): any;
export declare function comprehendDocumentClassifierTagsToHclTerraform(struct?: ComprehendDocumentClassifierTags | cdktn.IResolvable): any;
export declare class ComprehendDocumentClassifierTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendDocumentClassifierTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendDocumentClassifierTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComprehendDocumentClassifierTagsList extends cdktn.ComplexList {
    internalValue?: ComprehendDocumentClassifierTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendDocumentClassifierTagsOutputReference;
}
export interface ComprehendDocumentClassifierVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#security_group_ids ComprehendDocumentClassifier#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#subnets ComprehendDocumentClassifier#subnets}
    */
    readonly subnets?: string[];
}
export declare function comprehendDocumentClassifierVpcConfigToTerraform(struct?: ComprehendDocumentClassifierVpcConfig | cdktn.IResolvable): any;
export declare function comprehendDocumentClassifierVpcConfigToHclTerraform(struct?: ComprehendDocumentClassifierVpcConfig | cdktn.IResolvable): any;
export declare class ComprehendDocumentClassifierVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendDocumentClassifierVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendDocumentClassifierVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier awscc_comprehend_document_classifier}
*/
export declare class ComprehendDocumentClassifier extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_comprehend_document_classifier";
    /**
    * Generates CDKTN code for importing a ComprehendDocumentClassifier resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComprehendDocumentClassifier to import
    * @param importFromId The id of the existing ComprehendDocumentClassifier that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComprehendDocumentClassifier to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_document_classifier awscc_comprehend_document_classifier} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComprehendDocumentClassifierConfig
    */
    constructor(scope: Construct, id: string, config: ComprehendDocumentClassifierConfig);
    get arn(): string;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    get dataAccessRoleArnInput(): string | undefined;
    private _documentClassifierName?;
    get documentClassifierName(): string;
    set documentClassifierName(value: string);
    get documentClassifierNameInput(): string | undefined;
    get id(): string;
    private _inputDataConfig;
    get inputDataConfig(): ComprehendDocumentClassifierInputDataConfigOutputReference;
    putInputDataConfig(value: ComprehendDocumentClassifierInputDataConfig): void;
    get inputDataConfigInput(): cdktn.IResolvable | ComprehendDocumentClassifierInputDataConfig | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _modelKmsKeyId?;
    get modelKmsKeyId(): string;
    set modelKmsKeyId(value: string);
    resetModelKmsKeyId(): void;
    get modelKmsKeyIdInput(): string | undefined;
    private _modelPolicy?;
    get modelPolicy(): string;
    set modelPolicy(value: string);
    resetModelPolicy(): void;
    get modelPolicyInput(): string | undefined;
    private _outputDataConfig;
    get outputDataConfig(): ComprehendDocumentClassifierOutputDataConfigOutputReference;
    putOutputDataConfig(value: ComprehendDocumentClassifierOutputDataConfig): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): cdktn.IResolvable | ComprehendDocumentClassifierOutputDataConfig | undefined;
    private _tags;
    get tags(): ComprehendDocumentClassifierTagsList;
    putTags(value: ComprehendDocumentClassifierTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ComprehendDocumentClassifierTags[] | undefined;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    resetVersionName(): void;
    get versionNameInput(): string | undefined;
    private _volumeKmsKeyId?;
    get volumeKmsKeyId(): string;
    set volumeKmsKeyId(value: string);
    resetVolumeKmsKeyId(): void;
    get volumeKmsKeyIdInput(): string | undefined;
    private _vpcConfig;
    get vpcConfig(): ComprehendDocumentClassifierVpcConfigOutputReference;
    putVpcConfig(value: ComprehendDocumentClassifierVpcConfig): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | ComprehendDocumentClassifierVpcConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
