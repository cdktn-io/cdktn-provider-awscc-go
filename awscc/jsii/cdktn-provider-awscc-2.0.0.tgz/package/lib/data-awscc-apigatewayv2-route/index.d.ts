/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2RouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_route#id DataAwsccApigatewayv2Route#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_route awscc_apigatewayv2_route}
*/
export declare class DataAwsccApigatewayv2Route extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_route";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2Route resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2Route to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2Route that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2Route to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_route awscc_apigatewayv2_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2RouteConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2RouteConfig);
    get apiId(): string;
    get apiKeyRequired(): cdktn.IResolvable;
    get authorizationScopes(): string[];
    get authorizationType(): string;
    get authorizerId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get modelSelectionExpression(): string;
    get operationName(): string;
    get requestModels(): string;
    get requestParameters(): string;
    get routeId(): string;
    get routeKey(): string;
    get routeResponseSelectionExpression(): string;
    get target(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
