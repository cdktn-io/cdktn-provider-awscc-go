/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodeguruprofilerProfilingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The agent permissions attached to this profiling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#agent_permissions CodeguruprofilerProfilingGroup#agent_permissions}
    */
    readonly agentPermissions?: CodeguruprofilerProfilingGroupAgentPermissions;
    /**
    * Configuration for Notification Channels for Anomaly Detection feature in CodeGuru Profiler which enables customers to detect anomalies in the application profile for those methods that represent the highest proportion of CPU time or latency
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#anomaly_detection_notification_configuration CodeguruprofilerProfilingGroup#anomaly_detection_notification_configuration}
    */
    readonly anomalyDetectionNotificationConfiguration?: CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration[] | cdktn.IResolvable;
    /**
    * The compute platform of the profiling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#compute_platform CodeguruprofilerProfilingGroup#compute_platform}
    */
    readonly computePlatform?: string;
    /**
    * The name of the profiling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#profiling_group_name CodeguruprofilerProfilingGroup#profiling_group_name}
    */
    readonly profilingGroupName: string;
    /**
    * The tags associated with a profiling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#tags CodeguruprofilerProfilingGroup#tags}
    */
    readonly tags?: CodeguruprofilerProfilingGroupTags[] | cdktn.IResolvable;
}
export interface CodeguruprofilerProfilingGroupAgentPermissions {
    /**
    * The principals for the agent permissions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#principals CodeguruprofilerProfilingGroup#principals}
    */
    readonly principals?: string[];
}
export declare function codeguruprofilerProfilingGroupAgentPermissionsToTerraform(struct?: CodeguruprofilerProfilingGroupAgentPermissions | cdktn.IResolvable): any;
export declare function codeguruprofilerProfilingGroupAgentPermissionsToHclTerraform(struct?: CodeguruprofilerProfilingGroupAgentPermissions | cdktn.IResolvable): any;
export declare class CodeguruprofilerProfilingGroupAgentPermissionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodeguruprofilerProfilingGroupAgentPermissions | cdktn.IResolvable | undefined;
    set internalValue(value: CodeguruprofilerProfilingGroupAgentPermissions | cdktn.IResolvable | undefined);
    private _principals?;
    get principals(): string[];
    set principals(value: string[]);
    resetPrincipals(): void;
    get principalsInput(): string[] | undefined;
}
export interface CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration {
    /**
    * Unique identifier for each Channel in the notification configuration of a Profiling Group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#channel_id CodeguruprofilerProfilingGroup#channel_id}
    */
    readonly channelId?: string;
    /**
    * Unique arn of the resource to be used for notifications. We support a valid SNS topic arn as a channel uri.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#channel_uri CodeguruprofilerProfilingGroup#channel_uri}
    */
    readonly channelUri?: string;
}
export declare function codeguruprofilerProfilingGroupAnomalyDetectionNotificationConfigurationToTerraform(struct?: CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration | cdktn.IResolvable): any;
export declare function codeguruprofilerProfilingGroupAnomalyDetectionNotificationConfigurationToHclTerraform(struct?: CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration | cdktn.IResolvable): any;
export declare class CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration | cdktn.IResolvable | undefined);
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    resetChannelId(): void;
    get channelIdInput(): string | undefined;
    private _channelUri?;
    get channelUri(): string;
    set channelUri(value: string);
    resetChannelUri(): void;
    get channelUriInput(): string | undefined;
}
export declare class CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfigurationList extends cdktn.ComplexList {
    internalValue?: CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfigurationOutputReference;
}
export interface CodeguruprofilerProfilingGroupTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. The allowed characters across services are: letters, numbers, and spaces representable in UTF-8, and the following characters: + - = . _ : / @.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#key CodeguruprofilerProfilingGroup#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length. The allowed characters across services are: letters, numbers, and spaces representable in UTF-8, and the following characters: + - = . _ : / @.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#value CodeguruprofilerProfilingGroup#value}
    */
    readonly value?: string;
}
export declare function codeguruprofilerProfilingGroupTagsToTerraform(struct?: CodeguruprofilerProfilingGroupTags | cdktn.IResolvable): any;
export declare function codeguruprofilerProfilingGroupTagsToHclTerraform(struct?: CodeguruprofilerProfilingGroupTags | cdktn.IResolvable): any;
export declare class CodeguruprofilerProfilingGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodeguruprofilerProfilingGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodeguruprofilerProfilingGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodeguruprofilerProfilingGroupTagsList extends cdktn.ComplexList {
    internalValue?: CodeguruprofilerProfilingGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodeguruprofilerProfilingGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group awscc_codeguruprofiler_profiling_group}
*/
export declare class CodeguruprofilerProfilingGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codeguruprofiler_profiling_group";
    /**
    * Generates CDKTN code for importing a CodeguruprofilerProfilingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodeguruprofilerProfilingGroup to import
    * @param importFromId The id of the existing CodeguruprofilerProfilingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodeguruprofilerProfilingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeguruprofiler_profiling_group awscc_codeguruprofiler_profiling_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodeguruprofilerProfilingGroupConfig
    */
    constructor(scope: Construct, id: string, config: CodeguruprofilerProfilingGroupConfig);
    private _agentPermissions;
    get agentPermissions(): CodeguruprofilerProfilingGroupAgentPermissionsOutputReference;
    putAgentPermissions(value: CodeguruprofilerProfilingGroupAgentPermissions): void;
    resetAgentPermissions(): void;
    get agentPermissionsInput(): cdktn.IResolvable | CodeguruprofilerProfilingGroupAgentPermissions | undefined;
    private _anomalyDetectionNotificationConfiguration;
    get anomalyDetectionNotificationConfiguration(): CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfigurationList;
    putAnomalyDetectionNotificationConfiguration(value: CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration[] | cdktn.IResolvable): void;
    resetAnomalyDetectionNotificationConfiguration(): void;
    get anomalyDetectionNotificationConfigurationInput(): cdktn.IResolvable | CodeguruprofilerProfilingGroupAnomalyDetectionNotificationConfiguration[] | undefined;
    get arn(): string;
    private _computePlatform?;
    get computePlatform(): string;
    set computePlatform(value: string);
    resetComputePlatform(): void;
    get computePlatformInput(): string | undefined;
    get id(): string;
    private _profilingGroupName?;
    get profilingGroupName(): string;
    set profilingGroupName(value: string);
    get profilingGroupNameInput(): string | undefined;
    private _tags;
    get tags(): CodeguruprofilerProfilingGroupTagsList;
    putTags(value: CodeguruprofilerProfilingGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodeguruprofilerProfilingGroupTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
