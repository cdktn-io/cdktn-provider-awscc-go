/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesRecommenderFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the recommender filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#description CustomerprofilesRecommenderFilter#description}
    */
    readonly description?: string;
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#domain_name CustomerprofilesRecommenderFilter#domain_name}
    */
    readonly domainName: string;
    /**
    * The filter expression that defines which items to include or exclude from recommendations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#recommender_filter_expression CustomerprofilesRecommenderFilter#recommender_filter_expression}
    */
    readonly recommenderFilterExpression: string;
    /**
    * The name of the recommender filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#recommender_filter_name CustomerprofilesRecommenderFilter#recommender_filter_name}
    */
    readonly recommenderFilterName: string;
    /**
    * The name of the recommender schema to use for this recommender filter. If not specified, the default schema is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#recommender_schema_name CustomerprofilesRecommenderFilter#recommender_schema_name}
    */
    readonly recommenderSchemaName?: string;
    /**
    * The tags used to organize, track, or control access for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#tags CustomerprofilesRecommenderFilter#tags}
    */
    readonly tags?: CustomerprofilesRecommenderFilterTags[] | cdktn.IResolvable;
}
export interface CustomerprofilesRecommenderFilterTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#key CustomerprofilesRecommenderFilter#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#value CustomerprofilesRecommenderFilter#value}
    */
    readonly value?: string;
}
export declare function customerprofilesRecommenderFilterTagsToTerraform(struct?: CustomerprofilesRecommenderFilterTags | cdktn.IResolvable): any;
export declare function customerprofilesRecommenderFilterTagsToHclTerraform(struct?: CustomerprofilesRecommenderFilterTags | cdktn.IResolvable): any;
export declare class CustomerprofilesRecommenderFilterTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesRecommenderFilterTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesRecommenderFilterTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesRecommenderFilterTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesRecommenderFilterTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesRecommenderFilterTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter awscc_customerprofiles_recommender_filter}
*/
export declare class CustomerprofilesRecommenderFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_recommender_filter";
    /**
    * Generates CDKTN code for importing a CustomerprofilesRecommenderFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesRecommenderFilter to import
    * @param importFromId The id of the existing CustomerprofilesRecommenderFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesRecommenderFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_recommender_filter awscc_customerprofiles_recommender_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesRecommenderFilterConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesRecommenderFilterConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get id(): string;
    get recommenderFilterArn(): string;
    private _recommenderFilterExpression?;
    get recommenderFilterExpression(): string;
    set recommenderFilterExpression(value: string);
    get recommenderFilterExpressionInput(): string | undefined;
    private _recommenderFilterName?;
    get recommenderFilterName(): string;
    set recommenderFilterName(value: string);
    get recommenderFilterNameInput(): string | undefined;
    private _recommenderSchemaName?;
    get recommenderSchemaName(): string;
    set recommenderSchemaName(value: string);
    resetRecommenderSchemaName(): void;
    get recommenderSchemaNameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): CustomerprofilesRecommenderFilterTagsList;
    putTags(value: CustomerprofilesRecommenderFilterTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesRecommenderFilterTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
