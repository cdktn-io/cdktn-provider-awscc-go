/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamAppBlockBuilderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#access_endpoints AppstreamAppBlockBuilder#access_endpoints}
    */
    readonly accessEndpoints?: AppstreamAppBlockBuilderAccessEndpoints[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#app_block_arns AppstreamAppBlockBuilder#app_block_arns}
    */
    readonly appBlockArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#description AppstreamAppBlockBuilder#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#disable_imdsv1 AppstreamAppBlockBuilder#disable_imdsv1}
    */
    readonly disableImdsv1?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#display_name AppstreamAppBlockBuilder#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#enable_default_internet_access AppstreamAppBlockBuilder#enable_default_internet_access}
    */
    readonly enableDefaultInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#iam_role_arn AppstreamAppBlockBuilder#iam_role_arn}
    */
    readonly iamRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#instance_type AppstreamAppBlockBuilder#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#name AppstreamAppBlockBuilder#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#platform AppstreamAppBlockBuilder#platform}
    */
    readonly platform: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#tags AppstreamAppBlockBuilder#tags}
    */
    readonly tags?: AppstreamAppBlockBuilderTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#vpc_config AppstreamAppBlockBuilder#vpc_config}
    */
    readonly vpcConfig: AppstreamAppBlockBuilderVpcConfig;
}
export interface AppstreamAppBlockBuilderAccessEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#endpoint_type AppstreamAppBlockBuilder#endpoint_type}
    */
    readonly endpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#vpce_id AppstreamAppBlockBuilder#vpce_id}
    */
    readonly vpceId?: string;
}
export declare function appstreamAppBlockBuilderAccessEndpointsToTerraform(struct?: AppstreamAppBlockBuilderAccessEndpoints | cdktn.IResolvable): any;
export declare function appstreamAppBlockBuilderAccessEndpointsToHclTerraform(struct?: AppstreamAppBlockBuilderAccessEndpoints | cdktn.IResolvable): any;
export declare class AppstreamAppBlockBuilderAccessEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamAppBlockBuilderAccessEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockBuilderAccessEndpoints | cdktn.IResolvable | undefined);
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    resetEndpointType(): void;
    get endpointTypeInput(): string | undefined;
    private _vpceId?;
    get vpceId(): string;
    set vpceId(value: string);
    resetVpceId(): void;
    get vpceIdInput(): string | undefined;
}
export declare class AppstreamAppBlockBuilderAccessEndpointsList extends cdktn.ComplexList {
    internalValue?: AppstreamAppBlockBuilderAccessEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamAppBlockBuilderAccessEndpointsOutputReference;
}
export interface AppstreamAppBlockBuilderTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#key AppstreamAppBlockBuilder#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#value AppstreamAppBlockBuilder#value}
    */
    readonly value?: string;
}
export declare function appstreamAppBlockBuilderTagsToTerraform(struct?: AppstreamAppBlockBuilderTags | cdktn.IResolvable): any;
export declare function appstreamAppBlockBuilderTagsToHclTerraform(struct?: AppstreamAppBlockBuilderTags | cdktn.IResolvable): any;
export declare class AppstreamAppBlockBuilderTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamAppBlockBuilderTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockBuilderTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppstreamAppBlockBuilderTagsList extends cdktn.ComplexList {
    internalValue?: AppstreamAppBlockBuilderTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamAppBlockBuilderTagsOutputReference;
}
export interface AppstreamAppBlockBuilderVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#security_group_ids AppstreamAppBlockBuilder#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#subnet_ids AppstreamAppBlockBuilder#subnet_ids}
    */
    readonly subnetIds?: string[];
}
export declare function appstreamAppBlockBuilderVpcConfigToTerraform(struct?: AppstreamAppBlockBuilderVpcConfig | cdktn.IResolvable): any;
export declare function appstreamAppBlockBuilderVpcConfigToHclTerraform(struct?: AppstreamAppBlockBuilderVpcConfig | cdktn.IResolvable): any;
export declare class AppstreamAppBlockBuilderVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamAppBlockBuilderVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockBuilderVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder awscc_appstream_app_block_builder}
*/
export declare class AppstreamAppBlockBuilder extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_app_block_builder";
    /**
    * Generates CDKTN code for importing a AppstreamAppBlockBuilder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamAppBlockBuilder to import
    * @param importFromId The id of the existing AppstreamAppBlockBuilder that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamAppBlockBuilder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block_builder awscc_appstream_app_block_builder} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamAppBlockBuilderConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamAppBlockBuilderConfig);
    private _accessEndpoints;
    get accessEndpoints(): AppstreamAppBlockBuilderAccessEndpointsList;
    putAccessEndpoints(value: AppstreamAppBlockBuilderAccessEndpoints[] | cdktn.IResolvable): void;
    resetAccessEndpoints(): void;
    get accessEndpointsInput(): cdktn.IResolvable | AppstreamAppBlockBuilderAccessEndpoints[] | undefined;
    private _appBlockArns?;
    get appBlockArns(): string[];
    set appBlockArns(value: string[]);
    resetAppBlockArns(): void;
    get appBlockArnsInput(): string[] | undefined;
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableImdsv1?;
    get disableImdsv1(): boolean | cdktn.IResolvable;
    set disableImdsv1(value: boolean | cdktn.IResolvable);
    resetDisableImdsv1(): void;
    get disableImdsv1Input(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enableDefaultInternetAccess?;
    get enableDefaultInternetAccess(): boolean | cdktn.IResolvable;
    set enableDefaultInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableDefaultInternetAccess(): void;
    get enableDefaultInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    resetIamRoleArn(): void;
    get iamRoleArnInput(): string | undefined;
    get id(): string;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _platform?;
    get platform(): string;
    set platform(value: string);
    get platformInput(): string | undefined;
    private _tags;
    get tags(): AppstreamAppBlockBuilderTagsList;
    putTags(value: AppstreamAppBlockBuilderTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppstreamAppBlockBuilderTags[] | undefined;
    private _vpcConfig;
    get vpcConfig(): AppstreamAppBlockBuilderVpcConfigOutputReference;
    putVpcConfig(value: AppstreamAppBlockBuilderVpcConfig): void;
    get vpcConfigInput(): cdktn.IResolvable | AppstreamAppBlockBuilderVpcConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
