/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreGatewayRateLimitConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional human-readable description for this limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#description BedrockagentcoreGatewayRateLimit#description}
    */
    readonly description?: string;
    /**
    * Ordered list of dimension names defining the scope of this limit.
    * Unique per gateway — no two limits can share the same dimensionKeys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#dimension_keys BedrockagentcoreGatewayRateLimit#dimension_keys}
    */
    readonly dimensionKeys: string[];
    /**
    * Rule entries mapping dimension values to rate configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#entries BedrockagentcoreGatewayRateLimit#entries}
    */
    readonly entries: BedrockagentcoreGatewayRateLimitEntries[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#gateway_identifier BedrockagentcoreGatewayRateLimit#gateway_identifier}
    */
    readonly gatewayIdentifier?: string;
    /**
    * Limit identifier. Optional on Create (system-generates if not provided by customer).
    * Always present in responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#rate_limit_id BedrockagentcoreGatewayRateLimit#rate_limit_id}
    */
    readonly rateLimitId?: string;
}
export interface BedrockagentcoreGatewayRateLimitEntriesConnections {
    /**
    * Time period for rate limiting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#period BedrockagentcoreGatewayRateLimit#period}
    */
    readonly period?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#rate BedrockagentcoreGatewayRateLimit#rate}
    */
    readonly rate?: number;
}
export declare function bedrockagentcoreGatewayRateLimitEntriesConnectionsToTerraform(struct?: BedrockagentcoreGatewayRateLimitEntriesConnections | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRateLimitEntriesConnectionsToHclTerraform(struct?: BedrockagentcoreGatewayRateLimitEntriesConnections | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRateLimitEntriesConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRateLimitEntriesConnections | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRateLimitEntriesConnections | cdktn.IResolvable | undefined);
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    private _rate?;
    get rate(): number;
    set rate(value: number);
    resetRate(): void;
    get rateInput(): number | undefined;
}
export declare class BedrockagentcoreGatewayRateLimitEntriesConnectionsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRateLimitEntriesConnections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRateLimitEntriesConnectionsOutputReference;
}
export interface BedrockagentcoreGatewayRateLimitEntriesRequests {
    /**
    * Time period for rate limiting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#period BedrockagentcoreGatewayRateLimit#period}
    */
    readonly period?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#rate BedrockagentcoreGatewayRateLimit#rate}
    */
    readonly rate?: number;
}
export declare function bedrockagentcoreGatewayRateLimitEntriesRequestsToTerraform(struct?: BedrockagentcoreGatewayRateLimitEntriesRequests | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRateLimitEntriesRequestsToHclTerraform(struct?: BedrockagentcoreGatewayRateLimitEntriesRequests | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRateLimitEntriesRequestsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRateLimitEntriesRequests | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRateLimitEntriesRequests | cdktn.IResolvable | undefined);
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    private _rate?;
    get rate(): number;
    set rate(value: number);
    resetRate(): void;
    get rateInput(): number | undefined;
}
export declare class BedrockagentcoreGatewayRateLimitEntriesRequestsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRateLimitEntriesRequests[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRateLimitEntriesRequestsOutputReference;
}
export interface BedrockagentcoreGatewayRateLimitEntriesTokens {
    /**
    * Time period for rate limiting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#period BedrockagentcoreGatewayRateLimit#period}
    */
    readonly period?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#rate BedrockagentcoreGatewayRateLimit#rate}
    */
    readonly rate?: number;
}
export declare function bedrockagentcoreGatewayRateLimitEntriesTokensToTerraform(struct?: BedrockagentcoreGatewayRateLimitEntriesTokens | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRateLimitEntriesTokensToHclTerraform(struct?: BedrockagentcoreGatewayRateLimitEntriesTokens | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRateLimitEntriesTokensOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRateLimitEntriesTokens | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRateLimitEntriesTokens | cdktn.IResolvable | undefined);
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    private _rate?;
    get rate(): number;
    set rate(value: number);
    resetRate(): void;
    get rateInput(): number | undefined;
}
export declare class BedrockagentcoreGatewayRateLimitEntriesTokensList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRateLimitEntriesTokens[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRateLimitEntriesTokensOutputReference;
}
export interface BedrockagentcoreGatewayRateLimitEntries {
    /**
    * Connection rate limits (per second only). Limited to 1 entry for now. — P2
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#connections BedrockagentcoreGatewayRateLimit#connections}
    */
    readonly connections?: BedrockagentcoreGatewayRateLimitEntriesConnections[] | cdktn.IResolvable;
    /**
    * Map of dimension name to dimension value for a rule entry
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#dimensions BedrockagentcoreGatewayRateLimit#dimensions}
    */
    readonly dimensions: {
        [key: string]: string;
    };
    /**
    * Request rate limits (RPS or RPM). Limited to 1 entry for now.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#requests BedrockagentcoreGatewayRateLimit#requests}
    */
    readonly requests?: BedrockagentcoreGatewayRateLimitEntriesRequests[] | cdktn.IResolvable;
    /**
    * Token rate limits (TPM). Limited to 1 entry for now. — P1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#tokens BedrockagentcoreGatewayRateLimit#tokens}
    */
    readonly tokens?: BedrockagentcoreGatewayRateLimitEntriesTokens[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRateLimitEntriesToTerraform(struct?: BedrockagentcoreGatewayRateLimitEntries | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRateLimitEntriesToHclTerraform(struct?: BedrockagentcoreGatewayRateLimitEntries | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRateLimitEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRateLimitEntries | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRateLimitEntries | cdktn.IResolvable | undefined);
    private _connections;
    get connections(): BedrockagentcoreGatewayRateLimitEntriesConnectionsList;
    putConnections(value: BedrockagentcoreGatewayRateLimitEntriesConnections[] | cdktn.IResolvable): void;
    resetConnections(): void;
    get connectionsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRateLimitEntriesConnections[] | undefined;
    private _dimensions?;
    get dimensions(): {
        [key: string]: string;
    };
    set dimensions(value: {
        [key: string]: string;
    });
    get dimensionsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests;
    get requests(): BedrockagentcoreGatewayRateLimitEntriesRequestsList;
    putRequests(value: BedrockagentcoreGatewayRateLimitEntriesRequests[] | cdktn.IResolvable): void;
    resetRequests(): void;
    get requestsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRateLimitEntriesRequests[] | undefined;
    private _tokens;
    get tokens(): BedrockagentcoreGatewayRateLimitEntriesTokensList;
    putTokens(value: BedrockagentcoreGatewayRateLimitEntriesTokens[] | cdktn.IResolvable): void;
    resetTokens(): void;
    get tokensInput(): cdktn.IResolvable | BedrockagentcoreGatewayRateLimitEntriesTokens[] | undefined;
}
export declare class BedrockagentcoreGatewayRateLimitEntriesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRateLimitEntries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRateLimitEntriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit awscc_bedrockagentcore_gateway_rate_limit}
*/
export declare class BedrockagentcoreGatewayRateLimit extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_gateway_rate_limit";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreGatewayRateLimit resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreGatewayRateLimit to import
    * @param importFromId The id of the existing BedrockagentcoreGatewayRateLimit that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreGatewayRateLimit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rate_limit awscc_bedrockagentcore_gateway_rate_limit} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreGatewayRateLimitConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreGatewayRateLimitConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dimensionKeys?;
    get dimensionKeys(): string[];
    set dimensionKeys(value: string[]);
    get dimensionKeysInput(): string[] | undefined;
    private _entries;
    get entries(): BedrockagentcoreGatewayRateLimitEntriesList;
    putEntries(value: BedrockagentcoreGatewayRateLimitEntries[] | cdktn.IResolvable): void;
    get entriesInput(): cdktn.IResolvable | BedrockagentcoreGatewayRateLimitEntries[] | undefined;
    private _gatewayIdentifier?;
    get gatewayIdentifier(): string;
    set gatewayIdentifier(value: string);
    resetGatewayIdentifier(): void;
    get gatewayIdentifierInput(): string | undefined;
    get id(): string;
    private _rateLimitId?;
    get rateLimitId(): string;
    set rateLimitId(value: string);
    resetRateLimitId(): void;
    get rateLimitIdInput(): string | undefined;
    get status(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
