/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BudgetsBudgetsActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#action_threshold BudgetsBudgetsAction#action_threshold}
    */
    readonly actionThreshold: BudgetsBudgetsActionActionThreshold;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#action_type BudgetsBudgetsAction#action_type}
    */
    readonly actionType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#approval_model BudgetsBudgetsAction#approval_model}
    */
    readonly approvalModel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#budget_name BudgetsBudgetsAction#budget_name}
    */
    readonly budgetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#definition BudgetsBudgetsAction#definition}
    */
    readonly definition: BudgetsBudgetsActionDefinition;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#execution_role_arn BudgetsBudgetsAction#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#notification_type BudgetsBudgetsAction#notification_type}
    */
    readonly notificationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#resource_tags BudgetsBudgetsAction#resource_tags}
    */
    readonly resourceTags?: BudgetsBudgetsActionResourceTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#subscribers BudgetsBudgetsAction#subscribers}
    */
    readonly subscribers: BudgetsBudgetsActionSubscribers[] | cdktn.IResolvable;
}
export interface BudgetsBudgetsActionActionThreshold {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#type BudgetsBudgetsAction#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#value BudgetsBudgetsAction#value}
    */
    readonly value: number;
}
export declare function budgetsBudgetsActionActionThresholdToTerraform(struct?: BudgetsBudgetsActionActionThreshold | cdktn.IResolvable): any;
export declare function budgetsBudgetsActionActionThresholdToHclTerraform(struct?: BudgetsBudgetsActionActionThreshold | cdktn.IResolvable): any;
export declare class BudgetsBudgetsActionActionThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetsActionActionThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetsActionActionThreshold | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface BudgetsBudgetsActionDefinitionIamActionDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#groups BudgetsBudgetsAction#groups}
    */
    readonly groups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#policy_arn BudgetsBudgetsAction#policy_arn}
    */
    readonly policyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#roles BudgetsBudgetsAction#roles}
    */
    readonly roles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#users BudgetsBudgetsAction#users}
    */
    readonly users?: string[];
}
export declare function budgetsBudgetsActionDefinitionIamActionDefinitionToTerraform(struct?: BudgetsBudgetsActionDefinitionIamActionDefinition | cdktn.IResolvable): any;
export declare function budgetsBudgetsActionDefinitionIamActionDefinitionToHclTerraform(struct?: BudgetsBudgetsActionDefinitionIamActionDefinition | cdktn.IResolvable): any;
export declare class BudgetsBudgetsActionDefinitionIamActionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetsActionDefinitionIamActionDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetsActionDefinitionIamActionDefinition | cdktn.IResolvable | undefined);
    private _groups?;
    get groups(): string[];
    set groups(value: string[]);
    resetGroups(): void;
    get groupsInput(): string[] | undefined;
    private _policyArn?;
    get policyArn(): string;
    set policyArn(value: string);
    resetPolicyArn(): void;
    get policyArnInput(): string | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _users?;
    get users(): string[];
    set users(value: string[]);
    resetUsers(): void;
    get usersInput(): string[] | undefined;
}
export interface BudgetsBudgetsActionDefinitionScpActionDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#policy_id BudgetsBudgetsAction#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#target_ids BudgetsBudgetsAction#target_ids}
    */
    readonly targetIds?: string[];
}
export declare function budgetsBudgetsActionDefinitionScpActionDefinitionToTerraform(struct?: BudgetsBudgetsActionDefinitionScpActionDefinition | cdktn.IResolvable): any;
export declare function budgetsBudgetsActionDefinitionScpActionDefinitionToHclTerraform(struct?: BudgetsBudgetsActionDefinitionScpActionDefinition | cdktn.IResolvable): any;
export declare class BudgetsBudgetsActionDefinitionScpActionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetsActionDefinitionScpActionDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetsActionDefinitionScpActionDefinition | cdktn.IResolvable | undefined);
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _targetIds?;
    get targetIds(): string[];
    set targetIds(value: string[]);
    resetTargetIds(): void;
    get targetIdsInput(): string[] | undefined;
}
export interface BudgetsBudgetsActionDefinitionSsmActionDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#instance_ids BudgetsBudgetsAction#instance_ids}
    */
    readonly instanceIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#region BudgetsBudgetsAction#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#subtype BudgetsBudgetsAction#subtype}
    */
    readonly subtype?: string;
}
export declare function budgetsBudgetsActionDefinitionSsmActionDefinitionToTerraform(struct?: BudgetsBudgetsActionDefinitionSsmActionDefinition | cdktn.IResolvable): any;
export declare function budgetsBudgetsActionDefinitionSsmActionDefinitionToHclTerraform(struct?: BudgetsBudgetsActionDefinitionSsmActionDefinition | cdktn.IResolvable): any;
export declare class BudgetsBudgetsActionDefinitionSsmActionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetsActionDefinitionSsmActionDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetsActionDefinitionSsmActionDefinition | cdktn.IResolvable | undefined);
    private _instanceIds?;
    get instanceIds(): string[];
    set instanceIds(value: string[]);
    resetInstanceIds(): void;
    get instanceIdsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _subtype?;
    get subtype(): string;
    set subtype(value: string);
    resetSubtype(): void;
    get subtypeInput(): string | undefined;
}
export interface BudgetsBudgetsActionDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#iam_action_definition BudgetsBudgetsAction#iam_action_definition}
    */
    readonly iamActionDefinition?: BudgetsBudgetsActionDefinitionIamActionDefinition;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#scp_action_definition BudgetsBudgetsAction#scp_action_definition}
    */
    readonly scpActionDefinition?: BudgetsBudgetsActionDefinitionScpActionDefinition;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#ssm_action_definition BudgetsBudgetsAction#ssm_action_definition}
    */
    readonly ssmActionDefinition?: BudgetsBudgetsActionDefinitionSsmActionDefinition;
}
export declare function budgetsBudgetsActionDefinitionToTerraform(struct?: BudgetsBudgetsActionDefinition | cdktn.IResolvable): any;
export declare function budgetsBudgetsActionDefinitionToHclTerraform(struct?: BudgetsBudgetsActionDefinition | cdktn.IResolvable): any;
export declare class BudgetsBudgetsActionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetsActionDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetsActionDefinition | cdktn.IResolvable | undefined);
    private _iamActionDefinition;
    get iamActionDefinition(): BudgetsBudgetsActionDefinitionIamActionDefinitionOutputReference;
    putIamActionDefinition(value: BudgetsBudgetsActionDefinitionIamActionDefinition): void;
    resetIamActionDefinition(): void;
    get iamActionDefinitionInput(): cdktn.IResolvable | BudgetsBudgetsActionDefinitionIamActionDefinition | undefined;
    private _scpActionDefinition;
    get scpActionDefinition(): BudgetsBudgetsActionDefinitionScpActionDefinitionOutputReference;
    putScpActionDefinition(value: BudgetsBudgetsActionDefinitionScpActionDefinition): void;
    resetScpActionDefinition(): void;
    get scpActionDefinitionInput(): cdktn.IResolvable | BudgetsBudgetsActionDefinitionScpActionDefinition | undefined;
    private _ssmActionDefinition;
    get ssmActionDefinition(): BudgetsBudgetsActionDefinitionSsmActionDefinitionOutputReference;
    putSsmActionDefinition(value: BudgetsBudgetsActionDefinitionSsmActionDefinition): void;
    resetSsmActionDefinition(): void;
    get ssmActionDefinitionInput(): cdktn.IResolvable | BudgetsBudgetsActionDefinitionSsmActionDefinition | undefined;
}
export interface BudgetsBudgetsActionResourceTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#key BudgetsBudgetsAction#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#value BudgetsBudgetsAction#value}
    */
    readonly value?: string;
}
export declare function budgetsBudgetsActionResourceTagsToTerraform(struct?: BudgetsBudgetsActionResourceTags | cdktn.IResolvable): any;
export declare function budgetsBudgetsActionResourceTagsToHclTerraform(struct?: BudgetsBudgetsActionResourceTags | cdktn.IResolvable): any;
export declare class BudgetsBudgetsActionResourceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetsActionResourceTags | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetsActionResourceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BudgetsBudgetsActionResourceTagsList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetsActionResourceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetsActionResourceTagsOutputReference;
}
export interface BudgetsBudgetsActionSubscribers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#address BudgetsBudgetsAction#address}
    */
    readonly address: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#type BudgetsBudgetsAction#type}
    */
    readonly type: string;
}
export declare function budgetsBudgetsActionSubscribersToTerraform(struct?: BudgetsBudgetsActionSubscribers | cdktn.IResolvable): any;
export declare function budgetsBudgetsActionSubscribersToHclTerraform(struct?: BudgetsBudgetsActionSubscribers | cdktn.IResolvable): any;
export declare class BudgetsBudgetsActionSubscribersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetsActionSubscribers | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetsActionSubscribers | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BudgetsBudgetsActionSubscribersList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetsActionSubscribers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetsActionSubscribersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action awscc_budgets_budgets_action}
*/
export declare class BudgetsBudgetsAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_budgets_budgets_action";
    /**
    * Generates CDKTN code for importing a BudgetsBudgetsAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BudgetsBudgetsAction to import
    * @param importFromId The id of the existing BudgetsBudgetsAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BudgetsBudgetsAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/budgets_budgets_action awscc_budgets_budgets_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BudgetsBudgetsActionConfig
    */
    constructor(scope: Construct, id: string, config: BudgetsBudgetsActionConfig);
    get actionId(): string;
    private _actionThreshold;
    get actionThreshold(): BudgetsBudgetsActionActionThresholdOutputReference;
    putActionThreshold(value: BudgetsBudgetsActionActionThreshold): void;
    get actionThresholdInput(): cdktn.IResolvable | BudgetsBudgetsActionActionThreshold | undefined;
    private _actionType?;
    get actionType(): string;
    set actionType(value: string);
    get actionTypeInput(): string | undefined;
    private _approvalModel?;
    get approvalModel(): string;
    set approvalModel(value: string);
    resetApprovalModel(): void;
    get approvalModelInput(): string | undefined;
    private _budgetName?;
    get budgetName(): string;
    set budgetName(value: string);
    get budgetNameInput(): string | undefined;
    private _definition;
    get definition(): BudgetsBudgetsActionDefinitionOutputReference;
    putDefinition(value: BudgetsBudgetsActionDefinition): void;
    get definitionInput(): cdktn.IResolvable | BudgetsBudgetsActionDefinition | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    get id(): string;
    private _notificationType?;
    get notificationType(): string;
    set notificationType(value: string);
    get notificationTypeInput(): string | undefined;
    private _resourceTags;
    get resourceTags(): BudgetsBudgetsActionResourceTagsList;
    putResourceTags(value: BudgetsBudgetsActionResourceTags[] | cdktn.IResolvable): void;
    resetResourceTags(): void;
    get resourceTagsInput(): cdktn.IResolvable | BudgetsBudgetsActionResourceTags[] | undefined;
    private _subscribers;
    get subscribers(): BudgetsBudgetsActionSubscribersList;
    putSubscribers(value: BudgetsBudgetsActionSubscribers[] | cdktn.IResolvable): void;
    get subscribersInput(): cdktn.IResolvable | BudgetsBudgetsActionSubscribers[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
