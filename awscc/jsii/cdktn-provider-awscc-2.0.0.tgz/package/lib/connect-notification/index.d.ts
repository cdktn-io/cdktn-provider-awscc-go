/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectNotificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The content of the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#content ConnectNotification#content}
    */
    readonly content: ConnectNotificationContent;
    /**
    * The time a notification will expire
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#expires_at ConnectNotification#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#instance_arn ConnectNotification#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The priority of the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#priority ConnectNotification#priority}
    */
    readonly priority?: string;
    /**
    * The recipients of the notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#recipients ConnectNotification#recipients}
    */
    readonly recipients?: string[];
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#tags ConnectNotification#tags}
    */
    readonly tags?: ConnectNotificationTags[] | cdktn.IResolvable;
}
export interface ConnectNotificationContent {
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#de_de ConnectNotification#de_de}
    */
    readonly deDe?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#en_us ConnectNotification#en_us}
    */
    readonly enUs?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#es_es ConnectNotification#es_es}
    */
    readonly esEs?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#fr_fr ConnectNotification#fr_fr}
    */
    readonly frFr?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#id_id ConnectNotification#id_id}
    */
    readonly idId?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#it_it ConnectNotification#it_it}
    */
    readonly itIt?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#ja_jp ConnectNotification#ja_jp}
    */
    readonly jaJp?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#ko_kr ConnectNotification#ko_kr}
    */
    readonly koKr?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#pt_br ConnectNotification#pt_br}
    */
    readonly ptBr?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#zh_cn ConnectNotification#zh_cn}
    */
    readonly zhCn?: string;
    /**
    * Localized notification content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#zh_tw ConnectNotification#zh_tw}
    */
    readonly zhTw?: string;
}
export declare function connectNotificationContentToTerraform(struct?: ConnectNotificationContent | cdktn.IResolvable): any;
export declare function connectNotificationContentToHclTerraform(struct?: ConnectNotificationContent | cdktn.IResolvable): any;
export declare class ConnectNotificationContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectNotificationContent | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectNotificationContent | cdktn.IResolvable | undefined);
    private _deDe?;
    get deDe(): string;
    set deDe(value: string);
    resetDeDe(): void;
    get deDeInput(): string | undefined;
    private _enUs?;
    get enUs(): string;
    set enUs(value: string);
    resetEnUs(): void;
    get enUsInput(): string | undefined;
    private _esEs?;
    get esEs(): string;
    set esEs(value: string);
    resetEsEs(): void;
    get esEsInput(): string | undefined;
    private _frFr?;
    get frFr(): string;
    set frFr(value: string);
    resetFrFr(): void;
    get frFrInput(): string | undefined;
    private _idId?;
    get idId(): string;
    set idId(value: string);
    resetIdId(): void;
    get idIdInput(): string | undefined;
    private _itIt?;
    get itIt(): string;
    set itIt(value: string);
    resetItIt(): void;
    get itItInput(): string | undefined;
    private _jaJp?;
    get jaJp(): string;
    set jaJp(value: string);
    resetJaJp(): void;
    get jaJpInput(): string | undefined;
    private _koKr?;
    get koKr(): string;
    set koKr(value: string);
    resetKoKr(): void;
    get koKrInput(): string | undefined;
    private _ptBr?;
    get ptBr(): string;
    set ptBr(value: string);
    resetPtBr(): void;
    get ptBrInput(): string | undefined;
    private _zhCn?;
    get zhCn(): string;
    set zhCn(value: string);
    resetZhCn(): void;
    get zhCnInput(): string | undefined;
    private _zhTw?;
    get zhTw(): string;
    set zhTw(value: string);
    resetZhTw(): void;
    get zhTwInput(): string | undefined;
}
export interface ConnectNotificationTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#key ConnectNotification#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#value ConnectNotification#value}
    */
    readonly value?: string;
}
export declare function connectNotificationTagsToTerraform(struct?: ConnectNotificationTags | cdktn.IResolvable): any;
export declare function connectNotificationTagsToHclTerraform(struct?: ConnectNotificationTags | cdktn.IResolvable): any;
export declare class ConnectNotificationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectNotificationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectNotificationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectNotificationTagsList extends cdktn.ComplexList {
    internalValue?: ConnectNotificationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectNotificationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification awscc_connect_notification}
*/
export declare class ConnectNotification extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_notification";
    /**
    * Generates CDKTN code for importing a ConnectNotification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectNotification to import
    * @param importFromId The id of the existing ConnectNotification that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectNotification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_notification awscc_connect_notification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectNotificationConfig
    */
    constructor(scope: Construct, id: string, config: ConnectNotificationConfig);
    get arn(): string;
    private _content;
    get content(): ConnectNotificationContentOutputReference;
    putContent(value: ConnectNotificationContent): void;
    get contentInput(): cdktn.IResolvable | ConnectNotificationContent | undefined;
    get createdAt(): string;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get notificationId(): string;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    resetRecipients(): void;
    get recipientsInput(): string[] | undefined;
    private _tags;
    get tags(): ConnectNotificationTagsList;
    putTags(value: ConnectNotificationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectNotificationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
