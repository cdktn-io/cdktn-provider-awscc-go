/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AthenaPreparedStatementConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the prepared statement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_prepared_statement#description AthenaPreparedStatement#description}
    */
    readonly description?: string;
    /**
    * The query string for the prepared statement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_prepared_statement#query_statement AthenaPreparedStatement#query_statement}
    */
    readonly queryStatement: string;
    /**
    * The name of the prepared statement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_prepared_statement#statement_name AthenaPreparedStatement#statement_name}
    */
    readonly statementName: string;
    /**
    * The name of the workgroup to which the prepared statement belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_prepared_statement#work_group AthenaPreparedStatement#work_group}
    */
    readonly workGroup: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_prepared_statement awscc_athena_prepared_statement}
*/
export declare class AthenaPreparedStatement extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_athena_prepared_statement";
    /**
    * Generates CDKTN code for importing a AthenaPreparedStatement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AthenaPreparedStatement to import
    * @param importFromId The id of the existing AthenaPreparedStatement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_prepared_statement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AthenaPreparedStatement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_prepared_statement awscc_athena_prepared_statement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AthenaPreparedStatementConfig
    */
    constructor(scope: Construct, id: string, config: AthenaPreparedStatementConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _queryStatement?;
    get queryStatement(): string;
    set queryStatement(value: string);
    get queryStatementInput(): string | undefined;
    private _statementName?;
    get statementName(): string;
    set statementName(value: string);
    get statementNameInput(): string | undefined;
    private _workGroup?;
    get workGroup(): string;
    set workGroup(value: string);
    get workGroupInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
