/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificatemanagerCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the private certificate authority (CA) that will be used to issue the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#certificate_authority_arn CertificatemanagerCertificate#certificate_authority_arn}
    */
    readonly certificateAuthorityArn?: string;
    /**
    * Specifies whether the certificate can be exported. ENABLED allows the certificate to be exported, DISABLED prevents export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#certificate_export CertificatemanagerCertificate#certificate_export}
    */
    readonly certificateExport?: string;
    /**
    * You can opt out of certificate transparency logging by specifying the DISABLED option. Opt in by specifying ENABLED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#certificate_transparency_logging_preference CertificatemanagerCertificate#certificate_transparency_logging_preference}
    */
    readonly certificateTransparencyLoggingPreference?: string;
    /**
    * The fully qualified domain name (FQDN), such as www.example.com, with which you want to secure an ACM certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#domain_name CertificatemanagerCertificate#domain_name}
    */
    readonly domainName: string;
    /**
    * Domain information that domain name registrars use to verify your identity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#domain_validation_options CertificatemanagerCertificate#domain_validation_options}
    */
    readonly domainValidationOptions?: CertificatemanagerCertificateDomainValidationOptions[] | cdktn.IResolvable;
    /**
    * Specifies the algorithm of the public and private key pair that your certificate uses to encrypt data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#key_algorithm CertificatemanagerCertificate#key_algorithm}
    */
    readonly keyAlgorithm?: string;
    /**
    * Additional FQDNs to be included in the Subject Alternative Name extension of the ACM certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#subject_alternative_names CertificatemanagerCertificate#subject_alternative_names}
    */
    readonly subjectAlternativeNames?: string[];
    /**
    * Key-value pairs that can identify the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#tags CertificatemanagerCertificate#tags}
    */
    readonly tags?: CertificatemanagerCertificateTags[] | cdktn.IResolvable;
    /**
    * The method you want to use to validate that you own or control the domain associated with a public certificate. Valid values are DNS, EMAIL or HTTP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#validation_method CertificatemanagerCertificate#validation_method}
    */
    readonly validationMethod?: string;
}
export interface CertificatemanagerCertificateDomainValidationOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#domain_name CertificatemanagerCertificate#domain_name}
    */
    readonly domainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#hosted_zone_id CertificatemanagerCertificate#hosted_zone_id}
    */
    readonly hostedZoneId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#validation_domain CertificatemanagerCertificate#validation_domain}
    */
    readonly validationDomain?: string;
}
export declare function certificatemanagerCertificateDomainValidationOptionsToTerraform(struct?: CertificatemanagerCertificateDomainValidationOptions | cdktn.IResolvable): any;
export declare function certificatemanagerCertificateDomainValidationOptionsToHclTerraform(struct?: CertificatemanagerCertificateDomainValidationOptions | cdktn.IResolvable): any;
export declare class CertificatemanagerCertificateDomainValidationOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificatemanagerCertificateDomainValidationOptions | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerCertificateDomainValidationOptions | cdktn.IResolvable | undefined);
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    resetDomainName(): void;
    get domainNameInput(): string | undefined;
    private _hostedZoneId?;
    get hostedZoneId(): string;
    set hostedZoneId(value: string);
    resetHostedZoneId(): void;
    get hostedZoneIdInput(): string | undefined;
    private _validationDomain?;
    get validationDomain(): string;
    set validationDomain(value: string);
    resetValidationDomain(): void;
    get validationDomainInput(): string | undefined;
}
export declare class CertificatemanagerCertificateDomainValidationOptionsList extends cdktn.ComplexList {
    internalValue?: CertificatemanagerCertificateDomainValidationOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificatemanagerCertificateDomainValidationOptionsOutputReference;
}
export interface CertificatemanagerCertificateTags {
    /**
    * The tag's key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#key CertificatemanagerCertificate#key}
    */
    readonly key?: string;
    /**
    * The tag's value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#value CertificatemanagerCertificate#value}
    */
    readonly value?: string;
}
export declare function certificatemanagerCertificateTagsToTerraform(struct?: CertificatemanagerCertificateTags | cdktn.IResolvable): any;
export declare function certificatemanagerCertificateTagsToHclTerraform(struct?: CertificatemanagerCertificateTags | cdktn.IResolvable): any;
export declare class CertificatemanagerCertificateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificatemanagerCertificateTags | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerCertificateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CertificatemanagerCertificateTagsList extends cdktn.ComplexList {
    internalValue?: CertificatemanagerCertificateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificatemanagerCertificateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate awscc_certificatemanager_certificate}
*/
export declare class CertificatemanagerCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_certificatemanager_certificate";
    /**
    * Generates CDKTN code for importing a CertificatemanagerCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificatemanagerCertificate to import
    * @param importFromId The id of the existing CertificatemanagerCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificatemanagerCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_certificate awscc_certificatemanager_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificatemanagerCertificateConfig
    */
    constructor(scope: Construct, id: string, config: CertificatemanagerCertificateConfig);
    get certificateArn(): string;
    private _certificateAuthorityArn?;
    get certificateAuthorityArn(): string;
    set certificateAuthorityArn(value: string);
    resetCertificateAuthorityArn(): void;
    get certificateAuthorityArnInput(): string | undefined;
    private _certificateExport?;
    get certificateExport(): string;
    set certificateExport(value: string);
    resetCertificateExport(): void;
    get certificateExportInput(): string | undefined;
    private _certificateTransparencyLoggingPreference?;
    get certificateTransparencyLoggingPreference(): string;
    set certificateTransparencyLoggingPreference(value: string);
    resetCertificateTransparencyLoggingPreference(): void;
    get certificateTransparencyLoggingPreferenceInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _domainValidationOptions;
    get domainValidationOptions(): CertificatemanagerCertificateDomainValidationOptionsList;
    putDomainValidationOptions(value: CertificatemanagerCertificateDomainValidationOptions[] | cdktn.IResolvable): void;
    resetDomainValidationOptions(): void;
    get domainValidationOptionsInput(): cdktn.IResolvable | CertificatemanagerCertificateDomainValidationOptions[] | undefined;
    get id(): string;
    private _keyAlgorithm?;
    get keyAlgorithm(): string;
    set keyAlgorithm(value: string);
    resetKeyAlgorithm(): void;
    get keyAlgorithmInput(): string | undefined;
    private _subjectAlternativeNames?;
    get subjectAlternativeNames(): string[];
    set subjectAlternativeNames(value: string[]);
    resetSubjectAlternativeNames(): void;
    get subjectAlternativeNamesInput(): string[] | undefined;
    private _tags;
    get tags(): CertificatemanagerCertificateTagsList;
    putTags(value: CertificatemanagerCertificateTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CertificatemanagerCertificateTags[] | undefined;
    private _validationMethod?;
    get validationMethod(): string;
    set validationMethod(value: string);
    resetValidationMethod(): void;
    get validationMethodInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
