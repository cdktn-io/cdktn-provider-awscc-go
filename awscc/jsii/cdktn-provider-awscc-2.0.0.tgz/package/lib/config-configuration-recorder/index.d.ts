/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigConfigurationRecorderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the configuration recorder. By default, AWS Config assigns the name "default" when creating the configuration recorder. To change the configuration recorder name, you must use the DeleteConfigurationRecorder action to delete your current configuration recorder, and then you must use the PutConfigurationRecorder command to create a configuration recorder that has the desired name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#name ConfigConfigurationRecorder#name}
    */
    readonly name?: string;
    /**
    * Specifies which resource types are in scope for the configuration recorder to record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#recording_group ConfigConfigurationRecorder#recording_group}
    */
    readonly recordingGroup?: ConfigConfigurationRecorderRecordingGroup;
    /**
    * Specifies the default recording frequency for the configuration recorder.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#recording_mode ConfigConfigurationRecorder#recording_mode}
    */
    readonly recordingMode?: ConfigConfigurationRecorderRecordingMode;
    /**
    * The Amazon Resource Name (ARN) of the role that allows AWS Config to read S3 objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#role_arn ConfigConfigurationRecorder#role_arn}
    */
    readonly roleArn: string;
    /**
    * Defaults to 'true'. Controls whether the recorder starts recording after the create operation. Set this to 'false' for development and testing purposes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#started_on_create ConfigConfigurationRecorder#started_on_create}
    */
    readonly startedOnCreate?: boolean | cdktn.IResolvable;
}
export interface ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypes {
    /**
    * A comma-separated list of resource types to exclude from recording by the configuration recorder.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#resource_types ConfigConfigurationRecorder#resource_types}
    */
    readonly resourceTypes?: string[];
}
export declare function configConfigurationRecorderRecordingGroupExclusionByResourceTypesToTerraform(struct?: ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypes | cdktn.IResolvable): any;
export declare function configConfigurationRecorderRecordingGroupExclusionByResourceTypesToHclTerraform(struct?: ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypes | cdktn.IResolvable): any;
export declare class ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypes | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypes | cdktn.IResolvable | undefined);
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
}
export interface ConfigConfigurationRecorderRecordingGroupRecordingStrategy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#use_only ConfigConfigurationRecorder#use_only}
    */
    readonly useOnly?: string;
}
export declare function configConfigurationRecorderRecordingGroupRecordingStrategyToTerraform(struct?: ConfigConfigurationRecorderRecordingGroupRecordingStrategy | cdktn.IResolvable): any;
export declare function configConfigurationRecorderRecordingGroupRecordingStrategyToHclTerraform(struct?: ConfigConfigurationRecorderRecordingGroupRecordingStrategy | cdktn.IResolvable): any;
export declare class ConfigConfigurationRecorderRecordingGroupRecordingStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigurationRecorderRecordingGroupRecordingStrategy | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigurationRecorderRecordingGroupRecordingStrategy | cdktn.IResolvable | undefined);
    private _useOnly?;
    get useOnly(): string;
    set useOnly(value: string);
    resetUseOnly(): void;
    get useOnlyInput(): string | undefined;
}
export interface ConfigConfigurationRecorderRecordingGroup {
    /**
    * Specifies whether AWS Config records configuration changes for all supported resource types, excluding the global IAM resource types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#all_supported ConfigConfigurationRecorder#all_supported}
    */
    readonly allSupported?: boolean | cdktn.IResolvable;
    /**
    * An object that specifies how AWS Config excludes resource types from being recorded by the configuration recorder.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#exclusion_by_resource_types ConfigConfigurationRecorder#exclusion_by_resource_types}
    */
    readonly exclusionByResourceTypes?: ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypes;
    /**
    * This option is a bundle which only applies to the global IAM resource types: IAM users, groups, roles, and customer managed policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#include_global_resource_types ConfigConfigurationRecorder#include_global_resource_types}
    */
    readonly includeGlobalResourceTypes?: boolean | cdktn.IResolvable;
    /**
    * An object that specifies the recording strategy for the configuration recorder.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#recording_strategy ConfigConfigurationRecorder#recording_strategy}
    */
    readonly recordingStrategy?: ConfigConfigurationRecorderRecordingGroupRecordingStrategy;
    /**
    * A comma-separated list that specifies which resource types AWS Config records.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#resource_types ConfigConfigurationRecorder#resource_types}
    */
    readonly resourceTypes?: string[];
}
export declare function configConfigurationRecorderRecordingGroupToTerraform(struct?: ConfigConfigurationRecorderRecordingGroup | cdktn.IResolvable): any;
export declare function configConfigurationRecorderRecordingGroupToHclTerraform(struct?: ConfigConfigurationRecorderRecordingGroup | cdktn.IResolvable): any;
export declare class ConfigConfigurationRecorderRecordingGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigurationRecorderRecordingGroup | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigurationRecorderRecordingGroup | cdktn.IResolvable | undefined);
    private _allSupported?;
    get allSupported(): boolean | cdktn.IResolvable;
    set allSupported(value: boolean | cdktn.IResolvable);
    resetAllSupported(): void;
    get allSupportedInput(): boolean | cdktn.IResolvable | undefined;
    private _exclusionByResourceTypes;
    get exclusionByResourceTypes(): ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypesOutputReference;
    putExclusionByResourceTypes(value: ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypes): void;
    resetExclusionByResourceTypes(): void;
    get exclusionByResourceTypesInput(): cdktn.IResolvable | ConfigConfigurationRecorderRecordingGroupExclusionByResourceTypes | undefined;
    private _includeGlobalResourceTypes?;
    get includeGlobalResourceTypes(): boolean | cdktn.IResolvable;
    set includeGlobalResourceTypes(value: boolean | cdktn.IResolvable);
    resetIncludeGlobalResourceTypes(): void;
    get includeGlobalResourceTypesInput(): boolean | cdktn.IResolvable | undefined;
    private _recordingStrategy;
    get recordingStrategy(): ConfigConfigurationRecorderRecordingGroupRecordingStrategyOutputReference;
    putRecordingStrategy(value: ConfigConfigurationRecorderRecordingGroupRecordingStrategy): void;
    resetRecordingStrategy(): void;
    get recordingStrategyInput(): cdktn.IResolvable | ConfigConfigurationRecorderRecordingGroupRecordingStrategy | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
}
export interface ConfigConfigurationRecorderRecordingModeRecordingModeOverrides {
    /**
    * A description that you provide for the override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#description ConfigConfigurationRecorder#description}
    */
    readonly description?: string;
    /**
    * The recording frequency that will be applied to all the resource types specified in the override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#recording_frequency ConfigConfigurationRecorder#recording_frequency}
    */
    readonly recordingFrequency?: string;
    /**
    * A comma-separated list that specifies which resource types AWS Config includes in the override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#resource_types ConfigConfigurationRecorder#resource_types}
    */
    readonly resourceTypes?: string[];
}
export declare function configConfigurationRecorderRecordingModeRecordingModeOverridesToTerraform(struct?: ConfigConfigurationRecorderRecordingModeRecordingModeOverrides | cdktn.IResolvable): any;
export declare function configConfigurationRecorderRecordingModeRecordingModeOverridesToHclTerraform(struct?: ConfigConfigurationRecorderRecordingModeRecordingModeOverrides | cdktn.IResolvable): any;
export declare class ConfigConfigurationRecorderRecordingModeRecordingModeOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigConfigurationRecorderRecordingModeRecordingModeOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigurationRecorderRecordingModeRecordingModeOverrides | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _recordingFrequency?;
    get recordingFrequency(): string;
    set recordingFrequency(value: string);
    resetRecordingFrequency(): void;
    get recordingFrequencyInput(): string | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
}
export declare class ConfigConfigurationRecorderRecordingModeRecordingModeOverridesList extends cdktn.ComplexList {
    internalValue?: ConfigConfigurationRecorderRecordingModeRecordingModeOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigConfigurationRecorderRecordingModeRecordingModeOverridesOutputReference;
}
export interface ConfigConfigurationRecorderRecordingMode {
    /**
    * The default recording frequency that AWS Config uses to record configuration changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#recording_frequency ConfigConfigurationRecorder#recording_frequency}
    */
    readonly recordingFrequency?: string;
    /**
    * An array of 'RecordingModeOverride' objects for you to specify your overrides for the recording mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#recording_mode_overrides ConfigConfigurationRecorder#recording_mode_overrides}
    */
    readonly recordingModeOverrides?: ConfigConfigurationRecorderRecordingModeRecordingModeOverrides[] | cdktn.IResolvable;
}
export declare function configConfigurationRecorderRecordingModeToTerraform(struct?: ConfigConfigurationRecorderRecordingMode | cdktn.IResolvable): any;
export declare function configConfigurationRecorderRecordingModeToHclTerraform(struct?: ConfigConfigurationRecorderRecordingMode | cdktn.IResolvable): any;
export declare class ConfigConfigurationRecorderRecordingModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigurationRecorderRecordingMode | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigurationRecorderRecordingMode | cdktn.IResolvable | undefined);
    private _recordingFrequency?;
    get recordingFrequency(): string;
    set recordingFrequency(value: string);
    resetRecordingFrequency(): void;
    get recordingFrequencyInput(): string | undefined;
    private _recordingModeOverrides;
    get recordingModeOverrides(): ConfigConfigurationRecorderRecordingModeRecordingModeOverridesList;
    putRecordingModeOverrides(value: ConfigConfigurationRecorderRecordingModeRecordingModeOverrides[] | cdktn.IResolvable): void;
    resetRecordingModeOverrides(): void;
    get recordingModeOverridesInput(): cdktn.IResolvable | ConfigConfigurationRecorderRecordingModeRecordingModeOverrides[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder awscc_config_configuration_recorder}
*/
export declare class ConfigConfigurationRecorder extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_configuration_recorder";
    /**
    * Generates CDKTN code for importing a ConfigConfigurationRecorder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigConfigurationRecorder to import
    * @param importFromId The id of the existing ConfigConfigurationRecorder that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigConfigurationRecorder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/config_configuration_recorder awscc_config_configuration_recorder} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigConfigurationRecorderConfig
    */
    constructor(scope: Construct, id: string, config: ConfigConfigurationRecorderConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _recordingGroup;
    get recordingGroup(): ConfigConfigurationRecorderRecordingGroupOutputReference;
    putRecordingGroup(value: ConfigConfigurationRecorderRecordingGroup): void;
    resetRecordingGroup(): void;
    get recordingGroupInput(): cdktn.IResolvable | ConfigConfigurationRecorderRecordingGroup | undefined;
    private _recordingMode;
    get recordingMode(): ConfigConfigurationRecorderRecordingModeOutputReference;
    putRecordingMode(value: ConfigConfigurationRecorderRecordingMode): void;
    resetRecordingMode(): void;
    get recordingModeInput(): cdktn.IResolvable | ConfigConfigurationRecorderRecordingMode | undefined;
    get resourceArn(): string;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _startedOnCreate?;
    get startedOnCreate(): boolean | cdktn.IResolvable;
    set startedOnCreate(value: boolean | cdktn.IResolvable);
    resetStartedOnCreate(): void;
    get startedOnCreateInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
