/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAppconfigConfigurationProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/appconfig_configuration_profile#id DataAwsccAppconfigConfigurationProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAppconfigConfigurationProfileTags {
}
export declare function dataAwsccAppconfigConfigurationProfileTagsToTerraform(struct?: DataAwsccAppconfigConfigurationProfileTags): any;
export declare function dataAwsccAppconfigConfigurationProfileTagsToHclTerraform(struct?: DataAwsccAppconfigConfigurationProfileTags): any;
export declare class DataAwsccAppconfigConfigurationProfileTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigConfigurationProfileTags | undefined;
    set internalValue(value: DataAwsccAppconfigConfigurationProfileTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAppconfigConfigurationProfileTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigConfigurationProfileTagsOutputReference;
}
export interface DataAwsccAppconfigConfigurationProfileValidators {
}
export declare function dataAwsccAppconfigConfigurationProfileValidatorsToTerraform(struct?: DataAwsccAppconfigConfigurationProfileValidators): any;
export declare function dataAwsccAppconfigConfigurationProfileValidatorsToHclTerraform(struct?: DataAwsccAppconfigConfigurationProfileValidators): any;
export declare class DataAwsccAppconfigConfigurationProfileValidatorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigConfigurationProfileValidators | undefined;
    set internalValue(value: DataAwsccAppconfigConfigurationProfileValidators | undefined);
    get content(): string;
    get type(): string;
}
export declare class DataAwsccAppconfigConfigurationProfileValidatorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigConfigurationProfileValidatorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/appconfig_configuration_profile awscc_appconfig_configuration_profile}
*/
export declare class DataAwsccAppconfigConfigurationProfile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_appconfig_configuration_profile";
    /**
    * Generates CDKTN code for importing a DataAwsccAppconfigConfigurationProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAppconfigConfigurationProfile to import
    * @param importFromId The id of the existing DataAwsccAppconfigConfigurationProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/appconfig_configuration_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAppconfigConfigurationProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/appconfig_configuration_profile awscc_appconfig_configuration_profile} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAppconfigConfigurationProfileConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAppconfigConfigurationProfileConfig);
    get applicationId(): string;
    get configurationProfileId(): string;
    get deletionProtectionCheck(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get kmsKeyArn(): string;
    get kmsKeyIdentifier(): string;
    get locationUri(): string;
    get name(): string;
    get retrievalRoleArn(): string;
    private _tags;
    get tags(): DataAwsccAppconfigConfigurationProfileTagsList;
    get type(): string;
    private _validators;
    get validators(): DataAwsccAppconfigConfigurationProfileValidatorsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
