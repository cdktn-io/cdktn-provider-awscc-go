/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationResourceVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the IAM execution role to use to register the type. If your resource type calls AWS APIs in any of its handlers, you must create an IAM execution role that includes the necessary permissions to call those AWS APIs, and provision that execution role in your account. CloudFormation then assumes that execution role to provide your resource type with the appropriate credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version#execution_role_arn CloudformationResourceVersion#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Specifies logging configuration information for a type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version#logging_config CloudformationResourceVersion#logging_config}
    */
    readonly loggingConfig?: CloudformationResourceVersionLoggingConfig;
    /**
    * A url to the S3 bucket containing the schema handler package that contains the schema, event handlers, and associated files for the type you want to register.
    *
    * For information on generating a schema handler package for the type you want to register, see submit in the CloudFormation CLI User Guide.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version#schema_handler_package CloudformationResourceVersion#schema_handler_package}
    */
    readonly schemaHandlerPackage: string;
    /**
    * The name of the type being registered.
    *
    * We recommend that type names adhere to the following pattern: company_or_organization::service::type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version#type_name CloudformationResourceVersion#type_name}
    */
    readonly typeName: string;
}
export interface CloudformationResourceVersionLoggingConfig {
    /**
    * The Amazon CloudWatch log group to which CloudFormation sends error logging information when invoking the type's handlers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version#log_group_name CloudformationResourceVersion#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The ARN of the role that CloudFormation should assume when sending log entries to CloudWatch logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version#log_role_arn CloudformationResourceVersion#log_role_arn}
    */
    readonly logRoleArn?: string;
}
export declare function cloudformationResourceVersionLoggingConfigToTerraform(struct?: CloudformationResourceVersionLoggingConfig | cdktn.IResolvable): any;
export declare function cloudformationResourceVersionLoggingConfigToHclTerraform(struct?: CloudformationResourceVersionLoggingConfig | cdktn.IResolvable): any;
export declare class CloudformationResourceVersionLoggingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationResourceVersionLoggingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationResourceVersionLoggingConfig | cdktn.IResolvable | undefined);
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _logRoleArn?;
    get logRoleArn(): string;
    set logRoleArn(value: string);
    resetLogRoleArn(): void;
    get logRoleArnInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version awscc_cloudformation_resource_version}
*/
export declare class CloudformationResourceVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_resource_version";
    /**
    * Generates CDKTN code for importing a CloudformationResourceVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationResourceVersion to import
    * @param importFromId The id of the existing CloudformationResourceVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationResourceVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_resource_version awscc_cloudformation_resource_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationResourceVersionConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationResourceVersionConfig);
    get arn(): string;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    get id(): string;
    get isDefaultVersion(): cdktn.IResolvable;
    private _loggingConfig;
    get loggingConfig(): CloudformationResourceVersionLoggingConfigOutputReference;
    putLoggingConfig(value: CloudformationResourceVersionLoggingConfig): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): cdktn.IResolvable | CloudformationResourceVersionLoggingConfig | undefined;
    get provisioningType(): string;
    private _schemaHandlerPackage?;
    get schemaHandlerPackage(): string;
    set schemaHandlerPackage(value: string);
    get schemaHandlerPackageInput(): string | undefined;
    get typeArn(): string;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    get typeNameInput(): string | undefined;
    get versionId(): string;
    get visibility(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
