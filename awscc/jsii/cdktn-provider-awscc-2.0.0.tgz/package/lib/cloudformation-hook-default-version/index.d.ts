/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationHookDefaultVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the type being registered.
    *
    * We recommend that type names adhere to the following pattern: company_or_organization::service::type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_default_version#type_name CloudformationHookDefaultVersion#type_name}
    */
    readonly typeName?: string;
    /**
    * The Amazon Resource Name (ARN) of the type version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_default_version#type_version_arn CloudformationHookDefaultVersion#type_version_arn}
    */
    readonly typeVersionArn?: string;
    /**
    * The ID of an existing version of the hook to set as the default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_default_version#version_id CloudformationHookDefaultVersion#version_id}
    */
    readonly versionId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_default_version awscc_cloudformation_hook_default_version}
*/
export declare class CloudformationHookDefaultVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_hook_default_version";
    /**
    * Generates CDKTN code for importing a CloudformationHookDefaultVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationHookDefaultVersion to import
    * @param importFromId The id of the existing CloudformationHookDefaultVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_default_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationHookDefaultVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_default_version awscc_cloudformation_hook_default_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationHookDefaultVersionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudformationHookDefaultVersionConfig);
    get arn(): string;
    get id(): string;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    resetTypeName(): void;
    get typeNameInput(): string | undefined;
    private _typeVersionArn?;
    get typeVersionArn(): string;
    set typeVersionArn(value: string);
    resetTypeVersionArn(): void;
    get typeVersionArnInput(): string | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
