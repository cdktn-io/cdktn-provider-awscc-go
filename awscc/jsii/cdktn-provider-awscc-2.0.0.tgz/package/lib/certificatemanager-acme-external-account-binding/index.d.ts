/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificatemanagerAcmeExternalAccountBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the ACME endpoint this binding is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#acme_endpoint_arn CertificatemanagerAcmeExternalAccountBinding#acme_endpoint_arn}
    */
    readonly acmeEndpointArn: string;
    /**
    * The expiration configuration for the external account binding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#expiration CertificatemanagerAcmeExternalAccountBinding#expiration}
    */
    readonly expiration?: CertificatemanagerAcmeExternalAccountBindingExpiration;
    /**
    * The IAM role ARN for cross-account access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#role_arn CertificatemanagerAcmeExternalAccountBinding#role_arn}
    */
    readonly roleArn: string;
    /**
    * Tags associated with the external account binding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#tags CertificatemanagerAcmeExternalAccountBinding#tags}
    */
    readonly tags?: CertificatemanagerAcmeExternalAccountBindingTags[] | cdktn.IResolvable;
}
export interface CertificatemanagerAcmeExternalAccountBindingExpiration {
    /**
    * The time unit for the expiration value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#type CertificatemanagerAcmeExternalAccountBinding#type}
    */
    readonly type?: string;
    /**
    * The expiration value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#value CertificatemanagerAcmeExternalAccountBinding#value}
    */
    readonly value?: number;
}
export declare function certificatemanagerAcmeExternalAccountBindingExpirationToTerraform(struct?: CertificatemanagerAcmeExternalAccountBindingExpiration | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeExternalAccountBindingExpirationToHclTerraform(struct?: CertificatemanagerAcmeExternalAccountBindingExpiration | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeExternalAccountBindingExpirationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificatemanagerAcmeExternalAccountBindingExpiration | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeExternalAccountBindingExpiration | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface CertificatemanagerAcmeExternalAccountBindingTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#key CertificatemanagerAcmeExternalAccountBinding#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#value CertificatemanagerAcmeExternalAccountBinding#value}
    */
    readonly value?: string;
}
export declare function certificatemanagerAcmeExternalAccountBindingTagsToTerraform(struct?: CertificatemanagerAcmeExternalAccountBindingTags | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeExternalAccountBindingTagsToHclTerraform(struct?: CertificatemanagerAcmeExternalAccountBindingTags | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeExternalAccountBindingTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificatemanagerAcmeExternalAccountBindingTags | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeExternalAccountBindingTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CertificatemanagerAcmeExternalAccountBindingTagsList extends cdktn.ComplexList {
    internalValue?: CertificatemanagerAcmeExternalAccountBindingTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificatemanagerAcmeExternalAccountBindingTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding awscc_certificatemanager_acme_external_account_binding}
*/
export declare class CertificatemanagerAcmeExternalAccountBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_certificatemanager_acme_external_account_binding";
    /**
    * Generates CDKTN code for importing a CertificatemanagerAcmeExternalAccountBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificatemanagerAcmeExternalAccountBinding to import
    * @param importFromId The id of the existing CertificatemanagerAcmeExternalAccountBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificatemanagerAcmeExternalAccountBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_external_account_binding awscc_certificatemanager_acme_external_account_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificatemanagerAcmeExternalAccountBindingConfig
    */
    constructor(scope: Construct, id: string, config: CertificatemanagerAcmeExternalAccountBindingConfig);
    private _acmeEndpointArn?;
    get acmeEndpointArn(): string;
    set acmeEndpointArn(value: string);
    get acmeEndpointArnInput(): string | undefined;
    get acmeExternalAccountBindingArn(): string;
    private _expiration;
    get expiration(): CertificatemanagerAcmeExternalAccountBindingExpirationOutputReference;
    putExpiration(value: CertificatemanagerAcmeExternalAccountBindingExpiration): void;
    resetExpiration(): void;
    get expirationInput(): cdktn.IResolvable | CertificatemanagerAcmeExternalAccountBindingExpiration | undefined;
    get id(): string;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags;
    get tags(): CertificatemanagerAcmeExternalAccountBindingTagsList;
    putTags(value: CertificatemanagerAcmeExternalAccountBindingTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CertificatemanagerAcmeExternalAccountBindingTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
