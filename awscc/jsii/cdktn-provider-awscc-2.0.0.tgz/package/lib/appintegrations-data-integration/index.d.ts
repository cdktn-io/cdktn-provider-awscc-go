/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppintegrationsDataIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The data integration description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#description AppintegrationsDataIntegration#description}
    */
    readonly description?: string;
    /**
    * The configuration for what files should be pulled from the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#file_configuration AppintegrationsDataIntegration#file_configuration}
    */
    readonly fileConfiguration?: AppintegrationsDataIntegrationFileConfiguration;
    /**
    * The KMS key of the data integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#kms_key AppintegrationsDataIntegration#kms_key}
    */
    readonly kmsKey: string;
    /**
    * The name of the data integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#name AppintegrationsDataIntegration#name}
    */
    readonly name: string;
    /**
    * The configuration for what data should be pulled from the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#object_configuration AppintegrationsDataIntegration#object_configuration}
    */
    readonly objectConfiguration?: {
        [key: string]: {
            [key: string]: string[];
        } | cdktn.IResolvable;
    } | cdktn.IResolvable;
    /**
    * The name of the data and how often it should be pulled from the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#schedule_config AppintegrationsDataIntegration#schedule_config}
    */
    readonly scheduleConfig?: AppintegrationsDataIntegrationScheduleConfig;
    /**
    * The URI of the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#source_uri AppintegrationsDataIntegration#source_uri}
    */
    readonly sourceUri: string;
    /**
    * The tags (keys and values) associated with the data integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#tags AppintegrationsDataIntegration#tags}
    */
    readonly tags?: AppintegrationsDataIntegrationTags[] | cdktn.IResolvable;
}
export interface AppintegrationsDataIntegrationFileConfiguration {
    /**
    * Restrictions for what files should be pulled from the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#filters AppintegrationsDataIntegration#filters}
    */
    readonly filters?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Identifiers for the source folders to pull all files from recursively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#folders AppintegrationsDataIntegration#folders}
    */
    readonly folders?: string[];
}
export declare function appintegrationsDataIntegrationFileConfigurationToTerraform(struct?: AppintegrationsDataIntegrationFileConfiguration | cdktn.IResolvable): any;
export declare function appintegrationsDataIntegrationFileConfigurationToHclTerraform(struct?: AppintegrationsDataIntegrationFileConfiguration | cdktn.IResolvable): any;
export declare class AppintegrationsDataIntegrationFileConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppintegrationsDataIntegrationFileConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsDataIntegrationFileConfiguration | cdktn.IResolvable | undefined);
    private _filters?;
    get filters(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set filters(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _folders?;
    get folders(): string[];
    set folders(value: string[]);
    resetFolders(): void;
    get foldersInput(): string[] | undefined;
}
export interface AppintegrationsDataIntegrationScheduleConfig {
    /**
    * The start date for objects to import in the first flow run. Epoch or ISO timestamp format is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#first_execution_from AppintegrationsDataIntegration#first_execution_from}
    */
    readonly firstExecutionFrom?: string;
    /**
    * The name of the object to pull from the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#object AppintegrationsDataIntegration#object}
    */
    readonly object?: string;
    /**
    * How often the data should be pulled from data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#schedule_expression AppintegrationsDataIntegration#schedule_expression}
    */
    readonly scheduleExpression?: string;
}
export declare function appintegrationsDataIntegrationScheduleConfigToTerraform(struct?: AppintegrationsDataIntegrationScheduleConfig | cdktn.IResolvable): any;
export declare function appintegrationsDataIntegrationScheduleConfigToHclTerraform(struct?: AppintegrationsDataIntegrationScheduleConfig | cdktn.IResolvable): any;
export declare class AppintegrationsDataIntegrationScheduleConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppintegrationsDataIntegrationScheduleConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsDataIntegrationScheduleConfig | cdktn.IResolvable | undefined);
    private _firstExecutionFrom?;
    get firstExecutionFrom(): string;
    set firstExecutionFrom(value: string);
    resetFirstExecutionFrom(): void;
    get firstExecutionFromInput(): string | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    resetScheduleExpression(): void;
    get scheduleExpressionInput(): string | undefined;
}
export interface AppintegrationsDataIntegrationTags {
    /**
    * A key to identify the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#key AppintegrationsDataIntegration#key}
    */
    readonly key?: string;
    /**
    * Corresponding tag value for the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#value AppintegrationsDataIntegration#value}
    */
    readonly value?: string;
}
export declare function appintegrationsDataIntegrationTagsToTerraform(struct?: AppintegrationsDataIntegrationTags | cdktn.IResolvable): any;
export declare function appintegrationsDataIntegrationTagsToHclTerraform(struct?: AppintegrationsDataIntegrationTags | cdktn.IResolvable): any;
export declare class AppintegrationsDataIntegrationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppintegrationsDataIntegrationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsDataIntegrationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppintegrationsDataIntegrationTagsList extends cdktn.ComplexList {
    internalValue?: AppintegrationsDataIntegrationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppintegrationsDataIntegrationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration awscc_appintegrations_data_integration}
*/
export declare class AppintegrationsDataIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appintegrations_data_integration";
    /**
    * Generates CDKTN code for importing a AppintegrationsDataIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppintegrationsDataIntegration to import
    * @param importFromId The id of the existing AppintegrationsDataIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppintegrationsDataIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_data_integration awscc_appintegrations_data_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppintegrationsDataIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: AppintegrationsDataIntegrationConfig);
    get dataIntegrationArn(): string;
    get dataIntegrationId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _fileConfiguration;
    get fileConfiguration(): AppintegrationsDataIntegrationFileConfigurationOutputReference;
    putFileConfiguration(value: AppintegrationsDataIntegrationFileConfiguration): void;
    resetFileConfiguration(): void;
    get fileConfigurationInput(): cdktn.IResolvable | AppintegrationsDataIntegrationFileConfiguration | undefined;
    get id(): string;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    get kmsKeyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _objectConfiguration?;
    get objectConfiguration(): {
        [key: string]: {
            [key: string]: string[];
        } | cdktn.IResolvable;
    } | cdktn.IResolvable;
    set objectConfiguration(value: {
        [key: string]: {
            [key: string]: string[];
        } | cdktn.IResolvable;
    } | cdktn.IResolvable);
    resetObjectConfiguration(): void;
    get objectConfigurationInput(): cdktn.IResolvable | {
        [key: string]: cdktn.IResolvable | {
            [key: string]: string[];
        };
    } | undefined;
    private _scheduleConfig;
    get scheduleConfig(): AppintegrationsDataIntegrationScheduleConfigOutputReference;
    putScheduleConfig(value: AppintegrationsDataIntegrationScheduleConfig): void;
    resetScheduleConfig(): void;
    get scheduleConfigInput(): cdktn.IResolvable | AppintegrationsDataIntegrationScheduleConfig | undefined;
    private _sourceUri?;
    get sourceUri(): string;
    set sourceUri(value: string);
    get sourceUriInput(): string | undefined;
    private _tags;
    get tags(): AppintegrationsDataIntegrationTagsList;
    putTags(value: AppintegrationsDataIntegrationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppintegrationsDataIntegrationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
