/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamEntitlementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement#app_visibility AppstreamEntitlement#app_visibility}
    */
    readonly appVisibility: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement#attributes AppstreamEntitlement#attributes}
    */
    readonly attributes: AppstreamEntitlementAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement#description AppstreamEntitlement#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement#name AppstreamEntitlement#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement#stack_name AppstreamEntitlement#stack_name}
    */
    readonly stackName: string;
}
export interface AppstreamEntitlementAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement#name AppstreamEntitlement#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement#value AppstreamEntitlement#value}
    */
    readonly value: string;
}
export declare function appstreamEntitlementAttributesToTerraform(struct?: AppstreamEntitlementAttributes | cdktn.IResolvable): any;
export declare function appstreamEntitlementAttributesToHclTerraform(struct?: AppstreamEntitlementAttributes | cdktn.IResolvable): any;
export declare class AppstreamEntitlementAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamEntitlementAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamEntitlementAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class AppstreamEntitlementAttributesList extends cdktn.ComplexList {
    internalValue?: AppstreamEntitlementAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamEntitlementAttributesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement awscc_appstream_entitlement}
*/
export declare class AppstreamEntitlement extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_entitlement";
    /**
    * Generates CDKTN code for importing a AppstreamEntitlement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamEntitlement to import
    * @param importFromId The id of the existing AppstreamEntitlement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamEntitlement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_entitlement awscc_appstream_entitlement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamEntitlementConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamEntitlementConfig);
    private _appVisibility?;
    get appVisibility(): string;
    set appVisibility(value: string);
    get appVisibilityInput(): string | undefined;
    private _attributes;
    get attributes(): AppstreamEntitlementAttributesList;
    putAttributes(value: AppstreamEntitlementAttributes[] | cdktn.IResolvable): void;
    get attributesInput(): cdktn.IResolvable | AppstreamEntitlementAttributes[] | undefined;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _stackName?;
    get stackName(): string;
    set stackName(value: string);
    get stackNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
