/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2ApiGatewayManagedOverridesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_api_gateway_managed_overrides#id DataAwsccApigatewayv2ApiGatewayManagedOverrides#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2ApiGatewayManagedOverridesIntegration {
}
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesIntegrationToTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesIntegration): any;
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesIntegrationToHclTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesIntegration): any;
export declare class DataAwsccApigatewayv2ApiGatewayManagedOverridesIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2ApiGatewayManagedOverridesIntegration | undefined;
    set internalValue(value: DataAwsccApigatewayv2ApiGatewayManagedOverridesIntegration | undefined);
    get description(): string;
    get integrationMethod(): string;
    get payloadFormatVersion(): string;
    get timeoutInMillis(): number;
}
export interface DataAwsccApigatewayv2ApiGatewayManagedOverridesRoute {
}
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesRouteToTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesRoute): any;
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesRouteToHclTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesRoute): any;
export declare class DataAwsccApigatewayv2ApiGatewayManagedOverridesRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2ApiGatewayManagedOverridesRoute | undefined;
    set internalValue(value: DataAwsccApigatewayv2ApiGatewayManagedOverridesRoute | undefined);
    get authorizationScopes(): string[];
    get authorizationType(): string;
    get authorizerId(): string;
    get operationName(): string;
    get target(): string;
}
export interface DataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings {
}
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettingsToTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings): any;
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettingsToHclTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings): any;
export declare class DataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings | undefined;
    set internalValue(value: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings | undefined);
    get destinationArn(): string;
    get format(): string;
}
export interface DataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings {
}
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettingsToTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings): any;
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettingsToHclTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings): any;
export declare class DataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings | undefined;
    set internalValue(value: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings | undefined);
    get detailedMetricsEnabled(): cdktn.IResolvable;
    get throttlingBurstLimit(): number;
    get throttlingRateLimit(): number;
}
export interface DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettings {
}
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettingsToTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettings): any;
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettingsToHclTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettings): any;
export declare class DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettings | undefined;
    set internalValue(value: DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettings | undefined);
    get detailedMetricsEnabled(): cdktn.IResolvable;
    get throttlingBurstLimit(): number;
    get throttlingRateLimit(): number;
}
export declare class DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettingsOutputReference;
}
export interface DataAwsccApigatewayv2ApiGatewayManagedOverridesStage {
}
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesStageToTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesStage): any;
export declare function dataAwsccApigatewayv2ApiGatewayManagedOverridesStageToHclTerraform(struct?: DataAwsccApigatewayv2ApiGatewayManagedOverridesStage): any;
export declare class DataAwsccApigatewayv2ApiGatewayManagedOverridesStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2ApiGatewayManagedOverridesStage | undefined;
    set internalValue(value: DataAwsccApigatewayv2ApiGatewayManagedOverridesStage | undefined);
    private _accessLogSettings;
    get accessLogSettings(): DataAwsccApigatewayv2ApiGatewayManagedOverridesStageAccessLogSettingsOutputReference;
    get autoDeploy(): cdktn.IResolvable;
    private _defaultRouteSettings;
    get defaultRouteSettings(): DataAwsccApigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettingsOutputReference;
    get description(): string;
    private _routeSettings;
    get routeSettings(): DataAwsccApigatewayv2ApiGatewayManagedOverridesStageRouteSettingsMap;
    private _stageVariables;
    get stageVariables(): cdktn.StringMap;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_api_gateway_managed_overrides awscc_apigatewayv2_api_gateway_managed_overrides}
*/
export declare class DataAwsccApigatewayv2ApiGatewayManagedOverrides extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_api_gateway_managed_overrides";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2ApiGatewayManagedOverrides resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2ApiGatewayManagedOverrides to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2ApiGatewayManagedOverrides that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_api_gateway_managed_overrides#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2ApiGatewayManagedOverrides to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_api_gateway_managed_overrides awscc_apigatewayv2_api_gateway_managed_overrides} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2ApiGatewayManagedOverridesConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2ApiGatewayManagedOverridesConfig);
    get apiGatewayManagedOverridesId(): string;
    get apiId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _integration;
    get integration(): DataAwsccApigatewayv2ApiGatewayManagedOverridesIntegrationOutputReference;
    private _route;
    get route(): DataAwsccApigatewayv2ApiGatewayManagedOverridesRouteOutputReference;
    private _stage;
    get stage(): DataAwsccApigatewayv2ApiGatewayManagedOverridesStageOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
