/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Apigatewayv2ApiGatewayManagedOverridesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the API for which to override the configuration of API Gateway-managed resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#api_id Apigatewayv2ApiGatewayManagedOverrides#api_id}
    */
    readonly apiId: string;
    /**
    * Overrides the integration configuration for an API Gateway-managed integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#integration Apigatewayv2ApiGatewayManagedOverrides#integration}
    */
    readonly integration?: Apigatewayv2ApiGatewayManagedOverridesIntegration;
    /**
    * Overrides the route configuration for an API Gateway-managed route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#route Apigatewayv2ApiGatewayManagedOverrides#route}
    */
    readonly route?: Apigatewayv2ApiGatewayManagedOverridesRoute;
    /**
    * Overrides the stage configuration for an API Gateway-managed stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#stage Apigatewayv2ApiGatewayManagedOverrides#stage}
    */
    readonly stage?: Apigatewayv2ApiGatewayManagedOverridesStage;
}
export interface Apigatewayv2ApiGatewayManagedOverridesIntegration {
    /**
    * The description of the integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#description Apigatewayv2ApiGatewayManagedOverrides#description}
    */
    readonly description?: string;
    /**
    * Specifies the integration's HTTP method type. For WebSocket APIs, if you use a Lambda integration, you must set the integration method to POST.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#integration_method Apigatewayv2ApiGatewayManagedOverrides#integration_method}
    */
    readonly integrationMethod?: string;
    /**
    * Specifies the format of the payload sent to an integration. Required for HTTP APIs. For HTTP APIs, supported values for Lambda proxy integrations are 1.0 and 2.0. For all other integrations, 1.0 is the only supported value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#payload_format_version Apigatewayv2ApiGatewayManagedOverrides#payload_format_version}
    */
    readonly payloadFormatVersion?: string;
    /**
    * Custom timeout between 50 and 29,000 milliseconds for WebSocket APIs and between 50 and 30,000 milliseconds for HTTP APIs. The default timeout is 29 seconds for WebSocket APIs and 30 seconds for HTTP APIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#timeout_in_millis Apigatewayv2ApiGatewayManagedOverrides#timeout_in_millis}
    */
    readonly timeoutInMillis?: number;
}
export declare function apigatewayv2ApiGatewayManagedOverridesIntegrationToTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesIntegration | cdktn.IResolvable): any;
export declare function apigatewayv2ApiGatewayManagedOverridesIntegrationToHclTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesIntegration | cdktn.IResolvable): any;
export declare class Apigatewayv2ApiGatewayManagedOverridesIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2ApiGatewayManagedOverridesIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2ApiGatewayManagedOverridesIntegration | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _integrationMethod?;
    get integrationMethod(): string;
    set integrationMethod(value: string);
    resetIntegrationMethod(): void;
    get integrationMethodInput(): string | undefined;
    private _payloadFormatVersion?;
    get payloadFormatVersion(): string;
    set payloadFormatVersion(value: string);
    resetPayloadFormatVersion(): void;
    get payloadFormatVersionInput(): string | undefined;
    private _timeoutInMillis?;
    get timeoutInMillis(): number;
    set timeoutInMillis(value: number);
    resetTimeoutInMillis(): void;
    get timeoutInMillisInput(): number | undefined;
}
export interface Apigatewayv2ApiGatewayManagedOverridesRoute {
    /**
    * The authorization scopes supported by this route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#authorization_scopes Apigatewayv2ApiGatewayManagedOverrides#authorization_scopes}
    */
    readonly authorizationScopes?: string[];
    /**
    * The authorization type for the route. To learn more, see AuthorizationType.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#authorization_type Apigatewayv2ApiGatewayManagedOverrides#authorization_type}
    */
    readonly authorizationType?: string;
    /**
    * The identifier of the Authorizer resource to be associated with this route. The authorizer identifier is generated by API Gateway when you created the authorizer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#authorizer_id Apigatewayv2ApiGatewayManagedOverrides#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * The operation name for the route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#operation_name Apigatewayv2ApiGatewayManagedOverrides#operation_name}
    */
    readonly operationName?: string;
    /**
    * For HTTP integrations, specify a fully qualified URL. For Lambda integrations, specify a function ARN. The type of the integration will be HTTP_PROXY or AWS_PROXY, respectively.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#target Apigatewayv2ApiGatewayManagedOverrides#target}
    */
    readonly target?: string;
}
export declare function apigatewayv2ApiGatewayManagedOverridesRouteToTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesRoute | cdktn.IResolvable): any;
export declare function apigatewayv2ApiGatewayManagedOverridesRouteToHclTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesRoute | cdktn.IResolvable): any;
export declare class Apigatewayv2ApiGatewayManagedOverridesRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2ApiGatewayManagedOverridesRoute | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2ApiGatewayManagedOverridesRoute | cdktn.IResolvable | undefined);
    private _authorizationScopes?;
    get authorizationScopes(): string[];
    set authorizationScopes(value: string[]);
    resetAuthorizationScopes(): void;
    get authorizationScopesInput(): string[] | undefined;
    private _authorizationType?;
    get authorizationType(): string;
    set authorizationType(value: string);
    resetAuthorizationType(): void;
    get authorizationTypeInput(): string | undefined;
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
}
export interface Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings {
    /**
    * The ARN of the CloudWatch Logs log group to receive access logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#destination_arn Apigatewayv2ApiGatewayManagedOverrides#destination_arn}
    */
    readonly destinationArn?: string;
    /**
    * A single line format of the access logs of data, as specified by selected $context variables. The format must include at least $context.requestId.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#format Apigatewayv2ApiGatewayManagedOverrides#format}
    */
    readonly format?: string;
}
export declare function apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettingsToTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings | cdktn.IResolvable): any;
export declare function apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettingsToHclTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings | cdktn.IResolvable): any;
export declare class Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings | cdktn.IResolvable | undefined);
    private _destinationArn?;
    get destinationArn(): string;
    set destinationArn(value: string);
    resetDestinationArn(): void;
    get destinationArnInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
}
export interface Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings {
    /**
    * Specifies whether detailed metrics are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#detailed_metrics_enabled Apigatewayv2ApiGatewayManagedOverrides#detailed_metrics_enabled}
    */
    readonly detailedMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Specifies the throttling burst limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#throttling_burst_limit Apigatewayv2ApiGatewayManagedOverrides#throttling_burst_limit}
    */
    readonly throttlingBurstLimit?: number;
    /**
    * Specifies the throttling rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#throttling_rate_limit Apigatewayv2ApiGatewayManagedOverrides#throttling_rate_limit}
    */
    readonly throttlingRateLimit?: number;
}
export declare function apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettingsToTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings | cdktn.IResolvable): any;
export declare function apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettingsToHclTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings | cdktn.IResolvable): any;
export declare class Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings | cdktn.IResolvable | undefined);
    private _detailedMetricsEnabled?;
    get detailedMetricsEnabled(): boolean | cdktn.IResolvable;
    set detailedMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetDetailedMetricsEnabled(): void;
    get detailedMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _throttlingBurstLimit?;
    get throttlingBurstLimit(): number;
    set throttlingBurstLimit(value: number);
    resetThrottlingBurstLimit(): void;
    get throttlingBurstLimitInput(): number | undefined;
    private _throttlingRateLimit?;
    get throttlingRateLimit(): number;
    set throttlingRateLimit(value: number);
    resetThrottlingRateLimit(): void;
    get throttlingRateLimitInput(): number | undefined;
}
export interface Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings {
    /**
    * Specifies whether detailed metrics are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#detailed_metrics_enabled Apigatewayv2ApiGatewayManagedOverrides#detailed_metrics_enabled}
    */
    readonly detailedMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Specifies the throttling burst limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#throttling_burst_limit Apigatewayv2ApiGatewayManagedOverrides#throttling_burst_limit}
    */
    readonly throttlingBurstLimit?: number;
    /**
    * Specifies the throttling rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#throttling_rate_limit Apigatewayv2ApiGatewayManagedOverrides#throttling_rate_limit}
    */
    readonly throttlingRateLimit?: number;
}
export declare function apigatewayv2ApiGatewayManagedOverridesStageRouteSettingsToTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings | cdktn.IResolvable): any;
export declare function apigatewayv2ApiGatewayManagedOverridesStageRouteSettingsToHclTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings | cdktn.IResolvable): any;
export declare class Apigatewayv2ApiGatewayManagedOverridesStageRouteSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings | cdktn.IResolvable | undefined);
    private _detailedMetricsEnabled?;
    get detailedMetricsEnabled(): boolean | cdktn.IResolvable;
    set detailedMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetDetailedMetricsEnabled(): void;
    get detailedMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _throttlingBurstLimit?;
    get throttlingBurstLimit(): number;
    set throttlingBurstLimit(value: number);
    resetThrottlingBurstLimit(): void;
    get throttlingBurstLimitInput(): number | undefined;
    private _throttlingRateLimit?;
    get throttlingRateLimit(): number;
    set throttlingRateLimit(value: number);
    resetThrottlingRateLimit(): void;
    get throttlingRateLimitInput(): number | undefined;
}
export declare class Apigatewayv2ApiGatewayManagedOverridesStageRouteSettingsMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): Apigatewayv2ApiGatewayManagedOverridesStageRouteSettingsOutputReference;
}
export interface Apigatewayv2ApiGatewayManagedOverridesStage {
    /**
    * Settings for logging access in a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#access_log_settings Apigatewayv2ApiGatewayManagedOverrides#access_log_settings}
    */
    readonly accessLogSettings?: Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings;
    /**
    * Specifies whether updates to an API automatically trigger a new deployment. The default value is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#auto_deploy Apigatewayv2ApiGatewayManagedOverrides#auto_deploy}
    */
    readonly autoDeploy?: boolean | cdktn.IResolvable;
    /**
    * The default route settings for the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#default_route_settings Apigatewayv2ApiGatewayManagedOverrides#default_route_settings}
    */
    readonly defaultRouteSettings?: Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings;
    /**
    * The description for the API stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#description Apigatewayv2ApiGatewayManagedOverrides#description}
    */
    readonly description?: string;
    /**
    * Route settings for the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#route_settings Apigatewayv2ApiGatewayManagedOverrides#route_settings}
    */
    readonly routeSettings?: {
        [key: string]: Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings;
    } | cdktn.IResolvable;
    /**
    * A map that defines the stage variables for a Stage. Variable names can have alphanumeric and underscore characters, and the values must match [A-Za-z0-9-._~:/?#&=,]+.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#stage_variables Apigatewayv2ApiGatewayManagedOverrides#stage_variables}
    */
    readonly stageVariables?: {
        [key: string]: string;
    };
}
export declare function apigatewayv2ApiGatewayManagedOverridesStageToTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesStage | cdktn.IResolvable): any;
export declare function apigatewayv2ApiGatewayManagedOverridesStageToHclTerraform(struct?: Apigatewayv2ApiGatewayManagedOverridesStage | cdktn.IResolvable): any;
export declare class Apigatewayv2ApiGatewayManagedOverridesStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2ApiGatewayManagedOverridesStage | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2ApiGatewayManagedOverridesStage | cdktn.IResolvable | undefined);
    private _accessLogSettings;
    get accessLogSettings(): Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettingsOutputReference;
    putAccessLogSettings(value: Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings): void;
    resetAccessLogSettings(): void;
    get accessLogSettingsInput(): cdktn.IResolvable | Apigatewayv2ApiGatewayManagedOverridesStageAccessLogSettings | undefined;
    private _autoDeploy?;
    get autoDeploy(): boolean | cdktn.IResolvable;
    set autoDeploy(value: boolean | cdktn.IResolvable);
    resetAutoDeploy(): void;
    get autoDeployInput(): boolean | cdktn.IResolvable | undefined;
    private _defaultRouteSettings;
    get defaultRouteSettings(): Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettingsOutputReference;
    putDefaultRouteSettings(value: Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings): void;
    resetDefaultRouteSettings(): void;
    get defaultRouteSettingsInput(): cdktn.IResolvable | Apigatewayv2ApiGatewayManagedOverridesStageDefaultRouteSettings | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _routeSettings;
    get routeSettings(): Apigatewayv2ApiGatewayManagedOverridesStageRouteSettingsMap;
    putRouteSettings(value: {
        [key: string]: Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings;
    } | cdktn.IResolvable): void;
    resetRouteSettings(): void;
    get routeSettingsInput(): cdktn.IResolvable | {
        [key: string]: Apigatewayv2ApiGatewayManagedOverridesStageRouteSettings;
    } | undefined;
    private _stageVariables?;
    get stageVariables(): {
        [key: string]: string;
    };
    set stageVariables(value: {
        [key: string]: string;
    });
    resetStageVariables(): void;
    get stageVariablesInput(): {
        [key: string]: string;
    } | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides awscc_apigatewayv2_api_gateway_managed_overrides}
*/
export declare class Apigatewayv2ApiGatewayManagedOverrides extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigatewayv2_api_gateway_managed_overrides";
    /**
    * Generates CDKTN code for importing a Apigatewayv2ApiGatewayManagedOverrides resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Apigatewayv2ApiGatewayManagedOverrides to import
    * @param importFromId The id of the existing Apigatewayv2ApiGatewayManagedOverrides that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Apigatewayv2ApiGatewayManagedOverrides to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_api_gateway_managed_overrides awscc_apigatewayv2_api_gateway_managed_overrides} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Apigatewayv2ApiGatewayManagedOverridesConfig
    */
    constructor(scope: Construct, id: string, config: Apigatewayv2ApiGatewayManagedOverridesConfig);
    get apiGatewayManagedOverridesId(): string;
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get id(): string;
    private _integration;
    get integration(): Apigatewayv2ApiGatewayManagedOverridesIntegrationOutputReference;
    putIntegration(value: Apigatewayv2ApiGatewayManagedOverridesIntegration): void;
    resetIntegration(): void;
    get integrationInput(): cdktn.IResolvable | Apigatewayv2ApiGatewayManagedOverridesIntegration | undefined;
    private _route;
    get route(): Apigatewayv2ApiGatewayManagedOverridesRouteOutputReference;
    putRoute(value: Apigatewayv2ApiGatewayManagedOverridesRoute): void;
    resetRoute(): void;
    get routeInput(): cdktn.IResolvable | Apigatewayv2ApiGatewayManagedOverridesRoute | undefined;
    private _stage;
    get stage(): Apigatewayv2ApiGatewayManagedOverridesStageOutputReference;
    putStage(value: Apigatewayv2ApiGatewayManagedOverridesStage): void;
    resetStage(): void;
    get stageInput(): cdktn.IResolvable | Apigatewayv2ApiGatewayManagedOverridesStage | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
