/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectVocabularyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The content of the custom vocabulary in plain-text format with a table of values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary#content ConnectVocabulary#content}
    */
    readonly content: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary#instance_id ConnectVocabulary#instance_id}
    */
    readonly instanceId: string;
    /**
    * The language code of the vocabulary entries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary#language_code ConnectVocabulary#language_code}
    */
    readonly languageCode: string;
    /**
    * The tags used to organize, track, or control access for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary#tags ConnectVocabulary#tags}
    */
    readonly tags?: ConnectVocabularyTags[] | cdktn.IResolvable;
    /**
    * A unique name of the custom vocabulary.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary#vocabulary_name ConnectVocabulary#vocabulary_name}
    */
    readonly vocabularyName: string;
}
export interface ConnectVocabularyTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary#key ConnectVocabulary#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary#value ConnectVocabulary#value}
    */
    readonly value?: string;
}
export declare function connectVocabularyTagsToTerraform(struct?: ConnectVocabularyTags | cdktn.IResolvable): any;
export declare function connectVocabularyTagsToHclTerraform(struct?: ConnectVocabularyTags | cdktn.IResolvable): any;
export declare class ConnectVocabularyTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectVocabularyTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectVocabularyTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectVocabularyTagsList extends cdktn.ComplexList {
    internalValue?: ConnectVocabularyTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectVocabularyTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary awscc_connect_vocabulary}
*/
export declare class ConnectVocabulary extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_vocabulary";
    /**
    * Generates CDKTN code for importing a ConnectVocabulary resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectVocabulary to import
    * @param importFromId The id of the existing ConnectVocabulary that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectVocabulary to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_vocabulary awscc_connect_vocabulary} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectVocabularyConfig
    */
    constructor(scope: Construct, id: string, config: ConnectVocabularyConfig);
    get arn(): string;
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    get lastModifiedTime(): string;
    get state(): string;
    private _tags;
    get tags(): ConnectVocabularyTagsList;
    putTags(value: ConnectVocabularyTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectVocabularyTags[] | undefined;
    get vocabularyId(): string;
    private _vocabularyName?;
    get vocabularyName(): string;
    set vocabularyName(value: string);
    get vocabularyNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
