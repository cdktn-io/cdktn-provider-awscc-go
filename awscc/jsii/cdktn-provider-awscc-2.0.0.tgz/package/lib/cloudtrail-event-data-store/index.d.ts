/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudtrailEventDataStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * The advanced event selectors that were used to select events for the data store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#advanced_event_selectors CloudtrailEventDataStore#advanced_event_selectors}
    */
    readonly advancedEventSelectors?: CloudtrailEventDataStoreAdvancedEventSelectors[] | cdktn.IResolvable;
    /**
    * The mode that the event data store will use to charge for event storage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#billing_mode CloudtrailEventDataStore#billing_mode}
    */
    readonly billingMode?: string;
    /**
    * An array that enriches event records in an existing event data store by including additional information specified in individual ContexKeySelector entries. If you add ContextKeySelectors, you must set MaxEventSize to Large.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#context_key_selectors CloudtrailEventDataStore#context_key_selectors}
    */
    readonly contextKeySelectors?: CloudtrailEventDataStoreContextKeySelectors[] | cdktn.IResolvable;
    /**
    * Indicates whether federation is enabled on an event data store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#federation_enabled CloudtrailEventDataStore#federation_enabled}
    */
    readonly federationEnabled?: boolean | cdktn.IResolvable;
    /**
    * The ARN of the role used for event data store federation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#federation_role_arn CloudtrailEventDataStore#federation_role_arn}
    */
    readonly federationRoleArn?: string;
    /**
    * Indicates whether the event data store is ingesting events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#ingestion_enabled CloudtrailEventDataStore#ingestion_enabled}
    */
    readonly ingestionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Lets you enable Insights event logging by specifying the Insights selectors that you want to enable on an existing event data store. Both InsightSelectors and InsightsDestination need to have a value in order to enable Insights events on an event data store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#insight_selectors CloudtrailEventDataStore#insight_selectors}
    */
    readonly insightSelectors?: CloudtrailEventDataStoreInsightSelectors[] | cdktn.IResolvable;
    /**
    * Specifies the ARN of the event data store that will collect Insights events. Both InsightSelectors and InsightsDestination need to have a value in order to enable Insights events on an event data store
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#insights_destination CloudtrailEventDataStore#insights_destination}
    */
    readonly insightsDestination?: string;
    /**
    * Specifies the KMS key ID to use to encrypt the events delivered by CloudTrail. The value can be an alias name prefixed by 'alias/', a fully specified ARN to an alias, a fully specified ARN to a key, or a globally unique identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#kms_key_id CloudtrailEventDataStore#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Specifies the maximum size allowed for the event. Valid values are Standard and Large. If you add ContextKeySelectors, this value must be set to Large.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#max_event_size CloudtrailEventDataStore#max_event_size}
    */
    readonly maxEventSize?: string;
    /**
    * Indicates whether the event data store includes events from all regions, or only from the region in which it was created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#multi_region_enabled CloudtrailEventDataStore#multi_region_enabled}
    */
    readonly multiRegionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the event data store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#name CloudtrailEventDataStore#name}
    */
    readonly name?: string;
    /**
    * Indicates that an event data store is collecting logged events for an organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#organization_enabled CloudtrailEventDataStore#organization_enabled}
    */
    readonly organizationEnabled?: boolean | cdktn.IResolvable;
    /**
    * The retention period, in days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#retention_period CloudtrailEventDataStore#retention_period}
    */
    readonly retentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#tags CloudtrailEventDataStore#tags}
    */
    readonly tags?: CloudtrailEventDataStoreTags[] | cdktn.IResolvable;
    /**
    * Indicates whether the event data store is protected from termination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#termination_protection_enabled CloudtrailEventDataStore#termination_protection_enabled}
    */
    readonly terminationProtectionEnabled?: boolean | cdktn.IResolvable;
}
export interface CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors {
    /**
    * An operator that includes events that match the last few characters of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#ends_with CloudtrailEventDataStore#ends_with}
    */
    readonly endsWith?: string[];
    /**
    * An operator that includes events that match the exact value of the event record field specified as the value of Field. This is the only valid operator that you can use with the readOnly, eventCategory, and resources.type fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#equals CloudtrailEventDataStore#equals}
    */
    readonly equalTo?: string[];
    /**
    * A field in an event record on which to filter events to be logged. Supported fields include readOnly, eventCategory, eventSource (for management events), eventName, resources.type, and resources.ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#field CloudtrailEventDataStore#field}
    */
    readonly field?: string;
    /**
    * An operator that excludes events that match the last few characters of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#not_ends_with CloudtrailEventDataStore#not_ends_with}
    */
    readonly notEndsWith?: string[];
    /**
    * An operator that excludes events that match the exact value of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#not_equals CloudtrailEventDataStore#not_equals}
    */
    readonly notEquals?: string[];
    /**
    * An operator that excludes events that match the first few characters of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#not_starts_with CloudtrailEventDataStore#not_starts_with}
    */
    readonly notStartsWith?: string[];
    /**
    * An operator that includes events that match the first few characters of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#starts_with CloudtrailEventDataStore#starts_with}
    */
    readonly startsWith?: string[];
}
export declare function cloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectorsToTerraform(struct?: CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors | cdktn.IResolvable): any;
export declare function cloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectorsToHclTerraform(struct?: CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors | cdktn.IResolvable): any;
export declare class CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors | cdktn.IResolvable | undefined);
    private _endsWith?;
    get endsWith(): string[];
    set endsWith(value: string[]);
    resetEndsWith(): void;
    get endsWithInput(): string[] | undefined;
    private _equals?;
    get equalTo(): string[];
    set equalTo(value: string[]);
    resetEqualTo(): void;
    get equalToInput(): string[] | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _notEndsWith?;
    get notEndsWith(): string[];
    set notEndsWith(value: string[]);
    resetNotEndsWith(): void;
    get notEndsWithInput(): string[] | undefined;
    private _notEquals?;
    get notEquals(): string[];
    set notEquals(value: string[]);
    resetNotEquals(): void;
    get notEqualsInput(): string[] | undefined;
    private _notStartsWith?;
    get notStartsWith(): string[];
    set notStartsWith(value: string[]);
    resetNotStartsWith(): void;
    get notStartsWithInput(): string[] | undefined;
    private _startsWith?;
    get startsWith(): string[];
    set startsWith(value: string[]);
    resetStartsWith(): void;
    get startsWithInput(): string[] | undefined;
}
export declare class CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectorsList extends cdktn.ComplexList {
    internalValue?: CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectorsOutputReference;
}
export interface CloudtrailEventDataStoreAdvancedEventSelectors {
    /**
    * Contains all selector statements in an advanced event selector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#field_selectors CloudtrailEventDataStore#field_selectors}
    */
    readonly fieldSelectors?: CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors[] | cdktn.IResolvable;
    /**
    * An optional, descriptive name for an advanced event selector, such as "Log data events for only two S3 buckets".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#name CloudtrailEventDataStore#name}
    */
    readonly name?: string;
}
export declare function cloudtrailEventDataStoreAdvancedEventSelectorsToTerraform(struct?: CloudtrailEventDataStoreAdvancedEventSelectors | cdktn.IResolvable): any;
export declare function cloudtrailEventDataStoreAdvancedEventSelectorsToHclTerraform(struct?: CloudtrailEventDataStoreAdvancedEventSelectors | cdktn.IResolvable): any;
export declare class CloudtrailEventDataStoreAdvancedEventSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailEventDataStoreAdvancedEventSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailEventDataStoreAdvancedEventSelectors | cdktn.IResolvable | undefined);
    private _fieldSelectors;
    get fieldSelectors(): CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectorsList;
    putFieldSelectors(value: CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors[] | cdktn.IResolvable): void;
    resetFieldSelectors(): void;
    get fieldSelectorsInput(): cdktn.IResolvable | CloudtrailEventDataStoreAdvancedEventSelectorsFieldSelectors[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CloudtrailEventDataStoreAdvancedEventSelectorsList extends cdktn.ComplexList {
    internalValue?: CloudtrailEventDataStoreAdvancedEventSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailEventDataStoreAdvancedEventSelectorsOutputReference;
}
export interface CloudtrailEventDataStoreContextKeySelectors {
    /**
    * An operator that includes events that match the exact value of the event record field specified in Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#equals CloudtrailEventDataStore#equals}
    */
    readonly equalTo?: string[];
    /**
    * Specifies the type of the event record field in ContextKeySelector. Valid values include RequestContext, TagContext.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#type CloudtrailEventDataStore#type}
    */
    readonly type?: string;
}
export declare function cloudtrailEventDataStoreContextKeySelectorsToTerraform(struct?: CloudtrailEventDataStoreContextKeySelectors | cdktn.IResolvable): any;
export declare function cloudtrailEventDataStoreContextKeySelectorsToHclTerraform(struct?: CloudtrailEventDataStoreContextKeySelectors | cdktn.IResolvable): any;
export declare class CloudtrailEventDataStoreContextKeySelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailEventDataStoreContextKeySelectors | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailEventDataStoreContextKeySelectors | cdktn.IResolvable | undefined);
    private _equals?;
    get equalTo(): string[];
    set equalTo(value: string[]);
    resetEqualTo(): void;
    get equalToInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CloudtrailEventDataStoreContextKeySelectorsList extends cdktn.ComplexList {
    internalValue?: CloudtrailEventDataStoreContextKeySelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailEventDataStoreContextKeySelectorsOutputReference;
}
export interface CloudtrailEventDataStoreInsightSelectors {
    /**
    * The type of Insights to log on an event data store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#insight_type CloudtrailEventDataStore#insight_type}
    */
    readonly insightType?: string;
}
export declare function cloudtrailEventDataStoreInsightSelectorsToTerraform(struct?: CloudtrailEventDataStoreInsightSelectors | cdktn.IResolvable): any;
export declare function cloudtrailEventDataStoreInsightSelectorsToHclTerraform(struct?: CloudtrailEventDataStoreInsightSelectors | cdktn.IResolvable): any;
export declare class CloudtrailEventDataStoreInsightSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailEventDataStoreInsightSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailEventDataStoreInsightSelectors | cdktn.IResolvable | undefined);
    private _insightType?;
    get insightType(): string;
    set insightType(value: string);
    resetInsightType(): void;
    get insightTypeInput(): string | undefined;
}
export declare class CloudtrailEventDataStoreInsightSelectorsList extends cdktn.ComplexList {
    internalValue?: CloudtrailEventDataStoreInsightSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailEventDataStoreInsightSelectorsOutputReference;
}
export interface CloudtrailEventDataStoreTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#key CloudtrailEventDataStore#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#value CloudtrailEventDataStore#value}
    */
    readonly value?: string;
}
export declare function cloudtrailEventDataStoreTagsToTerraform(struct?: CloudtrailEventDataStoreTags | cdktn.IResolvable): any;
export declare function cloudtrailEventDataStoreTagsToHclTerraform(struct?: CloudtrailEventDataStoreTags | cdktn.IResolvable): any;
export declare class CloudtrailEventDataStoreTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailEventDataStoreTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailEventDataStoreTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudtrailEventDataStoreTagsList extends cdktn.ComplexList {
    internalValue?: CloudtrailEventDataStoreTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailEventDataStoreTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store awscc_cloudtrail_event_data_store}
*/
export declare class CloudtrailEventDataStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudtrail_event_data_store";
    /**
    * Generates CDKTN code for importing a CloudtrailEventDataStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudtrailEventDataStore to import
    * @param importFromId The id of the existing CloudtrailEventDataStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudtrailEventDataStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_event_data_store awscc_cloudtrail_event_data_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudtrailEventDataStoreConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudtrailEventDataStoreConfig);
    private _advancedEventSelectors;
    get advancedEventSelectors(): CloudtrailEventDataStoreAdvancedEventSelectorsList;
    putAdvancedEventSelectors(value: CloudtrailEventDataStoreAdvancedEventSelectors[] | cdktn.IResolvable): void;
    resetAdvancedEventSelectors(): void;
    get advancedEventSelectorsInput(): cdktn.IResolvable | CloudtrailEventDataStoreAdvancedEventSelectors[] | undefined;
    private _billingMode?;
    get billingMode(): string;
    set billingMode(value: string);
    resetBillingMode(): void;
    get billingModeInput(): string | undefined;
    private _contextKeySelectors;
    get contextKeySelectors(): CloudtrailEventDataStoreContextKeySelectorsList;
    putContextKeySelectors(value: CloudtrailEventDataStoreContextKeySelectors[] | cdktn.IResolvable): void;
    resetContextKeySelectors(): void;
    get contextKeySelectorsInput(): cdktn.IResolvable | CloudtrailEventDataStoreContextKeySelectors[] | undefined;
    get createdTimestamp(): string;
    get eventDataStoreArn(): string;
    private _federationEnabled?;
    get federationEnabled(): boolean | cdktn.IResolvable;
    set federationEnabled(value: boolean | cdktn.IResolvable);
    resetFederationEnabled(): void;
    get federationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _federationRoleArn?;
    get federationRoleArn(): string;
    set federationRoleArn(value: string);
    resetFederationRoleArn(): void;
    get federationRoleArnInput(): string | undefined;
    get id(): string;
    private _ingestionEnabled?;
    get ingestionEnabled(): boolean | cdktn.IResolvable;
    set ingestionEnabled(value: boolean | cdktn.IResolvable);
    resetIngestionEnabled(): void;
    get ingestionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _insightSelectors;
    get insightSelectors(): CloudtrailEventDataStoreInsightSelectorsList;
    putInsightSelectors(value: CloudtrailEventDataStoreInsightSelectors[] | cdktn.IResolvable): void;
    resetInsightSelectors(): void;
    get insightSelectorsInput(): cdktn.IResolvable | CloudtrailEventDataStoreInsightSelectors[] | undefined;
    private _insightsDestination?;
    get insightsDestination(): string;
    set insightsDestination(value: string);
    resetInsightsDestination(): void;
    get insightsDestinationInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _maxEventSize?;
    get maxEventSize(): string;
    set maxEventSize(value: string);
    resetMaxEventSize(): void;
    get maxEventSizeInput(): string | undefined;
    private _multiRegionEnabled?;
    get multiRegionEnabled(): boolean | cdktn.IResolvable;
    set multiRegionEnabled(value: boolean | cdktn.IResolvable);
    resetMultiRegionEnabled(): void;
    get multiRegionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _organizationEnabled?;
    get organizationEnabled(): boolean | cdktn.IResolvable;
    set organizationEnabled(value: boolean | cdktn.IResolvable);
    resetOrganizationEnabled(): void;
    get organizationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _retentionPeriod?;
    get retentionPeriod(): number;
    set retentionPeriod(value: number);
    resetRetentionPeriod(): void;
    get retentionPeriodInput(): number | undefined;
    get status(): string;
    private _tags;
    get tags(): CloudtrailEventDataStoreTagsList;
    putTags(value: CloudtrailEventDataStoreTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudtrailEventDataStoreTags[] | undefined;
    private _terminationProtectionEnabled?;
    get terminationProtectionEnabled(): boolean | cdktn.IResolvable;
    set terminationProtectionEnabled(value: boolean | cdktn.IResolvable);
    resetTerminationProtectionEnabled(): void;
    get terminationProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get updatedTimestamp(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
