/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2PortalProductConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_portal_product#id DataAwsccApigatewayv2PortalProduct#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2PortalProductTags {
}
export declare function dataAwsccApigatewayv2PortalProductTagsToTerraform(struct?: DataAwsccApigatewayv2PortalProductTags): any;
export declare function dataAwsccApigatewayv2PortalProductTagsToHclTerraform(struct?: DataAwsccApigatewayv2PortalProductTags): any;
export declare class DataAwsccApigatewayv2PortalProductTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayv2PortalProductTags | undefined;
    set internalValue(value: DataAwsccApigatewayv2PortalProductTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayv2PortalProductTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayv2PortalProductTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_portal_product awscc_apigatewayv2_portal_product}
*/
export declare class DataAwsccApigatewayv2PortalProduct extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_portal_product";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2PortalProduct resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2PortalProduct to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2PortalProduct that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_portal_product#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2PortalProduct to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_portal_product awscc_apigatewayv2_portal_product} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2PortalProductConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2PortalProductConfig);
    get description(): string;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get lastModified(): string;
    get portalProductArn(): string;
    get portalProductId(): string;
    private _tags;
    get tags(): DataAwsccApigatewayv2PortalProductTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
