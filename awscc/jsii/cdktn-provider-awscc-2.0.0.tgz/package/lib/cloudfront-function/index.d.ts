/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * A flag that determines whether to automatically publish the function to the ``LIVE`` stage when it?s created. To automatically publish to the ``LIVE`` stage, set this property to ``true``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#auto_publish CloudfrontFunction#auto_publish}
    */
    readonly autoPublish?: boolean | cdktn.IResolvable;
    /**
    * The function code. For more information about writing a CloudFront function, see [Writing function code for CloudFront Functions](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/writing-function-code.html) in the *Amazon CloudFront Developer Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#function_code CloudfrontFunction#function_code}
    */
    readonly functionCode: string;
    /**
    * Contains configuration information about a CloudFront function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#function_config CloudfrontFunction#function_config}
    */
    readonly functionConfig: CloudfrontFunctionFunctionConfig;
    /**
    * Contains metadata about a CloudFront function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#function_metadata CloudfrontFunction#function_metadata}
    */
    readonly functionMetadata?: CloudfrontFunctionFunctionMetadata;
    /**
    * A name to identify the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#name CloudfrontFunction#name}
    */
    readonly name: string;
    /**
    * A complex type that contains zero or more ``Tag`` elements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#tags CloudfrontFunction#tags}
    */
    readonly tags?: CloudfrontFunctionTags[] | cdktn.IResolvable;
}
export interface CloudfrontFunctionFunctionConfigKeyValueStoreAssociations {
    /**
    * The Amazon Resource Name (ARN) of the key value store association.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#key_value_store_arn CloudfrontFunction#key_value_store_arn}
    */
    readonly keyValueStoreArn?: string;
}
export declare function cloudfrontFunctionFunctionConfigKeyValueStoreAssociationsToTerraform(struct?: CloudfrontFunctionFunctionConfigKeyValueStoreAssociations | cdktn.IResolvable): any;
export declare function cloudfrontFunctionFunctionConfigKeyValueStoreAssociationsToHclTerraform(struct?: CloudfrontFunctionFunctionConfigKeyValueStoreAssociations | cdktn.IResolvable): any;
export declare class CloudfrontFunctionFunctionConfigKeyValueStoreAssociationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontFunctionFunctionConfigKeyValueStoreAssociations | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontFunctionFunctionConfigKeyValueStoreAssociations | cdktn.IResolvable | undefined);
    private _keyValueStoreArn?;
    get keyValueStoreArn(): string;
    set keyValueStoreArn(value: string);
    resetKeyValueStoreArn(): void;
    get keyValueStoreArnInput(): string | undefined;
}
export declare class CloudfrontFunctionFunctionConfigKeyValueStoreAssociationsList extends cdktn.ComplexList {
    internalValue?: CloudfrontFunctionFunctionConfigKeyValueStoreAssociations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontFunctionFunctionConfigKeyValueStoreAssociationsOutputReference;
}
export interface CloudfrontFunctionFunctionConfig {
    /**
    * A comment to describe the function. The comment cannot be longer than 128 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#comment CloudfrontFunction#comment}
    */
    readonly comment: string;
    /**
    * The configuration for the key value store associations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#key_value_store_associations CloudfrontFunction#key_value_store_associations}
    */
    readonly keyValueStoreAssociations?: CloudfrontFunctionFunctionConfigKeyValueStoreAssociations[] | cdktn.IResolvable;
    /**
    * The function's runtime environment version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#runtime CloudfrontFunction#runtime}
    */
    readonly runtime: string;
}
export declare function cloudfrontFunctionFunctionConfigToTerraform(struct?: CloudfrontFunctionFunctionConfig | cdktn.IResolvable): any;
export declare function cloudfrontFunctionFunctionConfigToHclTerraform(struct?: CloudfrontFunctionFunctionConfig | cdktn.IResolvable): any;
export declare class CloudfrontFunctionFunctionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontFunctionFunctionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontFunctionFunctionConfig | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    get commentInput(): string | undefined;
    private _keyValueStoreAssociations;
    get keyValueStoreAssociations(): CloudfrontFunctionFunctionConfigKeyValueStoreAssociationsList;
    putKeyValueStoreAssociations(value: CloudfrontFunctionFunctionConfigKeyValueStoreAssociations[] | cdktn.IResolvable): void;
    resetKeyValueStoreAssociations(): void;
    get keyValueStoreAssociationsInput(): cdktn.IResolvable | CloudfrontFunctionFunctionConfigKeyValueStoreAssociations[] | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    get runtimeInput(): string | undefined;
}
export interface CloudfrontFunctionFunctionMetadata {
}
export declare function cloudfrontFunctionFunctionMetadataToTerraform(struct?: CloudfrontFunctionFunctionMetadata | cdktn.IResolvable): any;
export declare function cloudfrontFunctionFunctionMetadataToHclTerraform(struct?: CloudfrontFunctionFunctionMetadata | cdktn.IResolvable): any;
export declare class CloudfrontFunctionFunctionMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontFunctionFunctionMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontFunctionFunctionMetadata | cdktn.IResolvable | undefined);
    get functionArn(): string;
}
export interface CloudfrontFunctionTags {
    /**
    * A string that contains ``Tag`` key.
    *  The string length should be between 1 and 128 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#key CloudfrontFunction#key}
    */
    readonly key?: string;
    /**
    * A string that contains an optional ``Tag`` value.
    *  The string length should be between 0 and 256 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#value CloudfrontFunction#value}
    */
    readonly value?: string;
}
export declare function cloudfrontFunctionTagsToTerraform(struct?: CloudfrontFunctionTags | cdktn.IResolvable): any;
export declare function cloudfrontFunctionTagsToHclTerraform(struct?: CloudfrontFunctionTags | cdktn.IResolvable): any;
export declare class CloudfrontFunctionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontFunctionTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontFunctionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontFunctionTagsList extends cdktn.ComplexList {
    internalValue?: CloudfrontFunctionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontFunctionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function awscc_cloudfront_function}
*/
export declare class CloudfrontFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_function";
    /**
    * Generates CDKTN code for importing a CloudfrontFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontFunction to import
    * @param importFromId The id of the existing CloudfrontFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_function awscc_cloudfront_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontFunctionConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontFunctionConfig);
    private _autoPublish?;
    get autoPublish(): boolean | cdktn.IResolvable;
    set autoPublish(value: boolean | cdktn.IResolvable);
    resetAutoPublish(): void;
    get autoPublishInput(): boolean | cdktn.IResolvable | undefined;
    get functionArn(): string;
    private _functionCode?;
    get functionCode(): string;
    set functionCode(value: string);
    get functionCodeInput(): string | undefined;
    private _functionConfig;
    get functionConfig(): CloudfrontFunctionFunctionConfigOutputReference;
    putFunctionConfig(value: CloudfrontFunctionFunctionConfig): void;
    get functionConfigInput(): cdktn.IResolvable | CloudfrontFunctionFunctionConfig | undefined;
    private _functionMetadata;
    get functionMetadata(): CloudfrontFunctionFunctionMetadataOutputReference;
    putFunctionMetadata(value: CloudfrontFunctionFunctionMetadata): void;
    resetFunctionMetadata(): void;
    get functionMetadataInput(): cdktn.IResolvable | CloudfrontFunctionFunctionMetadata | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get stage(): string;
    private _tags;
    get tags(): CloudfrontFunctionTagsList;
    putTags(value: CloudfrontFunctionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudfrontFunctionTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
