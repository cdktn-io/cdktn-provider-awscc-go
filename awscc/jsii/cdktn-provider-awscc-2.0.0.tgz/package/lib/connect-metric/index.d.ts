/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectMetricConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the custom metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#description ConnectMetric#description}
    */
    readonly description?: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#instance_arn ConnectMetric#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The calculation configuration for the metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#metric_calculation ConnectMetric#metric_calculation}
    */
    readonly metricCalculation: ConnectMetricMetricCalculation;
    /**
    * The name of the custom metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#name ConnectMetric#name}
    */
    readonly name: string;
    /**
    * Indicates how to classify a positive trend in metric data on the UI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#positive_trend_indicator ConnectMetric#positive_trend_indicator}
    */
    readonly positiveTrendIndicator?: string;
    /**
    * The status of the custom metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#status ConnectMetric#status}
    */
    readonly status: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#tags ConnectMetric#tags}
    */
    readonly tags?: ConnectMetricTags[] | cdktn.IResolvable;
    /**
    * Display unit for the metric data
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#unit ConnectMetric#unit}
    */
    readonly unit: string;
}
export interface ConnectMetricCreatedUser {
}
export declare function connectMetricCreatedUserToTerraform(struct?: ConnectMetricCreatedUser): any;
export declare function connectMetricCreatedUserToHclTerraform(struct?: ConnectMetricCreatedUser): any;
export declare class ConnectMetricCreatedUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectMetricCreatedUser | undefined;
    set internalValue(value: ConnectMetricCreatedUser | undefined);
    get awsIdentityArn(): string;
    get connectUserArn(): string;
}
export interface ConnectMetricFilters {
}
export declare function connectMetricFiltersToTerraform(struct?: ConnectMetricFilters): any;
export declare function connectMetricFiltersToHclTerraform(struct?: ConnectMetricFilters): any;
export declare class ConnectMetricFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectMetricFilters | undefined;
    set internalValue(value: ConnectMetricFilters | undefined);
    get id(): string;
    get type(): string;
}
export declare class ConnectMetricFiltersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectMetricFiltersOutputReference;
}
export interface ConnectMetricLastModifiedUser {
}
export declare function connectMetricLastModifiedUserToTerraform(struct?: ConnectMetricLastModifiedUser): any;
export declare function connectMetricLastModifiedUserToHclTerraform(struct?: ConnectMetricLastModifiedUser): any;
export declare class ConnectMetricLastModifiedUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectMetricLastModifiedUser | undefined;
    set internalValue(value: ConnectMetricLastModifiedUser | undefined);
    get awsIdentityArn(): string;
    get connectUserArn(): string;
}
export interface ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#comparison ConnectMetric#comparison}
    */
    readonly comparison?: string;
}
export declare function connectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanConditionToTerraform(struct?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanCondition | cdktn.IResolvable): any;
export declare function connectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanConditionToHclTerraform(struct?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanCondition | cdktn.IResolvable): any;
export declare class ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanCondition | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanCondition | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
}
export interface ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#comparison ConnectMetric#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#values ConnectMetric#values}
    */
    readonly values?: number[];
}
export declare function connectMetricMetricCalculationCalculationComponentsMetricFiltersNumberConditionToTerraform(struct?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberCondition | cdktn.IResolvable): any;
export declare function connectMetricMetricCalculationCalculationComponentsMetricFiltersNumberConditionToHclTerraform(struct?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberCondition | cdktn.IResolvable): any;
export declare class ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberCondition | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberCondition | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): number[];
    set values(value: number[]);
    resetValues(): void;
    get valuesInput(): number[] | undefined;
}
export interface ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#comparison ConnectMetric#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#values ConnectMetric#values}
    */
    readonly values?: string[];
}
export declare function connectMetricMetricCalculationCalculationComponentsMetricFiltersStringConditionToTerraform(struct?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringCondition | cdktn.IResolvable): any;
export declare function connectMetricMetricCalculationCalculationComponentsMetricFiltersStringConditionToHclTerraform(struct?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringCondition | cdktn.IResolvable): any;
export declare class ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringCondition | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringCondition | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface ConnectMetricMetricCalculationCalculationComponentsMetricFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#boolean_condition ConnectMetric#boolean_condition}
    */
    readonly booleanCondition?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanCondition;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#metric_filter_key ConnectMetric#metric_filter_key}
    */
    readonly metricFilterKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#negate ConnectMetric#negate}
    */
    readonly negate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#number_condition ConnectMetric#number_condition}
    */
    readonly numberCondition?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberCondition;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#string_condition ConnectMetric#string_condition}
    */
    readonly stringCondition?: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringCondition;
}
export declare function connectMetricMetricCalculationCalculationComponentsMetricFiltersToTerraform(struct?: ConnectMetricMetricCalculationCalculationComponentsMetricFilters | cdktn.IResolvable): any;
export declare function connectMetricMetricCalculationCalculationComponentsMetricFiltersToHclTerraform(struct?: ConnectMetricMetricCalculationCalculationComponentsMetricFilters | cdktn.IResolvable): any;
export declare class ConnectMetricMetricCalculationCalculationComponentsMetricFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectMetricMetricCalculationCalculationComponentsMetricFilters | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectMetricMetricCalculationCalculationComponentsMetricFilters | cdktn.IResolvable | undefined);
    private _booleanCondition;
    get booleanCondition(): ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanConditionOutputReference;
    putBooleanCondition(value: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanCondition): void;
    resetBooleanCondition(): void;
    get booleanConditionInput(): cdktn.IResolvable | ConnectMetricMetricCalculationCalculationComponentsMetricFiltersBooleanCondition | undefined;
    private _metricFilterKey?;
    get metricFilterKey(): string;
    set metricFilterKey(value: string);
    resetMetricFilterKey(): void;
    get metricFilterKeyInput(): string | undefined;
    private _negate?;
    get negate(): boolean | cdktn.IResolvable;
    set negate(value: boolean | cdktn.IResolvable);
    resetNegate(): void;
    get negateInput(): boolean | cdktn.IResolvable | undefined;
    private _numberCondition;
    get numberCondition(): ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberConditionOutputReference;
    putNumberCondition(value: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberCondition): void;
    resetNumberCondition(): void;
    get numberConditionInput(): cdktn.IResolvable | ConnectMetricMetricCalculationCalculationComponentsMetricFiltersNumberCondition | undefined;
    private _stringCondition;
    get stringCondition(): ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringConditionOutputReference;
    putStringCondition(value: ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringCondition): void;
    resetStringCondition(): void;
    get stringConditionInput(): cdktn.IResolvable | ConnectMetricMetricCalculationCalculationComponentsMetricFiltersStringCondition | undefined;
}
export declare class ConnectMetricMetricCalculationCalculationComponentsMetricFiltersList extends cdktn.ComplexList {
    internalValue?: ConnectMetricMetricCalculationCalculationComponentsMetricFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectMetricMetricCalculationCalculationComponentsMetricFiltersOutputReference;
}
export interface ConnectMetricMetricCalculationCalculationComponents {
    /**
    * Metric calculation component alias for use within a calculation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#alias ConnectMetric#alias}
    */
    readonly alias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#metric_filters ConnectMetric#metric_filters}
    */
    readonly metricFilters?: ConnectMetricMetricCalculationCalculationComponentsMetricFilters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#metric_id ConnectMetric#metric_id}
    */
    readonly metricId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#metric_name ConnectMetric#metric_name}
    */
    readonly metricName?: string;
}
export declare function connectMetricMetricCalculationCalculationComponentsToTerraform(struct?: ConnectMetricMetricCalculationCalculationComponents | cdktn.IResolvable): any;
export declare function connectMetricMetricCalculationCalculationComponentsToHclTerraform(struct?: ConnectMetricMetricCalculationCalculationComponents | cdktn.IResolvable): any;
export declare class ConnectMetricMetricCalculationCalculationComponentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectMetricMetricCalculationCalculationComponents | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectMetricMetricCalculationCalculationComponents | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    get aliasInput(): string | undefined;
    private _metricFilters;
    get metricFilters(): ConnectMetricMetricCalculationCalculationComponentsMetricFiltersList;
    putMetricFilters(value: ConnectMetricMetricCalculationCalculationComponentsMetricFilters[] | cdktn.IResolvable): void;
    resetMetricFilters(): void;
    get metricFiltersInput(): cdktn.IResolvable | ConnectMetricMetricCalculationCalculationComponentsMetricFilters[] | undefined;
    private _metricId?;
    get metricId(): string;
    set metricId(value: string);
    resetMetricId(): void;
    get metricIdInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
}
export declare class ConnectMetricMetricCalculationCalculationComponentsList extends cdktn.ComplexList {
    internalValue?: ConnectMetricMetricCalculationCalculationComponents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectMetricMetricCalculationCalculationComponentsOutputReference;
}
export interface ConnectMetricMetricCalculation {
    /**
    * The calculation formula
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#calculation ConnectMetric#calculation}
    */
    readonly calculation: string;
    /**
    * The calculation components for the metric
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#calculation_components ConnectMetric#calculation_components}
    */
    readonly calculationComponents: ConnectMetricMetricCalculationCalculationComponents[] | cdktn.IResolvable;
}
export declare function connectMetricMetricCalculationToTerraform(struct?: ConnectMetricMetricCalculation | cdktn.IResolvable): any;
export declare function connectMetricMetricCalculationToHclTerraform(struct?: ConnectMetricMetricCalculation | cdktn.IResolvable): any;
export declare class ConnectMetricMetricCalculationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectMetricMetricCalculation | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectMetricMetricCalculation | cdktn.IResolvable | undefined);
    private _calculation?;
    get calculation(): string;
    set calculation(value: string);
    get calculationInput(): string | undefined;
    private _calculationComponents;
    get calculationComponents(): ConnectMetricMetricCalculationCalculationComponentsList;
    putCalculationComponents(value: ConnectMetricMetricCalculationCalculationComponents[] | cdktn.IResolvable): void;
    get calculationComponentsInput(): cdktn.IResolvable | ConnectMetricMetricCalculationCalculationComponents[] | undefined;
}
export interface ConnectMetricTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#key ConnectMetric#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#value ConnectMetric#value}
    */
    readonly value?: string;
}
export declare function connectMetricTagsToTerraform(struct?: ConnectMetricTags | cdktn.IResolvable): any;
export declare function connectMetricTagsToHclTerraform(struct?: ConnectMetricTags | cdktn.IResolvable): any;
export declare class ConnectMetricTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectMetricTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectMetricTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectMetricTagsList extends cdktn.ComplexList {
    internalValue?: ConnectMetricTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectMetricTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric awscc_connect_metric}
*/
export declare class ConnectMetric extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_metric";
    /**
    * Generates CDKTN code for importing a ConnectMetric resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectMetric to import
    * @param importFromId The id of the existing ConnectMetric that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectMetric to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_metric awscc_connect_metric} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectMetricConfig
    */
    constructor(scope: Construct, id: string, config: ConnectMetricConfig);
    get category(): string;
    get createdTime(): number;
    private _createdUser;
    get createdUser(): ConnectMetricCreatedUserOutputReference;
    get creationMethod(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get effectiveTime(): number;
    private _filters;
    get filters(): ConnectMetricFiltersList;
    get groupings(): string[];
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get lastModifiedRegion(): string;
    get lastModifiedTime(): number;
    private _lastModifiedUser;
    get lastModifiedUser(): ConnectMetricLastModifiedUserOutputReference;
    get metricArn(): string;
    private _metricCalculation;
    get metricCalculation(): ConnectMetricMetricCalculationOutputReference;
    putMetricCalculation(value: ConnectMetricMetricCalculation): void;
    get metricCalculationInput(): cdktn.IResolvable | ConnectMetricMetricCalculation | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _positiveTrendIndicator?;
    get positiveTrendIndicator(): string;
    set positiveTrendIndicator(value: string);
    resetPositiveTrendIndicator(): void;
    get positiveTrendIndicatorInput(): string | undefined;
    get primaryEventSource(): string;
    get primaryEventSourceEffectiveTimestampType(): string;
    get refreshRate(): number;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    get supportedStats(): string[];
    get supportsCustomCalculation(): cdktn.IResolvable;
    get supportsPreaggregateCalculation(): cdktn.IResolvable;
    private _tags;
    get tags(): ConnectMetricTagsList;
    putTags(value: ConnectMetricTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectMetricTags[] | undefined;
    get type(): string;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
