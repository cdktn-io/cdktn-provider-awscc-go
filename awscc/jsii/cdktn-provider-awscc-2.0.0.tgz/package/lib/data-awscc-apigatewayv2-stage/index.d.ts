/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2StageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_stage#id DataAwsccApigatewayv2Stage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2StageAccessLogSettings {
}
export declare function dataAwsccApigatewayv2StageAccessLogSettingsToTerraform(struct?: DataAwsccApigatewayv2StageAccessLogSettings): any;
export declare function dataAwsccApigatewayv2StageAccessLogSettingsToHclTerraform(struct?: DataAwsccApigatewayv2StageAccessLogSettings): any;
export declare class DataAwsccApigatewayv2StageAccessLogSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2StageAccessLogSettings | undefined;
    set internalValue(value: DataAwsccApigatewayv2StageAccessLogSettings | undefined);
    get destinationArn(): string;
    get format(): string;
}
export interface DataAwsccApigatewayv2StageDefaultRouteSettings {
}
export declare function dataAwsccApigatewayv2StageDefaultRouteSettingsToTerraform(struct?: DataAwsccApigatewayv2StageDefaultRouteSettings): any;
export declare function dataAwsccApigatewayv2StageDefaultRouteSettingsToHclTerraform(struct?: DataAwsccApigatewayv2StageDefaultRouteSettings): any;
export declare class DataAwsccApigatewayv2StageDefaultRouteSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2StageDefaultRouteSettings | undefined;
    set internalValue(value: DataAwsccApigatewayv2StageDefaultRouteSettings | undefined);
    get dataTraceEnabled(): cdktn.IResolvable;
    get detailedMetricsEnabled(): cdktn.IResolvable;
    get loggingLevel(): string;
    get throttlingBurstLimit(): number;
    get throttlingRateLimit(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_stage awscc_apigatewayv2_stage}
*/
export declare class DataAwsccApigatewayv2Stage extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_stage";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2Stage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2Stage to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2Stage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_stage#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2Stage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigatewayv2_stage awscc_apigatewayv2_stage} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2StageConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2StageConfig);
    private _accessLogSettings;
    get accessLogSettings(): DataAwsccApigatewayv2StageAccessLogSettingsOutputReference;
    get apiId(): string;
    get autoDeploy(): cdktn.IResolvable;
    get clientCertificateId(): string;
    private _defaultRouteSettings;
    get defaultRouteSettings(): DataAwsccApigatewayv2StageDefaultRouteSettingsOutputReference;
    get deploymentId(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get routeSettings(): string;
    get stageName(): string;
    get stageVariables(): string;
    get tags(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
