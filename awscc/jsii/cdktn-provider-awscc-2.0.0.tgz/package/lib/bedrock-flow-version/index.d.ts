/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockFlowVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the flow version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_flow_version#description BedrockFlowVersion#description}
    */
    readonly description?: string;
    /**
    * Arn representation of the Flow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_flow_version#flow_arn BedrockFlowVersion#flow_arn}
    */
    readonly flowArn: string;
}
export interface BedrockFlowVersionDefinitionConnectionsConfigurationConditional {
}
export declare function bedrockFlowVersionDefinitionConnectionsConfigurationConditionalToTerraform(struct?: BedrockFlowVersionDefinitionConnectionsConfigurationConditional): any;
export declare function bedrockFlowVersionDefinitionConnectionsConfigurationConditionalToHclTerraform(struct?: BedrockFlowVersionDefinitionConnectionsConfigurationConditional): any;
export declare class BedrockFlowVersionDefinitionConnectionsConfigurationConditionalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionConnectionsConfigurationConditional | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionConnectionsConfigurationConditional | undefined);
    get condition(): string;
}
export interface BedrockFlowVersionDefinitionConnectionsConfigurationData {
}
export declare function bedrockFlowVersionDefinitionConnectionsConfigurationDataToTerraform(struct?: BedrockFlowVersionDefinitionConnectionsConfigurationData): any;
export declare function bedrockFlowVersionDefinitionConnectionsConfigurationDataToHclTerraform(struct?: BedrockFlowVersionDefinitionConnectionsConfigurationData): any;
export declare class BedrockFlowVersionDefinitionConnectionsConfigurationDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionConnectionsConfigurationData | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionConnectionsConfigurationData | undefined);
    get sourceOutput(): string;
    get targetInput(): string;
}
export interface BedrockFlowVersionDefinitionConnectionsConfiguration {
}
export declare function bedrockFlowVersionDefinitionConnectionsConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionConnectionsConfiguration): any;
export declare function bedrockFlowVersionDefinitionConnectionsConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionConnectionsConfiguration): any;
export declare class BedrockFlowVersionDefinitionConnectionsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionConnectionsConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionConnectionsConfiguration | undefined);
    private _conditional;
    get conditional(): BedrockFlowVersionDefinitionConnectionsConfigurationConditionalOutputReference;
    private _data;
    get data(): BedrockFlowVersionDefinitionConnectionsConfigurationDataOutputReference;
}
export interface BedrockFlowVersionDefinitionConnections {
}
export declare function bedrockFlowVersionDefinitionConnectionsToTerraform(struct?: BedrockFlowVersionDefinitionConnections): any;
export declare function bedrockFlowVersionDefinitionConnectionsToHclTerraform(struct?: BedrockFlowVersionDefinitionConnections): any;
export declare class BedrockFlowVersionDefinitionConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockFlowVersionDefinitionConnections | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionConnections | undefined);
    private _configuration;
    get configuration(): BedrockFlowVersionDefinitionConnectionsConfigurationOutputReference;
    get name(): string;
    get source(): string;
    get target(): string;
    get type(): string;
}
export declare class BedrockFlowVersionDefinitionConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockFlowVersionDefinitionConnectionsOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationAgent {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationAgentToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationAgent): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationAgentToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationAgent): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationAgent | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationAgent | undefined);
    get agentAliasArn(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationConditionConditions {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationConditionConditionsToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationConditionConditions): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationConditionConditionsToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationConditionConditions): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationConditionConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationConditionConditions | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationConditionConditions | undefined);
    get expression(): string;
    get name(): string;
}
export declare class BedrockFlowVersionDefinitionNodesConfigurationConditionConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockFlowVersionDefinitionNodesConfigurationConditionConditionsOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationCondition {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationConditionToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationCondition): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationConditionToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationCondition): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationCondition | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationCondition | undefined);
    private _conditions;
    get conditions(): BedrockFlowVersionDefinitionNodesConfigurationConditionConditionsList;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationInlineCode {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationInlineCodeToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationInlineCode): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationInlineCodeToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationInlineCode): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationInlineCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationInlineCode | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationInlineCode | undefined);
    get code(): string;
    get language(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfiguration {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfiguration): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfiguration): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfiguration | undefined);
    get guardrailIdentifier(): string;
    get guardrailVersion(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBase {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBase): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBase): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBase | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBase | undefined);
    private _guardrailConfiguration;
    get guardrailConfiguration(): BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseGuardrailConfigurationOutputReference;
    get knowledgeBaseId(): string;
    get modelId(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationLambdaFunction {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationLambdaFunctionToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationLambdaFunction): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationLambdaFunctionToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationLambdaFunction): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationLambdaFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationLambdaFunction | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationLambdaFunction | undefined);
    get lambdaArn(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationLex {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationLexToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationLex): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationLexToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationLex): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationLexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationLex | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationLex | undefined);
    get botAliasArn(): string;
    get localeId(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfiguration {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfiguration): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfiguration): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfiguration | undefined);
    get guardrailIdentifier(): string;
    get guardrailVersion(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationText {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationText): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationText): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationText | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationText | undefined);
    get maxTokens(): number;
    get stopSequences(): string[];
    get temperature(): number;
    get topP(): number;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfiguration {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfiguration): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfiguration): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfiguration | undefined);
    private _text;
    get text(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariables {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablesToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariables): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablesToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariables): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariables | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariables | undefined);
    get name(): string;
}
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablesOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationText {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationText): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationText): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationText | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationText | undefined);
    private _inputVariables;
    get inputVariables(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablesList;
    get text(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfiguration {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfiguration): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfiguration): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfiguration | undefined);
    private _text;
    get text(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInline {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInline): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInline): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInline | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInline | undefined);
    private _inferenceConfiguration;
    get inferenceConfiguration(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineInferenceConfigurationOutputReference;
    get modelId(): string;
    private _templateConfiguration;
    get templateConfiguration(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineTemplateConfigurationOutputReference;
    get templateType(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResource {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResourceToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResource): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResourceToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResource): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResource | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResource | undefined);
    get promptArn(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfiguration {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfiguration): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfiguration): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfiguration | undefined);
    private _inline;
    get inline(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationInlineOutputReference;
    private _resource;
    get resource(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationResourceOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationPrompt {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPrompt): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationPromptToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationPrompt): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationPromptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationPrompt | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationPrompt | undefined);
    private _guardrailConfiguration;
    get guardrailConfiguration(): BedrockFlowVersionDefinitionNodesConfigurationPromptGuardrailConfigurationOutputReference;
    private _sourceConfiguration;
    get sourceConfiguration(): BedrockFlowVersionDefinitionNodesConfigurationPromptSourceConfigurationOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3 {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3ToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3ToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3 | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3 | undefined);
    get bucketName(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfiguration {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfiguration): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfiguration): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfiguration | undefined);
    private _s3;
    get s3(): BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationS3OutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationRetrieval {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationRetrievalToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationRetrieval): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationRetrievalToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationRetrieval): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationRetrieval | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationRetrieval | undefined);
    private _serviceConfiguration;
    get serviceConfiguration(): BedrockFlowVersionDefinitionNodesConfigurationRetrievalServiceConfigurationOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3 {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3ToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3ToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3 | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3 | undefined);
    get bucketName(): string;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfiguration {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfiguration): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfiguration): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfiguration | undefined);
    private _s3;
    get s3(): BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationS3OutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfigurationStorage {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationStorageToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationStorage): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationStorageToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfigurationStorage): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfigurationStorage | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfigurationStorage | undefined);
    private _serviceConfiguration;
    get serviceConfiguration(): BedrockFlowVersionDefinitionNodesConfigurationStorageServiceConfigurationOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesConfiguration {
}
export declare function bedrockFlowVersionDefinitionNodesConfigurationToTerraform(struct?: BedrockFlowVersionDefinitionNodesConfiguration): any;
export declare function bedrockFlowVersionDefinitionNodesConfigurationToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesConfiguration): any;
export declare class BedrockFlowVersionDefinitionNodesConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinitionNodesConfiguration | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesConfiguration | undefined);
    private _agent;
    get agent(): BedrockFlowVersionDefinitionNodesConfigurationAgentOutputReference;
    get collector(): string;
    private _condition;
    get condition(): BedrockFlowVersionDefinitionNodesConfigurationConditionOutputReference;
    private _inlineCode;
    get inlineCode(): BedrockFlowVersionDefinitionNodesConfigurationInlineCodeOutputReference;
    get input(): string;
    get iterator(): string;
    private _knowledgeBase;
    get knowledgeBase(): BedrockFlowVersionDefinitionNodesConfigurationKnowledgeBaseOutputReference;
    private _lambdaFunction;
    get lambdaFunction(): BedrockFlowVersionDefinitionNodesConfigurationLambdaFunctionOutputReference;
    private _lex;
    get lex(): BedrockFlowVersionDefinitionNodesConfigurationLexOutputReference;
    get output(): string;
    private _prompt;
    get prompt(): BedrockFlowVersionDefinitionNodesConfigurationPromptOutputReference;
    private _retrieval;
    get retrieval(): BedrockFlowVersionDefinitionNodesConfigurationRetrievalOutputReference;
    private _storage;
    get storage(): BedrockFlowVersionDefinitionNodesConfigurationStorageOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesInputs {
}
export declare function bedrockFlowVersionDefinitionNodesInputsToTerraform(struct?: BedrockFlowVersionDefinitionNodesInputs): any;
export declare function bedrockFlowVersionDefinitionNodesInputsToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesInputs): any;
export declare class BedrockFlowVersionDefinitionNodesInputsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockFlowVersionDefinitionNodesInputs | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesInputs | undefined);
    get expression(): string;
    get name(): string;
    get type(): string;
}
export declare class BedrockFlowVersionDefinitionNodesInputsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockFlowVersionDefinitionNodesInputsOutputReference;
}
export interface BedrockFlowVersionDefinitionNodesOutputs {
}
export declare function bedrockFlowVersionDefinitionNodesOutputsToTerraform(struct?: BedrockFlowVersionDefinitionNodesOutputs): any;
export declare function bedrockFlowVersionDefinitionNodesOutputsToHclTerraform(struct?: BedrockFlowVersionDefinitionNodesOutputs): any;
export declare class BedrockFlowVersionDefinitionNodesOutputsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockFlowVersionDefinitionNodesOutputs | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodesOutputs | undefined);
    get name(): string;
    get type(): string;
}
export declare class BedrockFlowVersionDefinitionNodesOutputsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockFlowVersionDefinitionNodesOutputsOutputReference;
}
export interface BedrockFlowVersionDefinitionNodes {
}
export declare function bedrockFlowVersionDefinitionNodesToTerraform(struct?: BedrockFlowVersionDefinitionNodes): any;
export declare function bedrockFlowVersionDefinitionNodesToHclTerraform(struct?: BedrockFlowVersionDefinitionNodes): any;
export declare class BedrockFlowVersionDefinitionNodesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockFlowVersionDefinitionNodes | undefined;
    set internalValue(value: BedrockFlowVersionDefinitionNodes | undefined);
    private _configuration;
    get configuration(): BedrockFlowVersionDefinitionNodesConfigurationOutputReference;
    private _inputs;
    get inputs(): BedrockFlowVersionDefinitionNodesInputsList;
    get name(): string;
    private _outputs;
    get outputs(): BedrockFlowVersionDefinitionNodesOutputsList;
    get type(): string;
}
export declare class BedrockFlowVersionDefinitionNodesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockFlowVersionDefinitionNodesOutputReference;
}
export interface BedrockFlowVersionDefinition {
}
export declare function bedrockFlowVersionDefinitionToTerraform(struct?: BedrockFlowVersionDefinition): any;
export declare function bedrockFlowVersionDefinitionToHclTerraform(struct?: BedrockFlowVersionDefinition): any;
export declare class BedrockFlowVersionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowVersionDefinition | undefined;
    set internalValue(value: BedrockFlowVersionDefinition | undefined);
    private _connections;
    get connections(): BedrockFlowVersionDefinitionConnectionsList;
    private _nodes;
    get nodes(): BedrockFlowVersionDefinitionNodesList;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_flow_version awscc_bedrock_flow_version}
*/
export declare class BedrockFlowVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_flow_version";
    /**
    * Generates CDKTN code for importing a BedrockFlowVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockFlowVersion to import
    * @param importFromId The id of the existing BedrockFlowVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_flow_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockFlowVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_flow_version awscc_bedrock_flow_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockFlowVersionConfig
    */
    constructor(scope: Construct, id: string, config: BedrockFlowVersionConfig);
    get createdAt(): string;
    get customerEncryptionKeyArn(): string;
    private _definition;
    get definition(): BedrockFlowVersionDefinitionOutputReference;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get executionRoleArn(): string;
    private _flowArn?;
    get flowArn(): string;
    set flowArn(value: string);
    get flowArnInput(): string | undefined;
    get flowId(): string;
    get id(): string;
    get name(): string;
    get status(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
