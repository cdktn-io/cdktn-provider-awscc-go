/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BcmpricingcalculatorBillScenarioConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the cost category group sharing preference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario#cost_category_group_sharing_preference_arn BcmpricingcalculatorBillScenario#cost_category_group_sharing_preference_arn}
    */
    readonly costCategoryGroupSharingPreferenceArn?: string;
    /**
    * The timestamp when the bill scenario expires
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario#expires_at BcmpricingcalculatorBillScenario#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The group sharing preference for the bill scenario
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario#group_sharing_preference BcmpricingcalculatorBillScenario#group_sharing_preference}
    */
    readonly groupSharingPreference?: string;
    /**
    * The name of the bill scenario
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario#name BcmpricingcalculatorBillScenario#name}
    */
    readonly name?: string;
    /**
    * An array of key-value pairs to apply to this resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario#tags BcmpricingcalculatorBillScenario#tags}
    */
    readonly tags?: BcmpricingcalculatorBillScenarioTags[] | cdktn.IResolvable;
}
export interface BcmpricingcalculatorBillScenarioBillInterval {
}
export declare function bcmpricingcalculatorBillScenarioBillIntervalToTerraform(struct?: BcmpricingcalculatorBillScenarioBillInterval): any;
export declare function bcmpricingcalculatorBillScenarioBillIntervalToHclTerraform(struct?: BcmpricingcalculatorBillScenarioBillInterval): any;
export declare class BcmpricingcalculatorBillScenarioBillIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmpricingcalculatorBillScenarioBillInterval | undefined;
    set internalValue(value: BcmpricingcalculatorBillScenarioBillInterval | undefined);
    get end(): string;
    get start(): string;
}
export interface BcmpricingcalculatorBillScenarioTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario#key BcmpricingcalculatorBillScenario#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario#value BcmpricingcalculatorBillScenario#value}
    */
    readonly value?: string;
}
export declare function bcmpricingcalculatorBillScenarioTagsToTerraform(struct?: BcmpricingcalculatorBillScenarioTags | cdktn.IResolvable): any;
export declare function bcmpricingcalculatorBillScenarioTagsToHclTerraform(struct?: BcmpricingcalculatorBillScenarioTags | cdktn.IResolvable): any;
export declare class BcmpricingcalculatorBillScenarioTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmpricingcalculatorBillScenarioTags | cdktn.IResolvable | undefined;
    set internalValue(value: BcmpricingcalculatorBillScenarioTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BcmpricingcalculatorBillScenarioTagsList extends cdktn.ComplexList {
    internalValue?: BcmpricingcalculatorBillScenarioTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmpricingcalculatorBillScenarioTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario awscc_bcmpricingcalculator_bill_scenario}
*/
export declare class BcmpricingcalculatorBillScenario extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bcmpricingcalculator_bill_scenario";
    /**
    * Generates CDKTN code for importing a BcmpricingcalculatorBillScenario resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BcmpricingcalculatorBillScenario to import
    * @param importFromId The id of the existing BcmpricingcalculatorBillScenario that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BcmpricingcalculatorBillScenario to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bcmpricingcalculator_bill_scenario awscc_bcmpricingcalculator_bill_scenario} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BcmpricingcalculatorBillScenarioConfig = {}
    */
    constructor(scope: Construct, id: string, config?: BcmpricingcalculatorBillScenarioConfig);
    get arn(): string;
    private _billInterval;
    get billInterval(): BcmpricingcalculatorBillScenarioBillIntervalOutputReference;
    get billScenarioId(): string;
    private _costCategoryGroupSharingPreferenceArn?;
    get costCategoryGroupSharingPreferenceArn(): string;
    set costCategoryGroupSharingPreferenceArn(value: string);
    resetCostCategoryGroupSharingPreferenceArn(): void;
    get costCategoryGroupSharingPreferenceArnInput(): string | undefined;
    get createdAt(): string;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    get failureMessage(): string;
    private _groupSharingPreference?;
    get groupSharingPreference(): string;
    set groupSharingPreference(value: string);
    resetGroupSharingPreference(): void;
    get groupSharingPreferenceInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): BcmpricingcalculatorBillScenarioTagsList;
    putTags(value: BcmpricingcalculatorBillScenarioTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BcmpricingcalculatorBillScenarioTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
