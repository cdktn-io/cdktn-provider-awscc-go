/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApptestTestCaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#description ApptestTestCase#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#name ApptestTestCase#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#steps ApptestTestCase#steps}
    */
    readonly steps: ApptestTestCaseSteps[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#tags ApptestTestCase#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface ApptestTestCaseLatestVersion {
}
export declare function apptestTestCaseLatestVersionToTerraform(struct?: ApptestTestCaseLatestVersion): any;
export declare function apptestTestCaseLatestVersionToHclTerraform(struct?: ApptestTestCaseLatestVersion): any;
export declare class ApptestTestCaseLatestVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseLatestVersion | undefined;
    set internalValue(value: ApptestTestCaseLatestVersion | undefined);
    get status(): string;
    get version(): number;
}
export interface ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#ccsid ApptestTestCase#ccsid}
    */
    readonly ccsid?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#format ApptestTestCase#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#length ApptestTestCase#length}
    */
    readonly length?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#name ApptestTestCase#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#type ApptestTestCase#type}
    */
    readonly type?: string;
}
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSetsToTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSetsToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets | cdktn.IResolvable | undefined);
    private _ccsid?;
    get ccsid(): string;
    set ccsid(value: string);
    resetCcsid(): void;
    get ccsidInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _length?;
    get length(): number;
    set length(value: number);
    resetLength(): void;
    get lengthInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSetsList extends cdktn.ComplexList {
    internalValue?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSetsOutputReference;
}
export interface ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#capture_tool ApptestTestCase#capture_tool}
    */
    readonly captureTool?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#type ApptestTestCase#type}
    */
    readonly type?: string;
}
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadataToTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadata | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadataToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadata | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadata | cdktn.IResolvable | undefined);
    private _captureTool?;
    get captureTool(): string;
    set captureTool(value: string);
    resetCaptureTool(): void;
    get captureToolInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#capture_tool ApptestTestCase#capture_tool}
    */
    readonly captureTool?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#type ApptestTestCase#type}
    */
    readonly type?: string;
}
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadataToTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadata | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadataToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadata | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadata | cdktn.IResolvable | undefined);
    private _captureTool?;
    get captureTool(): string;
    set captureTool(value: string);
    resetCaptureTool(): void;
    get captureToolInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdc {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#source_metadata ApptestTestCase#source_metadata}
    */
    readonly sourceMetadata?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadata;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#target_metadata ApptestTestCase#target_metadata}
    */
    readonly targetMetadata?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadata;
}
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcToTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdc | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdc | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdc | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdc | cdktn.IResolvable | undefined);
    private _sourceMetadata;
    get sourceMetadata(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadataOutputReference;
    putSourceMetadata(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadata): void;
    resetSourceMetadata(): void;
    get sourceMetadataInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcSourceMetadata | undefined;
    private _targetMetadata;
    get targetMetadata(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadataOutputReference;
    putTargetMetadata(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadata): void;
    resetTargetMetadata(): void;
    get targetMetadataInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcTargetMetadata | undefined;
}
export interface ApptestTestCaseStepsActionCompareActionInputFileFileMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#data_sets ApptestTestCase#data_sets}
    */
    readonly dataSets?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#database_cdc ApptestTestCase#database_cdc}
    */
    readonly databaseCdc?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdc;
}
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataToTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadata | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionInputFileFileMetadataToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadata | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionInputFileFileMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadata | cdktn.IResolvable | undefined);
    private _dataSets;
    get dataSets(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSetsList;
    putDataSets(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets[] | cdktn.IResolvable): void;
    resetDataSets(): void;
    get dataSetsInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDataSets[] | undefined;
    private _databaseCdc;
    get databaseCdc(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdcOutputReference;
    putDatabaseCdc(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdc): void;
    resetDatabaseCdc(): void;
    get databaseCdcInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionInputFileFileMetadataDatabaseCdc | undefined;
}
export interface ApptestTestCaseStepsActionCompareActionInputFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#file_metadata ApptestTestCase#file_metadata}
    */
    readonly fileMetadata?: ApptestTestCaseStepsActionCompareActionInputFileFileMetadata;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#source_location ApptestTestCase#source_location}
    */
    readonly sourceLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#target_location ApptestTestCase#target_location}
    */
    readonly targetLocation?: string;
}
export declare function apptestTestCaseStepsActionCompareActionInputFileToTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFile | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionInputFileToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionInputFile | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionInputFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareActionInputFile | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionInputFile | cdktn.IResolvable | undefined);
    private _fileMetadata;
    get fileMetadata(): ApptestTestCaseStepsActionCompareActionInputFileFileMetadataOutputReference;
    putFileMetadata(value: ApptestTestCaseStepsActionCompareActionInputFileFileMetadata): void;
    resetFileMetadata(): void;
    get fileMetadataInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionInputFileFileMetadata | undefined;
    private _sourceLocation?;
    get sourceLocation(): string;
    set sourceLocation(value: string);
    resetSourceLocation(): void;
    get sourceLocationInput(): string | undefined;
    private _targetLocation?;
    get targetLocation(): string;
    set targetLocation(value: string);
    resetTargetLocation(): void;
    get targetLocationInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionCompareActionInput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#file ApptestTestCase#file}
    */
    readonly file?: ApptestTestCaseStepsActionCompareActionInputFile;
}
export declare function apptestTestCaseStepsActionCompareActionInputToTerraform(struct?: ApptestTestCaseStepsActionCompareActionInput | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionInputToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionInput | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareActionInput | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionInput | cdktn.IResolvable | undefined);
    private _file;
    get file(): ApptestTestCaseStepsActionCompareActionInputFileOutputReference;
    putFile(value: ApptestTestCaseStepsActionCompareActionInputFile): void;
    resetFile(): void;
    get fileInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionInputFile | undefined;
}
export interface ApptestTestCaseStepsActionCompareActionOutputFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#file_location ApptestTestCase#file_location}
    */
    readonly fileLocation?: string;
}
export declare function apptestTestCaseStepsActionCompareActionOutputFileToTerraform(struct?: ApptestTestCaseStepsActionCompareActionOutputFile | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionOutputFileToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionOutputFile | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionOutputFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareActionOutputFile | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionOutputFile | cdktn.IResolvable | undefined);
    private _fileLocation?;
    get fileLocation(): string;
    set fileLocation(value: string);
    resetFileLocation(): void;
    get fileLocationInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionCompareActionOutput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#file ApptestTestCase#file}
    */
    readonly file?: ApptestTestCaseStepsActionCompareActionOutputFile;
}
export declare function apptestTestCaseStepsActionCompareActionOutputToTerraform(struct?: ApptestTestCaseStepsActionCompareActionOutput | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionOutputToHclTerraform(struct?: ApptestTestCaseStepsActionCompareActionOutput | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareActionOutput | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareActionOutput | cdktn.IResolvable | undefined);
    private _file;
    get file(): ApptestTestCaseStepsActionCompareActionOutputFileOutputReference;
    putFile(value: ApptestTestCaseStepsActionCompareActionOutputFile): void;
    resetFile(): void;
    get fileInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionOutputFile | undefined;
}
export interface ApptestTestCaseStepsActionCompareAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#input ApptestTestCase#input}
    */
    readonly input?: ApptestTestCaseStepsActionCompareActionInput;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#output ApptestTestCase#output}
    */
    readonly output?: ApptestTestCaseStepsActionCompareActionOutput;
}
export declare function apptestTestCaseStepsActionCompareActionToTerraform(struct?: ApptestTestCaseStepsActionCompareAction | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionCompareActionToHclTerraform(struct?: ApptestTestCaseStepsActionCompareAction | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionCompareActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionCompareAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionCompareAction | cdktn.IResolvable | undefined);
    private _input;
    get input(): ApptestTestCaseStepsActionCompareActionInputOutputReference;
    putInput(value: ApptestTestCaseStepsActionCompareActionInput): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionInput | undefined;
    private _output;
    get output(): ApptestTestCaseStepsActionCompareActionOutputOutputReference;
    putOutput(value: ApptestTestCaseStepsActionCompareActionOutput): void;
    resetOutput(): void;
    get outputInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareActionOutput | undefined;
}
export interface ApptestTestCaseStepsActionMainframeActionActionTypeBatch {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#batch_job_name ApptestTestCase#batch_job_name}
    */
    readonly batchJobName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#batch_job_parameters ApptestTestCase#batch_job_parameters}
    */
    readonly batchJobParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#export_data_set_names ApptestTestCase#export_data_set_names}
    */
    readonly exportDataSetNames?: string[];
}
export declare function apptestTestCaseStepsActionMainframeActionActionTypeBatchToTerraform(struct?: ApptestTestCaseStepsActionMainframeActionActionTypeBatch | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionMainframeActionActionTypeBatchToHclTerraform(struct?: ApptestTestCaseStepsActionMainframeActionActionTypeBatch | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionMainframeActionActionTypeBatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionMainframeActionActionTypeBatch | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionMainframeActionActionTypeBatch | cdktn.IResolvable | undefined);
    private _batchJobName?;
    get batchJobName(): string;
    set batchJobName(value: string);
    resetBatchJobName(): void;
    get batchJobNameInput(): string | undefined;
    private _batchJobParameters?;
    get batchJobParameters(): {
        [key: string]: string;
    };
    set batchJobParameters(value: {
        [key: string]: string;
    });
    resetBatchJobParameters(): void;
    get batchJobParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _exportDataSetNames?;
    get exportDataSetNames(): string[];
    set exportDataSetNames(value: string[]);
    resetExportDataSetNames(): void;
    get exportDataSetNamesInput(): string[] | undefined;
}
export interface ApptestTestCaseStepsActionMainframeActionActionTypeTn3270Script {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#script_location ApptestTestCase#script_location}
    */
    readonly scriptLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#type ApptestTestCase#type}
    */
    readonly type?: string;
}
export declare function apptestTestCaseStepsActionMainframeActionActionTypeTn3270ScriptToTerraform(struct?: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270Script | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionMainframeActionActionTypeTn3270ScriptToHclTerraform(struct?: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270Script | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionMainframeActionActionTypeTn3270ScriptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionMainframeActionActionTypeTn3270Script | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270Script | cdktn.IResolvable | undefined);
    private _scriptLocation?;
    get scriptLocation(): string;
    set scriptLocation(value: string);
    resetScriptLocation(): void;
    get scriptLocationInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionMainframeActionActionTypeTn3270 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#export_data_set_names ApptestTestCase#export_data_set_names}
    */
    readonly exportDataSetNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#script ApptestTestCase#script}
    */
    readonly script?: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270Script;
}
export declare function apptestTestCaseStepsActionMainframeActionActionTypeTn3270ToTerraform(struct?: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270 | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionMainframeActionActionTypeTn3270ToHclTerraform(struct?: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270 | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionMainframeActionActionTypeTn3270OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionMainframeActionActionTypeTn3270 | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270 | cdktn.IResolvable | undefined);
    private _exportDataSetNames?;
    get exportDataSetNames(): string[];
    set exportDataSetNames(value: string[]);
    resetExportDataSetNames(): void;
    get exportDataSetNamesInput(): string[] | undefined;
    private _script;
    get script(): ApptestTestCaseStepsActionMainframeActionActionTypeTn3270ScriptOutputReference;
    putScript(value: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270Script): void;
    resetScript(): void;
    get scriptInput(): cdktn.IResolvable | ApptestTestCaseStepsActionMainframeActionActionTypeTn3270Script | undefined;
}
export interface ApptestTestCaseStepsActionMainframeActionActionType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#batch ApptestTestCase#batch}
    */
    readonly batch?: ApptestTestCaseStepsActionMainframeActionActionTypeBatch;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#tn_3270 ApptestTestCase#tn_3270}
    */
    readonly tn3270?: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270;
}
export declare function apptestTestCaseStepsActionMainframeActionActionTypeToTerraform(struct?: ApptestTestCaseStepsActionMainframeActionActionType | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionMainframeActionActionTypeToHclTerraform(struct?: ApptestTestCaseStepsActionMainframeActionActionType | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionMainframeActionActionTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionMainframeActionActionType | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionMainframeActionActionType | cdktn.IResolvable | undefined);
    private _batch;
    get batch(): ApptestTestCaseStepsActionMainframeActionActionTypeBatchOutputReference;
    putBatch(value: ApptestTestCaseStepsActionMainframeActionActionTypeBatch): void;
    resetBatch(): void;
    get batchInput(): cdktn.IResolvable | ApptestTestCaseStepsActionMainframeActionActionTypeBatch | undefined;
    private _tn3270;
    get tn3270(): ApptestTestCaseStepsActionMainframeActionActionTypeTn3270OutputReference;
    putTn3270(value: ApptestTestCaseStepsActionMainframeActionActionTypeTn3270): void;
    resetTn3270(): void;
    get tn3270Input(): cdktn.IResolvable | ApptestTestCaseStepsActionMainframeActionActionTypeTn3270 | undefined;
}
export interface ApptestTestCaseStepsActionMainframeActionProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#dms_task_arn ApptestTestCase#dms_task_arn}
    */
    readonly dmsTaskArn?: string;
}
export declare function apptestTestCaseStepsActionMainframeActionPropertiesToTerraform(struct?: ApptestTestCaseStepsActionMainframeActionProperties | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionMainframeActionPropertiesToHclTerraform(struct?: ApptestTestCaseStepsActionMainframeActionProperties | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionMainframeActionPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionMainframeActionProperties | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionMainframeActionProperties | cdktn.IResolvable | undefined);
    private _dmsTaskArn?;
    get dmsTaskArn(): string;
    set dmsTaskArn(value: string);
    resetDmsTaskArn(): void;
    get dmsTaskArnInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionMainframeAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#action_type ApptestTestCase#action_type}
    */
    readonly actionType?: ApptestTestCaseStepsActionMainframeActionActionType;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#properties ApptestTestCase#properties}
    */
    readonly properties?: ApptestTestCaseStepsActionMainframeActionProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#resource ApptestTestCase#resource}
    */
    readonly resource?: string;
}
export declare function apptestTestCaseStepsActionMainframeActionToTerraform(struct?: ApptestTestCaseStepsActionMainframeAction | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionMainframeActionToHclTerraform(struct?: ApptestTestCaseStepsActionMainframeAction | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionMainframeActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionMainframeAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionMainframeAction | cdktn.IResolvable | undefined);
    private _actionType;
    get actionType(): ApptestTestCaseStepsActionMainframeActionActionTypeOutputReference;
    putActionType(value: ApptestTestCaseStepsActionMainframeActionActionType): void;
    resetActionType(): void;
    get actionTypeInput(): cdktn.IResolvable | ApptestTestCaseStepsActionMainframeActionActionType | undefined;
    private _properties;
    get properties(): ApptestTestCaseStepsActionMainframeActionPropertiesOutputReference;
    putProperties(value: ApptestTestCaseStepsActionMainframeActionProperties): void;
    resetProperties(): void;
    get propertiesInput(): cdktn.IResolvable | ApptestTestCaseStepsActionMainframeActionProperties | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionResourceActionCloudformationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#action_type ApptestTestCase#action_type}
    */
    readonly actionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#resource ApptestTestCase#resource}
    */
    readonly resource?: string;
}
export declare function apptestTestCaseStepsActionResourceActionCloudformationActionToTerraform(struct?: ApptestTestCaseStepsActionResourceActionCloudformationAction | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionResourceActionCloudformationActionToHclTerraform(struct?: ApptestTestCaseStepsActionResourceActionCloudformationAction | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionResourceActionCloudformationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionResourceActionCloudformationAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionResourceActionCloudformationAction | cdktn.IResolvable | undefined);
    private _actionType?;
    get actionType(): string;
    set actionType(value: string);
    resetActionType(): void;
    get actionTypeInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#force_stop ApptestTestCase#force_stop}
    */
    readonly forceStop?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#import_data_set_location ApptestTestCase#import_data_set_location}
    */
    readonly importDataSetLocation?: string;
}
export declare function apptestTestCaseStepsActionResourceActionM2ManagedApplicationActionPropertiesToTerraform(struct?: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionProperties | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionResourceActionM2ManagedApplicationActionPropertiesToHclTerraform(struct?: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionProperties | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionProperties | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionProperties | cdktn.IResolvable | undefined);
    private _forceStop?;
    get forceStop(): boolean | cdktn.IResolvable;
    set forceStop(value: boolean | cdktn.IResolvable);
    resetForceStop(): void;
    get forceStopInput(): boolean | cdktn.IResolvable | undefined;
    private _importDataSetLocation?;
    get importDataSetLocation(): string;
    set importDataSetLocation(value: string);
    resetImportDataSetLocation(): void;
    get importDataSetLocationInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionResourceActionM2ManagedApplicationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#action_type ApptestTestCase#action_type}
    */
    readonly actionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#properties ApptestTestCase#properties}
    */
    readonly properties?: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#resource ApptestTestCase#resource}
    */
    readonly resource?: string;
}
export declare function apptestTestCaseStepsActionResourceActionM2ManagedApplicationActionToTerraform(struct?: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationAction | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionResourceActionM2ManagedApplicationActionToHclTerraform(struct?: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationAction | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionResourceActionM2ManagedApplicationAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationAction | cdktn.IResolvable | undefined);
    private _actionType?;
    get actionType(): string;
    set actionType(value: string);
    resetActionType(): void;
    get actionTypeInput(): string | undefined;
    private _properties;
    get properties(): ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionPropertiesOutputReference;
    putProperties(value: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionProperties): void;
    resetProperties(): void;
    get propertiesInput(): cdktn.IResolvable | ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionProperties | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#action_type ApptestTestCase#action_type}
    */
    readonly actionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#resource ApptestTestCase#resource}
    */
    readonly resource?: string;
}
export declare function apptestTestCaseStepsActionResourceActionM2NonManagedApplicationActionToTerraform(struct?: ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationAction | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionResourceActionM2NonManagedApplicationActionToHclTerraform(struct?: ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationAction | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationAction | cdktn.IResolvable | undefined);
    private _actionType?;
    get actionType(): string;
    set actionType(value: string);
    resetActionType(): void;
    get actionTypeInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
}
export interface ApptestTestCaseStepsActionResourceAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#cloudformation_action ApptestTestCase#cloudformation_action}
    */
    readonly cloudformationAction?: ApptestTestCaseStepsActionResourceActionCloudformationAction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#m2_managed_application_action ApptestTestCase#m2_managed_application_action}
    */
    readonly m2ManagedApplicationAction?: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationAction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#m2_non_managed_application_action ApptestTestCase#m2_non_managed_application_action}
    */
    readonly m2NonManagedApplicationAction?: ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationAction;
}
export declare function apptestTestCaseStepsActionResourceActionToTerraform(struct?: ApptestTestCaseStepsActionResourceAction | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionResourceActionToHclTerraform(struct?: ApptestTestCaseStepsActionResourceAction | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionResourceActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsActionResourceAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsActionResourceAction | cdktn.IResolvable | undefined);
    private _cloudformationAction;
    get cloudformationAction(): ApptestTestCaseStepsActionResourceActionCloudformationActionOutputReference;
    putCloudformationAction(value: ApptestTestCaseStepsActionResourceActionCloudformationAction): void;
    resetCloudformationAction(): void;
    get cloudformationActionInput(): cdktn.IResolvable | ApptestTestCaseStepsActionResourceActionCloudformationAction | undefined;
    private _m2ManagedApplicationAction;
    get m2ManagedApplicationAction(): ApptestTestCaseStepsActionResourceActionM2ManagedApplicationActionOutputReference;
    putM2ManagedApplicationAction(value: ApptestTestCaseStepsActionResourceActionM2ManagedApplicationAction): void;
    resetM2ManagedApplicationAction(): void;
    get m2ManagedApplicationActionInput(): cdktn.IResolvable | ApptestTestCaseStepsActionResourceActionM2ManagedApplicationAction | undefined;
    private _m2NonManagedApplicationAction;
    get m2NonManagedApplicationAction(): ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationActionOutputReference;
    putM2NonManagedApplicationAction(value: ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationAction): void;
    resetM2NonManagedApplicationAction(): void;
    get m2NonManagedApplicationActionInput(): cdktn.IResolvable | ApptestTestCaseStepsActionResourceActionM2NonManagedApplicationAction | undefined;
}
export interface ApptestTestCaseStepsAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#compare_action ApptestTestCase#compare_action}
    */
    readonly compareAction?: ApptestTestCaseStepsActionCompareAction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#mainframe_action ApptestTestCase#mainframe_action}
    */
    readonly mainframeAction?: ApptestTestCaseStepsActionMainframeAction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#resource_action ApptestTestCase#resource_action}
    */
    readonly resourceAction?: ApptestTestCaseStepsActionResourceAction;
}
export declare function apptestTestCaseStepsActionToTerraform(struct?: ApptestTestCaseStepsAction | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsActionToHclTerraform(struct?: ApptestTestCaseStepsAction | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApptestTestCaseStepsAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseStepsAction | cdktn.IResolvable | undefined);
    private _compareAction;
    get compareAction(): ApptestTestCaseStepsActionCompareActionOutputReference;
    putCompareAction(value: ApptestTestCaseStepsActionCompareAction): void;
    resetCompareAction(): void;
    get compareActionInput(): cdktn.IResolvable | ApptestTestCaseStepsActionCompareAction | undefined;
    private _mainframeAction;
    get mainframeAction(): ApptestTestCaseStepsActionMainframeActionOutputReference;
    putMainframeAction(value: ApptestTestCaseStepsActionMainframeAction): void;
    resetMainframeAction(): void;
    get mainframeActionInput(): cdktn.IResolvable | ApptestTestCaseStepsActionMainframeAction | undefined;
    private _resourceAction;
    get resourceAction(): ApptestTestCaseStepsActionResourceActionOutputReference;
    putResourceAction(value: ApptestTestCaseStepsActionResourceAction): void;
    resetResourceAction(): void;
    get resourceActionInput(): cdktn.IResolvable | ApptestTestCaseStepsActionResourceAction | undefined;
}
export interface ApptestTestCaseSteps {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#action ApptestTestCase#action}
    */
    readonly action: ApptestTestCaseStepsAction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#description ApptestTestCase#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#name ApptestTestCase#name}
    */
    readonly name: string;
}
export declare function apptestTestCaseStepsToTerraform(struct?: ApptestTestCaseSteps | cdktn.IResolvable): any;
export declare function apptestTestCaseStepsToHclTerraform(struct?: ApptestTestCaseSteps | cdktn.IResolvable): any;
export declare class ApptestTestCaseStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApptestTestCaseSteps | cdktn.IResolvable | undefined;
    set internalValue(value: ApptestTestCaseSteps | cdktn.IResolvable | undefined);
    private _action;
    get action(): ApptestTestCaseStepsActionOutputReference;
    putAction(value: ApptestTestCaseStepsAction): void;
    get actionInput(): cdktn.IResolvable | ApptestTestCaseStepsAction | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ApptestTestCaseStepsList extends cdktn.ComplexList {
    internalValue?: ApptestTestCaseSteps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApptestTestCaseStepsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case awscc_apptest_test_case}
*/
export declare class ApptestTestCase extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apptest_test_case";
    /**
    * Generates CDKTN code for importing a ApptestTestCase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApptestTestCase to import
    * @param importFromId The id of the existing ApptestTestCase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApptestTestCase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apptest_test_case awscc_apptest_test_case} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApptestTestCaseConfig
    */
    constructor(scope: Construct, id: string, config: ApptestTestCaseConfig);
    get creationTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastUpdateTime(): string;
    private _latestVersion;
    get latestVersion(): ApptestTestCaseLatestVersionOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _steps;
    get steps(): ApptestTestCaseStepsList;
    putSteps(value: ApptestTestCaseSteps[] | cdktn.IResolvable): void;
    get stepsInput(): cdktn.IResolvable | ApptestTestCaseSteps[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get testCaseArn(): string;
    get testCaseId(): string;
    get testCaseVersion(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
