/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreCapacityProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The capacity configuration for the capacity provider. Defines the compute resources for this capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#compute_configuration BedrockagentcoreCapacityProvider#compute_configuration}
    */
    readonly computeConfiguration: BedrockagentcoreCapacityProviderComputeConfiguration;
    /**
    * An optional description of the capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#description BedrockagentcoreCapacityProvider#description}
    */
    readonly description?: string;
    /**
    * The name of the capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#name BedrockagentcoreCapacityProvider#name}
    */
    readonly name: string;
    /**
    * Configuration for permissions associated with a capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#permissions_configuration BedrockagentcoreCapacityProvider#permissions_configuration}
    */
    readonly permissionsConfiguration: BedrockagentcoreCapacityProviderPermissionsConfiguration;
    /**
    * An array of key-value pairs to apply to the capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#tags BedrockagentcoreCapacityProvider#tags}
    */
    readonly tags?: BedrockagentcoreCapacityProviderTags[] | cdktn.IResolvable;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTarget {
    /**
    * The ID of the Capacity Reservation in which to run the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#capacity_reservation_id BedrockagentcoreCapacityProvider#capacity_reservation_id}
    */
    readonly capacityReservationId?: string;
    /**
    * The ARN of the Capacity Reservation resource group in which to run the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#capacity_reservation_resource_group_arn BedrockagentcoreCapacityProvider#capacity_reservation_resource_group_arn}
    */
    readonly capacityReservationResourceGroupArn?: string;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTargetToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTarget | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTargetToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTarget | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTarget | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTarget | cdktn.IResolvable | undefined);
    private _capacityReservationId?;
    get capacityReservationId(): string;
    set capacityReservationId(value: string);
    resetCapacityReservationId(): void;
    get capacityReservationIdInput(): string | undefined;
    private _capacityReservationResourceGroupArn?;
    get capacityReservationResourceGroupArn(): string;
    set capacityReservationResourceGroupArn(value: string);
    resetCapacityReservationResourceGroupArn(): void;
    get capacityReservationResourceGroupArnInput(): string | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecification {
    /**
    * Indicates the instance's Capacity Reservation preferences.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#capacity_reservation_preference BedrockagentcoreCapacityProvider#capacity_reservation_preference}
    */
    readonly capacityReservationPreference?: string;
    /**
    * Information about the target Capacity Reservation or Capacity Reservation group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#capacity_reservation_target BedrockagentcoreCapacityProvider#capacity_reservation_target}
    */
    readonly capacityReservationTarget?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTarget;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecification | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecification | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecification | cdktn.IResolvable | undefined);
    private _capacityReservationPreference?;
    get capacityReservationPreference(): string;
    set capacityReservationPreference(value: string);
    resetCapacityReservationPreference(): void;
    get capacityReservationPreferenceInput(): string | undefined;
    private _capacityReservationTarget;
    get capacityReservationTarget(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTargetOutputReference;
    putCapacityReservationTarget(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTarget): void;
    resetCapacityReservationTarget(): void;
    get capacityReservationTargetInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationCapacityReservationTarget | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbs {
    /**
    * The index of the EBS card. Applies to instances with multiple EBS cards.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#ebs_card_index BedrockagentcoreCapacityProvider#ebs_card_index}
    */
    readonly ebsCardIndex?: number;
    /**
    * Indicates whether the EBS volume is encrypted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#encrypted BedrockagentcoreCapacityProvider#encrypted}
    */
    readonly encrypted?: boolean | cdktn.IResolvable;
    /**
    * The number of I/O operations per second (IOPS).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#iops BedrockagentcoreCapacityProvider#iops}
    */
    readonly iops?: number;
    /**
    * Identifier of the customer managed KMS key to use for EBS encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#kms_key_id BedrockagentcoreCapacityProvider#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * The ID of the snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#snapshot_id BedrockagentcoreCapacityProvider#snapshot_id}
    */
    readonly snapshotId?: string;
    /**
    * The throughput to provision for a gp3 volume, in MiB/s.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#throughput BedrockagentcoreCapacityProvider#throughput}
    */
    readonly throughput?: number;
    /**
    * The rate at which the volume is initialized after creation, in MiB/s. Supported only for volumes created from snapshots. If the snapshot is enabled for fast snapshot restore and a volume initialization rate is also specified, the volume is initialized at the specified rate instead of by fast snapshot restore. Valid range: 100-300 MiB/s.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#volume_initialization_rate BedrockagentcoreCapacityProvider#volume_initialization_rate}
    */
    readonly volumeInitializationRate?: number;
    /**
    * The size of the volume, in GiBs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#volume_size BedrockagentcoreCapacityProvider#volume_size}
    */
    readonly volumeSize?: number;
    /**
    * The volume type. Defaults to gp3 if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#volume_type BedrockagentcoreCapacityProvider#volume_type}
    */
    readonly volumeType?: string;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbsToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbs | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbsToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbs | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbs | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbs | cdktn.IResolvable | undefined);
    private _ebsCardIndex?;
    get ebsCardIndex(): number;
    set ebsCardIndex(value: number);
    resetEbsCardIndex(): void;
    get ebsCardIndexInput(): number | undefined;
    private _encrypted?;
    get encrypted(): boolean | cdktn.IResolvable;
    set encrypted(value: boolean | cdktn.IResolvable);
    resetEncrypted(): void;
    get encryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _iops?;
    get iops(): number;
    set iops(value: number);
    resetIops(): void;
    get iopsInput(): number | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    resetSnapshotId(): void;
    get snapshotIdInput(): string | undefined;
    private _throughput?;
    get throughput(): number;
    set throughput(value: number);
    resetThroughput(): void;
    get throughputInput(): number | undefined;
    private _volumeInitializationRate?;
    get volumeInitializationRate(): number;
    set volumeInitializationRate(value: number);
    resetVolumeInitializationRate(): void;
    get volumeInitializationRateInput(): number | undefined;
    private _volumeSize?;
    get volumeSize(): number;
    set volumeSize(value: number);
    resetVolumeSize(): void;
    get volumeSizeInput(): number | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes {
    /**
    * The device name (for example, /dev/sdh or xvdh).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#device_name BedrockagentcoreCapacityProvider#device_name}
    */
    readonly deviceName?: string;
    /**
    * Parameters used to automatically set up EBS volumes when the instance is launched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#ebs BedrockagentcoreCapacityProvider#ebs}
    */
    readonly ebs?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbs;
    /**
    * The virtual device name (ephemeralN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#virtual_name BedrockagentcoreCapacityProvider#virtual_name}
    */
    readonly virtualName?: string;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes | cdktn.IResolvable | undefined);
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _ebs;
    get ebs(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbsOutputReference;
    putEbs(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbs): void;
    resetEbs(): void;
    get ebsInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesEbs | undefined;
    private _virtualName?;
    get virtualName(): string;
    set virtualName(value: string);
    resetVirtualName(): void;
    get virtualNameInput(): string | undefined;
}
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesOutputReference;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirements {
    /**
    * List of allowed instance types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#allowed_instance_types BedrockagentcoreCapacityProvider#allowed_instance_types}
    */
    readonly allowedInstanceTypes: string[];
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirementsToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirements | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirementsToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirements | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirements | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirements | cdktn.IResolvable | undefined);
    private _allowedInstanceTypes?;
    get allowedInstanceTypes(): string[];
    set allowedInstanceTypes(value: string[]);
    get allowedInstanceTypesInput(): string[] | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications {
    /**
    * The ARN of the license configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#license_configuration_arn BedrockagentcoreCapacityProvider#license_configuration_arn}
    */
    readonly licenseConfigurationArn?: string;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecificationsToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecificationsToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications | cdktn.IResolvable | undefined);
    private _licenseConfigurationArn?;
    get licenseConfigurationArn(): string;
    set licenseConfigurationArn(value: string);
    resetLicenseConfigurationArn(): void;
    get licenseConfigurationArnInput(): string | undefined;
}
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecificationsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecificationsOutputReference;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParameters {
    /**
    * The Capacity Reservation targeting option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#capacity_reservation_specification BedrockagentcoreCapacityProvider#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecification;
    /**
    * The block device mapping for ephemeral (instance store) volumes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#ephemeral_volumes BedrockagentcoreCapacityProvider#ephemeral_volumes}
    */
    readonly ephemeralVolumes?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes[] | cdktn.IResolvable;
    /**
    * The ARN of the IAM instance profile to associate with launched instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#instance_profile_arn BedrockagentcoreCapacityProvider#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Requirements for EC2 instance types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#instance_requirements BedrockagentcoreCapacityProvider#instance_requirements}
    */
    readonly instanceRequirements: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirements;
    /**
    * The license configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#license_specifications BedrockagentcoreCapacityProvider#license_specifications}
    */
    readonly licenseSpecifications?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications[] | cdktn.IResolvable;
    /**
    * The monitoring level for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#monitoring BedrockagentcoreCapacityProvider#monitoring}
    */
    readonly monitoring?: string;
    /**
    * The operating system and CPU architecture for the instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#operating_system BedrockagentcoreCapacityProvider#operating_system}
    */
    readonly operatingSystem: string;
    /**
    * Tags to apply to all EC2 resources (instances, volumes, and network interfaces) created by this capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#propagated_tags BedrockagentcoreCapacityProvider#propagated_tags}
    */
    readonly propagatedTags?: {
        [key: string]: string;
    };
    /**
    * The name of the SSH key pair to configure on instances for SSH connectivity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#ssh_key_name BedrockagentcoreCapacityProvider#ssh_key_name}
    */
    readonly sshKeyName?: string;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParameters | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParameters | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParameters | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParameters | cdktn.IResolvable | undefined);
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecificationOutputReference;
    putCapacityReservationSpecification(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecification): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersCapacityReservationSpecification | undefined;
    private _ephemeralVolumes;
    get ephemeralVolumes(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumesList;
    putEphemeralVolumes(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes[] | cdktn.IResolvable): void;
    resetEphemeralVolumes(): void;
    get ephemeralVolumesInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersEphemeralVolumes[] | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _instanceRequirements;
    get instanceRequirements(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirementsOutputReference;
    putInstanceRequirements(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirements): void;
    get instanceRequirementsInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersInstanceRequirements | undefined;
    private _licenseSpecifications;
    get licenseSpecifications(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecificationsList;
    putLicenseSpecifications(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications[] | cdktn.IResolvable): void;
    resetLicenseSpecifications(): void;
    get licenseSpecificationsInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersLicenseSpecifications[] | undefined;
    private _monitoring?;
    get monitoring(): string;
    set monitoring(value: string);
    resetMonitoring(): void;
    get monitoringInput(): string | undefined;
    private _operatingSystem?;
    get operatingSystem(): string;
    set operatingSystem(value: string);
    get operatingSystemInput(): string | undefined;
    private _propagatedTags?;
    get propagatedTags(): {
        [key: string]: string;
    };
    set propagatedTags(value: {
        [key: string]: string;
    });
    resetPropagatedTags(): void;
    get propagatedTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _sshKeyName?;
    get sshKeyName(): string;
    set sshKeyName(value: string);
    resetSshKeyName(): void;
    get sshKeyNameInput(): string | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSource {
    /**
    * Parameters for launching EC2 instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#launch_parameters BedrockagentcoreCapacityProvider#launch_parameters}
    */
    readonly launchParameters: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParameters;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSource | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSource | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSource | cdktn.IResolvable | undefined);
    private _launchParameters;
    get launchParameters(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParametersOutputReference;
    putLaunchParameters(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParameters): void;
    get launchParametersInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceLaunchParameters | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfiguration {
    /**
    * The number of seconds an instance can remain idle before it is stopped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#idle_instance_timeout BedrockagentcoreCapacityProvider#idle_instance_timeout}
    */
    readonly idleInstanceTimeout?: number;
    /**
    * Maximum lifetime for the instance in seconds. Once reached, instances will be automatically terminated regardless of activity. Default: 28800 seconds (8 hours). Maximum: 1209600 seconds (14 days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#max_lifetime BedrockagentcoreCapacityProvider#max_lifetime}
    */
    readonly maxLifetime?: number;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfigurationToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfigurationToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfiguration | cdktn.IResolvable | undefined);
    private _idleInstanceTimeout?;
    get idleInstanceTimeout(): number;
    set idleInstanceTimeout(value: number);
    resetIdleInstanceTimeout(): void;
    get idleInstanceTimeoutInput(): number | undefined;
    private _maxLifetime?;
    get maxLifetime(): number;
    set maxLifetime(value: number);
    resetMaxLifetime(): void;
    get maxLifetimeInput(): number | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolume {
    /**
    * Indicates whether the EBS volume is encrypted. Encrypted volumes can only be attached to instances that support Amazon EBS encryption. If you are creating a volume from a snapshot, you can't specify an encryption value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#encrypted BedrockagentcoreCapacityProvider#encrypted}
    */
    readonly encrypted?: boolean | cdktn.IResolvable;
    /**
    * The free space guaranteed on the root volume, in GiB. The service adds the operating system overhead on top of this value. Defaults to 8 GiB. The maximum is below the 65,536 GiB gp3 ceiling because the service adds the AMI size bucket on top of this value, and the resulting total must still be a provisionable gp3 volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#free_space_gi_b BedrockagentcoreCapacityProvider#free_space_gi_b}
    */
    readonly freeSpaceGiB?: number;
    /**
    * The number of IOPS to provision. Only valid for gp3, io1, and io2 volumes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#iops BedrockagentcoreCapacityProvider#iops}
    */
    readonly iops?: number;
    /**
    * Identifier of the customer managed KMS key to use for EBS encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#kms_key_id BedrockagentcoreCapacityProvider#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * The throughput to provision for a gp3 volume, in MiB/s. Valid range: 125-2000 MiB/s.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#throughput BedrockagentcoreCapacityProvider#throughput}
    */
    readonly throughput?: number;
    /**
    * The EBS volume type. Defaults to gp3 if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#volume_type BedrockagentcoreCapacityProvider#volume_type}
    */
    readonly volumeType?: string;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolumeToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolume | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolumeToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolume | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolume | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolume | cdktn.IResolvable | undefined);
    private _encrypted?;
    get encrypted(): boolean | cdktn.IResolvable;
    set encrypted(value: boolean | cdktn.IResolvable);
    resetEncrypted(): void;
    get encryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _freeSpaceGiB?;
    get freeSpaceGiB(): number;
    set freeSpaceGiB(value: number);
    resetFreeSpaceGiB(): void;
    get freeSpaceGiBInput(): number | undefined;
    private _iops?;
    get iops(): number;
    set iops(value: number);
    resetIops(): void;
    get iopsInput(): number | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _throughput?;
    get throughput(): number;
    set throughput(value: number);
    resetThroughput(): void;
    get throughputInput(): number | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfiguration {
    /**
    * Whether to encrypt the volume. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#encrypted BedrockagentcoreCapacityProvider#encrypted}
    */
    readonly encrypted?: boolean | cdktn.IResolvable;
    /**
    * The number of IOPS to provision. Only valid for gp3, io1, and io2 volumes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#iops BedrockagentcoreCapacityProvider#iops}
    */
    readonly iops?: number;
    /**
    * Identifier of the KMS key to use for encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#kms_key_id BedrockagentcoreCapacityProvider#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * The logical name of the volume, used to reference it when mounting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#name BedrockagentcoreCapacityProvider#name}
    */
    readonly name?: string;
    /**
    * The size of the volume in GiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#size_gi_b BedrockagentcoreCapacityProvider#size_gi_b}
    */
    readonly sizeGiB?: number;
    /**
    * Optional EBS snapshot ID to initialize the volume from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#snapshot_id BedrockagentcoreCapacityProvider#snapshot_id}
    */
    readonly snapshotId?: string;
    /**
    * The throughput in MiB/s. Only valid for gp3 volumes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#throughput BedrockagentcoreCapacityProvider#throughput}
    */
    readonly throughput?: number;
    /**
    * The EBS volume type. Defaults to gp3 if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#volume_type BedrockagentcoreCapacityProvider#volume_type}
    */
    readonly volumeType?: string;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfigurationToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfigurationToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfiguration | cdktn.IResolvable | undefined);
    private _encrypted?;
    get encrypted(): boolean | cdktn.IResolvable;
    set encrypted(value: boolean | cdktn.IResolvable);
    resetEncrypted(): void;
    get encryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _iops?;
    get iops(): number;
    set iops(value: number);
    resetIops(): void;
    get iopsInput(): number | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sizeGiB?;
    get sizeGiB(): number;
    set sizeGiB(value: number);
    resetSizeGiB(): void;
    get sizeGiBInput(): number | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    resetSnapshotId(): void;
    get snapshotIdInput(): string | undefined;
    private _throughput?;
    get throughput(): number;
    set throughput(value: number);
    resetThroughput(): void;
    get throughputInput(): number | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes {
    /**
    * Configuration for an EBS-backed persistent volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#ebs_configuration BedrockagentcoreCapacityProvider#ebs_configuration}
    */
    readonly ebsConfiguration?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfiguration;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes | cdktn.IResolvable | undefined);
    private _ebsConfiguration;
    get ebsConfiguration(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfigurationOutputReference;
    putEbsConfiguration(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfiguration): void;
    resetEbsConfiguration(): void;
    get ebsConfigurationInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesEbsConfiguration | undefined;
}
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesOutputReference;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfiguration {
    /**
    * The IDs of the security groups to associate with the instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#security_groups BedrockagentcoreCapacityProvider#security_groups}
    */
    readonly securityGroups: string[];
    /**
    * The IDs of the subnets in which to launch instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#subnets BedrockagentcoreCapacityProvider#subnets}
    */
    readonly subnets: string[];
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfigurationToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfigurationToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfiguration | cdktn.IResolvable | undefined);
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    get subnetsInput(): string[] | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfigurationEc2Configuration {
    /**
    * How the launch template is specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#launch_template_source BedrockagentcoreCapacityProvider#launch_template_source}
    */
    readonly launchTemplateSource: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSource;
    /**
    * Configuration for managing the lifecycle of instances in a capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#lifecycle_configuration BedrockagentcoreCapacityProvider#lifecycle_configuration}
    */
    readonly lifecycleConfiguration?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfiguration;
    /**
    * Customer-facing configuration for the (service-managed) root volume. The service provisions the root volume at its own AMI size estimate plus FreeSpaceGiB, and pins the visible free space to FreeSpaceGiB with a filler file, so the space you are guaranteed does not change as the underlying AMI grows. The device name and the delete-on-termination behavior are service-owned and are not configurable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#root_volume BedrockagentcoreCapacityProvider#root_volume}
    */
    readonly rootVolume?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolume;
    /**
    * Named persistent EBS volumes for this capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#volumes BedrockagentcoreCapacityProvider#volumes}
    */
    readonly volumes?: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes[] | cdktn.IResolvable;
    /**
    * VPC configuration for launching EC2 instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#vpc_configuration BedrockagentcoreCapacityProvider#vpc_configuration}
    */
    readonly vpcConfiguration: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfiguration;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2Configuration | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfigurationEc2Configuration | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfigurationEc2Configuration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2Configuration | cdktn.IResolvable | undefined);
    private _launchTemplateSource;
    get launchTemplateSource(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSourceOutputReference;
    putLaunchTemplateSource(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSource): void;
    get launchTemplateSourceInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLaunchTemplateSource | undefined;
    private _lifecycleConfiguration;
    get lifecycleConfiguration(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfigurationOutputReference;
    putLifecycleConfiguration(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfiguration): void;
    resetLifecycleConfiguration(): void;
    get lifecycleConfigurationInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationLifecycleConfiguration | undefined;
    private _rootVolume;
    get rootVolume(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolumeOutputReference;
    putRootVolume(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolume): void;
    resetRootVolume(): void;
    get rootVolumeInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationRootVolume | undefined;
    private _volumes;
    get volumes(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumesList;
    putVolumes(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVolumes[] | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfigurationOutputReference;
    putVpcConfiguration(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfiguration): void;
    get vpcConfigurationInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationVpcConfiguration | undefined;
}
export interface BedrockagentcoreCapacityProviderComputeConfiguration {
    /**
    * Configuration for EC2-based capacity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#ec_2_configuration BedrockagentcoreCapacityProvider#ec_2_configuration}
    */
    readonly ec2Configuration: BedrockagentcoreCapacityProviderComputeConfigurationEc2Configuration;
}
export declare function bedrockagentcoreCapacityProviderComputeConfigurationToTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderComputeConfigurationToHclTerraform(struct?: BedrockagentcoreCapacityProviderComputeConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderComputeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderComputeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderComputeConfiguration | cdktn.IResolvable | undefined);
    private _ec2Configuration;
    get ec2Configuration(): BedrockagentcoreCapacityProviderComputeConfigurationEc2ConfigurationOutputReference;
    putEc2Configuration(value: BedrockagentcoreCapacityProviderComputeConfigurationEc2Configuration): void;
    get ec2ConfigurationInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfigurationEc2Configuration | undefined;
}
export interface BedrockagentcoreCapacityProviderPermissionsConfiguration {
    /**
    * The ARN of the IAM role that operators use to manage the capacity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#capacity_provider_operator_role_arn BedrockagentcoreCapacityProvider#capacity_provider_operator_role_arn}
    */
    readonly capacityProviderOperatorRoleArn: string;
}
export declare function bedrockagentcoreCapacityProviderPermissionsConfigurationToTerraform(struct?: BedrockagentcoreCapacityProviderPermissionsConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderPermissionsConfigurationToHclTerraform(struct?: BedrockagentcoreCapacityProviderPermissionsConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderPermissionsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCapacityProviderPermissionsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderPermissionsConfiguration | cdktn.IResolvable | undefined);
    private _capacityProviderOperatorRoleArn?;
    get capacityProviderOperatorRoleArn(): string;
    set capacityProviderOperatorRoleArn(value: string);
    get capacityProviderOperatorRoleArnInput(): string | undefined;
}
export interface BedrockagentcoreCapacityProviderTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#key BedrockagentcoreCapacityProvider#key}
    */
    readonly key?: string;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#value BedrockagentcoreCapacityProvider#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcoreCapacityProviderTagsToTerraform(struct?: BedrockagentcoreCapacityProviderTags | cdktn.IResolvable): any;
export declare function bedrockagentcoreCapacityProviderTagsToHclTerraform(struct?: BedrockagentcoreCapacityProviderTags | cdktn.IResolvable): any;
export declare class BedrockagentcoreCapacityProviderTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCapacityProviderTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCapacityProviderTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcoreCapacityProviderTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCapacityProviderTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCapacityProviderTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider awscc_bedrockagentcore_capacity_provider}
*/
export declare class BedrockagentcoreCapacityProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_capacity_provider";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreCapacityProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreCapacityProvider to import
    * @param importFromId The id of the existing BedrockagentcoreCapacityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreCapacityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_capacity_provider awscc_bedrockagentcore_capacity_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreCapacityProviderConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreCapacityProviderConfig);
    get arn(): string;
    get capacityProviderId(): string;
    private _computeConfiguration;
    get computeConfiguration(): BedrockagentcoreCapacityProviderComputeConfigurationOutputReference;
    putComputeConfiguration(value: BedrockagentcoreCapacityProviderComputeConfiguration): void;
    get computeConfigurationInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderComputeConfiguration | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permissionsConfiguration;
    get permissionsConfiguration(): BedrockagentcoreCapacityProviderPermissionsConfigurationOutputReference;
    putPermissionsConfiguration(value: BedrockagentcoreCapacityProviderPermissionsConfiguration): void;
    get permissionsConfigurationInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderPermissionsConfiguration | undefined;
    get status(): string;
    private _tags;
    get tags(): BedrockagentcoreCapacityProviderTagsList;
    putTags(value: BedrockagentcoreCapacityProviderTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcoreCapacityProviderTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
