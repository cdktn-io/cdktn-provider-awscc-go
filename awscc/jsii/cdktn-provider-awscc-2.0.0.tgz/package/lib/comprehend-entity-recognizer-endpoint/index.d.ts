/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComprehendEntityRecognizerEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the IAM role that grants Amazon Comprehend read access to trained custom models encrypted with a customer managed key (ModelKmsKeyId).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#data_access_role_arn ComprehendEntityRecognizerEndpoint#data_access_role_arn}
    */
    readonly dataAccessRoleArn?: string;
    /**
    * The desired number of inference units to be used by the model. Each inference unit represents throughput of 100 characters per second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#desired_inference_units ComprehendEntityRecognizerEndpoint#desired_inference_units}
    */
    readonly desiredInferenceUnits: number;
    /**
    * The name of the endpoint. The name must be unique within the AWS Region and account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#endpoint_name ComprehendEntityRecognizerEndpoint#endpoint_name}
    */
    readonly endpointName: string;
    /**
    * The Amazon Resource Name (ARN) of the flywheel to which the endpoint is attached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#flywheel_arn ComprehendEntityRecognizerEndpoint#flywheel_arn}
    */
    readonly flywheelArn?: string;
    /**
    * The Amazon Resource Name (ARN) of the entity recognizer model to which the endpoint is attached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#model_arn ComprehendEntityRecognizerEndpoint#model_arn}
    */
    readonly modelArn?: string;
    /**
    * Tags associated with the endpoint being created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#tags ComprehendEntityRecognizerEndpoint#tags}
    */
    readonly tags?: ComprehendEntityRecognizerEndpointTags[] | cdktn.IResolvable;
}
export interface ComprehendEntityRecognizerEndpointTags {
    /**
    * The initial part of a key-value pair that forms a tag associated with a given resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#key ComprehendEntityRecognizerEndpoint#key}
    */
    readonly key?: string;
    /**
    * The second part of a key-value pair that forms a tag associated with a given resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#value ComprehendEntityRecognizerEndpoint#value}
    */
    readonly value?: string;
}
export declare function comprehendEntityRecognizerEndpointTagsToTerraform(struct?: ComprehendEntityRecognizerEndpointTags | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerEndpointTagsToHclTerraform(struct?: ComprehendEntityRecognizerEndpointTags | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerEndpointTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendEntityRecognizerEndpointTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerEndpointTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComprehendEntityRecognizerEndpointTagsList extends cdktn.ComplexList {
    internalValue?: ComprehendEntityRecognizerEndpointTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendEntityRecognizerEndpointTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint awscc_comprehend_entity_recognizer_endpoint}
*/
export declare class ComprehendEntityRecognizerEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_comprehend_entity_recognizer_endpoint";
    /**
    * Generates CDKTN code for importing a ComprehendEntityRecognizerEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComprehendEntityRecognizerEndpoint to import
    * @param importFromId The id of the existing ComprehendEntityRecognizerEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComprehendEntityRecognizerEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/comprehend_entity_recognizer_endpoint awscc_comprehend_entity_recognizer_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComprehendEntityRecognizerEndpointConfig
    */
    constructor(scope: Construct, id: string, config: ComprehendEntityRecognizerEndpointConfig);
    get arn(): string;
    get creationTime(): string;
    get currentInferenceUnits(): number;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    resetDataAccessRoleArn(): void;
    get dataAccessRoleArnInput(): string | undefined;
    private _desiredInferenceUnits?;
    get desiredInferenceUnits(): number;
    set desiredInferenceUnits(value: number);
    get desiredInferenceUnitsInput(): number | undefined;
    private _endpointName?;
    get endpointName(): string;
    set endpointName(value: string);
    get endpointNameInput(): string | undefined;
    get endpointStatus(): string;
    private _flywheelArn?;
    get flywheelArn(): string;
    set flywheelArn(value: string);
    resetFlywheelArn(): void;
    get flywheelArnInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): string;
    private _modelArn?;
    get modelArn(): string;
    set modelArn(value: string);
    resetModelArn(): void;
    get modelArnInput(): string | undefined;
    private _tags;
    get tags(): ComprehendEntityRecognizerEndpointTagsList;
    putTags(value: ComprehendEntityRecognizerEndpointTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ComprehendEntityRecognizerEndpointTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
