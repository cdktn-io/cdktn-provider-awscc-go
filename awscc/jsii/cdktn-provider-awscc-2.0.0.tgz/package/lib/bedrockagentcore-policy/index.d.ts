/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcorePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The definition structure for policies. Encapsulates different policy formats.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#definition BedrockagentcorePolicy#definition}
    */
    readonly definition: BedrockagentcorePolicyDefinition;
    /**
    * A human-readable description of the policy's purpose and functionality.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#description BedrockagentcorePolicy#description}
    */
    readonly description?: string;
    /**
    * Whether the policy contributes to the enforce decision returned to Gateway. LOG_ONLY policies are still evaluated but their decisions are observed only, allowing customers to validate a policy against real traffic before promoting it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#enforcement_mode BedrockagentcorePolicy#enforcement_mode}
    */
    readonly enforcementMode?: string;
    /**
    * The customer-assigned immutable name for the policy. Must be unique within the policy engine.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#name BedrockagentcorePolicy#name}
    */
    readonly name: string;
    /**
    * The identifier of the policy engine which contains this policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#policy_engine_id BedrockagentcorePolicy#policy_engine_id}
    */
    readonly policyEngineId: string;
    /**
    * The validation mode for the policy. Determines how Cedar analyzer validation results are handled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#validation_mode BedrockagentcorePolicy#validation_mode}
    */
    readonly validationMode?: string;
}
export interface BedrockagentcorePolicyDefinitionCedar {
    /**
    * The Cedar policy statement that defines the authorization logic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#statement BedrockagentcorePolicy#statement}
    */
    readonly statement?: string;
}
export declare function bedrockagentcorePolicyDefinitionCedarToTerraform(struct?: BedrockagentcorePolicyDefinitionCedar | cdktn.IResolvable): any;
export declare function bedrockagentcorePolicyDefinitionCedarToHclTerraform(struct?: BedrockagentcorePolicyDefinitionCedar | cdktn.IResolvable): any;
export declare class BedrockagentcorePolicyDefinitionCedarOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePolicyDefinitionCedar | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePolicyDefinitionCedar | cdktn.IResolvable | undefined);
    private _statement?;
    get statement(): string;
    set statement(value: string);
    resetStatement(): void;
    get statementInput(): string | undefined;
}
export interface BedrockagentcorePolicyDefinitionPolicy {
    /**
    * The policy statement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#statement BedrockagentcorePolicy#statement}
    */
    readonly statement?: string;
}
export declare function bedrockagentcorePolicyDefinitionPolicyToTerraform(struct?: BedrockagentcorePolicyDefinitionPolicy | cdktn.IResolvable): any;
export declare function bedrockagentcorePolicyDefinitionPolicyToHclTerraform(struct?: BedrockagentcorePolicyDefinitionPolicy | cdktn.IResolvable): any;
export declare class BedrockagentcorePolicyDefinitionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePolicyDefinitionPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePolicyDefinitionPolicy | cdktn.IResolvable | undefined);
    private _statement?;
    get statement(): string;
    set statement(value: string);
    resetStatement(): void;
    get statementInput(): string | undefined;
}
export interface BedrockagentcorePolicyDefinition {
    /**
    * A Cedar policy statement within the AgentCore Policy system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#cedar BedrockagentcorePolicy#cedar}
    */
    readonly cedar?: BedrockagentcorePolicyDefinitionCedar;
    /**
    * A policy statement within the AgentCore Policy system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#policy BedrockagentcorePolicy#policy}
    */
    readonly policy?: BedrockagentcorePolicyDefinitionPolicy;
}
export declare function bedrockagentcorePolicyDefinitionToTerraform(struct?: BedrockagentcorePolicyDefinition | cdktn.IResolvable): any;
export declare function bedrockagentcorePolicyDefinitionToHclTerraform(struct?: BedrockagentcorePolicyDefinition | cdktn.IResolvable): any;
export declare class BedrockagentcorePolicyDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePolicyDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePolicyDefinition | cdktn.IResolvable | undefined);
    private _cedar;
    get cedar(): BedrockagentcorePolicyDefinitionCedarOutputReference;
    putCedar(value: BedrockagentcorePolicyDefinitionCedar): void;
    resetCedar(): void;
    get cedarInput(): cdktn.IResolvable | BedrockagentcorePolicyDefinitionCedar | undefined;
    private _policy;
    get policy(): BedrockagentcorePolicyDefinitionPolicyOutputReference;
    putPolicy(value: BedrockagentcorePolicyDefinitionPolicy): void;
    resetPolicy(): void;
    get policyInput(): cdktn.IResolvable | BedrockagentcorePolicyDefinitionPolicy | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy awscc_bedrockagentcore_policy}
*/
export declare class BedrockagentcorePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_policy";
    /**
    * Generates CDKTN code for importing a BedrockagentcorePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcorePolicy to import
    * @param importFromId The id of the existing BedrockagentcorePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcorePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy awscc_bedrockagentcore_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcorePolicyConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcorePolicyConfig);
    get createdAt(): string;
    private _definition;
    get definition(): BedrockagentcorePolicyDefinitionOutputReference;
    putDefinition(value: BedrockagentcorePolicyDefinition): void;
    get definitionInput(): cdktn.IResolvable | BedrockagentcorePolicyDefinition | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enforcementMode?;
    get enforcementMode(): string;
    set enforcementMode(value: string);
    resetEnforcementMode(): void;
    get enforcementModeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyArn(): string;
    private _policyEngineId?;
    get policyEngineId(): string;
    set policyEngineId(value: string);
    get policyEngineIdInput(): string | undefined;
    get policyId(): string;
    get status(): string;
    get statusReasons(): string[];
    get updatedAt(): string;
    private _validationMode?;
    get validationMode(): string;
    set validationMode(value: string);
    resetValidationMode(): void;
    get validationModeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
