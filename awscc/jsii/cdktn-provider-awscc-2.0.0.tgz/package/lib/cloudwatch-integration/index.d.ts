/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Write-only API-key credential material for the integration. Stored encrypted and never returned on read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#credential CloudwatchIntegration#credential}
    */
    readonly credential?: CloudwatchIntegrationCredential;
    /**
    * Type-specific configuration attributes (max 50 entries). EXTERNAL_AGENT requires 'catalogId'. On update, supplied attributes merge into the existing map; omitting a key does not remove it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#integration_attributes CloudwatchIntegration#integration_attributes}
    */
    readonly integrationAttributes?: {
        [key: string]: string;
    };
    /**
    * The type of integration. Immutable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#integration_type CloudwatchIntegration#integration_type}
    */
    readonly integrationType: string;
    /**
    * The customer-supplied name of the integration. Unique per account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#name CloudwatchIntegration#name}
    */
    readonly name: string;
    /**
    * IAM role ARN the integration assumes. Required for AWS_INTEGRATION (a valid, service-assumable IAM role ARN). Not used by AWS_CONFIG_SLREC or EXTERNAL_AGENT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#role_arn CloudwatchIntegration#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Tags associated with the integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#tags CloudwatchIntegration#tags}
    */
    readonly tags?: CloudwatchIntegrationTags[] | cdktn.IResolvable;
}
export interface CloudwatchIntegrationCredentialApiKeyCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#api_key_value CloudwatchIntegration#api_key_value}
    */
    readonly apiKeyValue?: string;
}
export declare function cloudwatchIntegrationCredentialApiKeyCredentialToTerraform(struct?: CloudwatchIntegrationCredentialApiKeyCredential | cdktn.IResolvable): any;
export declare function cloudwatchIntegrationCredentialApiKeyCredentialToHclTerraform(struct?: CloudwatchIntegrationCredentialApiKeyCredential | cdktn.IResolvable): any;
export declare class CloudwatchIntegrationCredentialApiKeyCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchIntegrationCredentialApiKeyCredential | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchIntegrationCredentialApiKeyCredential | cdktn.IResolvable | undefined);
    private _apiKeyValue?;
    get apiKeyValue(): string;
    set apiKeyValue(value: string);
    resetApiKeyValue(): void;
    get apiKeyValueInput(): string | undefined;
}
export interface CloudwatchIntegrationCredential {
    /**
    * API-key credential material that can be rotated in place on update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#api_key_credential CloudwatchIntegration#api_key_credential}
    */
    readonly apiKeyCredential?: CloudwatchIntegrationCredentialApiKeyCredential;
}
export declare function cloudwatchIntegrationCredentialToTerraform(struct?: CloudwatchIntegrationCredential | cdktn.IResolvable): any;
export declare function cloudwatchIntegrationCredentialToHclTerraform(struct?: CloudwatchIntegrationCredential | cdktn.IResolvable): any;
export declare class CloudwatchIntegrationCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchIntegrationCredential | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchIntegrationCredential | cdktn.IResolvable | undefined);
    private _apiKeyCredential;
    get apiKeyCredential(): CloudwatchIntegrationCredentialApiKeyCredentialOutputReference;
    putApiKeyCredential(value: CloudwatchIntegrationCredentialApiKeyCredential): void;
    resetApiKeyCredential(): void;
    get apiKeyCredentialInput(): cdktn.IResolvable | CloudwatchIntegrationCredentialApiKeyCredential | undefined;
}
export interface CloudwatchIntegrationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#key CloudwatchIntegration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#value CloudwatchIntegration#value}
    */
    readonly value?: string;
}
export declare function cloudwatchIntegrationTagsToTerraform(struct?: CloudwatchIntegrationTags | cdktn.IResolvable): any;
export declare function cloudwatchIntegrationTagsToHclTerraform(struct?: CloudwatchIntegrationTags | cdktn.IResolvable): any;
export declare class CloudwatchIntegrationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchIntegrationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchIntegrationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchIntegrationTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchIntegrationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchIntegrationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration awscc_cloudwatch_integration}
*/
export declare class CloudwatchIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_integration";
    /**
    * Generates CDKTN code for importing a CloudwatchIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchIntegration to import
    * @param importFromId The id of the existing CloudwatchIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_integration awscc_cloudwatch_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchIntegrationConfig);
    get createdAt(): string;
    private _credential;
    get credential(): CloudwatchIntegrationCredentialOutputReference;
    putCredential(value: CloudwatchIntegrationCredential): void;
    resetCredential(): void;
    get credentialInput(): cdktn.IResolvable | CloudwatchIntegrationCredential | undefined;
    get id(): string;
    get integrationArn(): string;
    private _integrationAttributes?;
    get integrationAttributes(): {
        [key: string]: string;
    };
    set integrationAttributes(value: {
        [key: string]: string;
    });
    resetIntegrationAttributes(): void;
    get integrationAttributesInput(): {
        [key: string]: string;
    } | undefined;
    get integrationId(): string;
    private _integrationType?;
    get integrationType(): string;
    set integrationType(value: string);
    get integrationTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): CloudwatchIntegrationTagsList;
    putTags(value: CloudwatchIntegrationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchIntegrationTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
