/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#authorizer_configuration BedrockagentcoreGateway#authorizer_configuration}
    */
    readonly authorizerConfiguration?: BedrockagentcoreGatewayAuthorizerConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#authorizer_type BedrockagentcoreGateway#authorizer_type}
    */
    readonly authorizerType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#description BedrockagentcoreGateway#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#exception_level BedrockagentcoreGateway#exception_level}
    */
    readonly exceptionLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#interceptor_configurations BedrockagentcoreGateway#interceptor_configurations}
    */
    readonly interceptorConfigurations?: BedrockagentcoreGatewayInterceptorConfigurations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#kms_key_arn BedrockagentcoreGateway#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#name BedrockagentcoreGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#policy_engine_configuration BedrockagentcoreGateway#policy_engine_configuration}
    */
    readonly policyEngineConfiguration?: BedrockagentcoreGatewayPolicyEngineConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#protocol_configuration BedrockagentcoreGateway#protocol_configuration}
    */
    readonly protocolConfiguration?: BedrockagentcoreGatewayProtocolConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#protocol_type BedrockagentcoreGateway#protocol_type}
    */
    readonly protocolType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#role_arn BedrockagentcoreGateway#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#tags BedrockagentcoreGateway#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#waf_configuration BedrockagentcoreGateway#waf_configuration}
    */
    readonly wafConfiguration?: BedrockagentcoreGatewayWafConfiguration;
}
export interface BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#match_value_string BedrockagentcoreGateway#match_value_string}
    */
    readonly matchValueString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#match_value_string_list BedrockagentcoreGateway#match_value_string_list}
    */
    readonly matchValueStringList?: string[];
}
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToHclTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined);
    private _matchValueString?;
    get matchValueString(): string;
    set matchValueString(value: string);
    resetMatchValueString(): void;
    get matchValueStringInput(): string | undefined;
    private _matchValueStringList?;
    get matchValueStringList(): string[];
    set matchValueStringList(value: string[]);
    resetMatchValueStringList(): void;
    get matchValueStringListInput(): string[] | undefined;
}
export interface BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#claim_match_operator BedrockagentcoreGateway#claim_match_operator}
    */
    readonly claimMatchOperator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#claim_match_value BedrockagentcoreGateway#claim_match_value}
    */
    readonly claimMatchValue?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue;
}
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToHclTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined);
    private _claimMatchOperator?;
    get claimMatchOperator(): string;
    set claimMatchOperator(value: string);
    resetClaimMatchOperator(): void;
    get claimMatchOperatorInput(): string | undefined;
    private _claimMatchValue;
    get claimMatchValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference;
    putClaimMatchValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue): void;
    resetClaimMatchValue(): void;
    get claimMatchValueInput(): cdktn.IResolvable | BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | undefined;
}
export interface BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#authorizing_claim_match_value BedrockagentcoreGateway#authorizing_claim_match_value}
    */
    readonly authorizingClaimMatchValue?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#inbound_token_claim_name BedrockagentcoreGateway#inbound_token_claim_name}
    */
    readonly inboundTokenClaimName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#inbound_token_claim_value_type BedrockagentcoreGateway#inbound_token_claim_value_type}
    */
    readonly inboundTokenClaimValueType?: string;
}
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToHclTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined);
    private _authorizingClaimMatchValue;
    get authorizingClaimMatchValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference;
    putAuthorizingClaimMatchValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue): void;
    resetAuthorizingClaimMatchValue(): void;
    get authorizingClaimMatchValueInput(): cdktn.IResolvable | BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | undefined;
    private _inboundTokenClaimName?;
    get inboundTokenClaimName(): string;
    set inboundTokenClaimName(value: string);
    resetInboundTokenClaimName(): void;
    get inboundTokenClaimNameInput(): string | undefined;
    private _inboundTokenClaimValueType?;
    get inboundTokenClaimValueType(): string;
    set inboundTokenClaimValueType(value: string);
    resetInboundTokenClaimValueType(): void;
    get inboundTokenClaimValueTypeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference;
}
export interface BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#endpoint_ip_address_type BedrockagentcoreGateway#endpoint_ip_address_type}
    */
    readonly endpointIpAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#routing_domain BedrockagentcoreGateway#routing_domain}
    */
    readonly routingDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#security_group_ids BedrockagentcoreGateway#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#subnet_ids BedrockagentcoreGateway#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#tags BedrockagentcoreGateway#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#vpc_identifier BedrockagentcoreGateway#vpc_identifier}
    */
    readonly vpcIdentifier?: string;
}
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceToTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceToHclTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined);
    private _endpointIpAddressType?;
    get endpointIpAddressType(): string;
    set endpointIpAddressType(value: string);
    resetEndpointIpAddressType(): void;
    get endpointIpAddressTypeInput(): string | undefined;
    private _routingDomain?;
    get routingDomain(): string;
    set routingDomain(value: string);
    resetRoutingDomain(): void;
    get routingDomainInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdentifier?;
    get vpcIdentifier(): string;
    set vpcIdentifier(value: string);
    resetVpcIdentifier(): void;
    get vpcIdentifierInput(): string | undefined;
}
export interface BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#resource_configuration_identifier BedrockagentcoreGateway#resource_configuration_identifier}
    */
    readonly resourceConfigurationIdentifier?: string;
}
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceToTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceToHclTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined);
    private _resourceConfigurationIdentifier?;
    get resourceConfigurationIdentifier(): string;
    set resourceConfigurationIdentifier(value: string);
    resetResourceConfigurationIdentifier(): void;
    get resourceConfigurationIdentifierInput(): string | undefined;
}
export interface BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#managed_vpc_resource BedrockagentcoreGateway#managed_vpc_resource}
    */
    readonly managedVpcResource?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#self_managed_lattice_resource BedrockagentcoreGateway#self_managed_lattice_resource}
    */
    readonly selfManagedLatticeResource?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource;
}
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointToTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointToHclTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable | undefined);
    private _managedVpcResource;
    get managedVpcResource(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceOutputReference;
    putManagedVpcResource(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource): void;
    resetManagedVpcResource(): void;
    get managedVpcResourceInput(): cdktn.IResolvable | BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | undefined;
    private _selfManagedLatticeResource;
    get selfManagedLatticeResource(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceOutputReference;
    putSelfManagedLatticeResource(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource): void;
    resetSelfManagedLatticeResource(): void;
    get selfManagedLatticeResourceInput(): cdktn.IResolvable | BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | undefined;
}
export interface BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizer {
    /**
    * Maps an originalScope (from allowedScopes) to an advertisedScope
    * exposed in WWW-Authenticate / Protected Resource Metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#advertised_scope_mapping BedrockagentcoreGateway#advertised_scope_mapping}
    */
    readonly advertisedScopeMapping?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#allowed_audience BedrockagentcoreGateway#allowed_audience}
    */
    readonly allowedAudience?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#allowed_clients BedrockagentcoreGateway#allowed_clients}
    */
    readonly allowedClients?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#allowed_scopes BedrockagentcoreGateway#allowed_scopes}
    */
    readonly allowedScopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#custom_claims BedrockagentcoreGateway#custom_claims}
    */
    readonly customClaims?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#discovery_url BedrockagentcoreGateway#discovery_url}
    */
    readonly discoveryUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#private_endpoint BedrockagentcoreGateway#private_endpoint}
    */
    readonly privateEndpoint?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint;
}
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerToTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerToHclTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined);
    private _advertisedScopeMapping?;
    get advertisedScopeMapping(): {
        [key: string]: string;
    };
    set advertisedScopeMapping(value: {
        [key: string]: string;
    });
    resetAdvertisedScopeMapping(): void;
    get advertisedScopeMappingInput(): {
        [key: string]: string;
    } | undefined;
    private _allowedAudience?;
    get allowedAudience(): string[];
    set allowedAudience(value: string[]);
    resetAllowedAudience(): void;
    get allowedAudienceInput(): string[] | undefined;
    private _allowedClients?;
    get allowedClients(): string[];
    set allowedClients(value: string[]);
    resetAllowedClients(): void;
    get allowedClientsInput(): string[] | undefined;
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
    private _customClaims;
    get customClaims(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList;
    putCustomClaims(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable): void;
    resetCustomClaims(): void;
    get customClaimsInput(): cdktn.IResolvable | BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | undefined;
    private _discoveryUrl?;
    get discoveryUrl(): string;
    set discoveryUrl(value: string);
    resetDiscoveryUrl(): void;
    get discoveryUrlInput(): string | undefined;
    private _privateEndpoint;
    get privateEndpoint(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOutputReference;
    putPrivateEndpoint(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint): void;
    resetPrivateEndpoint(): void;
    get privateEndpointInput(): cdktn.IResolvable | BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | undefined;
}
export interface BedrockagentcoreGatewayAuthorizerConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#custom_jwt_authorizer BedrockagentcoreGateway#custom_jwt_authorizer}
    */
    readonly customJwtAuthorizer?: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizer;
}
export declare function bedrockagentcoreGatewayAuthorizerConfigurationToTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayAuthorizerConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayAuthorizerConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayAuthorizerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayAuthorizerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayAuthorizerConfiguration | cdktn.IResolvable | undefined);
    private _customJwtAuthorizer;
    get customJwtAuthorizer(): BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizerOutputReference;
    putCustomJwtAuthorizer(value: BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizer): void;
    resetCustomJwtAuthorizer(): void;
    get customJwtAuthorizerInput(): cdktn.IResolvable | BedrockagentcoreGatewayAuthorizerConfigurationCustomJwtAuthorizer | undefined;
}
export interface BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#field BedrockagentcoreGateway#field}
    */
    readonly field?: string;
}
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExcludeToTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExcludeToHclTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExcludeList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExcludeOutputReference;
}
export interface BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#exclude BedrockagentcoreGateway#exclude}
    */
    readonly exclude?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterToTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilter | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterToHclTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilter | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilter | cdktn.IResolvable | undefined);
    private _exclude;
    get exclude(): BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExcludeList;
    putExclude(value: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude[] | cdktn.IResolvable): void;
    resetExclude(): void;
    get excludeInput(): cdktn.IResolvable | BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterExclude[] | undefined;
}
export interface BedrockagentcoreGatewayInterceptorConfigurationsInputConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#pass_request_headers BedrockagentcoreGateway#pass_request_headers}
    */
    readonly passRequestHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#payload_filter BedrockagentcoreGateway#payload_filter}
    */
    readonly payloadFilter?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilter;
}
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationToTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayInterceptorConfigurationsInputConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayInterceptorConfigurationsInputConfiguration | cdktn.IResolvable | undefined);
    private _passRequestHeaders?;
    get passRequestHeaders(): boolean | cdktn.IResolvable;
    set passRequestHeaders(value: boolean | cdktn.IResolvable);
    resetPassRequestHeaders(): void;
    get passRequestHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _payloadFilter;
    get payloadFilter(): BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilterOutputReference;
    putPayloadFilter(value: BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilter): void;
    resetPayloadFilter(): void;
    get payloadFilterInput(): cdktn.IResolvable | BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationPayloadFilter | undefined;
}
export interface BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambda {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#arn BedrockagentcoreGateway#arn}
    */
    readonly arn?: string;
}
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambdaToTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambda | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambdaToHclTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambda | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambdaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambda | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambda | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
}
export interface BedrockagentcoreGatewayInterceptorConfigurationsInterceptor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#lambda BedrockagentcoreGateway#lambda}
    */
    readonly lambda?: BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambda;
}
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInterceptorToTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInterceptor | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayInterceptorConfigurationsInterceptorToHclTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurationsInterceptor | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayInterceptorConfigurationsInterceptorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayInterceptorConfigurationsInterceptor | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayInterceptorConfigurationsInterceptor | cdktn.IResolvable | undefined);
    private _lambda;
    get lambda(): BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambdaOutputReference;
    putLambda(value: BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambda): void;
    resetLambda(): void;
    get lambdaInput(): cdktn.IResolvable | BedrockagentcoreGatewayInterceptorConfigurationsInterceptorLambda | undefined;
}
export interface BedrockagentcoreGatewayInterceptorConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#input_configuration BedrockagentcoreGateway#input_configuration}
    */
    readonly inputConfiguration?: BedrockagentcoreGatewayInterceptorConfigurationsInputConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#interception_points BedrockagentcoreGateway#interception_points}
    */
    readonly interceptionPoints?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#interceptor BedrockagentcoreGateway#interceptor}
    */
    readonly interceptor?: BedrockagentcoreGatewayInterceptorConfigurationsInterceptor;
}
export declare function bedrockagentcoreGatewayInterceptorConfigurationsToTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurations | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayInterceptorConfigurationsToHclTerraform(struct?: BedrockagentcoreGatewayInterceptorConfigurations | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayInterceptorConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayInterceptorConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayInterceptorConfigurations | cdktn.IResolvable | undefined);
    private _inputConfiguration;
    get inputConfiguration(): BedrockagentcoreGatewayInterceptorConfigurationsInputConfigurationOutputReference;
    putInputConfiguration(value: BedrockagentcoreGatewayInterceptorConfigurationsInputConfiguration): void;
    resetInputConfiguration(): void;
    get inputConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayInterceptorConfigurationsInputConfiguration | undefined;
    private _interceptionPoints?;
    get interceptionPoints(): string[];
    set interceptionPoints(value: string[]);
    resetInterceptionPoints(): void;
    get interceptionPointsInput(): string[] | undefined;
    private _interceptor;
    get interceptor(): BedrockagentcoreGatewayInterceptorConfigurationsInterceptorOutputReference;
    putInterceptor(value: BedrockagentcoreGatewayInterceptorConfigurationsInterceptor): void;
    resetInterceptor(): void;
    get interceptorInput(): cdktn.IResolvable | BedrockagentcoreGatewayInterceptorConfigurationsInterceptor | undefined;
}
export declare class BedrockagentcoreGatewayInterceptorConfigurationsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayInterceptorConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayInterceptorConfigurationsOutputReference;
}
export interface BedrockagentcoreGatewayPolicyEngineConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#arn BedrockagentcoreGateway#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#mode BedrockagentcoreGateway#mode}
    */
    readonly mode?: string;
}
export declare function bedrockagentcoreGatewayPolicyEngineConfigurationToTerraform(struct?: BedrockagentcoreGatewayPolicyEngineConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayPolicyEngineConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayPolicyEngineConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayPolicyEngineConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayPolicyEngineConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayPolicyEngineConfiguration | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#session_timeout_in_seconds BedrockagentcoreGateway#session_timeout_in_seconds}
    */
    readonly sessionTimeoutInSeconds?: number;
}
export declare function bedrockagentcoreGatewayProtocolConfigurationMcpSessionConfigurationToTerraform(struct?: BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayProtocolConfigurationMcpSessionConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfiguration | cdktn.IResolvable | undefined);
    private _sessionTimeoutInSeconds?;
    get sessionTimeoutInSeconds(): number;
    set sessionTimeoutInSeconds(value: number);
    resetSessionTimeoutInSeconds(): void;
    get sessionTimeoutInSecondsInput(): number | undefined;
}
export interface BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#enable_response_streaming BedrockagentcoreGateway#enable_response_streaming}
    */
    readonly enableResponseStreaming?: boolean | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfigurationToTerraform(struct?: BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfiguration | cdktn.IResolvable | undefined);
    private _enableResponseStreaming?;
    get enableResponseStreaming(): boolean | cdktn.IResolvable;
    set enableResponseStreaming(value: boolean | cdktn.IResolvable);
    resetEnableResponseStreaming(): void;
    get enableResponseStreamingInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BedrockagentcoreGatewayProtocolConfigurationMcp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#instructions BedrockagentcoreGateway#instructions}
    */
    readonly instructions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#search_type BedrockagentcoreGateway#search_type}
    */
    readonly searchType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#session_configuration BedrockagentcoreGateway#session_configuration}
    */
    readonly sessionConfiguration?: BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#streaming_configuration BedrockagentcoreGateway#streaming_configuration}
    */
    readonly streamingConfiguration?: BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#supported_versions BedrockagentcoreGateway#supported_versions}
    */
    readonly supportedVersions?: string[];
}
export declare function bedrockagentcoreGatewayProtocolConfigurationMcpToTerraform(struct?: BedrockagentcoreGatewayProtocolConfigurationMcp | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayProtocolConfigurationMcpToHclTerraform(struct?: BedrockagentcoreGatewayProtocolConfigurationMcp | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayProtocolConfigurationMcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayProtocolConfigurationMcp | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayProtocolConfigurationMcp | cdktn.IResolvable | undefined);
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    resetInstructions(): void;
    get instructionsInput(): string | undefined;
    private _searchType?;
    get searchType(): string;
    set searchType(value: string);
    resetSearchType(): void;
    get searchTypeInput(): string | undefined;
    private _sessionConfiguration;
    get sessionConfiguration(): BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfigurationOutputReference;
    putSessionConfiguration(value: BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfiguration): void;
    resetSessionConfiguration(): void;
    get sessionConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayProtocolConfigurationMcpSessionConfiguration | undefined;
    private _streamingConfiguration;
    get streamingConfiguration(): BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfigurationOutputReference;
    putStreamingConfiguration(value: BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfiguration): void;
    resetStreamingConfiguration(): void;
    get streamingConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayProtocolConfigurationMcpStreamingConfiguration | undefined;
    private _supportedVersions?;
    get supportedVersions(): string[];
    set supportedVersions(value: string[]);
    resetSupportedVersions(): void;
    get supportedVersionsInput(): string[] | undefined;
}
export interface BedrockagentcoreGatewayProtocolConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#mcp BedrockagentcoreGateway#mcp}
    */
    readonly mcp?: BedrockagentcoreGatewayProtocolConfigurationMcp;
}
export declare function bedrockagentcoreGatewayProtocolConfigurationToTerraform(struct?: BedrockagentcoreGatewayProtocolConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayProtocolConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayProtocolConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayProtocolConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayProtocolConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayProtocolConfiguration | cdktn.IResolvable | undefined);
    private _mcp;
    get mcp(): BedrockagentcoreGatewayProtocolConfigurationMcpOutputReference;
    putMcp(value: BedrockagentcoreGatewayProtocolConfigurationMcp): void;
    resetMcp(): void;
    get mcpInput(): cdktn.IResolvable | BedrockagentcoreGatewayProtocolConfigurationMcp | undefined;
}
export interface BedrockagentcoreGatewayWafConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#failure_mode BedrockagentcoreGateway#failure_mode}
    */
    readonly failureMode?: string;
}
export declare function bedrockagentcoreGatewayWafConfigurationToTerraform(struct?: BedrockagentcoreGatewayWafConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayWafConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayWafConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayWafConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayWafConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayWafConfiguration | cdktn.IResolvable | undefined);
    private _failureMode?;
    get failureMode(): string;
    set failureMode(value: string);
    resetFailureMode(): void;
    get failureModeInput(): string | undefined;
}
export interface BedrockagentcoreGatewayWorkloadIdentityDetails {
}
export declare function bedrockagentcoreGatewayWorkloadIdentityDetailsToTerraform(struct?: BedrockagentcoreGatewayWorkloadIdentityDetails): any;
export declare function bedrockagentcoreGatewayWorkloadIdentityDetailsToHclTerraform(struct?: BedrockagentcoreGatewayWorkloadIdentityDetails): any;
export declare class BedrockagentcoreGatewayWorkloadIdentityDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayWorkloadIdentityDetails | undefined;
    set internalValue(value: BedrockagentcoreGatewayWorkloadIdentityDetails | undefined);
    get workloadIdentityArn(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway awscc_bedrockagentcore_gateway}
*/
export declare class BedrockagentcoreGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_gateway";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreGateway to import
    * @param importFromId The id of the existing BedrockagentcoreGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway awscc_bedrockagentcore_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreGatewayConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreGatewayConfig);
    private _authorizerConfiguration;
    get authorizerConfiguration(): BedrockagentcoreGatewayAuthorizerConfigurationOutputReference;
    putAuthorizerConfiguration(value: BedrockagentcoreGatewayAuthorizerConfiguration): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayAuthorizerConfiguration | undefined;
    private _authorizerType?;
    get authorizerType(): string;
    set authorizerType(value: string);
    get authorizerTypeInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _exceptionLevel?;
    get exceptionLevel(): string;
    set exceptionLevel(value: string);
    resetExceptionLevel(): void;
    get exceptionLevelInput(): string | undefined;
    get gatewayArn(): string;
    get gatewayIdentifier(): string;
    get gatewayUrl(): string;
    get id(): string;
    private _interceptorConfigurations;
    get interceptorConfigurations(): BedrockagentcoreGatewayInterceptorConfigurationsList;
    putInterceptorConfigurations(value: BedrockagentcoreGatewayInterceptorConfigurations[] | cdktn.IResolvable): void;
    resetInterceptorConfigurations(): void;
    get interceptorConfigurationsInput(): cdktn.IResolvable | BedrockagentcoreGatewayInterceptorConfigurations[] | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyEngineConfiguration;
    get policyEngineConfiguration(): BedrockagentcoreGatewayPolicyEngineConfigurationOutputReference;
    putPolicyEngineConfiguration(value: BedrockagentcoreGatewayPolicyEngineConfiguration): void;
    resetPolicyEngineConfiguration(): void;
    get policyEngineConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayPolicyEngineConfiguration | undefined;
    private _protocolConfiguration;
    get protocolConfiguration(): BedrockagentcoreGatewayProtocolConfigurationOutputReference;
    putProtocolConfiguration(value: BedrockagentcoreGatewayProtocolConfiguration): void;
    resetProtocolConfiguration(): void;
    get protocolConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayProtocolConfiguration | undefined;
    private _protocolType?;
    get protocolType(): string;
    set protocolType(value: string);
    resetProtocolType(): void;
    get protocolTypeInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    get statusReasons(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    private _wafConfiguration;
    get wafConfiguration(): BedrockagentcoreGatewayWafConfigurationOutputReference;
    putWafConfiguration(value: BedrockagentcoreGatewayWafConfiguration): void;
    resetWafConfiguration(): void;
    get wafConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayWafConfiguration | undefined;
    get webAclArn(): string;
    private _workloadIdentityDetails;
    get workloadIdentityDetails(): BedrockagentcoreGatewayWorkloadIdentityDetailsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
