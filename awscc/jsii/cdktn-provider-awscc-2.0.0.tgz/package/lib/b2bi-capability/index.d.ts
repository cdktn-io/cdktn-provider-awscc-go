/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface B2BiCapabilityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#configuration B2BiCapability#configuration}
    */
    readonly configuration: B2BiCapabilityConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#instructions_documents B2BiCapability#instructions_documents}
    */
    readonly instructionsDocuments?: B2BiCapabilityInstructionsDocuments[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#name B2BiCapability#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#tags B2BiCapability#tags}
    */
    readonly tags?: B2BiCapabilityTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#type B2BiCapability#type}
    */
    readonly type: string;
}
export interface B2BiCapabilityConfigurationEdiInputLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#bucket_name B2BiCapability#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#key B2BiCapability#key}
    */
    readonly key?: string;
}
export declare function b2BiCapabilityConfigurationEdiInputLocationToTerraform(struct?: B2BiCapabilityConfigurationEdiInputLocation | cdktn.IResolvable): any;
export declare function b2BiCapabilityConfigurationEdiInputLocationToHclTerraform(struct?: B2BiCapabilityConfigurationEdiInputLocation | cdktn.IResolvable): any;
export declare class B2BiCapabilityConfigurationEdiInputLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiCapabilityConfigurationEdiInputLocation | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiCapabilityConfigurationEdiInputLocation | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
}
export interface B2BiCapabilityConfigurationEdiOutputLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#bucket_name B2BiCapability#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#key B2BiCapability#key}
    */
    readonly key?: string;
}
export declare function b2BiCapabilityConfigurationEdiOutputLocationToTerraform(struct?: B2BiCapabilityConfigurationEdiOutputLocation | cdktn.IResolvable): any;
export declare function b2BiCapabilityConfigurationEdiOutputLocationToHclTerraform(struct?: B2BiCapabilityConfigurationEdiOutputLocation | cdktn.IResolvable): any;
export declare class B2BiCapabilityConfigurationEdiOutputLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiCapabilityConfigurationEdiOutputLocation | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiCapabilityConfigurationEdiOutputLocation | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
}
export interface B2BiCapabilityConfigurationEdiTypeX12Details {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#transaction_set B2BiCapability#transaction_set}
    */
    readonly transactionSet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#version B2BiCapability#version}
    */
    readonly version?: string;
}
export declare function b2BiCapabilityConfigurationEdiTypeX12DetailsToTerraform(struct?: B2BiCapabilityConfigurationEdiTypeX12Details | cdktn.IResolvable): any;
export declare function b2BiCapabilityConfigurationEdiTypeX12DetailsToHclTerraform(struct?: B2BiCapabilityConfigurationEdiTypeX12Details | cdktn.IResolvable): any;
export declare class B2BiCapabilityConfigurationEdiTypeX12DetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiCapabilityConfigurationEdiTypeX12Details | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiCapabilityConfigurationEdiTypeX12Details | cdktn.IResolvable | undefined);
    private _transactionSet?;
    get transactionSet(): string;
    set transactionSet(value: string);
    resetTransactionSet(): void;
    get transactionSetInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface B2BiCapabilityConfigurationEdiType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#x12_details B2BiCapability#x12_details}
    */
    readonly x12Details?: B2BiCapabilityConfigurationEdiTypeX12Details;
}
export declare function b2BiCapabilityConfigurationEdiTypeToTerraform(struct?: B2BiCapabilityConfigurationEdiType | cdktn.IResolvable): any;
export declare function b2BiCapabilityConfigurationEdiTypeToHclTerraform(struct?: B2BiCapabilityConfigurationEdiType | cdktn.IResolvable): any;
export declare class B2BiCapabilityConfigurationEdiTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiCapabilityConfigurationEdiType | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiCapabilityConfigurationEdiType | cdktn.IResolvable | undefined);
    private _x12Details;
    get x12Details(): B2BiCapabilityConfigurationEdiTypeX12DetailsOutputReference;
    putX12Details(value: B2BiCapabilityConfigurationEdiTypeX12Details): void;
    resetX12Details(): void;
    get x12DetailsInput(): cdktn.IResolvable | B2BiCapabilityConfigurationEdiTypeX12Details | undefined;
}
export interface B2BiCapabilityConfigurationEdi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#capability_direction B2BiCapability#capability_direction}
    */
    readonly capabilityDirection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#input_location B2BiCapability#input_location}
    */
    readonly inputLocation?: B2BiCapabilityConfigurationEdiInputLocation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#output_location B2BiCapability#output_location}
    */
    readonly outputLocation?: B2BiCapabilityConfigurationEdiOutputLocation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#transformer_id B2BiCapability#transformer_id}
    */
    readonly transformerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#type B2BiCapability#type}
    */
    readonly type?: B2BiCapabilityConfigurationEdiType;
}
export declare function b2BiCapabilityConfigurationEdiToTerraform(struct?: B2BiCapabilityConfigurationEdi | cdktn.IResolvable): any;
export declare function b2BiCapabilityConfigurationEdiToHclTerraform(struct?: B2BiCapabilityConfigurationEdi | cdktn.IResolvable): any;
export declare class B2BiCapabilityConfigurationEdiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiCapabilityConfigurationEdi | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiCapabilityConfigurationEdi | cdktn.IResolvable | undefined);
    private _capabilityDirection?;
    get capabilityDirection(): string;
    set capabilityDirection(value: string);
    resetCapabilityDirection(): void;
    get capabilityDirectionInput(): string | undefined;
    private _inputLocation;
    get inputLocation(): B2BiCapabilityConfigurationEdiInputLocationOutputReference;
    putInputLocation(value: B2BiCapabilityConfigurationEdiInputLocation): void;
    resetInputLocation(): void;
    get inputLocationInput(): cdktn.IResolvable | B2BiCapabilityConfigurationEdiInputLocation | undefined;
    private _outputLocation;
    get outputLocation(): B2BiCapabilityConfigurationEdiOutputLocationOutputReference;
    putOutputLocation(value: B2BiCapabilityConfigurationEdiOutputLocation): void;
    resetOutputLocation(): void;
    get outputLocationInput(): cdktn.IResolvable | B2BiCapabilityConfigurationEdiOutputLocation | undefined;
    private _transformerId?;
    get transformerId(): string;
    set transformerId(value: string);
    resetTransformerId(): void;
    get transformerIdInput(): string | undefined;
    private _type;
    get type(): B2BiCapabilityConfigurationEdiTypeOutputReference;
    putType(value: B2BiCapabilityConfigurationEdiType): void;
    resetType(): void;
    get typeInput(): cdktn.IResolvable | B2BiCapabilityConfigurationEdiType | undefined;
}
export interface B2BiCapabilityConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#edi B2BiCapability#edi}
    */
    readonly edi?: B2BiCapabilityConfigurationEdi;
}
export declare function b2BiCapabilityConfigurationToTerraform(struct?: B2BiCapabilityConfiguration | cdktn.IResolvable): any;
export declare function b2BiCapabilityConfigurationToHclTerraform(struct?: B2BiCapabilityConfiguration | cdktn.IResolvable): any;
export declare class B2BiCapabilityConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiCapabilityConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiCapabilityConfiguration | cdktn.IResolvable | undefined);
    private _edi;
    get edi(): B2BiCapabilityConfigurationEdiOutputReference;
    putEdi(value: B2BiCapabilityConfigurationEdi): void;
    resetEdi(): void;
    get ediInput(): cdktn.IResolvable | B2BiCapabilityConfigurationEdi | undefined;
}
export interface B2BiCapabilityInstructionsDocuments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#bucket_name B2BiCapability#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#key B2BiCapability#key}
    */
    readonly key?: string;
}
export declare function b2BiCapabilityInstructionsDocumentsToTerraform(struct?: B2BiCapabilityInstructionsDocuments | cdktn.IResolvable): any;
export declare function b2BiCapabilityInstructionsDocumentsToHclTerraform(struct?: B2BiCapabilityInstructionsDocuments | cdktn.IResolvable): any;
export declare class B2BiCapabilityInstructionsDocumentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): B2BiCapabilityInstructionsDocuments | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiCapabilityInstructionsDocuments | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
}
export declare class B2BiCapabilityInstructionsDocumentsList extends cdktn.ComplexList {
    internalValue?: B2BiCapabilityInstructionsDocuments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): B2BiCapabilityInstructionsDocumentsOutputReference;
}
export interface B2BiCapabilityTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#key B2BiCapability#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#value B2BiCapability#value}
    */
    readonly value?: string;
}
export declare function b2BiCapabilityTagsToTerraform(struct?: B2BiCapabilityTags | cdktn.IResolvable): any;
export declare function b2BiCapabilityTagsToHclTerraform(struct?: B2BiCapabilityTags | cdktn.IResolvable): any;
export declare class B2BiCapabilityTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): B2BiCapabilityTags | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiCapabilityTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class B2BiCapabilityTagsList extends cdktn.ComplexList {
    internalValue?: B2BiCapabilityTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): B2BiCapabilityTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability awscc_b2bi_capability}
*/
export declare class B2BiCapability extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_b2bi_capability";
    /**
    * Generates CDKTN code for importing a B2BiCapability resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the B2BiCapability to import
    * @param importFromId The id of the existing B2BiCapability that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the B2BiCapability to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/b2bi_capability awscc_b2bi_capability} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options B2BiCapabilityConfig
    */
    constructor(scope: Construct, id: string, config: B2BiCapabilityConfig);
    get capabilityArn(): string;
    get capabilityId(): string;
    private _configuration;
    get configuration(): B2BiCapabilityConfigurationOutputReference;
    putConfiguration(value: B2BiCapabilityConfiguration): void;
    get configurationInput(): cdktn.IResolvable | B2BiCapabilityConfiguration | undefined;
    get createdAt(): string;
    get id(): string;
    private _instructionsDocuments;
    get instructionsDocuments(): B2BiCapabilityInstructionsDocumentsList;
    putInstructionsDocuments(value: B2BiCapabilityInstructionsDocuments[] | cdktn.IResolvable): void;
    resetInstructionsDocuments(): void;
    get instructionsDocumentsInput(): cdktn.IResolvable | B2BiCapabilityInstructionsDocuments[] | undefined;
    get modifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): B2BiCapabilityTagsList;
    putTags(value: B2BiCapabilityTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | B2BiCapabilityTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
