/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcorePolicyEngineConfig extends cdktn.TerraformMetaArguments {
    /**
    * A human-readable description of the policy engine's purpose and scope
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine#description BedrockagentcorePolicyEngine#description}
    */
    readonly description?: string;
    /**
    * The ARN of the KMS key used to encrypt the policy engine data
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine#encryption_key_arn BedrockagentcorePolicyEngine#encryption_key_arn}
    */
    readonly encryptionKeyArn?: string;
    /**
    * The customer-assigned immutable name for the policy engine
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine#name BedrockagentcorePolicyEngine#name}
    */
    readonly name: string;
    /**
    * A list of tags to assign to the policy engine.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine#tags BedrockagentcorePolicyEngine#tags}
    */
    readonly tags?: BedrockagentcorePolicyEngineTags[] | cdktn.IResolvable;
}
export interface BedrockagentcorePolicyEngineTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine#key BedrockagentcorePolicyEngine#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine#value BedrockagentcorePolicyEngine#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcorePolicyEngineTagsToTerraform(struct?: BedrockagentcorePolicyEngineTags | cdktn.IResolvable): any;
export declare function bedrockagentcorePolicyEngineTagsToHclTerraform(struct?: BedrockagentcorePolicyEngineTags | cdktn.IResolvable): any;
export declare class BedrockagentcorePolicyEngineTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcorePolicyEngineTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePolicyEngineTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcorePolicyEngineTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcorePolicyEngineTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcorePolicyEngineTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine awscc_bedrockagentcore_policy_engine}
*/
export declare class BedrockagentcorePolicyEngine extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_policy_engine";
    /**
    * Generates CDKTN code for importing a BedrockagentcorePolicyEngine resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcorePolicyEngine to import
    * @param importFromId The id of the existing BedrockagentcorePolicyEngine that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcorePolicyEngine to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_policy_engine awscc_bedrockagentcore_policy_engine} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcorePolicyEngineConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcorePolicyEngineConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encryptionKeyArn?;
    get encryptionKeyArn(): string;
    set encryptionKeyArn(value: string);
    resetEncryptionKeyArn(): void;
    get encryptionKeyArnInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyEngineArn(): string;
    get policyEngineId(): string;
    get status(): string;
    get statusReasons(): string[];
    private _tags;
    get tags(): BedrockagentcorePolicyEngineTagsList;
    putTags(value: BedrockagentcorePolicyEngineTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcorePolicyEngineTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
