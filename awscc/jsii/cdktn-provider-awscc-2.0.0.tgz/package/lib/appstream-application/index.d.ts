/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#app_block_arn AppstreamApplication#app_block_arn}
    */
    readonly appBlockArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#attributes_to_delete AppstreamApplication#attributes_to_delete}
    */
    readonly attributesToDelete?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#description AppstreamApplication#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#display_name AppstreamApplication#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#icon_s3_location AppstreamApplication#icon_s3_location}
    */
    readonly iconS3Location: AppstreamApplicationIconS3Location;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#instance_families AppstreamApplication#instance_families}
    */
    readonly instanceFamilies: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#launch_parameters AppstreamApplication#launch_parameters}
    */
    readonly launchParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#launch_path AppstreamApplication#launch_path}
    */
    readonly launchPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#name AppstreamApplication#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#platforms AppstreamApplication#platforms}
    */
    readonly platforms: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#tags AppstreamApplication#tags}
    */
    readonly tags?: AppstreamApplicationTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#working_directory AppstreamApplication#working_directory}
    */
    readonly workingDirectory?: string;
}
export interface AppstreamApplicationIconS3Location {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#s3_bucket AppstreamApplication#s3_bucket}
    */
    readonly s3Bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#s3_key AppstreamApplication#s3_key}
    */
    readonly s3Key: string;
}
export declare function appstreamApplicationIconS3LocationToTerraform(struct?: AppstreamApplicationIconS3Location | cdktn.IResolvable): any;
export declare function appstreamApplicationIconS3LocationToHclTerraform(struct?: AppstreamApplicationIconS3Location | cdktn.IResolvable): any;
export declare class AppstreamApplicationIconS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamApplicationIconS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamApplicationIconS3Location | cdktn.IResolvable | undefined);
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    get s3BucketInput(): string | undefined;
    private _s3Key?;
    get s3Key(): string;
    set s3Key(value: string);
    get s3KeyInput(): string | undefined;
}
export interface AppstreamApplicationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#key AppstreamApplication#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#tag_key AppstreamApplication#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#tag_value AppstreamApplication#tag_value}
    */
    readonly tagValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#value AppstreamApplication#value}
    */
    readonly value?: string;
}
export declare function appstreamApplicationTagsToTerraform(struct?: AppstreamApplicationTags | cdktn.IResolvable): any;
export declare function appstreamApplicationTagsToHclTerraform(struct?: AppstreamApplicationTags | cdktn.IResolvable): any;
export declare class AppstreamApplicationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamApplicationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamApplicationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppstreamApplicationTagsList extends cdktn.ComplexList {
    internalValue?: AppstreamApplicationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamApplicationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application awscc_appstream_application}
*/
export declare class AppstreamApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_application";
    /**
    * Generates CDKTN code for importing a AppstreamApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamApplication to import
    * @param importFromId The id of the existing AppstreamApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_application awscc_appstream_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamApplicationConfig);
    private _appBlockArn?;
    get appBlockArn(): string;
    set appBlockArn(value: string);
    get appBlockArnInput(): string | undefined;
    get arn(): string;
    private _attributesToDelete?;
    get attributesToDelete(): string[];
    set attributesToDelete(value: string[]);
    resetAttributesToDelete(): void;
    get attributesToDeleteInput(): string[] | undefined;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _iconS3Location;
    get iconS3Location(): AppstreamApplicationIconS3LocationOutputReference;
    putIconS3Location(value: AppstreamApplicationIconS3Location): void;
    get iconS3LocationInput(): cdktn.IResolvable | AppstreamApplicationIconS3Location | undefined;
    get id(): string;
    private _instanceFamilies?;
    get instanceFamilies(): string[];
    set instanceFamilies(value: string[]);
    get instanceFamiliesInput(): string[] | undefined;
    private _launchParameters?;
    get launchParameters(): string;
    set launchParameters(value: string);
    resetLaunchParameters(): void;
    get launchParametersInput(): string | undefined;
    private _launchPath?;
    get launchPath(): string;
    set launchPath(value: string);
    get launchPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _platforms?;
    get platforms(): string[];
    set platforms(value: string[]);
    get platformsInput(): string[] | undefined;
    private _tags;
    get tags(): AppstreamApplicationTagsList;
    putTags(value: AppstreamApplicationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppstreamApplicationTags[] | undefined;
    private _workingDirectory?;
    get workingDirectory(): string;
    set workingDirectory(value: string);
    resetWorkingDirectory(): void;
    get workingDirectoryInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
