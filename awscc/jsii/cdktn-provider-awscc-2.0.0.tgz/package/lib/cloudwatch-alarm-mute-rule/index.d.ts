/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchAlarmMuteRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the AlarmMuteRule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#description CloudwatchAlarmMuteRule#description}
    */
    readonly description?: string;
    /**
    * The date, with the same timezone offset as "ScheduleTimezone" after which the alarm mute rule will be expired.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#expire_date CloudwatchAlarmMuteRule#expire_date}
    */
    readonly expireDate?: string;
    /**
    * Targets to be muted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#mute_targets CloudwatchAlarmMuteRule#mute_targets}
    */
    readonly muteTargets?: CloudwatchAlarmMuteRuleMuteTargets;
    /**
    * The name of the AlarmMuteRule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#name CloudwatchAlarmMuteRule#name}
    */
    readonly name?: string;
    /**
    * The rule for the mute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#rule CloudwatchAlarmMuteRule#rule}
    */
    readonly rule: CloudwatchAlarmMuteRuleRule;
    /**
    * The date, with the same timezone offset as "ScheduleTimezone", after which the alarm mute rule will become active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#start_date CloudwatchAlarmMuteRule#start_date}
    */
    readonly startDate?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#tags CloudwatchAlarmMuteRule#tags}
    */
    readonly tags?: CloudwatchAlarmMuteRuleTags[] | cdktn.IResolvable;
}
export interface CloudwatchAlarmMuteRuleMuteTargets {
    /**
    * The alarm names to be mute by the AlarmMuteRule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#alarm_names CloudwatchAlarmMuteRule#alarm_names}
    */
    readonly alarmNames?: string[];
}
export declare function cloudwatchAlarmMuteRuleMuteTargetsToTerraform(struct?: CloudwatchAlarmMuteRuleMuteTargets | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMuteRuleMuteTargetsToHclTerraform(struct?: CloudwatchAlarmMuteRuleMuteTargets | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMuteRuleMuteTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmMuteRuleMuteTargets | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMuteRuleMuteTargets | cdktn.IResolvable | undefined);
    private _alarmNames?;
    get alarmNames(): string[];
    set alarmNames(value: string[]);
    resetAlarmNames(): void;
    get alarmNamesInput(): string[] | undefined;
}
export interface CloudwatchAlarmMuteRuleRuleSchedule {
    /**
    * The duration of the schedule when it triggers
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#duration CloudwatchAlarmMuteRule#duration}
    */
    readonly duration: string;
    /**
    * The expression of the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#expression CloudwatchAlarmMuteRule#expression}
    */
    readonly expression: string;
    /**
    * The timezone of the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#timezone CloudwatchAlarmMuteRule#timezone}
    */
    readonly timezone?: string;
}
export declare function cloudwatchAlarmMuteRuleRuleScheduleToTerraform(struct?: CloudwatchAlarmMuteRuleRuleSchedule | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMuteRuleRuleScheduleToHclTerraform(struct?: CloudwatchAlarmMuteRuleRuleSchedule | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMuteRuleRuleScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmMuteRuleRuleSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMuteRuleRuleSchedule | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): string;
    set duration(value: string);
    get durationInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
export interface CloudwatchAlarmMuteRuleRule {
    /**
    * Schedule for the mute to be active
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#schedule CloudwatchAlarmMuteRule#schedule}
    */
    readonly schedule: CloudwatchAlarmMuteRuleRuleSchedule;
}
export declare function cloudwatchAlarmMuteRuleRuleToTerraform(struct?: CloudwatchAlarmMuteRuleRule | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMuteRuleRuleToHclTerraform(struct?: CloudwatchAlarmMuteRuleRule | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMuteRuleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmMuteRuleRule | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMuteRuleRule | cdktn.IResolvable | undefined);
    private _schedule;
    get schedule(): CloudwatchAlarmMuteRuleRuleScheduleOutputReference;
    putSchedule(value: CloudwatchAlarmMuteRuleRuleSchedule): void;
    get scheduleInput(): cdktn.IResolvable | CloudwatchAlarmMuteRuleRuleSchedule | undefined;
}
export interface CloudwatchAlarmMuteRuleTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#key CloudwatchAlarmMuteRule#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#value CloudwatchAlarmMuteRule#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAlarmMuteRuleTagsToTerraform(struct?: CloudwatchAlarmMuteRuleTags | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMuteRuleTagsToHclTerraform(struct?: CloudwatchAlarmMuteRuleTags | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMuteRuleTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlarmMuteRuleTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMuteRuleTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAlarmMuteRuleTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlarmMuteRuleTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlarmMuteRuleTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule awscc_cloudwatch_alarm_mute_rule}
*/
export declare class CloudwatchAlarmMuteRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_alarm_mute_rule";
    /**
    * Generates CDKTN code for importing a CloudwatchAlarmMuteRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchAlarmMuteRule to import
    * @param importFromId The id of the existing CloudwatchAlarmMuteRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchAlarmMuteRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_alarm_mute_rule awscc_cloudwatch_alarm_mute_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchAlarmMuteRuleConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchAlarmMuteRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expireDate?;
    get expireDate(): string;
    set expireDate(value: string);
    resetExpireDate(): void;
    get expireDateInput(): string | undefined;
    get id(): string;
    get lastUpdatedTimestamp(): string;
    private _muteTargets;
    get muteTargets(): CloudwatchAlarmMuteRuleMuteTargetsOutputReference;
    putMuteTargets(value: CloudwatchAlarmMuteRuleMuteTargets): void;
    resetMuteTargets(): void;
    get muteTargetsInput(): cdktn.IResolvable | CloudwatchAlarmMuteRuleMuteTargets | undefined;
    get muteType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _rule;
    get rule(): CloudwatchAlarmMuteRuleRuleOutputReference;
    putRule(value: CloudwatchAlarmMuteRuleRule): void;
    get ruleInput(): cdktn.IResolvable | CloudwatchAlarmMuteRuleRule | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): CloudwatchAlarmMuteRuleTagsList;
    putTags(value: CloudwatchAlarmMuteRuleTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchAlarmMuteRuleTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
