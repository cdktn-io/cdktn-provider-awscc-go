/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AthenaCapacityReservationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Assignment configuration to assign workgroups to a reservation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#capacity_assignment_configuration AthenaCapacityReservation#capacity_assignment_configuration}
    */
    readonly capacityAssignmentConfiguration?: AthenaCapacityReservationCapacityAssignmentConfiguration;
    /**
    * The reservation name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#name AthenaCapacityReservation#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#tags AthenaCapacityReservation#tags}
    */
    readonly tags?: AthenaCapacityReservationTags[] | cdktn.IResolvable;
    /**
    * The number of DPUs to request to be allocated to the reservation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#target_dpus AthenaCapacityReservation#target_dpus}
    */
    readonly targetDpus: number;
}
export interface AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#workgroup_names AthenaCapacityReservation#workgroup_names}
    */
    readonly workgroupNames?: string[];
}
export declare function athenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignmentsToTerraform(struct?: AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments | cdktn.IResolvable): any;
export declare function athenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignmentsToHclTerraform(struct?: AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments | cdktn.IResolvable): any;
export declare class AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments | cdktn.IResolvable | undefined);
    private _workgroupNames?;
    get workgroupNames(): string[];
    set workgroupNames(value: string[]);
    resetWorkgroupNames(): void;
    get workgroupNamesInput(): string[] | undefined;
}
export declare class AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignmentsList extends cdktn.ComplexList {
    internalValue?: AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignmentsOutputReference;
}
export interface AthenaCapacityReservationCapacityAssignmentConfiguration {
    /**
    * List of capacity assignments
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#capacity_assignments AthenaCapacityReservation#capacity_assignments}
    */
    readonly capacityAssignments?: AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments[] | cdktn.IResolvable;
}
export declare function athenaCapacityReservationCapacityAssignmentConfigurationToTerraform(struct?: AthenaCapacityReservationCapacityAssignmentConfiguration | cdktn.IResolvable): any;
export declare function athenaCapacityReservationCapacityAssignmentConfigurationToHclTerraform(struct?: AthenaCapacityReservationCapacityAssignmentConfiguration | cdktn.IResolvable): any;
export declare class AthenaCapacityReservationCapacityAssignmentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaCapacityReservationCapacityAssignmentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaCapacityReservationCapacityAssignmentConfiguration | cdktn.IResolvable | undefined);
    private _capacityAssignments;
    get capacityAssignments(): AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignmentsList;
    putCapacityAssignments(value: AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments[] | cdktn.IResolvable): void;
    resetCapacityAssignments(): void;
    get capacityAssignmentsInput(): cdktn.IResolvable | AthenaCapacityReservationCapacityAssignmentConfigurationCapacityAssignments[] | undefined;
}
export interface AthenaCapacityReservationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#key AthenaCapacityReservation#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#value AthenaCapacityReservation#value}
    */
    readonly value?: string;
}
export declare function athenaCapacityReservationTagsToTerraform(struct?: AthenaCapacityReservationTags | cdktn.IResolvable): any;
export declare function athenaCapacityReservationTagsToHclTerraform(struct?: AthenaCapacityReservationTags | cdktn.IResolvable): any;
export declare class AthenaCapacityReservationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AthenaCapacityReservationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaCapacityReservationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AthenaCapacityReservationTagsList extends cdktn.ComplexList {
    internalValue?: AthenaCapacityReservationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AthenaCapacityReservationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation awscc_athena_capacity_reservation}
*/
export declare class AthenaCapacityReservation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_athena_capacity_reservation";
    /**
    * Generates CDKTN code for importing a AthenaCapacityReservation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AthenaCapacityReservation to import
    * @param importFromId The id of the existing AthenaCapacityReservation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AthenaCapacityReservation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/athena_capacity_reservation awscc_athena_capacity_reservation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AthenaCapacityReservationConfig
    */
    constructor(scope: Construct, id: string, config: AthenaCapacityReservationConfig);
    get allocatedDpus(): number;
    get arn(): string;
    private _capacityAssignmentConfiguration;
    get capacityAssignmentConfiguration(): AthenaCapacityReservationCapacityAssignmentConfigurationOutputReference;
    putCapacityAssignmentConfiguration(value: AthenaCapacityReservationCapacityAssignmentConfiguration): void;
    resetCapacityAssignmentConfiguration(): void;
    get capacityAssignmentConfigurationInput(): cdktn.IResolvable | AthenaCapacityReservationCapacityAssignmentConfiguration | undefined;
    get creationTime(): string;
    get id(): string;
    get lastSuccessfulAllocationTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): AthenaCapacityReservationTagsList;
    putTags(value: AthenaCapacityReservationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AthenaCapacityReservationTags[] | undefined;
    private _targetDpus?;
    get targetDpus(): number;
    set targetDpus(value: number);
    get targetDpusInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
