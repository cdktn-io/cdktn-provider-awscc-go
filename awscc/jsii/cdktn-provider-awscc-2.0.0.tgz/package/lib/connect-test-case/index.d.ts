/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectTestCaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * The content of the test case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#content ConnectTestCase#content}
    */
    readonly content: string;
    /**
    * The description of the test case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#description ConnectTestCase#description}
    */
    readonly description?: string;
    /**
    * Entry point for Testcase.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#entry_point ConnectTestCase#entry_point}
    */
    readonly entryPoint?: ConnectTestCaseEntryPoint;
    /**
    * The initialization data of the test case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#initialization_data ConnectTestCase#initialization_data}
    */
    readonly initializationData?: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#instance_arn ConnectTestCase#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the test case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#name ConnectTestCase#name}
    */
    readonly name: string;
    /**
    * The status of the test case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#status ConnectTestCase#status}
    */
    readonly status?: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#tags ConnectTestCase#tags}
    */
    readonly tags?: ConnectTestCaseTags[] | cdktn.IResolvable;
}
export interface ConnectTestCaseEntryPointChatEntryPointParameters {
    /**
    * The flow id used for the TestCase
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#flow_id ConnectTestCase#flow_id}
    */
    readonly flowId?: string;
}
export declare function connectTestCaseEntryPointChatEntryPointParametersToTerraform(struct?: ConnectTestCaseEntryPointChatEntryPointParameters | cdktn.IResolvable): any;
export declare function connectTestCaseEntryPointChatEntryPointParametersToHclTerraform(struct?: ConnectTestCaseEntryPointChatEntryPointParameters | cdktn.IResolvable): any;
export declare class ConnectTestCaseEntryPointChatEntryPointParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTestCaseEntryPointChatEntryPointParameters | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTestCaseEntryPointChatEntryPointParameters | cdktn.IResolvable | undefined);
    private _flowId?;
    get flowId(): string;
    set flowId(value: string);
    resetFlowId(): void;
    get flowIdInput(): string | undefined;
}
export interface ConnectTestCaseEntryPointVoiceCallEntryPointParameters {
    /**
    * The destination phonenumber of the EntryPoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#destination_phone_number ConnectTestCase#destination_phone_number}
    */
    readonly destinationPhoneNumber?: string;
    /**
    * The flow id used for the TestCase
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#flow_id ConnectTestCase#flow_id}
    */
    readonly flowId?: string;
    /**
    * The source phonenumber of the EntryPoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#source_phone_number ConnectTestCase#source_phone_number}
    */
    readonly sourcePhoneNumber?: string;
}
export declare function connectTestCaseEntryPointVoiceCallEntryPointParametersToTerraform(struct?: ConnectTestCaseEntryPointVoiceCallEntryPointParameters | cdktn.IResolvable): any;
export declare function connectTestCaseEntryPointVoiceCallEntryPointParametersToHclTerraform(struct?: ConnectTestCaseEntryPointVoiceCallEntryPointParameters | cdktn.IResolvable): any;
export declare class ConnectTestCaseEntryPointVoiceCallEntryPointParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTestCaseEntryPointVoiceCallEntryPointParameters | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTestCaseEntryPointVoiceCallEntryPointParameters | cdktn.IResolvable | undefined);
    private _destinationPhoneNumber?;
    get destinationPhoneNumber(): string;
    set destinationPhoneNumber(value: string);
    resetDestinationPhoneNumber(): void;
    get destinationPhoneNumberInput(): string | undefined;
    private _flowId?;
    get flowId(): string;
    set flowId(value: string);
    resetFlowId(): void;
    get flowIdInput(): string | undefined;
    private _sourcePhoneNumber?;
    get sourcePhoneNumber(): string;
    set sourcePhoneNumber(value: string);
    resetSourcePhoneNumber(): void;
    get sourcePhoneNumberInput(): string | undefined;
}
export interface ConnectTestCaseEntryPoint {
    /**
    * The chat entry point parameters for the test case
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#chat_entry_point_parameters ConnectTestCase#chat_entry_point_parameters}
    */
    readonly chatEntryPointParameters?: ConnectTestCaseEntryPointChatEntryPointParameters;
    /**
    * The type of the Entry Point
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#type ConnectTestCase#type}
    */
    readonly type?: string;
    /**
    * The voice call entry point parameters for the test case
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#voice_call_entry_point_parameters ConnectTestCase#voice_call_entry_point_parameters}
    */
    readonly voiceCallEntryPointParameters?: ConnectTestCaseEntryPointVoiceCallEntryPointParameters;
}
export declare function connectTestCaseEntryPointToTerraform(struct?: ConnectTestCaseEntryPoint | cdktn.IResolvable): any;
export declare function connectTestCaseEntryPointToHclTerraform(struct?: ConnectTestCaseEntryPoint | cdktn.IResolvable): any;
export declare class ConnectTestCaseEntryPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTestCaseEntryPoint | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTestCaseEntryPoint | cdktn.IResolvable | undefined);
    private _chatEntryPointParameters;
    get chatEntryPointParameters(): ConnectTestCaseEntryPointChatEntryPointParametersOutputReference;
    putChatEntryPointParameters(value: ConnectTestCaseEntryPointChatEntryPointParameters): void;
    resetChatEntryPointParameters(): void;
    get chatEntryPointParametersInput(): cdktn.IResolvable | ConnectTestCaseEntryPointChatEntryPointParameters | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _voiceCallEntryPointParameters;
    get voiceCallEntryPointParameters(): ConnectTestCaseEntryPointVoiceCallEntryPointParametersOutputReference;
    putVoiceCallEntryPointParameters(value: ConnectTestCaseEntryPointVoiceCallEntryPointParameters): void;
    resetVoiceCallEntryPointParameters(): void;
    get voiceCallEntryPointParametersInput(): cdktn.IResolvable | ConnectTestCaseEntryPointVoiceCallEntryPointParameters | undefined;
}
export interface ConnectTestCaseTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#key ConnectTestCase#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#value ConnectTestCase#value}
    */
    readonly value?: string;
}
export declare function connectTestCaseTagsToTerraform(struct?: ConnectTestCaseTags | cdktn.IResolvable): any;
export declare function connectTestCaseTagsToHclTerraform(struct?: ConnectTestCaseTags | cdktn.IResolvable): any;
export declare class ConnectTestCaseTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectTestCaseTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTestCaseTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectTestCaseTagsList extends cdktn.ComplexList {
    internalValue?: ConnectTestCaseTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectTestCaseTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case awscc_connect_test_case}
*/
export declare class ConnectTestCase extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_test_case";
    /**
    * Generates CDKTN code for importing a ConnectTestCase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectTestCase to import
    * @param importFromId The id of the existing ConnectTestCase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectTestCase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_test_case awscc_connect_test_case} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectTestCaseConfig
    */
    constructor(scope: Construct, id: string, config: ConnectTestCaseConfig);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _entryPoint;
    get entryPoint(): ConnectTestCaseEntryPointOutputReference;
    putEntryPoint(value: ConnectTestCaseEntryPoint): void;
    resetEntryPoint(): void;
    get entryPointInput(): cdktn.IResolvable | ConnectTestCaseEntryPoint | undefined;
    get id(): string;
    private _initializationData?;
    get initializationData(): string;
    set initializationData(value: string);
    resetInitializationData(): void;
    get initializationDataInput(): string | undefined;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get lastModifiedRegion(): string;
    get lastModifiedTime(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags;
    get tags(): ConnectTestCaseTagsList;
    putTags(value: ConnectTestCaseTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectTestCaseTags[] | undefined;
    get testCaseArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
