/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcorePaymentManagerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The authorizer configuration for the payment manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#authorizer_configuration BedrockagentcorePaymentManager#authorizer_configuration}
    */
    readonly authorizerConfiguration?: BedrockagentcorePaymentManagerAuthorizerConfiguration;
    /**
    * The type of authorizer for the payment manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#authorizer_type BedrockagentcorePaymentManager#authorizer_type}
    */
    readonly authorizerType: string;
    /**
    * A description of the payment manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#description BedrockagentcorePaymentManager#description}
    */
    readonly description?: string;
    /**
    * The name of the payment manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#name BedrockagentcorePaymentManager#name}
    */
    readonly name: string;
    /**
    * The ARN of the IAM role for the payment manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#role_arn BedrockagentcorePaymentManager#role_arn}
    */
    readonly roleArn: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#tags BedrockagentcorePaymentManager#tags}
    */
    readonly tags?: BedrockagentcorePaymentManagerTags[] | cdktn.IResolvable;
}
export interface BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#match_value_string BedrockagentcorePaymentManager#match_value_string}
    */
    readonly matchValueString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#match_value_string_list BedrockagentcorePaymentManager#match_value_string_list}
    */
    readonly matchValueStringList?: string[];
}
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToHclTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined);
    private _matchValueString?;
    get matchValueString(): string;
    set matchValueString(value: string);
    resetMatchValueString(): void;
    get matchValueStringInput(): string | undefined;
    private _matchValueStringList?;
    get matchValueStringList(): string[];
    set matchValueStringList(value: string[]);
    resetMatchValueStringList(): void;
    get matchValueStringListInput(): string[] | undefined;
}
export interface BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#claim_match_operator BedrockagentcorePaymentManager#claim_match_operator}
    */
    readonly claimMatchOperator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#claim_match_value BedrockagentcorePaymentManager#claim_match_value}
    */
    readonly claimMatchValue?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue;
}
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToHclTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined);
    private _claimMatchOperator?;
    get claimMatchOperator(): string;
    set claimMatchOperator(value: string);
    resetClaimMatchOperator(): void;
    get claimMatchOperatorInput(): string | undefined;
    private _claimMatchValue;
    get claimMatchValue(): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference;
    putClaimMatchValue(value: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue): void;
    resetClaimMatchValue(): void;
    get claimMatchValueInput(): cdktn.IResolvable | BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | undefined;
}
export interface BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#authorizing_claim_match_value BedrockagentcorePaymentManager#authorizing_claim_match_value}
    */
    readonly authorizingClaimMatchValue?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#inbound_token_claim_name BedrockagentcorePaymentManager#inbound_token_claim_name}
    */
    readonly inboundTokenClaimName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#inbound_token_claim_value_type BedrockagentcorePaymentManager#inbound_token_claim_value_type}
    */
    readonly inboundTokenClaimValueType?: string;
}
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToHclTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined);
    private _authorizingClaimMatchValue;
    get authorizingClaimMatchValue(): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference;
    putAuthorizingClaimMatchValue(value: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue): void;
    resetAuthorizingClaimMatchValue(): void;
    get authorizingClaimMatchValueInput(): cdktn.IResolvable | BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | undefined;
    private _inboundTokenClaimName?;
    get inboundTokenClaimName(): string;
    set inboundTokenClaimName(value: string);
    resetInboundTokenClaimName(): void;
    get inboundTokenClaimNameInput(): string | undefined;
    private _inboundTokenClaimValueType?;
    get inboundTokenClaimValueType(): string;
    set inboundTokenClaimValueType(value: string);
    resetInboundTokenClaimValueType(): void;
    get inboundTokenClaimValueTypeInput(): string | undefined;
}
export declare class BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference;
}
export interface BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#allowed_audience BedrockagentcorePaymentManager#allowed_audience}
    */
    readonly allowedAudience?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#allowed_clients BedrockagentcorePaymentManager#allowed_clients}
    */
    readonly allowedClients?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#allowed_scopes BedrockagentcorePaymentManager#allowed_scopes}
    */
    readonly allowedScopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#custom_claims BedrockagentcorePaymentManager#custom_claims}
    */
    readonly customClaims?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#discovery_url BedrockagentcorePaymentManager#discovery_url}
    */
    readonly discoveryUrl?: string;
}
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerToTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerToHclTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined);
    private _allowedAudience?;
    get allowedAudience(): string[];
    set allowedAudience(value: string[]);
    resetAllowedAudience(): void;
    get allowedAudienceInput(): string[] | undefined;
    private _allowedClients?;
    get allowedClients(): string[];
    set allowedClients(value: string[]);
    resetAllowedClients(): void;
    get allowedClientsInput(): string[] | undefined;
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
    private _customClaims;
    get customClaims(): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList;
    putCustomClaims(value: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable): void;
    resetCustomClaims(): void;
    get customClaimsInput(): cdktn.IResolvable | BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | undefined;
    private _discoveryUrl?;
    get discoveryUrl(): string;
    set discoveryUrl(value: string);
    resetDiscoveryUrl(): void;
    get discoveryUrlInput(): string | undefined;
}
export interface BedrockagentcorePaymentManagerAuthorizerConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#custom_jwt_authorizer BedrockagentcorePaymentManager#custom_jwt_authorizer}
    */
    readonly customJwtAuthorizer?: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizer;
}
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationToTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentManagerAuthorizerConfigurationToHclTerraform(struct?: BedrockagentcorePaymentManagerAuthorizerConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentManagerAuthorizerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentManagerAuthorizerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentManagerAuthorizerConfiguration | cdktn.IResolvable | undefined);
    private _customJwtAuthorizer;
    get customJwtAuthorizer(): BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizerOutputReference;
    putCustomJwtAuthorizer(value: BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizer): void;
    resetCustomJwtAuthorizer(): void;
    get customJwtAuthorizerInput(): cdktn.IResolvable | BedrockagentcorePaymentManagerAuthorizerConfigurationCustomJwtAuthorizer | undefined;
}
export interface BedrockagentcorePaymentManagerTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#key BedrockagentcorePaymentManager#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#value BedrockagentcorePaymentManager#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcorePaymentManagerTagsToTerraform(struct?: BedrockagentcorePaymentManagerTags | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentManagerTagsToHclTerraform(struct?: BedrockagentcorePaymentManagerTags | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentManagerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcorePaymentManagerTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentManagerTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcorePaymentManagerTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcorePaymentManagerTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcorePaymentManagerTagsOutputReference;
}
export interface BedrockagentcorePaymentManagerWorkloadIdentityDetails {
}
export declare function bedrockagentcorePaymentManagerWorkloadIdentityDetailsToTerraform(struct?: BedrockagentcorePaymentManagerWorkloadIdentityDetails): any;
export declare function bedrockagentcorePaymentManagerWorkloadIdentityDetailsToHclTerraform(struct?: BedrockagentcorePaymentManagerWorkloadIdentityDetails): any;
export declare class BedrockagentcorePaymentManagerWorkloadIdentityDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentManagerWorkloadIdentityDetails | undefined;
    set internalValue(value: BedrockagentcorePaymentManagerWorkloadIdentityDetails | undefined);
    get workloadIdentityArn(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager awscc_bedrockagentcore_payment_manager}
*/
export declare class BedrockagentcorePaymentManager extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_payment_manager";
    /**
    * Generates CDKTN code for importing a BedrockagentcorePaymentManager resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcorePaymentManager to import
    * @param importFromId The id of the existing BedrockagentcorePaymentManager that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcorePaymentManager to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_manager awscc_bedrockagentcore_payment_manager} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcorePaymentManagerConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcorePaymentManagerConfig);
    private _authorizerConfiguration;
    get authorizerConfiguration(): BedrockagentcorePaymentManagerAuthorizerConfigurationOutputReference;
    putAuthorizerConfiguration(value: BedrockagentcorePaymentManagerAuthorizerConfiguration): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | BedrockagentcorePaymentManagerAuthorizerConfiguration | undefined;
    private _authorizerType?;
    get authorizerType(): string;
    set authorizerType(value: string);
    get authorizerTypeInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get paymentManagerArn(): string;
    get paymentManagerId(): string;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): BedrockagentcorePaymentManagerTagsList;
    putTags(value: BedrockagentcorePaymentManagerTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcorePaymentManagerTags[] | undefined;
    private _workloadIdentityDetails;
    get workloadIdentityDetails(): BedrockagentcorePaymentManagerWorkloadIdentityDetailsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
