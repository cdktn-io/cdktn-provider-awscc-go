/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApprunnerObservabilityConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * A name for the observability configuration. When you use it for the first time in an AWS Region, App Runner creates revision number 1 of this name. When you use the same name in subsequent calls, App Runner creates incremental revisions of the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration#observability_configuration_name ApprunnerObservabilityConfiguration#observability_configuration_name}
    */
    readonly observabilityConfigurationName?: string;
    /**
    * A list of metadata items that you can associate with your observability configuration resource. A tag is a key-value pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration#tags ApprunnerObservabilityConfiguration#tags}
    */
    readonly tags?: ApprunnerObservabilityConfigurationTags[] | cdktn.IResolvable;
    /**
    * The configuration of the tracing feature within this observability configuration. If you don't specify it, App Runner doesn't enable tracing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration#trace_configuration ApprunnerObservabilityConfiguration#trace_configuration}
    */
    readonly traceConfiguration?: ApprunnerObservabilityConfigurationTraceConfiguration;
}
export interface ApprunnerObservabilityConfigurationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration#key ApprunnerObservabilityConfiguration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration#value ApprunnerObservabilityConfiguration#value}
    */
    readonly value?: string;
}
export declare function apprunnerObservabilityConfigurationTagsToTerraform(struct?: ApprunnerObservabilityConfigurationTags | cdktn.IResolvable): any;
export declare function apprunnerObservabilityConfigurationTagsToHclTerraform(struct?: ApprunnerObservabilityConfigurationTags | cdktn.IResolvable): any;
export declare class ApprunnerObservabilityConfigurationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApprunnerObservabilityConfigurationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerObservabilityConfigurationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApprunnerObservabilityConfigurationTagsList extends cdktn.ComplexList {
    internalValue?: ApprunnerObservabilityConfigurationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApprunnerObservabilityConfigurationTagsOutputReference;
}
export interface ApprunnerObservabilityConfigurationTraceConfiguration {
    /**
    * The implementation provider chosen for tracing App Runner services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration#vendor ApprunnerObservabilityConfiguration#vendor}
    */
    readonly vendor?: string;
}
export declare function apprunnerObservabilityConfigurationTraceConfigurationToTerraform(struct?: ApprunnerObservabilityConfigurationTraceConfiguration | cdktn.IResolvable): any;
export declare function apprunnerObservabilityConfigurationTraceConfigurationToHclTerraform(struct?: ApprunnerObservabilityConfigurationTraceConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerObservabilityConfigurationTraceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerObservabilityConfigurationTraceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerObservabilityConfigurationTraceConfiguration | cdktn.IResolvable | undefined);
    private _vendor?;
    get vendor(): string;
    set vendor(value: string);
    resetVendor(): void;
    get vendorInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration awscc_apprunner_observability_configuration}
*/
export declare class ApprunnerObservabilityConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apprunner_observability_configuration";
    /**
    * Generates CDKTN code for importing a ApprunnerObservabilityConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApprunnerObservabilityConfiguration to import
    * @param importFromId The id of the existing ApprunnerObservabilityConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApprunnerObservabilityConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_observability_configuration awscc_apprunner_observability_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApprunnerObservabilityConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApprunnerObservabilityConfigurationConfig);
    get id(): string;
    get latest(): cdktn.IResolvable;
    get observabilityConfigurationArn(): string;
    private _observabilityConfigurationName?;
    get observabilityConfigurationName(): string;
    set observabilityConfigurationName(value: string);
    resetObservabilityConfigurationName(): void;
    get observabilityConfigurationNameInput(): string | undefined;
    get observabilityConfigurationRevision(): number;
    private _tags;
    get tags(): ApprunnerObservabilityConfigurationTagsList;
    putTags(value: ApprunnerObservabilityConfigurationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApprunnerObservabilityConfigurationTags[] | undefined;
    private _traceConfiguration;
    get traceConfiguration(): ApprunnerObservabilityConfigurationTraceConfigurationOutputReference;
    putTraceConfiguration(value: ApprunnerObservabilityConfigurationTraceConfiguration): void;
    resetTraceConfiguration(): void;
    get traceConfigurationInput(): cdktn.IResolvable | ApprunnerObservabilityConfigurationTraceConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
