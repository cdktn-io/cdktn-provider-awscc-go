/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppintegrationsEventIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The event integration description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#description AppintegrationsEventIntegration#description}
    */
    readonly description?: string;
    /**
    * The Amazon Eventbridge bus for the event integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#event_bridge_bus AppintegrationsEventIntegration#event_bridge_bus}
    */
    readonly eventBridgeBus: string;
    /**
    * The EventFilter (source) associated with the event integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#event_filter AppintegrationsEventIntegration#event_filter}
    */
    readonly eventFilter: AppintegrationsEventIntegrationEventFilter;
    /**
    * The name of the event integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#name AppintegrationsEventIntegration#name}
    */
    readonly name: string;
    /**
    * The tags (keys and values) associated with the event integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#tags AppintegrationsEventIntegration#tags}
    */
    readonly tags?: AppintegrationsEventIntegrationTags[] | cdktn.IResolvable;
}
export interface AppintegrationsEventIntegrationEventFilter {
    /**
    * The source of the events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#source AppintegrationsEventIntegration#source}
    */
    readonly source: string;
}
export declare function appintegrationsEventIntegrationEventFilterToTerraform(struct?: AppintegrationsEventIntegrationEventFilter | cdktn.IResolvable): any;
export declare function appintegrationsEventIntegrationEventFilterToHclTerraform(struct?: AppintegrationsEventIntegrationEventFilter | cdktn.IResolvable): any;
export declare class AppintegrationsEventIntegrationEventFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppintegrationsEventIntegrationEventFilter | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsEventIntegrationEventFilter | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export interface AppintegrationsEventIntegrationTags {
    /**
    * A key to identify the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#key AppintegrationsEventIntegration#key}
    */
    readonly key?: string;
    /**
    * Corresponding tag value for the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#value AppintegrationsEventIntegration#value}
    */
    readonly value?: string;
}
export declare function appintegrationsEventIntegrationTagsToTerraform(struct?: AppintegrationsEventIntegrationTags | cdktn.IResolvable): any;
export declare function appintegrationsEventIntegrationTagsToHclTerraform(struct?: AppintegrationsEventIntegrationTags | cdktn.IResolvable): any;
export declare class AppintegrationsEventIntegrationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppintegrationsEventIntegrationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsEventIntegrationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppintegrationsEventIntegrationTagsList extends cdktn.ComplexList {
    internalValue?: AppintegrationsEventIntegrationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppintegrationsEventIntegrationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration awscc_appintegrations_event_integration}
*/
export declare class AppintegrationsEventIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appintegrations_event_integration";
    /**
    * Generates CDKTN code for importing a AppintegrationsEventIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppintegrationsEventIntegration to import
    * @param importFromId The id of the existing AppintegrationsEventIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppintegrationsEventIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appintegrations_event_integration awscc_appintegrations_event_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppintegrationsEventIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: AppintegrationsEventIntegrationConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _eventBridgeBus?;
    get eventBridgeBus(): string;
    set eventBridgeBus(value: string);
    get eventBridgeBusInput(): string | undefined;
    private _eventFilter;
    get eventFilter(): AppintegrationsEventIntegrationEventFilterOutputReference;
    putEventFilter(value: AppintegrationsEventIntegrationEventFilter): void;
    get eventFilterInput(): cdktn.IResolvable | AppintegrationsEventIntegrationEventFilter | undefined;
    get eventIntegrationArn(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): AppintegrationsEventIntegrationTagsList;
    putTags(value: AppintegrationsEventIntegrationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppintegrationsEventIntegrationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
