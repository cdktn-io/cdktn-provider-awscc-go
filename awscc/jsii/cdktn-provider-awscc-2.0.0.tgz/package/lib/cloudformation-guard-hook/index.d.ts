/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationGuardHookConfig extends cdktn.TerraformMetaArguments {
    /**
    * The typename alias for the hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#alias CloudformationGuardHook#alias}
    */
    readonly alias: string;
    /**
    * The execution role ARN assumed by hooks to read Guard rules from S3 and write Guard outputs to S3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#execution_role CloudformationGuardHook#execution_role}
    */
    readonly executionRole: string;
    /**
    * Attribute to specify CloudFormation behavior on hook failure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#failure_mode CloudformationGuardHook#failure_mode}
    */
    readonly failureMode?: string;
    /**
    * Attribute to specify which stacks this hook applies to or should get invoked for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#hook_status CloudformationGuardHook#hook_status}
    */
    readonly hookStatus?: string;
    /**
    * S3 Bucket where the guard validate report will be uploaded to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#log_bucket CloudformationGuardHook#log_bucket}
    */
    readonly logBucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#options CloudformationGuardHook#options}
    */
    readonly options?: CloudformationGuardHookOptions;
    /**
    * S3 Source Location for the Guard files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#rule_location CloudformationGuardHook#rule_location}
    */
    readonly ruleLocation: CloudformationGuardHookRuleLocation;
    /**
    * Filters to allow hooks to target specific stack attributes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#stack_filters CloudformationGuardHook#stack_filters}
    */
    readonly stackFilters?: CloudformationGuardHookStackFilters;
    /**
    * Attribute to specify which targets should invoke the hook
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#target_filters CloudformationGuardHook#target_filters}
    */
    readonly targetFilters?: CloudformationGuardHookTargetFilters;
    /**
    * Which operations should this Hook run against? Resource changes, stacks or change sets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#target_operations CloudformationGuardHook#target_operations}
    */
    readonly targetOperations: string[];
}
export interface CloudformationGuardHookOptions {
    /**
    * Specifies the S3 location of input parameter files for your Guard rules. You can specify either a single S3 location or an array of up to 10 S3 locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#input_params CloudformationGuardHook#input_params}
    */
    readonly inputParams?: string;
}
export declare function cloudformationGuardHookOptionsToTerraform(struct?: CloudformationGuardHookOptions | cdktn.IResolvable): any;
export declare function cloudformationGuardHookOptionsToHclTerraform(struct?: CloudformationGuardHookOptions | cdktn.IResolvable): any;
export declare class CloudformationGuardHookOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationGuardHookOptions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationGuardHookOptions | cdktn.IResolvable | undefined);
    private _inputParams?;
    get inputParams(): string;
    set inputParams(value: string);
    resetInputParams(): void;
    get inputParamsInput(): string | undefined;
}
export interface CloudformationGuardHookRuleLocation {
    /**
    * S3 uri of Guard files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#uri CloudformationGuardHook#uri}
    */
    readonly uri: string;
    /**
    * S3 object version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#version_id CloudformationGuardHook#version_id}
    */
    readonly versionId?: string;
}
export declare function cloudformationGuardHookRuleLocationToTerraform(struct?: CloudformationGuardHookRuleLocation | cdktn.IResolvable): any;
export declare function cloudformationGuardHookRuleLocationToHclTerraform(struct?: CloudformationGuardHookRuleLocation | cdktn.IResolvable): any;
export declare class CloudformationGuardHookRuleLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationGuardHookRuleLocation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationGuardHookRuleLocation | cdktn.IResolvable | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
}
export interface CloudformationGuardHookStackFiltersStackNames {
    /**
    * List of stack names that the hook is going to be excluded from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#exclude CloudformationGuardHook#exclude}
    */
    readonly exclude?: string[];
    /**
    * List of stack names that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#include CloudformationGuardHook#include}
    */
    readonly include?: string[];
}
export declare function cloudformationGuardHookStackFiltersStackNamesToTerraform(struct?: CloudformationGuardHookStackFiltersStackNames | cdktn.IResolvable): any;
export declare function cloudformationGuardHookStackFiltersStackNamesToHclTerraform(struct?: CloudformationGuardHookStackFiltersStackNames | cdktn.IResolvable): any;
export declare class CloudformationGuardHookStackFiltersStackNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationGuardHookStackFiltersStackNames | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationGuardHookStackFiltersStackNames | cdktn.IResolvable | undefined);
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface CloudformationGuardHookStackFiltersStackRoles {
    /**
    * List of stack roles that the hook is going to be excluded from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#exclude CloudformationGuardHook#exclude}
    */
    readonly exclude?: string[];
    /**
    * List of stack roles that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#include CloudformationGuardHook#include}
    */
    readonly include?: string[];
}
export declare function cloudformationGuardHookStackFiltersStackRolesToTerraform(struct?: CloudformationGuardHookStackFiltersStackRoles | cdktn.IResolvable): any;
export declare function cloudformationGuardHookStackFiltersStackRolesToHclTerraform(struct?: CloudformationGuardHookStackFiltersStackRoles | cdktn.IResolvable): any;
export declare class CloudformationGuardHookStackFiltersStackRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationGuardHookStackFiltersStackRoles | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationGuardHookStackFiltersStackRoles | cdktn.IResolvable | undefined);
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface CloudformationGuardHookStackFilters {
    /**
    * Attribute to specify the filtering behavior. ANY will make the Hook pass if one filter matches. ALL will make the Hook pass if all filters match
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#filtering_criteria CloudformationGuardHook#filtering_criteria}
    */
    readonly filteringCriteria?: string;
    /**
    * List of stack names as filters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#stack_names CloudformationGuardHook#stack_names}
    */
    readonly stackNames?: CloudformationGuardHookStackFiltersStackNames;
    /**
    * List of stack roles that are performing the stack operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#stack_roles CloudformationGuardHook#stack_roles}
    */
    readonly stackRoles?: CloudformationGuardHookStackFiltersStackRoles;
}
export declare function cloudformationGuardHookStackFiltersToTerraform(struct?: CloudformationGuardHookStackFilters | cdktn.IResolvable): any;
export declare function cloudformationGuardHookStackFiltersToHclTerraform(struct?: CloudformationGuardHookStackFilters | cdktn.IResolvable): any;
export declare class CloudformationGuardHookStackFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationGuardHookStackFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationGuardHookStackFilters | cdktn.IResolvable | undefined);
    private _filteringCriteria?;
    get filteringCriteria(): string;
    set filteringCriteria(value: string);
    resetFilteringCriteria(): void;
    get filteringCriteriaInput(): string | undefined;
    private _stackNames;
    get stackNames(): CloudformationGuardHookStackFiltersStackNamesOutputReference;
    putStackNames(value: CloudformationGuardHookStackFiltersStackNames): void;
    resetStackNames(): void;
    get stackNamesInput(): cdktn.IResolvable | CloudformationGuardHookStackFiltersStackNames | undefined;
    private _stackRoles;
    get stackRoles(): CloudformationGuardHookStackFiltersStackRolesOutputReference;
    putStackRoles(value: CloudformationGuardHookStackFiltersStackRoles): void;
    resetStackRoles(): void;
    get stackRolesInput(): cdktn.IResolvable | CloudformationGuardHookStackFiltersStackRoles | undefined;
}
export interface CloudformationGuardHookTargetFiltersTargets {
    /**
    * Target actions are the type of operation hooks will be executed at.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#action CloudformationGuardHook#action}
    */
    readonly action?: string;
    /**
    * Invocation points are the point in provisioning workflow where hooks will be executed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#invocation_point CloudformationGuardHook#invocation_point}
    */
    readonly invocationPoint?: string;
    /**
    * Type name of hook target. Hook targets are the destination where hooks will be invoked against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#target_name CloudformationGuardHook#target_name}
    */
    readonly targetName?: string;
}
export declare function cloudformationGuardHookTargetFiltersTargetsToTerraform(struct?: CloudformationGuardHookTargetFiltersTargets | cdktn.IResolvable): any;
export declare function cloudformationGuardHookTargetFiltersTargetsToHclTerraform(struct?: CloudformationGuardHookTargetFiltersTargets | cdktn.IResolvable): any;
export declare class CloudformationGuardHookTargetFiltersTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationGuardHookTargetFiltersTargets | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationGuardHookTargetFiltersTargets | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _invocationPoint?;
    get invocationPoint(): string;
    set invocationPoint(value: string);
    resetInvocationPoint(): void;
    get invocationPointInput(): string | undefined;
    private _targetName?;
    get targetName(): string;
    set targetName(value: string);
    resetTargetName(): void;
    get targetNameInput(): string | undefined;
}
export declare class CloudformationGuardHookTargetFiltersTargetsList extends cdktn.ComplexList {
    internalValue?: CloudformationGuardHookTargetFiltersTargets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationGuardHookTargetFiltersTargetsOutputReference;
}
export interface CloudformationGuardHookTargetFilters {
    /**
    * List of actions that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#actions CloudformationGuardHook#actions}
    */
    readonly actions?: string[];
    /**
    * List of invocation points that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#invocation_points CloudformationGuardHook#invocation_points}
    */
    readonly invocationPoints?: string[];
    /**
    * List of type names that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#target_names CloudformationGuardHook#target_names}
    */
    readonly targetNames?: string[];
    /**
    * List of hook targets
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#targets CloudformationGuardHook#targets}
    */
    readonly targets?: CloudformationGuardHookTargetFiltersTargets[] | cdktn.IResolvable;
}
export declare function cloudformationGuardHookTargetFiltersToTerraform(struct?: CloudformationGuardHookTargetFilters | cdktn.IResolvable): any;
export declare function cloudformationGuardHookTargetFiltersToHclTerraform(struct?: CloudformationGuardHookTargetFilters | cdktn.IResolvable): any;
export declare class CloudformationGuardHookTargetFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationGuardHookTargetFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationGuardHookTargetFilters | cdktn.IResolvable | undefined);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    resetActions(): void;
    get actionsInput(): string[] | undefined;
    private _invocationPoints?;
    get invocationPoints(): string[];
    set invocationPoints(value: string[]);
    resetInvocationPoints(): void;
    get invocationPointsInput(): string[] | undefined;
    private _targetNames?;
    get targetNames(): string[];
    set targetNames(value: string[]);
    resetTargetNames(): void;
    get targetNamesInput(): string[] | undefined;
    private _targets;
    get targets(): CloudformationGuardHookTargetFiltersTargetsList;
    putTargets(value: CloudformationGuardHookTargetFiltersTargets[] | cdktn.IResolvable): void;
    resetTargets(): void;
    get targetsInput(): cdktn.IResolvable | CloudformationGuardHookTargetFiltersTargets[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook awscc_cloudformation_guard_hook}
*/
export declare class CloudformationGuardHook extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_guard_hook";
    /**
    * Generates CDKTN code for importing a CloudformationGuardHook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationGuardHook to import
    * @param importFromId The id of the existing CloudformationGuardHook that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationGuardHook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_guard_hook awscc_cloudformation_guard_hook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationGuardHookConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationGuardHookConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    get aliasInput(): string | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    get executionRoleInput(): string | undefined;
    private _failureMode?;
    get failureMode(): string;
    set failureMode(value: string);
    resetFailureMode(): void;
    get failureModeInput(): string | undefined;
    get hookArn(): string;
    private _hookStatus?;
    get hookStatus(): string;
    set hookStatus(value: string);
    resetHookStatus(): void;
    get hookStatusInput(): string | undefined;
    get id(): string;
    private _logBucket?;
    get logBucket(): string;
    set logBucket(value: string);
    resetLogBucket(): void;
    get logBucketInput(): string | undefined;
    private _options;
    get options(): CloudformationGuardHookOptionsOutputReference;
    putOptions(value: CloudformationGuardHookOptions): void;
    resetOptions(): void;
    get optionsInput(): cdktn.IResolvable | CloudformationGuardHookOptions | undefined;
    private _ruleLocation;
    get ruleLocation(): CloudformationGuardHookRuleLocationOutputReference;
    putRuleLocation(value: CloudformationGuardHookRuleLocation): void;
    get ruleLocationInput(): cdktn.IResolvable | CloudformationGuardHookRuleLocation | undefined;
    private _stackFilters;
    get stackFilters(): CloudformationGuardHookStackFiltersOutputReference;
    putStackFilters(value: CloudformationGuardHookStackFilters): void;
    resetStackFilters(): void;
    get stackFiltersInput(): cdktn.IResolvable | CloudformationGuardHookStackFilters | undefined;
    private _targetFilters;
    get targetFilters(): CloudformationGuardHookTargetFiltersOutputReference;
    putTargetFilters(value: CloudformationGuardHookTargetFilters): void;
    resetTargetFilters(): void;
    get targetFiltersInput(): cdktn.IResolvable | CloudformationGuardHookTargetFilters | undefined;
    private _targetOperations?;
    get targetOperations(): string[];
    set targetOperations(value: string[]);
    get targetOperationsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
