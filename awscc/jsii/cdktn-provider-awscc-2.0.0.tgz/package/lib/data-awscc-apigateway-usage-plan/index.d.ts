/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayUsagePlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigateway_usage_plan#id DataAwsccApigatewayUsagePlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayUsagePlanApiStagesThrottle {
}
export declare function dataAwsccApigatewayUsagePlanApiStagesThrottleToTerraform(struct?: DataAwsccApigatewayUsagePlanApiStagesThrottle): any;
export declare function dataAwsccApigatewayUsagePlanApiStagesThrottleToHclTerraform(struct?: DataAwsccApigatewayUsagePlanApiStagesThrottle): any;
export declare class DataAwsccApigatewayUsagePlanApiStagesThrottleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataAwsccApigatewayUsagePlanApiStagesThrottle | undefined;
    set internalValue(value: DataAwsccApigatewayUsagePlanApiStagesThrottle | undefined);
    get burstLimit(): number;
    get rateLimit(): number;
}
export declare class DataAwsccApigatewayUsagePlanApiStagesThrottleMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataAwsccApigatewayUsagePlanApiStagesThrottleOutputReference;
}
export interface DataAwsccApigatewayUsagePlanApiStages {
}
export declare function dataAwsccApigatewayUsagePlanApiStagesToTerraform(struct?: DataAwsccApigatewayUsagePlanApiStages): any;
export declare function dataAwsccApigatewayUsagePlanApiStagesToHclTerraform(struct?: DataAwsccApigatewayUsagePlanApiStages): any;
export declare class DataAwsccApigatewayUsagePlanApiStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayUsagePlanApiStages | undefined;
    set internalValue(value: DataAwsccApigatewayUsagePlanApiStages | undefined);
    get apiId(): string;
    get stage(): string;
    private _throttle;
    get throttle(): DataAwsccApigatewayUsagePlanApiStagesThrottleMap;
}
export declare class DataAwsccApigatewayUsagePlanApiStagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayUsagePlanApiStagesOutputReference;
}
export interface DataAwsccApigatewayUsagePlanQuota {
}
export declare function dataAwsccApigatewayUsagePlanQuotaToTerraform(struct?: DataAwsccApigatewayUsagePlanQuota): any;
export declare function dataAwsccApigatewayUsagePlanQuotaToHclTerraform(struct?: DataAwsccApigatewayUsagePlanQuota): any;
export declare class DataAwsccApigatewayUsagePlanQuotaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayUsagePlanQuota | undefined;
    set internalValue(value: DataAwsccApigatewayUsagePlanQuota | undefined);
    get limit(): number;
    get offset(): number;
    get period(): string;
}
export interface DataAwsccApigatewayUsagePlanTags {
}
export declare function dataAwsccApigatewayUsagePlanTagsToTerraform(struct?: DataAwsccApigatewayUsagePlanTags): any;
export declare function dataAwsccApigatewayUsagePlanTagsToHclTerraform(struct?: DataAwsccApigatewayUsagePlanTags): any;
export declare class DataAwsccApigatewayUsagePlanTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayUsagePlanTags | undefined;
    set internalValue(value: DataAwsccApigatewayUsagePlanTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayUsagePlanTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayUsagePlanTagsOutputReference;
}
export interface DataAwsccApigatewayUsagePlanThrottle {
}
export declare function dataAwsccApigatewayUsagePlanThrottleToTerraform(struct?: DataAwsccApigatewayUsagePlanThrottle): any;
export declare function dataAwsccApigatewayUsagePlanThrottleToHclTerraform(struct?: DataAwsccApigatewayUsagePlanThrottle): any;
export declare class DataAwsccApigatewayUsagePlanThrottleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayUsagePlanThrottle | undefined;
    set internalValue(value: DataAwsccApigatewayUsagePlanThrottle | undefined);
    get burstLimit(): number;
    get rateLimit(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigateway_usage_plan awscc_apigateway_usage_plan}
*/
export declare class DataAwsccApigatewayUsagePlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_usage_plan";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayUsagePlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayUsagePlan to import
    * @param importFromId The id of the existing DataAwsccApigatewayUsagePlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigateway_usage_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayUsagePlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/apigateway_usage_plan awscc_apigateway_usage_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayUsagePlanConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayUsagePlanConfig);
    private _apiStages;
    get apiStages(): DataAwsccApigatewayUsagePlanApiStagesList;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _quota;
    get quota(): DataAwsccApigatewayUsagePlanQuotaOutputReference;
    private _tags;
    get tags(): DataAwsccApigatewayUsagePlanTagsList;
    private _throttle;
    get throttle(): DataAwsccApigatewayUsagePlanThrottleOutputReference;
    get usagePlanId(): string;
    get usagePlanName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
