/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Apigatewayv2StageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Settings for logging access in this stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#access_log_settings Apigatewayv2Stage#access_log_settings}
    */
    readonly accessLogSettings?: Apigatewayv2StageAccessLogSettings;
    /**
    * The API identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#api_id Apigatewayv2Stage#api_id}
    */
    readonly apiId: string;
    /**
    * Specifies whether updates to an API automatically trigger a new deployment. The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#auto_deploy Apigatewayv2Stage#auto_deploy}
    */
    readonly autoDeploy?: boolean | cdktn.IResolvable;
    /**
    * The identifier of a client certificate for a Stage. Supported only for WebSocket APIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#client_certificate_id Apigatewayv2Stage#client_certificate_id}
    */
    readonly clientCertificateId?: string;
    /**
    * The default route settings for the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#default_route_settings Apigatewayv2Stage#default_route_settings}
    */
    readonly defaultRouteSettings?: Apigatewayv2StageDefaultRouteSettings;
    /**
    * The deployment identifier for the API stage. Can't be updated if autoDeploy is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#deployment_id Apigatewayv2Stage#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * The description for the API stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#description Apigatewayv2Stage#description}
    */
    readonly description?: string;
    /**
    * Route settings for the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#route_settings Apigatewayv2Stage#route_settings}
    */
    readonly routeSettings?: string;
    /**
    * The stage name. Stage names can contain only alphanumeric characters, hyphens, and underscores, or be $default. Maximum length is 128 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#stage_name Apigatewayv2Stage#stage_name}
    */
    readonly stageName: string;
    /**
    * A map that defines the stage variables for a Stage. Variable names can have alphanumeric and underscore characters, and the values must match [A-Za-z0-9-._~:/?#&=,]+.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#stage_variables Apigatewayv2Stage#stage_variables}
    */
    readonly stageVariables?: string;
    /**
    * The collection of tags. Each tag element is associated with a given resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#tags Apigatewayv2Stage#tags}
    */
    readonly tags?: string;
}
export interface Apigatewayv2StageAccessLogSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#destination_arn Apigatewayv2Stage#destination_arn}
    */
    readonly destinationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#format Apigatewayv2Stage#format}
    */
    readonly format?: string;
}
export declare function apigatewayv2StageAccessLogSettingsToTerraform(struct?: Apigatewayv2StageAccessLogSettings | cdktn.IResolvable): any;
export declare function apigatewayv2StageAccessLogSettingsToHclTerraform(struct?: Apigatewayv2StageAccessLogSettings | cdktn.IResolvable): any;
export declare class Apigatewayv2StageAccessLogSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2StageAccessLogSettings | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2StageAccessLogSettings | cdktn.IResolvable | undefined);
    private _destinationArn?;
    get destinationArn(): string;
    set destinationArn(value: string);
    resetDestinationArn(): void;
    get destinationArnInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
}
export interface Apigatewayv2StageDefaultRouteSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#data_trace_enabled Apigatewayv2Stage#data_trace_enabled}
    */
    readonly dataTraceEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#detailed_metrics_enabled Apigatewayv2Stage#detailed_metrics_enabled}
    */
    readonly detailedMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#logging_level Apigatewayv2Stage#logging_level}
    */
    readonly loggingLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#throttling_burst_limit Apigatewayv2Stage#throttling_burst_limit}
    */
    readonly throttlingBurstLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#throttling_rate_limit Apigatewayv2Stage#throttling_rate_limit}
    */
    readonly throttlingRateLimit?: number;
}
export declare function apigatewayv2StageDefaultRouteSettingsToTerraform(struct?: Apigatewayv2StageDefaultRouteSettings | cdktn.IResolvable): any;
export declare function apigatewayv2StageDefaultRouteSettingsToHclTerraform(struct?: Apigatewayv2StageDefaultRouteSettings | cdktn.IResolvable): any;
export declare class Apigatewayv2StageDefaultRouteSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2StageDefaultRouteSettings | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2StageDefaultRouteSettings | cdktn.IResolvable | undefined);
    private _dataTraceEnabled?;
    get dataTraceEnabled(): boolean | cdktn.IResolvable;
    set dataTraceEnabled(value: boolean | cdktn.IResolvable);
    resetDataTraceEnabled(): void;
    get dataTraceEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _detailedMetricsEnabled?;
    get detailedMetricsEnabled(): boolean | cdktn.IResolvable;
    set detailedMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetDetailedMetricsEnabled(): void;
    get detailedMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _loggingLevel?;
    get loggingLevel(): string;
    set loggingLevel(value: string);
    resetLoggingLevel(): void;
    get loggingLevelInput(): string | undefined;
    private _throttlingBurstLimit?;
    get throttlingBurstLimit(): number;
    set throttlingBurstLimit(value: number);
    resetThrottlingBurstLimit(): void;
    get throttlingBurstLimitInput(): number | undefined;
    private _throttlingRateLimit?;
    get throttlingRateLimit(): number;
    set throttlingRateLimit(value: number);
    resetThrottlingRateLimit(): void;
    get throttlingRateLimitInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage awscc_apigatewayv2_stage}
*/
export declare class Apigatewayv2Stage extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigatewayv2_stage";
    /**
    * Generates CDKTN code for importing a Apigatewayv2Stage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Apigatewayv2Stage to import
    * @param importFromId The id of the existing Apigatewayv2Stage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Apigatewayv2Stage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_stage awscc_apigatewayv2_stage} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Apigatewayv2StageConfig
    */
    constructor(scope: Construct, id: string, config: Apigatewayv2StageConfig);
    private _accessLogSettings;
    get accessLogSettings(): Apigatewayv2StageAccessLogSettingsOutputReference;
    putAccessLogSettings(value: Apigatewayv2StageAccessLogSettings): void;
    resetAccessLogSettings(): void;
    get accessLogSettingsInput(): cdktn.IResolvable | Apigatewayv2StageAccessLogSettings | undefined;
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _autoDeploy?;
    get autoDeploy(): boolean | cdktn.IResolvable;
    set autoDeploy(value: boolean | cdktn.IResolvable);
    resetAutoDeploy(): void;
    get autoDeployInput(): boolean | cdktn.IResolvable | undefined;
    private _clientCertificateId?;
    get clientCertificateId(): string;
    set clientCertificateId(value: string);
    resetClientCertificateId(): void;
    get clientCertificateIdInput(): string | undefined;
    private _defaultRouteSettings;
    get defaultRouteSettings(): Apigatewayv2StageDefaultRouteSettingsOutputReference;
    putDefaultRouteSettings(value: Apigatewayv2StageDefaultRouteSettings): void;
    resetDefaultRouteSettings(): void;
    get defaultRouteSettingsInput(): cdktn.IResolvable | Apigatewayv2StageDefaultRouteSettings | undefined;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _routeSettings?;
    get routeSettings(): string;
    set routeSettings(value: string);
    resetRouteSettings(): void;
    get routeSettingsInput(): string | undefined;
    private _stageName?;
    get stageName(): string;
    set stageName(value: string);
    get stageNameInput(): string | undefined;
    private _stageVariables?;
    get stageVariables(): string;
    set stageVariables(value: string);
    resetStageVariables(): void;
    get stageVariablesInput(): string | undefined;
    private _tags?;
    get tags(): string;
    set tags(value: string);
    resetTags(): void;
    get tagsInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
