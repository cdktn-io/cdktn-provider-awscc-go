/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Connectcampaignsv2CampaignConfig extends cdktn.TerraformMetaArguments {
    /**
    * The possible types of channel subtype config parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#channel_subtype_config Connectcampaignsv2Campaign#channel_subtype_config}
    */
    readonly channelSubtypeConfig?: Connectcampaignsv2CampaignChannelSubtypeConfig;
    /**
    * Communication limits config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#communication_limits_override Connectcampaignsv2Campaign#communication_limits_override}
    */
    readonly communicationLimitsOverride?: Connectcampaignsv2CampaignCommunicationLimitsOverride;
    /**
    * Campaign communication time config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#communication_time_config Connectcampaignsv2Campaign#communication_time_config}
    */
    readonly communicationTimeConfig?: Connectcampaignsv2CampaignCommunicationTimeConfig;
    /**
    * Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#connect_campaign_flow_arn Connectcampaignsv2Campaign#connect_campaign_flow_arn}
    */
    readonly connectCampaignFlowArn?: string;
    /**
    * Amazon Connect Instance Id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#connect_instance_id Connectcampaignsv2Campaign#connect_instance_id}
    */
    readonly connectInstanceId: string;
    /**
    * Entry limits config for a campaign
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#entry_limits_config Connectcampaignsv2Campaign#entry_limits_config}
    */
    readonly entryLimitsConfig?: Connectcampaignsv2CampaignEntryLimitsConfig;
    /**
    * Campaign name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#name Connectcampaignsv2Campaign#name}
    */
    readonly name: string;
    /**
    * Campaign schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#schedule Connectcampaignsv2Campaign#schedule}
    */
    readonly schedule?: Connectcampaignsv2CampaignSchedule;
    /**
    * The possible source of the campaign
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#source Connectcampaignsv2Campaign#source}
    */
    readonly source?: Connectcampaignsv2CampaignSource;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#tags Connectcampaignsv2Campaign#tags}
    */
    readonly tags?: Connectcampaignsv2CampaignTags[] | cdktn.IResolvable;
    /**
    * Campaign type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#type Connectcampaignsv2Campaign#type}
    */
    readonly type?: string;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfig {
    /**
    * Email address used for Email messages
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#connect_source_email_address Connectcampaignsv2Campaign#connect_source_email_address}
    */
    readonly connectSourceEmailAddress?: string;
    /**
    * The name of the source email address display name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#source_email_address_display_name Connectcampaignsv2Campaign#source_email_address_display_name}
    */
    readonly sourceEmailAddressDisplayName?: string;
    /**
    * Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#wisdom_template_arn Connectcampaignsv2Campaign#wisdom_template_arn}
    */
    readonly wisdomTemplateArn?: string;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfig | cdktn.IResolvable | undefined);
    private _connectSourceEmailAddress?;
    get connectSourceEmailAddress(): string;
    set connectSourceEmailAddress(value: string);
    resetConnectSourceEmailAddress(): void;
    get connectSourceEmailAddressInput(): string | undefined;
    private _sourceEmailAddressDisplayName?;
    get sourceEmailAddressDisplayName(): string;
    set sourceEmailAddressDisplayName(value: string);
    resetSourceEmailAddressDisplayName(): void;
    get sourceEmailAddressDisplayNameInput(): string | undefined;
    private _wisdomTemplateArn?;
    get wisdomTemplateArn(): string;
    set wisdomTemplateArn(value: string);
    resetWisdomTemplateArn(): void;
    get wisdomTemplateArnInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundMode {
    /**
    * Agentless config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#agentless_config Connectcampaignsv2Campaign#agentless_config}
    */
    readonly agentlessConfig?: string;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundModeToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundMode | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundModeToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundMode | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundMode | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundMode | cdktn.IResolvable | undefined);
    private _agentlessConfig?;
    get agentlessConfig(): string;
    set agentlessConfig(value: string);
    resetAgentlessConfig(): void;
    get agentlessConfigInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigEmail {
    /**
    * Allocates outbound capacity for the specific channel of this campaign between multiple active campaigns
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#capacity Connectcampaignsv2Campaign#capacity}
    */
    readonly capacity?: number;
    /**
    * Default Email outbound config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#default_outbound_config Connectcampaignsv2Campaign#default_outbound_config}
    */
    readonly defaultOutboundConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfig;
    /**
    * Email Outbound Mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#outbound_mode Connectcampaignsv2Campaign#outbound_mode}
    */
    readonly outboundMode?: Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundMode;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigEmailToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigEmail | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigEmailToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigEmail | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigEmail | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigEmail | cdktn.IResolvable | undefined);
    private _capacity?;
    get capacity(): number;
    set capacity(value: number);
    resetCapacity(): void;
    get capacityInput(): number | undefined;
    private _defaultOutboundConfig;
    get defaultOutboundConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfigOutputReference;
    putDefaultOutboundConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfig): void;
    resetDefaultOutboundConfig(): void;
    get defaultOutboundConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigEmailDefaultOutboundConfig | undefined;
    private _outboundMode;
    get outboundMode(): Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundModeOutputReference;
    putOutboundMode(value: Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundMode): void;
    resetOutboundMode(): void;
    get outboundModeInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutboundMode | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfig {
    /**
    * Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#connect_source_phone_number_arn Connectcampaignsv2Campaign#connect_source_phone_number_arn}
    */
    readonly connectSourcePhoneNumberArn?: string;
    /**
    * Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#wisdom_template_arn Connectcampaignsv2Campaign#wisdom_template_arn}
    */
    readonly wisdomTemplateArn?: string;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfig | cdktn.IResolvable | undefined);
    private _connectSourcePhoneNumberArn?;
    get connectSourcePhoneNumberArn(): string;
    set connectSourcePhoneNumberArn(value: string);
    resetConnectSourcePhoneNumberArn(): void;
    get connectSourcePhoneNumberArnInput(): string | undefined;
    private _wisdomTemplateArn?;
    get wisdomTemplateArn(): string;
    set wisdomTemplateArn(value: string);
    resetWisdomTemplateArn(): void;
    get wisdomTemplateArnInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundMode {
    /**
    * Agentless config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#agentless_config Connectcampaignsv2Campaign#agentless_config}
    */
    readonly agentlessConfig?: string;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundModeToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundMode | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundModeToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundMode | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundMode | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundMode | cdktn.IResolvable | undefined);
    private _agentlessConfig?;
    get agentlessConfig(): string;
    set agentlessConfig(value: string);
    resetAgentlessConfig(): void;
    get agentlessConfigInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigSms {
    /**
    * Allocates outbound capacity for the specific channel of this campaign between multiple active campaigns
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#capacity Connectcampaignsv2Campaign#capacity}
    */
    readonly capacity?: number;
    /**
    * Default SMS outbound config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#default_outbound_config Connectcampaignsv2Campaign#default_outbound_config}
    */
    readonly defaultOutboundConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfig;
    /**
    * SMS Outbound Mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#outbound_mode Connectcampaignsv2Campaign#outbound_mode}
    */
    readonly outboundMode?: Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundMode;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigSmsToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigSms | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigSmsToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigSms | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigSms | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigSms | cdktn.IResolvable | undefined);
    private _capacity?;
    get capacity(): number;
    set capacity(value: number);
    resetCapacity(): void;
    get capacityInput(): number | undefined;
    private _defaultOutboundConfig;
    get defaultOutboundConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfigOutputReference;
    putDefaultOutboundConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfig): void;
    resetDefaultOutboundConfig(): void;
    get defaultOutboundConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigSmsDefaultOutboundConfig | undefined;
    private _outboundMode;
    get outboundMode(): Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundModeOutputReference;
    putOutboundMode(value: Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundMode): void;
    resetOutboundMode(): void;
    get outboundModeInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutboundMode | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfig {
    /**
    * Enables detection of prompts (e.g., beep after after a voicemail greeting)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#await_answer_machine_prompt Connectcampaignsv2Campaign#await_answer_machine_prompt}
    */
    readonly awaitAnswerMachinePrompt?: boolean | cdktn.IResolvable;
    /**
    * Flag to decided whether outbound calls should have answering machine detection enabled or not
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#enable_answer_machine_detection Connectcampaignsv2Campaign#enable_answer_machine_detection}
    */
    readonly enableAnswerMachineDetection?: boolean | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfig | cdktn.IResolvable | undefined);
    private _awaitAnswerMachinePrompt?;
    get awaitAnswerMachinePrompt(): boolean | cdktn.IResolvable;
    set awaitAnswerMachinePrompt(value: boolean | cdktn.IResolvable);
    resetAwaitAnswerMachinePrompt(): void;
    get awaitAnswerMachinePromptInput(): boolean | cdktn.IResolvable | undefined;
    private _enableAnswerMachineDetection?;
    get enableAnswerMachineDetection(): boolean | cdktn.IResolvable;
    set enableAnswerMachineDetection(value: boolean | cdktn.IResolvable);
    resetEnableAnswerMachineDetection(): void;
    get enableAnswerMachineDetectionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfig {
    /**
    * The configuration used for answering machine detection during outbound calls
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#answer_machine_detection_config Connectcampaignsv2Campaign#answer_machine_detection_config}
    */
    readonly answerMachineDetectionConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfig;
    /**
    * The identifier of the contact flow for the outbound call
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#connect_contact_flow_id Connectcampaignsv2Campaign#connect_contact_flow_id}
    */
    readonly connectContactFlowId?: string;
    /**
    * The phone number associated with the Amazon Connect instance, in E.164 format. If you do not specify a source phone number, you must specify a queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#connect_source_phone_number Connectcampaignsv2Campaign#connect_source_phone_number}
    */
    readonly connectSourcePhoneNumber?: string;
    /**
    * Maximum ring time for outbound calls in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#ring_timeout Connectcampaignsv2Campaign#ring_timeout}
    */
    readonly ringTimeout?: number;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfig | cdktn.IResolvable | undefined);
    private _answerMachineDetectionConfig;
    get answerMachineDetectionConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfigOutputReference;
    putAnswerMachineDetectionConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfig): void;
    resetAnswerMachineDetectionConfig(): void;
    get answerMachineDetectionConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigAnswerMachineDetectionConfig | undefined;
    private _connectContactFlowId?;
    get connectContactFlowId(): string;
    set connectContactFlowId(value: string);
    resetConnectContactFlowId(): void;
    get connectContactFlowIdInput(): string | undefined;
    private _connectSourcePhoneNumber?;
    get connectSourcePhoneNumber(): string;
    set connectSourcePhoneNumber(value: string);
    resetConnectSourcePhoneNumber(): void;
    get connectSourcePhoneNumberInput(): string | undefined;
    private _ringTimeout?;
    get ringTimeout(): number;
    set ringTimeout(value: number);
    resetRingTimeout(): void;
    get ringTimeoutInput(): number | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfig {
    /**
    * The bandwidth allocation of a queue resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#bandwidth_allocation Connectcampaignsv2Campaign#bandwidth_allocation}
    */
    readonly bandwidthAllocation?: number;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfig | cdktn.IResolvable | undefined);
    private _bandwidthAllocation?;
    get bandwidthAllocation(): number;
    set bandwidthAllocation(value: number);
    resetBandwidthAllocation(): void;
    get bandwidthAllocationInput(): number | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfig {
    /**
    * Timeout duration for a preview contact in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#duration_in_seconds Connectcampaignsv2Campaign#duration_in_seconds}
    */
    readonly durationInSeconds?: number;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfig | cdktn.IResolvable | undefined);
    private _durationInSeconds?;
    get durationInSeconds(): number;
    set durationInSeconds(value: number);
    resetDurationInSeconds(): void;
    get durationInSecondsInput(): number | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfig {
    /**
    * Actions that can be performed by agent during preview phase
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#agent_actions Connectcampaignsv2Campaign#agent_actions}
    */
    readonly agentActions?: string[];
    /**
    * The bandwidth allocation of a queue resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#bandwidth_allocation Connectcampaignsv2Campaign#bandwidth_allocation}
    */
    readonly bandwidthAllocation?: number;
    /**
    * Timeout Config for preview contacts
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#timeout_config Connectcampaignsv2Campaign#timeout_config}
    */
    readonly timeoutConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfig;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfig | cdktn.IResolvable | undefined);
    private _agentActions?;
    get agentActions(): string[];
    set agentActions(value: string[]);
    resetAgentActions(): void;
    get agentActionsInput(): string[] | undefined;
    private _bandwidthAllocation?;
    get bandwidthAllocation(): number;
    set bandwidthAllocation(value: number);
    resetBandwidthAllocation(): void;
    get bandwidthAllocationInput(): number | undefined;
    private _timeoutConfig;
    get timeoutConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfigOutputReference;
    putTimeoutConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfig): void;
    resetTimeoutConfig(): void;
    get timeoutConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigTimeoutConfig | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfig {
    /**
    * The bandwidth allocation of a queue resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#bandwidth_allocation Connectcampaignsv2Campaign#bandwidth_allocation}
    */
    readonly bandwidthAllocation?: number;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfig | cdktn.IResolvable | undefined);
    private _bandwidthAllocation?;
    get bandwidthAllocation(): number;
    set bandwidthAllocation(value: number);
    resetBandwidthAllocation(): void;
    get bandwidthAllocationInput(): number | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundMode {
    /**
    * Agentless config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#agentless_config Connectcampaignsv2Campaign#agentless_config}
    */
    readonly agentlessConfig?: string;
    /**
    * Predictive config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#predictive_config Connectcampaignsv2Campaign#predictive_config}
    */
    readonly predictiveConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfig;
    /**
    * Preview config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#preview_config Connectcampaignsv2Campaign#preview_config}
    */
    readonly previewConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfig;
    /**
    * Progressive config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#progressive_config Connectcampaignsv2Campaign#progressive_config}
    */
    readonly progressiveConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfig;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundMode | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundMode | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundMode | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundMode | cdktn.IResolvable | undefined);
    private _agentlessConfig?;
    get agentlessConfig(): string;
    set agentlessConfig(value: string);
    resetAgentlessConfig(): void;
    get agentlessConfigInput(): string | undefined;
    private _predictiveConfig;
    get predictiveConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfigOutputReference;
    putPredictiveConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfig): void;
    resetPredictiveConfig(): void;
    get predictiveConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePredictiveConfig | undefined;
    private _previewConfig;
    get previewConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfigOutputReference;
    putPreviewConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfig): void;
    resetPreviewConfig(): void;
    get previewConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModePreviewConfig | undefined;
    private _progressiveConfig;
    get progressiveConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfigOutputReference;
    putProgressiveConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfig): void;
    resetProgressiveConfig(): void;
    get progressiveConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeProgressiveConfig | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigTelephony {
    /**
    * Allocates outbound capacity for the specific channel of this campaign between multiple active campaigns
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#capacity Connectcampaignsv2Campaign#capacity}
    */
    readonly capacity?: number;
    /**
    * The queue for the call
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#connect_queue_id Connectcampaignsv2Campaign#connect_queue_id}
    */
    readonly connectQueueId?: string;
    /**
    * Default Telephone Outbound config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#default_outbound_config Connectcampaignsv2Campaign#default_outbound_config}
    */
    readonly defaultOutboundConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfig;
    /**
    * Telephony Outbound Mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#outbound_mode Connectcampaignsv2Campaign#outbound_mode}
    */
    readonly outboundMode?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundMode;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephony | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigTelephonyToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephony | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephony | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephony | cdktn.IResolvable | undefined);
    private _capacity?;
    get capacity(): number;
    set capacity(value: number);
    resetCapacity(): void;
    get capacityInput(): number | undefined;
    private _connectQueueId?;
    get connectQueueId(): string;
    set connectQueueId(value: string);
    resetConnectQueueId(): void;
    get connectQueueIdInput(): string | undefined;
    private _defaultOutboundConfig;
    get defaultOutboundConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfigOutputReference;
    putDefaultOutboundConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfig): void;
    resetDefaultOutboundConfig(): void;
    get defaultOutboundConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyDefaultOutboundConfig | undefined;
    private _outboundMode;
    get outboundMode(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundModeOutputReference;
    putOutboundMode(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundMode): void;
    resetOutboundMode(): void;
    get outboundModeInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutboundMode | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfig {
    /**
    * Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#connect_source_phone_number_arn Connectcampaignsv2Campaign#connect_source_phone_number_arn}
    */
    readonly connectSourcePhoneNumberArn?: string;
    /**
    * Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#wisdom_template_arn Connectcampaignsv2Campaign#wisdom_template_arn}
    */
    readonly wisdomTemplateArn?: string;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfig | cdktn.IResolvable | undefined);
    private _connectSourcePhoneNumberArn?;
    get connectSourcePhoneNumberArn(): string;
    set connectSourcePhoneNumberArn(value: string);
    resetConnectSourcePhoneNumberArn(): void;
    get connectSourcePhoneNumberArnInput(): string | undefined;
    private _wisdomTemplateArn?;
    get wisdomTemplateArn(): string;
    set wisdomTemplateArn(value: string);
    resetWisdomTemplateArn(): void;
    get wisdomTemplateArnInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundMode {
    /**
    * Agentless config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#agentless_config Connectcampaignsv2Campaign#agentless_config}
    */
    readonly agentlessConfig?: string;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundModeToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundMode | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundModeToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundMode | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundMode | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundMode | cdktn.IResolvable | undefined);
    private _agentlessConfig?;
    get agentlessConfig(): string;
    set agentlessConfig(value: string);
    resetAgentlessConfig(): void;
    get agentlessConfigInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfigWhatsApp {
    /**
    * Allocates outbound capacity for the specific channel of this campaign between multiple active campaigns
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#capacity Connectcampaignsv2Campaign#capacity}
    */
    readonly capacity?: number;
    /**
    * Default WhatsApp outbound config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#default_outbound_config Connectcampaignsv2Campaign#default_outbound_config}
    */
    readonly defaultOutboundConfig?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfig;
    /**
    * WhatsApp Outbound Mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#outbound_mode Connectcampaignsv2Campaign#outbound_mode}
    */
    readonly outboundMode?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundMode;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsApp | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsApp | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfigWhatsApp | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsApp | cdktn.IResolvable | undefined);
    private _capacity?;
    get capacity(): number;
    set capacity(value: number);
    resetCapacity(): void;
    get capacityInput(): number | undefined;
    private _defaultOutboundConfig;
    get defaultOutboundConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfigOutputReference;
    putDefaultOutboundConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfig): void;
    resetDefaultOutboundConfig(): void;
    get defaultOutboundConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppDefaultOutboundConfig | undefined;
    private _outboundMode;
    get outboundMode(): Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundModeOutputReference;
    putOutboundMode(value: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundMode): void;
    resetOutboundMode(): void;
    get outboundModeInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutboundMode | undefined;
}
export interface Connectcampaignsv2CampaignChannelSubtypeConfig {
    /**
    * Email Channel Subtype config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#email Connectcampaignsv2Campaign#email}
    */
    readonly email?: Connectcampaignsv2CampaignChannelSubtypeConfigEmail;
    /**
    * SMS Channel Subtype config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#sms Connectcampaignsv2Campaign#sms}
    */
    readonly sms?: Connectcampaignsv2CampaignChannelSubtypeConfigSms;
    /**
    * Telephony Channel Subtype config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#telephony Connectcampaignsv2Campaign#telephony}
    */
    readonly telephony?: Connectcampaignsv2CampaignChannelSubtypeConfigTelephony;
    /**
    * WhatsApp Channel Subtype config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#whats_app Connectcampaignsv2Campaign#whats_app}
    */
    readonly whatsApp?: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsApp;
}
export declare function connectcampaignsv2CampaignChannelSubtypeConfigToTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignChannelSubtypeConfigToHclTerraform(struct?: Connectcampaignsv2CampaignChannelSubtypeConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignChannelSubtypeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignChannelSubtypeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignChannelSubtypeConfig | cdktn.IResolvable | undefined);
    private _email;
    get email(): Connectcampaignsv2CampaignChannelSubtypeConfigEmailOutputReference;
    putEmail(value: Connectcampaignsv2CampaignChannelSubtypeConfigEmail): void;
    resetEmail(): void;
    get emailInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigEmail | undefined;
    private _sms;
    get sms(): Connectcampaignsv2CampaignChannelSubtypeConfigSmsOutputReference;
    putSms(value: Connectcampaignsv2CampaignChannelSubtypeConfigSms): void;
    resetSms(): void;
    get smsInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigSms | undefined;
    private _telephony;
    get telephony(): Connectcampaignsv2CampaignChannelSubtypeConfigTelephonyOutputReference;
    putTelephony(value: Connectcampaignsv2CampaignChannelSubtypeConfigTelephony): void;
    resetTelephony(): void;
    get telephonyInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigTelephony | undefined;
    private _whatsApp;
    get whatsApp(): Connectcampaignsv2CampaignChannelSubtypeConfigWhatsAppOutputReference;
    putWhatsApp(value: Connectcampaignsv2CampaignChannelSubtypeConfigWhatsApp): void;
    resetWhatsApp(): void;
    get whatsAppInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfigWhatsApp | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#frequency Connectcampaignsv2Campaign#frequency}
    */
    readonly frequency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#max_count_per_recipient Connectcampaignsv2Campaign#max_count_per_recipient}
    */
    readonly maxCountPerRecipient?: number;
    /**
    * The communication limit time unit
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#unit Connectcampaignsv2Campaign#unit}
    */
    readonly unit?: string;
}
export declare function connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStructToTerraform(struct?: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStructToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct | cdktn.IResolvable | undefined);
    private _frequency?;
    get frequency(): number;
    set frequency(value: number);
    resetFrequency(): void;
    get frequencyInput(): number | undefined;
    private _maxCountPerRecipient?;
    get maxCountPerRecipient(): number;
    set maxCountPerRecipient(value: number);
    resetMaxCountPerRecipient(): void;
    get maxCountPerRecipientInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStructList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStructOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypes {
    /**
    * List of communication limit
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#communication_limit_list Connectcampaignsv2Campaign#communication_limit_list}
    */
    readonly communicationLimitList?: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesToTerraform(struct?: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypes | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypes | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypes | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypes | cdktn.IResolvable | undefined);
    private _communicationLimitList;
    get communicationLimitList(): Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStructList;
    putCommunicationLimitList(value: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct[] | cdktn.IResolvable): void;
    resetCommunicationLimitList(): void;
    get communicationLimitListInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesCommunicationLimitListStruct[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationLimitsOverride {
    /**
    * Communication limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#all_channels_subtypes Connectcampaignsv2Campaign#all_channels_subtypes}
    */
    readonly allChannelsSubtypes?: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypes;
    /**
    * Enumeration of Instance Limits handling in a Campaign
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#instance_limits_handling Connectcampaignsv2Campaign#instance_limits_handling}
    */
    readonly instanceLimitsHandling?: string;
}
export declare function connectcampaignsv2CampaignCommunicationLimitsOverrideToTerraform(struct?: Connectcampaignsv2CampaignCommunicationLimitsOverride | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationLimitsOverrideToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationLimitsOverride | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationLimitsOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationLimitsOverride | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationLimitsOverride | cdktn.IResolvable | undefined);
    private _allChannelsSubtypes;
    get allChannelsSubtypes(): Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypesOutputReference;
    putAllChannelsSubtypes(value: Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypes): void;
    resetAllChannelsSubtypes(): void;
    get allChannelsSubtypesInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationLimitsOverrideAllChannelsSubtypes | undefined;
    private _instanceLimitsHandling?;
    get instanceLimitsHandling(): string;
    set instanceLimitsHandling(value: string);
    resetInstanceLimitsHandling(): void;
    get instanceLimitsHandlingInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue {
    /**
    * Time in ISO 8601 format, e.g. T23:11
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_time Connectcampaignsv2Campaign#end_time}
    */
    readonly endTime?: string;
    /**
    * Time in ISO 8601 format, e.g. T23:11
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_time Connectcampaignsv2Campaign#start_time}
    */
    readonly startTime?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValueToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValueToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValueList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValueOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours {
    /**
    * Day of week
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#key Connectcampaignsv2Campaign#key}
    */
    readonly key?: string;
    /**
    * List of time range
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#value Connectcampaignsv2Campaign#value}
    */
    readonly value?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value;
    get value(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValueList;
    putValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursValue[] | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHours {
    /**
    * Daily Hours map
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#daily_hours Connectcampaignsv2Campaign#daily_hours}
    */
    readonly dailyHours?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHours | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHours | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHours | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHours | cdktn.IResolvable | undefined);
    private _dailyHours;
    get dailyHours(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHoursList;
    putDailyHours(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours[] | cdktn.IResolvable): void;
    resetDailyHours(): void;
    get dailyHoursInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursDailyHours[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct {
    /**
    * Date in ISO 8601 format, e.g. 2024-01-01
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_date Connectcampaignsv2Campaign#end_date}
    */
    readonly endDate?: string;
    /**
    * The name of a restricted period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#name Connectcampaignsv2Campaign#name}
    */
    readonly name?: string;
    /**
    * Date in ISO 8601 format, e.g. 2024-01-01
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_date Connectcampaignsv2Campaign#start_date}
    */
    readonly startDate?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStructToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStructToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable | undefined);
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    resetEndDate(): void;
    get endDateInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStructList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStructOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriods {
    /**
    * List of restricted period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#restricted_period_list Connectcampaignsv2Campaign#restricted_period_list}
    */
    readonly restrictedPeriodList?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriods | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriods | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriods | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriods | cdktn.IResolvable | undefined);
    private _restrictedPeriodList;
    get restrictedPeriodList(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStructList;
    putRestrictedPeriodList(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable): void;
    resetRestrictedPeriodList(): void;
    get restrictedPeriodListInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsRestrictedPeriodListStruct[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigEmail {
    /**
    * Open Hours config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#open_hours Connectcampaignsv2Campaign#open_hours}
    */
    readonly openHours?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHours;
    /**
    * Restricted period config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#restricted_periods Connectcampaignsv2Campaign#restricted_periods}
    */
    readonly restrictedPeriods?: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriods;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmail | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigEmailToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigEmail | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigEmail | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmail | cdktn.IResolvable | undefined);
    private _openHours;
    get openHours(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHoursOutputReference;
    putOpenHours(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHours): void;
    resetOpenHours(): void;
    get openHoursInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigEmailOpenHours | undefined;
    private _restrictedPeriods;
    get restrictedPeriods(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriodsOutputReference;
    putRestrictedPeriods(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriods): void;
    resetRestrictedPeriods(): void;
    get restrictedPeriodsInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigEmailRestrictedPeriods | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfig {
    /**
    * Time Zone Id in the IANA format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#default_time_zone Connectcampaignsv2Campaign#default_time_zone}
    */
    readonly defaultTimeZone?: string;
    /**
    * Local TimeZone Detection method list
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#local_time_zone_detection Connectcampaignsv2Campaign#local_time_zone_detection}
    */
    readonly localTimeZoneDetection?: string[];
    /**
    * Local TimeZone Detection scope
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#local_time_zone_detection_scope Connectcampaignsv2Campaign#local_time_zone_detection_scope}
    */
    readonly localTimeZoneDetectionScope?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfigToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfigToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfig | cdktn.IResolvable | undefined);
    private _defaultTimeZone?;
    get defaultTimeZone(): string;
    set defaultTimeZone(value: string);
    resetDefaultTimeZone(): void;
    get defaultTimeZoneInput(): string | undefined;
    private _localTimeZoneDetection?;
    get localTimeZoneDetection(): string[];
    set localTimeZoneDetection(value: string[]);
    resetLocalTimeZoneDetection(): void;
    get localTimeZoneDetectionInput(): string[] | undefined;
    private _localTimeZoneDetectionScope?;
    get localTimeZoneDetectionScope(): string;
    set localTimeZoneDetectionScope(value: string);
    resetLocalTimeZoneDetectionScope(): void;
    get localTimeZoneDetectionScopeInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue {
    /**
    * Time in ISO 8601 format, e.g. T23:11
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_time Connectcampaignsv2Campaign#end_time}
    */
    readonly endTime?: string;
    /**
    * Time in ISO 8601 format, e.g. T23:11
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_time Connectcampaignsv2Campaign#start_time}
    */
    readonly startTime?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValueToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValueToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValueList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValueOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours {
    /**
    * Day of week
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#key Connectcampaignsv2Campaign#key}
    */
    readonly key?: string;
    /**
    * List of time range
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#value Connectcampaignsv2Campaign#value}
    */
    readonly value?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value;
    get value(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValueList;
    putValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursValue[] | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHours {
    /**
    * Daily Hours map
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#daily_hours Connectcampaignsv2Campaign#daily_hours}
    */
    readonly dailyHours?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHours | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHours | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHours | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHours | cdktn.IResolvable | undefined);
    private _dailyHours;
    get dailyHours(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHoursList;
    putDailyHours(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours[] | cdktn.IResolvable): void;
    resetDailyHours(): void;
    get dailyHoursInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursDailyHours[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct {
    /**
    * Date in ISO 8601 format, e.g. 2024-01-01
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_date Connectcampaignsv2Campaign#end_date}
    */
    readonly endDate?: string;
    /**
    * The name of a restricted period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#name Connectcampaignsv2Campaign#name}
    */
    readonly name?: string;
    /**
    * Date in ISO 8601 format, e.g. 2024-01-01
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_date Connectcampaignsv2Campaign#start_date}
    */
    readonly startDate?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStructToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStructToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable | undefined);
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    resetEndDate(): void;
    get endDateInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStructList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStructOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriods {
    /**
    * List of restricted period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#restricted_period_list Connectcampaignsv2Campaign#restricted_period_list}
    */
    readonly restrictedPeriodList?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriods | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriods | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriods | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriods | cdktn.IResolvable | undefined);
    private _restrictedPeriodList;
    get restrictedPeriodList(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStructList;
    putRestrictedPeriodList(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable): void;
    resetRestrictedPeriodList(): void;
    get restrictedPeriodListInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsRestrictedPeriodListStruct[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigSms {
    /**
    * Open Hours config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#open_hours Connectcampaignsv2Campaign#open_hours}
    */
    readonly openHours?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHours;
    /**
    * Restricted period config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#restricted_periods Connectcampaignsv2Campaign#restricted_periods}
    */
    readonly restrictedPeriods?: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriods;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSms | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigSmsToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigSms | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigSmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigSms | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigSms | cdktn.IResolvable | undefined);
    private _openHours;
    get openHours(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHoursOutputReference;
    putOpenHours(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHours): void;
    resetOpenHours(): void;
    get openHoursInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigSmsOpenHours | undefined;
    private _restrictedPeriods;
    get restrictedPeriods(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriodsOutputReference;
    putRestrictedPeriods(value: Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriods): void;
    resetRestrictedPeriods(): void;
    get restrictedPeriodsInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigSmsRestrictedPeriods | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue {
    /**
    * Time in ISO 8601 format, e.g. T23:11
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_time Connectcampaignsv2Campaign#end_time}
    */
    readonly endTime?: string;
    /**
    * Time in ISO 8601 format, e.g. T23:11
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_time Connectcampaignsv2Campaign#start_time}
    */
    readonly startTime?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValueToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValueToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValueList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValueOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours {
    /**
    * Day of week
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#key Connectcampaignsv2Campaign#key}
    */
    readonly key?: string;
    /**
    * List of time range
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#value Connectcampaignsv2Campaign#value}
    */
    readonly value?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value;
    get value(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValueList;
    putValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursValue[] | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHours {
    /**
    * Daily Hours map
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#daily_hours Connectcampaignsv2Campaign#daily_hours}
    */
    readonly dailyHours?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHours | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHours | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHours | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHours | cdktn.IResolvable | undefined);
    private _dailyHours;
    get dailyHours(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHoursList;
    putDailyHours(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours[] | cdktn.IResolvable): void;
    resetDailyHours(): void;
    get dailyHoursInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursDailyHours[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct {
    /**
    * Date in ISO 8601 format, e.g. 2024-01-01
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_date Connectcampaignsv2Campaign#end_date}
    */
    readonly endDate?: string;
    /**
    * The name of a restricted period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#name Connectcampaignsv2Campaign#name}
    */
    readonly name?: string;
    /**
    * Date in ISO 8601 format, e.g. 2024-01-01
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_date Connectcampaignsv2Campaign#start_date}
    */
    readonly startDate?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStructToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStructToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable | undefined);
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    resetEndDate(): void;
    get endDateInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStructList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStructOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriods {
    /**
    * List of restricted period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#restricted_period_list Connectcampaignsv2Campaign#restricted_period_list}
    */
    readonly restrictedPeriodList?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriods | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriods | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriods | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriods | cdktn.IResolvable | undefined);
    private _restrictedPeriodList;
    get restrictedPeriodList(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStructList;
    putRestrictedPeriodList(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable): void;
    resetRestrictedPeriodList(): void;
    get restrictedPeriodListInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsRestrictedPeriodListStruct[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigTelephony {
    /**
    * Open Hours config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#open_hours Connectcampaignsv2Campaign#open_hours}
    */
    readonly openHours?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHours;
    /**
    * Restricted period config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#restricted_periods Connectcampaignsv2Campaign#restricted_periods}
    */
    readonly restrictedPeriods?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriods;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephony | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigTelephonyToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephony | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephony | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephony | cdktn.IResolvable | undefined);
    private _openHours;
    get openHours(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHoursOutputReference;
    putOpenHours(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHours): void;
    resetOpenHours(): void;
    get openHoursInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOpenHours | undefined;
    private _restrictedPeriods;
    get restrictedPeriods(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriodsOutputReference;
    putRestrictedPeriods(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriods): void;
    resetRestrictedPeriods(): void;
    get restrictedPeriodsInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyRestrictedPeriods | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue {
    /**
    * Time in ISO 8601 format, e.g. T23:11
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_time Connectcampaignsv2Campaign#end_time}
    */
    readonly endTime?: string;
    /**
    * Time in ISO 8601 format, e.g. T23:11
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_time Connectcampaignsv2Campaign#start_time}
    */
    readonly startTime?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValueToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValueToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValueList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValueOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours {
    /**
    * Day of week
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#key Connectcampaignsv2Campaign#key}
    */
    readonly key?: string;
    /**
    * List of time range
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#value Connectcampaignsv2Campaign#value}
    */
    readonly value?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value;
    get value(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValueList;
    putValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursValue[] | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHours {
    /**
    * Daily Hours map
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#daily_hours Connectcampaignsv2Campaign#daily_hours}
    */
    readonly dailyHours?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHours | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHours | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHours | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHours | cdktn.IResolvable | undefined);
    private _dailyHours;
    get dailyHours(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHoursList;
    putDailyHours(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours[] | cdktn.IResolvable): void;
    resetDailyHours(): void;
    get dailyHoursInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursDailyHours[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct {
    /**
    * Date in ISO 8601 format, e.g. 2024-01-01
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_date Connectcampaignsv2Campaign#end_date}
    */
    readonly endDate?: string;
    /**
    * The name of a restricted period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#name Connectcampaignsv2Campaign#name}
    */
    readonly name?: string;
    /**
    * Date in ISO 8601 format, e.g. 2024-01-01
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_date Connectcampaignsv2Campaign#start_date}
    */
    readonly startDate?: string;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStructToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStructToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct | cdktn.IResolvable | undefined);
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    resetEndDate(): void;
    get endDateInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStructList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStructOutputReference;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriods {
    /**
    * List of restricted period
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#restricted_period_list Connectcampaignsv2Campaign#restricted_period_list}
    */
    readonly restrictedPeriodList?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriods | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriods | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriods | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriods | cdktn.IResolvable | undefined);
    private _restrictedPeriodList;
    get restrictedPeriodList(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStructList;
    putRestrictedPeriodList(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct[] | cdktn.IResolvable): void;
    resetRestrictedPeriodList(): void;
    get restrictedPeriodListInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsRestrictedPeriodListStruct[] | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfigWhatsApp {
    /**
    * Open Hours config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#open_hours Connectcampaignsv2Campaign#open_hours}
    */
    readonly openHours?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHours;
    /**
    * Restricted period config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#restricted_periods Connectcampaignsv2Campaign#restricted_periods}
    */
    readonly restrictedPeriods?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriods;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsApp | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsApp | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsApp | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsApp | cdktn.IResolvable | undefined);
    private _openHours;
    get openHours(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHoursOutputReference;
    putOpenHours(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHours): void;
    resetOpenHours(): void;
    get openHoursInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOpenHours | undefined;
    private _restrictedPeriods;
    get restrictedPeriods(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriodsOutputReference;
    putRestrictedPeriods(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriods): void;
    resetRestrictedPeriods(): void;
    get restrictedPeriodsInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppRestrictedPeriods | undefined;
}
export interface Connectcampaignsv2CampaignCommunicationTimeConfig {
    /**
    * Time window config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#email Connectcampaignsv2Campaign#email}
    */
    readonly email?: Connectcampaignsv2CampaignCommunicationTimeConfigEmail;
    /**
    * Local time zone config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#local_time_zone_config Connectcampaignsv2Campaign#local_time_zone_config}
    */
    readonly localTimeZoneConfig?: Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfig;
    /**
    * Time window config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#sms Connectcampaignsv2Campaign#sms}
    */
    readonly sms?: Connectcampaignsv2CampaignCommunicationTimeConfigSms;
    /**
    * Time window config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#telephony Connectcampaignsv2Campaign#telephony}
    */
    readonly telephony?: Connectcampaignsv2CampaignCommunicationTimeConfigTelephony;
    /**
    * Time window config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#whats_app Connectcampaignsv2Campaign#whats_app}
    */
    readonly whatsApp?: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsApp;
}
export declare function connectcampaignsv2CampaignCommunicationTimeConfigToTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignCommunicationTimeConfigToHclTerraform(struct?: Connectcampaignsv2CampaignCommunicationTimeConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignCommunicationTimeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignCommunicationTimeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignCommunicationTimeConfig | cdktn.IResolvable | undefined);
    private _email;
    get email(): Connectcampaignsv2CampaignCommunicationTimeConfigEmailOutputReference;
    putEmail(value: Connectcampaignsv2CampaignCommunicationTimeConfigEmail): void;
    resetEmail(): void;
    get emailInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigEmail | undefined;
    private _localTimeZoneConfig;
    get localTimeZoneConfig(): Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfigOutputReference;
    putLocalTimeZoneConfig(value: Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfig): void;
    resetLocalTimeZoneConfig(): void;
    get localTimeZoneConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigLocalTimeZoneConfig | undefined;
    private _sms;
    get sms(): Connectcampaignsv2CampaignCommunicationTimeConfigSmsOutputReference;
    putSms(value: Connectcampaignsv2CampaignCommunicationTimeConfigSms): void;
    resetSms(): void;
    get smsInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigSms | undefined;
    private _telephony;
    get telephony(): Connectcampaignsv2CampaignCommunicationTimeConfigTelephonyOutputReference;
    putTelephony(value: Connectcampaignsv2CampaignCommunicationTimeConfigTelephony): void;
    resetTelephony(): void;
    get telephonyInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigTelephony | undefined;
    private _whatsApp;
    get whatsApp(): Connectcampaignsv2CampaignCommunicationTimeConfigWhatsAppOutputReference;
    putWhatsApp(value: Connectcampaignsv2CampaignCommunicationTimeConfigWhatsApp): void;
    resetWhatsApp(): void;
    get whatsAppInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfigWhatsApp | undefined;
}
export interface Connectcampaignsv2CampaignEntryLimitsConfig {
    /**
    * Maximum number of entries per participant. 0 indicates unlimited entries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#max_entry_count Connectcampaignsv2Campaign#max_entry_count}
    */
    readonly maxEntryCount?: number;
    /**
    * Minimum time interval between entries for the same participant in ISO 8601 duration format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#min_entry_interval Connectcampaignsv2Campaign#min_entry_interval}
    */
    readonly minEntryInterval?: string;
}
export declare function connectcampaignsv2CampaignEntryLimitsConfigToTerraform(struct?: Connectcampaignsv2CampaignEntryLimitsConfig | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignEntryLimitsConfigToHclTerraform(struct?: Connectcampaignsv2CampaignEntryLimitsConfig | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignEntryLimitsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignEntryLimitsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignEntryLimitsConfig | cdktn.IResolvable | undefined);
    private _maxEntryCount?;
    get maxEntryCount(): number;
    set maxEntryCount(value: number);
    resetMaxEntryCount(): void;
    get maxEntryCountInput(): number | undefined;
    private _minEntryInterval?;
    get minEntryInterval(): string;
    set minEntryInterval(value: string);
    resetMinEntryInterval(): void;
    get minEntryIntervalInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignSchedule {
    /**
    * Timestamp with no UTC offset or timezone
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#end_time Connectcampaignsv2Campaign#end_time}
    */
    readonly endTime?: string;
    /**
    * Time duration in ISO 8601 format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#refresh_frequency Connectcampaignsv2Campaign#refresh_frequency}
    */
    readonly refreshFrequency?: string;
    /**
    * Timestamp with no UTC offset or timezone
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#start_time Connectcampaignsv2Campaign#start_time}
    */
    readonly startTime?: string;
}
export declare function connectcampaignsv2CampaignScheduleToTerraform(struct?: Connectcampaignsv2CampaignSchedule | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignScheduleToHclTerraform(struct?: Connectcampaignsv2CampaignSchedule | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignSchedule | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _refreshFrequency?;
    get refreshFrequency(): string;
    set refreshFrequency(value: string);
    resetRefreshFrequency(): void;
    get refreshFrequencyInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignSourceEventTrigger {
    /**
    * Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#customer_profiles_domain_arn Connectcampaignsv2Campaign#customer_profiles_domain_arn}
    */
    readonly customerProfilesDomainArn?: string;
}
export declare function connectcampaignsv2CampaignSourceEventTriggerToTerraform(struct?: Connectcampaignsv2CampaignSourceEventTrigger | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignSourceEventTriggerToHclTerraform(struct?: Connectcampaignsv2CampaignSourceEventTrigger | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignSourceEventTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignSourceEventTrigger | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignSourceEventTrigger | cdktn.IResolvable | undefined);
    private _customerProfilesDomainArn?;
    get customerProfilesDomainArn(): string;
    set customerProfilesDomainArn(value: string);
    resetCustomerProfilesDomainArn(): void;
    get customerProfilesDomainArnInput(): string | undefined;
}
export interface Connectcampaignsv2CampaignSource {
    /**
    * Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#customer_profiles_segment_arn Connectcampaignsv2Campaign#customer_profiles_segment_arn}
    */
    readonly customerProfilesSegmentArn?: string;
    /**
    * The event trigger of the campaign
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#event_trigger Connectcampaignsv2Campaign#event_trigger}
    */
    readonly eventTrigger?: Connectcampaignsv2CampaignSourceEventTrigger;
}
export declare function connectcampaignsv2CampaignSourceToTerraform(struct?: Connectcampaignsv2CampaignSource | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignSourceToHclTerraform(struct?: Connectcampaignsv2CampaignSource | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Connectcampaignsv2CampaignSource | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignSource | cdktn.IResolvable | undefined);
    private _customerProfilesSegmentArn?;
    get customerProfilesSegmentArn(): string;
    set customerProfilesSegmentArn(value: string);
    resetCustomerProfilesSegmentArn(): void;
    get customerProfilesSegmentArnInput(): string | undefined;
    private _eventTrigger;
    get eventTrigger(): Connectcampaignsv2CampaignSourceEventTriggerOutputReference;
    putEventTrigger(value: Connectcampaignsv2CampaignSourceEventTrigger): void;
    resetEventTrigger(): void;
    get eventTriggerInput(): cdktn.IResolvable | Connectcampaignsv2CampaignSourceEventTrigger | undefined;
}
export interface Connectcampaignsv2CampaignTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#key Connectcampaignsv2Campaign#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#value Connectcampaignsv2Campaign#value}
    */
    readonly value?: string;
}
export declare function connectcampaignsv2CampaignTagsToTerraform(struct?: Connectcampaignsv2CampaignTags | cdktn.IResolvable): any;
export declare function connectcampaignsv2CampaignTagsToHclTerraform(struct?: Connectcampaignsv2CampaignTags | cdktn.IResolvable): any;
export declare class Connectcampaignsv2CampaignTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Connectcampaignsv2CampaignTags | cdktn.IResolvable | undefined;
    set internalValue(value: Connectcampaignsv2CampaignTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class Connectcampaignsv2CampaignTagsList extends cdktn.ComplexList {
    internalValue?: Connectcampaignsv2CampaignTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Connectcampaignsv2CampaignTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign awscc_connectcampaignsv2_campaign}
*/
export declare class Connectcampaignsv2Campaign extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connectcampaignsv2_campaign";
    /**
    * Generates CDKTN code for importing a Connectcampaignsv2Campaign resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Connectcampaignsv2Campaign to import
    * @param importFromId The id of the existing Connectcampaignsv2Campaign that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Connectcampaignsv2Campaign to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connectcampaignsv2_campaign awscc_connectcampaignsv2_campaign} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Connectcampaignsv2CampaignConfig
    */
    constructor(scope: Construct, id: string, config: Connectcampaignsv2CampaignConfig);
    get arn(): string;
    private _channelSubtypeConfig;
    get channelSubtypeConfig(): Connectcampaignsv2CampaignChannelSubtypeConfigOutputReference;
    putChannelSubtypeConfig(value: Connectcampaignsv2CampaignChannelSubtypeConfig): void;
    resetChannelSubtypeConfig(): void;
    get channelSubtypeConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignChannelSubtypeConfig | undefined;
    private _communicationLimitsOverride;
    get communicationLimitsOverride(): Connectcampaignsv2CampaignCommunicationLimitsOverrideOutputReference;
    putCommunicationLimitsOverride(value: Connectcampaignsv2CampaignCommunicationLimitsOverride): void;
    resetCommunicationLimitsOverride(): void;
    get communicationLimitsOverrideInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationLimitsOverride | undefined;
    private _communicationTimeConfig;
    get communicationTimeConfig(): Connectcampaignsv2CampaignCommunicationTimeConfigOutputReference;
    putCommunicationTimeConfig(value: Connectcampaignsv2CampaignCommunicationTimeConfig): void;
    resetCommunicationTimeConfig(): void;
    get communicationTimeConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignCommunicationTimeConfig | undefined;
    private _connectCampaignFlowArn?;
    get connectCampaignFlowArn(): string;
    set connectCampaignFlowArn(value: string);
    resetConnectCampaignFlowArn(): void;
    get connectCampaignFlowArnInput(): string | undefined;
    private _connectInstanceId?;
    get connectInstanceId(): string;
    set connectInstanceId(value: string);
    get connectInstanceIdInput(): string | undefined;
    private _entryLimitsConfig;
    get entryLimitsConfig(): Connectcampaignsv2CampaignEntryLimitsConfigOutputReference;
    putEntryLimitsConfig(value: Connectcampaignsv2CampaignEntryLimitsConfig): void;
    resetEntryLimitsConfig(): void;
    get entryLimitsConfigInput(): cdktn.IResolvable | Connectcampaignsv2CampaignEntryLimitsConfig | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schedule;
    get schedule(): Connectcampaignsv2CampaignScheduleOutputReference;
    putSchedule(value: Connectcampaignsv2CampaignSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): cdktn.IResolvable | Connectcampaignsv2CampaignSchedule | undefined;
    private _source;
    get source(): Connectcampaignsv2CampaignSourceOutputReference;
    putSource(value: Connectcampaignsv2CampaignSource): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | Connectcampaignsv2CampaignSource | undefined;
    private _tags;
    get tags(): Connectcampaignsv2CampaignTagsList;
    putTags(value: Connectcampaignsv2CampaignTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | Connectcampaignsv2CampaignTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
