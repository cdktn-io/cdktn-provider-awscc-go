/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigExtensionAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association#extension_identifier AppconfigExtensionAssociation#extension_identifier}
    */
    readonly extensionIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association#extension_version_number AppconfigExtensionAssociation#extension_version_number}
    */
    readonly extensionVersionNumber?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association#parameters AppconfigExtensionAssociation#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association#resource_identifier AppconfigExtensionAssociation#resource_identifier}
    */
    readonly resourceIdentifier?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association#tags AppconfigExtensionAssociation#tags}
    */
    readonly tags?: AppconfigExtensionAssociationTags[] | cdktn.IResolvable;
}
export interface AppconfigExtensionAssociationTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association#key AppconfigExtensionAssociation#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association#value AppconfigExtensionAssociation#value}
    */
    readonly value?: string;
}
export declare function appconfigExtensionAssociationTagsToTerraform(struct?: AppconfigExtensionAssociationTags | cdktn.IResolvable): any;
export declare function appconfigExtensionAssociationTagsToHclTerraform(struct?: AppconfigExtensionAssociationTags | cdktn.IResolvable): any;
export declare class AppconfigExtensionAssociationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigExtensionAssociationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExtensionAssociationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppconfigExtensionAssociationTagsList extends cdktn.ComplexList {
    internalValue?: AppconfigExtensionAssociationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigExtensionAssociationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association awscc_appconfig_extension_association}
*/
export declare class AppconfigExtensionAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appconfig_extension_association";
    /**
    * Generates CDKTN code for importing a AppconfigExtensionAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigExtensionAssociation to import
    * @param importFromId The id of the existing AppconfigExtensionAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigExtensionAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appconfig_extension_association awscc_appconfig_extension_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigExtensionAssociationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AppconfigExtensionAssociationConfig);
    get arn(): string;
    get extensionArn(): string;
    get extensionAssociationId(): string;
    private _extensionIdentifier?;
    get extensionIdentifier(): string;
    set extensionIdentifier(value: string);
    resetExtensionIdentifier(): void;
    get extensionIdentifierInput(): string | undefined;
    private _extensionVersionNumber?;
    get extensionVersionNumber(): number;
    set extensionVersionNumber(value: number);
    resetExtensionVersionNumber(): void;
    get extensionVersionNumberInput(): number | undefined;
    get id(): string;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    get resourceArn(): string;
    private _resourceIdentifier?;
    get resourceIdentifier(): string;
    set resourceIdentifier(value: string);
    resetResourceIdentifier(): void;
    get resourceIdentifierInput(): string | undefined;
    private _tags;
    get tags(): AppconfigExtensionAssociationTagsList;
    putTags(value: AppconfigExtensionAssociationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppconfigExtensionAssociationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
