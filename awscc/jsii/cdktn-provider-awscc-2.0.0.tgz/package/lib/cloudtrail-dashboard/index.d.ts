/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudtrailDashboardConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#name CloudtrailDashboard#name}
    */
    readonly name?: string;
    /**
    * Configures the automatic refresh schedule for the dashboard. Includes the frequency unit (DAYS or HOURS) and value, as well as the status (ENABLED or DISABLED) of the refresh schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#refresh_schedule CloudtrailDashboard#refresh_schedule}
    */
    readonly refreshSchedule?: CloudtrailDashboardRefreshSchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#tags CloudtrailDashboard#tags}
    */
    readonly tags?: CloudtrailDashboardTags[] | cdktn.IResolvable;
    /**
    * Indicates whether the dashboard is protected from termination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#termination_protection_enabled CloudtrailDashboard#termination_protection_enabled}
    */
    readonly terminationProtectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * List of widgets on the dashboard
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#widgets CloudtrailDashboard#widgets}
    */
    readonly widgets?: CloudtrailDashboardWidgets[] | cdktn.IResolvable;
}
export interface CloudtrailDashboardRefreshScheduleFrequency {
    /**
    * The frequency unit. Supported values are HOURS and DAYS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#unit CloudtrailDashboard#unit}
    */
    readonly unit?: string;
    /**
    * The frequency value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#value CloudtrailDashboard#value}
    */
    readonly value?: number;
}
export declare function cloudtrailDashboardRefreshScheduleFrequencyToTerraform(struct?: CloudtrailDashboardRefreshScheduleFrequency | cdktn.IResolvable): any;
export declare function cloudtrailDashboardRefreshScheduleFrequencyToHclTerraform(struct?: CloudtrailDashboardRefreshScheduleFrequency | cdktn.IResolvable): any;
export declare class CloudtrailDashboardRefreshScheduleFrequencyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudtrailDashboardRefreshScheduleFrequency | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailDashboardRefreshScheduleFrequency | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface CloudtrailDashboardRefreshSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#frequency CloudtrailDashboard#frequency}
    */
    readonly frequency?: CloudtrailDashboardRefreshScheduleFrequency;
    /**
    * The status of the schedule. Supported values are ENABLED and DISABLED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#status CloudtrailDashboard#status}
    */
    readonly status?: string;
    /**
    * StartTime of the automatic schedule refresh.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#time_of_day CloudtrailDashboard#time_of_day}
    */
    readonly timeOfDay?: string;
}
export declare function cloudtrailDashboardRefreshScheduleToTerraform(struct?: CloudtrailDashboardRefreshSchedule | cdktn.IResolvable): any;
export declare function cloudtrailDashboardRefreshScheduleToHclTerraform(struct?: CloudtrailDashboardRefreshSchedule | cdktn.IResolvable): any;
export declare class CloudtrailDashboardRefreshScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudtrailDashboardRefreshSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailDashboardRefreshSchedule | cdktn.IResolvable | undefined);
    private _frequency;
    get frequency(): CloudtrailDashboardRefreshScheduleFrequencyOutputReference;
    putFrequency(value: CloudtrailDashboardRefreshScheduleFrequency): void;
    resetFrequency(): void;
    get frequencyInput(): cdktn.IResolvable | CloudtrailDashboardRefreshScheduleFrequency | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _timeOfDay?;
    get timeOfDay(): string;
    set timeOfDay(value: string);
    resetTimeOfDay(): void;
    get timeOfDayInput(): string | undefined;
}
export interface CloudtrailDashboardTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#key CloudtrailDashboard#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#value CloudtrailDashboard#value}
    */
    readonly value?: string;
}
export declare function cloudtrailDashboardTagsToTerraform(struct?: CloudtrailDashboardTags | cdktn.IResolvable): any;
export declare function cloudtrailDashboardTagsToHclTerraform(struct?: CloudtrailDashboardTags | cdktn.IResolvable): any;
export declare class CloudtrailDashboardTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailDashboardTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailDashboardTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudtrailDashboardTagsList extends cdktn.ComplexList {
    internalValue?: CloudtrailDashboardTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailDashboardTagsOutputReference;
}
export interface CloudtrailDashboardWidgets {
    /**
    * The placeholder keys in the QueryStatement. For example: $StartTime$, $EndTime$, $Period$.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#query_parameters CloudtrailDashboard#query_parameters}
    */
    readonly queryParameters?: string[];
    /**
    * The SQL query statement on one or more event data stores.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#query_statement CloudtrailDashboard#query_statement}
    */
    readonly queryStatement?: string;
    /**
    * The view properties of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#view_properties CloudtrailDashboard#view_properties}
    */
    readonly viewProperties?: {
        [key: string]: string;
    };
}
export declare function cloudtrailDashboardWidgetsToTerraform(struct?: CloudtrailDashboardWidgets | cdktn.IResolvable): any;
export declare function cloudtrailDashboardWidgetsToHclTerraform(struct?: CloudtrailDashboardWidgets | cdktn.IResolvable): any;
export declare class CloudtrailDashboardWidgetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailDashboardWidgets | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailDashboardWidgets | cdktn.IResolvable | undefined);
    private _queryParameters?;
    get queryParameters(): string[];
    set queryParameters(value: string[]);
    resetQueryParameters(): void;
    get queryParametersInput(): string[] | undefined;
    private _queryStatement?;
    get queryStatement(): string;
    set queryStatement(value: string);
    resetQueryStatement(): void;
    get queryStatementInput(): string | undefined;
    private _viewProperties?;
    get viewProperties(): {
        [key: string]: string;
    };
    set viewProperties(value: {
        [key: string]: string;
    });
    resetViewProperties(): void;
    get viewPropertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class CloudtrailDashboardWidgetsList extends cdktn.ComplexList {
    internalValue?: CloudtrailDashboardWidgets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailDashboardWidgetsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard awscc_cloudtrail_dashboard}
*/
export declare class CloudtrailDashboard extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudtrail_dashboard";
    /**
    * Generates CDKTN code for importing a CloudtrailDashboard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudtrailDashboard to import
    * @param importFromId The id of the existing CloudtrailDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudtrailDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudtrail_dashboard awscc_cloudtrail_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudtrailDashboardConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudtrailDashboardConfig);
    get createdTimestamp(): string;
    get dashboardArn(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _refreshSchedule;
    get refreshSchedule(): CloudtrailDashboardRefreshScheduleOutputReference;
    putRefreshSchedule(value: CloudtrailDashboardRefreshSchedule): void;
    resetRefreshSchedule(): void;
    get refreshScheduleInput(): cdktn.IResolvable | CloudtrailDashboardRefreshSchedule | undefined;
    get status(): string;
    private _tags;
    get tags(): CloudtrailDashboardTagsList;
    putTags(value: CloudtrailDashboardTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudtrailDashboardTags[] | undefined;
    private _terminationProtectionEnabled?;
    get terminationProtectionEnabled(): boolean | cdktn.IResolvable;
    set terminationProtectionEnabled(value: boolean | cdktn.IResolvable);
    resetTerminationProtectionEnabled(): void;
    get terminationProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get type(): string;
    get updatedTimestamp(): string;
    private _widgets;
    get widgets(): CloudtrailDashboardWidgetsList;
    putWidgets(value: CloudtrailDashboardWidgets[] | cdktn.IResolvable): void;
    resetWidgets(): void;
    get widgetsInput(): cdktn.IResolvable | CloudtrailDashboardWidgets[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
