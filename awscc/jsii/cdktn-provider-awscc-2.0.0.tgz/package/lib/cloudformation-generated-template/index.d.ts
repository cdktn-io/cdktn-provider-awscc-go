/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationGeneratedTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name assigned to the generated template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_generated_template#generated_template_name CloudformationGeneratedTemplate#generated_template_name}
    */
    readonly generatedTemplateName: string;
    /**
    * The configuration details of the generated template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_generated_template#template_configuration CloudformationGeneratedTemplate#template_configuration}
    */
    readonly templateConfiguration?: CloudformationGeneratedTemplateTemplateConfiguration;
}
export interface CloudformationGeneratedTemplateProgress {
}
export declare function cloudformationGeneratedTemplateProgressToTerraform(struct?: CloudformationGeneratedTemplateProgress): any;
export declare function cloudformationGeneratedTemplateProgressToHclTerraform(struct?: CloudformationGeneratedTemplateProgress): any;
export declare class CloudformationGeneratedTemplateProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationGeneratedTemplateProgress | undefined;
    set internalValue(value: CloudformationGeneratedTemplateProgress | undefined);
    get resourcesFailed(): number;
    get resourcesPending(): number;
    get resourcesProcessing(): number;
    get resourcesSucceeded(): number;
}
export interface CloudformationGeneratedTemplateTemplateConfiguration {
    /**
    * The DeletionPolicy assigned to resources in the generated template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_generated_template#deletion_policy CloudformationGeneratedTemplate#deletion_policy}
    */
    readonly deletionPolicy?: string;
    /**
    * The UpdateReplacePolicy assigned to resources in the generated template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_generated_template#update_replace_policy CloudformationGeneratedTemplate#update_replace_policy}
    */
    readonly updateReplacePolicy?: string;
}
export declare function cloudformationGeneratedTemplateTemplateConfigurationToTerraform(struct?: CloudformationGeneratedTemplateTemplateConfiguration | cdktn.IResolvable): any;
export declare function cloudformationGeneratedTemplateTemplateConfigurationToHclTerraform(struct?: CloudformationGeneratedTemplateTemplateConfiguration | cdktn.IResolvable): any;
export declare class CloudformationGeneratedTemplateTemplateConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationGeneratedTemplateTemplateConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationGeneratedTemplateTemplateConfiguration | cdktn.IResolvable | undefined);
    private _deletionPolicy?;
    get deletionPolicy(): string;
    set deletionPolicy(value: string);
    resetDeletionPolicy(): void;
    get deletionPolicyInput(): string | undefined;
    private _updateReplacePolicy?;
    get updateReplacePolicy(): string;
    set updateReplacePolicy(value: string);
    resetUpdateReplacePolicy(): void;
    get updateReplacePolicyInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_generated_template awscc_cloudformation_generated_template}
*/
export declare class CloudformationGeneratedTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_generated_template";
    /**
    * Generates CDKTN code for importing a CloudformationGeneratedTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationGeneratedTemplate to import
    * @param importFromId The id of the existing CloudformationGeneratedTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_generated_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationGeneratedTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_generated_template awscc_cloudformation_generated_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationGeneratedTemplateConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationGeneratedTemplateConfig);
    get creationTime(): string;
    get generatedTemplateId(): string;
    private _generatedTemplateName?;
    get generatedTemplateName(): string;
    set generatedTemplateName(value: string);
    get generatedTemplateNameInput(): string | undefined;
    get id(): string;
    get lastUpdatedTime(): string;
    private _progress;
    get progress(): CloudformationGeneratedTemplateProgressOutputReference;
    get status(): string;
    private _templateConfiguration;
    get templateConfiguration(): CloudformationGeneratedTemplateTemplateConfigurationOutputReference;
    putTemplateConfiguration(value: CloudformationGeneratedTemplateTemplateConfiguration): void;
    resetTemplateConfiguration(): void;
    get templateConfigurationInput(): cdktn.IResolvable | CloudformationGeneratedTemplateTemplateConfiguration | undefined;
    get totalWarnings(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
