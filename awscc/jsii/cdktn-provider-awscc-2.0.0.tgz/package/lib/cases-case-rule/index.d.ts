/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CasesCaseRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description explaining the purpose and behavior of this case rule. Helps administrators understand when and why this rule applies to case fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#description CasesCaseRule#description}
    */
    readonly description?: string;
    /**
    * The unique identifier of the Cases domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#domain_id CasesCaseRule#domain_id}
    */
    readonly domainId?: string;
    /**
    * A descriptive name for the case rule. Must be unique within the domain and should clearly indicate the rule's purpose (e.g., 'Priority Field Required for Urgent Cases').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#name CasesCaseRule#name}
    */
    readonly name: string;
    /**
    * Defines the rule behavior and conditions. Specifies the rule type and the conditions under which it applies. In the Amazon Connect admin website, this corresponds to case field conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#rule CasesCaseRule#rule}
    */
    readonly rule: CasesCaseRuleRule;
    /**
    * The tags that you attach to this case rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#tags CasesCaseRule#tags}
    */
    readonly tags?: CasesCaseRuleTags[] | cdktn.IResolvable;
}
export interface CasesCaseRuleRuleHiddenConditionsEqualToOperandOne {
    /**
    * The field ID this operand should take the value of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#field_id CasesCaseRule#field_id}
    */
    readonly fieldId?: string;
}
export declare function casesCaseRuleRuleHiddenConditionsEqualToOperandOneToTerraform(struct?: CasesCaseRuleRuleHiddenConditionsEqualToOperandOne | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleHiddenConditionsEqualToOperandOneToHclTerraform(struct?: CasesCaseRuleRuleHiddenConditionsEqualToOperandOne | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleHiddenConditionsEqualToOperandOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleHiddenConditionsEqualToOperandOne | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleHiddenConditionsEqualToOperandOne | cdktn.IResolvable | undefined);
    private _fieldId?;
    get fieldId(): string;
    set fieldId(value: string);
    resetFieldId(): void;
    get fieldIdInput(): string | undefined;
}
export interface CasesCaseRuleRuleHiddenConditionsEqualToOperandTwo {
    /**
    * A boolean value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#boolean_value CasesCaseRule#boolean_value}
    */
    readonly booleanValue?: boolean | cdktn.IResolvable;
    /**
    * A numeric value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#double_value CasesCaseRule#double_value}
    */
    readonly doubleValue?: number;
    /**
    * An empty operand value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#empty_value CasesCaseRule#empty_value}
    */
    readonly emptyValue?: string;
    /**
    * A string value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#string_value CasesCaseRule#string_value}
    */
    readonly stringValue?: string;
}
export declare function casesCaseRuleRuleHiddenConditionsEqualToOperandTwoToTerraform(struct?: CasesCaseRuleRuleHiddenConditionsEqualToOperandTwo | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleHiddenConditionsEqualToOperandTwoToHclTerraform(struct?: CasesCaseRuleRuleHiddenConditionsEqualToOperandTwo | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleHiddenConditionsEqualToOperandTwoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleHiddenConditionsEqualToOperandTwo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleHiddenConditionsEqualToOperandTwo | cdktn.IResolvable | undefined);
    private _booleanValue?;
    get booleanValue(): boolean | cdktn.IResolvable;
    set booleanValue(value: boolean | cdktn.IResolvable);
    resetBooleanValue(): void;
    get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _emptyValue?;
    get emptyValue(): string;
    set emptyValue(value: string);
    resetEmptyValue(): void;
    get emptyValueInput(): string | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface CasesCaseRuleRuleHiddenConditionsEqualTo {
    /**
    * The left hand operand in the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#operand_one CasesCaseRule#operand_one}
    */
    readonly operandOne?: CasesCaseRuleRuleHiddenConditionsEqualToOperandOne;
    /**
    * The right hand operand in the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#operand_two CasesCaseRule#operand_two}
    */
    readonly operandTwo?: CasesCaseRuleRuleHiddenConditionsEqualToOperandTwo;
    /**
    * The value of the outer rule if the condition evaluates to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#result CasesCaseRule#result}
    */
    readonly result?: boolean | cdktn.IResolvable;
}
export declare function casesCaseRuleRuleHiddenConditionsEqualToToTerraform(struct?: CasesCaseRuleRuleHiddenConditionsEqualTo | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleHiddenConditionsEqualToToHclTerraform(struct?: CasesCaseRuleRuleHiddenConditionsEqualTo | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleHiddenConditionsEqualToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleHiddenConditionsEqualTo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleHiddenConditionsEqualTo | cdktn.IResolvable | undefined);
    private _operandOne;
    get operandOne(): CasesCaseRuleRuleHiddenConditionsEqualToOperandOneOutputReference;
    putOperandOne(value: CasesCaseRuleRuleHiddenConditionsEqualToOperandOne): void;
    resetOperandOne(): void;
    get operandOneInput(): cdktn.IResolvable | CasesCaseRuleRuleHiddenConditionsEqualToOperandOne | undefined;
    private _operandTwo;
    get operandTwo(): CasesCaseRuleRuleHiddenConditionsEqualToOperandTwoOutputReference;
    putOperandTwo(value: CasesCaseRuleRuleHiddenConditionsEqualToOperandTwo): void;
    resetOperandTwo(): void;
    get operandTwoInput(): cdktn.IResolvable | CasesCaseRuleRuleHiddenConditionsEqualToOperandTwo | undefined;
    private _result?;
    get result(): boolean | cdktn.IResolvable;
    set result(value: boolean | cdktn.IResolvable);
    resetResult(): void;
    get resultInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOne {
    /**
    * The field ID this operand should take the value of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#field_id CasesCaseRule#field_id}
    */
    readonly fieldId?: string;
}
export declare function casesCaseRuleRuleHiddenConditionsNotEqualToOperandOneToTerraform(struct?: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOne | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleHiddenConditionsNotEqualToOperandOneToHclTerraform(struct?: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOne | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOne | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOne | cdktn.IResolvable | undefined);
    private _fieldId?;
    get fieldId(): string;
    set fieldId(value: string);
    resetFieldId(): void;
    get fieldIdInput(): string | undefined;
}
export interface CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwo {
    /**
    * A boolean value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#boolean_value CasesCaseRule#boolean_value}
    */
    readonly booleanValue?: boolean | cdktn.IResolvable;
    /**
    * A numeric value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#double_value CasesCaseRule#double_value}
    */
    readonly doubleValue?: number;
    /**
    * An empty operand value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#empty_value CasesCaseRule#empty_value}
    */
    readonly emptyValue?: string;
    /**
    * A string value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#string_value CasesCaseRule#string_value}
    */
    readonly stringValue?: string;
}
export declare function casesCaseRuleRuleHiddenConditionsNotEqualToOperandTwoToTerraform(struct?: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwo | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleHiddenConditionsNotEqualToOperandTwoToHclTerraform(struct?: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwo | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwo | cdktn.IResolvable | undefined);
    private _booleanValue?;
    get booleanValue(): boolean | cdktn.IResolvable;
    set booleanValue(value: boolean | cdktn.IResolvable);
    resetBooleanValue(): void;
    get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _emptyValue?;
    get emptyValue(): string;
    set emptyValue(value: string);
    resetEmptyValue(): void;
    get emptyValueInput(): string | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface CasesCaseRuleRuleHiddenConditionsNotEqualTo {
    /**
    * The left hand operand in the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#operand_one CasesCaseRule#operand_one}
    */
    readonly operandOne?: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOne;
    /**
    * The right hand operand in the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#operand_two CasesCaseRule#operand_two}
    */
    readonly operandTwo?: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwo;
    /**
    * The value of the outer rule if the condition evaluates to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#result CasesCaseRule#result}
    */
    readonly result?: boolean | cdktn.IResolvable;
}
export declare function casesCaseRuleRuleHiddenConditionsNotEqualToToTerraform(struct?: CasesCaseRuleRuleHiddenConditionsNotEqualTo | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleHiddenConditionsNotEqualToToHclTerraform(struct?: CasesCaseRuleRuleHiddenConditionsNotEqualTo | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleHiddenConditionsNotEqualToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleHiddenConditionsNotEqualTo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleHiddenConditionsNotEqualTo | cdktn.IResolvable | undefined);
    private _operandOne;
    get operandOne(): CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOneOutputReference;
    putOperandOne(value: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOne): void;
    resetOperandOne(): void;
    get operandOneInput(): cdktn.IResolvable | CasesCaseRuleRuleHiddenConditionsNotEqualToOperandOne | undefined;
    private _operandTwo;
    get operandTwo(): CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwoOutputReference;
    putOperandTwo(value: CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwo): void;
    resetOperandTwo(): void;
    get operandTwoInput(): cdktn.IResolvable | CasesCaseRuleRuleHiddenConditionsNotEqualToOperandTwo | undefined;
    private _result?;
    get result(): boolean | cdktn.IResolvable;
    set result(value: boolean | cdktn.IResolvable);
    resetResult(): void;
    get resultInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CasesCaseRuleRuleHiddenConditions {
    /**
    * Boolean operands for a condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#equal_to CasesCaseRule#equal_to}
    */
    readonly equalTo?: CasesCaseRuleRuleHiddenConditionsEqualTo;
    /**
    * Boolean operands for a condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#not_equal_to CasesCaseRule#not_equal_to}
    */
    readonly notEqualTo?: CasesCaseRuleRuleHiddenConditionsNotEqualTo;
}
export declare function casesCaseRuleRuleHiddenConditionsToTerraform(struct?: CasesCaseRuleRuleHiddenConditions | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleHiddenConditionsToHclTerraform(struct?: CasesCaseRuleRuleHiddenConditions | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleHiddenConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesCaseRuleRuleHiddenConditions | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleHiddenConditions | cdktn.IResolvable | undefined);
    private _equalTo;
    get equalTo(): CasesCaseRuleRuleHiddenConditionsEqualToOutputReference;
    putEqualTo(value: CasesCaseRuleRuleHiddenConditionsEqualTo): void;
    resetEqualTo(): void;
    get equalToInput(): cdktn.IResolvable | CasesCaseRuleRuleHiddenConditionsEqualTo | undefined;
    private _notEqualTo;
    get notEqualTo(): CasesCaseRuleRuleHiddenConditionsNotEqualToOutputReference;
    putNotEqualTo(value: CasesCaseRuleRuleHiddenConditionsNotEqualTo): void;
    resetNotEqualTo(): void;
    get notEqualToInput(): cdktn.IResolvable | CasesCaseRuleRuleHiddenConditionsNotEqualTo | undefined;
}
export declare class CasesCaseRuleRuleHiddenConditionsList extends cdktn.ComplexList {
    internalValue?: CasesCaseRuleRuleHiddenConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesCaseRuleRuleHiddenConditionsOutputReference;
}
export interface CasesCaseRuleRuleHidden {
    /**
    * List of conditions for the hidden rule; the first condition to evaluate to true dictates the value of the rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#conditions CasesCaseRule#conditions}
    */
    readonly conditions?: CasesCaseRuleRuleHiddenConditions[] | cdktn.IResolvable;
    /**
    * The value of the rule (i.e. whether the field is hidden) should none of the conditions evaluate to true
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#default_value CasesCaseRule#default_value}
    */
    readonly defaultValue?: boolean | cdktn.IResolvable;
}
export declare function casesCaseRuleRuleHiddenToTerraform(struct?: CasesCaseRuleRuleHidden | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleHiddenToHclTerraform(struct?: CasesCaseRuleRuleHidden | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleHiddenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleHidden | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleHidden | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): CasesCaseRuleRuleHiddenConditionsList;
    putConditions(value: CasesCaseRuleRuleHiddenConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | CasesCaseRuleRuleHiddenConditions[] | undefined;
    private _defaultValue?;
    get defaultValue(): boolean | cdktn.IResolvable;
    set defaultValue(value: boolean | cdktn.IResolvable);
    resetDefaultValue(): void;
    get defaultValueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CasesCaseRuleRuleRequiredConditionsEqualToOperandOne {
    /**
    * The field ID this operand should take the value of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#field_id CasesCaseRule#field_id}
    */
    readonly fieldId?: string;
}
export declare function casesCaseRuleRuleRequiredConditionsEqualToOperandOneToTerraform(struct?: CasesCaseRuleRuleRequiredConditionsEqualToOperandOne | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleRequiredConditionsEqualToOperandOneToHclTerraform(struct?: CasesCaseRuleRuleRequiredConditionsEqualToOperandOne | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleRequiredConditionsEqualToOperandOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleRequiredConditionsEqualToOperandOne | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleRequiredConditionsEqualToOperandOne | cdktn.IResolvable | undefined);
    private _fieldId?;
    get fieldId(): string;
    set fieldId(value: string);
    resetFieldId(): void;
    get fieldIdInput(): string | undefined;
}
export interface CasesCaseRuleRuleRequiredConditionsEqualToOperandTwo {
    /**
    * A boolean value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#boolean_value CasesCaseRule#boolean_value}
    */
    readonly booleanValue?: boolean | cdktn.IResolvable;
    /**
    * A numeric value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#double_value CasesCaseRule#double_value}
    */
    readonly doubleValue?: number;
    /**
    * An empty operand value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#empty_value CasesCaseRule#empty_value}
    */
    readonly emptyValue?: string;
    /**
    * A string value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#string_value CasesCaseRule#string_value}
    */
    readonly stringValue?: string;
}
export declare function casesCaseRuleRuleRequiredConditionsEqualToOperandTwoToTerraform(struct?: CasesCaseRuleRuleRequiredConditionsEqualToOperandTwo | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleRequiredConditionsEqualToOperandTwoToHclTerraform(struct?: CasesCaseRuleRuleRequiredConditionsEqualToOperandTwo | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleRequiredConditionsEqualToOperandTwoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleRequiredConditionsEqualToOperandTwo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleRequiredConditionsEqualToOperandTwo | cdktn.IResolvable | undefined);
    private _booleanValue?;
    get booleanValue(): boolean | cdktn.IResolvable;
    set booleanValue(value: boolean | cdktn.IResolvable);
    resetBooleanValue(): void;
    get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _emptyValue?;
    get emptyValue(): string;
    set emptyValue(value: string);
    resetEmptyValue(): void;
    get emptyValueInput(): string | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface CasesCaseRuleRuleRequiredConditionsEqualTo {
    /**
    * The left hand operand in the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#operand_one CasesCaseRule#operand_one}
    */
    readonly operandOne?: CasesCaseRuleRuleRequiredConditionsEqualToOperandOne;
    /**
    * The right hand operand in the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#operand_two CasesCaseRule#operand_two}
    */
    readonly operandTwo?: CasesCaseRuleRuleRequiredConditionsEqualToOperandTwo;
    /**
    * The value of the outer rule if the condition evaluates to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#result CasesCaseRule#result}
    */
    readonly result?: boolean | cdktn.IResolvable;
}
export declare function casesCaseRuleRuleRequiredConditionsEqualToToTerraform(struct?: CasesCaseRuleRuleRequiredConditionsEqualTo | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleRequiredConditionsEqualToToHclTerraform(struct?: CasesCaseRuleRuleRequiredConditionsEqualTo | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleRequiredConditionsEqualToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleRequiredConditionsEqualTo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleRequiredConditionsEqualTo | cdktn.IResolvable | undefined);
    private _operandOne;
    get operandOne(): CasesCaseRuleRuleRequiredConditionsEqualToOperandOneOutputReference;
    putOperandOne(value: CasesCaseRuleRuleRequiredConditionsEqualToOperandOne): void;
    resetOperandOne(): void;
    get operandOneInput(): cdktn.IResolvable | CasesCaseRuleRuleRequiredConditionsEqualToOperandOne | undefined;
    private _operandTwo;
    get operandTwo(): CasesCaseRuleRuleRequiredConditionsEqualToOperandTwoOutputReference;
    putOperandTwo(value: CasesCaseRuleRuleRequiredConditionsEqualToOperandTwo): void;
    resetOperandTwo(): void;
    get operandTwoInput(): cdktn.IResolvable | CasesCaseRuleRuleRequiredConditionsEqualToOperandTwo | undefined;
    private _result?;
    get result(): boolean | cdktn.IResolvable;
    set result(value: boolean | cdktn.IResolvable);
    resetResult(): void;
    get resultInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOne {
    /**
    * The field ID this operand should take the value of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#field_id CasesCaseRule#field_id}
    */
    readonly fieldId?: string;
}
export declare function casesCaseRuleRuleRequiredConditionsNotEqualToOperandOneToTerraform(struct?: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOne | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleRequiredConditionsNotEqualToOperandOneToHclTerraform(struct?: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOne | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOne | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOne | cdktn.IResolvable | undefined);
    private _fieldId?;
    get fieldId(): string;
    set fieldId(value: string);
    resetFieldId(): void;
    get fieldIdInput(): string | undefined;
}
export interface CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwo {
    /**
    * A boolean value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#boolean_value CasesCaseRule#boolean_value}
    */
    readonly booleanValue?: boolean | cdktn.IResolvable;
    /**
    * A numeric value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#double_value CasesCaseRule#double_value}
    */
    readonly doubleValue?: number;
    /**
    * An empty operand value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#empty_value CasesCaseRule#empty_value}
    */
    readonly emptyValue?: string;
    /**
    * A string value to compare against the field value in the condition evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#string_value CasesCaseRule#string_value}
    */
    readonly stringValue?: string;
}
export declare function casesCaseRuleRuleRequiredConditionsNotEqualToOperandTwoToTerraform(struct?: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwo | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleRequiredConditionsNotEqualToOperandTwoToHclTerraform(struct?: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwo | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwo | cdktn.IResolvable | undefined);
    private _booleanValue?;
    get booleanValue(): boolean | cdktn.IResolvable;
    set booleanValue(value: boolean | cdktn.IResolvable);
    resetBooleanValue(): void;
    get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _emptyValue?;
    get emptyValue(): string;
    set emptyValue(value: string);
    resetEmptyValue(): void;
    get emptyValueInput(): string | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface CasesCaseRuleRuleRequiredConditionsNotEqualTo {
    /**
    * The left hand operand in the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#operand_one CasesCaseRule#operand_one}
    */
    readonly operandOne?: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOne;
    /**
    * The right hand operand in the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#operand_two CasesCaseRule#operand_two}
    */
    readonly operandTwo?: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwo;
    /**
    * The value of the outer rule if the condition evaluates to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#result CasesCaseRule#result}
    */
    readonly result?: boolean | cdktn.IResolvable;
}
export declare function casesCaseRuleRuleRequiredConditionsNotEqualToToTerraform(struct?: CasesCaseRuleRuleRequiredConditionsNotEqualTo | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleRequiredConditionsNotEqualToToHclTerraform(struct?: CasesCaseRuleRuleRequiredConditionsNotEqualTo | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleRequiredConditionsNotEqualToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleRequiredConditionsNotEqualTo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleRequiredConditionsNotEqualTo | cdktn.IResolvable | undefined);
    private _operandOne;
    get operandOne(): CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOneOutputReference;
    putOperandOne(value: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOne): void;
    resetOperandOne(): void;
    get operandOneInput(): cdktn.IResolvable | CasesCaseRuleRuleRequiredConditionsNotEqualToOperandOne | undefined;
    private _operandTwo;
    get operandTwo(): CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwoOutputReference;
    putOperandTwo(value: CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwo): void;
    resetOperandTwo(): void;
    get operandTwoInput(): cdktn.IResolvable | CasesCaseRuleRuleRequiredConditionsNotEqualToOperandTwo | undefined;
    private _result?;
    get result(): boolean | cdktn.IResolvable;
    set result(value: boolean | cdktn.IResolvable);
    resetResult(): void;
    get resultInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CasesCaseRuleRuleRequiredConditions {
    /**
    * Boolean operands for a condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#equal_to CasesCaseRule#equal_to}
    */
    readonly equalTo?: CasesCaseRuleRuleRequiredConditionsEqualTo;
    /**
    * Boolean operands for a condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#not_equal_to CasesCaseRule#not_equal_to}
    */
    readonly notEqualTo?: CasesCaseRuleRuleRequiredConditionsNotEqualTo;
}
export declare function casesCaseRuleRuleRequiredConditionsToTerraform(struct?: CasesCaseRuleRuleRequiredConditions | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleRequiredConditionsToHclTerraform(struct?: CasesCaseRuleRuleRequiredConditions | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleRequiredConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesCaseRuleRuleRequiredConditions | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleRequiredConditions | cdktn.IResolvable | undefined);
    private _equalTo;
    get equalTo(): CasesCaseRuleRuleRequiredConditionsEqualToOutputReference;
    putEqualTo(value: CasesCaseRuleRuleRequiredConditionsEqualTo): void;
    resetEqualTo(): void;
    get equalToInput(): cdktn.IResolvable | CasesCaseRuleRuleRequiredConditionsEqualTo | undefined;
    private _notEqualTo;
    get notEqualTo(): CasesCaseRuleRuleRequiredConditionsNotEqualToOutputReference;
    putNotEqualTo(value: CasesCaseRuleRuleRequiredConditionsNotEqualTo): void;
    resetNotEqualTo(): void;
    get notEqualToInput(): cdktn.IResolvable | CasesCaseRuleRuleRequiredConditionsNotEqualTo | undefined;
}
export declare class CasesCaseRuleRuleRequiredConditionsList extends cdktn.ComplexList {
    internalValue?: CasesCaseRuleRuleRequiredConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesCaseRuleRuleRequiredConditionsOutputReference;
}
export interface CasesCaseRuleRuleRequired {
    /**
    * An ordered list of boolean conditions that determine when the field should be required. Conditions are evaluated in order, and the first condition that evaluates to true determines whether the field is required, overriding the default value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#conditions CasesCaseRule#conditions}
    */
    readonly conditions?: CasesCaseRuleRuleRequiredConditions[] | cdktn.IResolvable;
    /**
    * The default required state for the field when none of the specified conditions are met. If true, the field is required by default; if false, the field is optional by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#default_value CasesCaseRule#default_value}
    */
    readonly defaultValue?: boolean | cdktn.IResolvable;
}
export declare function casesCaseRuleRuleRequiredToTerraform(struct?: CasesCaseRuleRuleRequired | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleRequiredToHclTerraform(struct?: CasesCaseRuleRuleRequired | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleRequiredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRuleRequired | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRuleRequired | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): CasesCaseRuleRuleRequiredConditionsList;
    putConditions(value: CasesCaseRuleRuleRequiredConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | CasesCaseRuleRuleRequiredConditions[] | undefined;
    private _defaultValue?;
    get defaultValue(): boolean | cdktn.IResolvable;
    set defaultValue(value: boolean | cdktn.IResolvable);
    resetDefaultValue(): void;
    get defaultValueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CasesCaseRuleRule {
    /**
    * Hidden rule type, used to indicate whether a field is hidden
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#hidden CasesCaseRule#hidden}
    */
    readonly hidden?: CasesCaseRuleRuleHidden;
    /**
    * A required rule type, used to indicate whether a field is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#required CasesCaseRule#required}
    */
    readonly required?: CasesCaseRuleRuleRequired;
}
export declare function casesCaseRuleRuleToTerraform(struct?: CasesCaseRuleRule | cdktn.IResolvable): any;
export declare function casesCaseRuleRuleToHclTerraform(struct?: CasesCaseRuleRule | cdktn.IResolvable): any;
export declare class CasesCaseRuleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesCaseRuleRule | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleRule | cdktn.IResolvable | undefined);
    private _hidden;
    get hidden(): CasesCaseRuleRuleHiddenOutputReference;
    putHidden(value: CasesCaseRuleRuleHidden): void;
    resetHidden(): void;
    get hiddenInput(): cdktn.IResolvable | CasesCaseRuleRuleHidden | undefined;
    private _required;
    get required(): CasesCaseRuleRuleRequiredOutputReference;
    putRequired(value: CasesCaseRuleRuleRequired): void;
    resetRequired(): void;
    get requiredInput(): cdktn.IResolvable | CasesCaseRuleRuleRequired | undefined;
}
export interface CasesCaseRuleTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#key CasesCaseRule#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#value CasesCaseRule#value}
    */
    readonly value?: string;
}
export declare function casesCaseRuleTagsToTerraform(struct?: CasesCaseRuleTags | cdktn.IResolvable): any;
export declare function casesCaseRuleTagsToHclTerraform(struct?: CasesCaseRuleTags | cdktn.IResolvable): any;
export declare class CasesCaseRuleTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesCaseRuleTags | cdktn.IResolvable | undefined;
    set internalValue(value: CasesCaseRuleTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CasesCaseRuleTagsList extends cdktn.ComplexList {
    internalValue?: CasesCaseRuleTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesCaseRuleTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule awscc_cases_case_rule}
*/
export declare class CasesCaseRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cases_case_rule";
    /**
    * Generates CDKTN code for importing a CasesCaseRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CasesCaseRule to import
    * @param importFromId The id of the existing CasesCaseRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CasesCaseRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cases_case_rule awscc_cases_case_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CasesCaseRuleConfig
    */
    constructor(scope: Construct, id: string, config: CasesCaseRuleConfig);
    get caseRuleArn(): string;
    get caseRuleId(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    resetDomainId(): void;
    get domainIdInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rule;
    get rule(): CasesCaseRuleRuleOutputReference;
    putRule(value: CasesCaseRuleRule): void;
    get ruleInput(): cdktn.IResolvable | CasesCaseRuleRule | undefined;
    private _tags;
    get tags(): CasesCaseRuleTagsList;
    putTags(value: CasesCaseRuleTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CasesCaseRuleTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
