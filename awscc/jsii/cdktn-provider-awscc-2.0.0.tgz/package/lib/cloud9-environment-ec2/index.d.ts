/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Cloud9EnvironmentEc2Config extends cdktn.TerraformMetaArguments {
    /**
    * The number of minutes until the running instance is shut down after the environment was last used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#automatic_stop_time_minutes Cloud9EnvironmentEc2#automatic_stop_time_minutes}
    */
    readonly automaticStopTimeMinutes?: number;
    /**
    * The connection type used for connecting to an Amazon EC2 environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#connection_type Cloud9EnvironmentEc2#connection_type}
    */
    readonly connectionType?: string;
    /**
    * The description of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#description Cloud9EnvironmentEc2#description}
    */
    readonly description?: string;
    /**
    * The identifier for the Amazon Machine Image (AMI) that's used to create the EC2 instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#image_id Cloud9EnvironmentEc2#image_id}
    */
    readonly imageId?: string;
    /**
    * The type of instance to connect to the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#instance_type Cloud9EnvironmentEc2#instance_type}
    */
    readonly instanceType?: string;
    /**
    * The name of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#name Cloud9EnvironmentEc2#name}
    */
    readonly name?: string;
    /**
    * The Amazon Resource Name (ARN) of the environment owner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#owner_arn Cloud9EnvironmentEc2#owner_arn}
    */
    readonly ownerArn?: string;
    /**
    * Any AWS CodeCommit source code repositories to be cloned into the development environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#repositories Cloud9EnvironmentEc2#repositories}
    */
    readonly repositories?: Cloud9EnvironmentEc2Repositories[] | cdktn.IResolvable;
    /**
    * The ID of the subnet in Amazon VPC that AWS Cloud9 will use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#subnet_id Cloud9EnvironmentEc2#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * An array of key-value pairs that will be associated with the new AWS Cloud9 development environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#tags Cloud9EnvironmentEc2#tags}
    */
    readonly tags?: Cloud9EnvironmentEc2Tags[] | cdktn.IResolvable;
}
export interface Cloud9EnvironmentEc2Repositories {
    /**
    * The path within the development environment's default file system location to clone the AWS CodeCommit repository into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#path_component Cloud9EnvironmentEc2#path_component}
    */
    readonly pathComponent?: string;
    /**
    * The clone URL of the AWS CodeCommit repository to be cloned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#repository_url Cloud9EnvironmentEc2#repository_url}
    */
    readonly repositoryUrl?: string;
}
export declare function cloud9EnvironmentEc2RepositoriesToTerraform(struct?: Cloud9EnvironmentEc2Repositories | cdktn.IResolvable): any;
export declare function cloud9EnvironmentEc2RepositoriesToHclTerraform(struct?: Cloud9EnvironmentEc2Repositories | cdktn.IResolvable): any;
export declare class Cloud9EnvironmentEc2RepositoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Cloud9EnvironmentEc2Repositories | cdktn.IResolvable | undefined;
    set internalValue(value: Cloud9EnvironmentEc2Repositories | cdktn.IResolvable | undefined);
    private _pathComponent?;
    get pathComponent(): string;
    set pathComponent(value: string);
    resetPathComponent(): void;
    get pathComponentInput(): string | undefined;
    private _repositoryUrl?;
    get repositoryUrl(): string;
    set repositoryUrl(value: string);
    resetRepositoryUrl(): void;
    get repositoryUrlInput(): string | undefined;
}
export declare class Cloud9EnvironmentEc2RepositoriesList extends cdktn.ComplexList {
    internalValue?: Cloud9EnvironmentEc2Repositories[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Cloud9EnvironmentEc2RepositoriesOutputReference;
}
export interface Cloud9EnvironmentEc2Tags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#key Cloud9EnvironmentEc2#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#value Cloud9EnvironmentEc2#value}
    */
    readonly value?: string;
}
export declare function cloud9EnvironmentEc2TagsToTerraform(struct?: Cloud9EnvironmentEc2Tags | cdktn.IResolvable): any;
export declare function cloud9EnvironmentEc2TagsToHclTerraform(struct?: Cloud9EnvironmentEc2Tags | cdktn.IResolvable): any;
export declare class Cloud9EnvironmentEc2TagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Cloud9EnvironmentEc2Tags | cdktn.IResolvable | undefined;
    set internalValue(value: Cloud9EnvironmentEc2Tags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class Cloud9EnvironmentEc2TagsList extends cdktn.ComplexList {
    internalValue?: Cloud9EnvironmentEc2Tags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Cloud9EnvironmentEc2TagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2 awscc_cloud9_environment_ec2}
*/
export declare class Cloud9EnvironmentEc2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloud9_environment_ec2";
    /**
    * Generates CDKTN code for importing a Cloud9EnvironmentEc2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Cloud9EnvironmentEc2 to import
    * @param importFromId The id of the existing Cloud9EnvironmentEc2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Cloud9EnvironmentEc2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloud9_environment_ec2 awscc_cloud9_environment_ec2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Cloud9EnvironmentEc2Config = {}
    */
    constructor(scope: Construct, id: string, config?: Cloud9EnvironmentEc2Config);
    get arn(): string;
    private _automaticStopTimeMinutes?;
    get automaticStopTimeMinutes(): number;
    set automaticStopTimeMinutes(value: number);
    resetAutomaticStopTimeMinutes(): void;
    get automaticStopTimeMinutesInput(): number | undefined;
    private _connectionType?;
    get connectionType(): string;
    set connectionType(value: string);
    resetConnectionType(): void;
    get connectionTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get environmentId(): string;
    get id(): string;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _ownerArn?;
    get ownerArn(): string;
    set ownerArn(value: string);
    resetOwnerArn(): void;
    get ownerArnInput(): string | undefined;
    private _repositories;
    get repositories(): Cloud9EnvironmentEc2RepositoriesList;
    putRepositories(value: Cloud9EnvironmentEc2Repositories[] | cdktn.IResolvable): void;
    resetRepositories(): void;
    get repositoriesInput(): cdktn.IResolvable | Cloud9EnvironmentEc2Repositories[] | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags;
    get tags(): Cloud9EnvironmentEc2TagsList;
    putTags(value: Cloud9EnvironmentEc2Tags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | Cloud9EnvironmentEc2Tags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
