/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAccessanalyzerAnalyzerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/accessanalyzer_analyzer#id DataAwsccAccessanalyzerAnalyzer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions {
}
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions): any;
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions): any;
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions | undefined);
    get accountIds(): string[];
    get resourceArns(): string[];
    get resourceTypes(): string[];
}
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsOutputReference;
}
export interface DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule {
}
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule): any;
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule): any;
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule | undefined);
    private _inclusions;
    get inclusions(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsList;
}
export interface DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration {
}
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration): any;
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration): any;
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration | undefined);
    private _internalAccessAnalysisRule;
    get internalAccessAnalysisRule(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleOutputReference;
}
export interface DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags {
}
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags): any;
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags): any;
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags | undefined);
}
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsOutputReference;
}
export interface DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions {
}
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions): any;
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions): any;
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions | undefined);
    get accountIds(): string[];
    private _resourceTags;
    get resourceTags(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsList;
}
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsOutputReference;
}
export interface DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule {
}
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule): any;
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule): any;
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule | undefined);
    private _exclusions;
    get exclusions(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsList;
}
export interface DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration {
}
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration): any;
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration): any;
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration | undefined);
    private _analysisRule;
    get analysisRule(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleOutputReference;
    get unusedAccessAge(): number;
}
export interface DataAwsccAccessanalyzerAnalyzerAnalyzerConfiguration {
}
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfiguration): any;
export declare function dataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerAnalyzerConfiguration): any;
export declare class DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfiguration | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerAnalyzerConfiguration | undefined);
    private _internalAccessConfiguration;
    get internalAccessConfiguration(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationOutputReference;
    private _unusedAccessConfiguration;
    get unusedAccessConfiguration(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationOutputReference;
}
export interface DataAwsccAccessanalyzerAnalyzerArchiveRulesFilter {
}
export declare function dataAwsccAccessanalyzerAnalyzerArchiveRulesFilterToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerArchiveRulesFilter): any;
export declare function dataAwsccAccessanalyzerAnalyzerArchiveRulesFilterToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerArchiveRulesFilter): any;
export declare class DataAwsccAccessanalyzerAnalyzerArchiveRulesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerArchiveRulesFilter | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerArchiveRulesFilter | undefined);
    get contains(): string[];
    get eq(): string[];
    get exists(): cdktn.IResolvable;
    get neq(): string[];
    get property(): string;
}
export declare class DataAwsccAccessanalyzerAnalyzerArchiveRulesFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAccessanalyzerAnalyzerArchiveRulesFilterOutputReference;
}
export interface DataAwsccAccessanalyzerAnalyzerArchiveRules {
}
export declare function dataAwsccAccessanalyzerAnalyzerArchiveRulesToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerArchiveRules): any;
export declare function dataAwsccAccessanalyzerAnalyzerArchiveRulesToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerArchiveRules): any;
export declare class DataAwsccAccessanalyzerAnalyzerArchiveRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerArchiveRules | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerArchiveRules | undefined);
    private _filter;
    get filter(): DataAwsccAccessanalyzerAnalyzerArchiveRulesFilterList;
    get ruleName(): string;
}
export declare class DataAwsccAccessanalyzerAnalyzerArchiveRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAccessanalyzerAnalyzerArchiveRulesOutputReference;
}
export interface DataAwsccAccessanalyzerAnalyzerTags {
}
export declare function dataAwsccAccessanalyzerAnalyzerTagsToTerraform(struct?: DataAwsccAccessanalyzerAnalyzerTags): any;
export declare function dataAwsccAccessanalyzerAnalyzerTagsToHclTerraform(struct?: DataAwsccAccessanalyzerAnalyzerTags): any;
export declare class DataAwsccAccessanalyzerAnalyzerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAccessanalyzerAnalyzerTags | undefined;
    set internalValue(value: DataAwsccAccessanalyzerAnalyzerTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAccessanalyzerAnalyzerTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAccessanalyzerAnalyzerTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/accessanalyzer_analyzer awscc_accessanalyzer_analyzer}
*/
export declare class DataAwsccAccessanalyzerAnalyzer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_accessanalyzer_analyzer";
    /**
    * Generates CDKTN code for importing a DataAwsccAccessanalyzerAnalyzer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAccessanalyzerAnalyzer to import
    * @param importFromId The id of the existing DataAwsccAccessanalyzerAnalyzer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/accessanalyzer_analyzer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAccessanalyzerAnalyzer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/accessanalyzer_analyzer awscc_accessanalyzer_analyzer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAccessanalyzerAnalyzerConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAccessanalyzerAnalyzerConfig);
    private _analyzerConfiguration;
    get analyzerConfiguration(): DataAwsccAccessanalyzerAnalyzerAnalyzerConfigurationOutputReference;
    get analyzerName(): string;
    private _archiveRules;
    get archiveRules(): DataAwsccAccessanalyzerAnalyzerArchiveRulesList;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _tags;
    get tags(): DataAwsccAccessanalyzerAnalyzerTagsList;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
