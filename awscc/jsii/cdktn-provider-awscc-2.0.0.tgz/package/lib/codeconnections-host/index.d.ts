/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodeconnectionsHostConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#name CodeconnectionsHost#name}
    */
    readonly name: string;
    /**
    * The endpoint of the infrastructure where your provider type is installed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#provider_endpoint CodeconnectionsHost#provider_endpoint}
    */
    readonly providerEndpoint: string;
    /**
    * The name of the installed provider to be associated with your connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#provider_type CodeconnectionsHost#provider_type}
    */
    readonly providerType: string;
    /**
    * Tags to apply to the host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#tags CodeconnectionsHost#tags}
    */
    readonly tags?: CodeconnectionsHostTags[] | cdktn.IResolvable;
    /**
    * The VPC configuration provisioned for the host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#vpc_configuration CodeconnectionsHost#vpc_configuration}
    */
    readonly vpcConfiguration?: CodeconnectionsHostVpcConfiguration;
}
export interface CodeconnectionsHostTags {
    /**
    * The tag's key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#key CodeconnectionsHost#key}
    */
    readonly key?: string;
    /**
    * The tag's value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#value CodeconnectionsHost#value}
    */
    readonly value?: string;
}
export declare function codeconnectionsHostTagsToTerraform(struct?: CodeconnectionsHostTags | cdktn.IResolvable): any;
export declare function codeconnectionsHostTagsToHclTerraform(struct?: CodeconnectionsHostTags | cdktn.IResolvable): any;
export declare class CodeconnectionsHostTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodeconnectionsHostTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodeconnectionsHostTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodeconnectionsHostTagsList extends cdktn.ComplexList {
    internalValue?: CodeconnectionsHostTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodeconnectionsHostTagsOutputReference;
}
export interface CodeconnectionsHostVpcConfiguration {
    /**
    * The ID of the security group or security groups associated with the Amazon VPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#security_group_ids CodeconnectionsHost#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * The ID of the subnet or subnets associated with the Amazon VPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#subnet_ids CodeconnectionsHost#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * The value of the Transport Layer Security (TLS) certificate associated with the infrastructure where your provider type is installed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#tls_certificate CodeconnectionsHost#tls_certificate}
    */
    readonly tlsCertificate?: string;
    /**
    * The ID of the Amazon VPC connected to the infrastructure where your provider type is installed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#vpc_id CodeconnectionsHost#vpc_id}
    */
    readonly vpcId?: string;
}
export declare function codeconnectionsHostVpcConfigurationToTerraform(struct?: CodeconnectionsHostVpcConfiguration | cdktn.IResolvable): any;
export declare function codeconnectionsHostVpcConfigurationToHclTerraform(struct?: CodeconnectionsHostVpcConfiguration | cdktn.IResolvable): any;
export declare class CodeconnectionsHostVpcConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodeconnectionsHostVpcConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodeconnectionsHostVpcConfiguration | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tlsCertificate?;
    get tlsCertificate(): string;
    set tlsCertificate(value: string);
    resetTlsCertificate(): void;
    get tlsCertificateInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host awscc_codeconnections_host}
*/
export declare class CodeconnectionsHost extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codeconnections_host";
    /**
    * Generates CDKTN code for importing a CodeconnectionsHost resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodeconnectionsHost to import
    * @param importFromId The id of the existing CodeconnectionsHost that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodeconnectionsHost to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/codeconnections_host awscc_codeconnections_host} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodeconnectionsHostConfig
    */
    constructor(scope: Construct, id: string, config: CodeconnectionsHostConfig);
    get hostArn(): string;
    get hostId(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerEndpoint?;
    get providerEndpoint(): string;
    set providerEndpoint(value: string);
    get providerEndpointInput(): string | undefined;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    get providerTypeInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): CodeconnectionsHostTagsList;
    putTags(value: CodeconnectionsHostTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodeconnectionsHostTags[] | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): CodeconnectionsHostVpcConfigurationOutputReference;
    putVpcConfiguration(value: CodeconnectionsHostVpcConfiguration): void;
    resetVpcConfiguration(): void;
    get vpcConfigurationInput(): cdktn.IResolvable | CodeconnectionsHostVpcConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
