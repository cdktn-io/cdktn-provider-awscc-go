/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectContactFlowModuleVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the contact flow module (ARN) this version is tied to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_contact_flow_module_version#contact_flow_module_id ConnectContactFlowModuleVersion#contact_flow_module_id}
    */
    readonly contactFlowModuleId: string;
    /**
    * The description of the version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_contact_flow_module_version#description ConnectContactFlowModuleVersion#description}
    */
    readonly description?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_contact_flow_module_version awscc_connect_contact_flow_module_version}
*/
export declare class ConnectContactFlowModuleVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_contact_flow_module_version";
    /**
    * Generates CDKTN code for importing a ConnectContactFlowModuleVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectContactFlowModuleVersion to import
    * @param importFromId The id of the existing ConnectContactFlowModuleVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_contact_flow_module_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectContactFlowModuleVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_contact_flow_module_version awscc_connect_contact_flow_module_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectContactFlowModuleVersionConfig
    */
    constructor(scope: Construct, id: string, config: ConnectContactFlowModuleVersionConfig);
    private _contactFlowModuleId?;
    get contactFlowModuleId(): string;
    set contactFlowModuleId(value: string);
    get contactFlowModuleIdInput(): string | undefined;
    get contactFlowModuleVersionArn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get flowModuleContentSha256(): string;
    get id(): string;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
