/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAgentregistryRegistryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/agentregistry_registry#id DataAwsccAgentregistryRegistry#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAgentregistryRegistryApprovalConfiguration {
}
export declare function dataAwsccAgentregistryRegistryApprovalConfigurationToTerraform(struct?: DataAwsccAgentregistryRegistryApprovalConfiguration): any;
export declare function dataAwsccAgentregistryRegistryApprovalConfigurationToHclTerraform(struct?: DataAwsccAgentregistryRegistryApprovalConfiguration): any;
export declare class DataAwsccAgentregistryRegistryApprovalConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryApprovalConfiguration | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryApprovalConfiguration | undefined);
    get autoApprovalRules(): string[];
}
export interface DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides {
}
export declare function dataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesToTerraform(struct?: DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides): any;
export declare function dataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesToHclTerraform(struct?: DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides): any;
export declare class DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides | undefined);
    get recordType(): string;
    get schema(): string;
}
export declare class DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesOutputReference;
}
export interface DataAwsccAgentregistryRegistryCustomMetadataSchemaConfiguration {
}
export declare function dataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationToTerraform(struct?: DataAwsccAgentregistryRegistryCustomMetadataSchemaConfiguration): any;
export declare function dataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationToHclTerraform(struct?: DataAwsccAgentregistryRegistryCustomMetadataSchemaConfiguration): any;
export declare class DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryCustomMetadataSchemaConfiguration | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryCustomMetadataSchemaConfiguration | undefined);
    get defaultSchema(): string;
    private _recordTypeSchemaOverrides;
    get recordTypeSchemaOverrides(): DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesList;
}
export interface DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue {
}
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue): any;
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToHclTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue): any;
export declare class DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | undefined);
    get matchValueString(): string;
    get matchValueStringList(): string[];
}
export interface DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue {
}
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue): any;
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToHclTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue): any;
export declare class DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | undefined);
    get claimMatchOperator(): string;
    private _claimMatchValue;
    get claimMatchValue(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference;
}
export interface DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims {
}
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims): any;
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToHclTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims): any;
export declare class DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | undefined);
    private _authorizingClaimMatchValue;
    get authorizingClaimMatchValue(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference;
    get inboundTokenClaimName(): string;
    get inboundTokenClaimValueType(): string;
}
export declare class DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference;
}
export interface DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer {
}
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerToTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer): any;
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerToHclTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer): any;
export declare class DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer | undefined);
    get allowedAudience(): string[];
    get allowedClients(): string[];
    get allowedScopes(): string[];
    private _customClaims;
    get customClaims(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList;
    get discoveryUrl(): string;
}
export interface DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration {
}
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationToTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration): any;
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationToHclTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration): any;
export declare class DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration | undefined);
    private _customJwtAuthorizer;
    get customJwtAuthorizer(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerOutputReference;
}
export interface DataAwsccAgentregistryRegistryDiscoveryConfiguration {
}
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationToTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfiguration): any;
export declare function dataAwsccAgentregistryRegistryDiscoveryConfigurationToHclTerraform(struct?: DataAwsccAgentregistryRegistryDiscoveryConfiguration): any;
export declare class DataAwsccAgentregistryRegistryDiscoveryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryDiscoveryConfiguration | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryDiscoveryConfiguration | undefined);
    private _authorizerConfiguration;
    get authorizerConfiguration(): DataAwsccAgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationOutputReference;
}
export interface DataAwsccAgentregistryRegistryEncryptionConfiguration {
}
export declare function dataAwsccAgentregistryRegistryEncryptionConfigurationToTerraform(struct?: DataAwsccAgentregistryRegistryEncryptionConfiguration): any;
export declare function dataAwsccAgentregistryRegistryEncryptionConfigurationToHclTerraform(struct?: DataAwsccAgentregistryRegistryEncryptionConfiguration): any;
export declare class DataAwsccAgentregistryRegistryEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryEncryptionConfiguration | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryEncryptionConfiguration | undefined);
    get kmsKeyArn(): string;
}
export interface DataAwsccAgentregistryRegistryTags {
}
export declare function dataAwsccAgentregistryRegistryTagsToTerraform(struct?: DataAwsccAgentregistryRegistryTags): any;
export declare function dataAwsccAgentregistryRegistryTagsToHclTerraform(struct?: DataAwsccAgentregistryRegistryTags): any;
export declare class DataAwsccAgentregistryRegistryTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAgentregistryRegistryTags | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAgentregistryRegistryTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAgentregistryRegistryTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/agentregistry_registry awscc_agentregistry_registry}
*/
export declare class DataAwsccAgentregistryRegistry extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_agentregistry_registry";
    /**
    * Generates CDKTN code for importing a DataAwsccAgentregistryRegistry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAgentregistryRegistry to import
    * @param importFromId The id of the existing DataAwsccAgentregistryRegistry that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/agentregistry_registry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAgentregistryRegistry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/agentregistry_registry awscc_agentregistry_registry} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAgentregistryRegistryConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAgentregistryRegistryConfig);
    private _approvalConfiguration;
    get approvalConfiguration(): DataAwsccAgentregistryRegistryApprovalConfigurationOutputReference;
    get authorizerType(): string;
    get autoDetectionEnabled(): cdktn.IResolvable;
    get autoDetectionScope(): string;
    get autoDetectionStatus(): string;
    get createdAt(): string;
    private _customMetadataSchemaConfiguration;
    get customMetadataSchemaConfiguration(): DataAwsccAgentregistryRegistryCustomMetadataSchemaConfigurationOutputReference;
    get description(): string;
    private _discoveryConfiguration;
    get discoveryConfiguration(): DataAwsccAgentregistryRegistryDiscoveryConfigurationOutputReference;
    private _encryptionConfiguration;
    get encryptionConfiguration(): DataAwsccAgentregistryRegistryEncryptionConfigurationOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    get registryArn(): string;
    get registryId(): string;
    get status(): string;
    private _tags;
    get tags(): DataAwsccAgentregistryRegistryTagsList;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
