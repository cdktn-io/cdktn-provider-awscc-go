/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectQueueConfig extends cdktn.TerraformMetaArguments {
    /**
    * The email addresses that agents can use when replying to or initiating email contacts
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#additional_email_addresses ConnectQueue#additional_email_addresses}
    */
    readonly additionalEmailAddresses?: ConnectQueueAdditionalEmailAddresses[] | cdktn.IResolvable;
    /**
    * The description of the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#description ConnectQueue#description}
    */
    readonly description?: string;
    /**
    * The identifier for the hours of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#hours_of_operation_arn ConnectQueue#hours_of_operation_arn}
    */
    readonly hoursOfOperationArn: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#instance_arn ConnectQueue#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The maximum number of contacts that can be in the queue before it is considered full.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#max_contacts ConnectQueue#max_contacts}
    */
    readonly maxContacts?: number;
    /**
    * The name of the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#name ConnectQueue#name}
    */
    readonly name: string;
    /**
    * The outbound caller ID name, number, and outbound whisper flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#outbound_caller_config ConnectQueue#outbound_caller_config}
    */
    readonly outboundCallerConfig?: ConnectQueueOutboundCallerConfig;
    /**
    * The outbound email configuration for a specified queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#outbound_email_config ConnectQueue#outbound_email_config}
    */
    readonly outboundEmailConfig?: ConnectQueueOutboundEmailConfig;
    /**
    * The quick connects available to agents who are working the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#quick_connect_arns ConnectQueue#quick_connect_arns}
    */
    readonly quickConnectArns?: string[];
    /**
    * The status of the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#status ConnectQueue#status}
    */
    readonly status?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#tags ConnectQueue#tags}
    */
    readonly tags?: ConnectQueueTags[] | cdktn.IResolvable;
}
export interface ConnectQueueAdditionalEmailAddresses {
    /**
    * The Amazon Resource Name (ARN) of the email address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#email_address_arn ConnectQueue#email_address_arn}
    */
    readonly emailAddressArn?: string;
}
export declare function connectQueueAdditionalEmailAddressesToTerraform(struct?: ConnectQueueAdditionalEmailAddresses | cdktn.IResolvable): any;
export declare function connectQueueAdditionalEmailAddressesToHclTerraform(struct?: ConnectQueueAdditionalEmailAddresses | cdktn.IResolvable): any;
export declare class ConnectQueueAdditionalEmailAddressesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectQueueAdditionalEmailAddresses | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQueueAdditionalEmailAddresses | cdktn.IResolvable | undefined);
    private _emailAddressArn?;
    get emailAddressArn(): string;
    set emailAddressArn(value: string);
    resetEmailAddressArn(): void;
    get emailAddressArnInput(): string | undefined;
}
export declare class ConnectQueueAdditionalEmailAddressesList extends cdktn.ComplexList {
    internalValue?: ConnectQueueAdditionalEmailAddresses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectQueueAdditionalEmailAddressesOutputReference;
}
export interface ConnectQueueOutboundCallerConfig {
    /**
    * The caller ID name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#outbound_caller_id_name ConnectQueue#outbound_caller_id_name}
    */
    readonly outboundCallerIdName?: string;
    /**
    * The caller ID number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#outbound_caller_id_number_arn ConnectQueue#outbound_caller_id_number_arn}
    */
    readonly outboundCallerIdNumberArn?: string;
    /**
    * The outbound whisper flow to be used during an outbound call.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#outbound_flow_arn ConnectQueue#outbound_flow_arn}
    */
    readonly outboundFlowArn?: string;
}
export declare function connectQueueOutboundCallerConfigToTerraform(struct?: ConnectQueueOutboundCallerConfig | cdktn.IResolvable): any;
export declare function connectQueueOutboundCallerConfigToHclTerraform(struct?: ConnectQueueOutboundCallerConfig | cdktn.IResolvable): any;
export declare class ConnectQueueOutboundCallerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectQueueOutboundCallerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQueueOutboundCallerConfig | cdktn.IResolvable | undefined);
    private _outboundCallerIdName?;
    get outboundCallerIdName(): string;
    set outboundCallerIdName(value: string);
    resetOutboundCallerIdName(): void;
    get outboundCallerIdNameInput(): string | undefined;
    private _outboundCallerIdNumberArn?;
    get outboundCallerIdNumberArn(): string;
    set outboundCallerIdNumberArn(value: string);
    resetOutboundCallerIdNumberArn(): void;
    get outboundCallerIdNumberArnInput(): string | undefined;
    private _outboundFlowArn?;
    get outboundFlowArn(): string;
    set outboundFlowArn(value: string);
    resetOutboundFlowArn(): void;
    get outboundFlowArnInput(): string | undefined;
}
export interface ConnectQueueOutboundEmailConfig {
    /**
    * The email address connect resource ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#outbound_email_address_id ConnectQueue#outbound_email_address_id}
    */
    readonly outboundEmailAddressId?: string;
}
export declare function connectQueueOutboundEmailConfigToTerraform(struct?: ConnectQueueOutboundEmailConfig | cdktn.IResolvable): any;
export declare function connectQueueOutboundEmailConfigToHclTerraform(struct?: ConnectQueueOutboundEmailConfig | cdktn.IResolvable): any;
export declare class ConnectQueueOutboundEmailConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectQueueOutboundEmailConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQueueOutboundEmailConfig | cdktn.IResolvable | undefined);
    private _outboundEmailAddressId?;
    get outboundEmailAddressId(): string;
    set outboundEmailAddressId(value: string);
    resetOutboundEmailAddressId(): void;
    get outboundEmailAddressIdInput(): string | undefined;
}
export interface ConnectQueueTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#key ConnectQueue#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#value ConnectQueue#value}
    */
    readonly value?: string;
}
export declare function connectQueueTagsToTerraform(struct?: ConnectQueueTags | cdktn.IResolvable): any;
export declare function connectQueueTagsToHclTerraform(struct?: ConnectQueueTags | cdktn.IResolvable): any;
export declare class ConnectQueueTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectQueueTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQueueTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectQueueTagsList extends cdktn.ComplexList {
    internalValue?: ConnectQueueTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectQueueTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue awscc_connect_queue}
*/
export declare class ConnectQueue extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_queue";
    /**
    * Generates CDKTN code for importing a ConnectQueue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectQueue to import
    * @param importFromId The id of the existing ConnectQueue that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectQueue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_queue awscc_connect_queue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectQueueConfig
    */
    constructor(scope: Construct, id: string, config: ConnectQueueConfig);
    private _additionalEmailAddresses;
    get additionalEmailAddresses(): ConnectQueueAdditionalEmailAddressesList;
    putAdditionalEmailAddresses(value: ConnectQueueAdditionalEmailAddresses[] | cdktn.IResolvable): void;
    resetAdditionalEmailAddresses(): void;
    get additionalEmailAddressesInput(): cdktn.IResolvable | ConnectQueueAdditionalEmailAddresses[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hoursOfOperationArn?;
    get hoursOfOperationArn(): string;
    set hoursOfOperationArn(value: string);
    get hoursOfOperationArnInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get lastModifiedRegion(): string;
    get lastModifiedTime(): number;
    private _maxContacts?;
    get maxContacts(): number;
    set maxContacts(value: number);
    resetMaxContacts(): void;
    get maxContactsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outboundCallerConfig;
    get outboundCallerConfig(): ConnectQueueOutboundCallerConfigOutputReference;
    putOutboundCallerConfig(value: ConnectQueueOutboundCallerConfig): void;
    resetOutboundCallerConfig(): void;
    get outboundCallerConfigInput(): cdktn.IResolvable | ConnectQueueOutboundCallerConfig | undefined;
    private _outboundEmailConfig;
    get outboundEmailConfig(): ConnectQueueOutboundEmailConfigOutputReference;
    putOutboundEmailConfig(value: ConnectQueueOutboundEmailConfig): void;
    resetOutboundEmailConfig(): void;
    get outboundEmailConfigInput(): cdktn.IResolvable | ConnectQueueOutboundEmailConfig | undefined;
    get queueArn(): string;
    private _quickConnectArns?;
    get quickConnectArns(): string[];
    set quickConnectArns(value: string[]);
    resetQuickConnectArns(): void;
    get quickConnectArnsInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags;
    get tags(): ConnectQueueTagsList;
    putTags(value: ConnectQueueTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectQueueTags[] | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
