/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAppconfigDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/appconfig_deployment#id DataAwsccAppconfigDeployment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAppconfigDeploymentDynamicExtensionParameters {
}
export declare function dataAwsccAppconfigDeploymentDynamicExtensionParametersToTerraform(struct?: DataAwsccAppconfigDeploymentDynamicExtensionParameters): any;
export declare function dataAwsccAppconfigDeploymentDynamicExtensionParametersToHclTerraform(struct?: DataAwsccAppconfigDeploymentDynamicExtensionParameters): any;
export declare class DataAwsccAppconfigDeploymentDynamicExtensionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigDeploymentDynamicExtensionParameters | undefined;
    set internalValue(value: DataAwsccAppconfigDeploymentDynamicExtensionParameters | undefined);
    get extensionReference(): string;
    get parameterName(): string;
    get parameterValue(): string;
}
export declare class DataAwsccAppconfigDeploymentDynamicExtensionParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigDeploymentDynamicExtensionParametersOutputReference;
}
export interface DataAwsccAppconfigDeploymentTags {
}
export declare function dataAwsccAppconfigDeploymentTagsToTerraform(struct?: DataAwsccAppconfigDeploymentTags): any;
export declare function dataAwsccAppconfigDeploymentTagsToHclTerraform(struct?: DataAwsccAppconfigDeploymentTags): any;
export declare class DataAwsccAppconfigDeploymentTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigDeploymentTags | undefined;
    set internalValue(value: DataAwsccAppconfigDeploymentTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAppconfigDeploymentTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigDeploymentTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/appconfig_deployment awscc_appconfig_deployment}
*/
export declare class DataAwsccAppconfigDeployment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_appconfig_deployment";
    /**
    * Generates CDKTN code for importing a DataAwsccAppconfigDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAppconfigDeployment to import
    * @param importFromId The id of the existing DataAwsccAppconfigDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/appconfig_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAppconfigDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/data-sources/appconfig_deployment awscc_appconfig_deployment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAppconfigDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAppconfigDeploymentConfig);
    get applicationId(): string;
    get configurationProfileId(): string;
    get configurationVersion(): string;
    get deploymentNumber(): string;
    get deploymentStrategyId(): string;
    get description(): string;
    private _dynamicExtensionParameters;
    get dynamicExtensionParameters(): DataAwsccAppconfigDeploymentDynamicExtensionParametersList;
    get environmentId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get kmsKeyIdentifier(): string;
    get state(): string;
    private _tags;
    get tags(): DataAwsccAppconfigDeploymentTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
