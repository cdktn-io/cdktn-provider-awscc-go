/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreOnlineEvaluationConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The configuration for clustering analysis of evaluation results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#clustering_config BedrockagentcoreOnlineEvaluationConfig#clustering_config}
    */
    readonly clusteringConfig?: BedrockagentcoreOnlineEvaluationConfigClusteringConfig;
    /**
    * The data source configuration that specifies CloudWatch log groups and service names to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#data_source_config BedrockagentcoreOnlineEvaluationConfig#data_source_config}
    */
    readonly dataSourceConfig: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig;
    /**
    * The description of the online evaluation configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#description BedrockagentcoreOnlineEvaluationConfig#description}
    */
    readonly description?: string;
    /**
    * The Amazon Resource Name (ARN) of the IAM role that grants permissions for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluation_execution_role_arn BedrockagentcoreOnlineEvaluationConfig#evaluation_execution_role_arn}
    */
    readonly evaluationExecutionRoleArn: string;
    /**
    * The list of evaluators to apply during online evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluators BedrockagentcoreOnlineEvaluationConfig#evaluators}
    */
    readonly evaluators?: BedrockagentcoreOnlineEvaluationConfigEvaluators[] | cdktn.IResolvable;
    /**
    * The execution status indicating whether the online evaluation is currently running.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#execution_status BedrockagentcoreOnlineEvaluationConfig#execution_status}
    */
    readonly executionStatus?: string;
    /**
    * The list of insights to enable for failure analysis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#insights BedrockagentcoreOnlineEvaluationConfig#insights}
    */
    readonly insights?: BedrockagentcoreOnlineEvaluationConfigInsights[] | cdktn.IResolvable;
    /**
    * The name of the online evaluation configuration. Must be unique within your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#online_evaluation_config_name BedrockagentcoreOnlineEvaluationConfig#online_evaluation_config_name}
    */
    readonly onlineEvaluationConfigName: string;
    /**
    * The configuration that specifies where evaluation results should be written.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#output_config BedrockagentcoreOnlineEvaluationConfig#output_config}
    */
    readonly outputConfig?: BedrockagentcoreOnlineEvaluationConfigOutputConfig;
    /**
    * The evaluation rule that defines sampling configuration, filters, and session detection settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#rule BedrockagentcoreOnlineEvaluationConfig#rule}
    */
    readonly rule: BedrockagentcoreOnlineEvaluationConfigRule;
    /**
    * A list of tags to assign to the online evaluation configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#tags BedrockagentcoreOnlineEvaluationConfig#tags}
    */
    readonly tags?: BedrockagentcoreOnlineEvaluationConfigTags[] | cdktn.IResolvable;
}
export interface BedrockagentcoreOnlineEvaluationConfigClusteringConfig {
    /**
    * The list of frequencies at which clustering reports are generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#frequencies BedrockagentcoreOnlineEvaluationConfig#frequencies}
    */
    readonly frequencies?: string[];
}
export declare function bedrockagentcoreOnlineEvaluationConfigClusteringConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigClusteringConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigClusteringConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigClusteringConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigClusteringConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigClusteringConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigClusteringConfig | cdktn.IResolvable | undefined);
    private _frequencies?;
    get frequencies(): string[];
    set frequencies(value: string[]);
    resetFrequencies(): void;
    get frequenciesInput(): string[] | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs {
    /**
    * The list of CloudWatch log group name prefixes to monitor for agent traces. Mutually exclusive with LogGroupNames; specify exactly one of the two selectors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#log_group_name_prefixes BedrockagentcoreOnlineEvaluationConfig#log_group_name_prefixes}
    */
    readonly logGroupNamePrefixes?: string[];
    /**
    * The list of CloudWatch log group names to monitor for agent traces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#log_group_names BedrockagentcoreOnlineEvaluationConfig#log_group_names}
    */
    readonly logGroupNames?: string[];
    /**
    * The list of service names to filter traces within the specified log groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#service_names BedrockagentcoreOnlineEvaluationConfig#service_names}
    */
    readonly serviceNames: string[];
}
export declare function bedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | cdktn.IResolvable | undefined);
    private _logGroupNamePrefixes?;
    get logGroupNamePrefixes(): string[];
    set logGroupNamePrefixes(value: string[]);
    resetLogGroupNamePrefixes(): void;
    get logGroupNamePrefixesInput(): string[] | undefined;
    private _logGroupNames?;
    get logGroupNames(): string[];
    set logGroupNames(value: string[]);
    resetLogGroupNames(): void;
    get logGroupNamesInput(): string[] | undefined;
    private _serviceNames?;
    get serviceNames(): string[];
    set serviceNames(value: string[]);
    get serviceNamesInput(): string[] | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigDataSourceConfig {
    /**
    * The configuration for reading agent traces from CloudWatch logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#cloudwatch_logs BedrockagentcoreOnlineEvaluationConfig#cloudwatch_logs}
    */
    readonly cloudwatchLogs: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs;
}
export declare function bedrockagentcoreOnlineEvaluationConfigDataSourceConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigDataSourceConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigDataSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | cdktn.IResolvable | undefined);
    private _cloudwatchLogs;
    get cloudwatchLogs(): BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsOutputReference;
    putCloudwatchLogs(value: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs): void;
    get cloudwatchLogsInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigEvaluators {
    /**
    * The ID of the evaluator: a built-in evaluator ID (Builtin.*), a managed third-party evaluator ID (ThirdParty.<provider>.<name>), or a custom evaluator ID. For a custom evaluator in the same template, use Fn::GetAtt with EvaluatorId. Ref returns the evaluator ARN, which this property does not accept.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluator_id BedrockagentcoreOnlineEvaluationConfig#evaluator_id}
    */
    readonly evaluatorId?: string;
}
export declare function bedrockagentcoreOnlineEvaluationConfigEvaluatorsToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigEvaluators | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigEvaluatorsToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigEvaluators | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigEvaluatorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigEvaluators | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigEvaluators | cdktn.IResolvable | undefined);
    private _evaluatorId?;
    get evaluatorId(): string;
    set evaluatorId(value: string);
    resetEvaluatorId(): void;
    get evaluatorIdInput(): string | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigEvaluatorsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigEvaluators[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigEvaluatorsOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigInsights {
    /**
    * The unique identifier of the insight.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#insight_id BedrockagentcoreOnlineEvaluationConfig#insight_id}
    */
    readonly insightId?: string;
}
export declare function bedrockagentcoreOnlineEvaluationConfigInsightsToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigInsights | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigInsightsToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigInsights | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigInsightsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigInsights | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigInsights | cdktn.IResolvable | undefined);
    private _insightId?;
    get insightId(): string;
    set insightId(value: string);
    resetInsightId(): void;
    get insightIdInput(): string | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigInsightsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigInsights[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigInsightsOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig {
    /**
    * The CloudWatch log group name for evaluation results. Omit to use the service-managed default log group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#log_group_name BedrockagentcoreOnlineEvaluationConfig#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The CloudWatch metrics namespace for evaluation result metrics. Omit to use the service-managed default namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#metrics_namespace BedrockagentcoreOnlineEvaluationConfig#metrics_namespace}
    */
    readonly metricsNamespace?: string;
    /**
    * Where evaluation results are written. DEDICATED_LOG_GROUP, the default when omitted, writes to a dedicated result log group. SOURCE_LOG_GROUP writes results back to the trace source log group; LogGroupName must not be specified with SOURCE_LOG_GROUP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#result_destination BedrockagentcoreOnlineEvaluationConfig#result_destination}
    */
    readonly resultDestination?: string;
}
export declare function bedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig | cdktn.IResolvable | undefined);
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _metricsNamespace?;
    get metricsNamespace(): string;
    set metricsNamespace(value: string);
    resetMetricsNamespace(): void;
    get metricsNamespaceInput(): string | undefined;
    private _resultDestination?;
    get resultDestination(): string;
    set resultDestination(value: string);
    resetResultDestination(): void;
    get resultDestinationInput(): string | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigOutputConfig {
    /**
    * The CloudWatch configuration for writing evaluation results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#cloudwatch_config BedrockagentcoreOnlineEvaluationConfig#cloudwatch_config}
    */
    readonly cloudwatchConfig?: BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig;
}
export declare function bedrockagentcoreOnlineEvaluationConfigOutputConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigOutputConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigOutputConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigOutputConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigOutputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigOutputConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigOutputConfig | cdktn.IResolvable | undefined);
    private _cloudwatchConfig;
    get cloudwatchConfig(): BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigOutputReference;
    putCloudwatchConfig(value: BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig): void;
    resetCloudwatchConfig(): void;
    get cloudwatchConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigRuleFiltersValue {
    /**
    * The boolean value for true/false filtering conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#boolean_value BedrockagentcoreOnlineEvaluationConfig#boolean_value}
    */
    readonly booleanValue?: boolean | cdktn.IResolvable;
    /**
    * The numeric value for numerical filtering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#double_value BedrockagentcoreOnlineEvaluationConfig#double_value}
    */
    readonly doubleValue?: number;
    /**
    * The string value for text-based filtering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#string_value BedrockagentcoreOnlineEvaluationConfig#string_value}
    */
    readonly stringValue?: string;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleFiltersValueToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleFiltersValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleFiltersValueToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleFiltersValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleFiltersValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRuleFiltersValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRuleFiltersValue | cdktn.IResolvable | undefined);
    private _booleanValue?;
    get booleanValue(): boolean | cdktn.IResolvable;
    set booleanValue(value: boolean | cdktn.IResolvable);
    resetBooleanValue(): void;
    get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigRuleFilters {
    /**
    * The key or field name to filter on within the agent trace data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#key BedrockagentcoreOnlineEvaluationConfig#key}
    */
    readonly key?: string;
    /**
    * The comparison operator to use for filtering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#operator BedrockagentcoreOnlineEvaluationConfig#operator}
    */
    readonly operator?: string;
    /**
    * The value used in filter comparisons.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#value BedrockagentcoreOnlineEvaluationConfig#value}
    */
    readonly value?: BedrockagentcoreOnlineEvaluationConfigRuleFiltersValue;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleFiltersToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleFilters | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleFiltersToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleFilters | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRuleFilters | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRuleFilters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _value;
    get value(): BedrockagentcoreOnlineEvaluationConfigRuleFiltersValueOutputReference;
    putValue(value: BedrockagentcoreOnlineEvaluationConfigRuleFiltersValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRuleFiltersValue | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigRuleFiltersList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigRuleFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigRuleFiltersOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig {
    /**
    * The percentage of agent traces to sample for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#sampling_percentage BedrockagentcoreOnlineEvaluationConfig#sampling_percentage}
    */
    readonly samplingPercentage: number;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | cdktn.IResolvable | undefined);
    private _samplingPercentage?;
    get samplingPercentage(): number;
    set samplingPercentage(value: number);
    get samplingPercentageInput(): number | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig {
    /**
    * The number of minutes of inactivity after which an agent session is considered complete.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#session_timeout_minutes BedrockagentcoreOnlineEvaluationConfig#session_timeout_minutes}
    */
    readonly sessionTimeoutMinutes?: number;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleSessionConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleSessionConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleSessionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | cdktn.IResolvable | undefined);
    private _sessionTimeoutMinutes?;
    get sessionTimeoutMinutes(): number;
    set sessionTimeoutMinutes(value: number);
    resetSessionTimeoutMinutes(): void;
    get sessionTimeoutMinutesInput(): number | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigRule {
    /**
    * The list of filters that determine which agent traces should be included in the evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#filters BedrockagentcoreOnlineEvaluationConfig#filters}
    */
    readonly filters?: BedrockagentcoreOnlineEvaluationConfigRuleFilters[] | cdktn.IResolvable;
    /**
    * The configuration that controls what percentage of agent traces are sampled for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#sampling_config BedrockagentcoreOnlineEvaluationConfig#sampling_config}
    */
    readonly samplingConfig: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig;
    /**
    * The configuration that defines how agent sessions are detected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#session_config BedrockagentcoreOnlineEvaluationConfig#session_config}
    */
    readonly sessionConfig?: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRule | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRule | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRule | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRule | cdktn.IResolvable | undefined);
    private _filters;
    get filters(): BedrockagentcoreOnlineEvaluationConfigRuleFiltersList;
    putFilters(value: BedrockagentcoreOnlineEvaluationConfigRuleFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRuleFilters[] | undefined;
    private _samplingConfig;
    get samplingConfig(): BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigOutputReference;
    putSamplingConfig(value: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig): void;
    get samplingConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | undefined;
    private _sessionConfig;
    get sessionConfig(): BedrockagentcoreOnlineEvaluationConfigRuleSessionConfigOutputReference;
    putSessionConfig(value: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig): void;
    resetSessionConfig(): void;
    get sessionConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | undefined;
}
export interface BedrockagentcoreOnlineEvaluationConfigTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#key BedrockagentcoreOnlineEvaluationConfig#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#value BedrockagentcoreOnlineEvaluationConfig#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcoreOnlineEvaluationConfigTagsToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigTags | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigTagsToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigTags | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config awscc_bedrockagentcore_online_evaluation_config}
*/
export declare class BedrockagentcoreOnlineEvaluationConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_online_evaluation_config";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreOnlineEvaluationConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreOnlineEvaluationConfig to import
    * @param importFromId The id of the existing BedrockagentcoreOnlineEvaluationConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreOnlineEvaluationConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_online_evaluation_config awscc_bedrockagentcore_online_evaluation_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreOnlineEvaluationConfigConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreOnlineEvaluationConfigConfig);
    private _clusteringConfig;
    get clusteringConfig(): BedrockagentcoreOnlineEvaluationConfigClusteringConfigOutputReference;
    putClusteringConfig(value: BedrockagentcoreOnlineEvaluationConfigClusteringConfig): void;
    resetClusteringConfig(): void;
    get clusteringConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigClusteringConfig | undefined;
    get createdAt(): string;
    private _dataSourceConfig;
    get dataSourceConfig(): BedrockagentcoreOnlineEvaluationConfigDataSourceConfigOutputReference;
    putDataSourceConfig(value: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig): void;
    get dataSourceConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _evaluationExecutionRoleArn?;
    get evaluationExecutionRoleArn(): string;
    set evaluationExecutionRoleArn(value: string);
    get evaluationExecutionRoleArnInput(): string | undefined;
    private _evaluators;
    get evaluators(): BedrockagentcoreOnlineEvaluationConfigEvaluatorsList;
    putEvaluators(value: BedrockagentcoreOnlineEvaluationConfigEvaluators[] | cdktn.IResolvable): void;
    resetEvaluators(): void;
    get evaluatorsInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigEvaluators[] | undefined;
    private _executionStatus?;
    get executionStatus(): string;
    set executionStatus(value: string);
    resetExecutionStatus(): void;
    get executionStatusInput(): string | undefined;
    get id(): string;
    private _insights;
    get insights(): BedrockagentcoreOnlineEvaluationConfigInsightsList;
    putInsights(value: BedrockagentcoreOnlineEvaluationConfigInsights[] | cdktn.IResolvable): void;
    resetInsights(): void;
    get insightsInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigInsights[] | undefined;
    get onlineEvaluationConfigArn(): string;
    get onlineEvaluationConfigId(): string;
    private _onlineEvaluationConfigName?;
    get onlineEvaluationConfigName(): string;
    set onlineEvaluationConfigName(value: string);
    get onlineEvaluationConfigNameInput(): string | undefined;
    private _outputConfig;
    get outputConfig(): BedrockagentcoreOnlineEvaluationConfigOutputConfigOutputReference;
    putOutputConfig(value: BedrockagentcoreOnlineEvaluationConfigOutputConfig): void;
    resetOutputConfig(): void;
    get outputConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigOutputConfig | undefined;
    private _rule;
    get rule(): BedrockagentcoreOnlineEvaluationConfigRuleOutputReference;
    putRule(value: BedrockagentcoreOnlineEvaluationConfigRule): void;
    get ruleInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRule | undefined;
    get status(): string;
    private _tags;
    get tags(): BedrockagentcoreOnlineEvaluationConfigTagsList;
    putTags(value: BedrockagentcoreOnlineEvaluationConfigTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
