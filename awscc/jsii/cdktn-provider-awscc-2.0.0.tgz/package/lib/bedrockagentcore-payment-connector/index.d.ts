/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcorePaymentConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the payment connector
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#connector_name BedrockagentcorePaymentConnector#connector_name}
    */
    readonly connectorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#connector_type BedrockagentcorePaymentConnector#connector_type}
    */
    readonly connectorType: string;
    /**
    * The credential provider configurations for the connector. Required when ProvisionMode is MANUAL or not specified. Empty for QUICK_CREATE until provisioning completes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#credential_provider_configurations BedrockagentcorePaymentConnector#credential_provider_configurations}
    */
    readonly credentialProviderConfigurations?: BedrockagentcorePaymentConnectorCredentialProviderConfigurations[] | cdktn.IResolvable;
    /**
    * A description of the payment connector
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#description BedrockagentcorePaymentConnector#description}
    */
    readonly description?: string;
    /**
    * The identifier of the parent payment manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#payment_manager_id BedrockagentcorePaymentConnector#payment_manager_id}
    */
    readonly paymentManagerId: string;
    /**
    * The provision mode for creating the connector. MANUAL requires CredentialProviderConfigurations; QUICK_CREATE orchestrates OAuth consent and credential provisioning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#provision_mode BedrockagentcorePaymentConnector#provision_mode}
    */
    readonly provisionMode?: string;
}
export interface BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdp {
    /**
    * The ARN of the payment credential provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#credential_provider_arn BedrockagentcorePaymentConnector#credential_provider_arn}
    */
    readonly credentialProviderArn?: string;
}
export declare function bedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdpToTerraform(struct?: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdp | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdpToHclTerraform(struct?: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdp | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdp | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdp | cdktn.IResolvable | undefined);
    private _credentialProviderArn?;
    get credentialProviderArn(): string;
    set credentialProviderArn(value: string);
    resetCredentialProviderArn(): void;
    get credentialProviderArnInput(): string | undefined;
}
export interface BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivy {
    /**
    * The ARN of the payment credential provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#credential_provider_arn BedrockagentcorePaymentConnector#credential_provider_arn}
    */
    readonly credentialProviderArn?: string;
}
export declare function bedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivyToTerraform(struct?: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivy | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivyToHclTerraform(struct?: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivy | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivy | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivy | cdktn.IResolvable | undefined);
    private _credentialProviderArn?;
    get credentialProviderArn(): string;
    set credentialProviderArn(value: string);
    resetCredentialProviderArn(): void;
    get credentialProviderArnInput(): string | undefined;
}
export interface BedrockagentcorePaymentConnectorCredentialProviderConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#coinbase_cdp BedrockagentcorePaymentConnector#coinbase_cdp}
    */
    readonly coinbaseCdp?: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#stripe_privy BedrockagentcorePaymentConnector#stripe_privy}
    */
    readonly stripePrivy?: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivy;
}
export declare function bedrockagentcorePaymentConnectorCredentialProviderConfigurationsToTerraform(struct?: BedrockagentcorePaymentConnectorCredentialProviderConfigurations | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentConnectorCredentialProviderConfigurationsToHclTerraform(struct?: BedrockagentcorePaymentConnectorCredentialProviderConfigurations | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentConnectorCredentialProviderConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcorePaymentConnectorCredentialProviderConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentConnectorCredentialProviderConfigurations | cdktn.IResolvable | undefined);
    private _coinbaseCdp;
    get coinbaseCdp(): BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdpOutputReference;
    putCoinbaseCdp(value: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdp): void;
    resetCoinbaseCdp(): void;
    get coinbaseCdpInput(): cdktn.IResolvable | BedrockagentcorePaymentConnectorCredentialProviderConfigurationsCoinbaseCdp | undefined;
    private _stripePrivy;
    get stripePrivy(): BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivyOutputReference;
    putStripePrivy(value: BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivy): void;
    resetStripePrivy(): void;
    get stripePrivyInput(): cdktn.IResolvable | BedrockagentcorePaymentConnectorCredentialProviderConfigurationsStripePrivy | undefined;
}
export declare class BedrockagentcorePaymentConnectorCredentialProviderConfigurationsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcorePaymentConnectorCredentialProviderConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcorePaymentConnectorCredentialProviderConfigurationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector awscc_bedrockagentcore_payment_connector}
*/
export declare class BedrockagentcorePaymentConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_payment_connector";
    /**
    * Generates CDKTN code for importing a BedrockagentcorePaymentConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcorePaymentConnector to import
    * @param importFromId The id of the existing BedrockagentcorePaymentConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcorePaymentConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_connector awscc_bedrockagentcore_payment_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcorePaymentConnectorConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcorePaymentConnectorConfig);
    get authorizationUrl(): string;
    get connectorCreatedAt(): string;
    get connectorLastUpdatedAt(): string;
    private _connectorName?;
    get connectorName(): string;
    set connectorName(value: string);
    get connectorNameInput(): string | undefined;
    get connectorStatus(): string;
    private _connectorType?;
    get connectorType(): string;
    set connectorType(value: string);
    get connectorTypeInput(): string | undefined;
    private _credentialProviderConfigurations;
    get credentialProviderConfigurations(): BedrockagentcorePaymentConnectorCredentialProviderConfigurationsList;
    putCredentialProviderConfigurations(value: BedrockagentcorePaymentConnectorCredentialProviderConfigurations[] | cdktn.IResolvable): void;
    resetCredentialProviderConfigurations(): void;
    get credentialProviderConfigurationsInput(): cdktn.IResolvable | BedrockagentcorePaymentConnectorCredentialProviderConfigurations[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get paymentConnectorArn(): string;
    get paymentConnectorId(): string;
    private _paymentManagerId?;
    get paymentManagerId(): string;
    set paymentManagerId(value: string);
    get paymentManagerIdInput(): string | undefined;
    private _provisionMode?;
    get provisionMode(): string;
    set provisionMode(value: string);
    resetProvisionMode(): void;
    get provisionModeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
