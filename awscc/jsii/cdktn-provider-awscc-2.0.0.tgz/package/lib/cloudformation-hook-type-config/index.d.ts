/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationHookTypeConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The configuration data for the extension, in this account and region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_type_config#configuration CloudformationHookTypeConfig#configuration}
    */
    readonly configuration?: string;
    /**
    * An alias by which to refer to this extension configuration data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_type_config#configuration_alias CloudformationHookTypeConfig#configuration_alias}
    */
    readonly configurationAlias?: string;
    /**
    * The Amazon Resource Name (ARN) of the type without version number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_type_config#type_arn CloudformationHookTypeConfig#type_arn}
    */
    readonly typeArn?: string;
    /**
    * The name of the type being registered.
    *
    * We recommend that type names adhere to the following pattern: company_or_organization::service::type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_type_config#type_name CloudformationHookTypeConfig#type_name}
    */
    readonly typeName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_type_config awscc_cloudformation_hook_type_config}
*/
export declare class CloudformationHookTypeConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_hook_type_config";
    /**
    * Generates CDKTN code for importing a CloudformationHookTypeConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationHookTypeConfig to import
    * @param importFromId The id of the existing CloudformationHookTypeConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_type_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationHookTypeConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudformation_hook_type_config awscc_cloudformation_hook_type_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationHookTypeConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudformationHookTypeConfigConfig);
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
    private _configurationAlias?;
    get configurationAlias(): string;
    set configurationAlias(value: string);
    resetConfigurationAlias(): void;
    get configurationAliasInput(): string | undefined;
    get configurationArn(): string;
    get id(): string;
    private _typeArn?;
    get typeArn(): string;
    set typeArn(value: string);
    resetTypeArn(): void;
    get typeArnInput(): string | undefined;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    resetTypeName(): void;
    get typeNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
