/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupBackupPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#backup_plan BackupBackupPlan#backup_plan}
    */
    readonly backupPlan: BackupBackupPlanBackupPlan;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#backup_plan_tags BackupBackupPlan#backup_plan_tags}
    */
    readonly backupPlanTags?: {
        [key: string]: string;
    };
}
export interface BackupBackupPlanBackupPlanAdvancedBackupSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#backup_options BackupBackupPlan#backup_options}
    */
    readonly backupOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#resource_type BackupBackupPlan#resource_type}
    */
    readonly resourceType?: string;
}
export declare function backupBackupPlanBackupPlanAdvancedBackupSettingsToTerraform(struct?: BackupBackupPlanBackupPlanAdvancedBackupSettings | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanAdvancedBackupSettingsToHclTerraform(struct?: BackupBackupPlanBackupPlanAdvancedBackupSettings | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanAdvancedBackupSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupPlanBackupPlanAdvancedBackupSettings | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlanAdvancedBackupSettings | cdktn.IResolvable | undefined);
    private _backupOptions?;
    get backupOptions(): string;
    set backupOptions(value: string);
    resetBackupOptions(): void;
    get backupOptionsInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
}
export declare class BackupBackupPlanBackupPlanAdvancedBackupSettingsList extends cdktn.ComplexList {
    internalValue?: BackupBackupPlanBackupPlanAdvancedBackupSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupPlanBackupPlanAdvancedBackupSettingsOutputReference;
}
export interface BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#delete_after_days BackupBackupPlan#delete_after_days}
    */
    readonly deleteAfterDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#move_to_cold_storage_after_days BackupBackupPlan#move_to_cold_storage_after_days}
    */
    readonly moveToColdStorageAfterDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#opt_in_to_archive_for_supported_resources BackupBackupPlan#opt_in_to_archive_for_supported_resources}
    */
    readonly optInToArchiveForSupportedResources?: boolean | cdktn.IResolvable;
}
export declare function backupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycleToTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycle | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycleToHclTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycle | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycle | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycle | cdktn.IResolvable | undefined);
    private _deleteAfterDays?;
    get deleteAfterDays(): number;
    set deleteAfterDays(value: number);
    resetDeleteAfterDays(): void;
    get deleteAfterDaysInput(): number | undefined;
    private _moveToColdStorageAfterDays?;
    get moveToColdStorageAfterDays(): number;
    set moveToColdStorageAfterDays(value: number);
    resetMoveToColdStorageAfterDays(): void;
    get moveToColdStorageAfterDaysInput(): number | undefined;
    private _optInToArchiveForSupportedResources?;
    get optInToArchiveForSupportedResources(): boolean | cdktn.IResolvable;
    set optInToArchiveForSupportedResources(value: boolean | cdktn.IResolvable);
    resetOptInToArchiveForSupportedResources(): void;
    get optInToArchiveForSupportedResourcesInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupBackupPlanBackupPlanBackupPlanRuleCopyActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#destination_backup_vault_arn BackupBackupPlan#destination_backup_vault_arn}
    */
    readonly destinationBackupVaultArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#lifecycle BackupBackupPlan#lifecycle}
    */
    readonly lifecycle?: BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycle;
}
export declare function backupBackupPlanBackupPlanBackupPlanRuleCopyActionsToTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleCopyActions | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanBackupPlanRuleCopyActionsToHclTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleCopyActions | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupPlanBackupPlanBackupPlanRuleCopyActions | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlanBackupPlanRuleCopyActions | cdktn.IResolvable | undefined);
    private _destinationBackupVaultArn?;
    get destinationBackupVaultArn(): string;
    set destinationBackupVaultArn(value: string);
    resetDestinationBackupVaultArn(): void;
    get destinationBackupVaultArnInput(): string | undefined;
    private _lifecycle;
    get lifecycle(): BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycleOutputReference;
    putLifecycle(value: BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycle): void;
    resetLifecycle(): void;
    get lifecycleInput(): cdktn.IResolvable | BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsLifecycle | undefined;
}
export declare class BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsList extends cdktn.ComplexList {
    internalValue?: BackupBackupPlanBackupPlanBackupPlanRuleCopyActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsOutputReference;
}
export interface BackupBackupPlanBackupPlanBackupPlanRuleIndexActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#resource_types BackupBackupPlan#resource_types}
    */
    readonly resourceTypes?: string[];
}
export declare function backupBackupPlanBackupPlanBackupPlanRuleIndexActionsToTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleIndexActions | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanBackupPlanRuleIndexActionsToHclTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleIndexActions | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanBackupPlanRuleIndexActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupPlanBackupPlanBackupPlanRuleIndexActions | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlanBackupPlanRuleIndexActions | cdktn.IResolvable | undefined);
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
}
export declare class BackupBackupPlanBackupPlanBackupPlanRuleIndexActionsList extends cdktn.ComplexList {
    internalValue?: BackupBackupPlanBackupPlanBackupPlanRuleIndexActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupPlanBackupPlanBackupPlanRuleIndexActionsOutputReference;
}
export interface BackupBackupPlanBackupPlanBackupPlanRuleLifecycle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#delete_after_days BackupBackupPlan#delete_after_days}
    */
    readonly deleteAfterDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#move_to_cold_storage_after_days BackupBackupPlan#move_to_cold_storage_after_days}
    */
    readonly moveToColdStorageAfterDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#opt_in_to_archive_for_supported_resources BackupBackupPlan#opt_in_to_archive_for_supported_resources}
    */
    readonly optInToArchiveForSupportedResources?: boolean | cdktn.IResolvable;
}
export declare function backupBackupPlanBackupPlanBackupPlanRuleLifecycleToTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleLifecycle | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanBackupPlanRuleLifecycleToHclTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleLifecycle | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanBackupPlanRuleLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupBackupPlanBackupPlanBackupPlanRuleLifecycle | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlanBackupPlanRuleLifecycle | cdktn.IResolvable | undefined);
    private _deleteAfterDays?;
    get deleteAfterDays(): number;
    set deleteAfterDays(value: number);
    resetDeleteAfterDays(): void;
    get deleteAfterDaysInput(): number | undefined;
    private _moveToColdStorageAfterDays?;
    get moveToColdStorageAfterDays(): number;
    set moveToColdStorageAfterDays(value: number);
    resetMoveToColdStorageAfterDays(): void;
    get moveToColdStorageAfterDaysInput(): number | undefined;
    private _optInToArchiveForSupportedResources?;
    get optInToArchiveForSupportedResources(): boolean | cdktn.IResolvable;
    set optInToArchiveForSupportedResources(value: boolean | cdktn.IResolvable);
    resetOptInToArchiveForSupportedResources(): void;
    get optInToArchiveForSupportedResourcesInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupBackupPlanBackupPlanBackupPlanRuleScanActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#malware_scanner BackupBackupPlan#malware_scanner}
    */
    readonly malwareScanner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#scan_mode BackupBackupPlan#scan_mode}
    */
    readonly scanMode?: string;
}
export declare function backupBackupPlanBackupPlanBackupPlanRuleScanActionsToTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleScanActions | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanBackupPlanRuleScanActionsToHclTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRuleScanActions | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanBackupPlanRuleScanActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupPlanBackupPlanBackupPlanRuleScanActions | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlanBackupPlanRuleScanActions | cdktn.IResolvable | undefined);
    private _malwareScanner?;
    get malwareScanner(): string;
    set malwareScanner(value: string);
    resetMalwareScanner(): void;
    get malwareScannerInput(): string | undefined;
    private _scanMode?;
    get scanMode(): string;
    set scanMode(value: string);
    resetScanMode(): void;
    get scanModeInput(): string | undefined;
}
export declare class BackupBackupPlanBackupPlanBackupPlanRuleScanActionsList extends cdktn.ComplexList {
    internalValue?: BackupBackupPlanBackupPlanBackupPlanRuleScanActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupPlanBackupPlanBackupPlanRuleScanActionsOutputReference;
}
export interface BackupBackupPlanBackupPlanBackupPlanRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#completion_window_minutes BackupBackupPlan#completion_window_minutes}
    */
    readonly completionWindowMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#copy_actions BackupBackupPlan#copy_actions}
    */
    readonly copyActions?: BackupBackupPlanBackupPlanBackupPlanRuleCopyActions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#enable_continuous_backup BackupBackupPlan#enable_continuous_backup}
    */
    readonly enableContinuousBackup?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#index_actions BackupBackupPlan#index_actions}
    */
    readonly indexActions?: BackupBackupPlanBackupPlanBackupPlanRuleIndexActions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#lifecycle BackupBackupPlan#lifecycle}
    */
    readonly lifecycle?: BackupBackupPlanBackupPlanBackupPlanRuleLifecycle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#recovery_point_tags BackupBackupPlan#recovery_point_tags}
    */
    readonly recoveryPointTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#rule_name BackupBackupPlan#rule_name}
    */
    readonly ruleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#scan_actions BackupBackupPlan#scan_actions}
    */
    readonly scanActions?: BackupBackupPlanBackupPlanBackupPlanRuleScanActions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#schedule_expression BackupBackupPlan#schedule_expression}
    */
    readonly scheduleExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#schedule_expression_timezone BackupBackupPlan#schedule_expression_timezone}
    */
    readonly scheduleExpressionTimezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#start_window_minutes BackupBackupPlan#start_window_minutes}
    */
    readonly startWindowMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#target_backup_vault BackupBackupPlan#target_backup_vault}
    */
    readonly targetBackupVault: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#target_logically_air_gapped_backup_vault_arn BackupBackupPlan#target_logically_air_gapped_backup_vault_arn}
    */
    readonly targetLogicallyAirGappedBackupVaultArn?: string;
}
export declare function backupBackupPlanBackupPlanBackupPlanRuleToTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRule | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanBackupPlanRuleToHclTerraform(struct?: BackupBackupPlanBackupPlanBackupPlanRule | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanBackupPlanRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupPlanBackupPlanBackupPlanRule | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlanBackupPlanRule | cdktn.IResolvable | undefined);
    private _completionWindowMinutes?;
    get completionWindowMinutes(): number;
    set completionWindowMinutes(value: number);
    resetCompletionWindowMinutes(): void;
    get completionWindowMinutesInput(): number | undefined;
    private _copyActions;
    get copyActions(): BackupBackupPlanBackupPlanBackupPlanRuleCopyActionsList;
    putCopyActions(value: BackupBackupPlanBackupPlanBackupPlanRuleCopyActions[] | cdktn.IResolvable): void;
    resetCopyActions(): void;
    get copyActionsInput(): cdktn.IResolvable | BackupBackupPlanBackupPlanBackupPlanRuleCopyActions[] | undefined;
    private _enableContinuousBackup?;
    get enableContinuousBackup(): boolean | cdktn.IResolvable;
    set enableContinuousBackup(value: boolean | cdktn.IResolvable);
    resetEnableContinuousBackup(): void;
    get enableContinuousBackupInput(): boolean | cdktn.IResolvable | undefined;
    private _indexActions;
    get indexActions(): BackupBackupPlanBackupPlanBackupPlanRuleIndexActionsList;
    putIndexActions(value: BackupBackupPlanBackupPlanBackupPlanRuleIndexActions[] | cdktn.IResolvable): void;
    resetIndexActions(): void;
    get indexActionsInput(): cdktn.IResolvable | BackupBackupPlanBackupPlanBackupPlanRuleIndexActions[] | undefined;
    private _lifecycle;
    get lifecycle(): BackupBackupPlanBackupPlanBackupPlanRuleLifecycleOutputReference;
    putLifecycle(value: BackupBackupPlanBackupPlanBackupPlanRuleLifecycle): void;
    resetLifecycle(): void;
    get lifecycleInput(): cdktn.IResolvable | BackupBackupPlanBackupPlanBackupPlanRuleLifecycle | undefined;
    private _recoveryPointTags?;
    get recoveryPointTags(): {
        [key: string]: string;
    };
    set recoveryPointTags(value: {
        [key: string]: string;
    });
    resetRecoveryPointTags(): void;
    get recoveryPointTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _scanActions;
    get scanActions(): BackupBackupPlanBackupPlanBackupPlanRuleScanActionsList;
    putScanActions(value: BackupBackupPlanBackupPlanBackupPlanRuleScanActions[] | cdktn.IResolvable): void;
    resetScanActions(): void;
    get scanActionsInput(): cdktn.IResolvable | BackupBackupPlanBackupPlanBackupPlanRuleScanActions[] | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    resetScheduleExpression(): void;
    get scheduleExpressionInput(): string | undefined;
    private _scheduleExpressionTimezone?;
    get scheduleExpressionTimezone(): string;
    set scheduleExpressionTimezone(value: string);
    resetScheduleExpressionTimezone(): void;
    get scheduleExpressionTimezoneInput(): string | undefined;
    private _startWindowMinutes?;
    get startWindowMinutes(): number;
    set startWindowMinutes(value: number);
    resetStartWindowMinutes(): void;
    get startWindowMinutesInput(): number | undefined;
    private _targetBackupVault?;
    get targetBackupVault(): string;
    set targetBackupVault(value: string);
    get targetBackupVaultInput(): string | undefined;
    private _targetLogicallyAirGappedBackupVaultArn?;
    get targetLogicallyAirGappedBackupVaultArn(): string;
    set targetLogicallyAirGappedBackupVaultArn(value: string);
    resetTargetLogicallyAirGappedBackupVaultArn(): void;
    get targetLogicallyAirGappedBackupVaultArnInput(): string | undefined;
}
export declare class BackupBackupPlanBackupPlanBackupPlanRuleList extends cdktn.ComplexList {
    internalValue?: BackupBackupPlanBackupPlanBackupPlanRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupPlanBackupPlanBackupPlanRuleOutputReference;
}
export interface BackupBackupPlanBackupPlanScanSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#malware_scanner BackupBackupPlan#malware_scanner}
    */
    readonly malwareScanner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#resource_types BackupBackupPlan#resource_types}
    */
    readonly resourceTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#scanner_role_arn BackupBackupPlan#scanner_role_arn}
    */
    readonly scannerRoleArn?: string;
}
export declare function backupBackupPlanBackupPlanScanSettingsToTerraform(struct?: BackupBackupPlanBackupPlanScanSettings | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanScanSettingsToHclTerraform(struct?: BackupBackupPlanBackupPlanScanSettings | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanScanSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupPlanBackupPlanScanSettings | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlanScanSettings | cdktn.IResolvable | undefined);
    private _malwareScanner?;
    get malwareScanner(): string;
    set malwareScanner(value: string);
    resetMalwareScanner(): void;
    get malwareScannerInput(): string | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
    private _scannerRoleArn?;
    get scannerRoleArn(): string;
    set scannerRoleArn(value: string);
    resetScannerRoleArn(): void;
    get scannerRoleArnInput(): string | undefined;
}
export declare class BackupBackupPlanBackupPlanScanSettingsList extends cdktn.ComplexList {
    internalValue?: BackupBackupPlanBackupPlanScanSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupPlanBackupPlanScanSettingsOutputReference;
}
export interface BackupBackupPlanBackupPlan {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#advanced_backup_settings BackupBackupPlan#advanced_backup_settings}
    */
    readonly advancedBackupSettings?: BackupBackupPlanBackupPlanAdvancedBackupSettings[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#backup_plan_name BackupBackupPlan#backup_plan_name}
    */
    readonly backupPlanName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#backup_plan_rule BackupBackupPlan#backup_plan_rule}
    */
    readonly backupPlanRule: BackupBackupPlanBackupPlanBackupPlanRule[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#scan_settings BackupBackupPlan#scan_settings}
    */
    readonly scanSettings?: BackupBackupPlanBackupPlanScanSettings[] | cdktn.IResolvable;
}
export declare function backupBackupPlanBackupPlanToTerraform(struct?: BackupBackupPlanBackupPlan | cdktn.IResolvable): any;
export declare function backupBackupPlanBackupPlanToHclTerraform(struct?: BackupBackupPlanBackupPlan | cdktn.IResolvable): any;
export declare class BackupBackupPlanBackupPlanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupBackupPlanBackupPlan | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupPlanBackupPlan | cdktn.IResolvable | undefined);
    private _advancedBackupSettings;
    get advancedBackupSettings(): BackupBackupPlanBackupPlanAdvancedBackupSettingsList;
    putAdvancedBackupSettings(value: BackupBackupPlanBackupPlanAdvancedBackupSettings[] | cdktn.IResolvable): void;
    resetAdvancedBackupSettings(): void;
    get advancedBackupSettingsInput(): cdktn.IResolvable | BackupBackupPlanBackupPlanAdvancedBackupSettings[] | undefined;
    private _backupPlanName?;
    get backupPlanName(): string;
    set backupPlanName(value: string);
    get backupPlanNameInput(): string | undefined;
    private _backupPlanRule;
    get backupPlanRule(): BackupBackupPlanBackupPlanBackupPlanRuleList;
    putBackupPlanRule(value: BackupBackupPlanBackupPlanBackupPlanRule[] | cdktn.IResolvable): void;
    get backupPlanRuleInput(): cdktn.IResolvable | BackupBackupPlanBackupPlanBackupPlanRule[] | undefined;
    private _scanSettings;
    get scanSettings(): BackupBackupPlanBackupPlanScanSettingsList;
    putScanSettings(value: BackupBackupPlanBackupPlanScanSettings[] | cdktn.IResolvable): void;
    resetScanSettings(): void;
    get scanSettingsInput(): cdktn.IResolvable | BackupBackupPlanBackupPlanScanSettings[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan awscc_backup_backup_plan}
*/
export declare class BackupBackupPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_backup_plan";
    /**
    * Generates CDKTN code for importing a BackupBackupPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupBackupPlan to import
    * @param importFromId The id of the existing BackupBackupPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupBackupPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/backup_backup_plan awscc_backup_backup_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupBackupPlanConfig
    */
    constructor(scope: Construct, id: string, config: BackupBackupPlanConfig);
    private _backupPlan;
    get backupPlan(): BackupBackupPlanBackupPlanOutputReference;
    putBackupPlan(value: BackupBackupPlanBackupPlan): void;
    get backupPlanInput(): cdktn.IResolvable | BackupBackupPlanBackupPlan | undefined;
    get backupPlanArn(): string;
    get backupPlanId(): string;
    private _backupPlanTags?;
    get backupPlanTags(): {
        [key: string]: string;
    };
    set backupPlanTags(value: {
        [key: string]: string;
    });
    resetBackupPlanTags(): void;
    get backupPlanTagsInput(): {
        [key: string]: string;
    } | undefined;
    get id(): string;
    get versionId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
