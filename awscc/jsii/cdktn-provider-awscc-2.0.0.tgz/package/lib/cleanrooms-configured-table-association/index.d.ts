/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsConfiguredTableAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#configured_table_association_analysis_rules CleanroomsConfiguredTableAssociation#configured_table_association_analysis_rules}
    */
    readonly configuredTableAssociationAnalysisRules?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#configured_table_identifier CleanroomsConfiguredTableAssociation#configured_table_identifier}
    */
    readonly configuredTableIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#description CleanroomsConfiguredTableAssociation#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#membership_identifier CleanroomsConfiguredTableAssociation#membership_identifier}
    */
    readonly membershipIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#name CleanroomsConfiguredTableAssociation#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#role_arn CleanroomsConfiguredTableAssociation#role_arn}
    */
    readonly roleArn: string;
    /**
    * An arbitrary set of tags (key-value pairs) for this cleanrooms collaboration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#tags CleanroomsConfiguredTableAssociation#tags}
    */
    readonly tags?: CleanroomsConfiguredTableAssociationTags[] | cdktn.IResolvable;
}
export interface CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Aggregation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#allowed_additional_analyses CleanroomsConfiguredTableAssociation#allowed_additional_analyses}
    */
    readonly allowedAdditionalAnalyses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#allowed_result_receivers CleanroomsConfiguredTableAssociation#allowed_result_receivers}
    */
    readonly allowedResultReceivers?: string[];
}
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1AggregationToTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Aggregation | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1AggregationToHclTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Aggregation | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1AggregationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Aggregation | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Aggregation | cdktn.IResolvable | undefined);
    private _allowedAdditionalAnalyses?;
    get allowedAdditionalAnalyses(): string[];
    set allowedAdditionalAnalyses(value: string[]);
    resetAllowedAdditionalAnalyses(): void;
    get allowedAdditionalAnalysesInput(): string[] | undefined;
    private _allowedResultReceivers?;
    get allowedResultReceivers(): string[];
    set allowedResultReceivers(value: string[]);
    resetAllowedResultReceivers(): void;
    get allowedResultReceiversInput(): string[] | undefined;
}
export interface CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Custom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#allowed_additional_analyses CleanroomsConfiguredTableAssociation#allowed_additional_analyses}
    */
    readonly allowedAdditionalAnalyses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#allowed_result_receivers CleanroomsConfiguredTableAssociation#allowed_result_receivers}
    */
    readonly allowedResultReceivers?: string[];
}
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1CustomToTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Custom | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1CustomToHclTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Custom | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1CustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Custom | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Custom | cdktn.IResolvable | undefined);
    private _allowedAdditionalAnalyses?;
    get allowedAdditionalAnalyses(): string[];
    set allowedAdditionalAnalyses(value: string[]);
    resetAllowedAdditionalAnalyses(): void;
    get allowedAdditionalAnalysesInput(): string[] | undefined;
    private _allowedResultReceivers?;
    get allowedResultReceivers(): string[];
    set allowedResultReceivers(value: string[]);
    resetAllowedResultReceivers(): void;
    get allowedResultReceiversInput(): string[] | undefined;
}
export interface CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#allowed_additional_analyses CleanroomsConfiguredTableAssociation#allowed_additional_analyses}
    */
    readonly allowedAdditionalAnalyses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#allowed_result_receivers CleanroomsConfiguredTableAssociation#allowed_result_receivers}
    */
    readonly allowedResultReceivers?: string[];
}
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStructToTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStruct | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStructToHclTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStruct | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStruct | cdktn.IResolvable | undefined);
    private _allowedAdditionalAnalyses?;
    get allowedAdditionalAnalyses(): string[];
    set allowedAdditionalAnalyses(value: string[]);
    resetAllowedAdditionalAnalyses(): void;
    get allowedAdditionalAnalysesInput(): string[] | undefined;
    private _allowedResultReceivers?;
    get allowedResultReceivers(): string[];
    set allowedResultReceivers(value: string[]);
    resetAllowedResultReceivers(): void;
    get allowedResultReceiversInput(): string[] | undefined;
}
export interface CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#aggregation CleanroomsConfiguredTableAssociation#aggregation}
    */
    readonly aggregation?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Aggregation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#custom CleanroomsConfiguredTableAssociation#custom}
    */
    readonly custom?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Custom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#list CleanroomsConfiguredTableAssociation#list}
    */
    readonly list?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStruct;
}
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ToTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1 | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ToHclTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1 | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1 | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1 | cdktn.IResolvable | undefined);
    private _aggregation;
    get aggregation(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1AggregationOutputReference;
    putAggregation(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Aggregation): void;
    resetAggregation(): void;
    get aggregationInput(): cdktn.IResolvable | CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Aggregation | undefined;
    private _custom;
    get custom(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1CustomOutputReference;
    putCustom(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Custom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1Custom | undefined;
    private _list;
    get list(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStructOutputReference;
    putList(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStruct): void;
    resetList(): void;
    get listInput(): cdktn.IResolvable | CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1ListStruct | undefined;
}
export interface CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#v1 CleanroomsConfiguredTableAssociation#v1}
    */
    readonly v1?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1;
}
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyToTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicy | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyToHclTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicy | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicy | cdktn.IResolvable | undefined);
    private _v1;
    get v1(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1OutputReference;
    putV1(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1): void;
    resetV1(): void;
    get v1Input(): cdktn.IResolvable | CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyV1 | undefined;
}
export interface CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#policy CleanroomsConfiguredTableAssociation#policy}
    */
    readonly policy?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#type CleanroomsConfiguredTableAssociation#type}
    */
    readonly type?: string;
}
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesToTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesToHclTerraform(struct?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules | cdktn.IResolvable | undefined);
    private _policy;
    get policy(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicyOutputReference;
    putPolicy(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicy): void;
    resetPolicy(): void;
    get policyInput(): cdktn.IResolvable | CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesPolicy | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesOutputReference;
}
export interface CleanroomsConfiguredTableAssociationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#key CleanroomsConfiguredTableAssociation#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#value CleanroomsConfiguredTableAssociation#value}
    */
    readonly value?: string;
}
export declare function cleanroomsConfiguredTableAssociationTagsToTerraform(struct?: CleanroomsConfiguredTableAssociationTags | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAssociationTagsToHclTerraform(struct?: CleanroomsConfiguredTableAssociationTags | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAssociationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableAssociationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAssociationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableAssociationTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableAssociationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableAssociationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association awscc_cleanrooms_configured_table_association}
*/
export declare class CleanroomsConfiguredTableAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanrooms_configured_table_association";
    /**
    * Generates CDKTN code for importing a CleanroomsConfiguredTableAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsConfiguredTableAssociation to import
    * @param importFromId The id of the existing CleanroomsConfiguredTableAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsConfiguredTableAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_configured_table_association awscc_cleanrooms_configured_table_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsConfiguredTableAssociationConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsConfiguredTableAssociationConfig);
    get arn(): string;
    private _configuredTableAssociationAnalysisRules;
    get configuredTableAssociationAnalysisRules(): CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRulesList;
    putConfiguredTableAssociationAnalysisRules(value: CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules[] | cdktn.IResolvable): void;
    resetConfiguredTableAssociationAnalysisRules(): void;
    get configuredTableAssociationAnalysisRulesInput(): cdktn.IResolvable | CleanroomsConfiguredTableAssociationConfiguredTableAssociationAnalysisRules[] | undefined;
    get configuredTableAssociationIdentifier(): string;
    private _configuredTableIdentifier?;
    get configuredTableIdentifier(): string;
    set configuredTableIdentifier(value: string);
    get configuredTableIdentifierInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _membershipIdentifier?;
    get membershipIdentifier(): string;
    set membershipIdentifier(value: string);
    get membershipIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags;
    get tags(): CleanroomsConfiguredTableAssociationTagsList;
    putTags(value: CleanroomsConfiguredTableAssociationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsConfiguredTableAssociationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
