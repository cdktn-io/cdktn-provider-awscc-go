/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectSecurityProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the hierarchy group that a security profile uses to restrict access to resources in Amazon Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#allowed_access_control_hierarchy_group_id ConnectSecurityProfile#allowed_access_control_hierarchy_group_id}
    */
    readonly allowedAccessControlHierarchyGroupId?: string;
    /**
    * The list of tags that a security profile uses to restrict access to resources in Amazon Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#allowed_access_control_tags ConnectSecurityProfile#allowed_access_control_tags}
    */
    readonly allowedAccessControlTags?: ConnectSecurityProfileAllowedAccessControlTags[] | cdktn.IResolvable;
    /**
    * The list of flow-module resources to be linked to a security profile in Amazon Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#allowed_flow_modules ConnectSecurityProfile#allowed_flow_modules}
    */
    readonly allowedFlowModules?: ConnectSecurityProfileAllowedFlowModules[] | cdktn.IResolvable;
    /**
    * A list of third-party applications that the security profile will give access to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#applications ConnectSecurityProfile#applications}
    */
    readonly applications?: ConnectSecurityProfileApplications[] | cdktn.IResolvable;
    /**
    * The description of the security profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#description ConnectSecurityProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#granular_access_control_configuration ConnectSecurityProfile#granular_access_control_configuration}
    */
    readonly granularAccessControlConfiguration?: ConnectSecurityProfileGranularAccessControlConfiguration;
    /**
    * The list of resources that a security profile applies hierarchy restrictions to in Amazon Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#hierarchy_restricted_resources ConnectSecurityProfile#hierarchy_restricted_resources}
    */
    readonly hierarchyRestrictedResources?: string[];
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#instance_arn ConnectSecurityProfile#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Permissions assigned to the security profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#permissions ConnectSecurityProfile#permissions}
    */
    readonly permissions?: string[];
    /**
    * The name of the security profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#security_profile_name ConnectSecurityProfile#security_profile_name}
    */
    readonly securityProfileName: string;
    /**
    * The list of resources that a security profile applies tag restrictions to in Amazon Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#tag_restricted_resources ConnectSecurityProfile#tag_restricted_resources}
    */
    readonly tagRestrictedResources?: string[];
    /**
    * The tags used to organize, track, or control access for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#tags ConnectSecurityProfile#tags}
    */
    readonly tags?: ConnectSecurityProfileTags[] | cdktn.IResolvable;
}
export interface ConnectSecurityProfileAllowedAccessControlTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#key ConnectSecurityProfile#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#value ConnectSecurityProfile#value}
    */
    readonly value?: string;
}
export declare function connectSecurityProfileAllowedAccessControlTagsToTerraform(struct?: ConnectSecurityProfileAllowedAccessControlTags | cdktn.IResolvable): any;
export declare function connectSecurityProfileAllowedAccessControlTagsToHclTerraform(struct?: ConnectSecurityProfileAllowedAccessControlTags | cdktn.IResolvable): any;
export declare class ConnectSecurityProfileAllowedAccessControlTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectSecurityProfileAllowedAccessControlTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectSecurityProfileAllowedAccessControlTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectSecurityProfileAllowedAccessControlTagsList extends cdktn.ComplexList {
    internalValue?: ConnectSecurityProfileAllowedAccessControlTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectSecurityProfileAllowedAccessControlTagsOutputReference;
}
export interface ConnectSecurityProfileAllowedFlowModules {
    /**
    * The identifier of the application that you want to give access to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#flow_module_id ConnectSecurityProfile#flow_module_id}
    */
    readonly flowModuleId?: string;
    /**
    * The type of the first-party application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#type ConnectSecurityProfile#type}
    */
    readonly type?: string;
}
export declare function connectSecurityProfileAllowedFlowModulesToTerraform(struct?: ConnectSecurityProfileAllowedFlowModules | cdktn.IResolvable): any;
export declare function connectSecurityProfileAllowedFlowModulesToHclTerraform(struct?: ConnectSecurityProfileAllowedFlowModules | cdktn.IResolvable): any;
export declare class ConnectSecurityProfileAllowedFlowModulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectSecurityProfileAllowedFlowModules | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectSecurityProfileAllowedFlowModules | cdktn.IResolvable | undefined);
    private _flowModuleId?;
    get flowModuleId(): string;
    set flowModuleId(value: string);
    resetFlowModuleId(): void;
    get flowModuleIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ConnectSecurityProfileAllowedFlowModulesList extends cdktn.ComplexList {
    internalValue?: ConnectSecurityProfileAllowedFlowModules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectSecurityProfileAllowedFlowModulesOutputReference;
}
export interface ConnectSecurityProfileApplications {
    /**
    * The permissions that the agent is granted on the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#application_permissions ConnectSecurityProfile#application_permissions}
    */
    readonly applicationPermissions?: string[];
    /**
    * Namespace of the application that you want to give access to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#namespace ConnectSecurityProfile#namespace}
    */
    readonly namespace?: string;
    /**
    * The type of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#type ConnectSecurityProfile#type}
    */
    readonly type?: string;
}
export declare function connectSecurityProfileApplicationsToTerraform(struct?: ConnectSecurityProfileApplications | cdktn.IResolvable): any;
export declare function connectSecurityProfileApplicationsToHclTerraform(struct?: ConnectSecurityProfileApplications | cdktn.IResolvable): any;
export declare class ConnectSecurityProfileApplicationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectSecurityProfileApplications | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectSecurityProfileApplications | cdktn.IResolvable | undefined);
    private _applicationPermissions?;
    get applicationPermissions(): string[];
    set applicationPermissions(value: string[]);
    resetApplicationPermissions(): void;
    get applicationPermissionsInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ConnectSecurityProfileApplicationsList extends cdktn.ComplexList {
    internalValue?: ConnectSecurityProfileApplications[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectSecurityProfileApplicationsOutputReference;
}
export interface ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues {
    /**
    * Specifies the type of access granted. Currently, only "ALLOW" is supported
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#access_type ConnectSecurityProfile#access_type}
    */
    readonly accessType?: string;
    /**
    * The name of the primary attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#attribute_name ConnectSecurityProfile#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * An array of allowed primary values for the specified primary attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#values ConnectSecurityProfile#values}
    */
    readonly values?: string[];
}
export declare function connectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValuesToTerraform(struct?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues | cdktn.IResolvable): any;
export declare function connectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValuesToHclTerraform(struct?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues | cdktn.IResolvable): any;
export declare class ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues | cdktn.IResolvable | undefined);
    private _accessType?;
    get accessType(): string;
    set accessType(value: string);
    resetAccessType(): void;
    get accessTypeInput(): string | undefined;
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValuesList extends cdktn.ComplexList {
    internalValue?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValuesOutputReference;
}
export interface ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfiguration {
    /**
    * An array of PrimaryAttributeValue objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#primary_attribute_values ConnectSecurityProfile#primary_attribute_values}
    */
    readonly primaryAttributeValues?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues[] | cdktn.IResolvable;
}
export declare function connectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationToTerraform(struct?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfiguration | cdktn.IResolvable): any;
export declare function connectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationToHclTerraform(struct?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfiguration | cdktn.IResolvable): any;
export declare class ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfiguration | cdktn.IResolvable | undefined);
    private _primaryAttributeValues;
    get primaryAttributeValues(): ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValuesList;
    putPrimaryAttributeValues(value: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues[] | cdktn.IResolvable): void;
    resetPrimaryAttributeValues(): void;
    get primaryAttributeValuesInput(): cdktn.IResolvable | ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationPrimaryAttributeValues[] | undefined;
}
export interface ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfiguration {
    /**
    * Contains the configuration for record-based access control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#primary_attribute_access_control_configuration ConnectSecurityProfile#primary_attribute_access_control_configuration}
    */
    readonly primaryAttributeAccessControlConfiguration?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfiguration;
}
export declare function connectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationToTerraform(struct?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfiguration | cdktn.IResolvable): any;
export declare function connectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationToHclTerraform(struct?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfiguration | cdktn.IResolvable): any;
export declare class ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfiguration | cdktn.IResolvable | undefined);
    private _primaryAttributeAccessControlConfiguration;
    get primaryAttributeAccessControlConfiguration(): ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfigurationOutputReference;
    putPrimaryAttributeAccessControlConfiguration(value: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfiguration): void;
    resetPrimaryAttributeAccessControlConfiguration(): void;
    get primaryAttributeAccessControlConfigurationInput(): cdktn.IResolvable | ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationPrimaryAttributeAccessControlConfiguration | undefined;
}
export interface ConnectSecurityProfileGranularAccessControlConfiguration {
    /**
    * Defines the access control configuration for data tables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#data_table_access_control_configuration ConnectSecurityProfile#data_table_access_control_configuration}
    */
    readonly dataTableAccessControlConfiguration?: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfiguration;
}
export declare function connectSecurityProfileGranularAccessControlConfigurationToTerraform(struct?: ConnectSecurityProfileGranularAccessControlConfiguration | cdktn.IResolvable): any;
export declare function connectSecurityProfileGranularAccessControlConfigurationToHclTerraform(struct?: ConnectSecurityProfileGranularAccessControlConfiguration | cdktn.IResolvable): any;
export declare class ConnectSecurityProfileGranularAccessControlConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectSecurityProfileGranularAccessControlConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectSecurityProfileGranularAccessControlConfiguration | cdktn.IResolvable | undefined);
    private _dataTableAccessControlConfiguration;
    get dataTableAccessControlConfiguration(): ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfigurationOutputReference;
    putDataTableAccessControlConfiguration(value: ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfiguration): void;
    resetDataTableAccessControlConfiguration(): void;
    get dataTableAccessControlConfigurationInput(): cdktn.IResolvable | ConnectSecurityProfileGranularAccessControlConfigurationDataTableAccessControlConfiguration | undefined;
}
export interface ConnectSecurityProfileTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#key ConnectSecurityProfile#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#value ConnectSecurityProfile#value}
    */
    readonly value?: string;
}
export declare function connectSecurityProfileTagsToTerraform(struct?: ConnectSecurityProfileTags | cdktn.IResolvable): any;
export declare function connectSecurityProfileTagsToHclTerraform(struct?: ConnectSecurityProfileTags | cdktn.IResolvable): any;
export declare class ConnectSecurityProfileTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectSecurityProfileTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectSecurityProfileTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectSecurityProfileTagsList extends cdktn.ComplexList {
    internalValue?: ConnectSecurityProfileTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectSecurityProfileTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile awscc_connect_security_profile}
*/
export declare class ConnectSecurityProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_security_profile";
    /**
    * Generates CDKTN code for importing a ConnectSecurityProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectSecurityProfile to import
    * @param importFromId The id of the existing ConnectSecurityProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectSecurityProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_security_profile awscc_connect_security_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectSecurityProfileConfig
    */
    constructor(scope: Construct, id: string, config: ConnectSecurityProfileConfig);
    private _allowedAccessControlHierarchyGroupId?;
    get allowedAccessControlHierarchyGroupId(): string;
    set allowedAccessControlHierarchyGroupId(value: string);
    resetAllowedAccessControlHierarchyGroupId(): void;
    get allowedAccessControlHierarchyGroupIdInput(): string | undefined;
    private _allowedAccessControlTags;
    get allowedAccessControlTags(): ConnectSecurityProfileAllowedAccessControlTagsList;
    putAllowedAccessControlTags(value: ConnectSecurityProfileAllowedAccessControlTags[] | cdktn.IResolvable): void;
    resetAllowedAccessControlTags(): void;
    get allowedAccessControlTagsInput(): cdktn.IResolvable | ConnectSecurityProfileAllowedAccessControlTags[] | undefined;
    private _allowedFlowModules;
    get allowedFlowModules(): ConnectSecurityProfileAllowedFlowModulesList;
    putAllowedFlowModules(value: ConnectSecurityProfileAllowedFlowModules[] | cdktn.IResolvable): void;
    resetAllowedFlowModules(): void;
    get allowedFlowModulesInput(): cdktn.IResolvable | ConnectSecurityProfileAllowedFlowModules[] | undefined;
    private _applications;
    get applications(): ConnectSecurityProfileApplicationsList;
    putApplications(value: ConnectSecurityProfileApplications[] | cdktn.IResolvable): void;
    resetApplications(): void;
    get applicationsInput(): cdktn.IResolvable | ConnectSecurityProfileApplications[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _granularAccessControlConfiguration;
    get granularAccessControlConfiguration(): ConnectSecurityProfileGranularAccessControlConfigurationOutputReference;
    putGranularAccessControlConfiguration(value: ConnectSecurityProfileGranularAccessControlConfiguration): void;
    resetGranularAccessControlConfiguration(): void;
    get granularAccessControlConfigurationInput(): cdktn.IResolvable | ConnectSecurityProfileGranularAccessControlConfiguration | undefined;
    private _hierarchyRestrictedResources?;
    get hierarchyRestrictedResources(): string[];
    set hierarchyRestrictedResources(value: string[]);
    resetHierarchyRestrictedResources(): void;
    get hierarchyRestrictedResourcesInput(): string[] | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get lastModifiedRegion(): string;
    get lastModifiedTime(): number;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    resetPermissions(): void;
    get permissionsInput(): string[] | undefined;
    get securityProfileArn(): string;
    private _securityProfileName?;
    get securityProfileName(): string;
    set securityProfileName(value: string);
    get securityProfileNameInput(): string | undefined;
    private _tagRestrictedResources?;
    get tagRestrictedResources(): string[];
    set tagRestrictedResources(value: string[]);
    resetTagRestrictedResources(): void;
    get tagRestrictedResourcesInput(): string[] | undefined;
    private _tags;
    get tags(): ConnectSecurityProfileTagsList;
    putTags(value: ConnectSecurityProfileTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectSecurityProfileTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
