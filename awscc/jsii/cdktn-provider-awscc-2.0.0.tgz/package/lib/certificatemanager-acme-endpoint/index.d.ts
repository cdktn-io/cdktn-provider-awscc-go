/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificatemanagerAcmeEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * The authorization behavior for the ACME endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#authorization_behavior CertificatemanagerAcmeEndpoint#authorization_behavior}
    */
    readonly authorizationBehavior: string;
    /**
    * The certificate authority configuration for the ACME endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#certificate_authority CertificatemanagerAcmeEndpoint#certificate_authority}
    */
    readonly certificateAuthority: CertificatemanagerAcmeEndpointCertificateAuthority;
    /**
    * Tags applied to certificates issued via this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#certificate_tags CertificatemanagerAcmeEndpoint#certificate_tags}
    */
    readonly certificateTags?: CertificatemanagerAcmeEndpointCertificateTags[] | cdktn.IResolvable;
    /**
    * Whether contact information is required for the ACME endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#contact CertificatemanagerAcmeEndpoint#contact}
    */
    readonly contact?: string;
    /**
    * Tags associated with the ACME endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#tags CertificatemanagerAcmeEndpoint#tags}
    */
    readonly tags?: CertificatemanagerAcmeEndpointTags[] | cdktn.IResolvable;
}
export interface CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthority {
    /**
    * The allowed key algorithms for certificates issued via this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#allowed_key_algorithms CertificatemanagerAcmeEndpoint#allowed_key_algorithms}
    */
    readonly allowedKeyAlgorithms?: string[];
}
export declare function certificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthorityToTerraform(struct?: CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthority | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthorityToHclTerraform(struct?: CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthority | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthority | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthority | cdktn.IResolvable | undefined);
    private _allowedKeyAlgorithms?;
    get allowedKeyAlgorithms(): string[];
    set allowedKeyAlgorithms(value: string[]);
    resetAllowedKeyAlgorithms(): void;
    get allowedKeyAlgorithmsInput(): string[] | undefined;
}
export interface CertificatemanagerAcmeEndpointCertificateAuthority {
    /**
    * Configuration for the public certificate authority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#public_certificate_authority CertificatemanagerAcmeEndpoint#public_certificate_authority}
    */
    readonly publicCertificateAuthority: CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthority;
}
export declare function certificatemanagerAcmeEndpointCertificateAuthorityToTerraform(struct?: CertificatemanagerAcmeEndpointCertificateAuthority | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeEndpointCertificateAuthorityToHclTerraform(struct?: CertificatemanagerAcmeEndpointCertificateAuthority | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeEndpointCertificateAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificatemanagerAcmeEndpointCertificateAuthority | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeEndpointCertificateAuthority | cdktn.IResolvable | undefined);
    private _publicCertificateAuthority;
    get publicCertificateAuthority(): CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthorityOutputReference;
    putPublicCertificateAuthority(value: CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthority): void;
    get publicCertificateAuthorityInput(): cdktn.IResolvable | CertificatemanagerAcmeEndpointCertificateAuthorityPublicCertificateAuthority | undefined;
}
export interface CertificatemanagerAcmeEndpointCertificateTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#key CertificatemanagerAcmeEndpoint#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#value CertificatemanagerAcmeEndpoint#value}
    */
    readonly value?: string;
}
export declare function certificatemanagerAcmeEndpointCertificateTagsToTerraform(struct?: CertificatemanagerAcmeEndpointCertificateTags | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeEndpointCertificateTagsToHclTerraform(struct?: CertificatemanagerAcmeEndpointCertificateTags | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeEndpointCertificateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificatemanagerAcmeEndpointCertificateTags | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeEndpointCertificateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CertificatemanagerAcmeEndpointCertificateTagsList extends cdktn.ComplexList {
    internalValue?: CertificatemanagerAcmeEndpointCertificateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificatemanagerAcmeEndpointCertificateTagsOutputReference;
}
export interface CertificatemanagerAcmeEndpointTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#key CertificatemanagerAcmeEndpoint#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#value CertificatemanagerAcmeEndpoint#value}
    */
    readonly value?: string;
}
export declare function certificatemanagerAcmeEndpointTagsToTerraform(struct?: CertificatemanagerAcmeEndpointTags | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeEndpointTagsToHclTerraform(struct?: CertificatemanagerAcmeEndpointTags | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeEndpointTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificatemanagerAcmeEndpointTags | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeEndpointTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CertificatemanagerAcmeEndpointTagsList extends cdktn.ComplexList {
    internalValue?: CertificatemanagerAcmeEndpointTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificatemanagerAcmeEndpointTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint awscc_certificatemanager_acme_endpoint}
*/
export declare class CertificatemanagerAcmeEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_certificatemanager_acme_endpoint";
    /**
    * Generates CDKTN code for importing a CertificatemanagerAcmeEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificatemanagerAcmeEndpoint to import
    * @param importFromId The id of the existing CertificatemanagerAcmeEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificatemanagerAcmeEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_endpoint awscc_certificatemanager_acme_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificatemanagerAcmeEndpointConfig
    */
    constructor(scope: Construct, id: string, config: CertificatemanagerAcmeEndpointConfig);
    get acmeEndpointArn(): string;
    private _authorizationBehavior?;
    get authorizationBehavior(): string;
    set authorizationBehavior(value: string);
    get authorizationBehaviorInput(): string | undefined;
    private _certificateAuthority;
    get certificateAuthority(): CertificatemanagerAcmeEndpointCertificateAuthorityOutputReference;
    putCertificateAuthority(value: CertificatemanagerAcmeEndpointCertificateAuthority): void;
    get certificateAuthorityInput(): cdktn.IResolvable | CertificatemanagerAcmeEndpointCertificateAuthority | undefined;
    private _certificateTags;
    get certificateTags(): CertificatemanagerAcmeEndpointCertificateTagsList;
    putCertificateTags(value: CertificatemanagerAcmeEndpointCertificateTags[] | cdktn.IResolvable): void;
    resetCertificateTags(): void;
    get certificateTagsInput(): cdktn.IResolvable | CertificatemanagerAcmeEndpointCertificateTags[] | undefined;
    private _contact?;
    get contact(): string;
    set contact(value: string);
    resetContact(): void;
    get contactInput(): string | undefined;
    get endpointUrl(): string;
    get id(): string;
    private _tags;
    get tags(): CertificatemanagerAcmeEndpointTagsList;
    putTags(value: CertificatemanagerAcmeEndpointTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CertificatemanagerAcmeEndpointTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
