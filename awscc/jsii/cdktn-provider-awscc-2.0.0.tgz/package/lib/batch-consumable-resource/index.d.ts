/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BatchConsumableResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of ConsumableResource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_consumable_resource#consumable_resource_name BatchConsumableResource#consumable_resource_name}
    */
    readonly consumableResourceName?: string;
    /**
    * Type of Consumable Resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_consumable_resource#resource_type BatchConsumableResource#resource_type}
    */
    readonly resourceType: string;
    /**
    * A key-value pair to associate with a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_consumable_resource#tags BatchConsumableResource#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Total Quantity of ConsumableResource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_consumable_resource#total_quantity BatchConsumableResource#total_quantity}
    */
    readonly totalQuantity: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_consumable_resource awscc_batch_consumable_resource}
*/
export declare class BatchConsumableResource extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_batch_consumable_resource";
    /**
    * Generates CDKTN code for importing a BatchConsumableResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BatchConsumableResource to import
    * @param importFromId The id of the existing BatchConsumableResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_consumable_resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BatchConsumableResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_consumable_resource awscc_batch_consumable_resource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BatchConsumableResourceConfig
    */
    constructor(scope: Construct, id: string, config: BatchConsumableResourceConfig);
    get availableQuantity(): number;
    get consumableResourceArn(): string;
    private _consumableResourceName?;
    get consumableResourceName(): string;
    set consumableResourceName(value: string);
    resetConsumableResourceName(): void;
    get consumableResourceNameInput(): string | undefined;
    get createdAt(): number;
    get id(): string;
    get inUseQuantity(): number;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _totalQuantity?;
    get totalQuantity(): number;
    set totalQuantity(value: number);
    get totalQuantityInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
