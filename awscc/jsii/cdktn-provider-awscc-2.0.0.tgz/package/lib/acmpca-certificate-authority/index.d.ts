/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AcmpcaCertificateAuthorityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Structure that contains CSR pass through extension information used by the CreateCertificateAuthority action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#csr_extensions AcmpcaCertificateAuthority#csr_extensions}
    */
    readonly csrExtensions?: AcmpcaCertificateAuthorityCsrExtensions;
    /**
    * Public key algorithm and size, in bits, of the key pair that your CA creates when it issues a certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#key_algorithm AcmpcaCertificateAuthority#key_algorithm}
    */
    readonly keyAlgorithm: string;
    /**
    * KeyStorageSecurityStadard defines a cryptographic key management compliance standard used for handling CA keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#key_storage_security_standard AcmpcaCertificateAuthority#key_storage_security_standard}
    */
    readonly keyStorageSecurityStandard?: string;
    /**
    * Certificate revocation information used by the CreateCertificateAuthority and UpdateCertificateAuthority actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#revocation_configuration AcmpcaCertificateAuthority#revocation_configuration}
    */
    readonly revocationConfiguration?: AcmpcaCertificateAuthorityRevocationConfiguration;
    /**
    * Algorithm your CA uses to sign certificate requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#signing_algorithm AcmpcaCertificateAuthority#signing_algorithm}
    */
    readonly signingAlgorithm: string;
    /**
    * Structure that contains X.500 distinguished name information for your CA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#subject AcmpcaCertificateAuthority#subject}
    */
    readonly subject: AcmpcaCertificateAuthoritySubject;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#tags AcmpcaCertificateAuthority#tags}
    */
    readonly tags?: AcmpcaCertificateAuthorityTags[] | cdktn.IResolvable;
    /**
    * The type of the certificate authority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#type AcmpcaCertificateAuthority#type}
    */
    readonly type: string;
    /**
    * Usage mode of the ceritificate authority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#usage_mode AcmpcaCertificateAuthority#usage_mode}
    */
    readonly usageMode?: string;
}
export interface AcmpcaCertificateAuthorityCsrExtensionsKeyUsage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#crl_sign AcmpcaCertificateAuthority#crl_sign}
    */
    readonly crlSign?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#data_encipherment AcmpcaCertificateAuthority#data_encipherment}
    */
    readonly dataEncipherment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#decipher_only AcmpcaCertificateAuthority#decipher_only}
    */
    readonly decipherOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#digital_signature AcmpcaCertificateAuthority#digital_signature}
    */
    readonly digitalSignature?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#encipher_only AcmpcaCertificateAuthority#encipher_only}
    */
    readonly encipherOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#key_agreement AcmpcaCertificateAuthority#key_agreement}
    */
    readonly keyAgreement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#key_cert_sign AcmpcaCertificateAuthority#key_cert_sign}
    */
    readonly keyCertSign?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#key_encipherment AcmpcaCertificateAuthority#key_encipherment}
    */
    readonly keyEncipherment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#non_repudiation AcmpcaCertificateAuthority#non_repudiation}
    */
    readonly nonRepudiation?: boolean | cdktn.IResolvable;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsKeyUsageToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsKeyUsage | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsKeyUsageToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsKeyUsage | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensionsKeyUsage | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensionsKeyUsage | cdktn.IResolvable | undefined);
    private _crlSign?;
    get crlSign(): boolean | cdktn.IResolvable;
    set crlSign(value: boolean | cdktn.IResolvable);
    resetCrlSign(): void;
    get crlSignInput(): boolean | cdktn.IResolvable | undefined;
    private _dataEncipherment?;
    get dataEncipherment(): boolean | cdktn.IResolvable;
    set dataEncipherment(value: boolean | cdktn.IResolvable);
    resetDataEncipherment(): void;
    get dataEnciphermentInput(): boolean | cdktn.IResolvable | undefined;
    private _decipherOnly?;
    get decipherOnly(): boolean | cdktn.IResolvable;
    set decipherOnly(value: boolean | cdktn.IResolvable);
    resetDecipherOnly(): void;
    get decipherOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _digitalSignature?;
    get digitalSignature(): boolean | cdktn.IResolvable;
    set digitalSignature(value: boolean | cdktn.IResolvable);
    resetDigitalSignature(): void;
    get digitalSignatureInput(): boolean | cdktn.IResolvable | undefined;
    private _encipherOnly?;
    get encipherOnly(): boolean | cdktn.IResolvable;
    set encipherOnly(value: boolean | cdktn.IResolvable);
    resetEncipherOnly(): void;
    get encipherOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _keyAgreement?;
    get keyAgreement(): boolean | cdktn.IResolvable;
    set keyAgreement(value: boolean | cdktn.IResolvable);
    resetKeyAgreement(): void;
    get keyAgreementInput(): boolean | cdktn.IResolvable | undefined;
    private _keyCertSign?;
    get keyCertSign(): boolean | cdktn.IResolvable;
    set keyCertSign(value: boolean | cdktn.IResolvable);
    resetKeyCertSign(): void;
    get keyCertSignInput(): boolean | cdktn.IResolvable | undefined;
    private _keyEncipherment?;
    get keyEncipherment(): boolean | cdktn.IResolvable;
    set keyEncipherment(value: boolean | cdktn.IResolvable);
    resetKeyEncipherment(): void;
    get keyEnciphermentInput(): boolean | cdktn.IResolvable | undefined;
    private _nonRepudiation?;
    get nonRepudiation(): boolean | cdktn.IResolvable;
    set nonRepudiation(value: boolean | cdktn.IResolvable);
    resetNonRepudiation(): void;
    get nonRepudiationInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes {
    /**
    * String that contains X.509 ObjectIdentifier information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#object_identifier AcmpcaCertificateAuthority#object_identifier}
    */
    readonly objectIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#value AcmpcaCertificateAuthority#value}
    */
    readonly value?: string;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes | cdktn.IResolvable | undefined);
    private _objectIdentifier?;
    get objectIdentifier(): string;
    set objectIdentifier(value: string);
    resetObjectIdentifier(): void;
    get objectIdentifierInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesOutputReference;
}
export interface AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#common_name AcmpcaCertificateAuthority#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#country AcmpcaCertificateAuthority#country}
    */
    readonly country?: string;
    /**
    * Array of X.500 attribute type and value. CustomAttributes cannot be used along with pre-defined attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#custom_attributes AcmpcaCertificateAuthority#custom_attributes}
    */
    readonly customAttributes?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#distinguished_name_qualifier AcmpcaCertificateAuthority#distinguished_name_qualifier}
    */
    readonly distinguishedNameQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#generation_qualifier AcmpcaCertificateAuthority#generation_qualifier}
    */
    readonly generationQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#given_name AcmpcaCertificateAuthority#given_name}
    */
    readonly givenName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#initials AcmpcaCertificateAuthority#initials}
    */
    readonly initials?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#locality AcmpcaCertificateAuthority#locality}
    */
    readonly locality?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#organization AcmpcaCertificateAuthority#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#organizational_unit AcmpcaCertificateAuthority#organizational_unit}
    */
    readonly organizationalUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#pseudonym AcmpcaCertificateAuthority#pseudonym}
    */
    readonly pseudonym?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#serial_number AcmpcaCertificateAuthority#serial_number}
    */
    readonly serialNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#state AcmpcaCertificateAuthority#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#surname AcmpcaCertificateAuthority#surname}
    */
    readonly surname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#title AcmpcaCertificateAuthority#title}
    */
    readonly title?: string;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName | cdktn.IResolvable | undefined);
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _customAttributes;
    get customAttributes(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesList;
    putCustomAttributes(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes[] | cdktn.IResolvable): void;
    resetCustomAttributes(): void;
    get customAttributesInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes[] | undefined;
    private _distinguishedNameQualifier?;
    get distinguishedNameQualifier(): string;
    set distinguishedNameQualifier(value: string);
    resetDistinguishedNameQualifier(): void;
    get distinguishedNameQualifierInput(): string | undefined;
    private _generationQualifier?;
    get generationQualifier(): string;
    set generationQualifier(value: string);
    resetGenerationQualifier(): void;
    get generationQualifierInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
    private _initials?;
    get initials(): string;
    set initials(value: string);
    resetInitials(): void;
    get initialsInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _organizationalUnit?;
    get organizationalUnit(): string;
    set organizationalUnit(value: string);
    resetOrganizationalUnit(): void;
    get organizationalUnitInput(): string | undefined;
    private _pseudonym?;
    get pseudonym(): string;
    set pseudonym(value: string);
    resetPseudonym(): void;
    get pseudonymInput(): string | undefined;
    private _serialNumber?;
    get serialNumber(): string;
    set serialNumber(value: string);
    resetSerialNumber(): void;
    get serialNumberInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _surname?;
    get surname(): string;
    set surname(value: string);
    resetSurname(): void;
    get surnameInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#name_assigner AcmpcaCertificateAuthority#name_assigner}
    */
    readonly nameAssigner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#party_name AcmpcaCertificateAuthority#party_name}
    */
    readonly partyName?: string;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyNameToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyNameToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName | cdktn.IResolvable | undefined);
    private _nameAssigner?;
    get nameAssigner(): string;
    set nameAssigner(value: string);
    resetNameAssigner(): void;
    get nameAssignerInput(): string | undefined;
    private _partyName?;
    get partyName(): string;
    set partyName(value: string);
    resetPartyName(): void;
    get partyNameInput(): string | undefined;
}
export interface AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName {
    /**
    * String that contains X.509 ObjectIdentifier information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#type_id AcmpcaCertificateAuthority#type_id}
    */
    readonly typeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#value AcmpcaCertificateAuthority#value}
    */
    readonly value?: string;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherNameToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherNameToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName | cdktn.IResolvable | undefined);
    private _typeId?;
    get typeId(): string;
    set typeId(value: string);
    resetTypeId(): void;
    get typeIdInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation {
    /**
    * Structure that contains X.500 distinguished name information for your CA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#directory_name AcmpcaCertificateAuthority#directory_name}
    */
    readonly directoryName?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName;
    /**
    * String that contains X.509 DnsName information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#dns_name AcmpcaCertificateAuthority#dns_name}
    */
    readonly dnsName?: string;
    /**
    * Structure that contains X.509 EdiPartyName information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#edi_party_name AcmpcaCertificateAuthority#edi_party_name}
    */
    readonly ediPartyName?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName;
    /**
    * String that contains X.509 IpAddress information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#ip_address AcmpcaCertificateAuthority#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * Structure that contains X.509 OtherName information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#other_name AcmpcaCertificateAuthority#other_name}
    */
    readonly otherName?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName;
    /**
    * String that contains X.509 ObjectIdentifier information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#registered_id AcmpcaCertificateAuthority#registered_id}
    */
    readonly registeredId?: string;
    /**
    * String that contains X.509 Rfc822Name information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#rfc_822_name AcmpcaCertificateAuthority#rfc_822_name}
    */
    readonly rfc822Name?: string;
    /**
    * String that contains X.509 UniformResourceIdentifier information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#uniform_resource_identifier AcmpcaCertificateAuthority#uniform_resource_identifier}
    */
    readonly uniformResourceIdentifier?: string;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation | cdktn.IResolvable | undefined);
    private _directoryName;
    get directoryName(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameOutputReference;
    putDirectoryName(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName): void;
    resetDirectoryName(): void;
    get directoryNameInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName | undefined;
    private _dnsName?;
    get dnsName(): string;
    set dnsName(value: string);
    resetDnsName(): void;
    get dnsNameInput(): string | undefined;
    private _ediPartyName;
    get ediPartyName(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyNameOutputReference;
    putEdiPartyName(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName): void;
    resetEdiPartyName(): void;
    get ediPartyNameInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _otherName;
    get otherName(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherNameOutputReference;
    putOtherName(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName): void;
    resetOtherName(): void;
    get otherNameInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName | undefined;
    private _registeredId?;
    get registeredId(): string;
    set registeredId(value: string);
    resetRegisteredId(): void;
    get registeredIdInput(): string | undefined;
    private _rfc822Name?;
    get rfc822Name(): string;
    set rfc822Name(value: string);
    resetRfc822Name(): void;
    get rfc822NameInput(): string | undefined;
    private _uniformResourceIdentifier?;
    get uniformResourceIdentifier(): string;
    set uniformResourceIdentifier(value: string);
    resetUniformResourceIdentifier(): void;
    get uniformResourceIdentifierInput(): string | undefined;
}
export interface AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod {
    /**
    * Pre-defined enum string for X.509 AccessMethod ObjectIdentifiers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#access_method_type AcmpcaCertificateAuthority#access_method_type}
    */
    readonly accessMethodType?: string;
    /**
    * String that contains X.509 ObjectIdentifier information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#custom_object_identifier AcmpcaCertificateAuthority#custom_object_identifier}
    */
    readonly customObjectIdentifier?: string;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethodToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethodToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod | cdktn.IResolvable | undefined);
    private _accessMethodType?;
    get accessMethodType(): string;
    set accessMethodType(value: string);
    resetAccessMethodType(): void;
    get accessMethodTypeInput(): string | undefined;
    private _customObjectIdentifier?;
    get customObjectIdentifier(): string;
    set customObjectIdentifier(value: string);
    resetCustomObjectIdentifier(): void;
    get customObjectIdentifierInput(): string | undefined;
}
export interface AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess {
    /**
    * Structure that contains X.509 GeneralName information. Assign one and ONLY one field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#access_location AcmpcaCertificateAuthority#access_location}
    */
    readonly accessLocation?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation;
    /**
    * Structure that contains X.509 AccessMethod information. Assign one and ONLY one field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#access_method AcmpcaCertificateAuthority#access_method}
    */
    readonly accessMethod?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess | cdktn.IResolvable | undefined);
    private _accessLocation;
    get accessLocation(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOutputReference;
    putAccessLocation(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation): void;
    resetAccessLocation(): void;
    get accessLocationInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation | undefined;
    private _accessMethod;
    get accessMethod(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethodOutputReference;
    putAccessMethod(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod): void;
    resetAccessMethod(): void;
    get accessMethodInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod | undefined;
}
export declare class AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessOutputReference;
}
export interface AcmpcaCertificateAuthorityCsrExtensions {
    /**
    * Structure that contains X.509 KeyUsage information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#key_usage AcmpcaCertificateAuthority#key_usage}
    */
    readonly keyUsage?: AcmpcaCertificateAuthorityCsrExtensionsKeyUsage;
    /**
    * Array of X.509 AccessDescription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#subject_information_access AcmpcaCertificateAuthority#subject_information_access}
    */
    readonly subjectInformationAccess?: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess[] | cdktn.IResolvable;
}
export declare function acmpcaCertificateAuthorityCsrExtensionsToTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensions | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityCsrExtensionsToHclTerraform(struct?: AcmpcaCertificateAuthorityCsrExtensions | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityCsrExtensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityCsrExtensions | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityCsrExtensions | cdktn.IResolvable | undefined);
    private _keyUsage;
    get keyUsage(): AcmpcaCertificateAuthorityCsrExtensionsKeyUsageOutputReference;
    putKeyUsage(value: AcmpcaCertificateAuthorityCsrExtensionsKeyUsage): void;
    resetKeyUsage(): void;
    get keyUsageInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensionsKeyUsage | undefined;
    private _subjectInformationAccess;
    get subjectInformationAccess(): AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessList;
    putSubjectInformationAccess(value: AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess[] | cdktn.IResolvable): void;
    resetSubjectInformationAccess(): void;
    get subjectInformationAccessInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess[] | undefined;
}
export interface AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#omit_extension AcmpcaCertificateAuthority#omit_extension}
    */
    readonly omitExtension?: boolean | cdktn.IResolvable;
}
export declare function acmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfigurationToTerraform(struct?: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfigurationToHclTerraform(struct?: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration | cdktn.IResolvable | undefined);
    private _omitExtension?;
    get omitExtension(): boolean | cdktn.IResolvable;
    set omitExtension(value: boolean | cdktn.IResolvable);
    resetOmitExtension(): void;
    get omitExtensionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration {
    /**
    * Configures the default behavior of the CRL Distribution Point extension for certificates issued by your certificate authority
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#crl_distribution_point_extension_configuration AcmpcaCertificateAuthority#crl_distribution_point_extension_configuration}
    */
    readonly crlDistributionPointExtensionConfiguration?: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#crl_type AcmpcaCertificateAuthority#crl_type}
    */
    readonly crlType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#custom_cname AcmpcaCertificateAuthority#custom_cname}
    */
    readonly customCname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#custom_path AcmpcaCertificateAuthority#custom_path}
    */
    readonly customPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#enabled AcmpcaCertificateAuthority#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#expiration_in_days AcmpcaCertificateAuthority#expiration_in_days}
    */
    readonly expirationInDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#s3_bucket_name AcmpcaCertificateAuthority#s3_bucket_name}
    */
    readonly s3BucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#s3_object_acl AcmpcaCertificateAuthority#s3_object_acl}
    */
    readonly s3ObjectAcl?: string;
}
export declare function acmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationToTerraform(struct?: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationToHclTerraform(struct?: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration | cdktn.IResolvable | undefined);
    private _crlDistributionPointExtensionConfiguration;
    get crlDistributionPointExtensionConfiguration(): AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfigurationOutputReference;
    putCrlDistributionPointExtensionConfiguration(value: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration): void;
    resetCrlDistributionPointExtensionConfiguration(): void;
    get crlDistributionPointExtensionConfigurationInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration | undefined;
    private _crlType?;
    get crlType(): string;
    set crlType(value: string);
    resetCrlType(): void;
    get crlTypeInput(): string | undefined;
    private _customCname?;
    get customCname(): string;
    set customCname(value: string);
    resetCustomCname(): void;
    get customCnameInput(): string | undefined;
    private _customPath?;
    get customPath(): string;
    set customPath(value: string);
    resetCustomPath(): void;
    get customPathInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _expirationInDays?;
    get expirationInDays(): number;
    set expirationInDays(value: number);
    resetExpirationInDays(): void;
    get expirationInDaysInput(): number | undefined;
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    resetS3BucketName(): void;
    get s3BucketNameInput(): string | undefined;
    private _s3ObjectAcl?;
    get s3ObjectAcl(): string;
    set s3ObjectAcl(value: string);
    resetS3ObjectAcl(): void;
    get s3ObjectAclInput(): string | undefined;
}
export interface AcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#enabled AcmpcaCertificateAuthority#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#ocsp_custom_cname AcmpcaCertificateAuthority#ocsp_custom_cname}
    */
    readonly ocspCustomCname?: string;
}
export declare function acmpcaCertificateAuthorityRevocationConfigurationOcspConfigurationToTerraform(struct?: AcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityRevocationConfigurationOcspConfigurationToHclTerraform(struct?: AcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityRevocationConfigurationOcspConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ocspCustomCname?;
    get ocspCustomCname(): string;
    set ocspCustomCname(value: string);
    resetOcspCustomCname(): void;
    get ocspCustomCnameInput(): string | undefined;
}
export interface AcmpcaCertificateAuthorityRevocationConfiguration {
    /**
    * Your certificate authority can create and maintain a certificate revocation list (CRL). A CRL contains information about certificates that have been revoked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#crl_configuration AcmpcaCertificateAuthority#crl_configuration}
    */
    readonly crlConfiguration?: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration;
    /**
    * Helps to configure online certificate status protocol (OCSP) responder for your certificate authority
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#ocsp_configuration AcmpcaCertificateAuthority#ocsp_configuration}
    */
    readonly ocspConfiguration?: AcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration;
}
export declare function acmpcaCertificateAuthorityRevocationConfigurationToTerraform(struct?: AcmpcaCertificateAuthorityRevocationConfiguration | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityRevocationConfigurationToHclTerraform(struct?: AcmpcaCertificateAuthorityRevocationConfiguration | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityRevocationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthorityRevocationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityRevocationConfiguration | cdktn.IResolvable | undefined);
    private _crlConfiguration;
    get crlConfiguration(): AcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationOutputReference;
    putCrlConfiguration(value: AcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration): void;
    resetCrlConfiguration(): void;
    get crlConfigurationInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration | undefined;
    private _ocspConfiguration;
    get ocspConfiguration(): AcmpcaCertificateAuthorityRevocationConfigurationOcspConfigurationOutputReference;
    putOcspConfiguration(value: AcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration): void;
    resetOcspConfiguration(): void;
    get ocspConfigurationInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration | undefined;
}
export interface AcmpcaCertificateAuthoritySubjectCustomAttributes {
    /**
    * String that contains X.509 ObjectIdentifier information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#object_identifier AcmpcaCertificateAuthority#object_identifier}
    */
    readonly objectIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#value AcmpcaCertificateAuthority#value}
    */
    readonly value?: string;
}
export declare function acmpcaCertificateAuthoritySubjectCustomAttributesToTerraform(struct?: AcmpcaCertificateAuthoritySubjectCustomAttributes | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthoritySubjectCustomAttributesToHclTerraform(struct?: AcmpcaCertificateAuthoritySubjectCustomAttributes | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthoritySubjectCustomAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateAuthoritySubjectCustomAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthoritySubjectCustomAttributes | cdktn.IResolvable | undefined);
    private _objectIdentifier?;
    get objectIdentifier(): string;
    set objectIdentifier(value: string);
    resetObjectIdentifier(): void;
    get objectIdentifierInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AcmpcaCertificateAuthoritySubjectCustomAttributesList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateAuthoritySubjectCustomAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateAuthoritySubjectCustomAttributesOutputReference;
}
export interface AcmpcaCertificateAuthoritySubject {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#common_name AcmpcaCertificateAuthority#common_name}
    */
    readonly commonName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#country AcmpcaCertificateAuthority#country}
    */
    readonly country?: string;
    /**
    * Array of X.500 attribute type and value. CustomAttributes cannot be used along with pre-defined attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#custom_attributes AcmpcaCertificateAuthority#custom_attributes}
    */
    readonly customAttributes?: AcmpcaCertificateAuthoritySubjectCustomAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#distinguished_name_qualifier AcmpcaCertificateAuthority#distinguished_name_qualifier}
    */
    readonly distinguishedNameQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#generation_qualifier AcmpcaCertificateAuthority#generation_qualifier}
    */
    readonly generationQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#given_name AcmpcaCertificateAuthority#given_name}
    */
    readonly givenName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#initials AcmpcaCertificateAuthority#initials}
    */
    readonly initials?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#locality AcmpcaCertificateAuthority#locality}
    */
    readonly locality?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#organization AcmpcaCertificateAuthority#organization}
    */
    readonly organization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#organizational_unit AcmpcaCertificateAuthority#organizational_unit}
    */
    readonly organizationalUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#pseudonym AcmpcaCertificateAuthority#pseudonym}
    */
    readonly pseudonym?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#serial_number AcmpcaCertificateAuthority#serial_number}
    */
    readonly serialNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#state AcmpcaCertificateAuthority#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#surname AcmpcaCertificateAuthority#surname}
    */
    readonly surname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#title AcmpcaCertificateAuthority#title}
    */
    readonly title?: string;
}
export declare function acmpcaCertificateAuthoritySubjectToTerraform(struct?: AcmpcaCertificateAuthoritySubject | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthoritySubjectToHclTerraform(struct?: AcmpcaCertificateAuthoritySubject | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthoritySubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateAuthoritySubject | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthoritySubject | cdktn.IResolvable | undefined);
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _customAttributes;
    get customAttributes(): AcmpcaCertificateAuthoritySubjectCustomAttributesList;
    putCustomAttributes(value: AcmpcaCertificateAuthoritySubjectCustomAttributes[] | cdktn.IResolvable): void;
    resetCustomAttributes(): void;
    get customAttributesInput(): cdktn.IResolvable | AcmpcaCertificateAuthoritySubjectCustomAttributes[] | undefined;
    private _distinguishedNameQualifier?;
    get distinguishedNameQualifier(): string;
    set distinguishedNameQualifier(value: string);
    resetDistinguishedNameQualifier(): void;
    get distinguishedNameQualifierInput(): string | undefined;
    private _generationQualifier?;
    get generationQualifier(): string;
    set generationQualifier(value: string);
    resetGenerationQualifier(): void;
    get generationQualifierInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
    private _initials?;
    get initials(): string;
    set initials(value: string);
    resetInitials(): void;
    get initialsInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _organizationalUnit?;
    get organizationalUnit(): string;
    set organizationalUnit(value: string);
    resetOrganizationalUnit(): void;
    get organizationalUnitInput(): string | undefined;
    private _pseudonym?;
    get pseudonym(): string;
    set pseudonym(value: string);
    resetPseudonym(): void;
    get pseudonymInput(): string | undefined;
    private _serialNumber?;
    get serialNumber(): string;
    set serialNumber(value: string);
    resetSerialNumber(): void;
    get serialNumberInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _surname?;
    get surname(): string;
    set surname(value: string);
    resetSurname(): void;
    get surnameInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface AcmpcaCertificateAuthorityTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#key AcmpcaCertificateAuthority#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#value AcmpcaCertificateAuthority#value}
    */
    readonly value?: string;
}
export declare function acmpcaCertificateAuthorityTagsToTerraform(struct?: AcmpcaCertificateAuthorityTags | cdktn.IResolvable): any;
export declare function acmpcaCertificateAuthorityTagsToHclTerraform(struct?: AcmpcaCertificateAuthorityTags | cdktn.IResolvable): any;
export declare class AcmpcaCertificateAuthorityTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateAuthorityTags | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateAuthorityTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AcmpcaCertificateAuthorityTagsList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateAuthorityTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateAuthorityTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority awscc_acmpca_certificate_authority}
*/
export declare class AcmpcaCertificateAuthority extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_acmpca_certificate_authority";
    /**
    * Generates CDKTN code for importing a AcmpcaCertificateAuthority resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AcmpcaCertificateAuthority to import
    * @param importFromId The id of the existing AcmpcaCertificateAuthority that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AcmpcaCertificateAuthority to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/acmpca_certificate_authority awscc_acmpca_certificate_authority} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AcmpcaCertificateAuthorityConfig
    */
    constructor(scope: Construct, id: string, config: AcmpcaCertificateAuthorityConfig);
    get arn(): string;
    get certificateSigningRequest(): string;
    private _csrExtensions;
    get csrExtensions(): AcmpcaCertificateAuthorityCsrExtensionsOutputReference;
    putCsrExtensions(value: AcmpcaCertificateAuthorityCsrExtensions): void;
    resetCsrExtensions(): void;
    get csrExtensionsInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityCsrExtensions | undefined;
    get id(): string;
    private _keyAlgorithm?;
    get keyAlgorithm(): string;
    set keyAlgorithm(value: string);
    get keyAlgorithmInput(): string | undefined;
    private _keyStorageSecurityStandard?;
    get keyStorageSecurityStandard(): string;
    set keyStorageSecurityStandard(value: string);
    resetKeyStorageSecurityStandard(): void;
    get keyStorageSecurityStandardInput(): string | undefined;
    private _revocationConfiguration;
    get revocationConfiguration(): AcmpcaCertificateAuthorityRevocationConfigurationOutputReference;
    putRevocationConfiguration(value: AcmpcaCertificateAuthorityRevocationConfiguration): void;
    resetRevocationConfiguration(): void;
    get revocationConfigurationInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityRevocationConfiguration | undefined;
    private _signingAlgorithm?;
    get signingAlgorithm(): string;
    set signingAlgorithm(value: string);
    get signingAlgorithmInput(): string | undefined;
    private _subject;
    get subject(): AcmpcaCertificateAuthoritySubjectOutputReference;
    putSubject(value: AcmpcaCertificateAuthoritySubject): void;
    get subjectInput(): cdktn.IResolvable | AcmpcaCertificateAuthoritySubject | undefined;
    private _tags;
    get tags(): AcmpcaCertificateAuthorityTagsList;
    putTags(value: AcmpcaCertificateAuthorityTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AcmpcaCertificateAuthorityTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _usageMode?;
    get usageMode(): string;
    set usageMode(value: string);
    resetUsageMode(): void;
    get usageModeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
