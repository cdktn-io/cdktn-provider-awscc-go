/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreConfigurationBundleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The branch name for version tracking.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#branch_name BedrockagentcoreConfigurationBundle#branch_name}
    */
    readonly branchName?: string;
    /**
    * The name for the configuration bundle. Names must be unique within your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#bundle_name BedrockagentcoreConfigurationBundle#bundle_name}
    */
    readonly bundleName: string;
    /**
    * A commit message describing the version of the configuration bundle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#commit_message BedrockagentcoreConfigurationBundle#commit_message}
    */
    readonly commitMessage?: string;
    /**
    * A map of component identifiers to their configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#components BedrockagentcoreConfigurationBundle#components}
    */
    readonly components: {
        [key: string]: BedrockagentcoreConfigurationBundleComponents;
    } | cdktn.IResolvable;
    /**
    * The source that created a configuration bundle version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#created_by BedrockagentcoreConfigurationBundle#created_by}
    */
    readonly createdBy?: BedrockagentcoreConfigurationBundleCreatedBy;
    /**
    * The description for the configuration bundle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#description BedrockagentcoreConfigurationBundle#description}
    */
    readonly description?: string;
    /**
    * The ARN of the KMS key used to encrypt component configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#kms_key_arn BedrockagentcoreConfigurationBundle#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Tags to assign to the configuration bundle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#tags BedrockagentcoreConfigurationBundle#tags}
    */
    readonly tags?: BedrockagentcoreConfigurationBundleTags[] | cdktn.IResolvable;
}
export interface BedrockagentcoreConfigurationBundleComponents {
    /**
    * The configuration values as a flexible JSON document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#configuration BedrockagentcoreConfigurationBundle#configuration}
    */
    readonly configuration?: string;
}
export declare function bedrockagentcoreConfigurationBundleComponentsToTerraform(struct?: BedrockagentcoreConfigurationBundleComponents | cdktn.IResolvable): any;
export declare function bedrockagentcoreConfigurationBundleComponentsToHclTerraform(struct?: BedrockagentcoreConfigurationBundleComponents | cdktn.IResolvable): any;
export declare class BedrockagentcoreConfigurationBundleComponentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): BedrockagentcoreConfigurationBundleComponents | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreConfigurationBundleComponents | cdktn.IResolvable | undefined);
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
}
export declare class BedrockagentcoreConfigurationBundleComponentsMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: BedrockagentcoreConfigurationBundleComponents;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): BedrockagentcoreConfigurationBundleComponentsOutputReference;
}
export interface BedrockagentcoreConfigurationBundleCreatedBy {
    /**
    * The Amazon Resource Name (ARN) of the source, if applicable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#arn BedrockagentcoreConfigurationBundle#arn}
    */
    readonly arn?: string;
    /**
    * The name of the source (for example, user, optimization-job, or system).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#name BedrockagentcoreConfigurationBundle#name}
    */
    readonly name?: string;
}
export declare function bedrockagentcoreConfigurationBundleCreatedByToTerraform(struct?: BedrockagentcoreConfigurationBundleCreatedBy | cdktn.IResolvable): any;
export declare function bedrockagentcoreConfigurationBundleCreatedByToHclTerraform(struct?: BedrockagentcoreConfigurationBundleCreatedBy | cdktn.IResolvable): any;
export declare class BedrockagentcoreConfigurationBundleCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreConfigurationBundleCreatedBy | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreConfigurationBundleCreatedBy | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface BedrockagentcoreConfigurationBundleLineageMetadataCreatedBy {
}
export declare function bedrockagentcoreConfigurationBundleLineageMetadataCreatedByToTerraform(struct?: BedrockagentcoreConfigurationBundleLineageMetadataCreatedBy): any;
export declare function bedrockagentcoreConfigurationBundleLineageMetadataCreatedByToHclTerraform(struct?: BedrockagentcoreConfigurationBundleLineageMetadataCreatedBy): any;
export declare class BedrockagentcoreConfigurationBundleLineageMetadataCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreConfigurationBundleLineageMetadataCreatedBy | undefined;
    set internalValue(value: BedrockagentcoreConfigurationBundleLineageMetadataCreatedBy | undefined);
    get arn(): string;
    get name(): string;
}
export interface BedrockagentcoreConfigurationBundleLineageMetadata {
}
export declare function bedrockagentcoreConfigurationBundleLineageMetadataToTerraform(struct?: BedrockagentcoreConfigurationBundleLineageMetadata): any;
export declare function bedrockagentcoreConfigurationBundleLineageMetadataToHclTerraform(struct?: BedrockagentcoreConfigurationBundleLineageMetadata): any;
export declare class BedrockagentcoreConfigurationBundleLineageMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreConfigurationBundleLineageMetadata | undefined;
    set internalValue(value: BedrockagentcoreConfigurationBundleLineageMetadata | undefined);
    get branchName(): string;
    get commitMessage(): string;
    private _createdBy;
    get createdBy(): BedrockagentcoreConfigurationBundleLineageMetadataCreatedByOutputReference;
    get parentVersionIds(): string[];
}
export interface BedrockagentcoreConfigurationBundleTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#key BedrockagentcoreConfigurationBundle#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#value BedrockagentcoreConfigurationBundle#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcoreConfigurationBundleTagsToTerraform(struct?: BedrockagentcoreConfigurationBundleTags | cdktn.IResolvable): any;
export declare function bedrockagentcoreConfigurationBundleTagsToHclTerraform(struct?: BedrockagentcoreConfigurationBundleTags | cdktn.IResolvable): any;
export declare class BedrockagentcoreConfigurationBundleTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreConfigurationBundleTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreConfigurationBundleTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcoreConfigurationBundleTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreConfigurationBundleTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreConfigurationBundleTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle awscc_bedrockagentcore_configuration_bundle}
*/
export declare class BedrockagentcoreConfigurationBundle extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_configuration_bundle";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreConfigurationBundle resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreConfigurationBundle to import
    * @param importFromId The id of the existing BedrockagentcoreConfigurationBundle that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreConfigurationBundle to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_configuration_bundle awscc_bedrockagentcore_configuration_bundle} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreConfigurationBundleConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreConfigurationBundleConfig);
    private _branchName?;
    get branchName(): string;
    set branchName(value: string);
    resetBranchName(): void;
    get branchNameInput(): string | undefined;
    get bundleArn(): string;
    get bundleId(): string;
    private _bundleName?;
    get bundleName(): string;
    set bundleName(value: string);
    get bundleNameInput(): string | undefined;
    private _commitMessage?;
    get commitMessage(): string;
    set commitMessage(value: string);
    resetCommitMessage(): void;
    get commitMessageInput(): string | undefined;
    private _components;
    get components(): BedrockagentcoreConfigurationBundleComponentsMap;
    putComponents(value: {
        [key: string]: BedrockagentcoreConfigurationBundleComponents;
    } | cdktn.IResolvable): void;
    get componentsInput(): cdktn.IResolvable | {
        [key: string]: BedrockagentcoreConfigurationBundleComponents;
    } | undefined;
    get createdAt(): string;
    private _createdBy;
    get createdBy(): BedrockagentcoreConfigurationBundleCreatedByOutputReference;
    putCreatedBy(value: BedrockagentcoreConfigurationBundleCreatedBy): void;
    resetCreatedBy(): void;
    get createdByInput(): cdktn.IResolvable | BedrockagentcoreConfigurationBundleCreatedBy | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _lineageMetadata;
    get lineageMetadata(): BedrockagentcoreConfigurationBundleLineageMetadataOutputReference;
    private _tags;
    get tags(): BedrockagentcoreConfigurationBundleTagsList;
    putTags(value: BedrockagentcoreConfigurationBundleTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcoreConfigurationBundleTags[] | undefined;
    get updatedAt(): string;
    get versionId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
