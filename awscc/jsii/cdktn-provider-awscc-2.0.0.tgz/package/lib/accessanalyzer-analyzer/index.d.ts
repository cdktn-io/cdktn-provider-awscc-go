/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessanalyzerAnalyzerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The configuration for the analyzer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#analyzer_configuration AccessanalyzerAnalyzer#analyzer_configuration}
    */
    readonly analyzerConfiguration?: AccessanalyzerAnalyzerAnalyzerConfiguration;
    /**
    * Analyzer name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#analyzer_name AccessanalyzerAnalyzer#analyzer_name}
    */
    readonly analyzerName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#archive_rules AccessanalyzerAnalyzer#archive_rules}
    */
    readonly archiveRules?: AccessanalyzerAnalyzerArchiveRules[] | cdktn.IResolvable;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#tags AccessanalyzerAnalyzer#tags}
    */
    readonly tags?: AccessanalyzerAnalyzerTags[] | cdktn.IResolvable;
    /**
    * The type of the analyzer, must be one of ACCOUNT, ORGANIZATION, ACCOUNT_INTERNAL_ACCESS, ORGANIZATION_INTERNAL_ACCESS, ACCOUNT_UNUSED_ACCESS and ORGANIZATION_UNUSED_ACCESS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#type AccessanalyzerAnalyzer#type}
    */
    readonly type: string;
}
export interface AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions {
    /**
    * A list of AWS account IDs to apply to the internal access analysis rule criteria. Account IDs can only be applied to the analysis rule criteria for organization-level analyzers and cannot include the organization owner account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#account_ids AccessanalyzerAnalyzer#account_ids}
    */
    readonly accountIds?: string[];
    /**
    * A list of resource ARNs to apply to the internal access analysis rule criteria. The analyzer will only generate findings for resources that match these ARNs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#resource_arns AccessanalyzerAnalyzer#resource_arns}
    */
    readonly resourceArns?: string[];
    /**
    * A list of resource types to apply to the internal access analysis rule criteria. The analyzer will only generate findings for resources of these types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#resource_types AccessanalyzerAnalyzer#resource_types}
    */
    readonly resourceTypes?: string[];
}
export declare function accessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsToTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsToHclTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions | cdktn.IResolvable | undefined);
    private _accountIds?;
    get accountIds(): string[];
    set accountIds(value: string[]);
    resetAccountIds(): void;
    get accountIdsInput(): string[] | undefined;
    private _resourceArns?;
    get resourceArns(): string[];
    set resourceArns(value: string[]);
    resetResourceArns(): void;
    get resourceArnsInput(): string[] | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
}
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsOutputReference;
}
export interface AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule {
    /**
    * A list of rules for the internal access analyzer containing criteria to include in analysis. Only resources that meet the rule criteria will generate findings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#inclusions AccessanalyzerAnalyzer#inclusions}
    */
    readonly inclusions?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions[] | cdktn.IResolvable;
}
export declare function accessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleToTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleToHclTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule | cdktn.IResolvable | undefined);
    private _inclusions;
    get inclusions(): AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusionsList;
    putInclusions(value: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions[] | cdktn.IResolvable): void;
    resetInclusions(): void;
    get inclusionsInput(): cdktn.IResolvable | AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleInclusions[] | undefined;
}
export interface AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration {
    /**
    * Contains information about analysis rules for the internal access analyzer. Analysis rules determine which entities will generate findings based on the criteria you define when you create the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#internal_access_analysis_rule AccessanalyzerAnalyzer#internal_access_analysis_rule}
    */
    readonly internalAccessAnalysisRule?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule;
}
export declare function accessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationToTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationToHclTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration | cdktn.IResolvable | undefined);
    private _internalAccessAnalysisRule;
    get internalAccessAnalysisRule(): AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRuleOutputReference;
    putInternalAccessAnalysisRule(value: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule): void;
    resetInternalAccessAnalysisRule(): void;
    get internalAccessAnalysisRuleInput(): cdktn.IResolvable | AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationInternalAccessAnalysisRule | undefined;
}
export interface AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags {
}
export declare function accessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsToTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsToHclTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags | cdktn.IResolvable | undefined);
}
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsOutputReference;
}
export interface AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions {
    /**
    * A list of AWS account IDs to apply to the analysis rule criteria. The accounts cannot include the organization analyzer owner account. Account IDs can only be applied to the analysis rule criteria for organization-level analyzers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#account_ids AccessanalyzerAnalyzer#account_ids}
    */
    readonly accountIds?: string[];
    /**
    * An array of key-value pairs to match for your resources. You can use the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * For the tag key, you can specify a value that is 1 to 128 characters in length and cannot be prefixed with aws:.
    *
    * For the tag value, you can specify a value that is 0 to 256 characters in length. If the specified tag value is 0 characters, the rule is applied to all principals with the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#resource_tags AccessanalyzerAnalyzer#resource_tags}
    */
    readonly resourceTags?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags[] | cdktn.IResolvable;
}
export declare function accessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsToTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsToHclTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions | cdktn.IResolvable | undefined);
    private _accountIds?;
    get accountIds(): string[];
    set accountIds(value: string[]);
    resetAccountIds(): void;
    get accountIdsInput(): string[] | undefined;
    private _resourceTags;
    get resourceTags(): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTagsList;
    putResourceTags(value: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags[] | cdktn.IResolvable): void;
    resetResourceTags(): void;
    get resourceTagsInput(): cdktn.IResolvable | AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsResourceTags[] | undefined;
}
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsOutputReference;
}
export interface AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule {
    /**
    * A list of rules for the analyzer containing criteria to exclude from analysis. Entities that meet the rule criteria will not generate findings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#exclusions AccessanalyzerAnalyzer#exclusions}
    */
    readonly exclusions?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions[] | cdktn.IResolvable;
}
export declare function accessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleToTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleToHclTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule | cdktn.IResolvable | undefined);
    private _exclusions;
    get exclusions(): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusionsList;
    putExclusions(value: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions[] | cdktn.IResolvable): void;
    resetExclusions(): void;
    get exclusionsInput(): cdktn.IResolvable | AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleExclusions[] | undefined;
}
export interface AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration {
    /**
    * Contains information about rules for the analyzer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#analysis_rule AccessanalyzerAnalyzer#analysis_rule}
    */
    readonly analysisRule?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule;
    /**
    * The specified access age in days for which to generate findings for unused access. For example, if you specify 90 days, the analyzer will generate findings for IAM entities within the accounts of the selected organization for any access that hasn't been used in 90 or more days since the analyzer's last scan. You can choose a value between 1 and 365 days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#unused_access_age AccessanalyzerAnalyzer#unused_access_age}
    */
    readonly unusedAccessAge?: number;
}
export declare function accessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationToTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationToHclTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration | cdktn.IResolvable | undefined);
    private _analysisRule;
    get analysisRule(): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRuleOutputReference;
    putAnalysisRule(value: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule): void;
    resetAnalysisRule(): void;
    get analysisRuleInput(): cdktn.IResolvable | AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationAnalysisRule | undefined;
    private _unusedAccessAge?;
    get unusedAccessAge(): number;
    set unusedAccessAge(value: number);
    resetUnusedAccessAge(): void;
    get unusedAccessAgeInput(): number | undefined;
}
export interface AccessanalyzerAnalyzerAnalyzerConfiguration {
    /**
    * Specifies the configuration of an internal access analyzer for an AWS organization or account. This configuration determines how the analyzer evaluates internal access within your AWS environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#internal_access_configuration AccessanalyzerAnalyzer#internal_access_configuration}
    */
    readonly internalAccessConfiguration?: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration;
    /**
    * The Configuration for Unused Access Analyzer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#unused_access_configuration AccessanalyzerAnalyzer#unused_access_configuration}
    */
    readonly unusedAccessConfiguration?: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration;
}
export declare function accessanalyzerAnalyzerAnalyzerConfigurationToTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfiguration | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerAnalyzerConfigurationToHclTerraform(struct?: AccessanalyzerAnalyzerAnalyzerConfiguration | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerAnalyzerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerAnalyzerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerAnalyzerConfiguration | cdktn.IResolvable | undefined);
    private _internalAccessConfiguration;
    get internalAccessConfiguration(): AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfigurationOutputReference;
    putInternalAccessConfiguration(value: AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration): void;
    resetInternalAccessConfiguration(): void;
    get internalAccessConfigurationInput(): cdktn.IResolvable | AccessanalyzerAnalyzerAnalyzerConfigurationInternalAccessConfiguration | undefined;
    private _unusedAccessConfiguration;
    get unusedAccessConfiguration(): AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfigurationOutputReference;
    putUnusedAccessConfiguration(value: AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration): void;
    resetUnusedAccessConfiguration(): void;
    get unusedAccessConfigurationInput(): cdktn.IResolvable | AccessanalyzerAnalyzerAnalyzerConfigurationUnusedAccessConfiguration | undefined;
}
export interface AccessanalyzerAnalyzerArchiveRulesFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#contains AccessanalyzerAnalyzer#contains}
    */
    readonly contains?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#eq AccessanalyzerAnalyzer#eq}
    */
    readonly eq?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#exists AccessanalyzerAnalyzer#exists}
    */
    readonly exists?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#neq AccessanalyzerAnalyzer#neq}
    */
    readonly neq?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#property AccessanalyzerAnalyzer#property}
    */
    readonly property?: string;
}
export declare function accessanalyzerAnalyzerArchiveRulesFilterToTerraform(struct?: AccessanalyzerAnalyzerArchiveRulesFilter | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerArchiveRulesFilterToHclTerraform(struct?: AccessanalyzerAnalyzerArchiveRulesFilter | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerArchiveRulesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerAnalyzerArchiveRulesFilter | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerArchiveRulesFilter | cdktn.IResolvable | undefined);
    private _contains?;
    get contains(): string[];
    set contains(value: string[]);
    resetContains(): void;
    get containsInput(): string[] | undefined;
    private _eq?;
    get eq(): string[];
    set eq(value: string[]);
    resetEq(): void;
    get eqInput(): string[] | undefined;
    private _exists?;
    get exists(): boolean | cdktn.IResolvable;
    set exists(value: boolean | cdktn.IResolvable);
    resetExists(): void;
    get existsInput(): boolean | cdktn.IResolvable | undefined;
    private _neq?;
    get neq(): string[];
    set neq(value: string[]);
    resetNeq(): void;
    get neqInput(): string[] | undefined;
    private _property?;
    get property(): string;
    set property(value: string);
    resetProperty(): void;
    get propertyInput(): string | undefined;
}
export declare class AccessanalyzerAnalyzerArchiveRulesFilterList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerAnalyzerArchiveRulesFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerAnalyzerArchiveRulesFilterOutputReference;
}
export interface AccessanalyzerAnalyzerArchiveRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#filter AccessanalyzerAnalyzer#filter}
    */
    readonly filter?: AccessanalyzerAnalyzerArchiveRulesFilter[] | cdktn.IResolvable;
    /**
    * The archive rule name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#rule_name AccessanalyzerAnalyzer#rule_name}
    */
    readonly ruleName?: string;
}
export declare function accessanalyzerAnalyzerArchiveRulesToTerraform(struct?: AccessanalyzerAnalyzerArchiveRules | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerArchiveRulesToHclTerraform(struct?: AccessanalyzerAnalyzerArchiveRules | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerArchiveRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerAnalyzerArchiveRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerArchiveRules | cdktn.IResolvable | undefined);
    private _filter;
    get filter(): AccessanalyzerAnalyzerArchiveRulesFilterList;
    putFilter(value: AccessanalyzerAnalyzerArchiveRulesFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | AccessanalyzerAnalyzerArchiveRulesFilter[] | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    resetRuleName(): void;
    get ruleNameInput(): string | undefined;
}
export declare class AccessanalyzerAnalyzerArchiveRulesList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerAnalyzerArchiveRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerAnalyzerArchiveRulesOutputReference;
}
export interface AccessanalyzerAnalyzerTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#key AccessanalyzerAnalyzer#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#value AccessanalyzerAnalyzer#value}
    */
    readonly value?: string;
}
export declare function accessanalyzerAnalyzerTagsToTerraform(struct?: AccessanalyzerAnalyzerTags | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerTagsToHclTerraform(struct?: AccessanalyzerAnalyzerTags | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerAnalyzerTags | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AccessanalyzerAnalyzerTagsList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerAnalyzerTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerAnalyzerTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer awscc_accessanalyzer_analyzer}
*/
export declare class AccessanalyzerAnalyzer extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_accessanalyzer_analyzer";
    /**
    * Generates CDKTN code for importing a AccessanalyzerAnalyzer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessanalyzerAnalyzer to import
    * @param importFromId The id of the existing AccessanalyzerAnalyzer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessanalyzerAnalyzer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_analyzer awscc_accessanalyzer_analyzer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessanalyzerAnalyzerConfig
    */
    constructor(scope: Construct, id: string, config: AccessanalyzerAnalyzerConfig);
    private _analyzerConfiguration;
    get analyzerConfiguration(): AccessanalyzerAnalyzerAnalyzerConfigurationOutputReference;
    putAnalyzerConfiguration(value: AccessanalyzerAnalyzerAnalyzerConfiguration): void;
    resetAnalyzerConfiguration(): void;
    get analyzerConfigurationInput(): AccessanalyzerAnalyzerAnalyzerConfiguration | cdktn.IResolvable | undefined;
    private _analyzerName?;
    get analyzerName(): string;
    set analyzerName(value: string);
    resetAnalyzerName(): void;
    get analyzerNameInput(): string | undefined;
    private _archiveRules;
    get archiveRules(): AccessanalyzerAnalyzerArchiveRulesList;
    putArchiveRules(value: AccessanalyzerAnalyzerArchiveRules[] | cdktn.IResolvable): void;
    resetArchiveRules(): void;
    get archiveRulesInput(): cdktn.IResolvable | AccessanalyzerAnalyzerArchiveRules[] | undefined;
    get arn(): string;
    get id(): string;
    private _tags;
    get tags(): AccessanalyzerAnalyzerTagsList;
    putTags(value: AccessanalyzerAnalyzerTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AccessanalyzerAnalyzerTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
