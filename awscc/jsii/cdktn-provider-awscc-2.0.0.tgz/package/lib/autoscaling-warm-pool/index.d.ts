/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AutoscalingWarmPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool#auto_scaling_group_name AutoscalingWarmPool#auto_scaling_group_name}
    */
    readonly autoScalingGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool#instance_reuse_policy AutoscalingWarmPool#instance_reuse_policy}
    */
    readonly instanceReusePolicy?: AutoscalingWarmPoolInstanceReusePolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool#max_group_prepared_capacity AutoscalingWarmPool#max_group_prepared_capacity}
    */
    readonly maxGroupPreparedCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool#min_size AutoscalingWarmPool#min_size}
    */
    readonly minSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool#pool_state AutoscalingWarmPool#pool_state}
    */
    readonly poolState?: string;
}
export interface AutoscalingWarmPoolInstanceReusePolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool#reuse_on_scale_in AutoscalingWarmPool#reuse_on_scale_in}
    */
    readonly reuseOnScaleIn?: boolean | cdktn.IResolvable;
}
export declare function autoscalingWarmPoolInstanceReusePolicyToTerraform(struct?: AutoscalingWarmPoolInstanceReusePolicy | cdktn.IResolvable): any;
export declare function autoscalingWarmPoolInstanceReusePolicyToHclTerraform(struct?: AutoscalingWarmPoolInstanceReusePolicy | cdktn.IResolvable): any;
export declare class AutoscalingWarmPoolInstanceReusePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingWarmPoolInstanceReusePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingWarmPoolInstanceReusePolicy | cdktn.IResolvable | undefined);
    private _reuseOnScaleIn?;
    get reuseOnScaleIn(): boolean | cdktn.IResolvable;
    set reuseOnScaleIn(value: boolean | cdktn.IResolvable);
    resetReuseOnScaleIn(): void;
    get reuseOnScaleInInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool awscc_autoscaling_warm_pool}
*/
export declare class AutoscalingWarmPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_autoscaling_warm_pool";
    /**
    * Generates CDKTN code for importing a AutoscalingWarmPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutoscalingWarmPool to import
    * @param importFromId The id of the existing AutoscalingWarmPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutoscalingWarmPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_warm_pool awscc_autoscaling_warm_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutoscalingWarmPoolConfig
    */
    constructor(scope: Construct, id: string, config: AutoscalingWarmPoolConfig);
    private _autoScalingGroupName?;
    get autoScalingGroupName(): string;
    set autoScalingGroupName(value: string);
    get autoScalingGroupNameInput(): string | undefined;
    get id(): string;
    private _instanceReusePolicy;
    get instanceReusePolicy(): AutoscalingWarmPoolInstanceReusePolicyOutputReference;
    putInstanceReusePolicy(value: AutoscalingWarmPoolInstanceReusePolicy): void;
    resetInstanceReusePolicy(): void;
    get instanceReusePolicyInput(): cdktn.IResolvable | AutoscalingWarmPoolInstanceReusePolicy | undefined;
    private _maxGroupPreparedCapacity?;
    get maxGroupPreparedCapacity(): number;
    set maxGroupPreparedCapacity(value: number);
    resetMaxGroupPreparedCapacity(): void;
    get maxGroupPreparedCapacityInput(): number | undefined;
    private _minSize?;
    get minSize(): number;
    set minSize(value: number);
    resetMinSize(): void;
    get minSizeInput(): number | undefined;
    private _poolState?;
    get poolState(): string;
    set poolState(value: string);
    resetPoolState(): void;
    get poolStateInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
