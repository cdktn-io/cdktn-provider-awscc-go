/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CurReportDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of manifests that you want Amazon Web Services to create for this report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#additional_artifacts CurReportDefinition#additional_artifacts}
    */
    readonly additionalArtifacts?: string[];
    /**
    * A list of strings that indicate additional content that Amazon Web Services includes in the report, such as individual resource IDs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#additional_schema_elements CurReportDefinition#additional_schema_elements}
    */
    readonly additionalSchemaElements?: string[];
    /**
    * The Amazon resource name of the billing view. You can get this value by using the billing view service public APIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#billing_view_arn CurReportDefinition#billing_view_arn}
    */
    readonly billingViewArn?: string;
    /**
    * The compression format that AWS uses for the report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#compression CurReportDefinition#compression}
    */
    readonly compression: string;
    /**
    * The format that AWS saves the report in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#format CurReportDefinition#format}
    */
    readonly format: string;
    /**
    * Whether you want Amazon Web Services to update your reports after they have been finalized if Amazon Web Services detects charges related to previous months. These charges can include refunds, credits, or support fees.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#refresh_closed_reports CurReportDefinition#refresh_closed_reports}
    */
    readonly refreshClosedReports: boolean | cdktn.IResolvable;
    /**
    * The name of the report that you want to create. The name must be unique, is case sensitive, and can't include spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#report_name CurReportDefinition#report_name}
    */
    readonly reportName: string;
    /**
    * Whether you want Amazon Web Services to overwrite the previous version of each report or to deliver the report in addition to the previous versions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#report_versioning CurReportDefinition#report_versioning}
    */
    readonly reportVersioning: string;
    /**
    * The S3 bucket where AWS delivers the report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#s3_bucket CurReportDefinition#s3_bucket}
    */
    readonly s3Bucket: string;
    /**
    * The prefix that AWS adds to the report name when AWS delivers the report. Your prefix can't include spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#s3_prefix CurReportDefinition#s3_prefix}
    */
    readonly s3Prefix: string;
    /**
    * The region of the S3 bucket that AWS delivers the report into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#s3_region CurReportDefinition#s3_region}
    */
    readonly s3Region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#tags CurReportDefinition#tags}
    */
    readonly tags?: CurReportDefinitionTags[] | cdktn.IResolvable;
    /**
    * The granularity of the line items in the report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#time_unit CurReportDefinition#time_unit}
    */
    readonly timeUnit: string;
}
export interface CurReportDefinitionTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#key CurReportDefinition#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#value CurReportDefinition#value}
    */
    readonly value?: string;
}
export declare function curReportDefinitionTagsToTerraform(struct?: CurReportDefinitionTags | cdktn.IResolvable): any;
export declare function curReportDefinitionTagsToHclTerraform(struct?: CurReportDefinitionTags | cdktn.IResolvable): any;
export declare class CurReportDefinitionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CurReportDefinitionTags | cdktn.IResolvable | undefined;
    set internalValue(value: CurReportDefinitionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CurReportDefinitionTagsList extends cdktn.ComplexList {
    internalValue?: CurReportDefinitionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CurReportDefinitionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition awscc_cur_report_definition}
*/
export declare class CurReportDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cur_report_definition";
    /**
    * Generates CDKTN code for importing a CurReportDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CurReportDefinition to import
    * @param importFromId The id of the existing CurReportDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CurReportDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cur_report_definition awscc_cur_report_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CurReportDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: CurReportDefinitionConfig);
    private _additionalArtifacts?;
    get additionalArtifacts(): string[];
    set additionalArtifacts(value: string[]);
    resetAdditionalArtifacts(): void;
    get additionalArtifactsInput(): string[] | undefined;
    private _additionalSchemaElements?;
    get additionalSchemaElements(): string[];
    set additionalSchemaElements(value: string[]);
    resetAdditionalSchemaElements(): void;
    get additionalSchemaElementsInput(): string[] | undefined;
    private _billingViewArn?;
    get billingViewArn(): string;
    set billingViewArn(value: string);
    resetBillingViewArn(): void;
    get billingViewArnInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    get compressionInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    get id(): string;
    private _refreshClosedReports?;
    get refreshClosedReports(): boolean | cdktn.IResolvable;
    set refreshClosedReports(value: boolean | cdktn.IResolvable);
    get refreshClosedReportsInput(): boolean | cdktn.IResolvable | undefined;
    private _reportName?;
    get reportName(): string;
    set reportName(value: string);
    get reportNameInput(): string | undefined;
    private _reportVersioning?;
    get reportVersioning(): string;
    set reportVersioning(value: string);
    get reportVersioningInput(): string | undefined;
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    get s3BucketInput(): string | undefined;
    private _s3Prefix?;
    get s3Prefix(): string;
    set s3Prefix(value: string);
    get s3PrefixInput(): string | undefined;
    private _s3Region?;
    get s3Region(): string;
    set s3Region(value: string);
    get s3RegionInput(): string | undefined;
    private _tags;
    get tags(): CurReportDefinitionTagsList;
    putTags(value: CurReportDefinitionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CurReportDefinitionTags[] | undefined;
    private _timeUnit?;
    get timeUnit(): string;
    set timeUnit(value: string);
    get timeUnitInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
