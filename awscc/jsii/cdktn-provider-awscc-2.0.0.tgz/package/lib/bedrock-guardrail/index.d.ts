/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockGuardrailConfig extends cdktn.TerraformMetaArguments {
    /**
    * Optional configuration for integrating Automated Reasoning policies with the guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#automated_reasoning_policy_config BedrockGuardrail#automated_reasoning_policy_config}
    */
    readonly automatedReasoningPolicyConfig?: BedrockGuardrailAutomatedReasoningPolicyConfig;
    /**
    * Messaging for when violations are detected in text
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#blocked_input_messaging BedrockGuardrail#blocked_input_messaging}
    */
    readonly blockedInputMessaging: string;
    /**
    * Messaging for when violations are detected in text
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#blocked_outputs_messaging BedrockGuardrail#blocked_outputs_messaging}
    */
    readonly blockedOutputsMessaging: string;
    /**
    * Content policy config for a guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#content_policy_config BedrockGuardrail#content_policy_config}
    */
    readonly contentPolicyConfig?: BedrockGuardrailContentPolicyConfig;
    /**
    * Contextual grounding policy config for a guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#contextual_grounding_policy_config BedrockGuardrail#contextual_grounding_policy_config}
    */
    readonly contextualGroundingPolicyConfig?: BedrockGuardrailContextualGroundingPolicyConfig;
    /**
    * The system-defined guardrail profile that you?re using with your guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#cross_region_config BedrockGuardrail#cross_region_config}
    */
    readonly crossRegionConfig?: BedrockGuardrailCrossRegionConfig;
    /**
    * Description of the guardrail or its version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#description BedrockGuardrail#description}
    */
    readonly description?: string;
    /**
    * The KMS key with which the guardrail was encrypted at rest
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#kms_key_arn BedrockGuardrail#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Name of the guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#name BedrockGuardrail#name}
    */
    readonly name: string;
    /**
    * Sensitive information policy config for a guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#sensitive_information_policy_config BedrockGuardrail#sensitive_information_policy_config}
    */
    readonly sensitiveInformationPolicyConfig?: BedrockGuardrailSensitiveInformationPolicyConfig;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#tags BedrockGuardrail#tags}
    */
    readonly tags?: BedrockGuardrailTags[] | cdktn.IResolvable;
    /**
    * Topic policy config for a guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#topic_policy_config BedrockGuardrail#topic_policy_config}
    */
    readonly topicPolicyConfig?: BedrockGuardrailTopicPolicyConfig;
    /**
    * Word policy config for a guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#word_policy_config BedrockGuardrail#word_policy_config}
    */
    readonly wordPolicyConfig?: BedrockGuardrailWordPolicyConfig;
}
export interface BedrockGuardrailAutomatedReasoningPolicyConfig {
    /**
    * The confidence threshold for triggering guardrail actions based on Automated Reasoning policy violations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#confidence_threshold BedrockGuardrail#confidence_threshold}
    */
    readonly confidenceThreshold?: number;
    /**
    * The list of Automated Reasoning policy ARNs to include in the guardrail configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#policies BedrockGuardrail#policies}
    */
    readonly policies?: string[];
}
export declare function bedrockGuardrailAutomatedReasoningPolicyConfigToTerraform(struct?: BedrockGuardrailAutomatedReasoningPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailAutomatedReasoningPolicyConfigToHclTerraform(struct?: BedrockGuardrailAutomatedReasoningPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailAutomatedReasoningPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailAutomatedReasoningPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailAutomatedReasoningPolicyConfig | cdktn.IResolvable | undefined);
    private _confidenceThreshold?;
    get confidenceThreshold(): number;
    set confidenceThreshold(value: number);
    resetConfidenceThreshold(): void;
    get confidenceThresholdInput(): number | undefined;
    private _policies?;
    get policies(): string[];
    set policies(value: string[]);
    resetPolicies(): void;
    get policiesInput(): string[] | undefined;
}
export interface BedrockGuardrailContentPolicyConfigContentFiltersTierConfig {
    /**
    * Tier name for tier configuration in content filters policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#tier_name BedrockGuardrail#tier_name}
    */
    readonly tierName?: string;
}
export declare function bedrockGuardrailContentPolicyConfigContentFiltersTierConfigToTerraform(struct?: BedrockGuardrailContentPolicyConfigContentFiltersTierConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContentPolicyConfigContentFiltersTierConfigToHclTerraform(struct?: BedrockGuardrailContentPolicyConfigContentFiltersTierConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContentPolicyConfigContentFiltersTierConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailContentPolicyConfigContentFiltersTierConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContentPolicyConfigContentFiltersTierConfig | cdktn.IResolvable | undefined);
    private _tierName?;
    get tierName(): string;
    set tierName(value: string);
    resetTierName(): void;
    get tierNameInput(): string | undefined;
}
export interface BedrockGuardrailContentPolicyConfigFiltersConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * List of modalities
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_modalities BedrockGuardrail#input_modalities}
    */
    readonly inputModalities?: string[];
    /**
    * Strength for filters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_strength BedrockGuardrail#input_strength}
    */
    readonly inputStrength?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * List of modalities
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_modalities BedrockGuardrail#output_modalities}
    */
    readonly outputModalities?: string[];
    /**
    * Strength for filters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_strength BedrockGuardrail#output_strength}
    */
    readonly outputStrength?: string;
    /**
    * Type of filter in content policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type?: string;
}
export declare function bedrockGuardrailContentPolicyConfigFiltersConfigToTerraform(struct?: BedrockGuardrailContentPolicyConfigFiltersConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContentPolicyConfigFiltersConfigToHclTerraform(struct?: BedrockGuardrailContentPolicyConfigFiltersConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContentPolicyConfigFiltersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailContentPolicyConfigFiltersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContentPolicyConfigFiltersConfig | cdktn.IResolvable | undefined);
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _inputModalities?;
    get inputModalities(): string[];
    set inputModalities(value: string[]);
    resetInputModalities(): void;
    get inputModalitiesInput(): string[] | undefined;
    private _inputStrength?;
    get inputStrength(): string;
    set inputStrength(value: string);
    resetInputStrength(): void;
    get inputStrengthInput(): string | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outputModalities?;
    get outputModalities(): string[];
    set outputModalities(value: string[]);
    resetOutputModalities(): void;
    get outputModalitiesInput(): string[] | undefined;
    private _outputStrength?;
    get outputStrength(): string;
    set outputStrength(value: string);
    resetOutputStrength(): void;
    get outputStrengthInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailContentPolicyConfigFiltersConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailContentPolicyConfigFiltersConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailContentPolicyConfigFiltersConfigOutputReference;
}
export interface BedrockGuardrailContentPolicyConfig {
    /**
    * Guardrail tier config for content policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#content_filters_tier_config BedrockGuardrail#content_filters_tier_config}
    */
    readonly contentFiltersTierConfig?: BedrockGuardrailContentPolicyConfigContentFiltersTierConfig;
    /**
    * List of content filter configs in content policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#filters_config BedrockGuardrail#filters_config}
    */
    readonly filtersConfig?: BedrockGuardrailContentPolicyConfigFiltersConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailContentPolicyConfigToTerraform(struct?: BedrockGuardrailContentPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContentPolicyConfigToHclTerraform(struct?: BedrockGuardrailContentPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContentPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailContentPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContentPolicyConfig | cdktn.IResolvable | undefined);
    private _contentFiltersTierConfig;
    get contentFiltersTierConfig(): BedrockGuardrailContentPolicyConfigContentFiltersTierConfigOutputReference;
    putContentFiltersTierConfig(value: BedrockGuardrailContentPolicyConfigContentFiltersTierConfig): void;
    resetContentFiltersTierConfig(): void;
    get contentFiltersTierConfigInput(): cdktn.IResolvable | BedrockGuardrailContentPolicyConfigContentFiltersTierConfig | undefined;
    private _filtersConfig;
    get filtersConfig(): BedrockGuardrailContentPolicyConfigFiltersConfigList;
    putFiltersConfig(value: BedrockGuardrailContentPolicyConfigFiltersConfig[] | cdktn.IResolvable): void;
    resetFiltersConfig(): void;
    get filtersConfigInput(): cdktn.IResolvable | BedrockGuardrailContentPolicyConfigFiltersConfig[] | undefined;
}
export interface BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#action BedrockGuardrail#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#enabled BedrockGuardrail#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The threshold for this filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#threshold BedrockGuardrail#threshold}
    */
    readonly threshold?: number;
    /**
    * Type of contextual grounding filter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type?: string;
}
export declare function bedrockGuardrailContextualGroundingPolicyConfigFiltersConfigToTerraform(struct?: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContextualGroundingPolicyConfigFiltersConfigToHclTerraform(struct?: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContextualGroundingPolicyConfigFiltersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailContextualGroundingPolicyConfigFiltersConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailContextualGroundingPolicyConfigFiltersConfigOutputReference;
}
export interface BedrockGuardrailContextualGroundingPolicyConfig {
    /**
    * List of contextual grounding filter configs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#filters_config BedrockGuardrail#filters_config}
    */
    readonly filtersConfig?: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailContextualGroundingPolicyConfigToTerraform(struct?: BedrockGuardrailContextualGroundingPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContextualGroundingPolicyConfigToHclTerraform(struct?: BedrockGuardrailContextualGroundingPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContextualGroundingPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailContextualGroundingPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContextualGroundingPolicyConfig | cdktn.IResolvable | undefined);
    private _filtersConfig;
    get filtersConfig(): BedrockGuardrailContextualGroundingPolicyConfigFiltersConfigList;
    putFiltersConfig(value: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig[] | cdktn.IResolvable): void;
    resetFiltersConfig(): void;
    get filtersConfigInput(): cdktn.IResolvable | BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig[] | undefined;
}
export interface BedrockGuardrailCrossRegionConfig {
    /**
    * The Amazon Resource Name (ARN) of the guardrail profile
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#guardrail_profile_arn BedrockGuardrail#guardrail_profile_arn}
    */
    readonly guardrailProfileArn?: string;
}
export declare function bedrockGuardrailCrossRegionConfigToTerraform(struct?: BedrockGuardrailCrossRegionConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailCrossRegionConfigToHclTerraform(struct?: BedrockGuardrailCrossRegionConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailCrossRegionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailCrossRegionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailCrossRegionConfig | cdktn.IResolvable | undefined);
    private _guardrailProfileArn?;
    get guardrailProfileArn(): string;
    set guardrailProfileArn(value: string);
    resetGuardrailProfileArn(): void;
    get guardrailProfileArnInput(): string | undefined;
}
export interface BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig {
    /**
    * Options for sensitive information action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#action BedrockGuardrail#action}
    */
    readonly action?: string;
    /**
    * Options for sensitive information action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Options for sensitive information action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * The currently supported PII entities
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type?: string;
}
export declare function bedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigToTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigToHclTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigOutputReference;
}
export interface BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig {
    /**
    * Options for sensitive information action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#action BedrockGuardrail#action}
    */
    readonly action?: string;
    /**
    * The regex description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#description BedrockGuardrail#description}
    */
    readonly description?: string;
    /**
    * Options for sensitive information action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * The regex name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#name BedrockGuardrail#name}
    */
    readonly name?: string;
    /**
    * Options for sensitive information action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * The regex pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#pattern BedrockGuardrail#pattern}
    */
    readonly pattern?: string;
}
export declare function bedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigToTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigToHclTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
}
export declare class BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigOutputReference;
}
export interface BedrockGuardrailSensitiveInformationPolicyConfig {
    /**
    * List of entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#pii_entities_config BedrockGuardrail#pii_entities_config}
    */
    readonly piiEntitiesConfig?: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig[] | cdktn.IResolvable;
    /**
    * List of regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#regexes_config BedrockGuardrail#regexes_config}
    */
    readonly regexesConfig?: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailSensitiveInformationPolicyConfigToTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailSensitiveInformationPolicyConfigToHclTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailSensitiveInformationPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailSensitiveInformationPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailSensitiveInformationPolicyConfig | cdktn.IResolvable | undefined);
    private _piiEntitiesConfig;
    get piiEntitiesConfig(): BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigList;
    putPiiEntitiesConfig(value: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig[] | cdktn.IResolvable): void;
    resetPiiEntitiesConfig(): void;
    get piiEntitiesConfigInput(): cdktn.IResolvable | BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig[] | undefined;
    private _regexesConfig;
    get regexesConfig(): BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigList;
    putRegexesConfig(value: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig[] | cdktn.IResolvable): void;
    resetRegexesConfig(): void;
    get regexesConfigInput(): cdktn.IResolvable | BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig[] | undefined;
}
export interface BedrockGuardrailTags {
    /**
    * Tag Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#key BedrockGuardrail#key}
    */
    readonly key?: string;
    /**
    * Tag Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#value BedrockGuardrail#value}
    */
    readonly value?: string;
}
export declare function bedrockGuardrailTagsToTerraform(struct?: BedrockGuardrailTags | cdktn.IResolvable): any;
export declare function bedrockGuardrailTagsToHclTerraform(struct?: BedrockGuardrailTags | cdktn.IResolvable): any;
export declare class BedrockGuardrailTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockGuardrailTagsList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailTagsOutputReference;
}
export interface BedrockGuardrailTopicPolicyConfigTopicsConfig {
    /**
    * Definition of topic in topic policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#definition BedrockGuardrail#definition}
    */
    readonly definition?: string;
    /**
    * List of text examples
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#examples BedrockGuardrail#examples}
    */
    readonly examples?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of topic in topic policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#name BedrockGuardrail#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Type of topic in a policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type?: string;
}
export declare function bedrockGuardrailTopicPolicyConfigTopicsConfigToTerraform(struct?: BedrockGuardrailTopicPolicyConfigTopicsConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailTopicPolicyConfigTopicsConfigToHclTerraform(struct?: BedrockGuardrailTopicPolicyConfigTopicsConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailTopicPolicyConfigTopicsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailTopicPolicyConfigTopicsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailTopicPolicyConfigTopicsConfig | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    resetDefinition(): void;
    get definitionInput(): string | undefined;
    private _examples?;
    get examples(): string[];
    set examples(value: string[]);
    resetExamples(): void;
    get examplesInput(): string[] | undefined;
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailTopicPolicyConfigTopicsConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailTopicPolicyConfigTopicsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailTopicPolicyConfigTopicsConfigOutputReference;
}
export interface BedrockGuardrailTopicPolicyConfigTopicsTierConfig {
    /**
    * Tier name for tier configuration in topic policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#tier_name BedrockGuardrail#tier_name}
    */
    readonly tierName?: string;
}
export declare function bedrockGuardrailTopicPolicyConfigTopicsTierConfigToTerraform(struct?: BedrockGuardrailTopicPolicyConfigTopicsTierConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailTopicPolicyConfigTopicsTierConfigToHclTerraform(struct?: BedrockGuardrailTopicPolicyConfigTopicsTierConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailTopicPolicyConfigTopicsTierConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailTopicPolicyConfigTopicsTierConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailTopicPolicyConfigTopicsTierConfig | cdktn.IResolvable | undefined);
    private _tierName?;
    get tierName(): string;
    set tierName(value: string);
    resetTierName(): void;
    get tierNameInput(): string | undefined;
}
export interface BedrockGuardrailTopicPolicyConfig {
    /**
    * List of topic configs in topic policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#topics_config BedrockGuardrail#topics_config}
    */
    readonly topicsConfig?: BedrockGuardrailTopicPolicyConfigTopicsConfig[] | cdktn.IResolvable;
    /**
    * Guardrail tier config for topic policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#topics_tier_config BedrockGuardrail#topics_tier_config}
    */
    readonly topicsTierConfig?: BedrockGuardrailTopicPolicyConfigTopicsTierConfig;
}
export declare function bedrockGuardrailTopicPolicyConfigToTerraform(struct?: BedrockGuardrailTopicPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailTopicPolicyConfigToHclTerraform(struct?: BedrockGuardrailTopicPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailTopicPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailTopicPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailTopicPolicyConfig | cdktn.IResolvable | undefined);
    private _topicsConfig;
    get topicsConfig(): BedrockGuardrailTopicPolicyConfigTopicsConfigList;
    putTopicsConfig(value: BedrockGuardrailTopicPolicyConfigTopicsConfig[] | cdktn.IResolvable): void;
    resetTopicsConfig(): void;
    get topicsConfigInput(): cdktn.IResolvable | BedrockGuardrailTopicPolicyConfigTopicsConfig[] | undefined;
    private _topicsTierConfig;
    get topicsTierConfig(): BedrockGuardrailTopicPolicyConfigTopicsTierConfigOutputReference;
    putTopicsTierConfig(value: BedrockGuardrailTopicPolicyConfigTopicsTierConfig): void;
    resetTopicsTierConfig(): void;
    get topicsTierConfigInput(): cdktn.IResolvable | BedrockGuardrailTopicPolicyConfigTopicsTierConfig | undefined;
}
export interface BedrockGuardrailWordPolicyConfigManagedWordListsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Options for managed words.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type?: string;
}
export declare function bedrockGuardrailWordPolicyConfigManagedWordListsConfigToTerraform(struct?: BedrockGuardrailWordPolicyConfigManagedWordListsConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailWordPolicyConfigManagedWordListsConfigToHclTerraform(struct?: BedrockGuardrailWordPolicyConfigManagedWordListsConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailWordPolicyConfigManagedWordListsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailWordPolicyConfigManagedWordListsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailWordPolicyConfigManagedWordListsConfig | cdktn.IResolvable | undefined);
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailWordPolicyConfigManagedWordListsConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailWordPolicyConfigManagedWordListsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailWordPolicyConfigManagedWordListsConfigOutputReference;
}
export interface BedrockGuardrailWordPolicyConfigWordsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * The custom word text.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#text BedrockGuardrail#text}
    */
    readonly text?: string;
}
export declare function bedrockGuardrailWordPolicyConfigWordsConfigToTerraform(struct?: BedrockGuardrailWordPolicyConfigWordsConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailWordPolicyConfigWordsConfigToHclTerraform(struct?: BedrockGuardrailWordPolicyConfigWordsConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailWordPolicyConfigWordsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailWordPolicyConfigWordsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailWordPolicyConfigWordsConfig | cdktn.IResolvable | undefined);
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
}
export declare class BedrockGuardrailWordPolicyConfigWordsConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailWordPolicyConfigWordsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailWordPolicyConfigWordsConfigOutputReference;
}
export interface BedrockGuardrailWordPolicyConfig {
    /**
    * A config for the list of managed words.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#managed_word_lists_config BedrockGuardrail#managed_word_lists_config}
    */
    readonly managedWordListsConfig?: BedrockGuardrailWordPolicyConfigManagedWordListsConfig[] | cdktn.IResolvable;
    /**
    * List of custom word configs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#words_config BedrockGuardrail#words_config}
    */
    readonly wordsConfig?: BedrockGuardrailWordPolicyConfigWordsConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailWordPolicyConfigToTerraform(struct?: BedrockGuardrailWordPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailWordPolicyConfigToHclTerraform(struct?: BedrockGuardrailWordPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailWordPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailWordPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailWordPolicyConfig | cdktn.IResolvable | undefined);
    private _managedWordListsConfig;
    get managedWordListsConfig(): BedrockGuardrailWordPolicyConfigManagedWordListsConfigList;
    putManagedWordListsConfig(value: BedrockGuardrailWordPolicyConfigManagedWordListsConfig[] | cdktn.IResolvable): void;
    resetManagedWordListsConfig(): void;
    get managedWordListsConfigInput(): cdktn.IResolvable | BedrockGuardrailWordPolicyConfigManagedWordListsConfig[] | undefined;
    private _wordsConfig;
    get wordsConfig(): BedrockGuardrailWordPolicyConfigWordsConfigList;
    putWordsConfig(value: BedrockGuardrailWordPolicyConfigWordsConfig[] | cdktn.IResolvable): void;
    resetWordsConfig(): void;
    get wordsConfigInput(): cdktn.IResolvable | BedrockGuardrailWordPolicyConfigWordsConfig[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail awscc_bedrock_guardrail}
*/
export declare class BedrockGuardrail extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_guardrail";
    /**
    * Generates CDKTN code for importing a BedrockGuardrail resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockGuardrail to import
    * @param importFromId The id of the existing BedrockGuardrail that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockGuardrail to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_guardrail awscc_bedrock_guardrail} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockGuardrailConfig
    */
    constructor(scope: Construct, id: string, config: BedrockGuardrailConfig);
    private _automatedReasoningPolicyConfig;
    get automatedReasoningPolicyConfig(): BedrockGuardrailAutomatedReasoningPolicyConfigOutputReference;
    putAutomatedReasoningPolicyConfig(value: BedrockGuardrailAutomatedReasoningPolicyConfig): void;
    resetAutomatedReasoningPolicyConfig(): void;
    get automatedReasoningPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailAutomatedReasoningPolicyConfig | undefined;
    private _blockedInputMessaging?;
    get blockedInputMessaging(): string;
    set blockedInputMessaging(value: string);
    get blockedInputMessagingInput(): string | undefined;
    private _blockedOutputsMessaging?;
    get blockedOutputsMessaging(): string;
    set blockedOutputsMessaging(value: string);
    get blockedOutputsMessagingInput(): string | undefined;
    private _contentPolicyConfig;
    get contentPolicyConfig(): BedrockGuardrailContentPolicyConfigOutputReference;
    putContentPolicyConfig(value: BedrockGuardrailContentPolicyConfig): void;
    resetContentPolicyConfig(): void;
    get contentPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailContentPolicyConfig | undefined;
    private _contextualGroundingPolicyConfig;
    get contextualGroundingPolicyConfig(): BedrockGuardrailContextualGroundingPolicyConfigOutputReference;
    putContextualGroundingPolicyConfig(value: BedrockGuardrailContextualGroundingPolicyConfig): void;
    resetContextualGroundingPolicyConfig(): void;
    get contextualGroundingPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailContextualGroundingPolicyConfig | undefined;
    get createdAt(): string;
    private _crossRegionConfig;
    get crossRegionConfig(): BedrockGuardrailCrossRegionConfigOutputReference;
    putCrossRegionConfig(value: BedrockGuardrailCrossRegionConfig): void;
    resetCrossRegionConfig(): void;
    get crossRegionConfigInput(): cdktn.IResolvable | BedrockGuardrailCrossRegionConfig | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get failureRecommendations(): string[];
    get guardrailArn(): string;
    get guardrailId(): string;
    get id(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sensitiveInformationPolicyConfig;
    get sensitiveInformationPolicyConfig(): BedrockGuardrailSensitiveInformationPolicyConfigOutputReference;
    putSensitiveInformationPolicyConfig(value: BedrockGuardrailSensitiveInformationPolicyConfig): void;
    resetSensitiveInformationPolicyConfig(): void;
    get sensitiveInformationPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailSensitiveInformationPolicyConfig | undefined;
    get status(): string;
    get statusReasons(): string[];
    private _tags;
    get tags(): BedrockGuardrailTagsList;
    putTags(value: BedrockGuardrailTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockGuardrailTags[] | undefined;
    private _topicPolicyConfig;
    get topicPolicyConfig(): BedrockGuardrailTopicPolicyConfigOutputReference;
    putTopicPolicyConfig(value: BedrockGuardrailTopicPolicyConfig): void;
    resetTopicPolicyConfig(): void;
    get topicPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailTopicPolicyConfig | undefined;
    get updatedAt(): string;
    get version(): string;
    private _wordPolicyConfig;
    get wordPolicyConfig(): BedrockGuardrailWordPolicyConfigOutputReference;
    putWordPolicyConfig(value: BedrockGuardrailWordPolicyConfig): void;
    resetWordPolicyConfig(): void;
    get wordPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailWordPolicyConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
