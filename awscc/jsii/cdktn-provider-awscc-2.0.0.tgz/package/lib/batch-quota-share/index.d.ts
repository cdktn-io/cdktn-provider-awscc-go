/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BatchQuotaShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list that specifies the quantity and type of compute capacity allocated to the quota share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#capacity_limits BatchQuotaShare#capacity_limits}
    */
    readonly capacityLimits: BatchQuotaShareCapacityLimits[] | cdktn.IResolvable;
    /**
    * The AWS Batch job queue associated with the quota share. This can be the job queue name or ARN. A job queue must be in the `VALID` state before you can associate it with a quota share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#job_queue BatchQuotaShare#job_queue}
    */
    readonly jobQueue: string;
    /**
    * Specifies the preemption behavior for jobs in a quota share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#preemption_configuration BatchQuotaShare#preemption_configuration}
    */
    readonly preemptionConfiguration: BatchQuotaSharePreemptionConfiguration;
    /**
    * The name of the quota share. It can be up to 128 characters long. It can contain uppercase and lowercase letters, numbers, hyphens (-), and underscores (_).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#quota_share_name BatchQuotaShare#quota_share_name}
    */
    readonly quotaShareName: string;
    /**
    * Specifies whether a quota share reserves, lends, or both lends and borrows idle compute capacity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#resource_sharing_configuration BatchQuotaShare#resource_sharing_configuration}
    */
    readonly resourceSharingConfiguration: BatchQuotaShareResourceSharingConfiguration;
    /**
    * The state of the quota share. If the quota share is `ENABLED`, it is able to accept jobs. If the quota share is `DISABLED`, new jobs won't be accepted but jobs already submitted can finish. The default state is `ENABLED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#state BatchQuotaShare#state}
    */
    readonly state?: string;
    /**
    * The tags that you apply to the quota share to help you categorize and organize your resources. Each tag consists of a key and an optional value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#tags BatchQuotaShare#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BatchQuotaShareCapacityLimits {
    /**
    * The unit of compute capacity for the capacityLimit. For example, `ml.m5.large`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#capacity_unit BatchQuotaShare#capacity_unit}
    */
    readonly capacityUnit: string;
    /**
    * The maximum capacity available for the quota share. This value represents the maximum quantity of a resource that can be allocated to jobs in the quota share without borrowing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#max_capacity BatchQuotaShare#max_capacity}
    */
    readonly maxCapacity: number;
}
export declare function batchQuotaShareCapacityLimitsToTerraform(struct?: BatchQuotaShareCapacityLimits | cdktn.IResolvable): any;
export declare function batchQuotaShareCapacityLimitsToHclTerraform(struct?: BatchQuotaShareCapacityLimits | cdktn.IResolvable): any;
export declare class BatchQuotaShareCapacityLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchQuotaShareCapacityLimits | cdktn.IResolvable | undefined;
    set internalValue(value: BatchQuotaShareCapacityLimits | cdktn.IResolvable | undefined);
    private _capacityUnit?;
    get capacityUnit(): string;
    set capacityUnit(value: string);
    get capacityUnitInput(): string | undefined;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    get maxCapacityInput(): number | undefined;
}
export declare class BatchQuotaShareCapacityLimitsList extends cdktn.ComplexList {
    internalValue?: BatchQuotaShareCapacityLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchQuotaShareCapacityLimitsOutputReference;
}
export interface BatchQuotaSharePreemptionConfiguration {
    /**
    * Specifies whether jobs within a quota share can be preempted by another, higher priority job in the same quota share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#in_share_preemption BatchQuotaShare#in_share_preemption}
    */
    readonly inSharePreemption: string;
}
export declare function batchQuotaSharePreemptionConfigurationToTerraform(struct?: BatchQuotaSharePreemptionConfiguration | cdktn.IResolvable): any;
export declare function batchQuotaSharePreemptionConfigurationToHclTerraform(struct?: BatchQuotaSharePreemptionConfiguration | cdktn.IResolvable): any;
export declare class BatchQuotaSharePreemptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchQuotaSharePreemptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchQuotaSharePreemptionConfiguration | cdktn.IResolvable | undefined);
    private _inSharePreemption?;
    get inSharePreemption(): string;
    set inSharePreemption(value: string);
    get inSharePreemptionInput(): string | undefined;
}
export interface BatchQuotaShareResourceSharingConfiguration {
    /**
    * The maximum percentage of additional capacity that the quota share can borrow from other shares. `BorrowLimit` can only be applied to quota shares with a strategy of `LEND_AND_BORROW`. This value is expressed as a percentage of the quota share's configured CapacityLimits. The `BorrowLimit` is applied uniformly across all capacity units. For example, if the `BorrowLimit` is 200, the quota share can borrow up to 200% of its configured `maxCapacity` for each capacity unit. The default `BorrowLimit` is -1, which indicates unlimited borrowing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#borrow_limit BatchQuotaShare#borrow_limit}
    */
    readonly borrowLimit?: number;
    /**
    * The resource sharing strategy for the quota share. The `RESERVE` strategy allows a quota share to reserve idle capacity for itself. `LEND` configures the share to lend its idle capacity to another share in need of capacity. The `LEND_AND_BORROW` strategy configures the share to borrow idle capacity from an underutilized share, as well as lend to another share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#strategy BatchQuotaShare#strategy}
    */
    readonly strategy: string;
}
export declare function batchQuotaShareResourceSharingConfigurationToTerraform(struct?: BatchQuotaShareResourceSharingConfiguration | cdktn.IResolvable): any;
export declare function batchQuotaShareResourceSharingConfigurationToHclTerraform(struct?: BatchQuotaShareResourceSharingConfiguration | cdktn.IResolvable): any;
export declare class BatchQuotaShareResourceSharingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchQuotaShareResourceSharingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchQuotaShareResourceSharingConfiguration | cdktn.IResolvable | undefined);
    private _borrowLimit?;
    get borrowLimit(): number;
    set borrowLimit(value: number);
    resetBorrowLimit(): void;
    get borrowLimitInput(): number | undefined;
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    get strategyInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share awscc_batch_quota_share}
*/
export declare class BatchQuotaShare extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_batch_quota_share";
    /**
    * Generates CDKTN code for importing a BatchQuotaShare resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BatchQuotaShare to import
    * @param importFromId The id of the existing BatchQuotaShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BatchQuotaShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_quota_share awscc_batch_quota_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BatchQuotaShareConfig
    */
    constructor(scope: Construct, id: string, config: BatchQuotaShareConfig);
    private _capacityLimits;
    get capacityLimits(): BatchQuotaShareCapacityLimitsList;
    putCapacityLimits(value: BatchQuotaShareCapacityLimits[] | cdktn.IResolvable): void;
    get capacityLimitsInput(): cdktn.IResolvable | BatchQuotaShareCapacityLimits[] | undefined;
    get id(): string;
    private _jobQueue?;
    get jobQueue(): string;
    set jobQueue(value: string);
    get jobQueueInput(): string | undefined;
    private _preemptionConfiguration;
    get preemptionConfiguration(): BatchQuotaSharePreemptionConfigurationOutputReference;
    putPreemptionConfiguration(value: BatchQuotaSharePreemptionConfiguration): void;
    get preemptionConfigurationInput(): cdktn.IResolvable | BatchQuotaSharePreemptionConfiguration | undefined;
    get quotaShareArn(): string;
    private _quotaShareName?;
    get quotaShareName(): string;
    set quotaShareName(value: string);
    get quotaShareNameInput(): string | undefined;
    private _resourceSharingConfiguration;
    get resourceSharingConfiguration(): BatchQuotaShareResourceSharingConfigurationOutputReference;
    putResourceSharingConfiguration(value: BatchQuotaShareResourceSharingConfiguration): void;
    get resourceSharingConfigurationInput(): cdktn.IResolvable | BatchQuotaShareResourceSharingConfiguration | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
