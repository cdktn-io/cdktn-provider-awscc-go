/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#domain_name CustomerprofilesIntegration#domain_name}
    */
    readonly domainName: string;
    /**
    * A list of unique names for active event triggers associated with the integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#event_trigger_names CustomerprofilesIntegration#event_trigger_names}
    */
    readonly eventTriggerNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#flow_definition CustomerprofilesIntegration#flow_definition}
    */
    readonly flowDefinition?: CustomerprofilesIntegrationFlowDefinition;
    /**
    * The name of the ObjectType defined for the 3rd party data in Profile Service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#object_type_name CustomerprofilesIntegration#object_type_name}
    */
    readonly objectTypeName?: string;
    /**
    * The mapping between 3rd party event types and ObjectType names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#object_type_names CustomerprofilesIntegration#object_type_names}
    */
    readonly objectTypeNames?: CustomerprofilesIntegrationObjectTypeNames[] | cdktn.IResolvable;
    /**
    * Scope of the integration, such as 'PROFILE' or 'DOMAIN'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#scope CustomerprofilesIntegration#scope}
    */
    readonly scope?: string;
    /**
    * The tags (keys and values) associated with the integration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#tags CustomerprofilesIntegration#tags}
    */
    readonly tags?: CustomerprofilesIntegrationTags[] | cdktn.IResolvable;
    /**
    * The URI of the S3 bucket or any other type of data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#uri CustomerprofilesIntegration#uri}
    */
    readonly uri?: string;
}
export interface CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#datetime_type_field_name CustomerprofilesIntegration#datetime_type_field_name}
    */
    readonly datetimeTypeFieldName?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfigToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfig | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfigToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfig | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfig | cdktn.IResolvable | undefined);
    private _datetimeTypeFieldName?;
    get datetimeTypeFieldName(): string;
    set datetimeTypeFieldName(value: string);
    resetDatetimeTypeFieldName(): void;
    get datetimeTypeFieldNameInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#object CustomerprofilesIntegration#object}
    */
    readonly object?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketoToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketo | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketoToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketo | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketo | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketo | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#bucket_name CustomerprofilesIntegration#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#bucket_prefix CustomerprofilesIntegration#bucket_prefix}
    */
    readonly bucketPrefix?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3ToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3 | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3ToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3 | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3 | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3 | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforce {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#enable_dynamic_field_update CustomerprofilesIntegration#enable_dynamic_field_update}
    */
    readonly enableDynamicFieldUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#include_deleted_records CustomerprofilesIntegration#include_deleted_records}
    */
    readonly includeDeletedRecords?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#object CustomerprofilesIntegration#object}
    */
    readonly object?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforceToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforce | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforceToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforce | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforce | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforce | cdktn.IResolvable | undefined);
    private _enableDynamicFieldUpdate?;
    get enableDynamicFieldUpdate(): boolean | cdktn.IResolvable;
    set enableDynamicFieldUpdate(value: boolean | cdktn.IResolvable);
    resetEnableDynamicFieldUpdate(): void;
    get enableDynamicFieldUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _includeDeletedRecords?;
    get includeDeletedRecords(): boolean | cdktn.IResolvable;
    set includeDeletedRecords(value: boolean | cdktn.IResolvable);
    resetIncludeDeletedRecords(): void;
    get includeDeletedRecordsInput(): boolean | cdktn.IResolvable | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#object CustomerprofilesIntegration#object}
    */
    readonly object?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNowToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNow | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNowToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNow | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNow | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNow | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendesk {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#object CustomerprofilesIntegration#object}
    */
    readonly object?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendeskToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendesk | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendeskToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendesk | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendeskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendesk | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendesk | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#marketo CustomerprofilesIntegration#marketo}
    */
    readonly marketo?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketo;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#s3 CustomerprofilesIntegration#s3}
    */
    readonly s3?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#salesforce CustomerprofilesIntegration#salesforce}
    */
    readonly salesforce?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforce;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#service_now CustomerprofilesIntegration#service_now}
    */
    readonly serviceNow?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#zendesk CustomerprofilesIntegration#zendesk}
    */
    readonly zendesk?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendesk;
}
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorProperties | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorProperties | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorProperties | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorProperties | cdktn.IResolvable | undefined);
    private _marketo;
    get marketo(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketoOutputReference;
    putMarketo(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketo): void;
    resetMarketo(): void;
    get marketoInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesMarketo | undefined;
    private _s3;
    get s3(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3OutputReference;
    putS3(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesS3 | undefined;
    private _salesforce;
    get salesforce(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforceOutputReference;
    putSalesforce(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforce): void;
    resetSalesforce(): void;
    get salesforceInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesSalesforce | undefined;
    private _serviceNow;
    get serviceNow(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNowOutputReference;
    putServiceNow(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNow): void;
    resetServiceNow(): void;
    get serviceNowInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesServiceNow | undefined;
    private _zendesk;
    get zendesk(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendeskOutputReference;
    putZendesk(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendesk): void;
    resetZendesk(): void;
    get zendeskInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesZendesk | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionSourceFlowConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#connector_profile_name CustomerprofilesIntegration#connector_profile_name}
    */
    readonly connectorProfileName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#connector_type CustomerprofilesIntegration#connector_type}
    */
    readonly connectorType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#incremental_pull_config CustomerprofilesIntegration#incremental_pull_config}
    */
    readonly incrementalPullConfig?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#source_connector_properties CustomerprofilesIntegration#source_connector_properties}
    */
    readonly sourceConnectorProperties?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorProperties;
}
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfig | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionSourceFlowConfigToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfig | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfig | cdktn.IResolvable | undefined);
    private _connectorProfileName?;
    get connectorProfileName(): string;
    set connectorProfileName(value: string);
    resetConnectorProfileName(): void;
    get connectorProfileNameInput(): string | undefined;
    private _connectorType?;
    get connectorType(): string;
    set connectorType(value: string);
    resetConnectorType(): void;
    get connectorTypeInput(): string | undefined;
    private _incrementalPullConfig;
    get incrementalPullConfig(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfigOutputReference;
    putIncrementalPullConfig(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfig): void;
    resetIncrementalPullConfig(): void;
    get incrementalPullConfigInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigIncrementalPullConfig | undefined;
    private _sourceConnectorProperties;
    get sourceConnectorProperties(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorPropertiesOutputReference;
    putSourceConnectorProperties(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorProperties): void;
    resetSourceConnectorProperties(): void;
    get sourceConnectorPropertiesInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigSourceConnectorProperties | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperator {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#marketo CustomerprofilesIntegration#marketo}
    */
    readonly marketo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#s3 CustomerprofilesIntegration#s3}
    */
    readonly s3?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#salesforce CustomerprofilesIntegration#salesforce}
    */
    readonly salesforce?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#service_now CustomerprofilesIntegration#service_now}
    */
    readonly serviceNow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#zendesk CustomerprofilesIntegration#zendesk}
    */
    readonly zendesk?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionTasksConnectorOperatorToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperator | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionTasksConnectorOperatorToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperator | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperatorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperator | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperator | cdktn.IResolvable | undefined);
    private _marketo?;
    get marketo(): string;
    set marketo(value: string);
    resetMarketo(): void;
    get marketoInput(): string | undefined;
    private _s3?;
    get s3(): string;
    set s3(value: string);
    resetS3(): void;
    get s3Input(): string | undefined;
    private _salesforce?;
    get salesforce(): string;
    set salesforce(value: string);
    resetSalesforce(): void;
    get salesforceInput(): string | undefined;
    private _serviceNow?;
    get serviceNow(): string;
    set serviceNow(value: string);
    resetServiceNow(): void;
    get serviceNowInput(): string | undefined;
    private _zendesk?;
    get zendesk(): string;
    set zendesk(value: string);
    resetZendesk(): void;
    get zendeskInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#operator_property_key CustomerprofilesIntegration#operator_property_key}
    */
    readonly operatorPropertyKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#property CustomerprofilesIntegration#property}
    */
    readonly property?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionTasksTaskPropertiesToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionTasksTaskPropertiesToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionTasksTaskPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties | cdktn.IResolvable | undefined);
    private _operatorPropertyKey?;
    get operatorPropertyKey(): string;
    set operatorPropertyKey(value: string);
    resetOperatorPropertyKey(): void;
    get operatorPropertyKeyInput(): string | undefined;
    private _property?;
    get property(): string;
    set property(value: string);
    resetProperty(): void;
    get propertyInput(): string | undefined;
}
export declare class CustomerprofilesIntegrationFlowDefinitionTasksTaskPropertiesList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesIntegrationFlowDefinitionTasksTaskPropertiesOutputReference;
}
export interface CustomerprofilesIntegrationFlowDefinitionTasks {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#connector_operator CustomerprofilesIntegration#connector_operator}
    */
    readonly connectorOperator?: CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperator;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#destination_field CustomerprofilesIntegration#destination_field}
    */
    readonly destinationField?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#source_fields CustomerprofilesIntegration#source_fields}
    */
    readonly sourceFields?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#task_properties CustomerprofilesIntegration#task_properties}
    */
    readonly taskProperties?: CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#task_type CustomerprofilesIntegration#task_type}
    */
    readonly taskType?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionTasksToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTasks | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionTasksToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTasks | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionTasksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionTasks | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionTasks | cdktn.IResolvable | undefined);
    private _connectorOperator;
    get connectorOperator(): CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperatorOutputReference;
    putConnectorOperator(value: CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperator): void;
    resetConnectorOperator(): void;
    get connectorOperatorInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionTasksConnectorOperator | undefined;
    private _destinationField?;
    get destinationField(): string;
    set destinationField(value: string);
    resetDestinationField(): void;
    get destinationFieldInput(): string | undefined;
    private _sourceFields?;
    get sourceFields(): string[];
    set sourceFields(value: string[]);
    resetSourceFields(): void;
    get sourceFieldsInput(): string[] | undefined;
    private _taskProperties;
    get taskProperties(): CustomerprofilesIntegrationFlowDefinitionTasksTaskPropertiesList;
    putTaskProperties(value: CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties[] | cdktn.IResolvable): void;
    resetTaskProperties(): void;
    get taskPropertiesInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionTasksTaskProperties[] | undefined;
    private _taskType?;
    get taskType(): string;
    set taskType(value: string);
    resetTaskType(): void;
    get taskTypeInput(): string | undefined;
}
export declare class CustomerprofilesIntegrationFlowDefinitionTasksList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesIntegrationFlowDefinitionTasks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesIntegrationFlowDefinitionTasksOutputReference;
}
export interface CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduled {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#data_pull_mode CustomerprofilesIntegration#data_pull_mode}
    */
    readonly dataPullMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#first_execution_from CustomerprofilesIntegration#first_execution_from}
    */
    readonly firstExecutionFrom?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#schedule_end_time CustomerprofilesIntegration#schedule_end_time}
    */
    readonly scheduleEndTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#schedule_expression CustomerprofilesIntegration#schedule_expression}
    */
    readonly scheduleExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#schedule_offset CustomerprofilesIntegration#schedule_offset}
    */
    readonly scheduleOffset?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#schedule_start_time CustomerprofilesIntegration#schedule_start_time}
    */
    readonly scheduleStartTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#timezone CustomerprofilesIntegration#timezone}
    */
    readonly timezone?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduledToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduled | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduledToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduled | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduledOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduled | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduled | cdktn.IResolvable | undefined);
    private _dataPullMode?;
    get dataPullMode(): string;
    set dataPullMode(value: string);
    resetDataPullMode(): void;
    get dataPullModeInput(): string | undefined;
    private _firstExecutionFrom?;
    get firstExecutionFrom(): number;
    set firstExecutionFrom(value: number);
    resetFirstExecutionFrom(): void;
    get firstExecutionFromInput(): number | undefined;
    private _scheduleEndTime?;
    get scheduleEndTime(): number;
    set scheduleEndTime(value: number);
    resetScheduleEndTime(): void;
    get scheduleEndTimeInput(): number | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    resetScheduleExpression(): void;
    get scheduleExpressionInput(): string | undefined;
    private _scheduleOffset?;
    get scheduleOffset(): number;
    set scheduleOffset(value: number);
    resetScheduleOffset(): void;
    get scheduleOffsetInput(): number | undefined;
    private _scheduleStartTime?;
    get scheduleStartTime(): number;
    set scheduleStartTime(value: number);
    resetScheduleStartTime(): void;
    get scheduleStartTimeInput(): number | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#scheduled CustomerprofilesIntegration#scheduled}
    */
    readonly scheduled?: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduled;
}
export declare function customerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerProperties | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerProperties | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerProperties | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerProperties | cdktn.IResolvable | undefined);
    private _scheduled;
    get scheduled(): CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduledOutputReference;
    putScheduled(value: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduled): void;
    resetScheduled(): void;
    get scheduledInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesScheduled | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinitionTriggerConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#trigger_properties CustomerprofilesIntegration#trigger_properties}
    */
    readonly triggerProperties?: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#trigger_type CustomerprofilesIntegration#trigger_type}
    */
    readonly triggerType?: string;
}
export declare function customerprofilesIntegrationFlowDefinitionTriggerConfigToTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTriggerConfig | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionTriggerConfigToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinitionTriggerConfig | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionTriggerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinitionTriggerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinitionTriggerConfig | cdktn.IResolvable | undefined);
    private _triggerProperties;
    get triggerProperties(): CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerPropertiesOutputReference;
    putTriggerProperties(value: CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerProperties): void;
    resetTriggerProperties(): void;
    get triggerPropertiesInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionTriggerConfigTriggerProperties | undefined;
    private _triggerType?;
    get triggerType(): string;
    set triggerType(value: string);
    resetTriggerType(): void;
    get triggerTypeInput(): string | undefined;
}
export interface CustomerprofilesIntegrationFlowDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#description CustomerprofilesIntegration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#flow_name CustomerprofilesIntegration#flow_name}
    */
    readonly flowName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#kms_arn CustomerprofilesIntegration#kms_arn}
    */
    readonly kmsArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#source_flow_config CustomerprofilesIntegration#source_flow_config}
    */
    readonly sourceFlowConfig?: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#tasks CustomerprofilesIntegration#tasks}
    */
    readonly tasks?: CustomerprofilesIntegrationFlowDefinitionTasks[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#trigger_config CustomerprofilesIntegration#trigger_config}
    */
    readonly triggerConfig?: CustomerprofilesIntegrationFlowDefinitionTriggerConfig;
}
export declare function customerprofilesIntegrationFlowDefinitionToTerraform(struct?: CustomerprofilesIntegrationFlowDefinition | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationFlowDefinitionToHclTerraform(struct?: CustomerprofilesIntegrationFlowDefinition | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationFlowDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesIntegrationFlowDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationFlowDefinition | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _flowName?;
    get flowName(): string;
    set flowName(value: string);
    resetFlowName(): void;
    get flowNameInput(): string | undefined;
    private _kmsArn?;
    get kmsArn(): string;
    set kmsArn(value: string);
    resetKmsArn(): void;
    get kmsArnInput(): string | undefined;
    private _sourceFlowConfig;
    get sourceFlowConfig(): CustomerprofilesIntegrationFlowDefinitionSourceFlowConfigOutputReference;
    putSourceFlowConfig(value: CustomerprofilesIntegrationFlowDefinitionSourceFlowConfig): void;
    resetSourceFlowConfig(): void;
    get sourceFlowConfigInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionSourceFlowConfig | undefined;
    private _tasks;
    get tasks(): CustomerprofilesIntegrationFlowDefinitionTasksList;
    putTasks(value: CustomerprofilesIntegrationFlowDefinitionTasks[] | cdktn.IResolvable): void;
    resetTasks(): void;
    get tasksInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionTasks[] | undefined;
    private _triggerConfig;
    get triggerConfig(): CustomerprofilesIntegrationFlowDefinitionTriggerConfigOutputReference;
    putTriggerConfig(value: CustomerprofilesIntegrationFlowDefinitionTriggerConfig): void;
    resetTriggerConfig(): void;
    get triggerConfigInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinitionTriggerConfig | undefined;
}
export interface CustomerprofilesIntegrationObjectTypeNames {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#key CustomerprofilesIntegration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#value CustomerprofilesIntegration#value}
    */
    readonly value?: string;
}
export declare function customerprofilesIntegrationObjectTypeNamesToTerraform(struct?: CustomerprofilesIntegrationObjectTypeNames | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationObjectTypeNamesToHclTerraform(struct?: CustomerprofilesIntegrationObjectTypeNames | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationObjectTypeNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesIntegrationObjectTypeNames | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationObjectTypeNames | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesIntegrationObjectTypeNamesList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesIntegrationObjectTypeNames[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesIntegrationObjectTypeNamesOutputReference;
}
export interface CustomerprofilesIntegrationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#key CustomerprofilesIntegration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#value CustomerprofilesIntegration#value}
    */
    readonly value?: string;
}
export declare function customerprofilesIntegrationTagsToTerraform(struct?: CustomerprofilesIntegrationTags | cdktn.IResolvable): any;
export declare function customerprofilesIntegrationTagsToHclTerraform(struct?: CustomerprofilesIntegrationTags | cdktn.IResolvable): any;
export declare class CustomerprofilesIntegrationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesIntegrationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesIntegrationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesIntegrationTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesIntegrationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesIntegrationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration awscc_customerprofiles_integration}
*/
export declare class CustomerprofilesIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_integration";
    /**
    * Generates CDKTN code for importing a CustomerprofilesIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesIntegration to import
    * @param importFromId The id of the existing CustomerprofilesIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/customerprofiles_integration awscc_customerprofiles_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesIntegrationConfig);
    get createdAt(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _eventTriggerNames?;
    get eventTriggerNames(): string[];
    set eventTriggerNames(value: string[]);
    resetEventTriggerNames(): void;
    get eventTriggerNamesInput(): string[] | undefined;
    private _flowDefinition;
    get flowDefinition(): CustomerprofilesIntegrationFlowDefinitionOutputReference;
    putFlowDefinition(value: CustomerprofilesIntegrationFlowDefinition): void;
    resetFlowDefinition(): void;
    get flowDefinitionInput(): cdktn.IResolvable | CustomerprofilesIntegrationFlowDefinition | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    private _objectTypeName?;
    get objectTypeName(): string;
    set objectTypeName(value: string);
    resetObjectTypeName(): void;
    get objectTypeNameInput(): string | undefined;
    private _objectTypeNames;
    get objectTypeNames(): CustomerprofilesIntegrationObjectTypeNamesList;
    putObjectTypeNames(value: CustomerprofilesIntegrationObjectTypeNames[] | cdktn.IResolvable): void;
    resetObjectTypeNames(): void;
    get objectTypeNamesInput(): cdktn.IResolvable | CustomerprofilesIntegrationObjectTypeNames[] | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _tags;
    get tags(): CustomerprofilesIntegrationTagsList;
    putTags(value: CustomerprofilesIntegrationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesIntegrationTags[] | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
