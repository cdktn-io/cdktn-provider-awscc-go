/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontPublicKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Configuration information about a public key that you can use with [signed URLs and signed cookies](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/PrivateContent.html), or with [field-level encryption](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/field-level-encryption.html).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_public_key#public_key_config CloudfrontPublicKey#public_key_config}
    */
    readonly publicKeyConfig: CloudfrontPublicKeyPublicKeyConfig;
}
export interface CloudfrontPublicKeyPublicKeyConfig {
    /**
    * A string included in the request to help make sure that the request can't be replayed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_public_key#caller_reference CloudfrontPublicKey#caller_reference}
    */
    readonly callerReference: string;
    /**
    * A comment to describe the public key. The comment cannot be longer than 128 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_public_key#comment CloudfrontPublicKey#comment}
    */
    readonly comment?: string;
    /**
    * The public key that you can use with [signed URLs and signed cookies](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/PrivateContent.html), or with [field-level encryption](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/field-level-encryption.html).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_public_key#encoded_key CloudfrontPublicKey#encoded_key}
    */
    readonly encodedKey: string;
    /**
    * A name to help identify the public key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_public_key#name CloudfrontPublicKey#name}
    */
    readonly name: string;
}
export declare function cloudfrontPublicKeyPublicKeyConfigToTerraform(struct?: CloudfrontPublicKeyPublicKeyConfig | cdktn.IResolvable): any;
export declare function cloudfrontPublicKeyPublicKeyConfigToHclTerraform(struct?: CloudfrontPublicKeyPublicKeyConfig | cdktn.IResolvable): any;
export declare class CloudfrontPublicKeyPublicKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontPublicKeyPublicKeyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontPublicKeyPublicKeyConfig | cdktn.IResolvable | undefined);
    private _callerReference?;
    get callerReference(): string;
    set callerReference(value: string);
    get callerReferenceInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _encodedKey?;
    get encodedKey(): string;
    set encodedKey(value: string);
    get encodedKeyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_public_key awscc_cloudfront_public_key}
*/
export declare class CloudfrontPublicKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_public_key";
    /**
    * Generates CDKTN code for importing a CloudfrontPublicKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontPublicKey to import
    * @param importFromId The id of the existing CloudfrontPublicKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_public_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontPublicKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_public_key awscc_cloudfront_public_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontPublicKeyConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontPublicKeyConfig);
    get createdTime(): string;
    get id(): string;
    private _publicKeyConfig;
    get publicKeyConfig(): CloudfrontPublicKeyPublicKeyConfigOutputReference;
    putPublicKeyConfig(value: CloudfrontPublicKeyPublicKeyConfig): void;
    get publicKeyConfigInput(): cdktn.IResolvable | CloudfrontPublicKeyPublicKeyConfig | undefined;
    get publicKeyId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
