/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockSessionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the KMS key to use to encrypt the session data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_session#encryption_key_arn BedrockSession#encryption_key_arn}
    */
    readonly encryptionKeyArn?: string;
    /**
    * A map of key-value pairs containing attributes to be persisted across the session.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_session#session_metadata BedrockSession#session_metadata}
    */
    readonly sessionMetadata?: {
        [key: string]: string;
    };
    /**
    * A list of tags associated with the session.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_session#tags BedrockSession#tags}
    */
    readonly tags?: BedrockSessionTags[] | cdktn.IResolvable;
}
export interface BedrockSessionTags {
    /**
    * The key of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_session#key BedrockSession#key}
    */
    readonly key?: string;
    /**
    * The value of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_session#value BedrockSession#value}
    */
    readonly value?: string;
}
export declare function bedrockSessionTagsToTerraform(struct?: BedrockSessionTags | cdktn.IResolvable): any;
export declare function bedrockSessionTagsToHclTerraform(struct?: BedrockSessionTags | cdktn.IResolvable): any;
export declare class BedrockSessionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockSessionTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockSessionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockSessionTagsList extends cdktn.ComplexList {
    internalValue?: BedrockSessionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockSessionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_session awscc_bedrock_session}
*/
export declare class BedrockSession extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_session";
    /**
    * Generates CDKTN code for importing a BedrockSession resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockSession to import
    * @param importFromId The id of the existing BedrockSession that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_session#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockSession to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrock_session awscc_bedrock_session} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockSessionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: BedrockSessionConfig);
    get createdAt(): string;
    private _encryptionKeyArn?;
    get encryptionKeyArn(): string;
    set encryptionKeyArn(value: string);
    resetEncryptionKeyArn(): void;
    get encryptionKeyArnInput(): string | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    get sessionArn(): string;
    get sessionId(): string;
    private _sessionMetadata?;
    get sessionMetadata(): {
        [key: string]: string;
    };
    set sessionMetadata(value: {
        [key: string]: string;
    });
    resetSessionMetadata(): void;
    get sessionMetadataInput(): {
        [key: string]: string;
    } | undefined;
    get sessionStatus(): string;
    private _tags;
    get tags(): BedrockSessionTagsList;
    putTags(value: BedrockSessionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockSessionTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
