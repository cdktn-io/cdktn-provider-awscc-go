/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountaccessEntitlementConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#application_arn AccountaccessEntitlement#application_arn}
    */
    readonly applicationArn: string;
    /**
    * The entitlement details
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#entitlement AccountaccessEntitlement#entitlement}
    */
    readonly entitlement: AccountaccessEntitlementEntitlement;
}
export interface AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter {
    /**
    * The ID of the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#group_id AccountaccessEntitlement#group_id}
    */
    readonly groupId?: string;
    /**
    * The ID of the user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#user_id AccountaccessEntitlement#user_id}
    */
    readonly userId?: string;
}
export declare function accountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterToTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable): any;
export declare function accountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterToHclTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable): any;
export declare class AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable | undefined);
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
}
export interface AccountaccessEntitlementEntitlementPrincipalRolePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#identity_center AccountaccessEntitlement#identity_center}
    */
    readonly identityCenter: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter;
}
export declare function accountaccessEntitlementEntitlementPrincipalRolePrincipalToTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRolePrincipal | cdktn.IResolvable): any;
export declare function accountaccessEntitlementEntitlementPrincipalRolePrincipalToHclTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRolePrincipal | cdktn.IResolvable): any;
export declare class AccountaccessEntitlementEntitlementPrincipalRolePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountaccessEntitlementEntitlementPrincipalRolePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessEntitlementEntitlementPrincipalRolePrincipal | cdktn.IResolvable | undefined);
    private _identityCenter;
    get identityCenter(): AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterOutputReference;
    putIdentityCenter(value: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter): void;
    get identityCenterInput(): cdktn.IResolvable | AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | undefined;
}
export interface AccountaccessEntitlementEntitlementPrincipalRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#principal AccountaccessEntitlement#principal}
    */
    readonly principal: AccountaccessEntitlementEntitlementPrincipalRolePrincipal;
    /**
    * The ARN of the IAM role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#role_arn AccountaccessEntitlement#role_arn}
    */
    readonly roleArn: string;
}
export declare function accountaccessEntitlementEntitlementPrincipalRoleToTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRole | cdktn.IResolvable): any;
export declare function accountaccessEntitlementEntitlementPrincipalRoleToHclTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRole | cdktn.IResolvable): any;
export declare class AccountaccessEntitlementEntitlementPrincipalRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountaccessEntitlementEntitlementPrincipalRole | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessEntitlementEntitlementPrincipalRole | cdktn.IResolvable | undefined);
    get account(): string;
    private _principal;
    get principal(): AccountaccessEntitlementEntitlementPrincipalRolePrincipalOutputReference;
    putPrincipal(value: AccountaccessEntitlementEntitlementPrincipalRolePrincipal): void;
    get principalInput(): cdktn.IResolvable | AccountaccessEntitlementEntitlementPrincipalRolePrincipal | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
export interface AccountaccessEntitlementEntitlement {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#principal_role AccountaccessEntitlement#principal_role}
    */
    readonly principalRole: AccountaccessEntitlementEntitlementPrincipalRole;
}
export declare function accountaccessEntitlementEntitlementToTerraform(struct?: AccountaccessEntitlementEntitlement | cdktn.IResolvable): any;
export declare function accountaccessEntitlementEntitlementToHclTerraform(struct?: AccountaccessEntitlementEntitlement | cdktn.IResolvable): any;
export declare class AccountaccessEntitlementEntitlementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountaccessEntitlementEntitlement | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessEntitlementEntitlement | cdktn.IResolvable | undefined);
    private _principalRole;
    get principalRole(): AccountaccessEntitlementEntitlementPrincipalRoleOutputReference;
    putPrincipalRole(value: AccountaccessEntitlementEntitlementPrincipalRole): void;
    get principalRoleInput(): cdktn.IResolvable | AccountaccessEntitlementEntitlementPrincipalRole | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement awscc_accountaccess_entitlement}
*/
export declare class AccountaccessEntitlement extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_accountaccess_entitlement";
    /**
    * Generates CDKTN code for importing a AccountaccessEntitlement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountaccessEntitlement to import
    * @param importFromId The id of the existing AccountaccessEntitlement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountaccessEntitlement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accountaccess_entitlement awscc_accountaccess_entitlement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountaccessEntitlementConfig
    */
    constructor(scope: Construct, id: string, config: AccountaccessEntitlementConfig);
    private _applicationArn?;
    get applicationArn(): string;
    set applicationArn(value: string);
    get applicationArnInput(): string | undefined;
    get createdAt(): string;
    private _entitlement;
    get entitlement(): AccountaccessEntitlementEntitlementOutputReference;
    putEntitlement(value: AccountaccessEntitlementEntitlement): void;
    get entitlementInput(): cdktn.IResolvable | AccountaccessEntitlementEntitlement | undefined;
    get entitlementId(): string;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
