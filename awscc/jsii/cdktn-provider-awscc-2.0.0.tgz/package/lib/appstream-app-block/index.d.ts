/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamAppBlockConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#description AppstreamAppBlock#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#display_name AppstreamAppBlock#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#name AppstreamAppBlock#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#packaging_type AppstreamAppBlock#packaging_type}
    */
    readonly packagingType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#post_setup_script_details AppstreamAppBlock#post_setup_script_details}
    */
    readonly postSetupScriptDetails?: AppstreamAppBlockPostSetupScriptDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#setup_script_details AppstreamAppBlock#setup_script_details}
    */
    readonly setupScriptDetails?: AppstreamAppBlockSetupScriptDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#source_s3_location AppstreamAppBlock#source_s3_location}
    */
    readonly sourceS3Location: AppstreamAppBlockSourceS3Location;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#tags AppstreamAppBlock#tags}
    */
    readonly tags?: AppstreamAppBlockTags[] | cdktn.IResolvable;
}
export interface AppstreamAppBlockPostSetupScriptDetailsScriptS3Location {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#s3_bucket AppstreamAppBlock#s3_bucket}
    */
    readonly s3Bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#s3_key AppstreamAppBlock#s3_key}
    */
    readonly s3Key?: string;
}
export declare function appstreamAppBlockPostSetupScriptDetailsScriptS3LocationToTerraform(struct?: AppstreamAppBlockPostSetupScriptDetailsScriptS3Location | cdktn.IResolvable): any;
export declare function appstreamAppBlockPostSetupScriptDetailsScriptS3LocationToHclTerraform(struct?: AppstreamAppBlockPostSetupScriptDetailsScriptS3Location | cdktn.IResolvable): any;
export declare class AppstreamAppBlockPostSetupScriptDetailsScriptS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamAppBlockPostSetupScriptDetailsScriptS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockPostSetupScriptDetailsScriptS3Location | cdktn.IResolvable | undefined);
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    resetS3Bucket(): void;
    get s3BucketInput(): string | undefined;
    private _s3Key?;
    get s3Key(): string;
    set s3Key(value: string);
    resetS3Key(): void;
    get s3KeyInput(): string | undefined;
}
export interface AppstreamAppBlockPostSetupScriptDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#executable_parameters AppstreamAppBlock#executable_parameters}
    */
    readonly executableParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#executable_path AppstreamAppBlock#executable_path}
    */
    readonly executablePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#script_s3_location AppstreamAppBlock#script_s3_location}
    */
    readonly scriptS3Location?: AppstreamAppBlockPostSetupScriptDetailsScriptS3Location;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#timeout_in_seconds AppstreamAppBlock#timeout_in_seconds}
    */
    readonly timeoutInSeconds?: number;
}
export declare function appstreamAppBlockPostSetupScriptDetailsToTerraform(struct?: AppstreamAppBlockPostSetupScriptDetails | cdktn.IResolvable): any;
export declare function appstreamAppBlockPostSetupScriptDetailsToHclTerraform(struct?: AppstreamAppBlockPostSetupScriptDetails | cdktn.IResolvable): any;
export declare class AppstreamAppBlockPostSetupScriptDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamAppBlockPostSetupScriptDetails | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockPostSetupScriptDetails | cdktn.IResolvable | undefined);
    private _executableParameters?;
    get executableParameters(): string;
    set executableParameters(value: string);
    resetExecutableParameters(): void;
    get executableParametersInput(): string | undefined;
    private _executablePath?;
    get executablePath(): string;
    set executablePath(value: string);
    resetExecutablePath(): void;
    get executablePathInput(): string | undefined;
    private _scriptS3Location;
    get scriptS3Location(): AppstreamAppBlockPostSetupScriptDetailsScriptS3LocationOutputReference;
    putScriptS3Location(value: AppstreamAppBlockPostSetupScriptDetailsScriptS3Location): void;
    resetScriptS3Location(): void;
    get scriptS3LocationInput(): cdktn.IResolvable | AppstreamAppBlockPostSetupScriptDetailsScriptS3Location | undefined;
    private _timeoutInSeconds?;
    get timeoutInSeconds(): number;
    set timeoutInSeconds(value: number);
    resetTimeoutInSeconds(): void;
    get timeoutInSecondsInput(): number | undefined;
}
export interface AppstreamAppBlockSetupScriptDetailsScriptS3Location {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#s3_bucket AppstreamAppBlock#s3_bucket}
    */
    readonly s3Bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#s3_key AppstreamAppBlock#s3_key}
    */
    readonly s3Key?: string;
}
export declare function appstreamAppBlockSetupScriptDetailsScriptS3LocationToTerraform(struct?: AppstreamAppBlockSetupScriptDetailsScriptS3Location | cdktn.IResolvable): any;
export declare function appstreamAppBlockSetupScriptDetailsScriptS3LocationToHclTerraform(struct?: AppstreamAppBlockSetupScriptDetailsScriptS3Location | cdktn.IResolvable): any;
export declare class AppstreamAppBlockSetupScriptDetailsScriptS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamAppBlockSetupScriptDetailsScriptS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockSetupScriptDetailsScriptS3Location | cdktn.IResolvable | undefined);
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    resetS3Bucket(): void;
    get s3BucketInput(): string | undefined;
    private _s3Key?;
    get s3Key(): string;
    set s3Key(value: string);
    resetS3Key(): void;
    get s3KeyInput(): string | undefined;
}
export interface AppstreamAppBlockSetupScriptDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#executable_parameters AppstreamAppBlock#executable_parameters}
    */
    readonly executableParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#executable_path AppstreamAppBlock#executable_path}
    */
    readonly executablePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#script_s3_location AppstreamAppBlock#script_s3_location}
    */
    readonly scriptS3Location?: AppstreamAppBlockSetupScriptDetailsScriptS3Location;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#timeout_in_seconds AppstreamAppBlock#timeout_in_seconds}
    */
    readonly timeoutInSeconds?: number;
}
export declare function appstreamAppBlockSetupScriptDetailsToTerraform(struct?: AppstreamAppBlockSetupScriptDetails | cdktn.IResolvable): any;
export declare function appstreamAppBlockSetupScriptDetailsToHclTerraform(struct?: AppstreamAppBlockSetupScriptDetails | cdktn.IResolvable): any;
export declare class AppstreamAppBlockSetupScriptDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamAppBlockSetupScriptDetails | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockSetupScriptDetails | cdktn.IResolvable | undefined);
    private _executableParameters?;
    get executableParameters(): string;
    set executableParameters(value: string);
    resetExecutableParameters(): void;
    get executableParametersInput(): string | undefined;
    private _executablePath?;
    get executablePath(): string;
    set executablePath(value: string);
    resetExecutablePath(): void;
    get executablePathInput(): string | undefined;
    private _scriptS3Location;
    get scriptS3Location(): AppstreamAppBlockSetupScriptDetailsScriptS3LocationOutputReference;
    putScriptS3Location(value: AppstreamAppBlockSetupScriptDetailsScriptS3Location): void;
    resetScriptS3Location(): void;
    get scriptS3LocationInput(): cdktn.IResolvable | AppstreamAppBlockSetupScriptDetailsScriptS3Location | undefined;
    private _timeoutInSeconds?;
    get timeoutInSeconds(): number;
    set timeoutInSeconds(value: number);
    resetTimeoutInSeconds(): void;
    get timeoutInSecondsInput(): number | undefined;
}
export interface AppstreamAppBlockSourceS3Location {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#s3_bucket AppstreamAppBlock#s3_bucket}
    */
    readonly s3Bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#s3_key AppstreamAppBlock#s3_key}
    */
    readonly s3Key?: string;
}
export declare function appstreamAppBlockSourceS3LocationToTerraform(struct?: AppstreamAppBlockSourceS3Location | cdktn.IResolvable): any;
export declare function appstreamAppBlockSourceS3LocationToHclTerraform(struct?: AppstreamAppBlockSourceS3Location | cdktn.IResolvable): any;
export declare class AppstreamAppBlockSourceS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamAppBlockSourceS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockSourceS3Location | cdktn.IResolvable | undefined);
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    get s3BucketInput(): string | undefined;
    private _s3Key?;
    get s3Key(): string;
    set s3Key(value: string);
    resetS3Key(): void;
    get s3KeyInput(): string | undefined;
}
export interface AppstreamAppBlockTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#key AppstreamAppBlock#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#tag_key AppstreamAppBlock#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#tag_value AppstreamAppBlock#tag_value}
    */
    readonly tagValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#value AppstreamAppBlock#value}
    */
    readonly value?: string;
}
export declare function appstreamAppBlockTagsToTerraform(struct?: AppstreamAppBlockTags | cdktn.IResolvable): any;
export declare function appstreamAppBlockTagsToHclTerraform(struct?: AppstreamAppBlockTags | cdktn.IResolvable): any;
export declare class AppstreamAppBlockTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamAppBlockTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamAppBlockTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppstreamAppBlockTagsList extends cdktn.ComplexList {
    internalValue?: AppstreamAppBlockTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamAppBlockTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block awscc_appstream_app_block}
*/
export declare class AppstreamAppBlock extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_app_block";
    /**
    * Generates CDKTN code for importing a AppstreamAppBlock resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamAppBlock to import
    * @param importFromId The id of the existing AppstreamAppBlock that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamAppBlock to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_app_block awscc_appstream_app_block} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamAppBlockConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamAppBlockConfig);
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _packagingType?;
    get packagingType(): string;
    set packagingType(value: string);
    resetPackagingType(): void;
    get packagingTypeInput(): string | undefined;
    private _postSetupScriptDetails;
    get postSetupScriptDetails(): AppstreamAppBlockPostSetupScriptDetailsOutputReference;
    putPostSetupScriptDetails(value: AppstreamAppBlockPostSetupScriptDetails): void;
    resetPostSetupScriptDetails(): void;
    get postSetupScriptDetailsInput(): cdktn.IResolvable | AppstreamAppBlockPostSetupScriptDetails | undefined;
    private _setupScriptDetails;
    get setupScriptDetails(): AppstreamAppBlockSetupScriptDetailsOutputReference;
    putSetupScriptDetails(value: AppstreamAppBlockSetupScriptDetails): void;
    resetSetupScriptDetails(): void;
    get setupScriptDetailsInput(): cdktn.IResolvable | AppstreamAppBlockSetupScriptDetails | undefined;
    private _sourceS3Location;
    get sourceS3Location(): AppstreamAppBlockSourceS3LocationOutputReference;
    putSourceS3Location(value: AppstreamAppBlockSourceS3Location): void;
    get sourceS3LocationInput(): cdktn.IResolvable | AppstreamAppBlockSourceS3Location | undefined;
    private _tags;
    get tags(): AppstreamAppBlockTagsList;
    putTags(value: AppstreamAppBlockTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppstreamAppBlockTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
