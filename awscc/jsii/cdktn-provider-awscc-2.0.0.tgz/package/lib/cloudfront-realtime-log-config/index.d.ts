/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontRealtimeLogConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Contains information about the Amazon Kinesis data stream where you are sending real-time log data for this real-time log configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#end_points CloudfrontRealtimeLogConfig#end_points}
    */
    readonly endPoints: CloudfrontRealtimeLogConfigEndPoints[] | cdktn.IResolvable;
    /**
    * A list of fields that are included in each real-time log record. In an API response, the fields are provided in the same order in which they are sent to the Amazon Kinesis data stream.
    *  For more information about fields, see [Real-time log configuration fields](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/real-time-logs.html#understand-real-time-log-config-fields) in the *Amazon CloudFront Developer Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#fields CloudfrontRealtimeLogConfig#fields}
    */
    readonly fields: string[];
    /**
    * The unique name of this real-time log configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#name CloudfrontRealtimeLogConfig#name}
    */
    readonly name: string;
    /**
    * The sampling rate for this real-time log configuration. The sampling rate determines the percentage of viewer requests that are represented in the real-time log data. The sampling rate is an integer between 1 and 100, inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#sampling_rate CloudfrontRealtimeLogConfig#sampling_rate}
    */
    readonly samplingRate: number;
}
export interface CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfig {
    /**
    * The Amazon Resource Name (ARN) of an IAMlong (IAM) role that CloudFront can use to send real-time log data to your Kinesis data stream.
    *  For more information the IAM role, see [Real-time log configuration IAM role](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/real-time-logs.html#understand-real-time-log-config-iam-role) in the *Amazon CloudFront Developer Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#role_arn CloudfrontRealtimeLogConfig#role_arn}
    */
    readonly roleArn: string;
    /**
    * The Amazon Resource Name (ARN) of the Kinesis data stream where you are sending real-time log data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#stream_arn CloudfrontRealtimeLogConfig#stream_arn}
    */
    readonly streamArn: string;
}
export declare function cloudfrontRealtimeLogConfigEndPointsKinesisStreamConfigToTerraform(struct?: CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfig | cdktn.IResolvable): any;
export declare function cloudfrontRealtimeLogConfigEndPointsKinesisStreamConfigToHclTerraform(struct?: CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfig | cdktn.IResolvable): any;
export declare class CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfig | cdktn.IResolvable | undefined);
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _streamArn?;
    get streamArn(): string;
    set streamArn(value: string);
    get streamArnInput(): string | undefined;
}
export interface CloudfrontRealtimeLogConfigEndPoints {
    /**
    * Contains information about the Amazon Kinesis data stream where you are sending real-time log data in a real-time log configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#kinesis_stream_config CloudfrontRealtimeLogConfig#kinesis_stream_config}
    */
    readonly kinesisStreamConfig: CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfig;
    /**
    * The type of data stream where you are sending real-time log data. The only valid value is ``Kinesis``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#stream_type CloudfrontRealtimeLogConfig#stream_type}
    */
    readonly streamType: string;
}
export declare function cloudfrontRealtimeLogConfigEndPointsToTerraform(struct?: CloudfrontRealtimeLogConfigEndPoints | cdktn.IResolvable): any;
export declare function cloudfrontRealtimeLogConfigEndPointsToHclTerraform(struct?: CloudfrontRealtimeLogConfigEndPoints | cdktn.IResolvable): any;
export declare class CloudfrontRealtimeLogConfigEndPointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontRealtimeLogConfigEndPoints | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontRealtimeLogConfigEndPoints | cdktn.IResolvable | undefined);
    private _kinesisStreamConfig;
    get kinesisStreamConfig(): CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfigOutputReference;
    putKinesisStreamConfig(value: CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfig): void;
    get kinesisStreamConfigInput(): cdktn.IResolvable | CloudfrontRealtimeLogConfigEndPointsKinesisStreamConfig | undefined;
    private _streamType?;
    get streamType(): string;
    set streamType(value: string);
    get streamTypeInput(): string | undefined;
}
export declare class CloudfrontRealtimeLogConfigEndPointsList extends cdktn.ComplexList {
    internalValue?: CloudfrontRealtimeLogConfigEndPoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontRealtimeLogConfigEndPointsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config awscc_cloudfront_realtime_log_config}
*/
export declare class CloudfrontRealtimeLogConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_realtime_log_config";
    /**
    * Generates CDKTN code for importing a CloudfrontRealtimeLogConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontRealtimeLogConfig to import
    * @param importFromId The id of the existing CloudfrontRealtimeLogConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontRealtimeLogConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudfront_realtime_log_config awscc_cloudfront_realtime_log_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontRealtimeLogConfigConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontRealtimeLogConfigConfig);
    get arn(): string;
    private _endPoints;
    get endPoints(): CloudfrontRealtimeLogConfigEndPointsList;
    putEndPoints(value: CloudfrontRealtimeLogConfigEndPoints[] | cdktn.IResolvable): void;
    get endPointsInput(): cdktn.IResolvable | CloudfrontRealtimeLogConfigEndPoints[] | undefined;
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    get fieldsInput(): string[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _samplingRate?;
    get samplingRate(): number;
    set samplingRate(value: number);
    get samplingRateInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
