/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Apigatewayv2RouteResponseConfig extends cdktn.TerraformMetaArguments {
    /**
    * The API identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response#api_id Apigatewayv2RouteResponse#api_id}
    */
    readonly apiId: string;
    /**
    * The model selection expression for the route response. Supported only for WebSocket APIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response#model_selection_expression Apigatewayv2RouteResponse#model_selection_expression}
    */
    readonly modelSelectionExpression?: string;
    /**
    * The response models for the route response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response#response_models Apigatewayv2RouteResponse#response_models}
    */
    readonly responseModels?: string;
    /**
    * The route response parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response#response_parameters Apigatewayv2RouteResponse#response_parameters}
    */
    readonly responseParameters?: {
        [key: string]: Apigatewayv2RouteResponseResponseParameters;
    } | cdktn.IResolvable;
    /**
    * The route ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response#route_id Apigatewayv2RouteResponse#route_id}
    */
    readonly routeId: string;
    /**
    * The route response key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response#route_response_key Apigatewayv2RouteResponse#route_response_key}
    */
    readonly routeResponseKey: string;
}
export interface Apigatewayv2RouteResponseResponseParameters {
    /**
    * Specifies whether the parameter is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response#required Apigatewayv2RouteResponse#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
}
export declare function apigatewayv2RouteResponseResponseParametersToTerraform(struct?: Apigatewayv2RouteResponseResponseParameters | cdktn.IResolvable): any;
export declare function apigatewayv2RouteResponseResponseParametersToHclTerraform(struct?: Apigatewayv2RouteResponseResponseParameters | cdktn.IResolvable): any;
export declare class Apigatewayv2RouteResponseResponseParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): Apigatewayv2RouteResponseResponseParameters | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RouteResponseResponseParameters | cdktn.IResolvable | undefined);
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class Apigatewayv2RouteResponseResponseParametersMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: Apigatewayv2RouteResponseResponseParameters;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): Apigatewayv2RouteResponseResponseParametersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response awscc_apigatewayv2_route_response}
*/
export declare class Apigatewayv2RouteResponse extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigatewayv2_route_response";
    /**
    * Generates CDKTN code for importing a Apigatewayv2RouteResponse resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Apigatewayv2RouteResponse to import
    * @param importFromId The id of the existing Apigatewayv2RouteResponse that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Apigatewayv2RouteResponse to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apigatewayv2_route_response awscc_apigatewayv2_route_response} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Apigatewayv2RouteResponseConfig
    */
    constructor(scope: Construct, id: string, config: Apigatewayv2RouteResponseConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get id(): string;
    private _modelSelectionExpression?;
    get modelSelectionExpression(): string;
    set modelSelectionExpression(value: string);
    resetModelSelectionExpression(): void;
    get modelSelectionExpressionInput(): string | undefined;
    private _responseModels?;
    get responseModels(): string;
    set responseModels(value: string);
    resetResponseModels(): void;
    get responseModelsInput(): string | undefined;
    private _responseParameters;
    get responseParameters(): Apigatewayv2RouteResponseResponseParametersMap;
    putResponseParameters(value: {
        [key: string]: Apigatewayv2RouteResponseResponseParameters;
    } | cdktn.IResolvable): void;
    resetResponseParameters(): void;
    get responseParametersInput(): cdktn.IResolvable | {
        [key: string]: Apigatewayv2RouteResponseResponseParameters;
    } | undefined;
    private _routeId?;
    get routeId(): string;
    set routeId(value: string);
    get routeIdInput(): string | undefined;
    get routeResponseId(): string;
    private _routeResponseKey?;
    get routeResponseKey(): string;
    set routeResponseKey(value: string);
    get routeResponseKeyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
