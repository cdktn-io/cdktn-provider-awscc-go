/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeMediaInsightsPipelineConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The elements in the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#elements ChimeMediaInsightsPipelineConfiguration#elements}
    */
    readonly elements: ChimeMediaInsightsPipelineConfigurationElements[] | cdktn.IResolvable;
    /**
    * The name of the media insights pipeline configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#media_insights_pipeline_configuration_name ChimeMediaInsightsPipelineConfiguration#media_insights_pipeline_configuration_name}
    */
    readonly mediaInsightsPipelineConfigurationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#real_time_alert_configuration ChimeMediaInsightsPipelineConfiguration#real_time_alert_configuration}
    */
    readonly realTimeAlertConfiguration?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfiguration;
    /**
    * The ARN of the role used by the service to access Amazon Web Services resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#resource_access_role_arn ChimeMediaInsightsPipelineConfiguration#resource_access_role_arn}
    */
    readonly resourceAccessRoleArn: string;
    /**
    * The tags associated with the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#tags ChimeMediaInsightsPipelineConfiguration#tags}
    */
    readonly tags?: ChimeMediaInsightsPipelineConfigurationTags[] | cdktn.IResolvable;
}
export interface ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettings {
    /**
    * The content redaction output settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#content_redaction_output ChimeMediaInsightsPipelineConfiguration#content_redaction_output}
    */
    readonly contentRedactionOutput?: string;
    /**
    * The ARN of the role used by Transcribe to upload post-call analysis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#data_access_role_arn ChimeMediaInsightsPipelineConfiguration#data_access_role_arn}
    */
    readonly dataAccessRoleArn?: string;
    /**
    * The ID of the KMS key used to encrypt the output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#output_encryption_kms_key_id ChimeMediaInsightsPipelineConfiguration#output_encryption_kms_key_id}
    */
    readonly outputEncryptionKmsKeyId?: string;
    /**
    * The URL of the Amazon S3 bucket for post-call data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#output_location ChimeMediaInsightsPipelineConfiguration#output_location}
    */
    readonly outputLocation?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettingsToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettings | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettingsToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettings | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettings | cdktn.IResolvable | undefined);
    private _contentRedactionOutput?;
    get contentRedactionOutput(): string;
    set contentRedactionOutput(value: string);
    resetContentRedactionOutput(): void;
    get contentRedactionOutputInput(): string | undefined;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    resetDataAccessRoleArn(): void;
    get dataAccessRoleArnInput(): string | undefined;
    private _outputEncryptionKmsKeyId?;
    get outputEncryptionKmsKeyId(): string;
    set outputEncryptionKmsKeyId(value: string);
    resetOutputEncryptionKmsKeyId(): void;
    get outputEncryptionKmsKeyIdInput(): string | undefined;
    private _outputLocation?;
    get outputLocation(): string;
    set outputLocation(value: string);
    resetOutputLocation(): void;
    get outputLocationInput(): string | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfiguration {
    /**
    * The categories to send to the insights target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#call_analytics_stream_categories ChimeMediaInsightsPipelineConfiguration#call_analytics_stream_categories}
    */
    readonly callAnalyticsStreamCategories?: string[];
    /**
    * Labels all PII identified in the transcript.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#content_identification_type ChimeMediaInsightsPipelineConfiguration#content_identification_type}
    */
    readonly contentIdentificationType?: string;
    /**
    * Redacts all PII identified in the transcript.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#content_redaction_type ChimeMediaInsightsPipelineConfiguration#content_redaction_type}
    */
    readonly contentRedactionType?: string;
    /**
    * Enables partial result stabilization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#enable_partial_results_stabilization ChimeMediaInsightsPipelineConfiguration#enable_partial_results_stabilization}
    */
    readonly enablePartialResultsStabilization?: boolean | cdktn.IResolvable;
    /**
    * If true, partial results are filtered out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#filter_partial_results ChimeMediaInsightsPipelineConfiguration#filter_partial_results}
    */
    readonly filterPartialResults?: boolean | cdktn.IResolvable;
    /**
    * The language code in the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#language_code ChimeMediaInsightsPipelineConfiguration#language_code}
    */
    readonly languageCode?: string;
    /**
    * The name of the custom language model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#language_model_name ChimeMediaInsightsPipelineConfiguration#language_model_name}
    */
    readonly languageModelName?: string;
    /**
    * The level of stability for partial results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#partial_results_stability ChimeMediaInsightsPipelineConfiguration#partial_results_stability}
    */
    readonly partialResultsStability?: string;
    /**
    * The types of PII to redact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#pii_entity_types ChimeMediaInsightsPipelineConfiguration#pii_entity_types}
    */
    readonly piiEntityTypes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#post_call_analytics_settings ChimeMediaInsightsPipelineConfiguration#post_call_analytics_settings}
    */
    readonly postCallAnalyticsSettings?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettings;
    /**
    * The vocabulary filtering method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#vocabulary_filter_method ChimeMediaInsightsPipelineConfiguration#vocabulary_filter_method}
    */
    readonly vocabularyFilterMethod?: string;
    /**
    * The name of the custom vocabulary filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#vocabulary_filter_name ChimeMediaInsightsPipelineConfiguration#vocabulary_filter_name}
    */
    readonly vocabularyFilterName?: string;
    /**
    * The name of the custom vocabulary.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#vocabulary_name ChimeMediaInsightsPipelineConfiguration#vocabulary_name}
    */
    readonly vocabularyName?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfiguration | cdktn.IResolvable | undefined);
    private _callAnalyticsStreamCategories?;
    get callAnalyticsStreamCategories(): string[];
    set callAnalyticsStreamCategories(value: string[]);
    resetCallAnalyticsStreamCategories(): void;
    get callAnalyticsStreamCategoriesInput(): string[] | undefined;
    private _contentIdentificationType?;
    get contentIdentificationType(): string;
    set contentIdentificationType(value: string);
    resetContentIdentificationType(): void;
    get contentIdentificationTypeInput(): string | undefined;
    private _contentRedactionType?;
    get contentRedactionType(): string;
    set contentRedactionType(value: string);
    resetContentRedactionType(): void;
    get contentRedactionTypeInput(): string | undefined;
    private _enablePartialResultsStabilization?;
    get enablePartialResultsStabilization(): boolean | cdktn.IResolvable;
    set enablePartialResultsStabilization(value: boolean | cdktn.IResolvable);
    resetEnablePartialResultsStabilization(): void;
    get enablePartialResultsStabilizationInput(): boolean | cdktn.IResolvable | undefined;
    private _filterPartialResults?;
    get filterPartialResults(): boolean | cdktn.IResolvable;
    set filterPartialResults(value: boolean | cdktn.IResolvable);
    resetFilterPartialResults(): void;
    get filterPartialResultsInput(): boolean | cdktn.IResolvable | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    resetLanguageCode(): void;
    get languageCodeInput(): string | undefined;
    private _languageModelName?;
    get languageModelName(): string;
    set languageModelName(value: string);
    resetLanguageModelName(): void;
    get languageModelNameInput(): string | undefined;
    private _partialResultsStability?;
    get partialResultsStability(): string;
    set partialResultsStability(value: string);
    resetPartialResultsStability(): void;
    get partialResultsStabilityInput(): string | undefined;
    private _piiEntityTypes?;
    get piiEntityTypes(): string;
    set piiEntityTypes(value: string);
    resetPiiEntityTypes(): void;
    get piiEntityTypesInput(): string | undefined;
    private _postCallAnalyticsSettings;
    get postCallAnalyticsSettings(): ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettingsOutputReference;
    putPostCallAnalyticsSettings(value: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettings): void;
    resetPostCallAnalyticsSettings(): void;
    get postCallAnalyticsSettingsInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationPostCallAnalyticsSettings | undefined;
    private _vocabularyFilterMethod?;
    get vocabularyFilterMethod(): string;
    set vocabularyFilterMethod(value: string);
    resetVocabularyFilterMethod(): void;
    get vocabularyFilterMethodInput(): string | undefined;
    private _vocabularyFilterName?;
    get vocabularyFilterName(): string;
    set vocabularyFilterName(value: string);
    resetVocabularyFilterName(): void;
    get vocabularyFilterNameInput(): string | undefined;
    private _vocabularyName?;
    get vocabularyName(): string;
    set vocabularyName(value: string);
    resetVocabularyName(): void;
    get vocabularyNameInput(): string | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfiguration {
    /**
    * Labels all PII identified in the transcript.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#content_identification_type ChimeMediaInsightsPipelineConfiguration#content_identification_type}
    */
    readonly contentIdentificationType?: string;
    /**
    * Redacts all PII identified in the transcript.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#content_redaction_type ChimeMediaInsightsPipelineConfiguration#content_redaction_type}
    */
    readonly contentRedactionType?: string;
    /**
    * Enables partial result stabilization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#enable_partial_results_stabilization ChimeMediaInsightsPipelineConfiguration#enable_partial_results_stabilization}
    */
    readonly enablePartialResultsStabilization?: boolean | cdktn.IResolvable;
    /**
    * If true, partial results are filtered out.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#filter_partial_results ChimeMediaInsightsPipelineConfiguration#filter_partial_results}
    */
    readonly filterPartialResults?: boolean | cdktn.IResolvable;
    /**
    * Turns language identification on or off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#identify_language ChimeMediaInsightsPipelineConfiguration#identify_language}
    */
    readonly identifyLanguage?: boolean | cdktn.IResolvable;
    /**
    * Turns multiple language identification on or off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#identify_multiple_languages ChimeMediaInsightsPipelineConfiguration#identify_multiple_languages}
    */
    readonly identifyMultipleLanguages?: boolean | cdktn.IResolvable;
    /**
    * The language code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#language_code ChimeMediaInsightsPipelineConfiguration#language_code}
    */
    readonly languageCode?: string;
    /**
    * The name of the custom language model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#language_model_name ChimeMediaInsightsPipelineConfiguration#language_model_name}
    */
    readonly languageModelName?: string;
    /**
    * The language options for transcription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#language_options ChimeMediaInsightsPipelineConfiguration#language_options}
    */
    readonly languageOptions?: string;
    /**
    * The level of stability for partial results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#partial_results_stability ChimeMediaInsightsPipelineConfiguration#partial_results_stability}
    */
    readonly partialResultsStability?: string;
    /**
    * The types of PII to redact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#pii_entity_types ChimeMediaInsightsPipelineConfiguration#pii_entity_types}
    */
    readonly piiEntityTypes?: string;
    /**
    * The preferred language for transcription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#preferred_language ChimeMediaInsightsPipelineConfiguration#preferred_language}
    */
    readonly preferredLanguage?: string;
    /**
    * Enables speaker partitioning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#show_speaker_label ChimeMediaInsightsPipelineConfiguration#show_speaker_label}
    */
    readonly showSpeakerLabel?: boolean | cdktn.IResolvable;
    /**
    * The vocabulary filtering method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#vocabulary_filter_method ChimeMediaInsightsPipelineConfiguration#vocabulary_filter_method}
    */
    readonly vocabularyFilterMethod?: string;
    /**
    * The name of the custom vocabulary filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#vocabulary_filter_name ChimeMediaInsightsPipelineConfiguration#vocabulary_filter_name}
    */
    readonly vocabularyFilterName?: string;
    /**
    * The names of the custom vocabulary filters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#vocabulary_filter_names ChimeMediaInsightsPipelineConfiguration#vocabulary_filter_names}
    */
    readonly vocabularyFilterNames?: string;
    /**
    * The name of the custom vocabulary.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#vocabulary_name ChimeMediaInsightsPipelineConfiguration#vocabulary_name}
    */
    readonly vocabularyName?: string;
    /**
    * The names of the custom vocabularies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#vocabulary_names ChimeMediaInsightsPipelineConfiguration#vocabulary_names}
    */
    readonly vocabularyNames?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfigurationToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfigurationToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfiguration | cdktn.IResolvable | undefined);
    private _contentIdentificationType?;
    get contentIdentificationType(): string;
    set contentIdentificationType(value: string);
    resetContentIdentificationType(): void;
    get contentIdentificationTypeInput(): string | undefined;
    private _contentRedactionType?;
    get contentRedactionType(): string;
    set contentRedactionType(value: string);
    resetContentRedactionType(): void;
    get contentRedactionTypeInput(): string | undefined;
    private _enablePartialResultsStabilization?;
    get enablePartialResultsStabilization(): boolean | cdktn.IResolvable;
    set enablePartialResultsStabilization(value: boolean | cdktn.IResolvable);
    resetEnablePartialResultsStabilization(): void;
    get enablePartialResultsStabilizationInput(): boolean | cdktn.IResolvable | undefined;
    private _filterPartialResults?;
    get filterPartialResults(): boolean | cdktn.IResolvable;
    set filterPartialResults(value: boolean | cdktn.IResolvable);
    resetFilterPartialResults(): void;
    get filterPartialResultsInput(): boolean | cdktn.IResolvable | undefined;
    private _identifyLanguage?;
    get identifyLanguage(): boolean | cdktn.IResolvable;
    set identifyLanguage(value: boolean | cdktn.IResolvable);
    resetIdentifyLanguage(): void;
    get identifyLanguageInput(): boolean | cdktn.IResolvable | undefined;
    private _identifyMultipleLanguages?;
    get identifyMultipleLanguages(): boolean | cdktn.IResolvable;
    set identifyMultipleLanguages(value: boolean | cdktn.IResolvable);
    resetIdentifyMultipleLanguages(): void;
    get identifyMultipleLanguagesInput(): boolean | cdktn.IResolvable | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    resetLanguageCode(): void;
    get languageCodeInput(): string | undefined;
    private _languageModelName?;
    get languageModelName(): string;
    set languageModelName(value: string);
    resetLanguageModelName(): void;
    get languageModelNameInput(): string | undefined;
    private _languageOptions?;
    get languageOptions(): string;
    set languageOptions(value: string);
    resetLanguageOptions(): void;
    get languageOptionsInput(): string | undefined;
    private _partialResultsStability?;
    get partialResultsStability(): string;
    set partialResultsStability(value: string);
    resetPartialResultsStability(): void;
    get partialResultsStabilityInput(): string | undefined;
    private _piiEntityTypes?;
    get piiEntityTypes(): string;
    set piiEntityTypes(value: string);
    resetPiiEntityTypes(): void;
    get piiEntityTypesInput(): string | undefined;
    private _preferredLanguage?;
    get preferredLanguage(): string;
    set preferredLanguage(value: string);
    resetPreferredLanguage(): void;
    get preferredLanguageInput(): string | undefined;
    private _showSpeakerLabel?;
    get showSpeakerLabel(): boolean | cdktn.IResolvable;
    set showSpeakerLabel(value: boolean | cdktn.IResolvable);
    resetShowSpeakerLabel(): void;
    get showSpeakerLabelInput(): boolean | cdktn.IResolvable | undefined;
    private _vocabularyFilterMethod?;
    get vocabularyFilterMethod(): string;
    set vocabularyFilterMethod(value: string);
    resetVocabularyFilterMethod(): void;
    get vocabularyFilterMethodInput(): string | undefined;
    private _vocabularyFilterName?;
    get vocabularyFilterName(): string;
    set vocabularyFilterName(value: string);
    resetVocabularyFilterName(): void;
    get vocabularyFilterNameInput(): string | undefined;
    private _vocabularyFilterNames?;
    get vocabularyFilterNames(): string;
    set vocabularyFilterNames(value: string);
    resetVocabularyFilterNames(): void;
    get vocabularyFilterNamesInput(): string | undefined;
    private _vocabularyName?;
    get vocabularyName(): string;
    set vocabularyName(value: string);
    resetVocabularyName(): void;
    get vocabularyNameInput(): string | undefined;
    private _vocabularyNames?;
    get vocabularyNames(): string;
    set vocabularyNames(value: string);
    resetVocabularyNames(): void;
    get vocabularyNamesInput(): string | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfiguration {
    /**
    * The ARN of the Kinesis Data Stream sink.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#insights_target ChimeMediaInsightsPipelineConfiguration#insights_target}
    */
    readonly insightsTarget?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfigurationToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfigurationToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfiguration | cdktn.IResolvable | undefined);
    private _insightsTarget?;
    get insightsTarget(): string;
    set insightsTarget(value: string);
    resetInsightsTarget(): void;
    get insightsTargetInput(): string | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfiguration {
    /**
    * The default URI of the Amazon S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#destination ChimeMediaInsightsPipelineConfiguration#destination}
    */
    readonly destination?: string;
    /**
    * The recording file format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#recording_file_format ChimeMediaInsightsPipelineConfiguration#recording_file_format}
    */
    readonly recordingFileFormat?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfigurationToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfigurationToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfiguration | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _recordingFileFormat?;
    get recordingFileFormat(): string;
    set recordingFileFormat(value: string);
    resetRecordingFileFormat(): void;
    get recordingFileFormatInput(): string | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationElements {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#amazon_transcribe_call_analytics_processor_configuration ChimeMediaInsightsPipelineConfiguration#amazon_transcribe_call_analytics_processor_configuration}
    */
    readonly amazonTranscribeCallAnalyticsProcessorConfiguration?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#amazon_transcribe_processor_configuration ChimeMediaInsightsPipelineConfiguration#amazon_transcribe_processor_configuration}
    */
    readonly amazonTranscribeProcessorConfiguration?: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#kinesis_data_stream_sink_configuration ChimeMediaInsightsPipelineConfiguration#kinesis_data_stream_sink_configuration}
    */
    readonly kinesisDataStreamSinkConfiguration?: ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#s3_recording_sink_configuration ChimeMediaInsightsPipelineConfiguration#s3_recording_sink_configuration}
    */
    readonly s3RecordingSinkConfiguration?: ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfiguration;
    /**
    * The element type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#type ChimeMediaInsightsPipelineConfiguration#type}
    */
    readonly type: string;
}
export declare function chimeMediaInsightsPipelineConfigurationElementsToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElements | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationElementsToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationElements | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationElementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationElements | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationElements | cdktn.IResolvable | undefined);
    private _amazonTranscribeCallAnalyticsProcessorConfiguration;
    get amazonTranscribeCallAnalyticsProcessorConfiguration(): ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfigurationOutputReference;
    putAmazonTranscribeCallAnalyticsProcessorConfiguration(value: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfiguration): void;
    resetAmazonTranscribeCallAnalyticsProcessorConfiguration(): void;
    get amazonTranscribeCallAnalyticsProcessorConfigurationInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeCallAnalyticsProcessorConfiguration | undefined;
    private _amazonTranscribeProcessorConfiguration;
    get amazonTranscribeProcessorConfiguration(): ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfigurationOutputReference;
    putAmazonTranscribeProcessorConfiguration(value: ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfiguration): void;
    resetAmazonTranscribeProcessorConfiguration(): void;
    get amazonTranscribeProcessorConfigurationInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationElementsAmazonTranscribeProcessorConfiguration | undefined;
    private _kinesisDataStreamSinkConfiguration;
    get kinesisDataStreamSinkConfiguration(): ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfigurationOutputReference;
    putKinesisDataStreamSinkConfiguration(value: ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfiguration): void;
    resetKinesisDataStreamSinkConfiguration(): void;
    get kinesisDataStreamSinkConfigurationInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationElementsKinesisDataStreamSinkConfiguration | undefined;
    private _s3RecordingSinkConfiguration;
    get s3RecordingSinkConfiguration(): ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfigurationOutputReference;
    putS3RecordingSinkConfiguration(value: ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfiguration): void;
    resetS3RecordingSinkConfiguration(): void;
    get s3RecordingSinkConfigurationInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationElementsS3RecordingSinkConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ChimeMediaInsightsPipelineConfigurationElementsList extends cdktn.ComplexList {
    internalValue?: ChimeMediaInsightsPipelineConfigurationElements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeMediaInsightsPipelineConfigurationElementsOutputReference;
}
export interface ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfiguration {
    /**
    * The name of the issue detection rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#rule_name ChimeMediaInsightsPipelineConfiguration#rule_name}
    */
    readonly ruleName?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfigurationToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfigurationToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfiguration | cdktn.IResolvable | undefined);
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    resetRuleName(): void;
    get ruleNameInput(): string | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfiguration {
    /**
    * The keywords or phrases to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#keywords ChimeMediaInsightsPipelineConfiguration#keywords}
    */
    readonly keywords?: string[];
    /**
    * Matches keywords on their presence or absence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#negate ChimeMediaInsightsPipelineConfiguration#negate}
    */
    readonly negate?: boolean | cdktn.IResolvable;
    /**
    * The name of the keyword match rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#rule_name ChimeMediaInsightsPipelineConfiguration#rule_name}
    */
    readonly ruleName?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfigurationToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfigurationToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfiguration | cdktn.IResolvable | undefined);
    private _keywords?;
    get keywords(): string[];
    set keywords(value: string[]);
    resetKeywords(): void;
    get keywordsInput(): string[] | undefined;
    private _negate?;
    get negate(): boolean | cdktn.IResolvable;
    set negate(value: boolean | cdktn.IResolvable);
    resetNegate(): void;
    get negateInput(): boolean | cdktn.IResolvable | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    resetRuleName(): void;
    get ruleNameInput(): string | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfiguration {
    /**
    * The name of the sentiment rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#rule_name ChimeMediaInsightsPipelineConfiguration#rule_name}
    */
    readonly ruleName?: string;
    /**
    * The type of sentiment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#sentiment_type ChimeMediaInsightsPipelineConfiguration#sentiment_type}
    */
    readonly sentimentType?: string;
    /**
    * The analysis interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#time_period ChimeMediaInsightsPipelineConfiguration#time_period}
    */
    readonly timePeriod?: number;
}
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfigurationToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfigurationToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfiguration | cdktn.IResolvable | undefined);
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    resetRuleName(): void;
    get ruleNameInput(): string | undefined;
    private _sentimentType?;
    get sentimentType(): string;
    set sentimentType(value: string);
    resetSentimentType(): void;
    get sentimentTypeInput(): string | undefined;
    private _timePeriod?;
    get timePeriod(): number;
    set timePeriod(value: number);
    resetTimePeriod(): void;
    get timePeriodInput(): number | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#issue_detection_configuration ChimeMediaInsightsPipelineConfiguration#issue_detection_configuration}
    */
    readonly issueDetectionConfiguration?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#keyword_match_configuration ChimeMediaInsightsPipelineConfiguration#keyword_match_configuration}
    */
    readonly keywordMatchConfiguration?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#sentiment_configuration ChimeMediaInsightsPipelineConfiguration#sentiment_configuration}
    */
    readonly sentimentConfiguration?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfiguration;
    /**
    * The type of alert rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#type ChimeMediaInsightsPipelineConfiguration#type}
    */
    readonly type?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules | cdktn.IResolvable | undefined);
    private _issueDetectionConfiguration;
    get issueDetectionConfiguration(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfigurationOutputReference;
    putIssueDetectionConfiguration(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfiguration): void;
    resetIssueDetectionConfiguration(): void;
    get issueDetectionConfigurationInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesIssueDetectionConfiguration | undefined;
    private _keywordMatchConfiguration;
    get keywordMatchConfiguration(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfigurationOutputReference;
    putKeywordMatchConfiguration(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfiguration): void;
    resetKeywordMatchConfiguration(): void;
    get keywordMatchConfigurationInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesKeywordMatchConfiguration | undefined;
    private _sentimentConfiguration;
    get sentimentConfiguration(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfigurationOutputReference;
    putSentimentConfiguration(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfiguration): void;
    resetSentimentConfiguration(): void;
    get sentimentConfigurationInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesSentimentConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesList extends cdktn.ComplexList {
    internalValue?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesOutputReference;
}
export interface ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfiguration {
    /**
    * Turns off real-time alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#disabled ChimeMediaInsightsPipelineConfiguration#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * The rules in the alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#rules ChimeMediaInsightsPipelineConfiguration#rules}
    */
    readonly rules?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules[] | cdktn.IResolvable;
}
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfiguration | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _rules;
    get rules(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRulesList;
    putRules(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationRules[] | undefined;
}
export interface ChimeMediaInsightsPipelineConfigurationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#key ChimeMediaInsightsPipelineConfiguration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#value ChimeMediaInsightsPipelineConfiguration#value}
    */
    readonly value?: string;
}
export declare function chimeMediaInsightsPipelineConfigurationTagsToTerraform(struct?: ChimeMediaInsightsPipelineConfigurationTags | cdktn.IResolvable): any;
export declare function chimeMediaInsightsPipelineConfigurationTagsToHclTerraform(struct?: ChimeMediaInsightsPipelineConfigurationTags | cdktn.IResolvable): any;
export declare class ChimeMediaInsightsPipelineConfigurationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeMediaInsightsPipelineConfigurationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaInsightsPipelineConfigurationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeMediaInsightsPipelineConfigurationTagsList extends cdktn.ComplexList {
    internalValue?: ChimeMediaInsightsPipelineConfigurationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeMediaInsightsPipelineConfigurationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration awscc_chime_media_insights_pipeline_configuration}
*/
export declare class ChimeMediaInsightsPipelineConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_media_insights_pipeline_configuration";
    /**
    * Generates CDKTN code for importing a ChimeMediaInsightsPipelineConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeMediaInsightsPipelineConfiguration to import
    * @param importFromId The id of the existing ChimeMediaInsightsPipelineConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeMediaInsightsPipelineConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/chime_media_insights_pipeline_configuration awscc_chime_media_insights_pipeline_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeMediaInsightsPipelineConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: ChimeMediaInsightsPipelineConfigurationConfig);
    get createdTimestamp(): string;
    private _elements;
    get elements(): ChimeMediaInsightsPipelineConfigurationElementsList;
    putElements(value: ChimeMediaInsightsPipelineConfigurationElements[] | cdktn.IResolvable): void;
    get elementsInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationElements[] | undefined;
    get id(): string;
    get mediaInsightsPipelineConfigurationArn(): string;
    get mediaInsightsPipelineConfigurationId(): string;
    private _mediaInsightsPipelineConfigurationName?;
    get mediaInsightsPipelineConfigurationName(): string;
    set mediaInsightsPipelineConfigurationName(value: string);
    get mediaInsightsPipelineConfigurationNameInput(): string | undefined;
    private _realTimeAlertConfiguration;
    get realTimeAlertConfiguration(): ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfigurationOutputReference;
    putRealTimeAlertConfiguration(value: ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfiguration): void;
    resetRealTimeAlertConfiguration(): void;
    get realTimeAlertConfigurationInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationRealTimeAlertConfiguration | undefined;
    private _resourceAccessRoleArn?;
    get resourceAccessRoleArn(): string;
    set resourceAccessRoleArn(value: string);
    get resourceAccessRoleArnInput(): string | undefined;
    private _tags;
    get tags(): ChimeMediaInsightsPipelineConfigurationTagsList;
    putTags(value: ChimeMediaInsightsPipelineConfigurationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeMediaInsightsPipelineConfigurationTags[] | undefined;
    get updatedTimestamp(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
