/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApprunnerVpcIngressConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The configuration of customer?s VPC and related VPC endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#ingress_vpc_configuration ApprunnerVpcIngressConnection#ingress_vpc_configuration}
    */
    readonly ingressVpcConfiguration: ApprunnerVpcIngressConnectionIngressVpcConfiguration;
    /**
    * The Amazon Resource Name (ARN) of the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#service_arn ApprunnerVpcIngressConnection#service_arn}
    */
    readonly serviceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#tags ApprunnerVpcIngressConnection#tags}
    */
    readonly tags?: ApprunnerVpcIngressConnectionTags[] | cdktn.IResolvable;
    /**
    * The customer-provided Vpc Ingress Connection name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#vpc_ingress_connection_name ApprunnerVpcIngressConnection#vpc_ingress_connection_name}
    */
    readonly vpcIngressConnectionName?: string;
}
export interface ApprunnerVpcIngressConnectionIngressVpcConfiguration {
    /**
    * The ID of the VPC endpoint that your App Runner service connects to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#vpc_endpoint_id ApprunnerVpcIngressConnection#vpc_endpoint_id}
    */
    readonly vpcEndpointId: string;
    /**
    * The ID of the VPC that the VPC endpoint is used in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#vpc_id ApprunnerVpcIngressConnection#vpc_id}
    */
    readonly vpcId: string;
}
export declare function apprunnerVpcIngressConnectionIngressVpcConfigurationToTerraform(struct?: ApprunnerVpcIngressConnectionIngressVpcConfiguration | cdktn.IResolvable): any;
export declare function apprunnerVpcIngressConnectionIngressVpcConfigurationToHclTerraform(struct?: ApprunnerVpcIngressConnectionIngressVpcConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerVpcIngressConnectionIngressVpcConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerVpcIngressConnectionIngressVpcConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerVpcIngressConnectionIngressVpcConfiguration | cdktn.IResolvable | undefined);
    private _vpcEndpointId?;
    get vpcEndpointId(): string;
    set vpcEndpointId(value: string);
    get vpcEndpointIdInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
}
export interface ApprunnerVpcIngressConnectionTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#key ApprunnerVpcIngressConnection#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#value ApprunnerVpcIngressConnection#value}
    */
    readonly value?: string;
}
export declare function apprunnerVpcIngressConnectionTagsToTerraform(struct?: ApprunnerVpcIngressConnectionTags | cdktn.IResolvable): any;
export declare function apprunnerVpcIngressConnectionTagsToHclTerraform(struct?: ApprunnerVpcIngressConnectionTags | cdktn.IResolvable): any;
export declare class ApprunnerVpcIngressConnectionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApprunnerVpcIngressConnectionTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerVpcIngressConnectionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApprunnerVpcIngressConnectionTagsList extends cdktn.ComplexList {
    internalValue?: ApprunnerVpcIngressConnectionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApprunnerVpcIngressConnectionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection awscc_apprunner_vpc_ingress_connection}
*/
export declare class ApprunnerVpcIngressConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apprunner_vpc_ingress_connection";
    /**
    * Generates CDKTN code for importing a ApprunnerVpcIngressConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApprunnerVpcIngressConnection to import
    * @param importFromId The id of the existing ApprunnerVpcIngressConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApprunnerVpcIngressConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/apprunner_vpc_ingress_connection awscc_apprunner_vpc_ingress_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApprunnerVpcIngressConnectionConfig
    */
    constructor(scope: Construct, id: string, config: ApprunnerVpcIngressConnectionConfig);
    get domainName(): string;
    get id(): string;
    private _ingressVpcConfiguration;
    get ingressVpcConfiguration(): ApprunnerVpcIngressConnectionIngressVpcConfigurationOutputReference;
    putIngressVpcConfiguration(value: ApprunnerVpcIngressConnectionIngressVpcConfiguration): void;
    get ingressVpcConfigurationInput(): cdktn.IResolvable | ApprunnerVpcIngressConnectionIngressVpcConfiguration | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): ApprunnerVpcIngressConnectionTagsList;
    putTags(value: ApprunnerVpcIngressConnectionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApprunnerVpcIngressConnectionTags[] | undefined;
    get vpcIngressConnectionArn(): string;
    private _vpcIngressConnectionName?;
    get vpcIngressConnectionName(): string;
    set vpcIngressConnectionName(value: string);
    resetVpcIngressConnectionName(): void;
    get vpcIngressConnectionNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
