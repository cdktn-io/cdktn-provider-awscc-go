/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectUserHierarchyGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group#instance_arn ConnectUserHierarchyGroup#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the user hierarchy group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group#name ConnectUserHierarchyGroup#name}
    */
    readonly name: string;
    /**
    * The Amazon Resource Name (ARN) for the parent user hierarchy group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group#parent_group_arn ConnectUserHierarchyGroup#parent_group_arn}
    */
    readonly parentGroupArn?: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group#tags ConnectUserHierarchyGroup#tags}
    */
    readonly tags?: ConnectUserHierarchyGroupTags[] | cdktn.IResolvable;
}
export interface ConnectUserHierarchyGroupTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group#key ConnectUserHierarchyGroup#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group#value ConnectUserHierarchyGroup#value}
    */
    readonly value?: string;
}
export declare function connectUserHierarchyGroupTagsToTerraform(struct?: ConnectUserHierarchyGroupTags | cdktn.IResolvable): any;
export declare function connectUserHierarchyGroupTagsToHclTerraform(struct?: ConnectUserHierarchyGroupTags | cdktn.IResolvable): any;
export declare class ConnectUserHierarchyGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUserHierarchyGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserHierarchyGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectUserHierarchyGroupTagsList extends cdktn.ComplexList {
    internalValue?: ConnectUserHierarchyGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUserHierarchyGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group awscc_connect_user_hierarchy_group}
*/
export declare class ConnectUserHierarchyGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_user_hierarchy_group";
    /**
    * Generates CDKTN code for importing a ConnectUserHierarchyGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectUserHierarchyGroup to import
    * @param importFromId The id of the existing ConnectUserHierarchyGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectUserHierarchyGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_user_hierarchy_group awscc_connect_user_hierarchy_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectUserHierarchyGroupConfig
    */
    constructor(scope: Construct, id: string, config: ConnectUserHierarchyGroupConfig);
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentGroupArn?;
    get parentGroupArn(): string;
    set parentGroupArn(value: string);
    resetParentGroupArn(): void;
    get parentGroupArnInput(): string | undefined;
    private _tags;
    get tags(): ConnectUserHierarchyGroupTagsList;
    putTags(value: ConnectUserHierarchyGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectUserHierarchyGroupTags[] | undefined;
    get userHierarchyGroupArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
