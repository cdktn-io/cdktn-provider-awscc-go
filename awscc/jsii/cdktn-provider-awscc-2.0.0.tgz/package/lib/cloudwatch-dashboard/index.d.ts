/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchDashboardConfig extends cdktn.TerraformMetaArguments {
    /**
    * The detailed information about the dashboard in JSON format, including the widgets to include and their location on the dashboard
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_dashboard#dashboard_body CloudwatchDashboard#dashboard_body}
    */
    readonly dashboardBody: string;
    /**
    * The name of the dashboard. The name must be between 1 and 255 characters. If you do not specify a name, one will be generated automatically.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_dashboard#dashboard_name CloudwatchDashboard#dashboard_name}
    */
    readonly dashboardName?: string;
    /**
    * A list of key-value pairs to associate with the cloudwatch dashboard. You can associate up to 50 tags with a dashboard
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_dashboard#tags CloudwatchDashboard#tags}
    */
    readonly tags?: CloudwatchDashboardTags[] | cdktn.IResolvable;
}
export interface CloudwatchDashboardTags {
    /**
    * A unique identifier for the tag. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_dashboard#key CloudwatchDashboard#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_dashboard#value CloudwatchDashboard#value}
    */
    readonly value?: string;
}
export declare function cloudwatchDashboardTagsToTerraform(struct?: CloudwatchDashboardTags | cdktn.IResolvable): any;
export declare function cloudwatchDashboardTagsToHclTerraform(struct?: CloudwatchDashboardTags | cdktn.IResolvable): any;
export declare class CloudwatchDashboardTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchDashboardTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDashboardTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchDashboardTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchDashboardTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchDashboardTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_dashboard awscc_cloudwatch_dashboard}
*/
export declare class CloudwatchDashboard extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_dashboard";
    /**
    * Generates CDKTN code for importing a CloudwatchDashboard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchDashboard to import
    * @param importFromId The id of the existing CloudwatchDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cloudwatch_dashboard awscc_cloudwatch_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchDashboardConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchDashboardConfig);
    private _dashboardBody?;
    get dashboardBody(): string;
    set dashboardBody(value: string);
    get dashboardBodyInput(): string | undefined;
    private _dashboardName?;
    get dashboardName(): string;
    set dashboardName(value: string);
    resetDashboardName(): void;
    get dashboardNameInput(): string | undefined;
    get id(): string;
    private _tags;
    get tags(): CloudwatchDashboardTagsList;
    putTags(value: CloudwatchDashboardTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchDashboardTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
