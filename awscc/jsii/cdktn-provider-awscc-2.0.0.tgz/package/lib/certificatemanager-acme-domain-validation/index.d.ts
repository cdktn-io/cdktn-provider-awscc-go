/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificatemanagerAcmeDomainValidationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the ACME endpoint this domain validation is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#acme_endpoint_arn CertificatemanagerAcmeDomainValidation#acme_endpoint_arn}
    */
    readonly acmeEndpointArn: string;
    /**
    * The domain name to validate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#domain_name CertificatemanagerAcmeDomainValidation#domain_name}
    */
    readonly domainName: string;
    /**
    * Prevalidation method configuration. Currently only DNS-based prevalidation is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#prevalidation_options CertificatemanagerAcmeDomainValidation#prevalidation_options}
    */
    readonly prevalidationOptions: CertificatemanagerAcmeDomainValidationPrevalidationOptions;
    /**
    * Tags associated with the domain validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#tags CertificatemanagerAcmeDomainValidation#tags}
    */
    readonly tags?: CertificatemanagerAcmeDomainValidationTags[] | cdktn.IResolvable;
}
export interface CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScope {
    /**
    * Whether certificates may be issued for the exact domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#exact_domain CertificatemanagerAcmeDomainValidation#exact_domain}
    */
    readonly exactDomain?: string;
    /**
    * Whether certificates may be issued for subdomains of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#subdomains CertificatemanagerAcmeDomainValidation#subdomains}
    */
    readonly subdomains?: string;
    /**
    * Whether wildcard certificates may be issued for the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#wildcards CertificatemanagerAcmeDomainValidation#wildcards}
    */
    readonly wildcards?: string;
}
export declare function certificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScopeToTerraform(struct?: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScope | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScopeToHclTerraform(struct?: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScope | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScope | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScope | cdktn.IResolvable | undefined);
    private _exactDomain?;
    get exactDomain(): string;
    set exactDomain(value: string);
    resetExactDomain(): void;
    get exactDomainInput(): string | undefined;
    private _subdomains?;
    get subdomains(): string;
    set subdomains(value: string);
    resetSubdomains(): void;
    get subdomainsInput(): string | undefined;
    private _wildcards?;
    get wildcards(): string;
    set wildcards(value: string);
    resetWildcards(): void;
    get wildcardsInput(): string | undefined;
}
export interface CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidation {
    /**
    * Controls which certificate types are authorized to be issued for the domain via the ACME endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#domain_scope CertificatemanagerAcmeDomainValidation#domain_scope}
    */
    readonly domainScope?: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScope;
    /**
    * The Route 53 hosted zone ID for automatic DNS record management. When provided, the service creates the validation DNS record on the customer's behalf.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#hosted_zone_id CertificatemanagerAcmeDomainValidation#hosted_zone_id}
    */
    readonly hostedZoneId?: string;
}
export declare function certificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationToTerraform(struct?: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidation | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationToHclTerraform(struct?: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidation | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidation | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidation | cdktn.IResolvable | undefined);
    private _domainScope;
    get domainScope(): CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScopeOutputReference;
    putDomainScope(value: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScope): void;
    resetDomainScope(): void;
    get domainScopeInput(): cdktn.IResolvable | CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationDomainScope | undefined;
    private _hostedZoneId?;
    get hostedZoneId(): string;
    set hostedZoneId(value: string);
    resetHostedZoneId(): void;
    get hostedZoneIdInput(): string | undefined;
}
export interface CertificatemanagerAcmeDomainValidationPrevalidationOptions {
    /**
    * DNS-based prevalidation options for the domain validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#dns_prevalidation CertificatemanagerAcmeDomainValidation#dns_prevalidation}
    */
    readonly dnsPrevalidation: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidation;
}
export declare function certificatemanagerAcmeDomainValidationPrevalidationOptionsToTerraform(struct?: CertificatemanagerAcmeDomainValidationPrevalidationOptions | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeDomainValidationPrevalidationOptionsToHclTerraform(struct?: CertificatemanagerAcmeDomainValidationPrevalidationOptions | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeDomainValidationPrevalidationOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificatemanagerAcmeDomainValidationPrevalidationOptions | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeDomainValidationPrevalidationOptions | cdktn.IResolvable | undefined);
    private _dnsPrevalidation;
    get dnsPrevalidation(): CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidationOutputReference;
    putDnsPrevalidation(value: CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidation): void;
    get dnsPrevalidationInput(): cdktn.IResolvable | CertificatemanagerAcmeDomainValidationPrevalidationOptionsDnsPrevalidation | undefined;
}
export interface CertificatemanagerAcmeDomainValidationTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#key CertificatemanagerAcmeDomainValidation#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#value CertificatemanagerAcmeDomainValidation#value}
    */
    readonly value?: string;
}
export declare function certificatemanagerAcmeDomainValidationTagsToTerraform(struct?: CertificatemanagerAcmeDomainValidationTags | cdktn.IResolvable): any;
export declare function certificatemanagerAcmeDomainValidationTagsToHclTerraform(struct?: CertificatemanagerAcmeDomainValidationTags | cdktn.IResolvable): any;
export declare class CertificatemanagerAcmeDomainValidationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertificatemanagerAcmeDomainValidationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAcmeDomainValidationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CertificatemanagerAcmeDomainValidationTagsList extends cdktn.ComplexList {
    internalValue?: CertificatemanagerAcmeDomainValidationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertificatemanagerAcmeDomainValidationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation awscc_certificatemanager_acme_domain_validation}
*/
export declare class CertificatemanagerAcmeDomainValidation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_certificatemanager_acme_domain_validation";
    /**
    * Generates CDKTN code for importing a CertificatemanagerAcmeDomainValidation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificatemanagerAcmeDomainValidation to import
    * @param importFromId The id of the existing CertificatemanagerAcmeDomainValidation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificatemanagerAcmeDomainValidation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/certificatemanager_acme_domain_validation awscc_certificatemanager_acme_domain_validation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificatemanagerAcmeDomainValidationConfig
    */
    constructor(scope: Construct, id: string, config: CertificatemanagerAcmeDomainValidationConfig);
    private _acmeEndpointArn?;
    get acmeEndpointArn(): string;
    set acmeEndpointArn(value: string);
    get acmeEndpointArnInput(): string | undefined;
    get arn(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get id(): string;
    private _prevalidationOptions;
    get prevalidationOptions(): CertificatemanagerAcmeDomainValidationPrevalidationOptionsOutputReference;
    putPrevalidationOptions(value: CertificatemanagerAcmeDomainValidationPrevalidationOptions): void;
    get prevalidationOptionsInput(): cdktn.IResolvable | CertificatemanagerAcmeDomainValidationPrevalidationOptions | undefined;
    private _tags;
    get tags(): CertificatemanagerAcmeDomainValidationTagsList;
    putTags(value: CertificatemanagerAcmeDomainValidationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CertificatemanagerAcmeDomainValidationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
