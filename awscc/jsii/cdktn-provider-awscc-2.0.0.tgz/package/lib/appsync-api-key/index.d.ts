/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unique AWS AppSync GraphQL API ID for this API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appsync_api_key#api_id AppsyncApiKey#api_id}
    */
    readonly apiId: string;
    /**
    * Unique description of your API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appsync_api_key#description AppsyncApiKey#description}
    */
    readonly description?: string;
    /**
    * The time after which the API key expires. The date is represented as seconds since the epoch, rounded down to the nearest hour.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appsync_api_key#expires AppsyncApiKey#expires}
    */
    readonly expires?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appsync_api_key awscc_appsync_api_key}
*/
export declare class AppsyncApiKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_api_key";
    /**
    * Generates CDKTN code for importing a AppsyncApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncApiKey to import
    * @param importFromId The id of the existing AppsyncApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appsync_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appsync_api_key awscc_appsync_api_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncApiKeyConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get apiKey(): string;
    get apiKeyId(): string;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expires?;
    get expires(): number;
    set expires(value: number);
    resetExpires(): void;
    get expiresInput(): number | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
