/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcorePaymentCredentialProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Supported vendor types for payment providers
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#credential_provider_vendor BedrockagentcorePaymentCredentialProvider#credential_provider_vendor}
    */
    readonly credentialProviderVendor: string;
    /**
    * Unique name for the payment credential provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#name BedrockagentcorePaymentCredentialProvider#name}
    */
    readonly name: string;
    /**
    * Provider configuration input containing secrets for creation/update
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#provider_configuration_input BedrockagentcorePaymentCredentialProvider#provider_configuration_input}
    */
    readonly providerConfigurationInput?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInput;
    /**
    * Tags for the payment credential provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#tags BedrockagentcorePaymentCredentialProvider#tags}
    */
    readonly tags?: BedrockagentcorePaymentCredentialProviderTags[] | cdktn.IResolvable;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfig {
    /**
    * The JSON key within the secret that contains the credential value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#json_key BedrockagentcorePaymentCredentialProvider#json_key}
    */
    readonly jsonKey?: string;
    /**
    * The ID or ARN of the secret in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#secret_id BedrockagentcorePaymentCredentialProvider#secret_id}
    */
    readonly secretId?: string;
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfigToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfig | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfigToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfig | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfig | cdktn.IResolvable | undefined);
    private _jsonKey?;
    get jsonKey(): string;
    set jsonKey(value: string);
    resetJsonKey(): void;
    get jsonKeyInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    resetSecretId(): void;
    get secretIdInput(): string | undefined;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfig {
    /**
    * The JSON key within the secret that contains the credential value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#json_key BedrockagentcorePaymentCredentialProvider#json_key}
    */
    readonly jsonKey?: string;
    /**
    * The ID or ARN of the secret in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#secret_id BedrockagentcorePaymentCredentialProvider#secret_id}
    */
    readonly secretId?: string;
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfigToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfig | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfigToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfig | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfig | cdktn.IResolvable | undefined);
    private _jsonKey?;
    get jsonKey(): string;
    set jsonKey(value: string);
    resetJsonKey(): void;
    get jsonKeyInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    resetSecretId(): void;
    get secretIdInput(): string | undefined;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfiguration {
    /**
    * The Coinbase CDP API key ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#api_key_id BedrockagentcorePaymentCredentialProvider#api_key_id}
    */
    readonly apiKeyId?: string;
    /**
    * The Coinbase CDP API key secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#api_key_secret BedrockagentcorePaymentCredentialProvider#api_key_secret}
    */
    readonly apiKeySecret?: string;
    /**
    * A reference to a customer-provided secret stored in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#api_key_secret_config BedrockagentcorePaymentCredentialProvider#api_key_secret_config}
    */
    readonly apiKeySecretConfig?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfig;
    /**
    * The source of the secret. Use MANAGED for service-managed secrets or EXTERNAL for customer-provided secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#api_key_secret_source BedrockagentcorePaymentCredentialProvider#api_key_secret_source}
    */
    readonly apiKeySecretSource?: string;
    /**
    * The Coinbase CDP wallet secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#wallet_secret BedrockagentcorePaymentCredentialProvider#wallet_secret}
    */
    readonly walletSecret?: string;
    /**
    * A reference to a customer-provided secret stored in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#wallet_secret_config BedrockagentcorePaymentCredentialProvider#wallet_secret_config}
    */
    readonly walletSecretConfig?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfig;
    /**
    * The source of the secret. Use MANAGED for service-managed secrets or EXTERNAL for customer-provided secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#wallet_secret_source BedrockagentcorePaymentCredentialProvider#wallet_secret_source}
    */
    readonly walletSecretSource?: string;
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfiguration | cdktn.IResolvable | undefined);
    private _apiKeyId?;
    get apiKeyId(): string;
    set apiKeyId(value: string);
    resetApiKeyId(): void;
    get apiKeyIdInput(): string | undefined;
    private _apiKeySecret?;
    get apiKeySecret(): string;
    set apiKeySecret(value: string);
    resetApiKeySecret(): void;
    get apiKeySecretInput(): string | undefined;
    private _apiKeySecretConfig;
    get apiKeySecretConfig(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfigOutputReference;
    putApiKeySecretConfig(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfig): void;
    resetApiKeySecretConfig(): void;
    get apiKeySecretConfigInput(): cdktn.IResolvable | BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationApiKeySecretConfig | undefined;
    private _apiKeySecretSource?;
    get apiKeySecretSource(): string;
    set apiKeySecretSource(value: string);
    resetApiKeySecretSource(): void;
    get apiKeySecretSourceInput(): string | undefined;
    private _walletSecret?;
    get walletSecret(): string;
    set walletSecret(value: string);
    resetWalletSecret(): void;
    get walletSecretInput(): string | undefined;
    private _walletSecretConfig;
    get walletSecretConfig(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfigOutputReference;
    putWalletSecretConfig(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfig): void;
    resetWalletSecretConfig(): void;
    get walletSecretConfigInput(): cdktn.IResolvable | BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationWalletSecretConfig | undefined;
    private _walletSecretSource?;
    get walletSecretSource(): string;
    set walletSecretSource(value: string);
    resetWalletSecretSource(): void;
    get walletSecretSourceInput(): string | undefined;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfig {
    /**
    * The JSON key within the secret that contains the credential value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#json_key BedrockagentcorePaymentCredentialProvider#json_key}
    */
    readonly jsonKey?: string;
    /**
    * The ID or ARN of the secret in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#secret_id BedrockagentcorePaymentCredentialProvider#secret_id}
    */
    readonly secretId?: string;
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfigToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfig | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfigToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfig | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfig | cdktn.IResolvable | undefined);
    private _jsonKey?;
    get jsonKey(): string;
    set jsonKey(value: string);
    resetJsonKey(): void;
    get jsonKeyInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    resetSecretId(): void;
    get secretIdInput(): string | undefined;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfig {
    /**
    * The JSON key within the secret that contains the credential value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#json_key BedrockagentcorePaymentCredentialProvider#json_key}
    */
    readonly jsonKey?: string;
    /**
    * The ID or ARN of the secret in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#secret_id BedrockagentcorePaymentCredentialProvider#secret_id}
    */
    readonly secretId?: string;
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfigToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfig | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfigToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfig | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfig | cdktn.IResolvable | undefined);
    private _jsonKey?;
    get jsonKey(): string;
    set jsonKey(value: string);
    resetJsonKey(): void;
    get jsonKeyInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    resetSecretId(): void;
    get secretIdInput(): string | undefined;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfiguration {
    /**
    * The app ID provided by Privy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#app_id BedrockagentcorePaymentCredentialProvider#app_id}
    */
    readonly appId?: string;
    /**
    * The app secret provided by Privy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#app_secret BedrockagentcorePaymentCredentialProvider#app_secret}
    */
    readonly appSecret?: string;
    /**
    * A reference to a customer-provided secret stored in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#app_secret_config BedrockagentcorePaymentCredentialProvider#app_secret_config}
    */
    readonly appSecretConfig?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfig;
    /**
    * The source of the secret. Use MANAGED for service-managed secrets or EXTERNAL for customer-provided secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#app_secret_source BedrockagentcorePaymentCredentialProvider#app_secret_source}
    */
    readonly appSecretSource?: string;
    /**
    * The authorization ID for the Stripe Privy integration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#authorization_id BedrockagentcorePaymentCredentialProvider#authorization_id}
    */
    readonly authorizationId?: string;
    /**
    * The authorization private key for the Stripe Privy integration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#authorization_private_key BedrockagentcorePaymentCredentialProvider#authorization_private_key}
    */
    readonly authorizationPrivateKey?: string;
    /**
    * A reference to a customer-provided secret stored in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#authorization_private_key_config BedrockagentcorePaymentCredentialProvider#authorization_private_key_config}
    */
    readonly authorizationPrivateKeyConfig?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfig;
    /**
    * The source of the secret. Use MANAGED for service-managed secrets or EXTERNAL for customer-provided secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#authorization_private_key_source BedrockagentcorePaymentCredentialProvider#authorization_private_key_source}
    */
    readonly authorizationPrivateKeySource?: string;
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfiguration | cdktn.IResolvable | undefined);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    resetAppId(): void;
    get appIdInput(): string | undefined;
    private _appSecret?;
    get appSecret(): string;
    set appSecret(value: string);
    resetAppSecret(): void;
    get appSecretInput(): string | undefined;
    private _appSecretConfig;
    get appSecretConfig(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfigOutputReference;
    putAppSecretConfig(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfig): void;
    resetAppSecretConfig(): void;
    get appSecretConfigInput(): cdktn.IResolvable | BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAppSecretConfig | undefined;
    private _appSecretSource?;
    get appSecretSource(): string;
    set appSecretSource(value: string);
    resetAppSecretSource(): void;
    get appSecretSourceInput(): string | undefined;
    private _authorizationId?;
    get authorizationId(): string;
    set authorizationId(value: string);
    resetAuthorizationId(): void;
    get authorizationIdInput(): string | undefined;
    private _authorizationPrivateKey?;
    get authorizationPrivateKey(): string;
    set authorizationPrivateKey(value: string);
    resetAuthorizationPrivateKey(): void;
    get authorizationPrivateKeyInput(): string | undefined;
    private _authorizationPrivateKeyConfig;
    get authorizationPrivateKeyConfig(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfigOutputReference;
    putAuthorizationPrivateKeyConfig(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfig): void;
    resetAuthorizationPrivateKeyConfig(): void;
    get authorizationPrivateKeyConfigInput(): cdktn.IResolvable | BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationAuthorizationPrivateKeyConfig | undefined;
    private _authorizationPrivateKeySource?;
    get authorizationPrivateKeySource(): string;
    set authorizationPrivateKeySource(value: string);
    resetAuthorizationPrivateKeySource(): void;
    get authorizationPrivateKeySourceInput(): string | undefined;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationInput {
    /**
    * Coinbase CDP configuration with API credentials
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#coinbase_cdp_configuration BedrockagentcorePaymentCredentialProvider#coinbase_cdp_configuration}
    */
    readonly coinbaseCdpConfiguration?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfiguration;
    /**
    * Stripe Privy configuration with credentials
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#stripe_privy_configuration BedrockagentcorePaymentCredentialProvider#stripe_privy_configuration}
    */
    readonly stripePrivyConfiguration?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfiguration;
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInput | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationInputToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationInput | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInput | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInput | cdktn.IResolvable | undefined);
    private _coinbaseCdpConfiguration;
    get coinbaseCdpConfiguration(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfigurationOutputReference;
    putCoinbaseCdpConfiguration(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfiguration): void;
    resetCoinbaseCdpConfiguration(): void;
    get coinbaseCdpConfigurationInput(): cdktn.IResolvable | BedrockagentcorePaymentCredentialProviderProviderConfigurationInputCoinbaseCdpConfiguration | undefined;
    private _stripePrivyConfiguration;
    get stripePrivyConfiguration(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfigurationOutputReference;
    putStripePrivyConfiguration(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfiguration): void;
    resetStripePrivyConfiguration(): void;
    get stripePrivyConfigurationInput(): cdktn.IResolvable | BedrockagentcorePaymentCredentialProviderProviderConfigurationInputStripePrivyConfiguration | undefined;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArn {
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArnToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArn): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArnToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArn): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArn | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArn | undefined);
    get secretArn(): string;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArn {
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArnToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArn): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArnToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArn): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArn | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArn | undefined);
    get secretArn(): string;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfiguration {
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfiguration): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfiguration): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfiguration | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfiguration | undefined);
    get apiKeyId(): string;
    private _apiKeySecretArn;
    get apiKeySecretArn(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationApiKeySecretArnOutputReference;
    get apiKeySecretJsonKey(): string;
    get apiKeySecretSource(): string;
    private _walletSecretArn;
    get walletSecretArn(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationWalletSecretArnOutputReference;
    get walletSecretJsonKey(): string;
    get walletSecretSource(): string;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArn {
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArnToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArn): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArnToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArn): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArn | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArn | undefined);
    get secretArn(): string;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArn {
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArnToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArn): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArnToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArn): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArn | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArn | undefined);
    get secretArn(): string;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfiguration {
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfiguration): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfiguration): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfiguration | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfiguration | undefined);
    get appId(): string;
    private _appSecretArn;
    get appSecretArn(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAppSecretArnOutputReference;
    get appSecretJsonKey(): string;
    get appSecretSource(): string;
    get authorizationId(): string;
    private _authorizationPrivateKeyArn;
    get authorizationPrivateKeyArn(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationAuthorizationPrivateKeyArnOutputReference;
    get authorizationPrivateKeyJsonKey(): string;
    get authorizationPrivateKeySource(): string;
}
export interface BedrockagentcorePaymentCredentialProviderProviderConfigurationOutput {
}
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputToTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutput): any;
export declare function bedrockagentcorePaymentCredentialProviderProviderConfigurationOutputToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutput): any;
export declare class BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutput | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationOutput | undefined);
    private _coinbaseCdpConfiguration;
    get coinbaseCdpConfiguration(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputCoinbaseCdpConfigurationOutputReference;
    private _stripePrivyConfiguration;
    get stripePrivyConfiguration(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputStripePrivyConfigurationOutputReference;
}
export interface BedrockagentcorePaymentCredentialProviderTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#key BedrockagentcorePaymentCredentialProvider#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#value BedrockagentcorePaymentCredentialProvider#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcorePaymentCredentialProviderTagsToTerraform(struct?: BedrockagentcorePaymentCredentialProviderTags | cdktn.IResolvable): any;
export declare function bedrockagentcorePaymentCredentialProviderTagsToHclTerraform(struct?: BedrockagentcorePaymentCredentialProviderTags | cdktn.IResolvable): any;
export declare class BedrockagentcorePaymentCredentialProviderTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcorePaymentCredentialProviderTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePaymentCredentialProviderTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcorePaymentCredentialProviderTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcorePaymentCredentialProviderTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcorePaymentCredentialProviderTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider awscc_bedrockagentcore_payment_credential_provider}
*/
export declare class BedrockagentcorePaymentCredentialProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_payment_credential_provider";
    /**
    * Generates CDKTN code for importing a BedrockagentcorePaymentCredentialProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcorePaymentCredentialProvider to import
    * @param importFromId The id of the existing BedrockagentcorePaymentCredentialProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcorePaymentCredentialProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_payment_credential_provider awscc_bedrockagentcore_payment_credential_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcorePaymentCredentialProviderConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcorePaymentCredentialProviderConfig);
    get createdTime(): string;
    get credentialProviderArn(): string;
    private _credentialProviderVendor?;
    get credentialProviderVendor(): string;
    set credentialProviderVendor(value: string);
    get credentialProviderVendorInput(): string | undefined;
    get id(): string;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfigurationInput;
    get providerConfigurationInput(): BedrockagentcorePaymentCredentialProviderProviderConfigurationInputOutputReference;
    putProviderConfigurationInput(value: BedrockagentcorePaymentCredentialProviderProviderConfigurationInput): void;
    resetProviderConfigurationInput(): void;
    get providerConfigurationInputInput(): cdktn.IResolvable | BedrockagentcorePaymentCredentialProviderProviderConfigurationInput | undefined;
    private _providerConfigurationOutput;
    get providerConfigurationOutput(): BedrockagentcorePaymentCredentialProviderProviderConfigurationOutputOutputReference;
    private _tags;
    get tags(): BedrockagentcorePaymentCredentialProviderTagsList;
    putTags(value: BedrockagentcorePaymentCredentialProviderTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcorePaymentCredentialProviderTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
