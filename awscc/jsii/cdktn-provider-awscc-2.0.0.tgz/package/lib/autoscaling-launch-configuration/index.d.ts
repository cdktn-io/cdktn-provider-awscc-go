/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AutoscalingLaunchConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * For Auto Scaling groups that are running in a virtual private cloud (VPC), specifies whether to assign a public IP address to the group's instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#associate_public_ip_address AutoscalingLaunchConfiguration#associate_public_ip_address}
    */
    readonly associatePublicIpAddress?: boolean | cdktn.IResolvable;
    /**
    * Specifies how block devices are exposed to the instance. You can specify virtual devices and EBS volumes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#block_device_mappings AutoscalingLaunchConfiguration#block_device_mappings}
    */
    readonly blockDeviceMappings?: AutoscalingLaunchConfigurationBlockDeviceMappings[] | cdktn.IResolvable;
    /**
    * The ID of a ClassicLink-enabled VPC to link your EC2-Classic instances to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#classic_link_vpc_id AutoscalingLaunchConfiguration#classic_link_vpc_id}
    */
    readonly classicLinkVpcId?: string;
    /**
    * The IDs of one or more security groups for the VPC that you specified in the ClassicLinkVPCId property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#classic_link_vpc_security_groups AutoscalingLaunchConfiguration#classic_link_vpc_security_groups}
    */
    readonly classicLinkVpcSecurityGroups?: string[];
    /**
    * Specifies whether the launch configuration is optimized for EBS I/O (true) or not (false).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#ebs_optimized AutoscalingLaunchConfiguration#ebs_optimized}
    */
    readonly ebsOptimized?: boolean | cdktn.IResolvable;
    /**
    * Provides the name or the Amazon Resource Name (ARN) of the instance profile associated with the IAM role for the instance. The instance profile contains the IAM role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#iam_instance_profile AutoscalingLaunchConfiguration#iam_instance_profile}
    */
    readonly iamInstanceProfile?: string;
    /**
    * Provides the unique ID of the Amazon Machine Image (AMI) that was assigned during registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#image_id AutoscalingLaunchConfiguration#image_id}
    */
    readonly imageId: string;
    /**
    * The ID of the Amazon EC2 instance you want to use to create the launch configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#instance_id AutoscalingLaunchConfiguration#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Controls whether instances in this group are launched with detailed (true) or basic (false) monitoring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#instance_monitoring AutoscalingLaunchConfiguration#instance_monitoring}
    */
    readonly instanceMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Specifies the instance type of the EC2 instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#instance_type AutoscalingLaunchConfiguration#instance_type}
    */
    readonly instanceType: string;
    /**
    * Provides the ID of the kernel associated with the EC2 AMI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#kernel_id AutoscalingLaunchConfiguration#kernel_id}
    */
    readonly kernelId?: string;
    /**
    * Provides the name of the EC2 key pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#key_name AutoscalingLaunchConfiguration#key_name}
    */
    readonly keyName?: string;
    /**
    * The name of the launch configuration. This name must be unique per Region per account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#launch_configuration_name AutoscalingLaunchConfiguration#launch_configuration_name}
    */
    readonly launchConfigurationName?: string;
    /**
    * The metadata options for the instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#metadata_options AutoscalingLaunchConfiguration#metadata_options}
    */
    readonly metadataOptions?: AutoscalingLaunchConfigurationMetadataOptions;
    /**
    * The tenancy of the instance, either default or dedicated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#placement_tenancy AutoscalingLaunchConfiguration#placement_tenancy}
    */
    readonly placementTenancy?: string;
    /**
    * The ID of the RAM disk to select.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#ram_disk_id AutoscalingLaunchConfiguration#ram_disk_id}
    */
    readonly ramDiskId?: string;
    /**
    * A list that contains the security groups to assign to the instances in the Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#security_groups AutoscalingLaunchConfiguration#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * The maximum hourly price you are willing to pay for any Spot Instances launched to fulfill the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#spot_price AutoscalingLaunchConfiguration#spot_price}
    */
    readonly spotPrice?: string;
    /**
    * The Base64-encoded user data to make available to the launched EC2 instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#user_data AutoscalingLaunchConfiguration#user_data}
    */
    readonly userData?: string;
}
export interface AutoscalingLaunchConfigurationBlockDeviceMappingsEbs {
    /**
    * Indicates whether the volume is deleted on instance termination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#delete_on_termination AutoscalingLaunchConfiguration#delete_on_termination}
    */
    readonly deleteOnTermination?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether the volume should be encrypted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#encrypted AutoscalingLaunchConfiguration#encrypted}
    */
    readonly encrypted?: boolean | cdktn.IResolvable;
    /**
    * The number of input/output (I/O) operations per second (IOPS) to provision for the volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#iops AutoscalingLaunchConfiguration#iops}
    */
    readonly iops?: number;
    /**
    * The snapshot ID of the volume to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#snapshot_id AutoscalingLaunchConfiguration#snapshot_id}
    */
    readonly snapshotId?: string;
    /**
    * The throughput (MiBps) to provision for a gp3 volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#throughput AutoscalingLaunchConfiguration#throughput}
    */
    readonly throughput?: number;
    /**
    * The volume size, in GiBs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#volume_size AutoscalingLaunchConfiguration#volume_size}
    */
    readonly volumeSize?: number;
    /**
    * The volume type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#volume_type AutoscalingLaunchConfiguration#volume_type}
    */
    readonly volumeType?: string;
}
export declare function autoscalingLaunchConfigurationBlockDeviceMappingsEbsToTerraform(struct?: AutoscalingLaunchConfigurationBlockDeviceMappingsEbs | cdktn.IResolvable): any;
export declare function autoscalingLaunchConfigurationBlockDeviceMappingsEbsToHclTerraform(struct?: AutoscalingLaunchConfigurationBlockDeviceMappingsEbs | cdktn.IResolvable): any;
export declare class AutoscalingLaunchConfigurationBlockDeviceMappingsEbsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingLaunchConfigurationBlockDeviceMappingsEbs | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingLaunchConfigurationBlockDeviceMappingsEbs | cdktn.IResolvable | undefined);
    private _deleteOnTermination?;
    get deleteOnTermination(): boolean | cdktn.IResolvable;
    set deleteOnTermination(value: boolean | cdktn.IResolvable);
    resetDeleteOnTermination(): void;
    get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _encrypted?;
    get encrypted(): boolean | cdktn.IResolvable;
    set encrypted(value: boolean | cdktn.IResolvable);
    resetEncrypted(): void;
    get encryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _iops?;
    get iops(): number;
    set iops(value: number);
    resetIops(): void;
    get iopsInput(): number | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    resetSnapshotId(): void;
    get snapshotIdInput(): string | undefined;
    private _throughput?;
    get throughput(): number;
    set throughput(value: number);
    resetThroughput(): void;
    get throughputInput(): number | undefined;
    private _volumeSize?;
    get volumeSize(): number;
    set volumeSize(value: number);
    resetVolumeSize(): void;
    get volumeSizeInput(): number | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
}
export interface AutoscalingLaunchConfigurationBlockDeviceMappings {
    /**
    * The device name exposed to the EC2 instance (for example, /dev/sdh or xvdh).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#device_name AutoscalingLaunchConfiguration#device_name}
    */
    readonly deviceName?: string;
    /**
    * Parameters used to automatically set up EBS volumes when an instance is launched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#ebs AutoscalingLaunchConfiguration#ebs}
    */
    readonly ebs?: AutoscalingLaunchConfigurationBlockDeviceMappingsEbs;
    /**
    * Setting this value to true suppresses the specified device included in the block device mapping of the AMI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#no_device AutoscalingLaunchConfiguration#no_device}
    */
    readonly noDevice?: boolean | cdktn.IResolvable;
    /**
    * The name of the virtual device.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#virtual_name AutoscalingLaunchConfiguration#virtual_name}
    */
    readonly virtualName?: string;
}
export declare function autoscalingLaunchConfigurationBlockDeviceMappingsToTerraform(struct?: AutoscalingLaunchConfigurationBlockDeviceMappings | cdktn.IResolvable): any;
export declare function autoscalingLaunchConfigurationBlockDeviceMappingsToHclTerraform(struct?: AutoscalingLaunchConfigurationBlockDeviceMappings | cdktn.IResolvable): any;
export declare class AutoscalingLaunchConfigurationBlockDeviceMappingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingLaunchConfigurationBlockDeviceMappings | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingLaunchConfigurationBlockDeviceMappings | cdktn.IResolvable | undefined);
    private _deviceName?;
    get deviceName(): string;
    set deviceName(value: string);
    resetDeviceName(): void;
    get deviceNameInput(): string | undefined;
    private _ebs;
    get ebs(): AutoscalingLaunchConfigurationBlockDeviceMappingsEbsOutputReference;
    putEbs(value: AutoscalingLaunchConfigurationBlockDeviceMappingsEbs): void;
    resetEbs(): void;
    get ebsInput(): cdktn.IResolvable | AutoscalingLaunchConfigurationBlockDeviceMappingsEbs | undefined;
    private _noDevice?;
    get noDevice(): boolean | cdktn.IResolvable;
    set noDevice(value: boolean | cdktn.IResolvable);
    resetNoDevice(): void;
    get noDeviceInput(): boolean | cdktn.IResolvable | undefined;
    private _virtualName?;
    get virtualName(): string;
    set virtualName(value: string);
    resetVirtualName(): void;
    get virtualNameInput(): string | undefined;
}
export declare class AutoscalingLaunchConfigurationBlockDeviceMappingsList extends cdktn.ComplexList {
    internalValue?: AutoscalingLaunchConfigurationBlockDeviceMappings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingLaunchConfigurationBlockDeviceMappingsOutputReference;
}
export interface AutoscalingLaunchConfigurationMetadataOptions {
    /**
    * This parameter enables or disables the HTTP metadata endpoint on your instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#http_endpoint AutoscalingLaunchConfiguration#http_endpoint}
    */
    readonly httpEndpoint?: string;
    /**
    * The desired HTTP PUT response hop limit for instance metadata requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#http_put_response_hop_limit AutoscalingLaunchConfiguration#http_put_response_hop_limit}
    */
    readonly httpPutResponseHopLimit?: number;
    /**
    * The state of token usage for your instance metadata requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#http_tokens AutoscalingLaunchConfiguration#http_tokens}
    */
    readonly httpTokens?: string;
}
export declare function autoscalingLaunchConfigurationMetadataOptionsToTerraform(struct?: AutoscalingLaunchConfigurationMetadataOptions | cdktn.IResolvable): any;
export declare function autoscalingLaunchConfigurationMetadataOptionsToHclTerraform(struct?: AutoscalingLaunchConfigurationMetadataOptions | cdktn.IResolvable): any;
export declare class AutoscalingLaunchConfigurationMetadataOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingLaunchConfigurationMetadataOptions | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingLaunchConfigurationMetadataOptions | cdktn.IResolvable | undefined);
    private _httpEndpoint?;
    get httpEndpoint(): string;
    set httpEndpoint(value: string);
    resetHttpEndpoint(): void;
    get httpEndpointInput(): string | undefined;
    private _httpPutResponseHopLimit?;
    get httpPutResponseHopLimit(): number;
    set httpPutResponseHopLimit(value: number);
    resetHttpPutResponseHopLimit(): void;
    get httpPutResponseHopLimitInput(): number | undefined;
    private _httpTokens?;
    get httpTokens(): string;
    set httpTokens(value: string);
    resetHttpTokens(): void;
    get httpTokensInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration awscc_autoscaling_launch_configuration}
*/
export declare class AutoscalingLaunchConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_autoscaling_launch_configuration";
    /**
    * Generates CDKTN code for importing a AutoscalingLaunchConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutoscalingLaunchConfiguration to import
    * @param importFromId The id of the existing AutoscalingLaunchConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutoscalingLaunchConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/autoscaling_launch_configuration awscc_autoscaling_launch_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutoscalingLaunchConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AutoscalingLaunchConfigurationConfig);
    private _associatePublicIpAddress?;
    get associatePublicIpAddress(): boolean | cdktn.IResolvable;
    set associatePublicIpAddress(value: boolean | cdktn.IResolvable);
    resetAssociatePublicIpAddress(): void;
    get associatePublicIpAddressInput(): boolean | cdktn.IResolvable | undefined;
    private _blockDeviceMappings;
    get blockDeviceMappings(): AutoscalingLaunchConfigurationBlockDeviceMappingsList;
    putBlockDeviceMappings(value: AutoscalingLaunchConfigurationBlockDeviceMappings[] | cdktn.IResolvable): void;
    resetBlockDeviceMappings(): void;
    get blockDeviceMappingsInput(): cdktn.IResolvable | AutoscalingLaunchConfigurationBlockDeviceMappings[] | undefined;
    private _classicLinkVpcId?;
    get classicLinkVpcId(): string;
    set classicLinkVpcId(value: string);
    resetClassicLinkVpcId(): void;
    get classicLinkVpcIdInput(): string | undefined;
    private _classicLinkVpcSecurityGroups?;
    get classicLinkVpcSecurityGroups(): string[];
    set classicLinkVpcSecurityGroups(value: string[]);
    resetClassicLinkVpcSecurityGroups(): void;
    get classicLinkVpcSecurityGroupsInput(): string[] | undefined;
    private _ebsOptimized?;
    get ebsOptimized(): boolean | cdktn.IResolvable;
    set ebsOptimized(value: boolean | cdktn.IResolvable);
    resetEbsOptimized(): void;
    get ebsOptimizedInput(): boolean | cdktn.IResolvable | undefined;
    private _iamInstanceProfile?;
    get iamInstanceProfile(): string;
    set iamInstanceProfile(value: string);
    resetIamInstanceProfile(): void;
    get iamInstanceProfileInput(): string | undefined;
    get id(): string;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    get imageIdInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _instanceMonitoring?;
    get instanceMonitoring(): boolean | cdktn.IResolvable;
    set instanceMonitoring(value: boolean | cdktn.IResolvable);
    resetInstanceMonitoring(): void;
    get instanceMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _kernelId?;
    get kernelId(): string;
    set kernelId(value: string);
    resetKernelId(): void;
    get kernelIdInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    private _launchConfigurationName?;
    get launchConfigurationName(): string;
    set launchConfigurationName(value: string);
    resetLaunchConfigurationName(): void;
    get launchConfigurationNameInput(): string | undefined;
    private _metadataOptions;
    get metadataOptions(): AutoscalingLaunchConfigurationMetadataOptionsOutputReference;
    putMetadataOptions(value: AutoscalingLaunchConfigurationMetadataOptions): void;
    resetMetadataOptions(): void;
    get metadataOptionsInput(): cdktn.IResolvable | AutoscalingLaunchConfigurationMetadataOptions | undefined;
    private _placementTenancy?;
    get placementTenancy(): string;
    set placementTenancy(value: string);
    resetPlacementTenancy(): void;
    get placementTenancyInput(): string | undefined;
    private _ramDiskId?;
    get ramDiskId(): string;
    set ramDiskId(value: string);
    resetRamDiskId(): void;
    get ramDiskIdInput(): string | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _spotPrice?;
    get spotPrice(): string;
    set spotPrice(value: string);
    resetSpotPrice(): void;
    get spotPriceInput(): string | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
