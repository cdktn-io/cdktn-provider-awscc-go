/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsPrivacyBudgetTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#auto_refresh CleanroomsPrivacyBudgetTemplate#auto_refresh}
    */
    readonly autoRefresh: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#membership_identifier CleanroomsPrivacyBudgetTemplate#membership_identifier}
    */
    readonly membershipIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#parameters CleanroomsPrivacyBudgetTemplate#parameters}
    */
    readonly parameters: CleanroomsPrivacyBudgetTemplateParameters;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#privacy_budget_type CleanroomsPrivacyBudgetTemplate#privacy_budget_type}
    */
    readonly privacyBudgetType: string;
    /**
    * An arbitrary set of tags (key-value pairs) for this cleanrooms privacy budget template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#tags CleanroomsPrivacyBudgetTemplate#tags}
    */
    readonly tags?: CleanroomsPrivacyBudgetTemplateTags[] | cdktn.IResolvable;
}
export interface CleanroomsPrivacyBudgetTemplateParametersBudgetParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#auto_refresh CleanroomsPrivacyBudgetTemplate#auto_refresh}
    */
    readonly autoRefresh?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#budget CleanroomsPrivacyBudgetTemplate#budget}
    */
    readonly budget?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#type CleanroomsPrivacyBudgetTemplate#type}
    */
    readonly type?: string;
}
export declare function cleanroomsPrivacyBudgetTemplateParametersBudgetParametersToTerraform(struct?: CleanroomsPrivacyBudgetTemplateParametersBudgetParameters | cdktn.IResolvable): any;
export declare function cleanroomsPrivacyBudgetTemplateParametersBudgetParametersToHclTerraform(struct?: CleanroomsPrivacyBudgetTemplateParametersBudgetParameters | cdktn.IResolvable): any;
export declare class CleanroomsPrivacyBudgetTemplateParametersBudgetParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsPrivacyBudgetTemplateParametersBudgetParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsPrivacyBudgetTemplateParametersBudgetParameters | cdktn.IResolvable | undefined);
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    resetAutoRefresh(): void;
    get autoRefreshInput(): string | undefined;
    private _budget?;
    get budget(): number;
    set budget(value: number);
    resetBudget(): void;
    get budgetInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CleanroomsPrivacyBudgetTemplateParametersBudgetParametersList extends cdktn.ComplexList {
    internalValue?: CleanroomsPrivacyBudgetTemplateParametersBudgetParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsPrivacyBudgetTemplateParametersBudgetParametersOutputReference;
}
export interface CleanroomsPrivacyBudgetTemplateParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#budget_parameters CleanroomsPrivacyBudgetTemplate#budget_parameters}
    */
    readonly budgetParameters?: CleanroomsPrivacyBudgetTemplateParametersBudgetParameters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#epsilon CleanroomsPrivacyBudgetTemplate#epsilon}
    */
    readonly epsilon?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#resource_arn CleanroomsPrivacyBudgetTemplate#resource_arn}
    */
    readonly resourceArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#users_noise_per_query CleanroomsPrivacyBudgetTemplate#users_noise_per_query}
    */
    readonly usersNoisePerQuery?: number;
}
export declare function cleanroomsPrivacyBudgetTemplateParametersToTerraform(struct?: CleanroomsPrivacyBudgetTemplateParameters | cdktn.IResolvable): any;
export declare function cleanroomsPrivacyBudgetTemplateParametersToHclTerraform(struct?: CleanroomsPrivacyBudgetTemplateParameters | cdktn.IResolvable): any;
export declare class CleanroomsPrivacyBudgetTemplateParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsPrivacyBudgetTemplateParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsPrivacyBudgetTemplateParameters | cdktn.IResolvable | undefined);
    private _budgetParameters;
    get budgetParameters(): CleanroomsPrivacyBudgetTemplateParametersBudgetParametersList;
    putBudgetParameters(value: CleanroomsPrivacyBudgetTemplateParametersBudgetParameters[] | cdktn.IResolvable): void;
    resetBudgetParameters(): void;
    get budgetParametersInput(): cdktn.IResolvable | CleanroomsPrivacyBudgetTemplateParametersBudgetParameters[] | undefined;
    private _epsilon?;
    get epsilon(): number;
    set epsilon(value: number);
    resetEpsilon(): void;
    get epsilonInput(): number | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    resetResourceArn(): void;
    get resourceArnInput(): string | undefined;
    private _usersNoisePerQuery?;
    get usersNoisePerQuery(): number;
    set usersNoisePerQuery(value: number);
    resetUsersNoisePerQuery(): void;
    get usersNoisePerQueryInput(): number | undefined;
}
export interface CleanroomsPrivacyBudgetTemplateTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#key CleanroomsPrivacyBudgetTemplate#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#value CleanroomsPrivacyBudgetTemplate#value}
    */
    readonly value?: string;
}
export declare function cleanroomsPrivacyBudgetTemplateTagsToTerraform(struct?: CleanroomsPrivacyBudgetTemplateTags | cdktn.IResolvable): any;
export declare function cleanroomsPrivacyBudgetTemplateTagsToHclTerraform(struct?: CleanroomsPrivacyBudgetTemplateTags | cdktn.IResolvable): any;
export declare class CleanroomsPrivacyBudgetTemplateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsPrivacyBudgetTemplateTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsPrivacyBudgetTemplateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsPrivacyBudgetTemplateTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsPrivacyBudgetTemplateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsPrivacyBudgetTemplateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template awscc_cleanrooms_privacy_budget_template}
*/
export declare class CleanroomsPrivacyBudgetTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanrooms_privacy_budget_template";
    /**
    * Generates CDKTN code for importing a CleanroomsPrivacyBudgetTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsPrivacyBudgetTemplate to import
    * @param importFromId The id of the existing CleanroomsPrivacyBudgetTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsPrivacyBudgetTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/cleanrooms_privacy_budget_template awscc_cleanrooms_privacy_budget_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsPrivacyBudgetTemplateConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsPrivacyBudgetTemplateConfig);
    get arn(): string;
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    get autoRefreshInput(): string | undefined;
    get collaborationArn(): string;
    get collaborationIdentifier(): string;
    get id(): string;
    get membershipArn(): string;
    private _membershipIdentifier?;
    get membershipIdentifier(): string;
    set membershipIdentifier(value: string);
    get membershipIdentifierInput(): string | undefined;
    private _parameters;
    get parameters(): CleanroomsPrivacyBudgetTemplateParametersOutputReference;
    putParameters(value: CleanroomsPrivacyBudgetTemplateParameters): void;
    get parametersInput(): cdktn.IResolvable | CleanroomsPrivacyBudgetTemplateParameters | undefined;
    get privacyBudgetTemplateIdentifier(): string;
    private _privacyBudgetType?;
    get privacyBudgetType(): string;
    set privacyBudgetType(value: string);
    get privacyBudgetTypeInput(): string | undefined;
    private _tags;
    get tags(): CleanroomsPrivacyBudgetTemplateTagsList;
    putTags(value: CleanroomsPrivacyBudgetTemplateTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsPrivacyBudgetTemplateTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
