/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreGatewayRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#actions BedrockagentcoreGatewayRule#actions}
    */
    readonly actions: BedrockagentcoreGatewayRuleActions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#conditions BedrockagentcoreGatewayRule#conditions}
    */
    readonly conditions?: BedrockagentcoreGatewayRuleConditions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#description BedrockagentcoreGatewayRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#gateway_identifier BedrockagentcoreGatewayRule#gateway_identifier}
    */
    readonly gatewayIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#priority BedrockagentcoreGatewayRule#priority}
    */
    readonly priority: number;
}
export interface BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverride {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#bundle_arn BedrockagentcoreGatewayRule#bundle_arn}
    */
    readonly bundleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#bundle_version BedrockagentcoreGatewayRule#bundle_version}
    */
    readonly bundleVersion?: string;
}
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverrideToTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverride | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverrideToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverride | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverride | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverride | cdktn.IResolvable | undefined);
    private _bundleArn?;
    get bundleArn(): string;
    set bundleArn(value: string);
    resetBundleArn(): void;
    get bundleArnInput(): string | undefined;
    private _bundleVersion?;
    get bundleVersion(): string;
    set bundleVersion(value: string);
    resetBundleVersion(): void;
    get bundleVersionInput(): string | undefined;
}
export interface BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#bundle_arn BedrockagentcoreGatewayRule#bundle_arn}
    */
    readonly bundleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#bundle_version BedrockagentcoreGatewayRule#bundle_version}
    */
    readonly bundleVersion?: string;
}
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleToTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | cdktn.IResolvable | undefined);
    private _bundleArn?;
    get bundleArn(): string;
    set bundleArn(value: string);
    resetBundleArn(): void;
    get bundleArnInput(): string | undefined;
    private _bundleVersion?;
    get bundleVersion(): string;
    set bundleVersion(value: string);
    resetBundleVersion(): void;
    get bundleVersionInput(): string | undefined;
}
export interface BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#configuration_bundle BedrockagentcoreGatewayRule#configuration_bundle}
    */
    readonly configurationBundle?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#description BedrockagentcoreGatewayRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#metadata BedrockagentcoreGatewayRule#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#name BedrockagentcoreGatewayRule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#weight BedrockagentcoreGatewayRule#weight}
    */
    readonly weight?: number;
}
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitToTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit | cdktn.IResolvable | undefined);
    private _configurationBundle;
    get configurationBundle(): BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleOutputReference;
    putConfigurationBundle(value: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle): void;
    resetConfigurationBundle(): void;
    get configurationBundleInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverride {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#traffic_split BedrockagentcoreGatewayRule#traffic_split}
    */
    readonly trafficSplit?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideToTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverride | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverride | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverride | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverride | cdktn.IResolvable | undefined);
    private _trafficSplit;
    get trafficSplit(): BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplitList;
    putTrafficSplit(value: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit[] | cdktn.IResolvable): void;
    resetTrafficSplit(): void;
    get trafficSplitInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideTrafficSplit[] | undefined;
}
export interface BedrockagentcoreGatewayRuleActionsConfigurationBundle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#static_override BedrockagentcoreGatewayRule#static_override}
    */
    readonly staticOverride?: BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverride;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#weighted_override BedrockagentcoreGatewayRule#weighted_override}
    */
    readonly weightedOverride?: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverride;
}
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleToTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundle | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsConfigurationBundleToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsConfigurationBundle | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsConfigurationBundleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleActionsConfigurationBundle | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsConfigurationBundle | cdktn.IResolvable | undefined);
    private _staticOverride;
    get staticOverride(): BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverrideOutputReference;
    putStaticOverride(value: BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverride): void;
    resetStaticOverride(): void;
    get staticOverrideInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsConfigurationBundleStaticOverride | undefined;
    private _weightedOverride;
    get weightedOverride(): BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverrideOutputReference;
    putWeightedOverride(value: BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverride): void;
    resetWeightedOverride(): void;
    get weightedOverrideInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsConfigurationBundleWeightedOverride | undefined;
}
export interface BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRoute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#target_name BedrockagentcoreGatewayRule#target_name}
    */
    readonly targetName?: string;
}
export declare function bedrockagentcoreGatewayRuleActionsRouteToTargetStaticRouteToTerraform(struct?: BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRoute | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsRouteToTargetStaticRouteToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRoute | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRoute | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRoute | cdktn.IResolvable | undefined);
    private _targetName?;
    get targetName(): string;
    set targetName(value: string);
    resetTargetName(): void;
    get targetNameInput(): string | undefined;
}
export interface BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#description BedrockagentcoreGatewayRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#metadata BedrockagentcoreGatewayRule#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#name BedrockagentcoreGatewayRule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#target_name BedrockagentcoreGatewayRule#target_name}
    */
    readonly targetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#weight BedrockagentcoreGatewayRule#weight}
    */
    readonly weight?: number;
}
export declare function bedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplitToTerraform(struct?: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplitToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _targetName?;
    get targetName(): string;
    set targetName(value: string);
    resetTargetName(): void;
    get targetNameInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplitList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplitOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRoute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#traffic_split BedrockagentcoreGatewayRule#traffic_split}
    */
    readonly trafficSplit?: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteToTerraform(struct?: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRoute | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRoute | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRoute | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRoute | cdktn.IResolvable | undefined);
    private _trafficSplit;
    get trafficSplit(): BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplitList;
    putTrafficSplit(value: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit[] | cdktn.IResolvable): void;
    resetTrafficSplit(): void;
    get trafficSplitInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteTrafficSplit[] | undefined;
}
export interface BedrockagentcoreGatewayRuleActionsRouteToTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#static_route BedrockagentcoreGatewayRule#static_route}
    */
    readonly staticRoute?: BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRoute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#weighted_route BedrockagentcoreGatewayRule#weighted_route}
    */
    readonly weightedRoute?: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRoute;
}
export declare function bedrockagentcoreGatewayRuleActionsRouteToTargetToTerraform(struct?: BedrockagentcoreGatewayRuleActionsRouteToTarget | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsRouteToTargetToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionsRouteToTarget | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsRouteToTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleActionsRouteToTarget | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionsRouteToTarget | cdktn.IResolvable | undefined);
    private _staticRoute;
    get staticRoute(): BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRouteOutputReference;
    putStaticRoute(value: BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRoute): void;
    resetStaticRoute(): void;
    get staticRouteInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsRouteToTargetStaticRoute | undefined;
    private _weightedRoute;
    get weightedRoute(): BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRouteOutputReference;
    putWeightedRoute(value: BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRoute): void;
    resetWeightedRoute(): void;
    get weightedRouteInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsRouteToTargetWeightedRoute | undefined;
}
export interface BedrockagentcoreGatewayRuleActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#configuration_bundle BedrockagentcoreGatewayRule#configuration_bundle}
    */
    readonly configurationBundle?: BedrockagentcoreGatewayRuleActionsConfigurationBundle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#route_to_target BedrockagentcoreGatewayRule#route_to_target}
    */
    readonly routeToTarget?: BedrockagentcoreGatewayRuleActionsRouteToTarget;
}
export declare function bedrockagentcoreGatewayRuleActionsToTerraform(struct?: BedrockagentcoreGatewayRuleActions | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionsToHclTerraform(struct?: BedrockagentcoreGatewayRuleActions | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActions | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActions | cdktn.IResolvable | undefined);
    private _configurationBundle;
    get configurationBundle(): BedrockagentcoreGatewayRuleActionsConfigurationBundleOutputReference;
    putConfigurationBundle(value: BedrockagentcoreGatewayRuleActionsConfigurationBundle): void;
    resetConfigurationBundle(): void;
    get configurationBundleInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsConfigurationBundle | undefined;
    private _routeToTarget;
    get routeToTarget(): BedrockagentcoreGatewayRuleActionsRouteToTargetOutputReference;
    putRouteToTarget(value: BedrockagentcoreGatewayRuleActionsRouteToTarget): void;
    resetRouteToTarget(): void;
    get routeToTargetInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionsRouteToTarget | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionsOutputReference;
}
export interface BedrockagentcoreGatewayRuleConditionsMatchPaths {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#any_of BedrockagentcoreGatewayRule#any_of}
    */
    readonly anyOf?: string[];
}
export declare function bedrockagentcoreGatewayRuleConditionsMatchPathsToTerraform(struct?: BedrockagentcoreGatewayRuleConditionsMatchPaths | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionsMatchPathsToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditionsMatchPaths | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionsMatchPathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleConditionsMatchPaths | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditionsMatchPaths | cdktn.IResolvable | undefined);
    private _anyOf?;
    get anyOf(): string[];
    set anyOf(value: string[]);
    resetAnyOf(): void;
    get anyOfInput(): string[] | undefined;
}
export interface BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#arn BedrockagentcoreGatewayRule#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#operator BedrockagentcoreGatewayRule#operator}
    */
    readonly operator?: string;
}
export declare function bedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipalToTerraform(struct?: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipal | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipalToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipal | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipal | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
}
export interface BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#iam_principal BedrockagentcoreGatewayRule#iam_principal}
    */
    readonly iamPrincipal?: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipal;
}
export declare function bedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfToTerraform(struct?: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf | cdktn.IResolvable | undefined);
    private _iamPrincipal;
    get iamPrincipal(): BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipalOutputReference;
    putIamPrincipal(value: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipal): void;
    resetIamPrincipal(): void;
    get iamPrincipalInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfIamPrincipal | undefined;
}
export declare class BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfOutputReference;
}
export interface BedrockagentcoreGatewayRuleConditionsMatchPrincipals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#any_of BedrockagentcoreGatewayRule#any_of}
    */
    readonly anyOf?: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleConditionsMatchPrincipalsToTerraform(struct?: BedrockagentcoreGatewayRuleConditionsMatchPrincipals | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionsMatchPrincipalsToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditionsMatchPrincipals | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionsMatchPrincipalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleConditionsMatchPrincipals | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditionsMatchPrincipals | cdktn.IResolvable | undefined);
    private _anyOf;
    get anyOf(): BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOfList;
    putAnyOf(value: BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf[] | cdktn.IResolvable): void;
    resetAnyOf(): void;
    get anyOfInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditionsMatchPrincipalsAnyOf[] | undefined;
}
export interface BedrockagentcoreGatewayRuleConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#match_paths BedrockagentcoreGatewayRule#match_paths}
    */
    readonly matchPaths?: BedrockagentcoreGatewayRuleConditionsMatchPaths;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#match_principals BedrockagentcoreGatewayRule#match_principals}
    */
    readonly matchPrincipals?: BedrockagentcoreGatewayRuleConditionsMatchPrincipals;
}
export declare function bedrockagentcoreGatewayRuleConditionsToTerraform(struct?: BedrockagentcoreGatewayRuleConditions | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionsToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditions | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleConditions | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditions | cdktn.IResolvable | undefined);
    private _matchPaths;
    get matchPaths(): BedrockagentcoreGatewayRuleConditionsMatchPathsOutputReference;
    putMatchPaths(value: BedrockagentcoreGatewayRuleConditionsMatchPaths): void;
    resetMatchPaths(): void;
    get matchPathsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditionsMatchPaths | undefined;
    private _matchPrincipals;
    get matchPrincipals(): BedrockagentcoreGatewayRuleConditionsMatchPrincipalsOutputReference;
    putMatchPrincipals(value: BedrockagentcoreGatewayRuleConditionsMatchPrincipals): void;
    resetMatchPrincipals(): void;
    get matchPrincipalsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditionsMatchPrincipals | undefined;
}
export declare class BedrockagentcoreGatewayRuleConditionsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleConditionsOutputReference;
}
export interface BedrockagentcoreGatewayRuleSystem {
}
export declare function bedrockagentcoreGatewayRuleSystemToTerraform(struct?: BedrockagentcoreGatewayRuleSystem): any;
export declare function bedrockagentcoreGatewayRuleSystemToHclTerraform(struct?: BedrockagentcoreGatewayRuleSystem): any;
export declare class BedrockagentcoreGatewayRuleSystemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleSystem | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleSystem | undefined);
    get managedBy(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule awscc_bedrockagentcore_gateway_rule}
*/
export declare class BedrockagentcoreGatewayRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_gateway_rule";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreGatewayRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreGatewayRule to import
    * @param importFromId The id of the existing BedrockagentcoreGatewayRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreGatewayRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/bedrockagentcore_gateway_rule awscc_bedrockagentcore_gateway_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreGatewayRuleConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreGatewayRuleConfig);
    private _actions;
    get actions(): BedrockagentcoreGatewayRuleActionsList;
    putActions(value: BedrockagentcoreGatewayRuleActions[] | cdktn.IResolvable): void;
    get actionsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActions[] | undefined;
    private _conditions;
    get conditions(): BedrockagentcoreGatewayRuleConditionsList;
    putConditions(value: BedrockagentcoreGatewayRuleConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditions[] | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get gatewayArn(): string;
    private _gatewayIdentifier?;
    get gatewayIdentifier(): string;
    set gatewayIdentifier(value: string);
    resetGatewayIdentifier(): void;
    get gatewayIdentifierInput(): string | undefined;
    get id(): string;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    get ruleId(): string;
    get status(): string;
    private _system;
    get systemAttribute(): BedrockagentcoreGatewayRuleSystemOutputReference;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
