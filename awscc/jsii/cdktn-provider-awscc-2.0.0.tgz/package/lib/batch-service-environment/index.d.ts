/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BatchServiceEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment#capacity_limits BatchServiceEnvironment#capacity_limits}
    */
    readonly capacityLimits: BatchServiceEnvironmentCapacityLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment#service_environment_name BatchServiceEnvironment#service_environment_name}
    */
    readonly serviceEnvironmentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment#service_environment_type BatchServiceEnvironment#service_environment_type}
    */
    readonly serviceEnvironmentType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment#state BatchServiceEnvironment#state}
    */
    readonly state?: string;
    /**
    * A key-value pair to associate with a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment#tags BatchServiceEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BatchServiceEnvironmentCapacityLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment#capacity_unit BatchServiceEnvironment#capacity_unit}
    */
    readonly capacityUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment#max_capacity BatchServiceEnvironment#max_capacity}
    */
    readonly maxCapacity?: number;
}
export declare function batchServiceEnvironmentCapacityLimitsToTerraform(struct?: BatchServiceEnvironmentCapacityLimits | cdktn.IResolvable): any;
export declare function batchServiceEnvironmentCapacityLimitsToHclTerraform(struct?: BatchServiceEnvironmentCapacityLimits | cdktn.IResolvable): any;
export declare class BatchServiceEnvironmentCapacityLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchServiceEnvironmentCapacityLimits | cdktn.IResolvable | undefined;
    set internalValue(value: BatchServiceEnvironmentCapacityLimits | cdktn.IResolvable | undefined);
    private _capacityUnit?;
    get capacityUnit(): string;
    set capacityUnit(value: string);
    resetCapacityUnit(): void;
    get capacityUnitInput(): string | undefined;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    resetMaxCapacity(): void;
    get maxCapacityInput(): number | undefined;
}
export declare class BatchServiceEnvironmentCapacityLimitsList extends cdktn.ComplexList {
    internalValue?: BatchServiceEnvironmentCapacityLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchServiceEnvironmentCapacityLimitsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment awscc_batch_service_environment}
*/
export declare class BatchServiceEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_batch_service_environment";
    /**
    * Generates CDKTN code for importing a BatchServiceEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BatchServiceEnvironment to import
    * @param importFromId The id of the existing BatchServiceEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BatchServiceEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/batch_service_environment awscc_batch_service_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BatchServiceEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: BatchServiceEnvironmentConfig);
    private _capacityLimits;
    get capacityLimits(): BatchServiceEnvironmentCapacityLimitsList;
    putCapacityLimits(value: BatchServiceEnvironmentCapacityLimits[] | cdktn.IResolvable): void;
    get capacityLimitsInput(): cdktn.IResolvable | BatchServiceEnvironmentCapacityLimits[] | undefined;
    get id(): string;
    get serviceEnvironmentArn(): string;
    private _serviceEnvironmentName?;
    get serviceEnvironmentName(): string;
    set serviceEnvironmentName(value: string);
    resetServiceEnvironmentName(): void;
    get serviceEnvironmentNameInput(): string | undefined;
    private _serviceEnvironmentType?;
    get serviceEnvironmentType(): string;
    set serviceEnvironmentType(value: string);
    get serviceEnvironmentTypeInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
