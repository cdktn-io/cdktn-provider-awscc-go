/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamStackUserAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The authentication type for the user who is associated with the stack. You must specify USERPOOL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_stack_user_association#authentication_type AppstreamStackUserAssociation#authentication_type}
    */
    readonly authenticationType: string;
    /**
    * Specifies whether a welcome email is sent to a user after the user is created in the user pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_stack_user_association#send_email_notification AppstreamStackUserAssociation#send_email_notification}
    */
    readonly sendEmailNotification?: boolean | cdktn.IResolvable;
    /**
    * The name of the stack that is associated with the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_stack_user_association#stack_name AppstreamStackUserAssociation#stack_name}
    */
    readonly stackName: string;
    /**
    * The name of the user who is associated with the stack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_stack_user_association#user_name AppstreamStackUserAssociation#user_name}
    */
    readonly userName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_stack_user_association awscc_appstream_stack_user_association}
*/
export declare class AppstreamStackUserAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_stack_user_association";
    /**
    * Generates CDKTN code for importing a AppstreamStackUserAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamStackUserAssociation to import
    * @param importFromId The id of the existing AppstreamStackUserAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_stack_user_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamStackUserAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/appstream_stack_user_association awscc_appstream_stack_user_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamStackUserAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamStackUserAssociationConfig);
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    get authenticationTypeInput(): string | undefined;
    get id(): string;
    private _sendEmailNotification?;
    get sendEmailNotification(): boolean | cdktn.IResolvable;
    set sendEmailNotification(value: boolean | cdktn.IResolvable);
    resetSendEmailNotification(): void;
    get sendEmailNotificationInput(): boolean | cdktn.IResolvable | undefined;
    private _stackName?;
    get stackName(): string;
    set stackName(value: string);
    get stackNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
