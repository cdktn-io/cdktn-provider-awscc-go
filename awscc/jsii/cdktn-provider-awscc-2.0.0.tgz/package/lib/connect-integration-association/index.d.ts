/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectIntegrationAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Amazon Connect instance identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#instance_id ConnectIntegrationAssociation#instance_id}
    */
    readonly instanceId: string;
    /**
    * ARN of Integration being associated with the instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#integration_arn ConnectIntegrationAssociation#integration_arn}
    */
    readonly integrationArn: string;
    /**
    * Specifies the integration type to be associated with the instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#integration_type ConnectIntegrationAssociation#integration_type}
    */
    readonly integrationType: string;
    /**
    * The name of the external application. This is only supported for the EVENT integration type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#source_application_name ConnectIntegrationAssociation#source_application_name}
    */
    readonly sourceApplicationName?: string;
    /**
    * The URL for the external application. This is only supported for the EVENT integration type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#source_application_url ConnectIntegrationAssociation#source_application_url}
    */
    readonly sourceApplicationUrl?: string;
    /**
    * The type of the data source. This is only supported for the EVENT integration type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#source_type ConnectIntegrationAssociation#source_type}
    */
    readonly sourceType?: string;
    /**
    * The tags used to organize, track, or control access for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#tags ConnectIntegrationAssociation#tags}
    */
    readonly tags?: ConnectIntegrationAssociationTags[] | cdktn.IResolvable;
}
export interface ConnectIntegrationAssociationTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#key ConnectIntegrationAssociation#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#value ConnectIntegrationAssociation#value}
    */
    readonly value?: string;
}
export declare function connectIntegrationAssociationTagsToTerraform(struct?: ConnectIntegrationAssociationTags | cdktn.IResolvable): any;
export declare function connectIntegrationAssociationTagsToHclTerraform(struct?: ConnectIntegrationAssociationTags | cdktn.IResolvable): any;
export declare class ConnectIntegrationAssociationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectIntegrationAssociationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectIntegrationAssociationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectIntegrationAssociationTagsList extends cdktn.ComplexList {
    internalValue?: ConnectIntegrationAssociationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectIntegrationAssociationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association awscc_connect_integration_association}
*/
export declare class ConnectIntegrationAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_integration_association";
    /**
    * Generates CDKTN code for importing a ConnectIntegrationAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectIntegrationAssociation to import
    * @param importFromId The id of the existing ConnectIntegrationAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectIntegrationAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/connect_integration_association awscc_connect_integration_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectIntegrationAssociationConfig
    */
    constructor(scope: Construct, id: string, config: ConnectIntegrationAssociationConfig);
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _integrationArn?;
    get integrationArn(): string;
    set integrationArn(value: string);
    get integrationArnInput(): string | undefined;
    get integrationAssociationId(): string;
    private _integrationType?;
    get integrationType(): string;
    set integrationType(value: string);
    get integrationTypeInput(): string | undefined;
    private _sourceApplicationName?;
    get sourceApplicationName(): string;
    set sourceApplicationName(value: string);
    resetSourceApplicationName(): void;
    get sourceApplicationNameInput(): string | undefined;
    private _sourceApplicationUrl?;
    get sourceApplicationUrl(): string;
    set sourceApplicationUrl(value: string);
    resetSourceApplicationUrl(): void;
    get sourceApplicationUrlInput(): string | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    resetSourceType(): void;
    get sourceTypeInput(): string | undefined;
    private _tags;
    get tags(): ConnectIntegrationAssociationTagsList;
    putTags(value: ConnectIntegrationAssociationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectIntegrationAssociationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
