/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessanalyzerArchiveRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the analyzer for the archive rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule#analyzer_name AccessanalyzerArchiveRule#analyzer_name}
    */
    readonly analyzerName: string;
    /**
    * The criteria for the archive rule. A map of filter criteria property names to their criterion values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule#filter AccessanalyzerArchiveRule#filter}
    */
    readonly filter: {
        [key: string]: AccessanalyzerArchiveRuleFilter;
    } | cdktn.IResolvable;
    /**
    * The name of the archive rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule#rule_name AccessanalyzerArchiveRule#rule_name}
    */
    readonly ruleName: string;
}
export interface AccessanalyzerArchiveRuleFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule#contains AccessanalyzerArchiveRule#contains}
    */
    readonly contains?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule#eq AccessanalyzerArchiveRule#eq}
    */
    readonly eq?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule#exists AccessanalyzerArchiveRule#exists}
    */
    readonly exists?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule#neq AccessanalyzerArchiveRule#neq}
    */
    readonly neq?: string[];
}
export declare function accessanalyzerArchiveRuleFilterToTerraform(struct?: AccessanalyzerArchiveRuleFilter | cdktn.IResolvable): any;
export declare function accessanalyzerArchiveRuleFilterToHclTerraform(struct?: AccessanalyzerArchiveRuleFilter | cdktn.IResolvable): any;
export declare class AccessanalyzerArchiveRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AccessanalyzerArchiveRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerArchiveRuleFilter | cdktn.IResolvable | undefined);
    private _contains?;
    get contains(): string[];
    set contains(value: string[]);
    resetContains(): void;
    get containsInput(): string[] | undefined;
    private _eq?;
    get eq(): string[];
    set eq(value: string[]);
    resetEq(): void;
    get eqInput(): string[] | undefined;
    private _exists?;
    get exists(): boolean | cdktn.IResolvable;
    set exists(value: boolean | cdktn.IResolvable);
    resetExists(): void;
    get existsInput(): boolean | cdktn.IResolvable | undefined;
    private _neq?;
    get neq(): string[];
    set neq(value: string[]);
    resetNeq(): void;
    get neqInput(): string[] | undefined;
}
export declare class AccessanalyzerArchiveRuleFilterMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: AccessanalyzerArchiveRuleFilter;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AccessanalyzerArchiveRuleFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule awscc_accessanalyzer_archive_rule}
*/
export declare class AccessanalyzerArchiveRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_accessanalyzer_archive_rule";
    /**
    * Generates CDKTN code for importing a AccessanalyzerArchiveRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessanalyzerArchiveRule to import
    * @param importFromId The id of the existing AccessanalyzerArchiveRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessanalyzerArchiveRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.107.0/docs/resources/accessanalyzer_archive_rule awscc_accessanalyzer_archive_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessanalyzerArchiveRuleConfig
    */
    constructor(scope: Construct, id: string, config: AccessanalyzerArchiveRuleConfig);
    private _analyzerName?;
    get analyzerName(): string;
    set analyzerName(value: string);
    get analyzerNameInput(): string | undefined;
    get arn(): string;
    get createdAt(): string;
    private _filter;
    get filter(): AccessanalyzerArchiveRuleFilterMap;
    putFilter(value: {
        [key: string]: AccessanalyzerArchiveRuleFilter;
    } | cdktn.IResolvable): void;
    get filterInput(): cdktn.IResolvable | {
        [key: string]: AccessanalyzerArchiveRuleFilter;
    } | undefined;
    get id(): string;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
