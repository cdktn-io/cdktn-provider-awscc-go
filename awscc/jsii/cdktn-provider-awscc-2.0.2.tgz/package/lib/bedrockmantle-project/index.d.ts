/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockmantleProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockmantle_project#name BedrockmantleProject#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockmantle_project#tags BedrockmantleProject#tags}
    */
    readonly tags?: BedrockmantleProjectTags[] | cdktn.IResolvable;
}
export interface BedrockmantleProjectTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockmantle_project#key BedrockmantleProject#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockmantle_project#value BedrockmantleProject#value}
    */
    readonly value?: string;
}
export declare function bedrockmantleProjectTagsToTerraform(struct?: BedrockmantleProjectTags | cdktn.IResolvable): any;
export declare function bedrockmantleProjectTagsToHclTerraform(struct?: BedrockmantleProjectTags | cdktn.IResolvable): any;
export declare class BedrockmantleProjectTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockmantleProjectTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockmantleProjectTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockmantleProjectTagsList extends cdktn.ComplexList {
    internalValue?: BedrockmantleProjectTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockmantleProjectTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockmantle_project awscc_bedrockmantle_project}
*/
export declare class BedrockmantleProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockmantle_project";
    /**
    * Generates CDKTN code for importing a BedrockmantleProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockmantleProject to import
    * @param importFromId The id of the existing BedrockmantleProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockmantle_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockmantleProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockmantle_project awscc_bedrockmantle_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockmantleProjectConfig
    */
    constructor(scope: Construct, id: string, config: BedrockmantleProjectConfig);
    get arn(): string;
    get createdAt(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get projectId(): string;
    private _tags;
    get tags(): BedrockmantleProjectTagsList;
    putTags(value: BedrockmantleProjectTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockmantleProjectTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
