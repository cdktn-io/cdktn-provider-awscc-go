/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockKnowledgeBasePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the knowledge base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_knowledge_base_policy#knowledge_base_id BedrockKnowledgeBasePolicy#knowledge_base_id}
    */
    readonly knowledgeBaseId: string;
    /**
    * The IAM policy document defining access permissions for the knowledge base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_knowledge_base_policy#policy_document BedrockKnowledgeBasePolicy#policy_document}
    */
    readonly policyDocument: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_knowledge_base_policy awscc_bedrock_knowledge_base_policy}
*/
export declare class BedrockKnowledgeBasePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_knowledge_base_policy";
    /**
    * Generates CDKTN code for importing a BedrockKnowledgeBasePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockKnowledgeBasePolicy to import
    * @param importFromId The id of the existing BedrockKnowledgeBasePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_knowledge_base_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockKnowledgeBasePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_knowledge_base_policy awscc_bedrock_knowledge_base_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockKnowledgeBasePolicyConfig
    */
    constructor(scope: Construct, id: string, config: BedrockKnowledgeBasePolicyConfig);
    get id(): string;
    private _knowledgeBaseId?;
    get knowledgeBaseId(): string;
    set knowledgeBaseId(value: string);
    get knowledgeBaseIdInput(): string | undefined;
    private _policyDocument?;
    get policyDocument(): string;
    set policyDocument(value: string);
    get policyDocumentInput(): string | undefined;
    get revisionId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
