/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectContactFlowVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the contact flow this version is tied to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_version#contact_flow_id ConnectContactFlowVersion#contact_flow_id}
    */
    readonly contactFlowId: string;
    /**
    * The description of the version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_version#description ConnectContactFlowVersion#description}
    */
    readonly description?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_version awscc_connect_contact_flow_version}
*/
export declare class ConnectContactFlowVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_contact_flow_version";
    /**
    * Generates CDKTN code for importing a ConnectContactFlowVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectContactFlowVersion to import
    * @param importFromId The id of the existing ConnectContactFlowVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectContactFlowVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_version awscc_connect_contact_flow_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectContactFlowVersionConfig
    */
    constructor(scope: Construct, id: string, config: ConnectContactFlowVersionConfig);
    private _contactFlowId?;
    get contactFlowId(): string;
    set contactFlowId(value: string);
    get contactFlowIdInput(): string | undefined;
    get contactFlowVersionArn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get flowContentSha256(): string;
    get id(): string;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
