/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ControltowerLandingZoneConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone#manifest ControltowerLandingZone#manifest}
    */
    readonly manifest: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone#remediation_types ControltowerLandingZone#remediation_types}
    */
    readonly remediationTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone#tags ControltowerLandingZone#tags}
    */
    readonly tags?: ControltowerLandingZoneTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone#version ControltowerLandingZone#version}
    */
    readonly version: string;
}
export interface ControltowerLandingZoneTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone#key ControltowerLandingZone#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone#value ControltowerLandingZone#value}
    */
    readonly value?: string;
}
export declare function controltowerLandingZoneTagsToTerraform(struct?: ControltowerLandingZoneTags | cdktn.IResolvable): any;
export declare function controltowerLandingZoneTagsToHclTerraform(struct?: ControltowerLandingZoneTags | cdktn.IResolvable): any;
export declare class ControltowerLandingZoneTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ControltowerLandingZoneTags | cdktn.IResolvable | undefined;
    set internalValue(value: ControltowerLandingZoneTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ControltowerLandingZoneTagsList extends cdktn.ComplexList {
    internalValue?: ControltowerLandingZoneTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ControltowerLandingZoneTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone awscc_controltower_landing_zone}
*/
export declare class ControltowerLandingZone extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_controltower_landing_zone";
    /**
    * Generates CDKTN code for importing a ControltowerLandingZone resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ControltowerLandingZone to import
    * @param importFromId The id of the existing ControltowerLandingZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ControltowerLandingZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/controltower_landing_zone awscc_controltower_landing_zone} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ControltowerLandingZoneConfig
    */
    constructor(scope: Construct, id: string, config: ControltowerLandingZoneConfig);
    get arn(): string;
    get driftStatus(): string;
    get id(): string;
    get landingZoneIdentifier(): string;
    get latestAvailableVersion(): string;
    private _manifest?;
    get manifest(): string;
    set manifest(value: string);
    get manifestInput(): string | undefined;
    private _remediationTypes?;
    get remediationTypes(): string[];
    set remediationTypes(value: string[]);
    resetRemediationTypes(): void;
    get remediationTypesInput(): string[] | undefined;
    get status(): string;
    private _tags;
    get tags(): ControltowerLandingZoneTagsList;
    putTags(value: ControltowerLandingZoneTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ControltowerLandingZoneTags[] | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
