/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppflowConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    *  The name of the connector. The name is unique for each ConnectorRegistration in your AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector#connector_label AppflowConnector#connector_label}
    */
    readonly connectorLabel?: string;
    /**
    * Contains information about the configuration of the connector being registered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector#connector_provisioning_config AppflowConnector#connector_provisioning_config}
    */
    readonly connectorProvisioningConfig: AppflowConnectorConnectorProvisioningConfig;
    /**
    * The provisioning type of the connector. Currently the only supported value is LAMBDA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector#connector_provisioning_type AppflowConnector#connector_provisioning_type}
    */
    readonly connectorProvisioningType: string;
    /**
    * A description about the connector that's being registered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector#description AppflowConnector#description}
    */
    readonly description?: string;
}
export interface AppflowConnectorConnectorProvisioningConfigLambda {
    /**
    * Lambda ARN of the connector being registered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector#lambda_arn AppflowConnector#lambda_arn}
    */
    readonly lambdaArn?: string;
}
export declare function appflowConnectorConnectorProvisioningConfigLambdaToTerraform(struct?: AppflowConnectorConnectorProvisioningConfigLambda | cdktn.IResolvable): any;
export declare function appflowConnectorConnectorProvisioningConfigLambdaToHclTerraform(struct?: AppflowConnectorConnectorProvisioningConfigLambda | cdktn.IResolvable): any;
export declare class AppflowConnectorConnectorProvisioningConfigLambdaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorConnectorProvisioningConfigLambda | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorConnectorProvisioningConfigLambda | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    resetLambdaArn(): void;
    get lambdaArnInput(): string | undefined;
}
export interface AppflowConnectorConnectorProvisioningConfig {
    /**
    * Contains information about the configuration of the lambda which is being registered as the connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector#lambda AppflowConnector#lambda}
    */
    readonly lambda?: AppflowConnectorConnectorProvisioningConfigLambda;
}
export declare function appflowConnectorConnectorProvisioningConfigToTerraform(struct?: AppflowConnectorConnectorProvisioningConfig | cdktn.IResolvable): any;
export declare function appflowConnectorConnectorProvisioningConfigToHclTerraform(struct?: AppflowConnectorConnectorProvisioningConfig | cdktn.IResolvable): any;
export declare class AppflowConnectorConnectorProvisioningConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorConnectorProvisioningConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorConnectorProvisioningConfig | cdktn.IResolvable | undefined);
    private _lambda;
    get lambda(): AppflowConnectorConnectorProvisioningConfigLambdaOutputReference;
    putLambda(value: AppflowConnectorConnectorProvisioningConfigLambda): void;
    resetLambda(): void;
    get lambdaInput(): cdktn.IResolvable | AppflowConnectorConnectorProvisioningConfigLambda | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector awscc_appflow_connector}
*/
export declare class AppflowConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appflow_connector";
    /**
    * Generates CDKTN code for importing a AppflowConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppflowConnector to import
    * @param importFromId The id of the existing AppflowConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppflowConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appflow_connector awscc_appflow_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppflowConnectorConfig
    */
    constructor(scope: Construct, id: string, config: AppflowConnectorConfig);
    get connectorArn(): string;
    private _connectorLabel?;
    get connectorLabel(): string;
    set connectorLabel(value: string);
    resetConnectorLabel(): void;
    get connectorLabelInput(): string | undefined;
    private _connectorProvisioningConfig;
    get connectorProvisioningConfig(): AppflowConnectorConnectorProvisioningConfigOutputReference;
    putConnectorProvisioningConfig(value: AppflowConnectorConnectorProvisioningConfig): void;
    get connectorProvisioningConfigInput(): cdktn.IResolvable | AppflowConnectorConnectorProvisioningConfig | undefined;
    private _connectorProvisioningType?;
    get connectorProvisioningType(): string;
    set connectorProvisioningType(value: string);
    get connectorProvisioningTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
