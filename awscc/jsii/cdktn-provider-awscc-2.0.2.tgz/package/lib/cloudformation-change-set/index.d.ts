/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationChangeSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The capabilities that are allowed in the stack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#capabilities CloudformationChangeSet#capabilities}
    */
    readonly capabilities?: string[];
    /**
    * The name of the change set. Must be unique among all change sets associated with the specified stack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#change_set_name CloudformationChangeSet#change_set_name}
    */
    readonly changeSetName: string;
    /**
    * The type of change set operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#change_set_type CloudformationChangeSet#change_set_type}
    */
    readonly changeSetType?: string;
    /**
    * Determines how CloudFormation handles configuration drift during deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#deployment_mode CloudformationChangeSet#deployment_mode}
    */
    readonly deploymentMode?: string;
    /**
    * A description to help you identify this change set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#description CloudformationChangeSet#description}
    */
    readonly description?: string;
    /**
    * Indicates if the change set imports resources that already exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#import_existing_resources CloudformationChangeSet#import_existing_resources}
    */
    readonly importExistingResources?: boolean | cdktn.IResolvable;
    /**
    * Creates a change set for all nested stacks specified in the template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#include_nested_stacks CloudformationChangeSet#include_nested_stacks}
    */
    readonly includeNestedStacks?: boolean | cdktn.IResolvable;
    /**
    * The ARNs of Amazon SNS topics that CloudFormation associates with the stack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#notification_ar_ns CloudformationChangeSet#notification_ar_ns}
    */
    readonly notificationArNs?: string[];
    /**
    * Determines what action will be taken if stack creation fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#on_stack_failure CloudformationChangeSet#on_stack_failure}
    */
    readonly onStackFailure?: string;
    /**
    * The ARN of an IAM role that CloudFormation assumes when executing the change set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#role_arn CloudformationChangeSet#role_arn}
    */
    readonly roleArn?: string;
    /**
    * The name or unique ID of the stack for which you are creating a change set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#stack_name CloudformationChangeSet#stack_name}
    */
    readonly stackName: string;
    /**
    * Key-value pairs to associate with the change set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#tags CloudformationChangeSet#tags}
    */
    readonly tags?: CloudformationChangeSetTags[] | cdktn.IResolvable;
    /**
    * A structure that contains the body of the revised template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#template_body CloudformationChangeSet#template_body}
    */
    readonly templateBody?: string;
    /**
    * The URL of the file that contains the revised template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#template_url CloudformationChangeSet#template_url}
    */
    readonly templateUrl?: string;
    /**
    * Whether to reuse the template associated with the stack to create the change set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#use_previous_template CloudformationChangeSet#use_previous_template}
    */
    readonly usePreviousTemplate?: boolean | cdktn.IResolvable;
}
export interface CloudformationChangeSetTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#key CloudformationChangeSet#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#value CloudformationChangeSet#value}
    */
    readonly value?: string;
}
export declare function cloudformationChangeSetTagsToTerraform(struct?: CloudformationChangeSetTags | cdktn.IResolvable): any;
export declare function cloudformationChangeSetTagsToHclTerraform(struct?: CloudformationChangeSetTags | cdktn.IResolvable): any;
export declare class CloudformationChangeSetTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationChangeSetTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationChangeSetTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudformationChangeSetTagsList extends cdktn.ComplexList {
    internalValue?: CloudformationChangeSetTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationChangeSetTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set awscc_cloudformation_change_set}
*/
export declare class CloudformationChangeSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_change_set";
    /**
    * Generates CDKTN code for importing a CloudformationChangeSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationChangeSet to import
    * @param importFromId The id of the existing CloudformationChangeSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationChangeSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_change_set awscc_cloudformation_change_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationChangeSetConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationChangeSetConfig);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    resetCapabilities(): void;
    get capabilitiesInput(): string[] | undefined;
    get changeSetId(): string;
    private _changeSetName?;
    get changeSetName(): string;
    set changeSetName(value: string);
    get changeSetNameInput(): string | undefined;
    private _changeSetType?;
    get changeSetType(): string;
    set changeSetType(value: string);
    resetChangeSetType(): void;
    get changeSetTypeInput(): string | undefined;
    get creationTime(): string;
    private _deploymentMode?;
    get deploymentMode(): string;
    set deploymentMode(value: string);
    resetDeploymentMode(): void;
    get deploymentModeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _importExistingResources?;
    get importExistingResources(): boolean | cdktn.IResolvable;
    set importExistingResources(value: boolean | cdktn.IResolvable);
    resetImportExistingResources(): void;
    get importExistingResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _includeNestedStacks?;
    get includeNestedStacks(): boolean | cdktn.IResolvable;
    set includeNestedStacks(value: boolean | cdktn.IResolvable);
    resetIncludeNestedStacks(): void;
    get includeNestedStacksInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationArNs?;
    get notificationArNs(): string[];
    set notificationArNs(value: string[]);
    resetNotificationArNs(): void;
    get notificationArNsInput(): string[] | undefined;
    private _onStackFailure?;
    get onStackFailure(): string;
    set onStackFailure(value: string);
    resetOnStackFailure(): void;
    get onStackFailureInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    get stackId(): string;
    private _stackName?;
    get stackName(): string;
    set stackName(value: string);
    get stackNameInput(): string | undefined;
    private _tags;
    get tags(): CloudformationChangeSetTagsList;
    putTags(value: CloudformationChangeSetTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudformationChangeSetTags[] | undefined;
    private _templateBody?;
    get templateBody(): string;
    set templateBody(value: string);
    resetTemplateBody(): void;
    get templateBodyInput(): string | undefined;
    private _templateUrl?;
    get templateUrl(): string;
    set templateUrl(value: string);
    resetTemplateUrl(): void;
    get templateUrlInput(): string | undefined;
    private _usePreviousTemplate?;
    get usePreviousTemplate(): boolean | cdktn.IResolvable;
    set usePreviousTemplate(value: boolean | cdktn.IResolvable);
    resetUsePreviousTemplate(): void;
    get usePreviousTemplateInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
