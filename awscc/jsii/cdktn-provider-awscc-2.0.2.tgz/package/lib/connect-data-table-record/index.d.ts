/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectDataTableRecordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#data_table_arn ConnectDataTableRecord#data_table_arn}
    */
    readonly dataTableArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#data_table_record ConnectDataTableRecord#data_table_record}
    */
    readonly dataTableRecord: ConnectDataTableRecordDataTableRecord;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#instance_arn ConnectDataTableRecord#instance_arn}
    */
    readonly instanceArn: string;
}
export interface ConnectDataTableRecordDataTableRecordPrimaryValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#attribute_id ConnectDataTableRecord#attribute_id}
    */
    readonly attributeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#attribute_value ConnectDataTableRecord#attribute_value}
    */
    readonly attributeValue?: string;
}
export declare function connectDataTableRecordDataTableRecordPrimaryValuesToTerraform(struct?: ConnectDataTableRecordDataTableRecordPrimaryValues | cdktn.IResolvable): any;
export declare function connectDataTableRecordDataTableRecordPrimaryValuesToHclTerraform(struct?: ConnectDataTableRecordDataTableRecordPrimaryValues | cdktn.IResolvable): any;
export declare class ConnectDataTableRecordDataTableRecordPrimaryValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectDataTableRecordDataTableRecordPrimaryValues | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectDataTableRecordDataTableRecordPrimaryValues | cdktn.IResolvable | undefined);
    private _attributeId?;
    get attributeId(): string;
    set attributeId(value: string);
    resetAttributeId(): void;
    get attributeIdInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
}
export declare class ConnectDataTableRecordDataTableRecordPrimaryValuesList extends cdktn.ComplexList {
    internalValue?: ConnectDataTableRecordDataTableRecordPrimaryValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectDataTableRecordDataTableRecordPrimaryValuesOutputReference;
}
export interface ConnectDataTableRecordDataTableRecordValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#attribute_id ConnectDataTableRecord#attribute_id}
    */
    readonly attributeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#attribute_value ConnectDataTableRecord#attribute_value}
    */
    readonly attributeValue?: string;
}
export declare function connectDataTableRecordDataTableRecordValuesToTerraform(struct?: ConnectDataTableRecordDataTableRecordValues | cdktn.IResolvable): any;
export declare function connectDataTableRecordDataTableRecordValuesToHclTerraform(struct?: ConnectDataTableRecordDataTableRecordValues | cdktn.IResolvable): any;
export declare class ConnectDataTableRecordDataTableRecordValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectDataTableRecordDataTableRecordValues | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectDataTableRecordDataTableRecordValues | cdktn.IResolvable | undefined);
    private _attributeId?;
    get attributeId(): string;
    set attributeId(value: string);
    resetAttributeId(): void;
    get attributeIdInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
}
export declare class ConnectDataTableRecordDataTableRecordValuesList extends cdktn.ComplexList {
    internalValue?: ConnectDataTableRecordDataTableRecordValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectDataTableRecordDataTableRecordValuesOutputReference;
}
export interface ConnectDataTableRecordDataTableRecord {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#primary_values ConnectDataTableRecord#primary_values}
    */
    readonly primaryValues?: ConnectDataTableRecordDataTableRecordPrimaryValues[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#values ConnectDataTableRecord#values}
    */
    readonly values: ConnectDataTableRecordDataTableRecordValues[] | cdktn.IResolvable;
}
export declare function connectDataTableRecordDataTableRecordToTerraform(struct?: ConnectDataTableRecordDataTableRecord | cdktn.IResolvable): any;
export declare function connectDataTableRecordDataTableRecordToHclTerraform(struct?: ConnectDataTableRecordDataTableRecord | cdktn.IResolvable): any;
export declare class ConnectDataTableRecordDataTableRecordOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectDataTableRecordDataTableRecord | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectDataTableRecordDataTableRecord | cdktn.IResolvable | undefined);
    private _primaryValues;
    get primaryValues(): ConnectDataTableRecordDataTableRecordPrimaryValuesList;
    putPrimaryValues(value: ConnectDataTableRecordDataTableRecordPrimaryValues[] | cdktn.IResolvable): void;
    resetPrimaryValues(): void;
    get primaryValuesInput(): cdktn.IResolvable | ConnectDataTableRecordDataTableRecordPrimaryValues[] | undefined;
    private _values;
    get values(): ConnectDataTableRecordDataTableRecordValuesList;
    putValues(value: ConnectDataTableRecordDataTableRecordValues[] | cdktn.IResolvable): void;
    get valuesInput(): cdktn.IResolvable | ConnectDataTableRecordDataTableRecordValues[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record awscc_connect_data_table_record}
*/
export declare class ConnectDataTableRecord extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_data_table_record";
    /**
    * Generates CDKTN code for importing a ConnectDataTableRecord resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectDataTableRecord to import
    * @param importFromId The id of the existing ConnectDataTableRecord that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectDataTableRecord to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_record awscc_connect_data_table_record} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectDataTableRecordConfig
    */
    constructor(scope: Construct, id: string, config: ConnectDataTableRecordConfig);
    private _dataTableArn?;
    get dataTableArn(): string;
    set dataTableArn(value: string);
    get dataTableArnInput(): string | undefined;
    private _dataTableRecord;
    get dataTableRecord(): ConnectDataTableRecordDataTableRecordOutputReference;
    putDataTableRecord(value: ConnectDataTableRecordDataTableRecord): void;
    get dataTableRecordInput(): cdktn.IResolvable | ConnectDataTableRecordDataTableRecord | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get recordId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
