/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudtrailTrailConfig extends cdktn.TerraformMetaArguments {
    /**
    * The advanced event selectors that were used to select events for the data store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#advanced_event_selectors CloudtrailTrail#advanced_event_selectors}
    */
    readonly advancedEventSelectors?: CloudtrailTrailAdvancedEventSelectors[] | cdktn.IResolvable;
    /**
    * Specifies the aggregation configuration to aggregate CloudTrail Events. A maximum of 1 aggregation configuration is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#aggregation_configurations CloudtrailTrail#aggregation_configurations}
    */
    readonly aggregationConfigurations?: CloudtrailTrailAggregationConfigurations[] | cdktn.IResolvable;
    /**
    * Specifies a log group name using an Amazon Resource Name (ARN), a unique identifier that represents the log group to which CloudTrail logs will be delivered. Not required unless you specify CloudWatchLogsRoleArn.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#cloudwatch_logs_log_group_arn CloudtrailTrail#cloudwatch_logs_log_group_arn}
    */
    readonly cloudwatchLogsLogGroupArn?: string;
    /**
    * Specifies the role for the CloudWatch Logs endpoint to assume to write to a user's log group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#cloudwatch_logs_role_arn CloudtrailTrail#cloudwatch_logs_role_arn}
    */
    readonly cloudwatchLogsRoleArn?: string;
    /**
    * Specifies whether log file validation is enabled. The default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#enable_log_file_validation CloudtrailTrail#enable_log_file_validation}
    */
    readonly enableLogFileValidation?: boolean | cdktn.IResolvable;
    /**
    * Use event selectors to further specify the management and data event settings for your trail. By default, trails created without specific event selectors will be configured to log all read and write management events, and no data events. When an event occurs in your account, CloudTrail evaluates the event selector for all trails. For each trail, if the event matches any event selector, the trail processes and logs the event. If the event doesn't match any event selector, the trail doesn't log the event. You can configure up to five event selectors for a trail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#event_selectors CloudtrailTrail#event_selectors}
    */
    readonly eventSelectors?: CloudtrailTrailEventSelectors[] | cdktn.IResolvable;
    /**
    * Specifies whether the trail is publishing events from global services such as IAM to the log files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#include_global_service_events CloudtrailTrail#include_global_service_events}
    */
    readonly includeGlobalServiceEvents?: boolean | cdktn.IResolvable;
    /**
    * Lets you enable Insights event logging by specifying the Insights selectors that you want to enable on an existing trail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#insight_selectors CloudtrailTrail#insight_selectors}
    */
    readonly insightSelectors?: CloudtrailTrailInsightSelectors[] | cdktn.IResolvable;
    /**
    * Whether the CloudTrail is currently logging AWS API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#is_logging CloudtrailTrail#is_logging}
    */
    readonly isLogging: boolean | cdktn.IResolvable;
    /**
    * Specifies whether the trail applies only to the current region or to all regions. The default is false. If the trail exists only in the current region and this value is set to true, shadow trails (replications of the trail) will be created in the other regions. If the trail exists in all regions and this value is set to false, the trail will remain in the region where it was created, and its shadow trails in other regions will be deleted. As a best practice, consider using trails that log events in all regions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#is_multi_region_trail CloudtrailTrail#is_multi_region_trail}
    */
    readonly isMultiRegionTrail?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether the trail is created for all accounts in an organization in AWS Organizations, or only for the current AWS account. The default is false, and cannot be true unless the call is made on behalf of an AWS account that is the master account for an organization in AWS Organizations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#is_organization_trail CloudtrailTrail#is_organization_trail}
    */
    readonly isOrganizationTrail?: boolean | cdktn.IResolvable;
    /**
    * Specifies the KMS key ID to use to encrypt the logs delivered by CloudTrail. The value can be an alias name prefixed by 'alias/', a fully specified ARN to an alias, a fully specified ARN to a key, or a globally unique identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#kms_key_id CloudtrailTrail#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Specifies the name of the Amazon S3 bucket designated for publishing log files. See Amazon S3 Bucket Naming Requirements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#s3_bucket_name CloudtrailTrail#s3_bucket_name}
    */
    readonly s3BucketName: string;
    /**
    * Specifies the Amazon S3 key prefix that comes after the name of the bucket you have designated for log file delivery. For more information, see Finding Your CloudTrail Log Files. The maximum length is 200 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#s3_key_prefix CloudtrailTrail#s3_key_prefix}
    */
    readonly s3KeyPrefix?: string;
    /**
    * Specifies the name of the Amazon SNS topic defined for notification of log file delivery. The maximum length is 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#sns_topic_name CloudtrailTrail#sns_topic_name}
    */
    readonly snsTopicName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#tags CloudtrailTrail#tags}
    */
    readonly tags?: CloudtrailTrailTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#trail_name CloudtrailTrail#trail_name}
    */
    readonly trailName?: string;
}
export interface CloudtrailTrailAdvancedEventSelectorsFieldSelectors {
    /**
    * An operator that includes events that match the last few characters of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#ends_with CloudtrailTrail#ends_with}
    */
    readonly endsWith?: string[];
    /**
    * An operator that includes events that match the exact value of the event record field specified as the value of Field. This is the only valid operator that you can use with the readOnly, eventCategory, and resources.type fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#equals CloudtrailTrail#equals}
    */
    readonly equalTo?: string[];
    /**
    * A field in an event record on which to filter events to be logged. Supported fields include readOnly, eventCategory, eventSource (for management events), eventName, resources.type, and resources.ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#field CloudtrailTrail#field}
    */
    readonly field?: string;
    /**
    * An operator that excludes events that match the last few characters of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#not_ends_with CloudtrailTrail#not_ends_with}
    */
    readonly notEndsWith?: string[];
    /**
    * An operator that excludes events that match the exact value of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#not_equals CloudtrailTrail#not_equals}
    */
    readonly notEquals?: string[];
    /**
    * An operator that excludes events that match the first few characters of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#not_starts_with CloudtrailTrail#not_starts_with}
    */
    readonly notStartsWith?: string[];
    /**
    * An operator that includes events that match the first few characters of the event record field specified as the value of Field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#starts_with CloudtrailTrail#starts_with}
    */
    readonly startsWith?: string[];
}
export declare function cloudtrailTrailAdvancedEventSelectorsFieldSelectorsToTerraform(struct?: CloudtrailTrailAdvancedEventSelectorsFieldSelectors | cdktn.IResolvable): any;
export declare function cloudtrailTrailAdvancedEventSelectorsFieldSelectorsToHclTerraform(struct?: CloudtrailTrailAdvancedEventSelectorsFieldSelectors | cdktn.IResolvable): any;
export declare class CloudtrailTrailAdvancedEventSelectorsFieldSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailTrailAdvancedEventSelectorsFieldSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailTrailAdvancedEventSelectorsFieldSelectors | cdktn.IResolvable | undefined);
    private _endsWith?;
    get endsWith(): string[];
    set endsWith(value: string[]);
    resetEndsWith(): void;
    get endsWithInput(): string[] | undefined;
    private _equals?;
    get equalTo(): string[];
    set equalTo(value: string[]);
    resetEqualTo(): void;
    get equalToInput(): string[] | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _notEndsWith?;
    get notEndsWith(): string[];
    set notEndsWith(value: string[]);
    resetNotEndsWith(): void;
    get notEndsWithInput(): string[] | undefined;
    private _notEquals?;
    get notEquals(): string[];
    set notEquals(value: string[]);
    resetNotEquals(): void;
    get notEqualsInput(): string[] | undefined;
    private _notStartsWith?;
    get notStartsWith(): string[];
    set notStartsWith(value: string[]);
    resetNotStartsWith(): void;
    get notStartsWithInput(): string[] | undefined;
    private _startsWith?;
    get startsWith(): string[];
    set startsWith(value: string[]);
    resetStartsWith(): void;
    get startsWithInput(): string[] | undefined;
}
export declare class CloudtrailTrailAdvancedEventSelectorsFieldSelectorsList extends cdktn.ComplexList {
    internalValue?: CloudtrailTrailAdvancedEventSelectorsFieldSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailTrailAdvancedEventSelectorsFieldSelectorsOutputReference;
}
export interface CloudtrailTrailAdvancedEventSelectors {
    /**
    * Contains all selector statements in an advanced event selector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#field_selectors CloudtrailTrail#field_selectors}
    */
    readonly fieldSelectors?: CloudtrailTrailAdvancedEventSelectorsFieldSelectors[] | cdktn.IResolvable;
    /**
    * An optional, descriptive name for an advanced event selector, such as "Log data events for only two S3 buckets".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#name CloudtrailTrail#name}
    */
    readonly name?: string;
}
export declare function cloudtrailTrailAdvancedEventSelectorsToTerraform(struct?: CloudtrailTrailAdvancedEventSelectors | cdktn.IResolvable): any;
export declare function cloudtrailTrailAdvancedEventSelectorsToHclTerraform(struct?: CloudtrailTrailAdvancedEventSelectors | cdktn.IResolvable): any;
export declare class CloudtrailTrailAdvancedEventSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailTrailAdvancedEventSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailTrailAdvancedEventSelectors | cdktn.IResolvable | undefined);
    private _fieldSelectors;
    get fieldSelectors(): CloudtrailTrailAdvancedEventSelectorsFieldSelectorsList;
    putFieldSelectors(value: CloudtrailTrailAdvancedEventSelectorsFieldSelectors[] | cdktn.IResolvable): void;
    resetFieldSelectors(): void;
    get fieldSelectorsInput(): cdktn.IResolvable | CloudtrailTrailAdvancedEventSelectorsFieldSelectors[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CloudtrailTrailAdvancedEventSelectorsList extends cdktn.ComplexList {
    internalValue?: CloudtrailTrailAdvancedEventSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailTrailAdvancedEventSelectorsOutputReference;
}
export interface CloudtrailTrailAggregationConfigurations {
    /**
    * The category of events to be aggregated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#event_category CloudtrailTrail#event_category}
    */
    readonly eventCategory?: string;
    /**
    * Contains all templates in an aggregation configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#templates CloudtrailTrail#templates}
    */
    readonly templates?: string[];
}
export declare function cloudtrailTrailAggregationConfigurationsToTerraform(struct?: CloudtrailTrailAggregationConfigurations | cdktn.IResolvable): any;
export declare function cloudtrailTrailAggregationConfigurationsToHclTerraform(struct?: CloudtrailTrailAggregationConfigurations | cdktn.IResolvable): any;
export declare class CloudtrailTrailAggregationConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailTrailAggregationConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailTrailAggregationConfigurations | cdktn.IResolvable | undefined);
    private _eventCategory?;
    get eventCategory(): string;
    set eventCategory(value: string);
    resetEventCategory(): void;
    get eventCategoryInput(): string | undefined;
    private _templates?;
    get templates(): string[];
    set templates(value: string[]);
    resetTemplates(): void;
    get templatesInput(): string[] | undefined;
}
export declare class CloudtrailTrailAggregationConfigurationsList extends cdktn.ComplexList {
    internalValue?: CloudtrailTrailAggregationConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailTrailAggregationConfigurationsOutputReference;
}
export interface CloudtrailTrailEventSelectorsDataResources {
    /**
    * The resource type in which you want to log data events. You can specify AWS::S3::Object or AWS::Lambda::Function resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#type CloudtrailTrail#type}
    */
    readonly type?: string;
    /**
    * An array of Amazon Resource Name (ARN) strings or partial ARN strings for the specified objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#values CloudtrailTrail#values}
    */
    readonly values?: string[];
}
export declare function cloudtrailTrailEventSelectorsDataResourcesToTerraform(struct?: CloudtrailTrailEventSelectorsDataResources | cdktn.IResolvable): any;
export declare function cloudtrailTrailEventSelectorsDataResourcesToHclTerraform(struct?: CloudtrailTrailEventSelectorsDataResources | cdktn.IResolvable): any;
export declare class CloudtrailTrailEventSelectorsDataResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailTrailEventSelectorsDataResources | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailTrailEventSelectorsDataResources | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CloudtrailTrailEventSelectorsDataResourcesList extends cdktn.ComplexList {
    internalValue?: CloudtrailTrailEventSelectorsDataResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailTrailEventSelectorsDataResourcesOutputReference;
}
export interface CloudtrailTrailEventSelectors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#data_resources CloudtrailTrail#data_resources}
    */
    readonly dataResources?: CloudtrailTrailEventSelectorsDataResources[] | cdktn.IResolvable;
    /**
    * An optional list of service event sources from which you do not want management events to be logged on your trail. In this release, the list can be empty (disables the filter), or it can filter out AWS Key Management Service events by containing "kms.amazonaws.com". By default, ExcludeManagementEventSources is empty, and AWS KMS events are included in events that are logged to your trail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#exclude_management_event_sources CloudtrailTrail#exclude_management_event_sources}
    */
    readonly excludeManagementEventSources?: string[];
    /**
    * Specify if you want your event selector to include management events for your trail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#include_management_events CloudtrailTrail#include_management_events}
    */
    readonly includeManagementEvents?: boolean | cdktn.IResolvable;
    /**
    * Specify if you want your trail to log read-only events, write-only events, or all. For example, the EC2 GetConsoleOutput is a read-only API operation and RunInstances is a write-only API operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#read_write_type CloudtrailTrail#read_write_type}
    */
    readonly readWriteType?: string;
}
export declare function cloudtrailTrailEventSelectorsToTerraform(struct?: CloudtrailTrailEventSelectors | cdktn.IResolvable): any;
export declare function cloudtrailTrailEventSelectorsToHclTerraform(struct?: CloudtrailTrailEventSelectors | cdktn.IResolvable): any;
export declare class CloudtrailTrailEventSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailTrailEventSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailTrailEventSelectors | cdktn.IResolvable | undefined);
    private _dataResources;
    get dataResources(): CloudtrailTrailEventSelectorsDataResourcesList;
    putDataResources(value: CloudtrailTrailEventSelectorsDataResources[] | cdktn.IResolvable): void;
    resetDataResources(): void;
    get dataResourcesInput(): cdktn.IResolvable | CloudtrailTrailEventSelectorsDataResources[] | undefined;
    private _excludeManagementEventSources?;
    get excludeManagementEventSources(): string[];
    set excludeManagementEventSources(value: string[]);
    resetExcludeManagementEventSources(): void;
    get excludeManagementEventSourcesInput(): string[] | undefined;
    private _includeManagementEvents?;
    get includeManagementEvents(): boolean | cdktn.IResolvable;
    set includeManagementEvents(value: boolean | cdktn.IResolvable);
    resetIncludeManagementEvents(): void;
    get includeManagementEventsInput(): boolean | cdktn.IResolvable | undefined;
    private _readWriteType?;
    get readWriteType(): string;
    set readWriteType(value: string);
    resetReadWriteType(): void;
    get readWriteTypeInput(): string | undefined;
}
export declare class CloudtrailTrailEventSelectorsList extends cdktn.ComplexList {
    internalValue?: CloudtrailTrailEventSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailTrailEventSelectorsOutputReference;
}
export interface CloudtrailTrailInsightSelectors {
    /**
    * The categories of events for which to log insights. By default, insights are logged for management events only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#event_categories CloudtrailTrail#event_categories}
    */
    readonly eventCategories?: string[];
    /**
    * The type of insight to log on a trail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#insight_type CloudtrailTrail#insight_type}
    */
    readonly insightType?: string;
}
export declare function cloudtrailTrailInsightSelectorsToTerraform(struct?: CloudtrailTrailInsightSelectors | cdktn.IResolvable): any;
export declare function cloudtrailTrailInsightSelectorsToHclTerraform(struct?: CloudtrailTrailInsightSelectors | cdktn.IResolvable): any;
export declare class CloudtrailTrailInsightSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailTrailInsightSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailTrailInsightSelectors | cdktn.IResolvable | undefined);
    private _eventCategories?;
    get eventCategories(): string[];
    set eventCategories(value: string[]);
    resetEventCategories(): void;
    get eventCategoriesInput(): string[] | undefined;
    private _insightType?;
    get insightType(): string;
    set insightType(value: string);
    resetInsightType(): void;
    get insightTypeInput(): string | undefined;
}
export declare class CloudtrailTrailInsightSelectorsList extends cdktn.ComplexList {
    internalValue?: CloudtrailTrailInsightSelectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailTrailInsightSelectorsOutputReference;
}
export interface CloudtrailTrailTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#key CloudtrailTrail#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#value CloudtrailTrail#value}
    */
    readonly value?: string;
}
export declare function cloudtrailTrailTagsToTerraform(struct?: CloudtrailTrailTags | cdktn.IResolvable): any;
export declare function cloudtrailTrailTagsToHclTerraform(struct?: CloudtrailTrailTags | cdktn.IResolvable): any;
export declare class CloudtrailTrailTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailTrailTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailTrailTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudtrailTrailTagsList extends cdktn.ComplexList {
    internalValue?: CloudtrailTrailTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailTrailTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail awscc_cloudtrail_trail}
*/
export declare class CloudtrailTrail extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudtrail_trail";
    /**
    * Generates CDKTN code for importing a CloudtrailTrail resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudtrailTrail to import
    * @param importFromId The id of the existing CloudtrailTrail that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudtrailTrail to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudtrail_trail awscc_cloudtrail_trail} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudtrailTrailConfig
    */
    constructor(scope: Construct, id: string, config: CloudtrailTrailConfig);
    private _advancedEventSelectors;
    get advancedEventSelectors(): CloudtrailTrailAdvancedEventSelectorsList;
    putAdvancedEventSelectors(value: CloudtrailTrailAdvancedEventSelectors[] | cdktn.IResolvable): void;
    resetAdvancedEventSelectors(): void;
    get advancedEventSelectorsInput(): cdktn.IResolvable | CloudtrailTrailAdvancedEventSelectors[] | undefined;
    private _aggregationConfigurations;
    get aggregationConfigurations(): CloudtrailTrailAggregationConfigurationsList;
    putAggregationConfigurations(value: CloudtrailTrailAggregationConfigurations[] | cdktn.IResolvable): void;
    resetAggregationConfigurations(): void;
    get aggregationConfigurationsInput(): cdktn.IResolvable | CloudtrailTrailAggregationConfigurations[] | undefined;
    get arn(): string;
    private _cloudwatchLogsLogGroupArn?;
    get cloudwatchLogsLogGroupArn(): string;
    set cloudwatchLogsLogGroupArn(value: string);
    resetCloudwatchLogsLogGroupArn(): void;
    get cloudwatchLogsLogGroupArnInput(): string | undefined;
    private _cloudwatchLogsRoleArn?;
    get cloudwatchLogsRoleArn(): string;
    set cloudwatchLogsRoleArn(value: string);
    resetCloudwatchLogsRoleArn(): void;
    get cloudwatchLogsRoleArnInput(): string | undefined;
    private _enableLogFileValidation?;
    get enableLogFileValidation(): boolean | cdktn.IResolvable;
    set enableLogFileValidation(value: boolean | cdktn.IResolvable);
    resetEnableLogFileValidation(): void;
    get enableLogFileValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _eventSelectors;
    get eventSelectors(): CloudtrailTrailEventSelectorsList;
    putEventSelectors(value: CloudtrailTrailEventSelectors[] | cdktn.IResolvable): void;
    resetEventSelectors(): void;
    get eventSelectorsInput(): cdktn.IResolvable | CloudtrailTrailEventSelectors[] | undefined;
    get id(): string;
    private _includeGlobalServiceEvents?;
    get includeGlobalServiceEvents(): boolean | cdktn.IResolvable;
    set includeGlobalServiceEvents(value: boolean | cdktn.IResolvable);
    resetIncludeGlobalServiceEvents(): void;
    get includeGlobalServiceEventsInput(): boolean | cdktn.IResolvable | undefined;
    private _insightSelectors;
    get insightSelectors(): CloudtrailTrailInsightSelectorsList;
    putInsightSelectors(value: CloudtrailTrailInsightSelectors[] | cdktn.IResolvable): void;
    resetInsightSelectors(): void;
    get insightSelectorsInput(): cdktn.IResolvable | CloudtrailTrailInsightSelectors[] | undefined;
    private _isLogging?;
    get isLogging(): boolean | cdktn.IResolvable;
    set isLogging(value: boolean | cdktn.IResolvable);
    get isLoggingInput(): boolean | cdktn.IResolvable | undefined;
    private _isMultiRegionTrail?;
    get isMultiRegionTrail(): boolean | cdktn.IResolvable;
    set isMultiRegionTrail(value: boolean | cdktn.IResolvable);
    resetIsMultiRegionTrail(): void;
    get isMultiRegionTrailInput(): boolean | cdktn.IResolvable | undefined;
    private _isOrganizationTrail?;
    get isOrganizationTrail(): boolean | cdktn.IResolvable;
    set isOrganizationTrail(value: boolean | cdktn.IResolvable);
    resetIsOrganizationTrail(): void;
    get isOrganizationTrailInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    get s3BucketNameInput(): string | undefined;
    private _s3KeyPrefix?;
    get s3KeyPrefix(): string;
    set s3KeyPrefix(value: string);
    resetS3KeyPrefix(): void;
    get s3KeyPrefixInput(): string | undefined;
    get snsTopicArn(): string;
    private _snsTopicName?;
    get snsTopicName(): string;
    set snsTopicName(value: string);
    resetSnsTopicName(): void;
    get snsTopicNameInput(): string | undefined;
    private _tags;
    get tags(): CloudtrailTrailTagsList;
    putTags(value: CloudtrailTrailTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudtrailTrailTags[] | undefined;
    private _trailName?;
    get trailName(): string;
    set trailName(value: string);
    resetTrailName(): void;
    get trailNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
