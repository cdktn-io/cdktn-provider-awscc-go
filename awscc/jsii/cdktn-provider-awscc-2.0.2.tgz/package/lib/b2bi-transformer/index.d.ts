/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface B2BiTransformerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#edi_type B2BiTransformer#edi_type}
    */
    readonly ediType?: B2BiTransformerEdiType;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#file_format B2BiTransformer#file_format}
    */
    readonly fileFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#input_conversion B2BiTransformer#input_conversion}
    */
    readonly inputConversion?: B2BiTransformerInputConversion;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#mapping B2BiTransformer#mapping}
    */
    readonly mapping?: B2BiTransformerMapping;
    /**
    * This shape is deprecated: This is a legacy trait. Please use input-conversion or output-conversion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#mapping_template B2BiTransformer#mapping_template}
    */
    readonly mappingTemplate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#name B2BiTransformer#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#output_conversion B2BiTransformer#output_conversion}
    */
    readonly outputConversion?: B2BiTransformerOutputConversion;
    /**
    * This shape is deprecated: This is a legacy trait. Please use input-conversion or output-conversion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#sample_document B2BiTransformer#sample_document}
    */
    readonly sampleDocument?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#sample_documents B2BiTransformer#sample_documents}
    */
    readonly sampleDocuments?: B2BiTransformerSampleDocuments;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#status B2BiTransformer#status}
    */
    readonly status: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#tags B2BiTransformer#tags}
    */
    readonly tags?: B2BiTransformerTags[] | cdktn.IResolvable;
}
export interface B2BiTransformerEdiTypeX12Details {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#transaction_set B2BiTransformer#transaction_set}
    */
    readonly transactionSet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#version B2BiTransformer#version}
    */
    readonly version?: string;
}
export declare function b2BiTransformerEdiTypeX12DetailsToTerraform(struct?: B2BiTransformerEdiTypeX12Details | cdktn.IResolvable): any;
export declare function b2BiTransformerEdiTypeX12DetailsToHclTerraform(struct?: B2BiTransformerEdiTypeX12Details | cdktn.IResolvable): any;
export declare class B2BiTransformerEdiTypeX12DetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerEdiTypeX12Details | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerEdiTypeX12Details | cdktn.IResolvable | undefined);
    private _transactionSet?;
    get transactionSet(): string;
    set transactionSet(value: string);
    resetTransactionSet(): void;
    get transactionSetInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface B2BiTransformerEdiType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#x12_details B2BiTransformer#x12_details}
    */
    readonly x12Details?: B2BiTransformerEdiTypeX12Details;
}
export declare function b2BiTransformerEdiTypeToTerraform(struct?: B2BiTransformerEdiType | cdktn.IResolvable): any;
export declare function b2BiTransformerEdiTypeToHclTerraform(struct?: B2BiTransformerEdiType | cdktn.IResolvable): any;
export declare class B2BiTransformerEdiTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerEdiType | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerEdiType | cdktn.IResolvable | undefined);
    private _x12Details;
    get x12Details(): B2BiTransformerEdiTypeX12DetailsOutputReference;
    putX12Details(value: B2BiTransformerEdiTypeX12Details): void;
    resetX12Details(): void;
    get x12DetailsInput(): cdktn.IResolvable | B2BiTransformerEdiTypeX12Details | undefined;
}
export interface B2BiTransformerInputConversionAdvancedOptionsX12SplitOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#split_by B2BiTransformer#split_by}
    */
    readonly splitBy?: string;
}
export declare function b2BiTransformerInputConversionAdvancedOptionsX12SplitOptionsToTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12SplitOptions | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionAdvancedOptionsX12SplitOptionsToHclTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12SplitOptions | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionAdvancedOptionsX12SplitOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionAdvancedOptionsX12SplitOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionAdvancedOptionsX12SplitOptions | cdktn.IResolvable | undefined);
    private _splitBy?;
    get splitBy(): string;
    set splitBy(value: string);
    resetSplitBy(): void;
    get splitByInput(): string | undefined;
}
export interface B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#codes_to_add B2BiTransformer#codes_to_add}
    */
    readonly codesToAdd?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#codes_to_remove B2BiTransformer#codes_to_remove}
    */
    readonly codesToRemove?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_id B2BiTransformer#element_id}
    */
    readonly elementId?: string;
}
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRuleToTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRuleToHclTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | cdktn.IResolvable | undefined);
    private _codesToAdd?;
    get codesToAdd(): string[];
    set codesToAdd(value: string[]);
    resetCodesToAdd(): void;
    get codesToAddInput(): string[] | undefined;
    private _codesToRemove?;
    get codesToRemove(): string[];
    set codesToRemove(value: string[]);
    resetCodesToRemove(): void;
    get codesToRemoveInput(): string[] | undefined;
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    resetElementId(): void;
    get elementIdInput(): string | undefined;
}
export interface B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_id B2BiTransformer#element_id}
    */
    readonly elementId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#max_length B2BiTransformer#max_length}
    */
    readonly maxLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#min_length B2BiTransformer#min_length}
    */
    readonly minLength?: number;
}
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRuleToTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRuleToHclTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | cdktn.IResolvable | undefined);
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    resetElementId(): void;
    get elementIdInput(): string | undefined;
    private _maxLength?;
    get maxLength(): number;
    set maxLength(value: number);
    resetMaxLength(): void;
    get maxLengthInput(): number | undefined;
    private _minLength?;
    get minLength(): number;
    set minLength(value: number);
    resetMinLength(): void;
    get minLengthInput(): number | undefined;
}
export interface B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_position B2BiTransformer#element_position}
    */
    readonly elementPosition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#requirement B2BiTransformer#requirement}
    */
    readonly requirement?: string;
}
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRuleToTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRuleToHclTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | cdktn.IResolvable | undefined);
    private _elementPosition?;
    get elementPosition(): string;
    set elementPosition(value: string);
    resetElementPosition(): void;
    get elementPositionInput(): string | undefined;
    private _requirement?;
    get requirement(): string;
    set requirement(value: string);
    resetRequirement(): void;
    get requirementInput(): string | undefined;
}
export interface B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#code_list_validation_rule B2BiTransformer#code_list_validation_rule}
    */
    readonly codeListValidationRule?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_length_validation_rule B2BiTransformer#element_length_validation_rule}
    */
    readonly elementLengthValidationRule?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_requirement_validation_rule B2BiTransformer#element_requirement_validation_rule}
    */
    readonly elementRequirementValidationRule?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule;
}
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesToTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesToHclTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules | cdktn.IResolvable | undefined);
    private _codeListValidationRule;
    get codeListValidationRule(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRuleOutputReference;
    putCodeListValidationRule(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule): void;
    resetCodeListValidationRule(): void;
    get codeListValidationRuleInput(): cdktn.IResolvable | B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | undefined;
    private _elementLengthValidationRule;
    get elementLengthValidationRule(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRuleOutputReference;
    putElementLengthValidationRule(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule): void;
    resetElementLengthValidationRule(): void;
    get elementLengthValidationRuleInput(): cdktn.IResolvable | B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | undefined;
    private _elementRequirementValidationRule;
    get elementRequirementValidationRule(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRuleOutputReference;
    putElementRequirementValidationRule(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule): void;
    resetElementRequirementValidationRule(): void;
    get elementRequirementValidationRuleInput(): cdktn.IResolvable | B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | undefined;
}
export declare class B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesList extends cdktn.ComplexList {
    internalValue?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesOutputReference;
}
export interface B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#validation_rules B2BiTransformer#validation_rules}
    */
    readonly validationRules?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules[] | cdktn.IResolvable;
}
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsToTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptions | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsToHclTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptions | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptions | cdktn.IResolvable | undefined);
    private _validationRules;
    get validationRules(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRulesList;
    putValidationRules(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules[] | cdktn.IResolvable): void;
    resetValidationRules(): void;
    get validationRulesInput(): cdktn.IResolvable | B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsValidationRules[] | undefined;
}
export interface B2BiTransformerInputConversionAdvancedOptionsX12 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#split_options B2BiTransformer#split_options}
    */
    readonly splitOptions?: B2BiTransformerInputConversionAdvancedOptionsX12SplitOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#validation_options B2BiTransformer#validation_options}
    */
    readonly validationOptions?: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptions;
}
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ToTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12 | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionAdvancedOptionsX12ToHclTerraform(struct?: B2BiTransformerInputConversionAdvancedOptionsX12 | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionAdvancedOptionsX12OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionAdvancedOptionsX12 | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionAdvancedOptionsX12 | cdktn.IResolvable | undefined);
    private _splitOptions;
    get splitOptions(): B2BiTransformerInputConversionAdvancedOptionsX12SplitOptionsOutputReference;
    putSplitOptions(value: B2BiTransformerInputConversionAdvancedOptionsX12SplitOptions): void;
    resetSplitOptions(): void;
    get splitOptionsInput(): cdktn.IResolvable | B2BiTransformerInputConversionAdvancedOptionsX12SplitOptions | undefined;
    private _validationOptions;
    get validationOptions(): B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptionsOutputReference;
    putValidationOptions(value: B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptions): void;
    resetValidationOptions(): void;
    get validationOptionsInput(): cdktn.IResolvable | B2BiTransformerInputConversionAdvancedOptionsX12ValidationOptions | undefined;
}
export interface B2BiTransformerInputConversionAdvancedOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#x12 B2BiTransformer#x12}
    */
    readonly x12?: B2BiTransformerInputConversionAdvancedOptionsX12;
}
export declare function b2BiTransformerInputConversionAdvancedOptionsToTerraform(struct?: B2BiTransformerInputConversionAdvancedOptions | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionAdvancedOptionsToHclTerraform(struct?: B2BiTransformerInputConversionAdvancedOptions | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionAdvancedOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionAdvancedOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionAdvancedOptions | cdktn.IResolvable | undefined);
    private _x12;
    get x12(): B2BiTransformerInputConversionAdvancedOptionsX12OutputReference;
    putX12(value: B2BiTransformerInputConversionAdvancedOptionsX12): void;
    resetX12(): void;
    get x12Input(): cdktn.IResolvable | B2BiTransformerInputConversionAdvancedOptionsX12 | undefined;
}
export interface B2BiTransformerInputConversionFormatOptionsX12 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#transaction_set B2BiTransformer#transaction_set}
    */
    readonly transactionSet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#version B2BiTransformer#version}
    */
    readonly version?: string;
}
export declare function b2BiTransformerInputConversionFormatOptionsX12ToTerraform(struct?: B2BiTransformerInputConversionFormatOptionsX12 | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionFormatOptionsX12ToHclTerraform(struct?: B2BiTransformerInputConversionFormatOptionsX12 | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionFormatOptionsX12OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionFormatOptionsX12 | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionFormatOptionsX12 | cdktn.IResolvable | undefined);
    private _transactionSet?;
    get transactionSet(): string;
    set transactionSet(value: string);
    resetTransactionSet(): void;
    get transactionSetInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface B2BiTransformerInputConversionFormatOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#x12 B2BiTransformer#x12}
    */
    readonly x12?: B2BiTransformerInputConversionFormatOptionsX12;
}
export declare function b2BiTransformerInputConversionFormatOptionsToTerraform(struct?: B2BiTransformerInputConversionFormatOptions | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionFormatOptionsToHclTerraform(struct?: B2BiTransformerInputConversionFormatOptions | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionFormatOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversionFormatOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversionFormatOptions | cdktn.IResolvable | undefined);
    private _x12;
    get x12(): B2BiTransformerInputConversionFormatOptionsX12OutputReference;
    putX12(value: B2BiTransformerInputConversionFormatOptionsX12): void;
    resetX12(): void;
    get x12Input(): cdktn.IResolvable | B2BiTransformerInputConversionFormatOptionsX12 | undefined;
}
export interface B2BiTransformerInputConversion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#advanced_options B2BiTransformer#advanced_options}
    */
    readonly advancedOptions?: B2BiTransformerInputConversionAdvancedOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#format_options B2BiTransformer#format_options}
    */
    readonly formatOptions?: B2BiTransformerInputConversionFormatOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#from_format B2BiTransformer#from_format}
    */
    readonly fromFormat?: string;
}
export declare function b2BiTransformerInputConversionToTerraform(struct?: B2BiTransformerInputConversion | cdktn.IResolvable): any;
export declare function b2BiTransformerInputConversionToHclTerraform(struct?: B2BiTransformerInputConversion | cdktn.IResolvable): any;
export declare class B2BiTransformerInputConversionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerInputConversion | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerInputConversion | cdktn.IResolvable | undefined);
    private _advancedOptions;
    get advancedOptions(): B2BiTransformerInputConversionAdvancedOptionsOutputReference;
    putAdvancedOptions(value: B2BiTransformerInputConversionAdvancedOptions): void;
    resetAdvancedOptions(): void;
    get advancedOptionsInput(): cdktn.IResolvable | B2BiTransformerInputConversionAdvancedOptions | undefined;
    private _formatOptions;
    get formatOptions(): B2BiTransformerInputConversionFormatOptionsOutputReference;
    putFormatOptions(value: B2BiTransformerInputConversionFormatOptions): void;
    resetFormatOptions(): void;
    get formatOptionsInput(): cdktn.IResolvable | B2BiTransformerInputConversionFormatOptions | undefined;
    private _fromFormat?;
    get fromFormat(): string;
    set fromFormat(value: string);
    resetFromFormat(): void;
    get fromFormatInput(): string | undefined;
}
export interface B2BiTransformerMapping {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#template B2BiTransformer#template}
    */
    readonly template?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#template_language B2BiTransformer#template_language}
    */
    readonly templateLanguage?: string;
}
export declare function b2BiTransformerMappingToTerraform(struct?: B2BiTransformerMapping | cdktn.IResolvable): any;
export declare function b2BiTransformerMappingToHclTerraform(struct?: B2BiTransformerMapping | cdktn.IResolvable): any;
export declare class B2BiTransformerMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerMapping | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerMapping | cdktn.IResolvable | undefined);
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
    private _templateLanguage?;
    get templateLanguage(): string;
    set templateLanguage(value: string);
    resetTemplateLanguage(): void;
    get templateLanguageInput(): string | undefined;
}
export interface B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#split_by B2BiTransformer#split_by}
    */
    readonly splitBy?: string;
}
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12SplitOptionsToTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptions | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12SplitOptionsToHclTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptions | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptions | cdktn.IResolvable | undefined);
    private _splitBy?;
    get splitBy(): string;
    set splitBy(value: string);
    resetSplitBy(): void;
    get splitByInput(): string | undefined;
}
export interface B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#codes_to_add B2BiTransformer#codes_to_add}
    */
    readonly codesToAdd?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#codes_to_remove B2BiTransformer#codes_to_remove}
    */
    readonly codesToRemove?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_id B2BiTransformer#element_id}
    */
    readonly elementId?: string;
}
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRuleToTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRuleToHclTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | cdktn.IResolvable | undefined);
    private _codesToAdd?;
    get codesToAdd(): string[];
    set codesToAdd(value: string[]);
    resetCodesToAdd(): void;
    get codesToAddInput(): string[] | undefined;
    private _codesToRemove?;
    get codesToRemove(): string[];
    set codesToRemove(value: string[]);
    resetCodesToRemove(): void;
    get codesToRemoveInput(): string[] | undefined;
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    resetElementId(): void;
    get elementIdInput(): string | undefined;
}
export interface B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_id B2BiTransformer#element_id}
    */
    readonly elementId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#max_length B2BiTransformer#max_length}
    */
    readonly maxLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#min_length B2BiTransformer#min_length}
    */
    readonly minLength?: number;
}
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRuleToTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRuleToHclTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | cdktn.IResolvable | undefined);
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    resetElementId(): void;
    get elementIdInput(): string | undefined;
    private _maxLength?;
    get maxLength(): number;
    set maxLength(value: number);
    resetMaxLength(): void;
    get maxLengthInput(): number | undefined;
    private _minLength?;
    get minLength(): number;
    set minLength(value: number);
    resetMinLength(): void;
    get minLengthInput(): number | undefined;
}
export interface B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_position B2BiTransformer#element_position}
    */
    readonly elementPosition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#requirement B2BiTransformer#requirement}
    */
    readonly requirement?: string;
}
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRuleToTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRuleToHclTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | cdktn.IResolvable | undefined);
    private _elementPosition?;
    get elementPosition(): string;
    set elementPosition(value: string);
    resetElementPosition(): void;
    get elementPositionInput(): string | undefined;
    private _requirement?;
    get requirement(): string;
    set requirement(value: string);
    resetRequirement(): void;
    get requirementInput(): string | undefined;
}
export interface B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#code_list_validation_rule B2BiTransformer#code_list_validation_rule}
    */
    readonly codeListValidationRule?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_length_validation_rule B2BiTransformer#element_length_validation_rule}
    */
    readonly elementLengthValidationRule?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#element_requirement_validation_rule B2BiTransformer#element_requirement_validation_rule}
    */
    readonly elementRequirementValidationRule?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule;
}
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesToTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesToHclTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules | cdktn.IResolvable | undefined);
    private _codeListValidationRule;
    get codeListValidationRule(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRuleOutputReference;
    putCodeListValidationRule(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule): void;
    resetCodeListValidationRule(): void;
    get codeListValidationRuleInput(): cdktn.IResolvable | B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesCodeListValidationRule | undefined;
    private _elementLengthValidationRule;
    get elementLengthValidationRule(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRuleOutputReference;
    putElementLengthValidationRule(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule): void;
    resetElementLengthValidationRule(): void;
    get elementLengthValidationRuleInput(): cdktn.IResolvable | B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementLengthValidationRule | undefined;
    private _elementRequirementValidationRule;
    get elementRequirementValidationRule(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRuleOutputReference;
    putElementRequirementValidationRule(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule): void;
    resetElementRequirementValidationRule(): void;
    get elementRequirementValidationRuleInput(): cdktn.IResolvable | B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesElementRequirementValidationRule | undefined;
}
export declare class B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesList extends cdktn.ComplexList {
    internalValue?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesOutputReference;
}
export interface B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#validation_rules B2BiTransformer#validation_rules}
    */
    readonly validationRules?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules[] | cdktn.IResolvable;
}
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsToTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptions | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsToHclTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptions | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptions | cdktn.IResolvable | undefined);
    private _validationRules;
    get validationRules(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRulesList;
    putValidationRules(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules[] | cdktn.IResolvable): void;
    resetValidationRules(): void;
    get validationRulesInput(): cdktn.IResolvable | B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsValidationRules[] | undefined;
}
export interface B2BiTransformerOutputConversionAdvancedOptionsX12 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#split_options B2BiTransformer#split_options}
    */
    readonly splitOptions?: B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#validation_options B2BiTransformer#validation_options}
    */
    readonly validationOptions?: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptions;
}
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ToTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12 | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionAdvancedOptionsX12ToHclTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptionsX12 | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionAdvancedOptionsX12OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionAdvancedOptionsX12 | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionAdvancedOptionsX12 | cdktn.IResolvable | undefined);
    private _splitOptions;
    get splitOptions(): B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptionsOutputReference;
    putSplitOptions(value: B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptions): void;
    resetSplitOptions(): void;
    get splitOptionsInput(): cdktn.IResolvable | B2BiTransformerOutputConversionAdvancedOptionsX12SplitOptions | undefined;
    private _validationOptions;
    get validationOptions(): B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptionsOutputReference;
    putValidationOptions(value: B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptions): void;
    resetValidationOptions(): void;
    get validationOptionsInput(): cdktn.IResolvable | B2BiTransformerOutputConversionAdvancedOptionsX12ValidationOptions | undefined;
}
export interface B2BiTransformerOutputConversionAdvancedOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#x12 B2BiTransformer#x12}
    */
    readonly x12?: B2BiTransformerOutputConversionAdvancedOptionsX12;
}
export declare function b2BiTransformerOutputConversionAdvancedOptionsToTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptions | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionAdvancedOptionsToHclTerraform(struct?: B2BiTransformerOutputConversionAdvancedOptions | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionAdvancedOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionAdvancedOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionAdvancedOptions | cdktn.IResolvable | undefined);
    private _x12;
    get x12(): B2BiTransformerOutputConversionAdvancedOptionsX12OutputReference;
    putX12(value: B2BiTransformerOutputConversionAdvancedOptionsX12): void;
    resetX12(): void;
    get x12Input(): cdktn.IResolvable | B2BiTransformerOutputConversionAdvancedOptionsX12 | undefined;
}
export interface B2BiTransformerOutputConversionFormatOptionsX12 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#transaction_set B2BiTransformer#transaction_set}
    */
    readonly transactionSet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#version B2BiTransformer#version}
    */
    readonly version?: string;
}
export declare function b2BiTransformerOutputConversionFormatOptionsX12ToTerraform(struct?: B2BiTransformerOutputConversionFormatOptionsX12 | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionFormatOptionsX12ToHclTerraform(struct?: B2BiTransformerOutputConversionFormatOptionsX12 | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionFormatOptionsX12OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionFormatOptionsX12 | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionFormatOptionsX12 | cdktn.IResolvable | undefined);
    private _transactionSet?;
    get transactionSet(): string;
    set transactionSet(value: string);
    resetTransactionSet(): void;
    get transactionSetInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface B2BiTransformerOutputConversionFormatOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#x12 B2BiTransformer#x12}
    */
    readonly x12?: B2BiTransformerOutputConversionFormatOptionsX12;
}
export declare function b2BiTransformerOutputConversionFormatOptionsToTerraform(struct?: B2BiTransformerOutputConversionFormatOptions | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionFormatOptionsToHclTerraform(struct?: B2BiTransformerOutputConversionFormatOptions | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionFormatOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversionFormatOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversionFormatOptions | cdktn.IResolvable | undefined);
    private _x12;
    get x12(): B2BiTransformerOutputConversionFormatOptionsX12OutputReference;
    putX12(value: B2BiTransformerOutputConversionFormatOptionsX12): void;
    resetX12(): void;
    get x12Input(): cdktn.IResolvable | B2BiTransformerOutputConversionFormatOptionsX12 | undefined;
}
export interface B2BiTransformerOutputConversion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#advanced_options B2BiTransformer#advanced_options}
    */
    readonly advancedOptions?: B2BiTransformerOutputConversionAdvancedOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#format_options B2BiTransformer#format_options}
    */
    readonly formatOptions?: B2BiTransformerOutputConversionFormatOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#to_format B2BiTransformer#to_format}
    */
    readonly toFormat?: string;
}
export declare function b2BiTransformerOutputConversionToTerraform(struct?: B2BiTransformerOutputConversion | cdktn.IResolvable): any;
export declare function b2BiTransformerOutputConversionToHclTerraform(struct?: B2BiTransformerOutputConversion | cdktn.IResolvable): any;
export declare class B2BiTransformerOutputConversionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerOutputConversion | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerOutputConversion | cdktn.IResolvable | undefined);
    private _advancedOptions;
    get advancedOptions(): B2BiTransformerOutputConversionAdvancedOptionsOutputReference;
    putAdvancedOptions(value: B2BiTransformerOutputConversionAdvancedOptions): void;
    resetAdvancedOptions(): void;
    get advancedOptionsInput(): cdktn.IResolvable | B2BiTransformerOutputConversionAdvancedOptions | undefined;
    private _formatOptions;
    get formatOptions(): B2BiTransformerOutputConversionFormatOptionsOutputReference;
    putFormatOptions(value: B2BiTransformerOutputConversionFormatOptions): void;
    resetFormatOptions(): void;
    get formatOptionsInput(): cdktn.IResolvable | B2BiTransformerOutputConversionFormatOptions | undefined;
    private _toFormat?;
    get toFormat(): string;
    set toFormat(value: string);
    resetToFormat(): void;
    get toFormatInput(): string | undefined;
}
export interface B2BiTransformerSampleDocumentsKeys {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#input B2BiTransformer#input}
    */
    readonly input?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#output B2BiTransformer#output}
    */
    readonly output?: string;
}
export declare function b2BiTransformerSampleDocumentsKeysToTerraform(struct?: B2BiTransformerSampleDocumentsKeys | cdktn.IResolvable): any;
export declare function b2BiTransformerSampleDocumentsKeysToHclTerraform(struct?: B2BiTransformerSampleDocumentsKeys | cdktn.IResolvable): any;
export declare class B2BiTransformerSampleDocumentsKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): B2BiTransformerSampleDocumentsKeys | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerSampleDocumentsKeys | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    private _output?;
    get output(): string;
    set output(value: string);
    resetOutput(): void;
    get outputInput(): string | undefined;
}
export declare class B2BiTransformerSampleDocumentsKeysList extends cdktn.ComplexList {
    internalValue?: B2BiTransformerSampleDocumentsKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): B2BiTransformerSampleDocumentsKeysOutputReference;
}
export interface B2BiTransformerSampleDocuments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#bucket_name B2BiTransformer#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#keys B2BiTransformer#keys}
    */
    readonly keys?: B2BiTransformerSampleDocumentsKeys[] | cdktn.IResolvable;
}
export declare function b2BiTransformerSampleDocumentsToTerraform(struct?: B2BiTransformerSampleDocuments | cdktn.IResolvable): any;
export declare function b2BiTransformerSampleDocumentsToHclTerraform(struct?: B2BiTransformerSampleDocuments | cdktn.IResolvable): any;
export declare class B2BiTransformerSampleDocumentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiTransformerSampleDocuments | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerSampleDocuments | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _keys;
    get keys(): B2BiTransformerSampleDocumentsKeysList;
    putKeys(value: B2BiTransformerSampleDocumentsKeys[] | cdktn.IResolvable): void;
    resetKeys(): void;
    get keysInput(): cdktn.IResolvable | B2BiTransformerSampleDocumentsKeys[] | undefined;
}
export interface B2BiTransformerTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#key B2BiTransformer#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#value B2BiTransformer#value}
    */
    readonly value?: string;
}
export declare function b2BiTransformerTagsToTerraform(struct?: B2BiTransformerTags | cdktn.IResolvable): any;
export declare function b2BiTransformerTagsToHclTerraform(struct?: B2BiTransformerTags | cdktn.IResolvable): any;
export declare class B2BiTransformerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): B2BiTransformerTags | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiTransformerTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class B2BiTransformerTagsList extends cdktn.ComplexList {
    internalValue?: B2BiTransformerTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): B2BiTransformerTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer awscc_b2bi_transformer}
*/
export declare class B2BiTransformer extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_b2bi_transformer";
    /**
    * Generates CDKTN code for importing a B2BiTransformer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the B2BiTransformer to import
    * @param importFromId The id of the existing B2BiTransformer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the B2BiTransformer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/b2bi_transformer awscc_b2bi_transformer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options B2BiTransformerConfig
    */
    constructor(scope: Construct, id: string, config: B2BiTransformerConfig);
    get createdAt(): string;
    private _ediType;
    get ediType(): B2BiTransformerEdiTypeOutputReference;
    putEdiType(value: B2BiTransformerEdiType): void;
    resetEdiType(): void;
    get ediTypeInput(): cdktn.IResolvable | B2BiTransformerEdiType | undefined;
    private _fileFormat?;
    get fileFormat(): string;
    set fileFormat(value: string);
    resetFileFormat(): void;
    get fileFormatInput(): string | undefined;
    get id(): string;
    private _inputConversion;
    get inputConversion(): B2BiTransformerInputConversionOutputReference;
    putInputConversion(value: B2BiTransformerInputConversion): void;
    resetInputConversion(): void;
    get inputConversionInput(): cdktn.IResolvable | B2BiTransformerInputConversion | undefined;
    private _mapping;
    get mapping(): B2BiTransformerMappingOutputReference;
    putMapping(value: B2BiTransformerMapping): void;
    resetMapping(): void;
    get mappingInput(): cdktn.IResolvable | B2BiTransformerMapping | undefined;
    private _mappingTemplate?;
    get mappingTemplate(): string;
    set mappingTemplate(value: string);
    resetMappingTemplate(): void;
    get mappingTemplateInput(): string | undefined;
    get modifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputConversion;
    get outputConversion(): B2BiTransformerOutputConversionOutputReference;
    putOutputConversion(value: B2BiTransformerOutputConversion): void;
    resetOutputConversion(): void;
    get outputConversionInput(): cdktn.IResolvable | B2BiTransformerOutputConversion | undefined;
    private _sampleDocument?;
    get sampleDocument(): string;
    set sampleDocument(value: string);
    resetSampleDocument(): void;
    get sampleDocumentInput(): string | undefined;
    private _sampleDocuments;
    get sampleDocuments(): B2BiTransformerSampleDocumentsOutputReference;
    putSampleDocuments(value: B2BiTransformerSampleDocuments): void;
    resetSampleDocuments(): void;
    get sampleDocumentsInput(): cdktn.IResolvable | B2BiTransformerSampleDocuments | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _tags;
    get tags(): B2BiTransformerTagsList;
    putTags(value: B2BiTransformerTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | B2BiTransformerTags[] | undefined;
    get transformerArn(): string;
    get transformerId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
