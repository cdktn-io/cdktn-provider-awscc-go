/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertificatemanagerAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/certificatemanager_account#expiry_events_configuration CertificatemanagerAccount#expiry_events_configuration}
    */
    readonly expiryEventsConfiguration: CertificatemanagerAccountExpiryEventsConfiguration;
}
export interface CertificatemanagerAccountExpiryEventsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/certificatemanager_account#days_before_expiry CertificatemanagerAccount#days_before_expiry}
    */
    readonly daysBeforeExpiry?: number;
}
export declare function certificatemanagerAccountExpiryEventsConfigurationToTerraform(struct?: CertificatemanagerAccountExpiryEventsConfiguration | cdktn.IResolvable): any;
export declare function certificatemanagerAccountExpiryEventsConfigurationToHclTerraform(struct?: CertificatemanagerAccountExpiryEventsConfiguration | cdktn.IResolvable): any;
export declare class CertificatemanagerAccountExpiryEventsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CertificatemanagerAccountExpiryEventsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CertificatemanagerAccountExpiryEventsConfiguration | cdktn.IResolvable | undefined);
    private _daysBeforeExpiry?;
    get daysBeforeExpiry(): number;
    set daysBeforeExpiry(value: number);
    resetDaysBeforeExpiry(): void;
    get daysBeforeExpiryInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/certificatemanager_account awscc_certificatemanager_account}
*/
export declare class CertificatemanagerAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_certificatemanager_account";
    /**
    * Generates CDKTN code for importing a CertificatemanagerAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertificatemanagerAccount to import
    * @param importFromId The id of the existing CertificatemanagerAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/certificatemanager_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertificatemanagerAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/certificatemanager_account awscc_certificatemanager_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertificatemanagerAccountConfig
    */
    constructor(scope: Construct, id: string, config: CertificatemanagerAccountConfig);
    get accountId(): string;
    private _expiryEventsConfiguration;
    get expiryEventsConfiguration(): CertificatemanagerAccountExpiryEventsConfigurationOutputReference;
    putExpiryEventsConfiguration(value: CertificatemanagerAccountExpiryEventsConfiguration): void;
    get expiryEventsConfigurationInput(): cdktn.IResolvable | CertificatemanagerAccountExpiryEventsConfiguration | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
