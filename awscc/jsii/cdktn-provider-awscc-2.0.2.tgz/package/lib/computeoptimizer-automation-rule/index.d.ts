/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComputeoptimizerAutomationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter criteria that specify which recommended actions qualify for implementation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#criteria ComputeoptimizerAutomationRule#criteria}
    */
    readonly criteria?: ComputeoptimizerAutomationRuleCriteria;
    /**
    * The description of the automation rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#description ComputeoptimizerAutomationRule#description}
    */
    readonly description?: string;
    /**
    * The name of the automation rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#name ComputeoptimizerAutomationRule#name}
    */
    readonly name: string;
    /**
    * Organization configuration for organization rules, including rule apply order and account scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#organization_configuration ComputeoptimizerAutomationRule#organization_configuration}
    */
    readonly organizationConfiguration?: ComputeoptimizerAutomationRuleOrganizationConfiguration;
    /**
    * Rule priority within its group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#priority ComputeoptimizerAutomationRule#priority}
    */
    readonly priority?: string;
    /**
    * The types of recommended actions this rule will implement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#recommended_action_types ComputeoptimizerAutomationRule#recommended_action_types}
    */
    readonly recommendedActionTypes: string[];
    /**
    * The type of automation rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#rule_type ComputeoptimizerAutomationRule#rule_type}
    */
    readonly ruleType: string;
    /**
    * The schedule configuration for when the rule runs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#schedule ComputeoptimizerAutomationRule#schedule}
    */
    readonly schedule: ComputeoptimizerAutomationRuleSchedule;
    /**
    * The status of the automation rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#status ComputeoptimizerAutomationRule#status}
    */
    readonly status: string;
    /**
    * Tags associated with the automation rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#tags ComputeoptimizerAutomationRule#tags}
    */
    readonly tags?: ComputeoptimizerAutomationRuleTags[] | cdktn.IResolvable;
}
export interface ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#comparison ComputeoptimizerAutomationRule#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#values ComputeoptimizerAutomationRule#values}
    */
    readonly values?: number[];
}
export declare function computeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGibToTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGibToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGibOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): number[];
    set values(value: number[]);
    resetValues(): void;
    get valuesInput(): number[] | undefined;
}
export declare class ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGibList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGibOutputReference;
}
export interface ComputeoptimizerAutomationRuleCriteriaEbsVolumeType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#comparison ComputeoptimizerAutomationRule#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#values ComputeoptimizerAutomationRule#values}
    */
    readonly values?: string[];
}
export declare function computeoptimizerAutomationRuleCriteriaEbsVolumeTypeToTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaEbsVolumeType | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaEbsVolumeTypeToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaEbsVolumeType | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaEbsVolumeTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleCriteriaEbsVolumeType | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteriaEbsVolumeType | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ComputeoptimizerAutomationRuleCriteriaEbsVolumeTypeList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleCriteriaEbsVolumeType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleCriteriaEbsVolumeTypeOutputReference;
}
export interface ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#comparison ComputeoptimizerAutomationRule#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#values ComputeoptimizerAutomationRule#values}
    */
    readonly values?: number[];
}
export declare function computeoptimizerAutomationRuleCriteriaEstimatedMonthlySavingsToTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaEstimatedMonthlySavingsToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): number[];
    set values(value: number[]);
    resetValues(): void;
    get valuesInput(): number[] | undefined;
}
export declare class ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavingsList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavingsOutputReference;
}
export interface ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#comparison ComputeoptimizerAutomationRule#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#values ComputeoptimizerAutomationRule#values}
    */
    readonly values?: number[];
}
export declare function computeoptimizerAutomationRuleCriteriaLookBackPeriodInDaysToTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaLookBackPeriodInDaysToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): number[];
    set values(value: number[]);
    resetValues(): void;
    get valuesInput(): number[] | undefined;
}
export declare class ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDaysList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDaysOutputReference;
}
export interface ComputeoptimizerAutomationRuleCriteriaRegion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#comparison ComputeoptimizerAutomationRule#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#values ComputeoptimizerAutomationRule#values}
    */
    readonly values?: string[];
}
export declare function computeoptimizerAutomationRuleCriteriaRegionToTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaRegion | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaRegionToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaRegion | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaRegionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleCriteriaRegion | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteriaRegion | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ComputeoptimizerAutomationRuleCriteriaRegionList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleCriteriaRegion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleCriteriaRegionOutputReference;
}
export interface ComputeoptimizerAutomationRuleCriteriaResourceArn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#comparison ComputeoptimizerAutomationRule#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#values ComputeoptimizerAutomationRule#values}
    */
    readonly values?: string[];
}
export declare function computeoptimizerAutomationRuleCriteriaResourceArnToTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaResourceArn | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaResourceArnToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaResourceArn | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaResourceArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleCriteriaResourceArn | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteriaResourceArn | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ComputeoptimizerAutomationRuleCriteriaResourceArnList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleCriteriaResourceArn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleCriteriaResourceArnOutputReference;
}
export interface ComputeoptimizerAutomationRuleCriteriaResourceTag {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#comparison ComputeoptimizerAutomationRule#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#key ComputeoptimizerAutomationRule#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#values ComputeoptimizerAutomationRule#values}
    */
    readonly values?: string[];
}
export declare function computeoptimizerAutomationRuleCriteriaResourceTagToTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaResourceTag | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaResourceTagToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaResourceTag | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaResourceTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleCriteriaResourceTag | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteriaResourceTag | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ComputeoptimizerAutomationRuleCriteriaResourceTagList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleCriteriaResourceTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleCriteriaResourceTagOutputReference;
}
export interface ComputeoptimizerAutomationRuleCriteriaRestartNeeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#comparison ComputeoptimizerAutomationRule#comparison}
    */
    readonly comparison?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#values ComputeoptimizerAutomationRule#values}
    */
    readonly values?: string[];
}
export declare function computeoptimizerAutomationRuleCriteriaRestartNeededToTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaRestartNeeded | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaRestartNeededToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteriaRestartNeeded | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaRestartNeededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleCriteriaRestartNeeded | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteriaRestartNeeded | cdktn.IResolvable | undefined);
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class ComputeoptimizerAutomationRuleCriteriaRestartNeededList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleCriteriaRestartNeeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleCriteriaRestartNeededOutputReference;
}
export interface ComputeoptimizerAutomationRuleCriteria {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#ebs_volume_size_in_gib ComputeoptimizerAutomationRule#ebs_volume_size_in_gib}
    */
    readonly ebsVolumeSizeInGib?: ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#ebs_volume_type ComputeoptimizerAutomationRule#ebs_volume_type}
    */
    readonly ebsVolumeType?: ComputeoptimizerAutomationRuleCriteriaEbsVolumeType[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#estimated_monthly_savings ComputeoptimizerAutomationRule#estimated_monthly_savings}
    */
    readonly estimatedMonthlySavings?: ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#look_back_period_in_days ComputeoptimizerAutomationRule#look_back_period_in_days}
    */
    readonly lookBackPeriodInDays?: ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#region ComputeoptimizerAutomationRule#region}
    */
    readonly region?: ComputeoptimizerAutomationRuleCriteriaRegion[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#resource_arn ComputeoptimizerAutomationRule#resource_arn}
    */
    readonly resourceArn?: ComputeoptimizerAutomationRuleCriteriaResourceArn[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#resource_tag ComputeoptimizerAutomationRule#resource_tag}
    */
    readonly resourceTag?: ComputeoptimizerAutomationRuleCriteriaResourceTag[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#restart_needed ComputeoptimizerAutomationRule#restart_needed}
    */
    readonly restartNeeded?: ComputeoptimizerAutomationRuleCriteriaRestartNeeded[] | cdktn.IResolvable;
}
export declare function computeoptimizerAutomationRuleCriteriaToTerraform(struct?: ComputeoptimizerAutomationRuleCriteria | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleCriteriaToHclTerraform(struct?: ComputeoptimizerAutomationRuleCriteria | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeoptimizerAutomationRuleCriteria | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleCriteria | cdktn.IResolvable | undefined);
    private _ebsVolumeSizeInGib;
    get ebsVolumeSizeInGib(): ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGibList;
    putEbsVolumeSizeInGib(value: ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib[] | cdktn.IResolvable): void;
    resetEbsVolumeSizeInGib(): void;
    get ebsVolumeSizeInGibInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteriaEbsVolumeSizeInGib[] | undefined;
    private _ebsVolumeType;
    get ebsVolumeType(): ComputeoptimizerAutomationRuleCriteriaEbsVolumeTypeList;
    putEbsVolumeType(value: ComputeoptimizerAutomationRuleCriteriaEbsVolumeType[] | cdktn.IResolvable): void;
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteriaEbsVolumeType[] | undefined;
    private _estimatedMonthlySavings;
    get estimatedMonthlySavings(): ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavingsList;
    putEstimatedMonthlySavings(value: ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings[] | cdktn.IResolvable): void;
    resetEstimatedMonthlySavings(): void;
    get estimatedMonthlySavingsInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteriaEstimatedMonthlySavings[] | undefined;
    private _lookBackPeriodInDays;
    get lookBackPeriodInDays(): ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDaysList;
    putLookBackPeriodInDays(value: ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays[] | cdktn.IResolvable): void;
    resetLookBackPeriodInDays(): void;
    get lookBackPeriodInDaysInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteriaLookBackPeriodInDays[] | undefined;
    private _region;
    get region(): ComputeoptimizerAutomationRuleCriteriaRegionList;
    putRegion(value: ComputeoptimizerAutomationRuleCriteriaRegion[] | cdktn.IResolvable): void;
    resetRegion(): void;
    get regionInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteriaRegion[] | undefined;
    private _resourceArn;
    get resourceArn(): ComputeoptimizerAutomationRuleCriteriaResourceArnList;
    putResourceArn(value: ComputeoptimizerAutomationRuleCriteriaResourceArn[] | cdktn.IResolvable): void;
    resetResourceArn(): void;
    get resourceArnInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteriaResourceArn[] | undefined;
    private _resourceTag;
    get resourceTag(): ComputeoptimizerAutomationRuleCriteriaResourceTagList;
    putResourceTag(value: ComputeoptimizerAutomationRuleCriteriaResourceTag[] | cdktn.IResolvable): void;
    resetResourceTag(): void;
    get resourceTagInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteriaResourceTag[] | undefined;
    private _restartNeeded;
    get restartNeeded(): ComputeoptimizerAutomationRuleCriteriaRestartNeededList;
    putRestartNeeded(value: ComputeoptimizerAutomationRuleCriteriaRestartNeeded[] | cdktn.IResolvable): void;
    resetRestartNeeded(): void;
    get restartNeededInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteriaRestartNeeded[] | undefined;
}
export interface ComputeoptimizerAutomationRuleOrganizationConfiguration {
    /**
    * List of account IDs where the organization rule applies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#account_ids ComputeoptimizerAutomationRule#account_ids}
    */
    readonly accountIds?: string[];
    /**
    * When the rule should be applied relative to account rules
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#rule_apply_order ComputeoptimizerAutomationRule#rule_apply_order}
    */
    readonly ruleApplyOrder?: string;
}
export declare function computeoptimizerAutomationRuleOrganizationConfigurationToTerraform(struct?: ComputeoptimizerAutomationRuleOrganizationConfiguration | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleOrganizationConfigurationToHclTerraform(struct?: ComputeoptimizerAutomationRuleOrganizationConfiguration | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleOrganizationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeoptimizerAutomationRuleOrganizationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleOrganizationConfiguration | cdktn.IResolvable | undefined);
    private _accountIds?;
    get accountIds(): string[];
    set accountIds(value: string[]);
    resetAccountIds(): void;
    get accountIdsInput(): string[] | undefined;
    private _ruleApplyOrder?;
    get ruleApplyOrder(): string;
    set ruleApplyOrder(value: string);
    resetRuleApplyOrder(): void;
    get ruleApplyOrderInput(): string | undefined;
}
export interface ComputeoptimizerAutomationRuleSchedule {
    /**
    * Execution window duration in minutes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#execution_window_in_minutes ComputeoptimizerAutomationRule#execution_window_in_minutes}
    */
    readonly executionWindowInMinutes?: number;
    /**
    * Schedule expression (e.g., cron or rate expression)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#schedule_expression ComputeoptimizerAutomationRule#schedule_expression}
    */
    readonly scheduleExpression?: string;
    /**
    * IANA timezone identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#schedule_expression_timezone ComputeoptimizerAutomationRule#schedule_expression_timezone}
    */
    readonly scheduleExpressionTimezone?: string;
}
export declare function computeoptimizerAutomationRuleScheduleToTerraform(struct?: ComputeoptimizerAutomationRuleSchedule | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleScheduleToHclTerraform(struct?: ComputeoptimizerAutomationRuleSchedule | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComputeoptimizerAutomationRuleSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleSchedule | cdktn.IResolvable | undefined);
    private _executionWindowInMinutes?;
    get executionWindowInMinutes(): number;
    set executionWindowInMinutes(value: number);
    resetExecutionWindowInMinutes(): void;
    get executionWindowInMinutesInput(): number | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    resetScheduleExpression(): void;
    get scheduleExpressionInput(): string | undefined;
    private _scheduleExpressionTimezone?;
    get scheduleExpressionTimezone(): string;
    set scheduleExpressionTimezone(value: string);
    resetScheduleExpressionTimezone(): void;
    get scheduleExpressionTimezoneInput(): string | undefined;
}
export interface ComputeoptimizerAutomationRuleTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#key ComputeoptimizerAutomationRule#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#value ComputeoptimizerAutomationRule#value}
    */
    readonly value?: string;
}
export declare function computeoptimizerAutomationRuleTagsToTerraform(struct?: ComputeoptimizerAutomationRuleTags | cdktn.IResolvable): any;
export declare function computeoptimizerAutomationRuleTagsToHclTerraform(struct?: ComputeoptimizerAutomationRuleTags | cdktn.IResolvable): any;
export declare class ComputeoptimizerAutomationRuleTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComputeoptimizerAutomationRuleTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComputeoptimizerAutomationRuleTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComputeoptimizerAutomationRuleTagsList extends cdktn.ComplexList {
    internalValue?: ComputeoptimizerAutomationRuleTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComputeoptimizerAutomationRuleTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule awscc_computeoptimizer_automation_rule}
*/
export declare class ComputeoptimizerAutomationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_computeoptimizer_automation_rule";
    /**
    * Generates CDKTN code for importing a ComputeoptimizerAutomationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComputeoptimizerAutomationRule to import
    * @param importFromId The id of the existing ComputeoptimizerAutomationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComputeoptimizerAutomationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/computeoptimizer_automation_rule awscc_computeoptimizer_automation_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComputeoptimizerAutomationRuleConfig
    */
    constructor(scope: Construct, id: string, config: ComputeoptimizerAutomationRuleConfig);
    get accountId(): string;
    get createdTimestamp(): string;
    private _criteria;
    get criteria(): ComputeoptimizerAutomationRuleCriteriaOutputReference;
    putCriteria(value: ComputeoptimizerAutomationRuleCriteria): void;
    resetCriteria(): void;
    get criteriaInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleCriteria | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastUpdatedTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organizationConfiguration;
    get organizationConfiguration(): ComputeoptimizerAutomationRuleOrganizationConfigurationOutputReference;
    putOrganizationConfiguration(value: ComputeoptimizerAutomationRuleOrganizationConfiguration): void;
    resetOrganizationConfiguration(): void;
    get organizationConfigurationInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleOrganizationConfiguration | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _recommendedActionTypes?;
    get recommendedActionTypes(): string[];
    set recommendedActionTypes(value: string[]);
    get recommendedActionTypesInput(): string[] | undefined;
    get ruleArn(): string;
    get ruleId(): string;
    get ruleRevision(): string;
    private _ruleType?;
    get ruleType(): string;
    set ruleType(value: string);
    get ruleTypeInput(): string | undefined;
    private _schedule;
    get schedule(): ComputeoptimizerAutomationRuleScheduleOutputReference;
    putSchedule(value: ComputeoptimizerAutomationRuleSchedule): void;
    get scheduleInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleSchedule | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _tags;
    get tags(): ComputeoptimizerAutomationRuleTagsList;
    putTags(value: ComputeoptimizerAutomationRuleTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ComputeoptimizerAutomationRuleTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
