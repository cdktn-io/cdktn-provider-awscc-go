/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CassandraTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Represents the read and write settings used for AutoScaling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#auto_scaling_specifications CassandraTable#auto_scaling_specifications}
    */
    readonly autoScalingSpecifications?: CassandraTableAutoScalingSpecifications;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#billing_mode CassandraTable#billing_mode}
    */
    readonly billingMode?: CassandraTableBillingMode;
    /**
    * Represents the CDC configuration for the table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#cdc_specification CassandraTable#cdc_specification}
    */
    readonly cdcSpecification?: CassandraTableCdcSpecification;
    /**
    * Indicates whether client side timestamps are enabled (true) or disabled (false) on the table. False by default, once it is enabled it cannot be disabled again.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#client_side_timestamps_enabled CassandraTable#client_side_timestamps_enabled}
    */
    readonly clientSideTimestampsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Clustering key columns of the table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#clustering_key_columns CassandraTable#clustering_key_columns}
    */
    readonly clusteringKeyColumns?: CassandraTableClusteringKeyColumns[] | cdktn.IResolvable;
    /**
    * Default TTL (Time To Live) in seconds, where zero is disabled. If the value is greater than zero, TTL is enabled for the entire table and an expiration timestamp is added to each column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#default_time_to_live CassandraTable#default_time_to_live}
    */
    readonly defaultTimeToLive?: number;
    /**
    * Represents the settings used to enable server-side encryption
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#encryption_specification CassandraTable#encryption_specification}
    */
    readonly encryptionSpecification?: CassandraTableEncryptionSpecification;
    /**
    * Name for Cassandra keyspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#keyspace_name CassandraTable#keyspace_name}
    */
    readonly keyspaceName: string;
    /**
    * Partition key columns of the table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#partition_key_columns CassandraTable#partition_key_columns}
    */
    readonly partitionKeyColumns: CassandraTablePartitionKeyColumns[] | cdktn.IResolvable;
    /**
    * Indicates whether point in time recovery is enabled (true) or disabled (false) on the table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#point_in_time_recovery_enabled CassandraTable#point_in_time_recovery_enabled}
    */
    readonly pointInTimeRecoveryEnabled?: boolean | cdktn.IResolvable;
    /**
    * Non-key columns of the table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#regular_columns CassandraTable#regular_columns}
    */
    readonly regularColumns?: CassandraTableRegularColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#replica_specifications CassandraTable#replica_specifications}
    */
    readonly replicaSpecifications?: CassandraTableReplicaSpecifications[] | cdktn.IResolvable;
    /**
    * Name for Cassandra table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#table_name CassandraTable#table_name}
    */
    readonly tableName?: string;
    /**
    * An array of key-value pairs to apply to this resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#tags CassandraTable#tags}
    */
    readonly tags?: CassandraTableTags[] | cdktn.IResolvable;
    /**
    * Warm throughput configuration for the table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#warm_throughput CassandraTable#warm_throughput}
    */
    readonly warmThroughput?: CassandraTableWarmThroughput;
}
export interface CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#disable_scale_in CassandraTable#disable_scale_in}
    */
    readonly disableScaleIn?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scale_in_cooldown CassandraTable#scale_in_cooldown}
    */
    readonly scaleInCooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scale_out_cooldown CassandraTable#scale_out_cooldown}
    */
    readonly scaleOutCooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#target_value CassandraTable#target_value}
    */
    readonly targetValue?: number;
}
export declare function cassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationToTerraform(struct?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable): any;
export declare function cassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationToHclTerraform(struct?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable): any;
export declare class CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable | undefined);
    private _disableScaleIn?;
    get disableScaleIn(): boolean | cdktn.IResolvable;
    set disableScaleIn(value: boolean | cdktn.IResolvable);
    resetDisableScaleIn(): void;
    get disableScaleInInput(): boolean | cdktn.IResolvable | undefined;
    private _scaleInCooldown?;
    get scaleInCooldown(): number;
    set scaleInCooldown(value: number);
    resetScaleInCooldown(): void;
    get scaleInCooldownInput(): number | undefined;
    private _scaleOutCooldown?;
    get scaleOutCooldown(): number;
    set scaleOutCooldown(value: number);
    resetScaleOutCooldown(): void;
    get scaleOutCooldownInput(): number | undefined;
    private _targetValue?;
    get targetValue(): number;
    set targetValue(value: number);
    resetTargetValue(): void;
    get targetValueInput(): number | undefined;
}
export interface CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicy {
    /**
    * Represents configuration for target tracking scaling policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#target_tracking_scaling_policy_configuration CassandraTable#target_tracking_scaling_policy_configuration}
    */
    readonly targetTrackingScalingPolicyConfiguration?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration;
}
export declare function cassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyToTerraform(struct?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicy | cdktn.IResolvable): any;
export declare function cassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyToHclTerraform(struct?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicy | cdktn.IResolvable): any;
export declare class CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicy | cdktn.IResolvable | undefined);
    private _targetTrackingScalingPolicyConfiguration;
    get targetTrackingScalingPolicyConfiguration(): CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationOutputReference;
    putTargetTrackingScalingPolicyConfiguration(value: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration): void;
    resetTargetTrackingScalingPolicyConfiguration(): void;
    get targetTrackingScalingPolicyConfigurationInput(): cdktn.IResolvable | CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | undefined;
}
export interface CassandraTableAutoScalingSpecificationsReadCapacityAutoScaling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#auto_scaling_disabled CassandraTable#auto_scaling_disabled}
    */
    readonly autoScalingDisabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#maximum_units CassandraTable#maximum_units}
    */
    readonly maximumUnits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#minimum_units CassandraTable#minimum_units}
    */
    readonly minimumUnits?: number;
    /**
    * Represents scaling policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scaling_policy CassandraTable#scaling_policy}
    */
    readonly scalingPolicy?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicy;
}
export declare function cassandraTableAutoScalingSpecificationsReadCapacityAutoScalingToTerraform(struct?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScaling | cdktn.IResolvable): any;
export declare function cassandraTableAutoScalingSpecificationsReadCapacityAutoScalingToHclTerraform(struct?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScaling | cdktn.IResolvable): any;
export declare class CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableAutoScalingSpecificationsReadCapacityAutoScaling | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableAutoScalingSpecificationsReadCapacityAutoScaling | cdktn.IResolvable | undefined);
    private _autoScalingDisabled?;
    get autoScalingDisabled(): boolean | cdktn.IResolvable;
    set autoScalingDisabled(value: boolean | cdktn.IResolvable);
    resetAutoScalingDisabled(): void;
    get autoScalingDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _maximumUnits?;
    get maximumUnits(): number;
    set maximumUnits(value: number);
    resetMaximumUnits(): void;
    get maximumUnitsInput(): number | undefined;
    private _minimumUnits?;
    get minimumUnits(): number;
    set minimumUnits(value: number);
    resetMinimumUnits(): void;
    get minimumUnitsInput(): number | undefined;
    private _scalingPolicy;
    get scalingPolicy(): CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicyOutputReference;
    putScalingPolicy(value: CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicy): void;
    resetScalingPolicy(): void;
    get scalingPolicyInput(): cdktn.IResolvable | CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingScalingPolicy | undefined;
}
export interface CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#disable_scale_in CassandraTable#disable_scale_in}
    */
    readonly disableScaleIn?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scale_in_cooldown CassandraTable#scale_in_cooldown}
    */
    readonly scaleInCooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scale_out_cooldown CassandraTable#scale_out_cooldown}
    */
    readonly scaleOutCooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#target_value CassandraTable#target_value}
    */
    readonly targetValue?: number;
}
export declare function cassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationToTerraform(struct?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable): any;
export declare function cassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationToHclTerraform(struct?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable): any;
export declare class CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable | undefined);
    private _disableScaleIn?;
    get disableScaleIn(): boolean | cdktn.IResolvable;
    set disableScaleIn(value: boolean | cdktn.IResolvable);
    resetDisableScaleIn(): void;
    get disableScaleInInput(): boolean | cdktn.IResolvable | undefined;
    private _scaleInCooldown?;
    get scaleInCooldown(): number;
    set scaleInCooldown(value: number);
    resetScaleInCooldown(): void;
    get scaleInCooldownInput(): number | undefined;
    private _scaleOutCooldown?;
    get scaleOutCooldown(): number;
    set scaleOutCooldown(value: number);
    resetScaleOutCooldown(): void;
    get scaleOutCooldownInput(): number | undefined;
    private _targetValue?;
    get targetValue(): number;
    set targetValue(value: number);
    resetTargetValue(): void;
    get targetValueInput(): number | undefined;
}
export interface CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicy {
    /**
    * Represents configuration for target tracking scaling policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#target_tracking_scaling_policy_configuration CassandraTable#target_tracking_scaling_policy_configuration}
    */
    readonly targetTrackingScalingPolicyConfiguration?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration;
}
export declare function cassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyToTerraform(struct?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicy | cdktn.IResolvable): any;
export declare function cassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyToHclTerraform(struct?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicy | cdktn.IResolvable): any;
export declare class CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicy | cdktn.IResolvable | undefined);
    private _targetTrackingScalingPolicyConfiguration;
    get targetTrackingScalingPolicyConfiguration(): CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationOutputReference;
    putTargetTrackingScalingPolicyConfiguration(value: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration): void;
    resetTargetTrackingScalingPolicyConfiguration(): void;
    get targetTrackingScalingPolicyConfigurationInput(): cdktn.IResolvable | CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | undefined;
}
export interface CassandraTableAutoScalingSpecificationsWriteCapacityAutoScaling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#auto_scaling_disabled CassandraTable#auto_scaling_disabled}
    */
    readonly autoScalingDisabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#maximum_units CassandraTable#maximum_units}
    */
    readonly maximumUnits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#minimum_units CassandraTable#minimum_units}
    */
    readonly minimumUnits?: number;
    /**
    * Represents scaling policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scaling_policy CassandraTable#scaling_policy}
    */
    readonly scalingPolicy?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicy;
}
export declare function cassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingToTerraform(struct?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScaling | cdktn.IResolvable): any;
export declare function cassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingToHclTerraform(struct?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScaling | cdktn.IResolvable): any;
export declare class CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableAutoScalingSpecificationsWriteCapacityAutoScaling | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScaling | cdktn.IResolvable | undefined);
    private _autoScalingDisabled?;
    get autoScalingDisabled(): boolean | cdktn.IResolvable;
    set autoScalingDisabled(value: boolean | cdktn.IResolvable);
    resetAutoScalingDisabled(): void;
    get autoScalingDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _maximumUnits?;
    get maximumUnits(): number;
    set maximumUnits(value: number);
    resetMaximumUnits(): void;
    get maximumUnitsInput(): number | undefined;
    private _minimumUnits?;
    get minimumUnits(): number;
    set minimumUnits(value: number);
    resetMinimumUnits(): void;
    get minimumUnitsInput(): number | undefined;
    private _scalingPolicy;
    get scalingPolicy(): CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicyOutputReference;
    putScalingPolicy(value: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicy): void;
    resetScalingPolicy(): void;
    get scalingPolicyInput(): cdktn.IResolvable | CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingScalingPolicy | undefined;
}
export interface CassandraTableAutoScalingSpecifications {
    /**
    * Represents configuration for auto scaling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#read_capacity_auto_scaling CassandraTable#read_capacity_auto_scaling}
    */
    readonly readCapacityAutoScaling?: CassandraTableAutoScalingSpecificationsReadCapacityAutoScaling;
    /**
    * Represents configuration for auto scaling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#write_capacity_auto_scaling CassandraTable#write_capacity_auto_scaling}
    */
    readonly writeCapacityAutoScaling?: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScaling;
}
export declare function cassandraTableAutoScalingSpecificationsToTerraform(struct?: CassandraTableAutoScalingSpecifications | cdktn.IResolvable): any;
export declare function cassandraTableAutoScalingSpecificationsToHclTerraform(struct?: CassandraTableAutoScalingSpecifications | cdktn.IResolvable): any;
export declare class CassandraTableAutoScalingSpecificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableAutoScalingSpecifications | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableAutoScalingSpecifications | cdktn.IResolvable | undefined);
    private _readCapacityAutoScaling;
    get readCapacityAutoScaling(): CassandraTableAutoScalingSpecificationsReadCapacityAutoScalingOutputReference;
    putReadCapacityAutoScaling(value: CassandraTableAutoScalingSpecificationsReadCapacityAutoScaling): void;
    resetReadCapacityAutoScaling(): void;
    get readCapacityAutoScalingInput(): cdktn.IResolvable | CassandraTableAutoScalingSpecificationsReadCapacityAutoScaling | undefined;
    private _writeCapacityAutoScaling;
    get writeCapacityAutoScaling(): CassandraTableAutoScalingSpecificationsWriteCapacityAutoScalingOutputReference;
    putWriteCapacityAutoScaling(value: CassandraTableAutoScalingSpecificationsWriteCapacityAutoScaling): void;
    resetWriteCapacityAutoScaling(): void;
    get writeCapacityAutoScalingInput(): cdktn.IResolvable | CassandraTableAutoScalingSpecificationsWriteCapacityAutoScaling | undefined;
}
export interface CassandraTableBillingModeProvisionedThroughput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#read_capacity_units CassandraTable#read_capacity_units}
    */
    readonly readCapacityUnits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#write_capacity_units CassandraTable#write_capacity_units}
    */
    readonly writeCapacityUnits?: number;
}
export declare function cassandraTableBillingModeProvisionedThroughputToTerraform(struct?: CassandraTableBillingModeProvisionedThroughput | cdktn.IResolvable): any;
export declare function cassandraTableBillingModeProvisionedThroughputToHclTerraform(struct?: CassandraTableBillingModeProvisionedThroughput | cdktn.IResolvable): any;
export declare class CassandraTableBillingModeProvisionedThroughputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableBillingModeProvisionedThroughput | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableBillingModeProvisionedThroughput | cdktn.IResolvable | undefined);
    private _readCapacityUnits?;
    get readCapacityUnits(): number;
    set readCapacityUnits(value: number);
    resetReadCapacityUnits(): void;
    get readCapacityUnitsInput(): number | undefined;
    private _writeCapacityUnits?;
    get writeCapacityUnits(): number;
    set writeCapacityUnits(value: number);
    resetWriteCapacityUnits(): void;
    get writeCapacityUnitsInput(): number | undefined;
}
export interface CassandraTableBillingMode {
    /**
    * Capacity mode for the specified table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#mode CassandraTable#mode}
    */
    readonly mode?: string;
    /**
    * Throughput for the specified table, which consists of values for ReadCapacityUnits and WriteCapacityUnits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#provisioned_throughput CassandraTable#provisioned_throughput}
    */
    readonly provisionedThroughput?: CassandraTableBillingModeProvisionedThroughput;
}
export declare function cassandraTableBillingModeToTerraform(struct?: CassandraTableBillingMode | cdktn.IResolvable): any;
export declare function cassandraTableBillingModeToHclTerraform(struct?: CassandraTableBillingMode | cdktn.IResolvable): any;
export declare class CassandraTableBillingModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableBillingMode | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableBillingMode | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _provisionedThroughput;
    get provisionedThroughput(): CassandraTableBillingModeProvisionedThroughputOutputReference;
    putProvisionedThroughput(value: CassandraTableBillingModeProvisionedThroughput): void;
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): cdktn.IResolvable | CassandraTableBillingModeProvisionedThroughput | undefined;
}
export interface CassandraTableCdcSpecificationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#key CassandraTable#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#value CassandraTable#value}
    */
    readonly value?: string;
}
export declare function cassandraTableCdcSpecificationTagsToTerraform(struct?: CassandraTableCdcSpecificationTags | cdktn.IResolvable): any;
export declare function cassandraTableCdcSpecificationTagsToHclTerraform(struct?: CassandraTableCdcSpecificationTags | cdktn.IResolvable): any;
export declare class CassandraTableCdcSpecificationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CassandraTableCdcSpecificationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableCdcSpecificationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CassandraTableCdcSpecificationTagsList extends cdktn.ComplexList {
    internalValue?: CassandraTableCdcSpecificationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CassandraTableCdcSpecificationTagsOutputReference;
}
export interface CassandraTableCdcSpecification {
    /**
    * Indicates whether CDC is enabled or disabled for the table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#status CassandraTable#status}
    */
    readonly status?: string;
    /**
    * An array of key-value pairs to apply to the CDC stream resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#tags CassandraTable#tags}
    */
    readonly tags?: CassandraTableCdcSpecificationTags[] | cdktn.IResolvable;
    /**
    * Specifies what data should be captured in the change data stream
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#view_type CassandraTable#view_type}
    */
    readonly viewType?: string;
}
export declare function cassandraTableCdcSpecificationToTerraform(struct?: CassandraTableCdcSpecification | cdktn.IResolvable): any;
export declare function cassandraTableCdcSpecificationToHclTerraform(struct?: CassandraTableCdcSpecification | cdktn.IResolvable): any;
export declare class CassandraTableCdcSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableCdcSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableCdcSpecification | cdktn.IResolvable | undefined);
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags;
    get tags(): CassandraTableCdcSpecificationTagsList;
    putTags(value: CassandraTableCdcSpecificationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CassandraTableCdcSpecificationTags[] | undefined;
    private _viewType?;
    get viewType(): string;
    set viewType(value: string);
    resetViewType(): void;
    get viewTypeInput(): string | undefined;
}
export interface CassandraTableClusteringKeyColumnsColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#column_name CassandraTable#column_name}
    */
    readonly columnName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#column_type CassandraTable#column_type}
    */
    readonly columnType?: string;
}
export declare function cassandraTableClusteringKeyColumnsColumnToTerraform(struct?: CassandraTableClusteringKeyColumnsColumn | cdktn.IResolvable): any;
export declare function cassandraTableClusteringKeyColumnsColumnToHclTerraform(struct?: CassandraTableClusteringKeyColumnsColumn | cdktn.IResolvable): any;
export declare class CassandraTableClusteringKeyColumnsColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableClusteringKeyColumnsColumn | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableClusteringKeyColumnsColumn | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    resetColumnName(): void;
    get columnNameInput(): string | undefined;
    private _columnType?;
    get columnType(): string;
    set columnType(value: string);
    resetColumnType(): void;
    get columnTypeInput(): string | undefined;
}
export interface CassandraTableClusteringKeyColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#column CassandraTable#column}
    */
    readonly column?: CassandraTableClusteringKeyColumnsColumn;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#order_by CassandraTable#order_by}
    */
    readonly orderBy?: string;
}
export declare function cassandraTableClusteringKeyColumnsToTerraform(struct?: CassandraTableClusteringKeyColumns | cdktn.IResolvable): any;
export declare function cassandraTableClusteringKeyColumnsToHclTerraform(struct?: CassandraTableClusteringKeyColumns | cdktn.IResolvable): any;
export declare class CassandraTableClusteringKeyColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CassandraTableClusteringKeyColumns | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableClusteringKeyColumns | cdktn.IResolvable | undefined);
    private _column;
    get column(): CassandraTableClusteringKeyColumnsColumnOutputReference;
    putColumn(value: CassandraTableClusteringKeyColumnsColumn): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | CassandraTableClusteringKeyColumnsColumn | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
}
export declare class CassandraTableClusteringKeyColumnsList extends cdktn.ComplexList {
    internalValue?: CassandraTableClusteringKeyColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CassandraTableClusteringKeyColumnsOutputReference;
}
export interface CassandraTableEncryptionSpecification {
    /**
    * Server-side encryption type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#encryption_type CassandraTable#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * The AWS KMS customer master key (CMK) that should be used for the AWS KMS encryption. To specify a CMK, use its key ID, Amazon Resource Name (ARN), alias name, or alias ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#kms_key_identifier CassandraTable#kms_key_identifier}
    */
    readonly kmsKeyIdentifier?: string;
}
export declare function cassandraTableEncryptionSpecificationToTerraform(struct?: CassandraTableEncryptionSpecification | cdktn.IResolvable): any;
export declare function cassandraTableEncryptionSpecificationToHclTerraform(struct?: CassandraTableEncryptionSpecification | cdktn.IResolvable): any;
export declare class CassandraTableEncryptionSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableEncryptionSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableEncryptionSpecification | cdktn.IResolvable | undefined);
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _kmsKeyIdentifier?;
    get kmsKeyIdentifier(): string;
    set kmsKeyIdentifier(value: string);
    resetKmsKeyIdentifier(): void;
    get kmsKeyIdentifierInput(): string | undefined;
}
export interface CassandraTablePartitionKeyColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#column_name CassandraTable#column_name}
    */
    readonly columnName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#column_type CassandraTable#column_type}
    */
    readonly columnType: string;
}
export declare function cassandraTablePartitionKeyColumnsToTerraform(struct?: CassandraTablePartitionKeyColumns | cdktn.IResolvable): any;
export declare function cassandraTablePartitionKeyColumnsToHclTerraform(struct?: CassandraTablePartitionKeyColumns | cdktn.IResolvable): any;
export declare class CassandraTablePartitionKeyColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CassandraTablePartitionKeyColumns | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTablePartitionKeyColumns | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    get columnNameInput(): string | undefined;
    private _columnType?;
    get columnType(): string;
    set columnType(value: string);
    get columnTypeInput(): string | undefined;
}
export declare class CassandraTablePartitionKeyColumnsList extends cdktn.ComplexList {
    internalValue?: CassandraTablePartitionKeyColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CassandraTablePartitionKeyColumnsOutputReference;
}
export interface CassandraTableRegularColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#column_name CassandraTable#column_name}
    */
    readonly columnName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#column_type CassandraTable#column_type}
    */
    readonly columnType?: string;
}
export declare function cassandraTableRegularColumnsToTerraform(struct?: CassandraTableRegularColumns | cdktn.IResolvable): any;
export declare function cassandraTableRegularColumnsToHclTerraform(struct?: CassandraTableRegularColumns | cdktn.IResolvable): any;
export declare class CassandraTableRegularColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CassandraTableRegularColumns | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableRegularColumns | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    resetColumnName(): void;
    get columnNameInput(): string | undefined;
    private _columnType?;
    get columnType(): string;
    set columnType(value: string);
    resetColumnType(): void;
    get columnTypeInput(): string | undefined;
}
export declare class CassandraTableRegularColumnsList extends cdktn.ComplexList {
    internalValue?: CassandraTableRegularColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CassandraTableRegularColumnsOutputReference;
}
export interface CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#disable_scale_in CassandraTable#disable_scale_in}
    */
    readonly disableScaleIn?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scale_in_cooldown CassandraTable#scale_in_cooldown}
    */
    readonly scaleInCooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scale_out_cooldown CassandraTable#scale_out_cooldown}
    */
    readonly scaleOutCooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#target_value CassandraTable#target_value}
    */
    readonly targetValue?: number;
}
export declare function cassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationToTerraform(struct?: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable): any;
export declare function cassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationToHclTerraform(struct?: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable): any;
export declare class CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | cdktn.IResolvable | undefined);
    private _disableScaleIn?;
    get disableScaleIn(): boolean | cdktn.IResolvable;
    set disableScaleIn(value: boolean | cdktn.IResolvable);
    resetDisableScaleIn(): void;
    get disableScaleInInput(): boolean | cdktn.IResolvable | undefined;
    private _scaleInCooldown?;
    get scaleInCooldown(): number;
    set scaleInCooldown(value: number);
    resetScaleInCooldown(): void;
    get scaleInCooldownInput(): number | undefined;
    private _scaleOutCooldown?;
    get scaleOutCooldown(): number;
    set scaleOutCooldown(value: number);
    resetScaleOutCooldown(): void;
    get scaleOutCooldownInput(): number | undefined;
    private _targetValue?;
    get targetValue(): number;
    set targetValue(value: number);
    resetTargetValue(): void;
    get targetValueInput(): number | undefined;
}
export interface CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicy {
    /**
    * Represents configuration for target tracking scaling policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#target_tracking_scaling_policy_configuration CassandraTable#target_tracking_scaling_policy_configuration}
    */
    readonly targetTrackingScalingPolicyConfiguration?: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration;
}
export declare function cassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyToTerraform(struct?: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicy | cdktn.IResolvable): any;
export declare function cassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyToHclTerraform(struct?: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicy | cdktn.IResolvable): any;
export declare class CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicy | cdktn.IResolvable | undefined);
    private _targetTrackingScalingPolicyConfiguration;
    get targetTrackingScalingPolicyConfiguration(): CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfigurationOutputReference;
    putTargetTrackingScalingPolicyConfiguration(value: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration): void;
    resetTargetTrackingScalingPolicyConfiguration(): void;
    get targetTrackingScalingPolicyConfigurationInput(): cdktn.IResolvable | CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyTargetTrackingScalingPolicyConfiguration | undefined;
}
export interface CassandraTableReplicaSpecificationsReadCapacityAutoScaling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#auto_scaling_disabled CassandraTable#auto_scaling_disabled}
    */
    readonly autoScalingDisabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#maximum_units CassandraTable#maximum_units}
    */
    readonly maximumUnits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#minimum_units CassandraTable#minimum_units}
    */
    readonly minimumUnits?: number;
    /**
    * Represents scaling policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#scaling_policy CassandraTable#scaling_policy}
    */
    readonly scalingPolicy?: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicy;
}
export declare function cassandraTableReplicaSpecificationsReadCapacityAutoScalingToTerraform(struct?: CassandraTableReplicaSpecificationsReadCapacityAutoScaling | cdktn.IResolvable): any;
export declare function cassandraTableReplicaSpecificationsReadCapacityAutoScalingToHclTerraform(struct?: CassandraTableReplicaSpecificationsReadCapacityAutoScaling | cdktn.IResolvable): any;
export declare class CassandraTableReplicaSpecificationsReadCapacityAutoScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableReplicaSpecificationsReadCapacityAutoScaling | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableReplicaSpecificationsReadCapacityAutoScaling | cdktn.IResolvable | undefined);
    private _autoScalingDisabled?;
    get autoScalingDisabled(): boolean | cdktn.IResolvable;
    set autoScalingDisabled(value: boolean | cdktn.IResolvable);
    resetAutoScalingDisabled(): void;
    get autoScalingDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _maximumUnits?;
    get maximumUnits(): number;
    set maximumUnits(value: number);
    resetMaximumUnits(): void;
    get maximumUnitsInput(): number | undefined;
    private _minimumUnits?;
    get minimumUnits(): number;
    set minimumUnits(value: number);
    resetMinimumUnits(): void;
    get minimumUnitsInput(): number | undefined;
    private _scalingPolicy;
    get scalingPolicy(): CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicyOutputReference;
    putScalingPolicy(value: CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicy): void;
    resetScalingPolicy(): void;
    get scalingPolicyInput(): cdktn.IResolvable | CassandraTableReplicaSpecificationsReadCapacityAutoScalingScalingPolicy | undefined;
}
export interface CassandraTableReplicaSpecifications {
    /**
    * Represents configuration for auto scaling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#read_capacity_auto_scaling CassandraTable#read_capacity_auto_scaling}
    */
    readonly readCapacityAutoScaling?: CassandraTableReplicaSpecificationsReadCapacityAutoScaling;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#read_capacity_units CassandraTable#read_capacity_units}
    */
    readonly readCapacityUnits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#region CassandraTable#region}
    */
    readonly region?: string;
}
export declare function cassandraTableReplicaSpecificationsToTerraform(struct?: CassandraTableReplicaSpecifications | cdktn.IResolvable): any;
export declare function cassandraTableReplicaSpecificationsToHclTerraform(struct?: CassandraTableReplicaSpecifications | cdktn.IResolvable): any;
export declare class CassandraTableReplicaSpecificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CassandraTableReplicaSpecifications | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableReplicaSpecifications | cdktn.IResolvable | undefined);
    private _readCapacityAutoScaling;
    get readCapacityAutoScaling(): CassandraTableReplicaSpecificationsReadCapacityAutoScalingOutputReference;
    putReadCapacityAutoScaling(value: CassandraTableReplicaSpecificationsReadCapacityAutoScaling): void;
    resetReadCapacityAutoScaling(): void;
    get readCapacityAutoScalingInput(): cdktn.IResolvable | CassandraTableReplicaSpecificationsReadCapacityAutoScaling | undefined;
    private _readCapacityUnits?;
    get readCapacityUnits(): number;
    set readCapacityUnits(value: number);
    resetReadCapacityUnits(): void;
    get readCapacityUnitsInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export declare class CassandraTableReplicaSpecificationsList extends cdktn.ComplexList {
    internalValue?: CassandraTableReplicaSpecifications[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CassandraTableReplicaSpecificationsOutputReference;
}
export interface CassandraTableTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#key CassandraTable#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#value CassandraTable#value}
    */
    readonly value?: string;
}
export declare function cassandraTableTagsToTerraform(struct?: CassandraTableTags | cdktn.IResolvable): any;
export declare function cassandraTableTagsToHclTerraform(struct?: CassandraTableTags | cdktn.IResolvable): any;
export declare class CassandraTableTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CassandraTableTags | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CassandraTableTagsList extends cdktn.ComplexList {
    internalValue?: CassandraTableTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CassandraTableTagsOutputReference;
}
export interface CassandraTableWarmThroughput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#read_units_per_second CassandraTable#read_units_per_second}
    */
    readonly readUnitsPerSecond?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#write_units_per_second CassandraTable#write_units_per_second}
    */
    readonly writeUnitsPerSecond?: number;
}
export declare function cassandraTableWarmThroughputToTerraform(struct?: CassandraTableWarmThroughput | cdktn.IResolvable): any;
export declare function cassandraTableWarmThroughputToHclTerraform(struct?: CassandraTableWarmThroughput | cdktn.IResolvable): any;
export declare class CassandraTableWarmThroughputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CassandraTableWarmThroughput | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTableWarmThroughput | cdktn.IResolvable | undefined);
    private _readUnitsPerSecond?;
    get readUnitsPerSecond(): number;
    set readUnitsPerSecond(value: number);
    resetReadUnitsPerSecond(): void;
    get readUnitsPerSecondInput(): number | undefined;
    private _writeUnitsPerSecond?;
    get writeUnitsPerSecond(): number;
    set writeUnitsPerSecond(value: number);
    resetWriteUnitsPerSecond(): void;
    get writeUnitsPerSecondInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table awscc_cassandra_table}
*/
export declare class CassandraTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cassandra_table";
    /**
    * Generates CDKTN code for importing a CassandraTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CassandraTable to import
    * @param importFromId The id of the existing CassandraTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CassandraTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cassandra_table awscc_cassandra_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CassandraTableConfig
    */
    constructor(scope: Construct, id: string, config: CassandraTableConfig);
    private _autoScalingSpecifications;
    get autoScalingSpecifications(): CassandraTableAutoScalingSpecificationsOutputReference;
    putAutoScalingSpecifications(value: CassandraTableAutoScalingSpecifications): void;
    resetAutoScalingSpecifications(): void;
    get autoScalingSpecificationsInput(): cdktn.IResolvable | CassandraTableAutoScalingSpecifications | undefined;
    private _billingMode;
    get billingMode(): CassandraTableBillingModeOutputReference;
    putBillingMode(value: CassandraTableBillingMode): void;
    resetBillingMode(): void;
    get billingModeInput(): cdktn.IResolvable | CassandraTableBillingMode | undefined;
    private _cdcSpecification;
    get cdcSpecification(): CassandraTableCdcSpecificationOutputReference;
    putCdcSpecification(value: CassandraTableCdcSpecification): void;
    resetCdcSpecification(): void;
    get cdcSpecificationInput(): cdktn.IResolvable | CassandraTableCdcSpecification | undefined;
    private _clientSideTimestampsEnabled?;
    get clientSideTimestampsEnabled(): boolean | cdktn.IResolvable;
    set clientSideTimestampsEnabled(value: boolean | cdktn.IResolvable);
    resetClientSideTimestampsEnabled(): void;
    get clientSideTimestampsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _clusteringKeyColumns;
    get clusteringKeyColumns(): CassandraTableClusteringKeyColumnsList;
    putClusteringKeyColumns(value: CassandraTableClusteringKeyColumns[] | cdktn.IResolvable): void;
    resetClusteringKeyColumns(): void;
    get clusteringKeyColumnsInput(): cdktn.IResolvable | CassandraTableClusteringKeyColumns[] | undefined;
    private _defaultTimeToLive?;
    get defaultTimeToLive(): number;
    set defaultTimeToLive(value: number);
    resetDefaultTimeToLive(): void;
    get defaultTimeToLiveInput(): number | undefined;
    private _encryptionSpecification;
    get encryptionSpecification(): CassandraTableEncryptionSpecificationOutputReference;
    putEncryptionSpecification(value: CassandraTableEncryptionSpecification): void;
    resetEncryptionSpecification(): void;
    get encryptionSpecificationInput(): cdktn.IResolvable | CassandraTableEncryptionSpecification | undefined;
    get id(): string;
    private _keyspaceName?;
    get keyspaceName(): string;
    set keyspaceName(value: string);
    get keyspaceNameInput(): string | undefined;
    private _partitionKeyColumns;
    get partitionKeyColumns(): CassandraTablePartitionKeyColumnsList;
    putPartitionKeyColumns(value: CassandraTablePartitionKeyColumns[] | cdktn.IResolvable): void;
    get partitionKeyColumnsInput(): cdktn.IResolvable | CassandraTablePartitionKeyColumns[] | undefined;
    private _pointInTimeRecoveryEnabled?;
    get pointInTimeRecoveryEnabled(): boolean | cdktn.IResolvable;
    set pointInTimeRecoveryEnabled(value: boolean | cdktn.IResolvable);
    resetPointInTimeRecoveryEnabled(): void;
    get pointInTimeRecoveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _regularColumns;
    get regularColumns(): CassandraTableRegularColumnsList;
    putRegularColumns(value: CassandraTableRegularColumns[] | cdktn.IResolvable): void;
    resetRegularColumns(): void;
    get regularColumnsInput(): cdktn.IResolvable | CassandraTableRegularColumns[] | undefined;
    private _replicaSpecifications;
    get replicaSpecifications(): CassandraTableReplicaSpecificationsList;
    putReplicaSpecifications(value: CassandraTableReplicaSpecifications[] | cdktn.IResolvable): void;
    resetReplicaSpecifications(): void;
    get replicaSpecificationsInput(): cdktn.IResolvable | CassandraTableReplicaSpecifications[] | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
    private _tags;
    get tags(): CassandraTableTagsList;
    putTags(value: CassandraTableTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CassandraTableTags[] | undefined;
    private _warmThroughput;
    get warmThroughput(): CassandraTableWarmThroughputOutputReference;
    putWarmThroughput(value: CassandraTableWarmThroughput): void;
    resetWarmThroughput(): void;
    get warmThroughputInput(): cdktn.IResolvable | CassandraTableWarmThroughput | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
