/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockPromptConfig extends cdktn.TerraformMetaArguments {
    /**
    * A KMS key ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#customer_encryption_key_arn BedrockPrompt#customer_encryption_key_arn}
    */
    readonly customerEncryptionKeyArn?: string;
    /**
    * Name for a variant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#default_variant BedrockPrompt#default_variant}
    */
    readonly defaultVariant?: string;
    /**
    * Name for a prompt resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#description BedrockPrompt#description}
    */
    readonly description?: string;
    /**
    * Name for a prompt resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#name BedrockPrompt#name}
    */
    readonly name: string;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#tags BedrockPrompt#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * List of prompt variants
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#variants BedrockPrompt#variants}
    */
    readonly variants?: BedrockPromptVariants[] | cdktn.IResolvable;
}
export interface BedrockPromptVariantsGenAiResourceAgent {
    /**
    * Arn representation of the Agent Alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#agent_identifier BedrockPrompt#agent_identifier}
    */
    readonly agentIdentifier?: string;
}
export declare function bedrockPromptVariantsGenAiResourceAgentToTerraform(struct?: BedrockPromptVariantsGenAiResourceAgent | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsGenAiResourceAgentToHclTerraform(struct?: BedrockPromptVariantsGenAiResourceAgent | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsGenAiResourceAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsGenAiResourceAgent | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsGenAiResourceAgent | cdktn.IResolvable | undefined);
    private _agentIdentifier?;
    get agentIdentifier(): string;
    set agentIdentifier(value: string);
    resetAgentIdentifier(): void;
    get agentIdentifierInput(): string | undefined;
}
export interface BedrockPromptVariantsGenAiResource {
    /**
    * Target Agent to invoke with Prompt
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#agent BedrockPrompt#agent}
    */
    readonly agent?: BedrockPromptVariantsGenAiResourceAgent;
}
export declare function bedrockPromptVariantsGenAiResourceToTerraform(struct?: BedrockPromptVariantsGenAiResource | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsGenAiResourceToHclTerraform(struct?: BedrockPromptVariantsGenAiResource | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsGenAiResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsGenAiResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsGenAiResource | cdktn.IResolvable | undefined);
    private _agent;
    get agent(): BedrockPromptVariantsGenAiResourceAgentOutputReference;
    putAgent(value: BedrockPromptVariantsGenAiResourceAgent): void;
    resetAgent(): void;
    get agentInput(): cdktn.IResolvable | BedrockPromptVariantsGenAiResourceAgent | undefined;
}
export interface BedrockPromptVariantsInferenceConfigurationText {
    /**
    * Maximum length of output
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#max_tokens BedrockPrompt#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * List of stop sequences
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#stop_sequences BedrockPrompt#stop_sequences}
    */
    readonly stopSequences?: string[];
    /**
    * Controls randomness, higher values increase diversity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#temperature BedrockPrompt#temperature}
    */
    readonly temperature?: number;
    /**
    * Cumulative probability cutoff for token selection
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#top_p BedrockPrompt#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockPromptVariantsInferenceConfigurationTextToTerraform(struct?: BedrockPromptVariantsInferenceConfigurationText | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsInferenceConfigurationTextToHclTerraform(struct?: BedrockPromptVariantsInferenceConfigurationText | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsInferenceConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsInferenceConfigurationText | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsInferenceConfigurationText | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _stopSequences?;
    get stopSequences(): string[];
    set stopSequences(value: string[]);
    resetStopSequences(): void;
    get stopSequencesInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockPromptVariantsInferenceConfiguration {
    /**
    * Prompt model inference configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#text BedrockPrompt#text}
    */
    readonly text?: BedrockPromptVariantsInferenceConfigurationText;
}
export declare function bedrockPromptVariantsInferenceConfigurationToTerraform(struct?: BedrockPromptVariantsInferenceConfiguration | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsInferenceConfigurationToHclTerraform(struct?: BedrockPromptVariantsInferenceConfiguration | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsInferenceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsInferenceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsInferenceConfiguration | cdktn.IResolvable | undefined);
    private _text;
    get text(): BedrockPromptVariantsInferenceConfigurationTextOutputReference;
    putText(value: BedrockPromptVariantsInferenceConfigurationText): void;
    resetText(): void;
    get textInput(): cdktn.IResolvable | BedrockPromptVariantsInferenceConfigurationText | undefined;
}
export interface BedrockPromptVariantsMetadata {
    /**
    * The key of a metadata tag for a prompt variant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#key BedrockPrompt#key}
    */
    readonly key?: string;
    /**
    * The value of a metadata tag for a prompt variant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#value BedrockPrompt#value}
    */
    readonly value?: string;
}
export declare function bedrockPromptVariantsMetadataToTerraform(struct?: BedrockPromptVariantsMetadata | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsMetadataToHclTerraform(struct?: BedrockPromptVariantsMetadata | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVariantsMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsMetadata | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockPromptVariantsMetadataList extends cdktn.ComplexList {
    internalValue?: BedrockPromptVariantsMetadata[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVariantsMetadataOutputReference;
}
export interface BedrockPromptVariantsTemplateConfigurationChatInputVariables {
    /**
    * Name for an input variable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#name BedrockPrompt#name}
    */
    readonly name?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatInputVariablesToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatInputVariables | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatInputVariablesToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatInputVariables | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatInputVariables | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatInputVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class BedrockPromptVariantsTemplateConfigurationChatInputVariablesList extends cdktn.ComplexList {
    internalValue?: BedrockPromptVariantsTemplateConfigurationChatInputVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVariantsTemplateConfigurationChatInputVariablesOutputReference;
}
export interface BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePoint {
    /**
    * CachePoint types for CachePointBlock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#type BedrockPrompt#type}
    */
    readonly type?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePointToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePoint | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePointToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePoint | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationChatMessagesContent {
    /**
    * CachePointBlock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#cache_point BedrockPrompt#cache_point}
    */
    readonly cachePoint?: BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePoint;
    /**
    * Configuration for chat prompt template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#text BedrockPrompt#text}
    */
    readonly text?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatMessagesContentToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatMessagesContent | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatMessagesContentToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatMessagesContent | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatMessagesContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatMessagesContent | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatMessagesContent | cdktn.IResolvable | undefined);
    private _cachePoint;
    get cachePoint(): BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePointOutputReference;
    putCachePoint(value: BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePoint): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatMessagesContentCachePoint | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
}
export declare class BedrockPromptVariantsTemplateConfigurationChatMessagesContentList extends cdktn.ComplexList {
    internalValue?: BedrockPromptVariantsTemplateConfigurationChatMessagesContent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVariantsTemplateConfigurationChatMessagesContentOutputReference;
}
export interface BedrockPromptVariantsTemplateConfigurationChatMessages {
    /**
    * List of Content Blocks
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#content BedrockPrompt#content}
    */
    readonly content?: BedrockPromptVariantsTemplateConfigurationChatMessagesContent[] | cdktn.IResolvable;
    /**
    * Conversation roles for the chat prompt
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#role BedrockPrompt#role}
    */
    readonly role?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatMessagesToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatMessages | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatMessagesToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatMessages | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatMessagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatMessages | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatMessages | cdktn.IResolvable | undefined);
    private _content;
    get content(): BedrockPromptVariantsTemplateConfigurationChatMessagesContentList;
    putContent(value: BedrockPromptVariantsTemplateConfigurationChatMessagesContent[] | cdktn.IResolvable): void;
    resetContent(): void;
    get contentInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatMessagesContent[] | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
}
export declare class BedrockPromptVariantsTemplateConfigurationChatMessagesList extends cdktn.ComplexList {
    internalValue?: BedrockPromptVariantsTemplateConfigurationChatMessages[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVariantsTemplateConfigurationChatMessagesOutputReference;
}
export interface BedrockPromptVariantsTemplateConfigurationChatSystemCachePoint {
    /**
    * CachePoint types for CachePointBlock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#type BedrockPrompt#type}
    */
    readonly type?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatSystemCachePointToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatSystemCachePointToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatSystemCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationChatSystem {
    /**
    * CachePointBlock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#cache_point BedrockPrompt#cache_point}
    */
    readonly cachePoint?: BedrockPromptVariantsTemplateConfigurationChatSystemCachePoint;
    /**
    * Configuration for chat prompt template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#text BedrockPrompt#text}
    */
    readonly text?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatSystemToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatSystem | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatSystemToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatSystem | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatSystemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatSystem | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatSystem | cdktn.IResolvable | undefined);
    private _cachePoint;
    get cachePoint(): BedrockPromptVariantsTemplateConfigurationChatSystemCachePointOutputReference;
    putCachePoint(value: BedrockPromptVariantsTemplateConfigurationChatSystemCachePoint): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatSystemCachePoint | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
}
export declare class BedrockPromptVariantsTemplateConfigurationChatSystemList extends cdktn.ComplexList {
    internalValue?: BedrockPromptVariantsTemplateConfigurationChatSystem[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVariantsTemplateConfigurationChatSystemOutputReference;
}
export interface BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool {
    /**
    * Tool name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#name BedrockPrompt#name}
    */
    readonly name?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceToolToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceToolToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoice {
    /**
    * Any Tool choice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#any BedrockPrompt#any}
    */
    readonly any?: string;
    /**
    * Auto Tool choice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#auto BedrockPrompt#auto}
    */
    readonly auto?: string;
    /**
    * Specific Tool choice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#tool BedrockPrompt#tool}
    */
    readonly tool?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable | undefined);
    private _any?;
    get any(): string;
    set any(value: string);
    resetAny(): void;
    get anyInput(): string | undefined;
    private _auto?;
    get auto(): string;
    set auto(value: string);
    resetAuto(): void;
    get autoInput(): string | undefined;
    private _tool;
    get tool(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceToolOutputReference;
    putTool(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool): void;
    resetTool(): void;
    get toolInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint {
    /**
    * CachePoint types for CachePointBlock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#type BedrockPrompt#type}
    */
    readonly type?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePointToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePointToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#json BedrockPrompt#json}
    */
    readonly json?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchemaToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchemaToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema | cdktn.IResolvable | undefined);
    private _json?;
    get json(): string;
    set json(value: string);
    resetJson(): void;
    get jsonInput(): string | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#description BedrockPrompt#description}
    */
    readonly description?: string;
    /**
    * Tool input schema
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#input_schema BedrockPrompt#input_schema}
    */
    readonly inputSchema?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema;
    /**
    * Tool name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#name BedrockPrompt#name}
    */
    readonly name?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inputSchema;
    get inputSchema(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchemaOutputReference;
    putInputSchema(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema): void;
    resetInputSchema(): void;
    get inputSchemaInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools {
    /**
    * CachePointBlock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#cache_point BedrockPrompt#cache_point}
    */
    readonly cachePoint?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint;
    /**
    * Tool specification
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#tool_spec BedrockPrompt#tool_spec}
    */
    readonly toolSpec?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools | cdktn.IResolvable | undefined);
    private _cachePoint;
    get cachePoint(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePointOutputReference;
    putCachePoint(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint | undefined;
    private _toolSpec;
    get toolSpec(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecOutputReference;
    putToolSpec(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec): void;
    resetToolSpec(): void;
    get toolSpecInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec | undefined;
}
export declare class BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsList extends cdktn.ComplexList {
    internalValue?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsOutputReference;
}
export interface BedrockPromptVariantsTemplateConfigurationChatToolConfiguration {
    /**
    * Tool choice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#tool_choice BedrockPrompt#tool_choice}
    */
    readonly toolChoice?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoice;
    /**
    * List of Tools
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#tools BedrockPrompt#tools}
    */
    readonly tools?: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools[] | cdktn.IResolvable;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfiguration | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatToolConfigurationToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChatToolConfiguration | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatToolConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChatToolConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChatToolConfiguration | cdktn.IResolvable | undefined);
    private _toolChoice;
    get toolChoice(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoiceOutputReference;
    putToolChoice(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoice): void;
    resetToolChoice(): void;
    get toolChoiceInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolChoice | undefined;
    private _tools;
    get tools(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationToolsList;
    putTools(value: BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools[] | cdktn.IResolvable): void;
    resetTools(): void;
    get toolsInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatToolConfigurationTools[] | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationChat {
    /**
    * List of input variables
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#input_variables BedrockPrompt#input_variables}
    */
    readonly inputVariables?: BedrockPromptVariantsTemplateConfigurationChatInputVariables[] | cdktn.IResolvable;
    /**
    * List of messages for chat prompt template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#messages BedrockPrompt#messages}
    */
    readonly messages?: BedrockPromptVariantsTemplateConfigurationChatMessages[] | cdktn.IResolvable;
    /**
    * Configuration for chat prompt template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#system BedrockPrompt#system}
    */
    readonly systemAttribute?: BedrockPromptVariantsTemplateConfigurationChatSystem[] | cdktn.IResolvable;
    /**
    * Tool configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#tool_configuration BedrockPrompt#tool_configuration}
    */
    readonly toolConfiguration?: BedrockPromptVariantsTemplateConfigurationChatToolConfiguration;
}
export declare function bedrockPromptVariantsTemplateConfigurationChatToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChat | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationChatToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationChat | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationChatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationChat | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationChat | cdktn.IResolvable | undefined);
    private _inputVariables;
    get inputVariables(): BedrockPromptVariantsTemplateConfigurationChatInputVariablesList;
    putInputVariables(value: BedrockPromptVariantsTemplateConfigurationChatInputVariables[] | cdktn.IResolvable): void;
    resetInputVariables(): void;
    get inputVariablesInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatInputVariables[] | undefined;
    private _messages;
    get messages(): BedrockPromptVariantsTemplateConfigurationChatMessagesList;
    putMessages(value: BedrockPromptVariantsTemplateConfigurationChatMessages[] | cdktn.IResolvable): void;
    resetMessages(): void;
    get messagesInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatMessages[] | undefined;
    private _system;
    get systemAttribute(): BedrockPromptVariantsTemplateConfigurationChatSystemList;
    putSystemAttribute(value: BedrockPromptVariantsTemplateConfigurationChatSystem[] | cdktn.IResolvable): void;
    resetSystemAttribute(): void;
    get systemAttributeInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatSystem[] | undefined;
    private _toolConfiguration;
    get toolConfiguration(): BedrockPromptVariantsTemplateConfigurationChatToolConfigurationOutputReference;
    putToolConfiguration(value: BedrockPromptVariantsTemplateConfigurationChatToolConfiguration): void;
    resetToolConfiguration(): void;
    get toolConfigurationInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChatToolConfiguration | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationTextCachePoint {
    /**
    * CachePoint types for CachePointBlock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#type BedrockPrompt#type}
    */
    readonly type?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationTextCachePointToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationTextCachePoint | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationTextCachePointToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationTextCachePoint | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationTextCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationTextCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationTextCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationTextInputVariables {
    /**
    * Name for an input variable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#name BedrockPrompt#name}
    */
    readonly name?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationTextInputVariablesToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationTextInputVariables | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationTextInputVariablesToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationTextInputVariables | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationTextInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationTextInputVariables | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationTextInputVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class BedrockPromptVariantsTemplateConfigurationTextInputVariablesList extends cdktn.ComplexList {
    internalValue?: BedrockPromptVariantsTemplateConfigurationTextInputVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVariantsTemplateConfigurationTextInputVariablesOutputReference;
}
export interface BedrockPromptVariantsTemplateConfigurationTextTextS3Location {
    /**
    * A bucket in S3
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#bucket BedrockPrompt#bucket}
    */
    readonly bucket?: string;
    /**
    * A object key in S3
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#key BedrockPrompt#key}
    */
    readonly key?: string;
    /**
    * The version of the the S3 object to use
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#version BedrockPrompt#version}
    */
    readonly version?: string;
}
export declare function bedrockPromptVariantsTemplateConfigurationTextTextS3LocationToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationTextTextS3Location | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationTextTextS3LocationToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationTextTextS3Location | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationTextTextS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationTextTextS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationTextTextS3Location | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface BedrockPromptVariantsTemplateConfigurationText {
    /**
    * CachePointBlock
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#cache_point BedrockPrompt#cache_point}
    */
    readonly cachePoint?: BedrockPromptVariantsTemplateConfigurationTextCachePoint;
    /**
    * List of input variables
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#input_variables BedrockPrompt#input_variables}
    */
    readonly inputVariables?: BedrockPromptVariantsTemplateConfigurationTextInputVariables[] | cdktn.IResolvable;
    /**
    * Prompt content for String prompt template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#text BedrockPrompt#text}
    */
    readonly text?: string;
    /**
    * The identifier for the S3 resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#text_s3_location BedrockPrompt#text_s3_location}
    */
    readonly textS3Location?: BedrockPromptVariantsTemplateConfigurationTextTextS3Location;
}
export declare function bedrockPromptVariantsTemplateConfigurationTextToTerraform(struct?: BedrockPromptVariantsTemplateConfigurationText | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationTextToHclTerraform(struct?: BedrockPromptVariantsTemplateConfigurationText | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfigurationText | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfigurationText | cdktn.IResolvable | undefined);
    private _cachePoint;
    get cachePoint(): BedrockPromptVariantsTemplateConfigurationTextCachePointOutputReference;
    putCachePoint(value: BedrockPromptVariantsTemplateConfigurationTextCachePoint): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationTextCachePoint | undefined;
    private _inputVariables;
    get inputVariables(): BedrockPromptVariantsTemplateConfigurationTextInputVariablesList;
    putInputVariables(value: BedrockPromptVariantsTemplateConfigurationTextInputVariables[] | cdktn.IResolvable): void;
    resetInputVariables(): void;
    get inputVariablesInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationTextInputVariables[] | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _textS3Location;
    get textS3Location(): BedrockPromptVariantsTemplateConfigurationTextTextS3LocationOutputReference;
    putTextS3Location(value: BedrockPromptVariantsTemplateConfigurationTextTextS3Location): void;
    resetTextS3Location(): void;
    get textS3LocationInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationTextTextS3Location | undefined;
}
export interface BedrockPromptVariantsTemplateConfiguration {
    /**
    * Configuration for chat prompt template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#chat BedrockPrompt#chat}
    */
    readonly chat?: BedrockPromptVariantsTemplateConfigurationChat;
    /**
    * Configuration for text prompt template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#text BedrockPrompt#text}
    */
    readonly text?: BedrockPromptVariantsTemplateConfigurationText;
}
export declare function bedrockPromptVariantsTemplateConfigurationToTerraform(struct?: BedrockPromptVariantsTemplateConfiguration | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsTemplateConfigurationToHclTerraform(struct?: BedrockPromptVariantsTemplateConfiguration | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsTemplateConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVariantsTemplateConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariantsTemplateConfiguration | cdktn.IResolvable | undefined);
    private _chat;
    get chat(): BedrockPromptVariantsTemplateConfigurationChatOutputReference;
    putChat(value: BedrockPromptVariantsTemplateConfigurationChat): void;
    resetChat(): void;
    get chatInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationChat | undefined;
    private _text;
    get text(): BedrockPromptVariantsTemplateConfigurationTextOutputReference;
    putText(value: BedrockPromptVariantsTemplateConfigurationText): void;
    resetText(): void;
    get textInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfigurationText | undefined;
}
export interface BedrockPromptVariants {
    /**
    * Contains model-specific configurations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#additional_model_request_fields BedrockPrompt#additional_model_request_fields}
    */
    readonly additionalModelRequestFields?: string;
    /**
    * Target resource to invoke with Prompt
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#gen_ai_resource BedrockPrompt#gen_ai_resource}
    */
    readonly genAiResource?: BedrockPromptVariantsGenAiResource;
    /**
    * Model inference configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#inference_configuration BedrockPrompt#inference_configuration}
    */
    readonly inferenceConfiguration?: BedrockPromptVariantsInferenceConfiguration;
    /**
    * List of metadata to associate with the prompt variant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#metadata BedrockPrompt#metadata}
    */
    readonly metadata?: BedrockPromptVariantsMetadata[] | cdktn.IResolvable;
    /**
    * ARN or Id of a Bedrock Foundational Model or Inference Profile, or the ARN of a imported model, or a provisioned throughput ARN for custom models.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#model_id BedrockPrompt#model_id}
    */
    readonly modelId?: string;
    /**
    * Name for a variant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#name BedrockPrompt#name}
    */
    readonly name?: string;
    /**
    * Prompt template configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#template_configuration BedrockPrompt#template_configuration}
    */
    readonly templateConfiguration?: BedrockPromptVariantsTemplateConfiguration;
    /**
    * Prompt template type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#template_type BedrockPrompt#template_type}
    */
    readonly templateType?: string;
}
export declare function bedrockPromptVariantsToTerraform(struct?: BedrockPromptVariants | cdktn.IResolvable): any;
export declare function bedrockPromptVariantsToHclTerraform(struct?: BedrockPromptVariants | cdktn.IResolvable): any;
export declare class BedrockPromptVariantsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVariants | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockPromptVariants | cdktn.IResolvable | undefined);
    private _additionalModelRequestFields?;
    get additionalModelRequestFields(): string;
    set additionalModelRequestFields(value: string);
    resetAdditionalModelRequestFields(): void;
    get additionalModelRequestFieldsInput(): string | undefined;
    private _genAiResource;
    get genAiResource(): BedrockPromptVariantsGenAiResourceOutputReference;
    putGenAiResource(value: BedrockPromptVariantsGenAiResource): void;
    resetGenAiResource(): void;
    get genAiResourceInput(): cdktn.IResolvable | BedrockPromptVariantsGenAiResource | undefined;
    private _inferenceConfiguration;
    get inferenceConfiguration(): BedrockPromptVariantsInferenceConfigurationOutputReference;
    putInferenceConfiguration(value: BedrockPromptVariantsInferenceConfiguration): void;
    resetInferenceConfiguration(): void;
    get inferenceConfigurationInput(): cdktn.IResolvable | BedrockPromptVariantsInferenceConfiguration | undefined;
    private _metadata;
    get metadata(): BedrockPromptVariantsMetadataList;
    putMetadata(value: BedrockPromptVariantsMetadata[] | cdktn.IResolvable): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | BedrockPromptVariantsMetadata[] | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _templateConfiguration;
    get templateConfiguration(): BedrockPromptVariantsTemplateConfigurationOutputReference;
    putTemplateConfiguration(value: BedrockPromptVariantsTemplateConfiguration): void;
    resetTemplateConfiguration(): void;
    get templateConfigurationInput(): cdktn.IResolvable | BedrockPromptVariantsTemplateConfiguration | undefined;
    private _templateType?;
    get templateType(): string;
    set templateType(value: string);
    resetTemplateType(): void;
    get templateTypeInput(): string | undefined;
}
export declare class BedrockPromptVariantsList extends cdktn.ComplexList {
    internalValue?: BedrockPromptVariants[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVariantsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt awscc_bedrock_prompt}
*/
export declare class BedrockPrompt extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_prompt";
    /**
    * Generates CDKTN code for importing a BedrockPrompt resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockPrompt to import
    * @param importFromId The id of the existing BedrockPrompt that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockPrompt to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt awscc_bedrock_prompt} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockPromptConfig
    */
    constructor(scope: Construct, id: string, config: BedrockPromptConfig);
    get arn(): string;
    get createdAt(): string;
    private _customerEncryptionKeyArn?;
    get customerEncryptionKeyArn(): string;
    set customerEncryptionKeyArn(value: string);
    resetCustomerEncryptionKeyArn(): void;
    get customerEncryptionKeyArnInput(): string | undefined;
    private _defaultVariant?;
    get defaultVariant(): string;
    set defaultVariant(value: string);
    resetDefaultVariant(): void;
    get defaultVariantInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get promptId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    private _variants;
    get variants(): BedrockPromptVariantsList;
    putVariants(value: BedrockPromptVariants[] | cdktn.IResolvable): void;
    resetVariants(): void;
    get variantsInput(): cdktn.IResolvable | BedrockPromptVariants[] | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
