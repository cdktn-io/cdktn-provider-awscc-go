/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayMethodConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_method#id DataAwsccApigatewayMethod#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayMethodIntegrationIntegrationResponses {
}
export declare function dataAwsccApigatewayMethodIntegrationIntegrationResponsesToTerraform(struct?: DataAwsccApigatewayMethodIntegrationIntegrationResponses): any;
export declare function dataAwsccApigatewayMethodIntegrationIntegrationResponsesToHclTerraform(struct?: DataAwsccApigatewayMethodIntegrationIntegrationResponses): any;
export declare class DataAwsccApigatewayMethodIntegrationIntegrationResponsesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayMethodIntegrationIntegrationResponses | undefined;
    set internalValue(value: DataAwsccApigatewayMethodIntegrationIntegrationResponses | undefined);
    get contentHandling(): string;
    private _responseParameters;
    get responseParameters(): cdktn.StringMap;
    private _responseTemplates;
    get responseTemplates(): cdktn.StringMap;
    get selectionPattern(): string;
    get statusCode(): string;
}
export declare class DataAwsccApigatewayMethodIntegrationIntegrationResponsesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayMethodIntegrationIntegrationResponsesOutputReference;
}
export interface DataAwsccApigatewayMethodIntegration {
}
export declare function dataAwsccApigatewayMethodIntegrationToTerraform(struct?: DataAwsccApigatewayMethodIntegration): any;
export declare function dataAwsccApigatewayMethodIntegrationToHclTerraform(struct?: DataAwsccApigatewayMethodIntegration): any;
export declare class DataAwsccApigatewayMethodIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayMethodIntegration | undefined;
    set internalValue(value: DataAwsccApigatewayMethodIntegration | undefined);
    get cacheKeyParameters(): string[];
    get cacheNamespace(): string;
    get connectionId(): string;
    get connectionType(): string;
    get contentHandling(): string;
    get credentials(): string;
    get integrationHttpMethod(): string;
    private _integrationResponses;
    get integrationResponses(): DataAwsccApigatewayMethodIntegrationIntegrationResponsesList;
    get integrationTarget(): string;
    get passthroughBehavior(): string;
    private _requestParameters;
    get requestParameters(): cdktn.StringMap;
    private _requestTemplates;
    get requestTemplates(): cdktn.StringMap;
    get responseTransferMode(): string;
    get timeoutInMillis(): number;
    get type(): string;
    get uri(): string;
}
export interface DataAwsccApigatewayMethodMethodResponses {
}
export declare function dataAwsccApigatewayMethodMethodResponsesToTerraform(struct?: DataAwsccApigatewayMethodMethodResponses): any;
export declare function dataAwsccApigatewayMethodMethodResponsesToHclTerraform(struct?: DataAwsccApigatewayMethodMethodResponses): any;
export declare class DataAwsccApigatewayMethodMethodResponsesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayMethodMethodResponses | undefined;
    set internalValue(value: DataAwsccApigatewayMethodMethodResponses | undefined);
    private _responseModels;
    get responseModels(): cdktn.StringMap;
    private _responseParameters;
    get responseParameters(): cdktn.BooleanMap;
    get statusCode(): string;
}
export declare class DataAwsccApigatewayMethodMethodResponsesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayMethodMethodResponsesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_method awscc_apigateway_method}
*/
export declare class DataAwsccApigatewayMethod extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_method";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayMethod resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayMethod to import
    * @param importFromId The id of the existing DataAwsccApigatewayMethod that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_method#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayMethod to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_method awscc_apigateway_method} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayMethodConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayMethodConfig);
    get apiKeyRequired(): cdktn.IResolvable;
    get authorizationScopes(): string[];
    get authorizationType(): string;
    get authorizerId(): string;
    get httpMethod(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _integration;
    get integration(): DataAwsccApigatewayMethodIntegrationOutputReference;
    private _methodResponses;
    get methodResponses(): DataAwsccApigatewayMethodMethodResponsesList;
    get operationName(): string;
    private _requestModels;
    get requestModels(): cdktn.StringMap;
    private _requestParameters;
    get requestParameters(): cdktn.BooleanMap;
    get requestValidatorId(): string;
    get resourceId(): string;
    get restApiId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
