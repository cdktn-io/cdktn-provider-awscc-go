/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectRoutingProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether agents with this routing profile will have their routing order calculated based on longest idle time or time since their last inbound contact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#agent_availability_timer ConnectRoutingProfile#agent_availability_timer}
    */
    readonly agentAvailabilityTimer?: string;
    /**
    * The identifier of the default outbound queue for this routing profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#default_outbound_queue_arn ConnectRoutingProfile#default_outbound_queue_arn}
    */
    readonly defaultOutboundQueueArn: string;
    /**
    * The description of the routing profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#description ConnectRoutingProfile#description}
    */
    readonly description: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#instance_arn ConnectRoutingProfile#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The manual assignment queues to associate with this routing profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#manual_assignment_queue_configs ConnectRoutingProfile#manual_assignment_queue_configs}
    */
    readonly manualAssignmentQueueConfigs?: ConnectRoutingProfileManualAssignmentQueueConfigs[] | cdktn.IResolvable;
    /**
    * The channels agents can handle in the Contact Control Panel (CCP) for this routing profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#media_concurrencies ConnectRoutingProfile#media_concurrencies}
    */
    readonly mediaConcurrencies: ConnectRoutingProfileMediaConcurrencies[] | cdktn.IResolvable;
    /**
    * The name of the routing profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#name ConnectRoutingProfile#name}
    */
    readonly name: string;
    /**
    * The queues to associate with this routing profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#queue_configs ConnectRoutingProfile#queue_configs}
    */
    readonly queueConfigs?: ConnectRoutingProfileQueueConfigs[] | cdktn.IResolvable;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#tags ConnectRoutingProfile#tags}
    */
    readonly tags?: ConnectRoutingProfileTags[] | cdktn.IResolvable;
}
export interface ConnectRoutingProfileManualAssignmentQueueConfigsQueueReference {
    /**
    * The channels that agents can handle in the Contact Control Panel (CCP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#channel ConnectRoutingProfile#channel}
    */
    readonly channel?: string;
    /**
    * The Amazon Resource Name (ARN) for the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#queue_arn ConnectRoutingProfile#queue_arn}
    */
    readonly queueArn?: string;
}
export declare function connectRoutingProfileManualAssignmentQueueConfigsQueueReferenceToTerraform(struct?: ConnectRoutingProfileManualAssignmentQueueConfigsQueueReference | cdktn.IResolvable): any;
export declare function connectRoutingProfileManualAssignmentQueueConfigsQueueReferenceToHclTerraform(struct?: ConnectRoutingProfileManualAssignmentQueueConfigsQueueReference | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileManualAssignmentQueueConfigsQueueReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectRoutingProfileManualAssignmentQueueConfigsQueueReference | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileManualAssignmentQueueConfigsQueueReference | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _queueArn?;
    get queueArn(): string;
    set queueArn(value: string);
    resetQueueArn(): void;
    get queueArnInput(): string | undefined;
}
export interface ConnectRoutingProfileManualAssignmentQueueConfigs {
    /**
    * Contains the channel and queue identifier for a routing profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#queue_reference ConnectRoutingProfile#queue_reference}
    */
    readonly queueReference?: ConnectRoutingProfileManualAssignmentQueueConfigsQueueReference;
}
export declare function connectRoutingProfileManualAssignmentQueueConfigsToTerraform(struct?: ConnectRoutingProfileManualAssignmentQueueConfigs | cdktn.IResolvable): any;
export declare function connectRoutingProfileManualAssignmentQueueConfigsToHclTerraform(struct?: ConnectRoutingProfileManualAssignmentQueueConfigs | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileManualAssignmentQueueConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectRoutingProfileManualAssignmentQueueConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileManualAssignmentQueueConfigs | cdktn.IResolvable | undefined);
    private _queueReference;
    get queueReference(): ConnectRoutingProfileManualAssignmentQueueConfigsQueueReferenceOutputReference;
    putQueueReference(value: ConnectRoutingProfileManualAssignmentQueueConfigsQueueReference): void;
    resetQueueReference(): void;
    get queueReferenceInput(): cdktn.IResolvable | ConnectRoutingProfileManualAssignmentQueueConfigsQueueReference | undefined;
}
export declare class ConnectRoutingProfileManualAssignmentQueueConfigsList extends cdktn.ComplexList {
    internalValue?: ConnectRoutingProfileManualAssignmentQueueConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectRoutingProfileManualAssignmentQueueConfigsOutputReference;
}
export interface ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior {
    /**
    * Specifies the other channels that can be routed to an agent handling their current channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#behavior_type ConnectRoutingProfile#behavior_type}
    */
    readonly behaviorType?: string;
}
export declare function connectRoutingProfileMediaConcurrenciesCrossChannelBehaviorToTerraform(struct?: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior | cdktn.IResolvable): any;
export declare function connectRoutingProfileMediaConcurrenciesCrossChannelBehaviorToHclTerraform(struct?: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileMediaConcurrenciesCrossChannelBehaviorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior | cdktn.IResolvable | undefined);
    private _behaviorType?;
    get behaviorType(): string;
    set behaviorType(value: string);
    resetBehaviorType(): void;
    get behaviorTypeInput(): string | undefined;
}
export interface ConnectRoutingProfileMediaConcurrencies {
    /**
    * The channels that agents can handle in the Contact Control Panel (CCP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#channel ConnectRoutingProfile#channel}
    */
    readonly channel: string;
    /**
    * The number of contacts an agent can have on a channel simultaneously.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#concurrency ConnectRoutingProfile#concurrency}
    */
    readonly concurrency: number;
    /**
    * Defines the cross-channel routing behavior that allows an agent working on a contact in one channel to be offered a contact from a different channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#cross_channel_behavior ConnectRoutingProfile#cross_channel_behavior}
    */
    readonly crossChannelBehavior?: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior;
}
export declare function connectRoutingProfileMediaConcurrenciesToTerraform(struct?: ConnectRoutingProfileMediaConcurrencies | cdktn.IResolvable): any;
export declare function connectRoutingProfileMediaConcurrenciesToHclTerraform(struct?: ConnectRoutingProfileMediaConcurrencies | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileMediaConcurrenciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectRoutingProfileMediaConcurrencies | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileMediaConcurrencies | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _concurrency?;
    get concurrency(): number;
    set concurrency(value: number);
    get concurrencyInput(): number | undefined;
    private _crossChannelBehavior;
    get crossChannelBehavior(): ConnectRoutingProfileMediaConcurrenciesCrossChannelBehaviorOutputReference;
    putCrossChannelBehavior(value: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior): void;
    resetCrossChannelBehavior(): void;
    get crossChannelBehaviorInput(): cdktn.IResolvable | ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior | undefined;
}
export declare class ConnectRoutingProfileMediaConcurrenciesList extends cdktn.ComplexList {
    internalValue?: ConnectRoutingProfileMediaConcurrencies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectRoutingProfileMediaConcurrenciesOutputReference;
}
export interface ConnectRoutingProfileQueueConfigsQueueReference {
    /**
    * The channels that agents can handle in the Contact Control Panel (CCP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#channel ConnectRoutingProfile#channel}
    */
    readonly channel?: string;
    /**
    * The Amazon Resource Name (ARN) for the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#queue_arn ConnectRoutingProfile#queue_arn}
    */
    readonly queueArn?: string;
}
export declare function connectRoutingProfileQueueConfigsQueueReferenceToTerraform(struct?: ConnectRoutingProfileQueueConfigsQueueReference | cdktn.IResolvable): any;
export declare function connectRoutingProfileQueueConfigsQueueReferenceToHclTerraform(struct?: ConnectRoutingProfileQueueConfigsQueueReference | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileQueueConfigsQueueReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectRoutingProfileQueueConfigsQueueReference | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileQueueConfigsQueueReference | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _queueArn?;
    get queueArn(): string;
    set queueArn(value: string);
    resetQueueArn(): void;
    get queueArnInput(): string | undefined;
}
export interface ConnectRoutingProfileQueueConfigs {
    /**
    * The delay, in seconds, a contact should wait in the queue before they are routed to an available agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#delay ConnectRoutingProfile#delay}
    */
    readonly delay?: number;
    /**
    * The order in which contacts are to be handled for the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#priority ConnectRoutingProfile#priority}
    */
    readonly priority?: number;
    /**
    * Contains the channel and queue identifier for a routing profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#queue_reference ConnectRoutingProfile#queue_reference}
    */
    readonly queueReference?: ConnectRoutingProfileQueueConfigsQueueReference;
}
export declare function connectRoutingProfileQueueConfigsToTerraform(struct?: ConnectRoutingProfileQueueConfigs | cdktn.IResolvable): any;
export declare function connectRoutingProfileQueueConfigsToHclTerraform(struct?: ConnectRoutingProfileQueueConfigs | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileQueueConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectRoutingProfileQueueConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileQueueConfigs | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): number;
    set delay(value: number);
    resetDelay(): void;
    get delayInput(): number | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _queueReference;
    get queueReference(): ConnectRoutingProfileQueueConfigsQueueReferenceOutputReference;
    putQueueReference(value: ConnectRoutingProfileQueueConfigsQueueReference): void;
    resetQueueReference(): void;
    get queueReferenceInput(): cdktn.IResolvable | ConnectRoutingProfileQueueConfigsQueueReference | undefined;
}
export declare class ConnectRoutingProfileQueueConfigsList extends cdktn.ComplexList {
    internalValue?: ConnectRoutingProfileQueueConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectRoutingProfileQueueConfigsOutputReference;
}
export interface ConnectRoutingProfileTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#key ConnectRoutingProfile#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#value ConnectRoutingProfile#value}
    */
    readonly value?: string;
}
export declare function connectRoutingProfileTagsToTerraform(struct?: ConnectRoutingProfileTags | cdktn.IResolvable): any;
export declare function connectRoutingProfileTagsToHclTerraform(struct?: ConnectRoutingProfileTags | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectRoutingProfileTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectRoutingProfileTagsList extends cdktn.ComplexList {
    internalValue?: ConnectRoutingProfileTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectRoutingProfileTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile awscc_connect_routing_profile}
*/
export declare class ConnectRoutingProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_routing_profile";
    /**
    * Generates CDKTN code for importing a ConnectRoutingProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectRoutingProfile to import
    * @param importFromId The id of the existing ConnectRoutingProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectRoutingProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_routing_profile awscc_connect_routing_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectRoutingProfileConfig
    */
    constructor(scope: Construct, id: string, config: ConnectRoutingProfileConfig);
    private _agentAvailabilityTimer?;
    get agentAvailabilityTimer(): string;
    set agentAvailabilityTimer(value: string);
    resetAgentAvailabilityTimer(): void;
    get agentAvailabilityTimerInput(): string | undefined;
    private _defaultOutboundQueueArn?;
    get defaultOutboundQueueArn(): string;
    set defaultOutboundQueueArn(value: string);
    get defaultOutboundQueueArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _manualAssignmentQueueConfigs;
    get manualAssignmentQueueConfigs(): ConnectRoutingProfileManualAssignmentQueueConfigsList;
    putManualAssignmentQueueConfigs(value: ConnectRoutingProfileManualAssignmentQueueConfigs[] | cdktn.IResolvable): void;
    resetManualAssignmentQueueConfigs(): void;
    get manualAssignmentQueueConfigsInput(): cdktn.IResolvable | ConnectRoutingProfileManualAssignmentQueueConfigs[] | undefined;
    private _mediaConcurrencies;
    get mediaConcurrencies(): ConnectRoutingProfileMediaConcurrenciesList;
    putMediaConcurrencies(value: ConnectRoutingProfileMediaConcurrencies[] | cdktn.IResolvable): void;
    get mediaConcurrenciesInput(): cdktn.IResolvable | ConnectRoutingProfileMediaConcurrencies[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _queueConfigs;
    get queueConfigs(): ConnectRoutingProfileQueueConfigsList;
    putQueueConfigs(value: ConnectRoutingProfileQueueConfigs[] | cdktn.IResolvable): void;
    resetQueueConfigs(): void;
    get queueConfigsInput(): cdktn.IResolvable | ConnectRoutingProfileQueueConfigs[] | undefined;
    get routingProfileArn(): string;
    private _tags;
    get tags(): ConnectRoutingProfileTagsList;
    putTags(value: ConnectRoutingProfileTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectRoutingProfileTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
