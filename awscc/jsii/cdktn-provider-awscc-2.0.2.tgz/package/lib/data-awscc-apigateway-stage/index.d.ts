/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayStageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_stage#id DataAwsccApigatewayStage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayStageAccessLogSetting {
}
export declare function dataAwsccApigatewayStageAccessLogSettingToTerraform(struct?: DataAwsccApigatewayStageAccessLogSetting): any;
export declare function dataAwsccApigatewayStageAccessLogSettingToHclTerraform(struct?: DataAwsccApigatewayStageAccessLogSetting): any;
export declare class DataAwsccApigatewayStageAccessLogSettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayStageAccessLogSetting | undefined;
    set internalValue(value: DataAwsccApigatewayStageAccessLogSetting | undefined);
    get destinationArn(): string;
    get format(): string;
}
export interface DataAwsccApigatewayStageCanarySetting {
}
export declare function dataAwsccApigatewayStageCanarySettingToTerraform(struct?: DataAwsccApigatewayStageCanarySetting): any;
export declare function dataAwsccApigatewayStageCanarySettingToHclTerraform(struct?: DataAwsccApigatewayStageCanarySetting): any;
export declare class DataAwsccApigatewayStageCanarySettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayStageCanarySetting | undefined;
    set internalValue(value: DataAwsccApigatewayStageCanarySetting | undefined);
    get deploymentId(): string;
    get percentTraffic(): number;
    private _stageVariableOverrides;
    get stageVariableOverrides(): cdktn.StringMap;
    get useStageCache(): cdktn.IResolvable;
}
export interface DataAwsccApigatewayStageMethodSettings {
}
export declare function dataAwsccApigatewayStageMethodSettingsToTerraform(struct?: DataAwsccApigatewayStageMethodSettings): any;
export declare function dataAwsccApigatewayStageMethodSettingsToHclTerraform(struct?: DataAwsccApigatewayStageMethodSettings): any;
export declare class DataAwsccApigatewayStageMethodSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayStageMethodSettings | undefined;
    set internalValue(value: DataAwsccApigatewayStageMethodSettings | undefined);
    get cacheDataEncrypted(): cdktn.IResolvable;
    get cacheTtlInSeconds(): number;
    get cachingEnabled(): cdktn.IResolvable;
    get dataTraceEnabled(): cdktn.IResolvable;
    get httpMethod(): string;
    get loggingLevel(): string;
    get metricsEnabled(): cdktn.IResolvable;
    get resourcePath(): string;
    get throttlingBurstLimit(): number;
    get throttlingRateLimit(): number;
}
export declare class DataAwsccApigatewayStageMethodSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayStageMethodSettingsOutputReference;
}
export interface DataAwsccApigatewayStageTags {
}
export declare function dataAwsccApigatewayStageTagsToTerraform(struct?: DataAwsccApigatewayStageTags): any;
export declare function dataAwsccApigatewayStageTagsToHclTerraform(struct?: DataAwsccApigatewayStageTags): any;
export declare class DataAwsccApigatewayStageTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayStageTags | undefined;
    set internalValue(value: DataAwsccApigatewayStageTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayStageTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayStageTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_stage awscc_apigateway_stage}
*/
export declare class DataAwsccApigatewayStage extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_stage";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayStage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayStage to import
    * @param importFromId The id of the existing DataAwsccApigatewayStage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_stage#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayStage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_stage awscc_apigateway_stage} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayStageConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayStageConfig);
    private _accessLogSetting;
    get accessLogSetting(): DataAwsccApigatewayStageAccessLogSettingOutputReference;
    get cacheClusterEnabled(): cdktn.IResolvable;
    get cacheClusterSize(): string;
    private _canarySetting;
    get canarySetting(): DataAwsccApigatewayStageCanarySettingOutputReference;
    get clientCertificateId(): string;
    get deploymentId(): string;
    get description(): string;
    get documentationVersion(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _methodSettings;
    get methodSettings(): DataAwsccApigatewayStageMethodSettingsList;
    get restApiId(): string;
    get stageName(): string;
    private _tags;
    get tags(): DataAwsccApigatewayStageTagsList;
    get tracingEnabled(): cdktn.IResolvable;
    private _variables;
    get variables(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
