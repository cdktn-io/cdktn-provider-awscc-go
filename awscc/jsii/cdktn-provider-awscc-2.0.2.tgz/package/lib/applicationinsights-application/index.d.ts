/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationinsightsApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set to true, the managed policies for SSM and CW will be attached to the instance roles if they are missing
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#attach_missing_permission ApplicationinsightsApplication#attach_missing_permission}
    */
    readonly attachMissingPermission?: boolean | cdktn.IResolvable;
    /**
    * If set to true, application will be configured with recommended monitoring configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#auto_configuration_enabled ApplicationinsightsApplication#auto_configuration_enabled}
    */
    readonly autoConfigurationEnabled?: boolean | cdktn.IResolvable;
    /**
    * The monitoring settings of the components.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#component_monitoring_settings ApplicationinsightsApplication#component_monitoring_settings}
    */
    readonly componentMonitoringSettings?: ApplicationinsightsApplicationComponentMonitoringSettings[] | cdktn.IResolvable;
    /**
    * The custom grouped components.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#custom_components ApplicationinsightsApplication#custom_components}
    */
    readonly customComponents?: ApplicationinsightsApplicationCustomComponents[] | cdktn.IResolvable;
    /**
    * Indicates whether Application Insights can listen to CloudWatch events for the application resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#cwe_monitor_enabled ApplicationinsightsApplication#cwe_monitor_enabled}
    */
    readonly cweMonitorEnabled?: boolean | cdktn.IResolvable;
    /**
    * The grouping type of the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#grouping_type ApplicationinsightsApplication#grouping_type}
    */
    readonly groupingType?: string;
    /**
    * The log pattern sets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_pattern_sets ApplicationinsightsApplication#log_pattern_sets}
    */
    readonly logPatternSets?: ApplicationinsightsApplicationLogPatternSets[] | cdktn.IResolvable;
    /**
    * When set to true, creates opsItems for any problems detected on an application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#ops_center_enabled ApplicationinsightsApplication#ops_center_enabled}
    */
    readonly opsCenterEnabled?: boolean | cdktn.IResolvable;
    /**
    * The SNS topic provided to Application Insights that is associated to the created opsItem.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#ops_item_sns_topic_arn ApplicationinsightsApplication#ops_item_sns_topic_arn}
    */
    readonly opsItemSnsTopicArn?: string;
    /**
    * The name of the resource group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#resource_group_name ApplicationinsightsApplication#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Application Insights sends notifications to this SNS topic whenever there is a problem update in the associated application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sns_notification_arn ApplicationinsightsApplication#sns_notification_arn}
    */
    readonly snsNotificationArn?: string;
    /**
    * The tags of Application Insights application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#tags ApplicationinsightsApplication#tags}
    */
    readonly tags?: ApplicationinsightsApplicationTags[] | cdktn.IResolvable;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics {
    /**
    * The name of the metric to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metric_name ApplicationinsightsApplication#alarm_metric_name}
    */
    readonly alarmMetricName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetricsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetricsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics | cdktn.IResolvable | undefined);
    private _alarmMetricName?;
    get alarmMetricName(): string;
    set alarmMetricName(value: string);
    resetAlarmMetricName(): void;
    get alarmMetricNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetricsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms {
    /**
    * The name of the CloudWatch alarm to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_name ApplicationinsightsApplication#alarm_name}
    */
    readonly alarmName?: string;
    /**
    * Indicates the degree of outage when the alarm goes off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#severity ApplicationinsightsApplication#severity}
    */
    readonly severity?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms | cdktn.IResolvable | undefined);
    private _alarmName?;
    get alarmName(): string;
    set alarmName(value: string);
    resetAlarmName(): void;
    get alarmNameInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter {
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | cdktn.IResolvable | undefined);
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporter {
    /**
    * A flag which indicates agreeing to install SAP HANA DB client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#agree_to_install_hanadb_client ApplicationinsightsApplication#agree_to_install_hanadb_client}
    */
    readonly agreeToInstallHanadbClient?: boolean | cdktn.IResolvable;
    /**
    * The HANA DB port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#hana_port ApplicationinsightsApplication#hana_port}
    */
    readonly hanaPort?: string;
    /**
    * The secret name which manages the HANA DB credentials e.g. {
    *   "username": "<>",
    *   "password": "<>"
    * }.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#hana_secret_name ApplicationinsightsApplication#hana_secret_name}
    */
    readonly hanaSecretName?: string;
    /**
    * HANA DB SID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#hanasid ApplicationinsightsApplication#hanasid}
    */
    readonly hanasid?: string;
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporter | cdktn.IResolvable | undefined);
    private _agreeToInstallHanadbClient?;
    get agreeToInstallHanadbClient(): boolean | cdktn.IResolvable;
    set agreeToInstallHanadbClient(value: boolean | cdktn.IResolvable);
    resetAgreeToInstallHanadbClient(): void;
    get agreeToInstallHanadbClientInput(): boolean | cdktn.IResolvable | undefined;
    private _hanaPort?;
    get hanaPort(): string;
    set hanaPort(value: string);
    resetHanaPort(): void;
    get hanaPortInput(): string | undefined;
    private _hanaSecretName?;
    get hanaSecretName(): string;
    set hanaSecretName(value: string);
    resetHanaSecretName(): void;
    get hanaSecretNameInput(): string | undefined;
    private _hanasid?;
    get hanasid(): string;
    set hanasid(value: string);
    resetHanasid(): void;
    get hanasidInput(): string | undefined;
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporter {
    /**
    * Java agent host port
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#host_port ApplicationinsightsApplication#host_port}
    */
    readonly hostPort?: string;
    /**
    * JMX service URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#jmxurl ApplicationinsightsApplication#jmxurl}
    */
    readonly jmxurl?: string;
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporter | cdktn.IResolvable | undefined);
    private _hostPort?;
    get hostPort(): string;
    set hostPort(value: string);
    resetHostPort(): void;
    get hostPortInput(): string | undefined;
    private _jmxurl?;
    get jmxurl(): string;
    set jmxurl(value: string);
    resetJmxurl(): void;
    get jmxurlInput(): string | undefined;
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs {
    /**
    * The type of encoding of the logs to be monitored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#encoding ApplicationinsightsApplication#encoding}
    */
    readonly encoding?: string;
    /**
    * The CloudWatch log group name to be associated to the monitored log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_group_name ApplicationinsightsApplication#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The path of the logs to be monitored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_path ApplicationinsightsApplication#log_path}
    */
    readonly logPath?: string;
    /**
    * The log type decides the log patterns against which Application Insights analyzes the log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_type ApplicationinsightsApplication#log_type}
    */
    readonly logType?: string;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set ApplicationinsightsApplication#pattern_set}
    */
    readonly patternSet?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs | cdktn.IResolvable | undefined);
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _logPath?;
    get logPath(): string;
    set logPath(value: string);
    resetLogPath(): void;
    get logPathInput(): string | undefined;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    resetLogType(): void;
    get logTypeInput(): string | undefined;
    private _patternSet?;
    get patternSet(): string;
    set patternSet(value: string);
    resetPatternSet(): void;
    get patternSetInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter {
    /**
    * SAP instance numbers for ASCS, ERS, and App Servers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#instance_numbers ApplicationinsightsApplication#instance_numbers}
    */
    readonly instanceNumbers?: string[];
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
    /**
    * SAP NetWeaver SID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sapsid ApplicationinsightsApplication#sapsid}
    */
    readonly sapsid?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | cdktn.IResolvable | undefined);
    private _instanceNumbers?;
    get instanceNumbers(): string[];
    set instanceNumbers(value: string[]);
    resetInstanceNumbers(): void;
    get instanceNumbersInput(): string[] | undefined;
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
    private _sapsid?;
    get sapsid(): string;
    set sapsid(value: string);
    resetSapsid(): void;
    get sapsidInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics {
    /**
    * The name of the metric to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metric_name ApplicationinsightsApplication#alarm_metric_name}
    */
    readonly alarmMetricName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetricsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetricsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable | undefined);
    private _alarmMetricName?;
    get alarmMetricName(): string;
    set alarmMetricName(value: string);
    resetAlarmMetricName(): void;
    get alarmMetricNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetricsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses {
    /**
    * A list of metrics to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metrics ApplicationinsightsApplication#alarm_metrics}
    */
    readonly alarmMetrics?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable;
    /**
    * The name of the process to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#process_name ApplicationinsightsApplication#process_name}
    */
    readonly processName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses | cdktn.IResolvable | undefined);
    private _alarmMetrics;
    get alarmMetrics(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetricsList;
    putAlarmMetrics(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable): void;
    resetAlarmMetrics(): void;
    get alarmMetricsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesAlarmMetrics[] | undefined;
    private _processName?;
    get processName(): string;
    set processName(value: string);
    resetProcessName(): void;
    get processNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter {
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
    /**
    * Secret name which managers SQL exporter connection. e.g. {"data_source_name": "sqlserver://<USERNAME>:<PASSWORD>@localhost:1433"}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sql_secret_name ApplicationinsightsApplication#sql_secret_name}
    */
    readonly sqlSecretName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | cdktn.IResolvable | undefined);
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
    private _sqlSecretName?;
    get sqlSecretName(): string;
    set sqlSecretName(value: string);
    resetSqlSecretName(): void;
    get sqlSecretNameInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents {
    /**
    * The levels of event to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#event_levels ApplicationinsightsApplication#event_levels}
    */
    readonly eventLevels?: string[];
    /**
    * The type of Windows Events to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#event_name ApplicationinsightsApplication#event_name}
    */
    readonly eventName?: string;
    /**
    * The CloudWatch log group name to be associated to the monitored log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_group_name ApplicationinsightsApplication#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set ApplicationinsightsApplication#pattern_set}
    */
    readonly patternSet?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEventsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEventsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents | cdktn.IResolvable | undefined);
    private _eventLevels?;
    get eventLevels(): string[];
    set eventLevels(value: string[]);
    resetEventLevels(): void;
    get eventLevelsInput(): string[] | undefined;
    private _eventName?;
    get eventName(): string;
    set eventName(value: string);
    resetEventName(): void;
    get eventNameInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _patternSet?;
    get patternSet(): string;
    set patternSet(value: string);
    resetPatternSet(): void;
    get patternSetInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEventsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEventsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetails {
    /**
    * A list of metrics to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metrics ApplicationinsightsApplication#alarm_metrics}
    */
    readonly alarmMetrics?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable;
    /**
    * A list of alarms to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarms ApplicationinsightsApplication#alarms}
    */
    readonly alarms?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms[] | cdktn.IResolvable;
    /**
    * The HA cluster Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#ha_cluster_prometheus_exporter ApplicationinsightsApplication#ha_cluster_prometheus_exporter}
    */
    readonly haClusterPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter;
    /**
    * The HANA DB Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#hana_prometheus_exporter ApplicationinsightsApplication#hana_prometheus_exporter}
    */
    readonly hanaPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporter;
    /**
    * The JMX Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#jmx_prometheus_exporter ApplicationinsightsApplication#jmx_prometheus_exporter}
    */
    readonly jmxPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporter;
    /**
    * A list of logs to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#logs ApplicationinsightsApplication#logs}
    */
    readonly logs?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs[] | cdktn.IResolvable;
    /**
    * The NetWeaver Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#net_weaver_prometheus_exporter ApplicationinsightsApplication#net_weaver_prometheus_exporter}
    */
    readonly netWeaverPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter;
    /**
    * A list of processes to monitor for the component. Only Windows EC2 instances can have a processes section.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#processes ApplicationinsightsApplication#processes}
    */
    readonly processes?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses[] | cdktn.IResolvable;
    /**
    * The SQL Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sql_server_prometheus_exporter ApplicationinsightsApplication#sql_server_prometheus_exporter}
    */
    readonly sqlServerPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter;
    /**
    * A list of Windows Events to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#windows_events ApplicationinsightsApplication#windows_events}
    */
    readonly windowsEvents?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents[] | cdktn.IResolvable;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetails | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetails | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetails | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetails | cdktn.IResolvable | undefined);
    private _alarmMetrics;
    get alarmMetrics(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetricsList;
    putAlarmMetrics(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable): void;
    resetAlarmMetrics(): void;
    get alarmMetricsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmMetrics[] | undefined;
    private _alarms;
    get alarms(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarmsList;
    putAlarms(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms[] | cdktn.IResolvable): void;
    resetAlarms(): void;
    get alarmsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsAlarms[] | undefined;
    private _haClusterPrometheusExporter;
    get haClusterPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporterOutputReference;
    putHaClusterPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter): void;
    resetHaClusterPrometheusExporter(): void;
    get haClusterPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | undefined;
    private _hanaPrometheusExporter;
    get hanaPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporterOutputReference;
    putHanaPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporter): void;
    resetHanaPrometheusExporter(): void;
    get hanaPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsHanaPrometheusExporter | undefined;
    private _jmxPrometheusExporter;
    get jmxPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporterOutputReference;
    putJmxPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporter): void;
    resetJmxPrometheusExporter(): void;
    get jmxPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsJmxPrometheusExporter | undefined;
    private _logs;
    get logs(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogsList;
    putLogs(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs[] | cdktn.IResolvable): void;
    resetLogs(): void;
    get logsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsLogs[] | undefined;
    private _netWeaverPrometheusExporter;
    get netWeaverPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporterOutputReference;
    putNetWeaverPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter): void;
    resetNetWeaverPrometheusExporter(): void;
    get netWeaverPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | undefined;
    private _processes;
    get processes(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcessesList;
    putProcesses(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses[] | cdktn.IResolvable): void;
    resetProcesses(): void;
    get processesInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsProcesses[] | undefined;
    private _sqlServerPrometheusExporter;
    get sqlServerPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporterOutputReference;
    putSqlServerPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter): void;
    resetSqlServerPrometheusExporter(): void;
    get sqlServerPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | undefined;
    private _windowsEvents;
    get windowsEvents(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEventsList;
    putWindowsEvents(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents[] | cdktn.IResolvable): void;
    resetWindowsEvents(): void;
    get windowsEventsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsWindowsEvents[] | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics {
    /**
    * The name of the metric to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metric_name ApplicationinsightsApplication#alarm_metric_name}
    */
    readonly alarmMetricName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics | cdktn.IResolvable | undefined);
    private _alarmMetricName?;
    get alarmMetricName(): string;
    set alarmMetricName(value: string);
    resetAlarmMetricName(): void;
    get alarmMetricNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs {
    /**
    * The type of encoding of the logs to be monitored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#encoding ApplicationinsightsApplication#encoding}
    */
    readonly encoding?: string;
    /**
    * The CloudWatch log group name to be associated to the monitored log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_group_name ApplicationinsightsApplication#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The path of the logs to be monitored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_path ApplicationinsightsApplication#log_path}
    */
    readonly logPath?: string;
    /**
    * The log type decides the log patterns against which Application Insights analyzes the log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_type ApplicationinsightsApplication#log_type}
    */
    readonly logType?: string;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set ApplicationinsightsApplication#pattern_set}
    */
    readonly patternSet?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs | cdktn.IResolvable | undefined);
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _logPath?;
    get logPath(): string;
    set logPath(value: string);
    resetLogPath(): void;
    get logPathInput(): string | undefined;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    resetLogType(): void;
    get logTypeInput(): string | undefined;
    private _patternSet?;
    get patternSet(): string;
    set patternSet(value: string);
    resetPatternSet(): void;
    get patternSetInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics {
    /**
    * The name of the metric to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metric_name ApplicationinsightsApplication#alarm_metric_name}
    */
    readonly alarmMetricName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable | undefined);
    private _alarmMetricName?;
    get alarmMetricName(): string;
    set alarmMetricName(value: string);
    resetAlarmMetricName(): void;
    get alarmMetricNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses {
    /**
    * A list of metrics to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metrics ApplicationinsightsApplication#alarm_metrics}
    */
    readonly alarmMetrics?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable;
    /**
    * The name of the process to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#process_name ApplicationinsightsApplication#process_name}
    */
    readonly processName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses | cdktn.IResolvable | undefined);
    private _alarmMetrics;
    get alarmMetrics(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsList;
    putAlarmMetrics(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable): void;
    resetAlarmMetrics(): void;
    get alarmMetricsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics[] | undefined;
    private _processName?;
    get processName(): string;
    set processName(value: string);
    resetProcessName(): void;
    get processNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents {
    /**
    * The levels of event to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#event_levels ApplicationinsightsApplication#event_levels}
    */
    readonly eventLevels?: string[];
    /**
    * The type of Windows Events to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#event_name ApplicationinsightsApplication#event_name}
    */
    readonly eventName?: string;
    /**
    * The CloudWatch log group name to be associated to the monitored log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_group_name ApplicationinsightsApplication#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set ApplicationinsightsApplication#pattern_set}
    */
    readonly patternSet?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents | cdktn.IResolvable | undefined);
    private _eventLevels?;
    get eventLevels(): string[];
    set eventLevels(value: string[]);
    resetEventLevels(): void;
    get eventLevelsInput(): string[] | undefined;
    private _eventName?;
    get eventName(): string;
    set eventName(value: string);
    resetEventName(): void;
    get eventNameInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _patternSet?;
    get patternSet(): string;
    set patternSet(value: string);
    resetPatternSet(): void;
    get patternSetInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails {
    /**
    * A list of metrics to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metrics ApplicationinsightsApplication#alarm_metrics}
    */
    readonly alarmMetrics?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable;
    /**
    * A list of logs to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#logs ApplicationinsightsApplication#logs}
    */
    readonly logs?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs[] | cdktn.IResolvable;
    /**
    * A list of processes to monitor for the component. Only Windows EC2 instances can have a processes section.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#processes ApplicationinsightsApplication#processes}
    */
    readonly processes?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses[] | cdktn.IResolvable;
    /**
    * A list of Windows Events to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#windows_events ApplicationinsightsApplication#windows_events}
    */
    readonly windowsEvents?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents[] | cdktn.IResolvable;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | cdktn.IResolvable | undefined);
    private _alarmMetrics;
    get alarmMetrics(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsList;
    putAlarmMetrics(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable): void;
    resetAlarmMetrics(): void;
    get alarmMetricsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics[] | undefined;
    private _logs;
    get logs(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsList;
    putLogs(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs[] | cdktn.IResolvable): void;
    resetLogs(): void;
    get logsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs[] | undefined;
    private _processes;
    get processes(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesList;
    putProcesses(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses[] | cdktn.IResolvable): void;
    resetProcesses(): void;
    get processesInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses[] | undefined;
    private _windowsEvents;
    get windowsEvents(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsList;
    putWindowsEvents(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents[] | cdktn.IResolvable): void;
    resetWindowsEvents(): void;
    get windowsEventsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents[] | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations {
    /**
    * The configuration settings of sub components.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sub_component_configuration_details ApplicationinsightsApplication#sub_component_configuration_details}
    */
    readonly subComponentConfigurationDetails?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails;
    /**
    * The sub component type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sub_component_type ApplicationinsightsApplication#sub_component_type}
    */
    readonly subComponentType?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations | cdktn.IResolvable | undefined);
    private _subComponentConfigurationDetails;
    get subComponentConfigurationDetails(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsOutputReference;
    putSubComponentConfigurationDetails(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails): void;
    resetSubComponentConfigurationDetails(): void;
    get subComponentConfigurationDetailsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | undefined;
    private _subComponentType?;
    get subComponentType(): string;
    set subComponentType(value: string);
    resetSubComponentType(): void;
    get subComponentTypeInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfiguration {
    /**
    * The configuration settings
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#configuration_details ApplicationinsightsApplication#configuration_details}
    */
    readonly configurationDetails?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetails;
    /**
    * Sub component configurations of the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sub_component_type_configurations ApplicationinsightsApplication#sub_component_type_configurations}
    */
    readonly subComponentTypeConfigurations?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations[] | cdktn.IResolvable;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfiguration | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfiguration | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfiguration | cdktn.IResolvable | undefined);
    private _configurationDetails;
    get configurationDetails(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetailsOutputReference;
    putConfigurationDetails(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetails): void;
    resetConfigurationDetails(): void;
    get configurationDetailsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationConfigurationDetails | undefined;
    private _subComponentTypeConfigurations;
    get subComponentTypeConfigurations(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurationsList;
    putSubComponentTypeConfigurations(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations[] | cdktn.IResolvable): void;
    resetSubComponentTypeConfigurations(): void;
    get subComponentTypeConfigurationsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationSubComponentTypeConfigurations[] | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics {
    /**
    * The name of the metric to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metric_name ApplicationinsightsApplication#alarm_metric_name}
    */
    readonly alarmMetricName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetricsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetricsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics | cdktn.IResolvable | undefined);
    private _alarmMetricName?;
    get alarmMetricName(): string;
    set alarmMetricName(value: string);
    resetAlarmMetricName(): void;
    get alarmMetricNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetricsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms {
    /**
    * The name of the CloudWatch alarm to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_name ApplicationinsightsApplication#alarm_name}
    */
    readonly alarmName?: string;
    /**
    * Indicates the degree of outage when the alarm goes off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#severity ApplicationinsightsApplication#severity}
    */
    readonly severity?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms | cdktn.IResolvable | undefined);
    private _alarmName?;
    get alarmName(): string;
    set alarmName(value: string);
    resetAlarmName(): void;
    get alarmNameInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter {
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | cdktn.IResolvable | undefined);
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporter {
    /**
    * A flag which indicates agreeing to install SAP HANA DB client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#agree_to_install_hanadb_client ApplicationinsightsApplication#agree_to_install_hanadb_client}
    */
    readonly agreeToInstallHanadbClient?: boolean | cdktn.IResolvable;
    /**
    * The HANA DB port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#hana_port ApplicationinsightsApplication#hana_port}
    */
    readonly hanaPort?: string;
    /**
    * The secret name which manages the HANA DB credentials e.g. {
    *   "username": "<>",
    *   "password": "<>"
    * }.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#hana_secret_name ApplicationinsightsApplication#hana_secret_name}
    */
    readonly hanaSecretName?: string;
    /**
    * HANA DB SID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#hanasid ApplicationinsightsApplication#hanasid}
    */
    readonly hanasid?: string;
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporter | cdktn.IResolvable | undefined);
    private _agreeToInstallHanadbClient?;
    get agreeToInstallHanadbClient(): boolean | cdktn.IResolvable;
    set agreeToInstallHanadbClient(value: boolean | cdktn.IResolvable);
    resetAgreeToInstallHanadbClient(): void;
    get agreeToInstallHanadbClientInput(): boolean | cdktn.IResolvable | undefined;
    private _hanaPort?;
    get hanaPort(): string;
    set hanaPort(value: string);
    resetHanaPort(): void;
    get hanaPortInput(): string | undefined;
    private _hanaSecretName?;
    get hanaSecretName(): string;
    set hanaSecretName(value: string);
    resetHanaSecretName(): void;
    get hanaSecretNameInput(): string | undefined;
    private _hanasid?;
    get hanasid(): string;
    set hanasid(value: string);
    resetHanasid(): void;
    get hanasidInput(): string | undefined;
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporter {
    /**
    * Java agent host port
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#host_port ApplicationinsightsApplication#host_port}
    */
    readonly hostPort?: string;
    /**
    * JMX service URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#jmxurl ApplicationinsightsApplication#jmxurl}
    */
    readonly jmxurl?: string;
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporter | cdktn.IResolvable | undefined);
    private _hostPort?;
    get hostPort(): string;
    set hostPort(value: string);
    resetHostPort(): void;
    get hostPortInput(): string | undefined;
    private _jmxurl?;
    get jmxurl(): string;
    set jmxurl(value: string);
    resetJmxurl(): void;
    get jmxurlInput(): string | undefined;
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs {
    /**
    * The type of encoding of the logs to be monitored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#encoding ApplicationinsightsApplication#encoding}
    */
    readonly encoding?: string;
    /**
    * The CloudWatch log group name to be associated to the monitored log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_group_name ApplicationinsightsApplication#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The path of the logs to be monitored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_path ApplicationinsightsApplication#log_path}
    */
    readonly logPath?: string;
    /**
    * The log type decides the log patterns against which Application Insights analyzes the log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_type ApplicationinsightsApplication#log_type}
    */
    readonly logType?: string;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set ApplicationinsightsApplication#pattern_set}
    */
    readonly patternSet?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs | cdktn.IResolvable | undefined);
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _logPath?;
    get logPath(): string;
    set logPath(value: string);
    resetLogPath(): void;
    get logPathInput(): string | undefined;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    resetLogType(): void;
    get logTypeInput(): string | undefined;
    private _patternSet?;
    get patternSet(): string;
    set patternSet(value: string);
    resetPatternSet(): void;
    get patternSetInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter {
    /**
    * SAP instance numbers for ASCS, ERS, and App Servers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#instance_numbers ApplicationinsightsApplication#instance_numbers}
    */
    readonly instanceNumbers?: string[];
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
    /**
    * SAP NetWeaver SID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sapsid ApplicationinsightsApplication#sapsid}
    */
    readonly sapsid?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | cdktn.IResolvable | undefined);
    private _instanceNumbers?;
    get instanceNumbers(): string[];
    set instanceNumbers(value: string[]);
    resetInstanceNumbers(): void;
    get instanceNumbersInput(): string[] | undefined;
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
    private _sapsid?;
    get sapsid(): string;
    set sapsid(value: string);
    resetSapsid(): void;
    get sapsidInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics {
    /**
    * The name of the metric to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metric_name ApplicationinsightsApplication#alarm_metric_name}
    */
    readonly alarmMetricName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetricsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetricsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable | undefined);
    private _alarmMetricName?;
    get alarmMetricName(): string;
    set alarmMetricName(value: string);
    resetAlarmMetricName(): void;
    get alarmMetricNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetricsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses {
    /**
    * A list of metrics to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metrics ApplicationinsightsApplication#alarm_metrics}
    */
    readonly alarmMetrics?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable;
    /**
    * The name of the process to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#process_name ApplicationinsightsApplication#process_name}
    */
    readonly processName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses | cdktn.IResolvable | undefined);
    private _alarmMetrics;
    get alarmMetrics(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetricsList;
    putAlarmMetrics(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable): void;
    resetAlarmMetrics(): void;
    get alarmMetricsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesAlarmMetrics[] | undefined;
    private _processName?;
    get processName(): string;
    set processName(value: string);
    resetProcessName(): void;
    get processNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter {
    /**
    * Prometheus exporter port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#prometheus_port ApplicationinsightsApplication#prometheus_port}
    */
    readonly prometheusPort?: string;
    /**
    * Secret name which managers SQL exporter connection. e.g. {"data_source_name": "sqlserver://<USERNAME>:<PASSWORD>@localhost:1433"}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sql_secret_name ApplicationinsightsApplication#sql_secret_name}
    */
    readonly sqlSecretName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporterToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporterToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | cdktn.IResolvable | undefined);
    private _prometheusPort?;
    get prometheusPort(): string;
    set prometheusPort(value: string);
    resetPrometheusPort(): void;
    get prometheusPortInput(): string | undefined;
    private _sqlSecretName?;
    get sqlSecretName(): string;
    set sqlSecretName(value: string);
    resetSqlSecretName(): void;
    get sqlSecretNameInput(): string | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents {
    /**
    * The levels of event to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#event_levels ApplicationinsightsApplication#event_levels}
    */
    readonly eventLevels?: string[];
    /**
    * The type of Windows Events to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#event_name ApplicationinsightsApplication#event_name}
    */
    readonly eventName?: string;
    /**
    * The CloudWatch log group name to be associated to the monitored log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_group_name ApplicationinsightsApplication#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set ApplicationinsightsApplication#pattern_set}
    */
    readonly patternSet?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEventsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEventsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents | cdktn.IResolvable | undefined);
    private _eventLevels?;
    get eventLevels(): string[];
    set eventLevels(value: string[]);
    resetEventLevels(): void;
    get eventLevelsInput(): string[] | undefined;
    private _eventName?;
    get eventName(): string;
    set eventName(value: string);
    resetEventName(): void;
    get eventNameInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _patternSet?;
    get patternSet(): string;
    set patternSet(value: string);
    resetPatternSet(): void;
    get patternSetInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEventsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEventsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetails {
    /**
    * A list of metrics to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metrics ApplicationinsightsApplication#alarm_metrics}
    */
    readonly alarmMetrics?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable;
    /**
    * A list of alarms to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarms ApplicationinsightsApplication#alarms}
    */
    readonly alarms?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms[] | cdktn.IResolvable;
    /**
    * The HA cluster Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#ha_cluster_prometheus_exporter ApplicationinsightsApplication#ha_cluster_prometheus_exporter}
    */
    readonly haClusterPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter;
    /**
    * The HANA DB Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#hana_prometheus_exporter ApplicationinsightsApplication#hana_prometheus_exporter}
    */
    readonly hanaPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporter;
    /**
    * The JMX Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#jmx_prometheus_exporter ApplicationinsightsApplication#jmx_prometheus_exporter}
    */
    readonly jmxPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporter;
    /**
    * A list of logs to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#logs ApplicationinsightsApplication#logs}
    */
    readonly logs?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs[] | cdktn.IResolvable;
    /**
    * The NetWeaver Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#net_weaver_prometheus_exporter ApplicationinsightsApplication#net_weaver_prometheus_exporter}
    */
    readonly netWeaverPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter;
    /**
    * A list of processes to monitor for the component. Only Windows EC2 instances can have a processes section.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#processes ApplicationinsightsApplication#processes}
    */
    readonly processes?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses[] | cdktn.IResolvable;
    /**
    * The SQL Prometheus Exporter settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sql_server_prometheus_exporter ApplicationinsightsApplication#sql_server_prometheus_exporter}
    */
    readonly sqlServerPrometheusExporter?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter;
    /**
    * A list of Windows Events to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#windows_events ApplicationinsightsApplication#windows_events}
    */
    readonly windowsEvents?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents[] | cdktn.IResolvable;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetails | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetails | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetails | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetails | cdktn.IResolvable | undefined);
    private _alarmMetrics;
    get alarmMetrics(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetricsList;
    putAlarmMetrics(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable): void;
    resetAlarmMetrics(): void;
    get alarmMetricsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmMetrics[] | undefined;
    private _alarms;
    get alarms(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarmsList;
    putAlarms(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms[] | cdktn.IResolvable): void;
    resetAlarms(): void;
    get alarmsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsAlarms[] | undefined;
    private _haClusterPrometheusExporter;
    get haClusterPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporterOutputReference;
    putHaClusterPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter): void;
    resetHaClusterPrometheusExporter(): void;
    get haClusterPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHaClusterPrometheusExporter | undefined;
    private _hanaPrometheusExporter;
    get hanaPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporterOutputReference;
    putHanaPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporter): void;
    resetHanaPrometheusExporter(): void;
    get hanaPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsHanaPrometheusExporter | undefined;
    private _jmxPrometheusExporter;
    get jmxPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporterOutputReference;
    putJmxPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporter): void;
    resetJmxPrometheusExporter(): void;
    get jmxPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsJmxPrometheusExporter | undefined;
    private _logs;
    get logs(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogsList;
    putLogs(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs[] | cdktn.IResolvable): void;
    resetLogs(): void;
    get logsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsLogs[] | undefined;
    private _netWeaverPrometheusExporter;
    get netWeaverPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporterOutputReference;
    putNetWeaverPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter): void;
    resetNetWeaverPrometheusExporter(): void;
    get netWeaverPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsNetWeaverPrometheusExporter | undefined;
    private _processes;
    get processes(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcessesList;
    putProcesses(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses[] | cdktn.IResolvable): void;
    resetProcesses(): void;
    get processesInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsProcesses[] | undefined;
    private _sqlServerPrometheusExporter;
    get sqlServerPrometheusExporter(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporterOutputReference;
    putSqlServerPrometheusExporter(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter): void;
    resetSqlServerPrometheusExporter(): void;
    get sqlServerPrometheusExporterInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsSqlServerPrometheusExporter | undefined;
    private _windowsEvents;
    get windowsEvents(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEventsList;
    putWindowsEvents(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents[] | cdktn.IResolvable): void;
    resetWindowsEvents(): void;
    get windowsEventsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsWindowsEvents[] | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics {
    /**
    * The name of the metric to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metric_name ApplicationinsightsApplication#alarm_metric_name}
    */
    readonly alarmMetricName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics | cdktn.IResolvable | undefined);
    private _alarmMetricName?;
    get alarmMetricName(): string;
    set alarmMetricName(value: string);
    resetAlarmMetricName(): void;
    get alarmMetricNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs {
    /**
    * The type of encoding of the logs to be monitored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#encoding ApplicationinsightsApplication#encoding}
    */
    readonly encoding?: string;
    /**
    * The CloudWatch log group name to be associated to the monitored log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_group_name ApplicationinsightsApplication#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The path of the logs to be monitored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_path ApplicationinsightsApplication#log_path}
    */
    readonly logPath?: string;
    /**
    * The log type decides the log patterns against which Application Insights analyzes the log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_type ApplicationinsightsApplication#log_type}
    */
    readonly logType?: string;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set ApplicationinsightsApplication#pattern_set}
    */
    readonly patternSet?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs | cdktn.IResolvable | undefined);
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _logPath?;
    get logPath(): string;
    set logPath(value: string);
    resetLogPath(): void;
    get logPathInput(): string | undefined;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    resetLogType(): void;
    get logTypeInput(): string | undefined;
    private _patternSet?;
    get patternSet(): string;
    set patternSet(value: string);
    resetPatternSet(): void;
    get patternSetInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics {
    /**
    * The name of the metric to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metric_name ApplicationinsightsApplication#alarm_metric_name}
    */
    readonly alarmMetricName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics | cdktn.IResolvable | undefined);
    private _alarmMetricName?;
    get alarmMetricName(): string;
    set alarmMetricName(value: string);
    resetAlarmMetricName(): void;
    get alarmMetricNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses {
    /**
    * A list of metrics to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metrics ApplicationinsightsApplication#alarm_metrics}
    */
    readonly alarmMetrics?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable;
    /**
    * The name of the process to be monitored for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#process_name ApplicationinsightsApplication#process_name}
    */
    readonly processName?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses | cdktn.IResolvable | undefined);
    private _alarmMetrics;
    get alarmMetrics(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetricsList;
    putAlarmMetrics(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics[] | cdktn.IResolvable): void;
    resetAlarmMetrics(): void;
    get alarmMetricsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesAlarmMetrics[] | undefined;
    private _processName?;
    get processName(): string;
    set processName(value: string);
    resetProcessName(): void;
    get processNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents {
    /**
    * The levels of event to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#event_levels ApplicationinsightsApplication#event_levels}
    */
    readonly eventLevels?: string[];
    /**
    * The type of Windows Events to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#event_name ApplicationinsightsApplication#event_name}
    */
    readonly eventName?: string;
    /**
    * The CloudWatch log group name to be associated to the monitored log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_group_name ApplicationinsightsApplication#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set ApplicationinsightsApplication#pattern_set}
    */
    readonly patternSet?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents | cdktn.IResolvable | undefined);
    private _eventLevels?;
    get eventLevels(): string[];
    set eventLevels(value: string[]);
    resetEventLevels(): void;
    get eventLevelsInput(): string[] | undefined;
    private _eventName?;
    get eventName(): string;
    set eventName(value: string);
    resetEventName(): void;
    get eventNameInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _patternSet?;
    get patternSet(): string;
    set patternSet(value: string);
    resetPatternSet(): void;
    get patternSetInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails {
    /**
    * A list of metrics to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#alarm_metrics ApplicationinsightsApplication#alarm_metrics}
    */
    readonly alarmMetrics?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable;
    /**
    * A list of logs to monitor for the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#logs ApplicationinsightsApplication#logs}
    */
    readonly logs?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs[] | cdktn.IResolvable;
    /**
    * A list of processes to monitor for the component. Only Windows EC2 instances can have a processes section.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#processes ApplicationinsightsApplication#processes}
    */
    readonly processes?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses[] | cdktn.IResolvable;
    /**
    * A list of Windows Events to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#windows_events ApplicationinsightsApplication#windows_events}
    */
    readonly windowsEvents?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents[] | cdktn.IResolvable;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | cdktn.IResolvable | undefined);
    private _alarmMetrics;
    get alarmMetrics(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetricsList;
    putAlarmMetrics(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics[] | cdktn.IResolvable): void;
    resetAlarmMetrics(): void;
    get alarmMetricsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsAlarmMetrics[] | undefined;
    private _logs;
    get logs(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogsList;
    putLogs(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs[] | cdktn.IResolvable): void;
    resetLogs(): void;
    get logsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsLogs[] | undefined;
    private _processes;
    get processes(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcessesList;
    putProcesses(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses[] | cdktn.IResolvable): void;
    resetProcesses(): void;
    get processesInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsProcesses[] | undefined;
    private _windowsEvents;
    get windowsEvents(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEventsList;
    putWindowsEvents(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents[] | cdktn.IResolvable): void;
    resetWindowsEvents(): void;
    get windowsEventsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsWindowsEvents[] | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations {
    /**
    * The configuration settings of sub components.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sub_component_configuration_details ApplicationinsightsApplication#sub_component_configuration_details}
    */
    readonly subComponentConfigurationDetails?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails;
    /**
    * The sub component type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sub_component_type ApplicationinsightsApplication#sub_component_type}
    */
    readonly subComponentType?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations | cdktn.IResolvable | undefined);
    private _subComponentConfigurationDetails;
    get subComponentConfigurationDetails(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetailsOutputReference;
    putSubComponentConfigurationDetails(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails): void;
    resetSubComponentConfigurationDetails(): void;
    get subComponentConfigurationDetailsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsSubComponentConfigurationDetails | undefined;
    private _subComponentType?;
    get subComponentType(): string;
    set subComponentType(value: string);
    resetSubComponentType(): void;
    get subComponentTypeInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsOutputReference;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfiguration {
    /**
    * The configuration settings
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#configuration_details ApplicationinsightsApplication#configuration_details}
    */
    readonly configurationDetails?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetails;
    /**
    * Sub component configurations of the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#sub_component_type_configurations ApplicationinsightsApplication#sub_component_type_configurations}
    */
    readonly subComponentTypeConfigurations?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations[] | cdktn.IResolvable;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfiguration | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfiguration | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfiguration | cdktn.IResolvable | undefined);
    private _configurationDetails;
    get configurationDetails(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetailsOutputReference;
    putConfigurationDetails(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetails): void;
    resetConfigurationDetails(): void;
    get configurationDetailsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationConfigurationDetails | undefined;
    private _subComponentTypeConfigurations;
    get subComponentTypeConfigurations(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurationsList;
    putSubComponentTypeConfigurations(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations[] | cdktn.IResolvable): void;
    resetSubComponentTypeConfigurations(): void;
    get subComponentTypeConfigurationsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationSubComponentTypeConfigurations[] | undefined;
}
export interface ApplicationinsightsApplicationComponentMonitoringSettings {
    /**
    * The ARN of the compnonent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#component_arn ApplicationinsightsApplication#component_arn}
    */
    readonly componentArn?: string;
    /**
    * The component monitoring configuration mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#component_configuration_mode ApplicationinsightsApplication#component_configuration_mode}
    */
    readonly componentConfigurationMode?: string;
    /**
    * The name of the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#component_name ApplicationinsightsApplication#component_name}
    */
    readonly componentName?: string;
    /**
    * The monitoring configuration of the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#custom_component_configuration ApplicationinsightsApplication#custom_component_configuration}
    */
    readonly customComponentConfiguration?: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfiguration;
    /**
    * The overwritten settings on default component monitoring configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#default_overwrite_component_configuration ApplicationinsightsApplication#default_overwrite_component_configuration}
    */
    readonly defaultOverwriteComponentConfiguration?: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfiguration;
    /**
    * The tier of the application component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#tier ApplicationinsightsApplication#tier}
    */
    readonly tier?: string;
}
export declare function applicationinsightsApplicationComponentMonitoringSettingsToTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettings | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationComponentMonitoringSettingsToHclTerraform(struct?: ApplicationinsightsApplicationComponentMonitoringSettings | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationComponentMonitoringSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationComponentMonitoringSettings | cdktn.IResolvable | undefined);
    private _componentArn?;
    get componentArn(): string;
    set componentArn(value: string);
    resetComponentArn(): void;
    get componentArnInput(): string | undefined;
    private _componentConfigurationMode?;
    get componentConfigurationMode(): string;
    set componentConfigurationMode(value: string);
    resetComponentConfigurationMode(): void;
    get componentConfigurationModeInput(): string | undefined;
    private _componentName?;
    get componentName(): string;
    set componentName(value: string);
    resetComponentName(): void;
    get componentNameInput(): string | undefined;
    private _customComponentConfiguration;
    get customComponentConfiguration(): ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfigurationOutputReference;
    putCustomComponentConfiguration(value: ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfiguration): void;
    resetCustomComponentConfiguration(): void;
    get customComponentConfigurationInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsCustomComponentConfiguration | undefined;
    private _defaultOverwriteComponentConfiguration;
    get defaultOverwriteComponentConfiguration(): ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfigurationOutputReference;
    putDefaultOverwriteComponentConfiguration(value: ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfiguration): void;
    resetDefaultOverwriteComponentConfiguration(): void;
    get defaultOverwriteComponentConfigurationInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettingsDefaultOverwriteComponentConfiguration | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationComponentMonitoringSettingsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationComponentMonitoringSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationComponentMonitoringSettingsOutputReference;
}
export interface ApplicationinsightsApplicationCustomComponents {
    /**
    * The name of the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#component_name ApplicationinsightsApplication#component_name}
    */
    readonly componentName?: string;
    /**
    * The list of resource ARNs that belong to the component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#resource_list ApplicationinsightsApplication#resource_list}
    */
    readonly resourceList?: string[];
}
export declare function applicationinsightsApplicationCustomComponentsToTerraform(struct?: ApplicationinsightsApplicationCustomComponents | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationCustomComponentsToHclTerraform(struct?: ApplicationinsightsApplicationCustomComponents | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationCustomComponentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationCustomComponents | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationCustomComponents | cdktn.IResolvable | undefined);
    private _componentName?;
    get componentName(): string;
    set componentName(value: string);
    resetComponentName(): void;
    get componentNameInput(): string | undefined;
    private _resourceList?;
    get resourceList(): string[];
    set resourceList(value: string[]);
    resetResourceList(): void;
    get resourceListInput(): string[] | undefined;
}
export declare class ApplicationinsightsApplicationCustomComponentsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationCustomComponents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationCustomComponentsOutputReference;
}
export interface ApplicationinsightsApplicationLogPatternSetsLogPatterns {
    /**
    * The log pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern ApplicationinsightsApplication#pattern}
    */
    readonly pattern?: string;
    /**
    * The name of the log pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_name ApplicationinsightsApplication#pattern_name}
    */
    readonly patternName?: string;
    /**
    * Rank of the log pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#rank ApplicationinsightsApplication#rank}
    */
    readonly rank?: number;
}
export declare function applicationinsightsApplicationLogPatternSetsLogPatternsToTerraform(struct?: ApplicationinsightsApplicationLogPatternSetsLogPatterns | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationLogPatternSetsLogPatternsToHclTerraform(struct?: ApplicationinsightsApplicationLogPatternSetsLogPatterns | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationLogPatternSetsLogPatternsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationLogPatternSetsLogPatterns | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationLogPatternSetsLogPatterns | cdktn.IResolvable | undefined);
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _patternName?;
    get patternName(): string;
    set patternName(value: string);
    resetPatternName(): void;
    get patternNameInput(): string | undefined;
    private _rank?;
    get rank(): number;
    set rank(value: number);
    resetRank(): void;
    get rankInput(): number | undefined;
}
export declare class ApplicationinsightsApplicationLogPatternSetsLogPatternsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationLogPatternSetsLogPatterns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationLogPatternSetsLogPatternsOutputReference;
}
export interface ApplicationinsightsApplicationLogPatternSets {
    /**
    * The log patterns of a set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#log_patterns ApplicationinsightsApplication#log_patterns}
    */
    readonly logPatterns?: ApplicationinsightsApplicationLogPatternSetsLogPatterns[] | cdktn.IResolvable;
    /**
    * The name of the log pattern set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#pattern_set_name ApplicationinsightsApplication#pattern_set_name}
    */
    readonly patternSetName?: string;
}
export declare function applicationinsightsApplicationLogPatternSetsToTerraform(struct?: ApplicationinsightsApplicationLogPatternSets | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationLogPatternSetsToHclTerraform(struct?: ApplicationinsightsApplicationLogPatternSets | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationLogPatternSetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationLogPatternSets | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationLogPatternSets | cdktn.IResolvable | undefined);
    private _logPatterns;
    get logPatterns(): ApplicationinsightsApplicationLogPatternSetsLogPatternsList;
    putLogPatterns(value: ApplicationinsightsApplicationLogPatternSetsLogPatterns[] | cdktn.IResolvable): void;
    resetLogPatterns(): void;
    get logPatternsInput(): cdktn.IResolvable | ApplicationinsightsApplicationLogPatternSetsLogPatterns[] | undefined;
    private _patternSetName?;
    get patternSetName(): string;
    set patternSetName(value: string);
    resetPatternSetName(): void;
    get patternSetNameInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationLogPatternSetsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationLogPatternSets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationLogPatternSetsOutputReference;
}
export interface ApplicationinsightsApplicationTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#key ApplicationinsightsApplication#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#value ApplicationinsightsApplication#value}
    */
    readonly value?: string;
}
export declare function applicationinsightsApplicationTagsToTerraform(struct?: ApplicationinsightsApplicationTags | cdktn.IResolvable): any;
export declare function applicationinsightsApplicationTagsToHclTerraform(struct?: ApplicationinsightsApplicationTags | cdktn.IResolvable): any;
export declare class ApplicationinsightsApplicationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationinsightsApplicationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationinsightsApplicationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApplicationinsightsApplicationTagsList extends cdktn.ComplexList {
    internalValue?: ApplicationinsightsApplicationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationinsightsApplicationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application awscc_applicationinsights_application}
*/
export declare class ApplicationinsightsApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_applicationinsights_application";
    /**
    * Generates CDKTN code for importing a ApplicationinsightsApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationinsightsApplication to import
    * @param importFromId The id of the existing ApplicationinsightsApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationinsightsApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationinsights_application awscc_applicationinsights_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationinsightsApplicationConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationinsightsApplicationConfig);
    get applicationArn(): string;
    private _attachMissingPermission?;
    get attachMissingPermission(): boolean | cdktn.IResolvable;
    set attachMissingPermission(value: boolean | cdktn.IResolvable);
    resetAttachMissingPermission(): void;
    get attachMissingPermissionInput(): boolean | cdktn.IResolvable | undefined;
    private _autoConfigurationEnabled?;
    get autoConfigurationEnabled(): boolean | cdktn.IResolvable;
    set autoConfigurationEnabled(value: boolean | cdktn.IResolvable);
    resetAutoConfigurationEnabled(): void;
    get autoConfigurationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _componentMonitoringSettings;
    get componentMonitoringSettings(): ApplicationinsightsApplicationComponentMonitoringSettingsList;
    putComponentMonitoringSettings(value: ApplicationinsightsApplicationComponentMonitoringSettings[] | cdktn.IResolvable): void;
    resetComponentMonitoringSettings(): void;
    get componentMonitoringSettingsInput(): cdktn.IResolvable | ApplicationinsightsApplicationComponentMonitoringSettings[] | undefined;
    private _customComponents;
    get customComponents(): ApplicationinsightsApplicationCustomComponentsList;
    putCustomComponents(value: ApplicationinsightsApplicationCustomComponents[] | cdktn.IResolvable): void;
    resetCustomComponents(): void;
    get customComponentsInput(): cdktn.IResolvable | ApplicationinsightsApplicationCustomComponents[] | undefined;
    private _cweMonitorEnabled?;
    get cweMonitorEnabled(): boolean | cdktn.IResolvable;
    set cweMonitorEnabled(value: boolean | cdktn.IResolvable);
    resetCweMonitorEnabled(): void;
    get cweMonitorEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _groupingType?;
    get groupingType(): string;
    set groupingType(value: string);
    resetGroupingType(): void;
    get groupingTypeInput(): string | undefined;
    get id(): string;
    private _logPatternSets;
    get logPatternSets(): ApplicationinsightsApplicationLogPatternSetsList;
    putLogPatternSets(value: ApplicationinsightsApplicationLogPatternSets[] | cdktn.IResolvable): void;
    resetLogPatternSets(): void;
    get logPatternSetsInput(): cdktn.IResolvable | ApplicationinsightsApplicationLogPatternSets[] | undefined;
    private _opsCenterEnabled?;
    get opsCenterEnabled(): boolean | cdktn.IResolvable;
    set opsCenterEnabled(value: boolean | cdktn.IResolvable);
    resetOpsCenterEnabled(): void;
    get opsCenterEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _opsItemSnsTopicArn?;
    get opsItemSnsTopicArn(): string;
    set opsItemSnsTopicArn(value: string);
    resetOpsItemSnsTopicArn(): void;
    get opsItemSnsTopicArnInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _snsNotificationArn?;
    get snsNotificationArn(): string;
    set snsNotificationArn(value: string);
    resetSnsNotificationArn(): void;
    get snsNotificationArnInput(): string | undefined;
    private _tags;
    get tags(): ApplicationinsightsApplicationTagsList;
    putTags(value: ApplicationinsightsApplicationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApplicationinsightsApplicationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
