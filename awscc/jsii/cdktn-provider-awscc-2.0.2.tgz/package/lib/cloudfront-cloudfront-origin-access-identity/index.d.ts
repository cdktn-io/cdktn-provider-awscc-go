/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontCloudfrontOriginAccessIdentityConfig extends cdktn.TerraformMetaArguments {
    /**
    * The current configuration information for the identity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_cloudfront_origin_access_identity#cloudfront_origin_access_identity_config CloudfrontCloudfrontOriginAccessIdentity#cloudfront_origin_access_identity_config}
    */
    readonly cloudfrontOriginAccessIdentityConfig: CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfig;
}
export interface CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfig {
    /**
    * A comment to describe the origin access identity. The comment cannot be longer than 128 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_cloudfront_origin_access_identity#comment CloudfrontCloudfrontOriginAccessIdentity#comment}
    */
    readonly comment: string;
}
export declare function cloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfigToTerraform(struct?: CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfig | cdktn.IResolvable): any;
export declare function cloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfigToHclTerraform(struct?: CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfig | cdktn.IResolvable): any;
export declare class CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfig | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    get commentInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_cloudfront_origin_access_identity awscc_cloudfront_cloudfront_origin_access_identity}
*/
export declare class CloudfrontCloudfrontOriginAccessIdentity extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_cloudfront_origin_access_identity";
    /**
    * Generates CDKTN code for importing a CloudfrontCloudfrontOriginAccessIdentity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontCloudfrontOriginAccessIdentity to import
    * @param importFromId The id of the existing CloudfrontCloudfrontOriginAccessIdentity that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_cloudfront_origin_access_identity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontCloudfrontOriginAccessIdentity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_cloudfront_origin_access_identity awscc_cloudfront_cloudfront_origin_access_identity} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontCloudfrontOriginAccessIdentityConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontCloudfrontOriginAccessIdentityConfig);
    private _cloudfrontOriginAccessIdentityConfig;
    get cloudfrontOriginAccessIdentityConfig(): CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfigOutputReference;
    putCloudfrontOriginAccessIdentityConfig(value: CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfig): void;
    get cloudfrontOriginAccessIdentityConfigInput(): cdktn.IResolvable | CloudfrontCloudfrontOriginAccessIdentityCloudfrontOriginAccessIdentityConfig | undefined;
    get cloudfrontOriginAccessIdentityId(): string;
    get id(): string;
    get s3CanonicalUserId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
