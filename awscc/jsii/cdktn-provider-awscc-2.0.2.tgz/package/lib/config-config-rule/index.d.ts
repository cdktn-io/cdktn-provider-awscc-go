/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigConfigRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether an AWS resource or CC rule is compliant and provides the number of contributors that affect the compliance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#compliance ConfigConfigRule#compliance}
    */
    readonly compliance?: ConfigConfigRuleCompliance;
    /**
    * A name for the CC rule. If you don't specify a name, CFN generates a unique physical ID and uses that ID for the rule name. For more information, see [Name Type](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-name.html).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#config_rule_name ConfigConfigRule#config_rule_name}
    */
    readonly configRuleName?: string;
    /**
    * The description that you provide for the CC rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#description ConfigConfigRule#description}
    */
    readonly description?: string;
    /**
    * The modes the CC rule can be evaluated in. The valid values are distinct objects. By default, the value is Detective evaluation mode only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#evaluation_modes ConfigConfigRule#evaluation_modes}
    */
    readonly evaluationModes?: ConfigConfigRuleEvaluationModes[] | cdktn.IResolvable;
    /**
    * A string, in JSON format, that is passed to the CC rule Lambda function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#input_parameters ConfigConfigRule#input_parameters}
    */
    readonly inputParameters?: string;
    /**
    * The maximum frequency with which CC runs evaluations for a rule. You can specify a value for ``MaximumExecutionFrequency`` when:
    *   +  You are using an AWS managed rule that is triggered at a periodic frequency.
    *   +  Your custom rule is triggered when CC delivers the configuration snapshot. For more information, see [ConfigSnapshotDeliveryProperties](https://docs.aws.amazon.com/config/latest/APIReference/API_ConfigSnapshotDeliveryProperties.html).
    *
    *   By default, rules with a periodic trigger are evaluated every 24 hours. To change the frequency, specify a valid value for the ``MaximumExecutionFrequency`` parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#maximum_execution_frequency ConfigConfigRule#maximum_execution_frequency}
    */
    readonly maximumExecutionFrequency?: string;
    /**
    * Defines which resources can trigger an evaluation for the rule. The scope can include one or more resource types, a combination of one resource type and one resource ID, or a combination of a tag key and value. Specify a scope to constrain the resources that can trigger an evaluation for the rule. If you do not specify a scope, evaluations are triggered when any resource in the recording group changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#scope ConfigConfigRule#scope}
    */
    readonly scope?: ConfigConfigRuleScope;
    /**
    * Provides the rule owner (```` for managed rules, ``CUSTOM_POLICY`` for Custom Policy rules, and ``CUSTOM_LAMBDA`` for Custom Lambda rules), the rule identifier, and the notifications that cause the function to evaluate your AWS resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#source ConfigConfigRule#source}
    */
    readonly source: ConfigConfigRuleSource;
}
export interface ConfigConfigRuleCompliance {
}
export declare function configConfigRuleComplianceToTerraform(struct?: ConfigConfigRuleCompliance | cdktn.IResolvable): any;
export declare function configConfigRuleComplianceToHclTerraform(struct?: ConfigConfigRuleCompliance | cdktn.IResolvable): any;
export declare class ConfigConfigRuleComplianceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigRuleCompliance | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigRuleCompliance | cdktn.IResolvable | undefined);
    get type(): string;
}
export interface ConfigConfigRuleEvaluationModes {
    /**
    * The mode of an evaluation. The valid values are Detective or Proactive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#mode ConfigConfigRule#mode}
    */
    readonly mode?: string;
}
export declare function configConfigRuleEvaluationModesToTerraform(struct?: ConfigConfigRuleEvaluationModes | cdktn.IResolvable): any;
export declare function configConfigRuleEvaluationModesToHclTerraform(struct?: ConfigConfigRuleEvaluationModes | cdktn.IResolvable): any;
export declare class ConfigConfigRuleEvaluationModesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigConfigRuleEvaluationModes | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigRuleEvaluationModes | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export declare class ConfigConfigRuleEvaluationModesList extends cdktn.ComplexList {
    internalValue?: ConfigConfigRuleEvaluationModes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigConfigRuleEvaluationModesOutputReference;
}
export interface ConfigConfigRuleScope {
    /**
    * The ID of the only AWS resource that you want to trigger an evaluation for the rule. If you specify a resource ID, you must specify one resource type for ``ComplianceResourceTypes``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#compliance_resource_id ConfigConfigRule#compliance_resource_id}
    */
    readonly complianceResourceId?: string;
    /**
    * The resource types of only those AWS resources that you want to trigger an evaluation for the rule. You can only specify one type if you also specify a resource ID for ``ComplianceResourceId``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#compliance_resource_types ConfigConfigRule#compliance_resource_types}
    */
    readonly complianceResourceTypes?: string[];
    /**
    * The tag key that is applied to only those AWS resources that you want to trigger an evaluation for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#tag_key ConfigConfigRule#tag_key}
    */
    readonly tagKey?: string;
    /**
    * The tag value applied to only those AWS resources that you want to trigger an evaluation for the rule. If you specify a value for ``TagValue``, you must also specify a value for ``TagKey``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#tag_value ConfigConfigRule#tag_value}
    */
    readonly tagValue?: string;
}
export declare function configConfigRuleScopeToTerraform(struct?: ConfigConfigRuleScope | cdktn.IResolvable): any;
export declare function configConfigRuleScopeToHclTerraform(struct?: ConfigConfigRuleScope | cdktn.IResolvable): any;
export declare class ConfigConfigRuleScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigRuleScope | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigRuleScope | cdktn.IResolvable | undefined);
    private _complianceResourceId?;
    get complianceResourceId(): string;
    set complianceResourceId(value: string);
    resetComplianceResourceId(): void;
    get complianceResourceIdInput(): string | undefined;
    private _complianceResourceTypes?;
    get complianceResourceTypes(): string[];
    set complianceResourceTypes(value: string[]);
    resetComplianceResourceTypes(): void;
    get complianceResourceTypesInput(): string[] | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface ConfigConfigRuleSourceCustomPolicyDetails {
    /**
    * The boolean expression for enabling debug logging for your CC Custom Policy rule. The default value is ``false``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#enable_debug_log_delivery ConfigConfigRule#enable_debug_log_delivery}
    */
    readonly enableDebugLogDelivery?: boolean | cdktn.IResolvable;
    /**
    * The runtime system for your CC Custom Policy rule. Guard is a policy-as-code language that allows you to write policies that are enforced by CC Custom Policy rules. For more information about Guard, see the [Guard GitHub Repository](https://docs.aws.amazon.com/https://github.com/aws-cloudformation/cloudformation-guard).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#policy_runtime ConfigConfigRule#policy_runtime}
    */
    readonly policyRuntime?: string;
    /**
    * The policy definition containing the logic for your CC Custom Policy rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#policy_text ConfigConfigRule#policy_text}
    */
    readonly policyText?: string;
}
export declare function configConfigRuleSourceCustomPolicyDetailsToTerraform(struct?: ConfigConfigRuleSourceCustomPolicyDetails | cdktn.IResolvable): any;
export declare function configConfigRuleSourceCustomPolicyDetailsToHclTerraform(struct?: ConfigConfigRuleSourceCustomPolicyDetails | cdktn.IResolvable): any;
export declare class ConfigConfigRuleSourceCustomPolicyDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigRuleSourceCustomPolicyDetails | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigRuleSourceCustomPolicyDetails | cdktn.IResolvable | undefined);
    private _enableDebugLogDelivery?;
    get enableDebugLogDelivery(): boolean | cdktn.IResolvable;
    set enableDebugLogDelivery(value: boolean | cdktn.IResolvable);
    resetEnableDebugLogDelivery(): void;
    get enableDebugLogDeliveryInput(): boolean | cdktn.IResolvable | undefined;
    private _policyRuntime?;
    get policyRuntime(): string;
    set policyRuntime(value: string);
    resetPolicyRuntime(): void;
    get policyRuntimeInput(): string | undefined;
    private _policyText?;
    get policyText(): string;
    set policyText(value: string);
    resetPolicyText(): void;
    get policyTextInput(): string | undefined;
}
export interface ConfigConfigRuleSourceSourceDetails {
    /**
    * The source of the event, such as an AWS service, that triggers CC to evaluate your AWS resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#event_source ConfigConfigRule#event_source}
    */
    readonly eventSource?: string;
    /**
    * The frequency at which you want CC to run evaluations for a custom rule with a periodic trigger. If you specify a value for ``MaximumExecutionFrequency``, then ``MessageType`` must use the ``ScheduledNotification`` value.
    *   By default, rules with a periodic trigger are evaluated every 24 hours. To change the frequency, specify a valid value for the ``MaximumExecutionFrequency`` parameter.
    *  Based on the valid value you choose, CC runs evaluations once for each valid value. For example, if you choose ``Three_Hours``, CC runs evaluations once every three hours. In this case, ``Three_Hours`` is the frequency of this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#maximum_execution_frequency ConfigConfigRule#maximum_execution_frequency}
    */
    readonly maximumExecutionFrequency?: string;
    /**
    * The type of notification that triggers CC to run an evaluation for a rule. You can specify the following notification types:
    *   +  ``ConfigurationItemChangeNotification`` - Triggers an evaluation when CC delivers a configuration item as a result of a resource change.
    *   +  ``OversizedConfigurationItemChangeNotification`` - Triggers an evaluation when CC delivers an oversized configuration item. CC may generate this notification type when a resource changes and the notification exceeds the maximum size allowed by Amazon SNS.
    *   +  ``ScheduledNotification`` - Triggers a periodic evaluation at the frequency specified for ``MaximumExecutionFrequency``.
    *   +  ``ConfigurationSnapshotDeliveryCompleted`` - Triggers a periodic evaluation when CC delivers a configuration snapshot.
    *
    *  If you want your custom rule to be triggered by configuration changes, specify two SourceDetail objects, one for ``ConfigurationItemChangeNotification`` and one for ``OversizedConfigurationItemChangeNotification``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#message_type ConfigConfigRule#message_type}
    */
    readonly messageType?: string;
}
export declare function configConfigRuleSourceSourceDetailsToTerraform(struct?: ConfigConfigRuleSourceSourceDetails | cdktn.IResolvable): any;
export declare function configConfigRuleSourceSourceDetailsToHclTerraform(struct?: ConfigConfigRuleSourceSourceDetails | cdktn.IResolvable): any;
export declare class ConfigConfigRuleSourceSourceDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigConfigRuleSourceSourceDetails | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigRuleSourceSourceDetails | cdktn.IResolvable | undefined);
    private _eventSource?;
    get eventSource(): string;
    set eventSource(value: string);
    resetEventSource(): void;
    get eventSourceInput(): string | undefined;
    private _maximumExecutionFrequency?;
    get maximumExecutionFrequency(): string;
    set maximumExecutionFrequency(value: string);
    resetMaximumExecutionFrequency(): void;
    get maximumExecutionFrequencyInput(): string | undefined;
    private _messageType?;
    get messageType(): string;
    set messageType(value: string);
    resetMessageType(): void;
    get messageTypeInput(): string | undefined;
}
export declare class ConfigConfigRuleSourceSourceDetailsList extends cdktn.ComplexList {
    internalValue?: ConfigConfigRuleSourceSourceDetails[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigConfigRuleSourceSourceDetailsOutputReference;
}
export interface ConfigConfigRuleSource {
    /**
    * Provides the runtime system, policy definition, and whether debug logging is enabled. Required when owner is set to ``CUSTOM_POLICY``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#custom_policy_details ConfigConfigRule#custom_policy_details}
    */
    readonly customPolicyDetails?: ConfigConfigRuleSourceCustomPolicyDetails;
    /**
    * Indicates whether AWS or the customer owns and manages the CC rule.
    *  CC Managed Rules are predefined rules owned by AWS. For more information, see [Managed Rules](https://docs.aws.amazon.com/config/latest/developerguide/evaluate-config_use-managed-rules.html) in the *developer guide*.
    *  CC Custom Rules are rules that you can develop either with Guard (``CUSTOM_POLICY``) or LAMlong (``CUSTOM_LAMBDA``). For more information, see [Custom Rules](https://docs.aws.amazon.com/config/latest/developerguide/evaluate-config_develop-rules.html) in the *developer guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#owner ConfigConfigRule#owner}
    */
    readonly owner: string;
    /**
    * Provides the source and the message types that cause CC to evaluate your AWS resources against a rule. It also provides the frequency with which you want CC to run evaluations for the rule if the trigger type is periodic.
    *  If the owner is set to ``CUSTOM_POLICY``, the only acceptable values for the CC rule trigger message type are ``ConfigurationItemChangeNotification`` and ``OversizedConfigurationItemChangeNotification``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#source_details ConfigConfigRule#source_details}
    */
    readonly sourceDetails?: ConfigConfigRuleSourceSourceDetails[] | cdktn.IResolvable;
    /**
    * For CC Managed rules, a predefined identifier from a list. For example, ``IAM_PASSWORD_POLICY`` is a managed rule. To reference a managed rule, see [List of Managed Rules](https://docs.aws.amazon.com/config/latest/developerguide/managed-rules-by-aws-config.html).
    *  For CC Custom Lambda rules, the identifier is the Amazon Resource Name (ARN) of the rule's LAMlong function, such as ``arn:aws:lambda:us-east-2:123456789012:function:custom_rule_name``.
    *  For CC Custom Policy rules, this field will be ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#source_identifier ConfigConfigRule#source_identifier}
    */
    readonly sourceIdentifier?: string;
}
export declare function configConfigRuleSourceToTerraform(struct?: ConfigConfigRuleSource | cdktn.IResolvable): any;
export declare function configConfigRuleSourceToHclTerraform(struct?: ConfigConfigRuleSource | cdktn.IResolvable): any;
export declare class ConfigConfigRuleSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigRuleSource | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigRuleSource | cdktn.IResolvable | undefined);
    private _customPolicyDetails;
    get customPolicyDetails(): ConfigConfigRuleSourceCustomPolicyDetailsOutputReference;
    putCustomPolicyDetails(value: ConfigConfigRuleSourceCustomPolicyDetails): void;
    resetCustomPolicyDetails(): void;
    get customPolicyDetailsInput(): cdktn.IResolvable | ConfigConfigRuleSourceCustomPolicyDetails | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    get ownerInput(): string | undefined;
    private _sourceDetails;
    get sourceDetails(): ConfigConfigRuleSourceSourceDetailsList;
    putSourceDetails(value: ConfigConfigRuleSourceSourceDetails[] | cdktn.IResolvable): void;
    resetSourceDetails(): void;
    get sourceDetailsInput(): cdktn.IResolvable | ConfigConfigRuleSourceSourceDetails[] | undefined;
    private _sourceIdentifier?;
    get sourceIdentifier(): string;
    set sourceIdentifier(value: string);
    resetSourceIdentifier(): void;
    get sourceIdentifierInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule awscc_config_config_rule}
*/
export declare class ConfigConfigRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_config_rule";
    /**
    * Generates CDKTN code for importing a ConfigConfigRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigConfigRule to import
    * @param importFromId The id of the existing ConfigConfigRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigConfigRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_config_rule awscc_config_config_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigConfigRuleConfig
    */
    constructor(scope: Construct, id: string, config: ConfigConfigRuleConfig);
    get arn(): string;
    private _compliance;
    get compliance(): ConfigConfigRuleComplianceOutputReference;
    putCompliance(value: ConfigConfigRuleCompliance): void;
    resetCompliance(): void;
    get complianceInput(): cdktn.IResolvable | ConfigConfigRuleCompliance | undefined;
    get configRuleId(): string;
    private _configRuleName?;
    get configRuleName(): string;
    set configRuleName(value: string);
    resetConfigRuleName(): void;
    get configRuleNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _evaluationModes;
    get evaluationModes(): ConfigConfigRuleEvaluationModesList;
    putEvaluationModes(value: ConfigConfigRuleEvaluationModes[] | cdktn.IResolvable): void;
    resetEvaluationModes(): void;
    get evaluationModesInput(): cdktn.IResolvable | ConfigConfigRuleEvaluationModes[] | undefined;
    get id(): string;
    private _inputParameters?;
    get inputParameters(): string;
    set inputParameters(value: string);
    resetInputParameters(): void;
    get inputParametersInput(): string | undefined;
    private _maximumExecutionFrequency?;
    get maximumExecutionFrequency(): string;
    set maximumExecutionFrequency(value: string);
    resetMaximumExecutionFrequency(): void;
    get maximumExecutionFrequencyInput(): string | undefined;
    private _scope;
    get scope(): ConfigConfigRuleScopeOutputReference;
    putScope(value: ConfigConfigRuleScope): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | ConfigConfigRuleScope | undefined;
    private _source;
    get source(): ConfigConfigRuleSourceOutputReference;
    putSource(value: ConfigConfigRuleSource): void;
    get sourceInput(): cdktn.IResolvable | ConfigConfigRuleSource | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
