/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchDomainAccessGrantForOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the organization domain the grant belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#domain_id CloudwatchDomainAccessGrantForOrganization#domain_id}
    */
    readonly domainId: string;
    /**
    * A name that identifies the access grant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#name CloudwatchDomainAccessGrantForOrganization#name}
    */
    readonly name: string;
    /**
    * The permission granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#permission CloudwatchDomainAccessGrantForOrganization#permission}
    */
    readonly permission: string;
    /**
    * The principal receiving the grant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#principal CloudwatchDomainAccessGrantForOrganization#principal}
    */
    readonly principal: CloudwatchDomainAccessGrantForOrganizationPrincipal;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#tags CloudwatchDomainAccessGrantForOrganization#tags}
    */
    readonly tags?: CloudwatchDomainAccessGrantForOrganizationTags[] | cdktn.IResolvable;
}
export interface CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes {
    /**
    * The attribute name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#key CloudwatchDomainAccessGrantForOrganization#key}
    */
    readonly key?: string;
    /**
    * The attribute value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#value CloudwatchDomainAccessGrantForOrganization#value}
    */
    readonly value?: string;
}
export declare function cloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributesToTerraform(struct?: CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes | cdktn.IResolvable): any;
export declare function cloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributesToHclTerraform(struct?: CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes | cdktn.IResolvable): any;
export declare class CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributesList extends cdktn.ComplexList {
    internalValue?: CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributesOutputReference;
}
export interface CloudwatchDomainAccessGrantForOrganizationPrincipal {
    /**
    * Attribute key-value pairs that select the principals the grant applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#principal_attributes CloudwatchDomainAccessGrantForOrganization#principal_attributes}
    */
    readonly principalAttributes?: CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes[] | cdktn.IResolvable;
    /**
    * The identifier of the principal, such as an IAM role ARN or an Identity Center user ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#principal_id CloudwatchDomainAccessGrantForOrganization#principal_id}
    */
    readonly principalId?: string;
    /**
    * The type of principal the grant is issued to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#principal_type CloudwatchDomainAccessGrantForOrganization#principal_type}
    */
    readonly principalType: string;
}
export declare function cloudwatchDomainAccessGrantForOrganizationPrincipalToTerraform(struct?: CloudwatchDomainAccessGrantForOrganizationPrincipal | cdktn.IResolvable): any;
export declare function cloudwatchDomainAccessGrantForOrganizationPrincipalToHclTerraform(struct?: CloudwatchDomainAccessGrantForOrganizationPrincipal | cdktn.IResolvable): any;
export declare class CloudwatchDomainAccessGrantForOrganizationPrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchDomainAccessGrantForOrganizationPrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainAccessGrantForOrganizationPrincipal | cdktn.IResolvable | undefined);
    private _principalAttributes;
    get principalAttributes(): CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributesList;
    putPrincipalAttributes(value: CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes[] | cdktn.IResolvable): void;
    resetPrincipalAttributes(): void;
    get principalAttributesInput(): cdktn.IResolvable | CloudwatchDomainAccessGrantForOrganizationPrincipalPrincipalAttributes[] | undefined;
    private _principalId?;
    get principalId(): string;
    set principalId(value: string);
    resetPrincipalId(): void;
    get principalIdInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    get principalTypeInput(): string | undefined;
}
export interface CloudwatchDomainAccessGrantForOrganizationTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#key CloudwatchDomainAccessGrantForOrganization#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#value CloudwatchDomainAccessGrantForOrganization#value}
    */
    readonly value?: string;
}
export declare function cloudwatchDomainAccessGrantForOrganizationTagsToTerraform(struct?: CloudwatchDomainAccessGrantForOrganizationTags | cdktn.IResolvable): any;
export declare function cloudwatchDomainAccessGrantForOrganizationTagsToHclTerraform(struct?: CloudwatchDomainAccessGrantForOrganizationTags | cdktn.IResolvable): any;
export declare class CloudwatchDomainAccessGrantForOrganizationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchDomainAccessGrantForOrganizationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainAccessGrantForOrganizationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchDomainAccessGrantForOrganizationTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchDomainAccessGrantForOrganizationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchDomainAccessGrantForOrganizationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization awscc_cloudwatch_domain_access_grant_for_organization}
*/
export declare class CloudwatchDomainAccessGrantForOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_domain_access_grant_for_organization";
    /**
    * Generates CDKTN code for importing a CloudwatchDomainAccessGrantForOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchDomainAccessGrantForOrganization to import
    * @param importFromId The id of the existing CloudwatchDomainAccessGrantForOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchDomainAccessGrantForOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_access_grant_for_organization awscc_cloudwatch_domain_access_grant_for_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchDomainAccessGrantForOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchDomainAccessGrantForOrganizationConfig);
    get arn(): string;
    get createdAt(): string;
    get createdBy(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    get grantId(): string;
    get grantType(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _principal;
    get principal(): CloudwatchDomainAccessGrantForOrganizationPrincipalOutputReference;
    putPrincipal(value: CloudwatchDomainAccessGrantForOrganizationPrincipal): void;
    get principalInput(): cdktn.IResolvable | CloudwatchDomainAccessGrantForOrganizationPrincipal | undefined;
    private _tags;
    get tags(): CloudwatchDomainAccessGrantForOrganizationTagsList;
    putTags(value: CloudwatchDomainAccessGrantForOrganizationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchDomainAccessGrantForOrganizationTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
