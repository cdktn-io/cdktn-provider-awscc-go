/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectDataTableAttributeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#data_table_arn ConnectDataTableAttribute#data_table_arn}
    */
    readonly dataTableArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#description ConnectDataTableAttribute#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#instance_arn ConnectDataTableAttribute#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#name ConnectDataTableAttribute#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#primary ConnectDataTableAttribute#primary}
    */
    readonly primary?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#validation ConnectDataTableAttribute#validation}
    */
    readonly validation?: ConnectDataTableAttributeValidation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#value_type ConnectDataTableAttribute#value_type}
    */
    readonly valueType: string;
}
export interface ConnectDataTableAttributeLockVersion {
}
export declare function connectDataTableAttributeLockVersionToTerraform(struct?: ConnectDataTableAttributeLockVersion): any;
export declare function connectDataTableAttributeLockVersionToHclTerraform(struct?: ConnectDataTableAttributeLockVersion): any;
export declare class ConnectDataTableAttributeLockVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectDataTableAttributeLockVersion | undefined;
    set internalValue(value: ConnectDataTableAttributeLockVersion | undefined);
    get attribute(): string;
    get dataTable(): string;
}
export interface ConnectDataTableAttributeValidationEnum {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#strict ConnectDataTableAttribute#strict}
    */
    readonly strict?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#values ConnectDataTableAttribute#values}
    */
    readonly values?: string[];
}
export declare function connectDataTableAttributeValidationEnumToTerraform(struct?: ConnectDataTableAttributeValidationEnum | cdktn.IResolvable): any;
export declare function connectDataTableAttributeValidationEnumToHclTerraform(struct?: ConnectDataTableAttributeValidationEnum | cdktn.IResolvable): any;
export declare class ConnectDataTableAttributeValidationEnumOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectDataTableAttributeValidationEnum | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectDataTableAttributeValidationEnum | cdktn.IResolvable | undefined);
    private _strict?;
    get strict(): boolean | cdktn.IResolvable;
    set strict(value: boolean | cdktn.IResolvable);
    resetStrict(): void;
    get strictInput(): boolean | cdktn.IResolvable | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface ConnectDataTableAttributeValidation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#enum ConnectDataTableAttribute#enum}
    */
    readonly enum?: ConnectDataTableAttributeValidationEnum;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#exclusive_maximum ConnectDataTableAttribute#exclusive_maximum}
    */
    readonly exclusiveMaximum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#exclusive_minimum ConnectDataTableAttribute#exclusive_minimum}
    */
    readonly exclusiveMinimum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#max_length ConnectDataTableAttribute#max_length}
    */
    readonly maxLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#max_values ConnectDataTableAttribute#max_values}
    */
    readonly maxValues?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#maximum ConnectDataTableAttribute#maximum}
    */
    readonly maximum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#min_length ConnectDataTableAttribute#min_length}
    */
    readonly minLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#min_values ConnectDataTableAttribute#min_values}
    */
    readonly minValues?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#minimum ConnectDataTableAttribute#minimum}
    */
    readonly minimum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#multiple_of ConnectDataTableAttribute#multiple_of}
    */
    readonly multipleOf?: number;
}
export declare function connectDataTableAttributeValidationToTerraform(struct?: ConnectDataTableAttributeValidation | cdktn.IResolvable): any;
export declare function connectDataTableAttributeValidationToHclTerraform(struct?: ConnectDataTableAttributeValidation | cdktn.IResolvable): any;
export declare class ConnectDataTableAttributeValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectDataTableAttributeValidation | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectDataTableAttributeValidation | cdktn.IResolvable | undefined);
    private _enum;
    get enum(): ConnectDataTableAttributeValidationEnumOutputReference;
    putEnum(value: ConnectDataTableAttributeValidationEnum): void;
    resetEnum(): void;
    get enumInput(): cdktn.IResolvable | ConnectDataTableAttributeValidationEnum | undefined;
    private _exclusiveMaximum?;
    get exclusiveMaximum(): number;
    set exclusiveMaximum(value: number);
    resetExclusiveMaximum(): void;
    get exclusiveMaximumInput(): number | undefined;
    private _exclusiveMinimum?;
    get exclusiveMinimum(): number;
    set exclusiveMinimum(value: number);
    resetExclusiveMinimum(): void;
    get exclusiveMinimumInput(): number | undefined;
    private _maxLength?;
    get maxLength(): number;
    set maxLength(value: number);
    resetMaxLength(): void;
    get maxLengthInput(): number | undefined;
    private _maxValues?;
    get maxValues(): number;
    set maxValues(value: number);
    resetMaxValues(): void;
    get maxValuesInput(): number | undefined;
    private _maximum?;
    get maximum(): number;
    set maximum(value: number);
    resetMaximum(): void;
    get maximumInput(): number | undefined;
    private _minLength?;
    get minLength(): number;
    set minLength(value: number);
    resetMinLength(): void;
    get minLengthInput(): number | undefined;
    private _minValues?;
    get minValues(): number;
    set minValues(value: number);
    resetMinValues(): void;
    get minValuesInput(): number | undefined;
    private _minimum?;
    get minimum(): number;
    set minimum(value: number);
    resetMinimum(): void;
    get minimumInput(): number | undefined;
    private _multipleOf?;
    get multipleOf(): number;
    set multipleOf(value: number);
    resetMultipleOf(): void;
    get multipleOfInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute awscc_connect_data_table_attribute}
*/
export declare class ConnectDataTableAttribute extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_data_table_attribute";
    /**
    * Generates CDKTN code for importing a ConnectDataTableAttribute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectDataTableAttribute to import
    * @param importFromId The id of the existing ConnectDataTableAttribute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectDataTableAttribute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_data_table_attribute awscc_connect_data_table_attribute} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectDataTableAttributeConfig
    */
    constructor(scope: Construct, id: string, config: ConnectDataTableAttributeConfig);
    get attributeId(): string;
    private _dataTableArn?;
    get dataTableArn(): string;
    set dataTableArn(value: string);
    get dataTableArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get lastModifiedRegion(): string;
    get lastModifiedTime(): number;
    private _lockVersion;
    get lockVersion(): ConnectDataTableAttributeLockVersionOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primary?;
    get primary(): boolean | cdktn.IResolvable;
    set primary(value: boolean | cdktn.IResolvable);
    resetPrimary(): void;
    get primaryInput(): boolean | cdktn.IResolvable | undefined;
    private _validation;
    get validation(): ConnectDataTableAttributeValidationOutputReference;
    putValidation(value: ConnectDataTableAttributeValidation): void;
    resetValidation(): void;
    get validationInput(): cdktn.IResolvable | ConnectDataTableAttributeValidation | undefined;
    private _valueType?;
    get valueType(): string;
    set valueType(value: string);
    get valueTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
