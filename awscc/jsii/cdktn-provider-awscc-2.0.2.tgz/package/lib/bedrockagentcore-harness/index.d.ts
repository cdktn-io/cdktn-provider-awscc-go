/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreHarnessConfig extends cdktn.TerraformMetaArguments {
    /**
    * The tools that the agent is allowed to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#allowed_tools BedrockagentcoreHarness#allowed_tools}
    */
    readonly allowedTools?: string[];
    /**
    * The inbound authorization configuration for authenticating incoming requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#authorizer_configuration BedrockagentcoreHarness#authorizer_configuration}
    */
    readonly authorizerConfiguration?: BedrockagentcoreHarnessAuthorizerConfiguration;
    /**
    * The compute environment configuration for the harness, including underlying runtime information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#environment BedrockagentcoreHarness#environment}
    */
    readonly environment?: BedrockagentcoreHarnessEnvironment;
    /**
    * The environment artifact for the harness, such as a custom container image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#environment_artifact BedrockagentcoreHarness#environment_artifact}
    */
    readonly environmentArtifact?: BedrockagentcoreHarnessEnvironmentArtifact;
    /**
    * Environment variables to set in the harness runtime environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#environment_variables BedrockagentcoreHarness#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * The ARN of the IAM role that the harness assumes when running.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#execution_role_arn BedrockagentcoreHarness#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * The name of the harness.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#harness_name BedrockagentcoreHarness#harness_name}
    */
    readonly harnessName: string;
    /**
    * The maximum number of iterations the agent loop can execute per invocation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#max_iterations BedrockagentcoreHarness#max_iterations}
    */
    readonly maxIterations?: number;
    /**
    * The maximum number of tokens the agent can generate per iteration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * The AgentCore Memory configuration for persisting conversation context.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#memory BedrockagentcoreHarness#memory}
    */
    readonly memory?: BedrockagentcoreHarnessMemory;
    /**
    * The model configuration for the harness.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#model BedrockagentcoreHarness#model}
    */
    readonly model: BedrockagentcoreHarnessModel;
    /**
    * The skills available to the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#skills BedrockagentcoreHarness#skills}
    */
    readonly skills?: BedrockagentcoreHarnessSkills[] | cdktn.IResolvable;
    /**
    * The system prompt that defines the agent's behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#system_prompt BedrockagentcoreHarness#system_prompt}
    */
    readonly systemPrompt?: BedrockagentcoreHarnessSystemPrompt[] | cdktn.IResolvable;
    /**
    * Tags to apply to the harness resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#tags BedrockagentcoreHarness#tags}
    */
    readonly tags?: BedrockagentcoreHarnessTags[] | cdktn.IResolvable;
    /**
    * The maximum duration in seconds for the agent loop execution per invocation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#timeout_seconds BedrockagentcoreHarness#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * The tools available to the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#tools BedrockagentcoreHarness#tools}
    */
    readonly tools?: BedrockagentcoreHarnessTools[] | cdktn.IResolvable;
    /**
    * The truncation configuration for managing conversation context.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#truncation BedrockagentcoreHarness#truncation}
    */
    readonly truncation?: BedrockagentcoreHarnessTruncation;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#match_value_string BedrockagentcoreHarness#match_value_string}
    */
    readonly matchValueString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#match_value_string_list BedrockagentcoreHarness#match_value_string_list}
    */
    readonly matchValueStringList?: string[];
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined);
    private _matchValueString?;
    get matchValueString(): string;
    set matchValueString(value: string);
    resetMatchValueString(): void;
    get matchValueStringInput(): string | undefined;
    private _matchValueStringList?;
    get matchValueStringList(): string[];
    set matchValueStringList(value: string[]);
    resetMatchValueStringList(): void;
    get matchValueStringListInput(): string[] | undefined;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#claim_match_operator BedrockagentcoreHarness#claim_match_operator}
    */
    readonly claimMatchOperator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#claim_match_value BedrockagentcoreHarness#claim_match_value}
    */
    readonly claimMatchValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined);
    private _claimMatchOperator?;
    get claimMatchOperator(): string;
    set claimMatchOperator(value: string);
    resetClaimMatchOperator(): void;
    get claimMatchOperatorInput(): string | undefined;
    private _claimMatchValue;
    get claimMatchValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference;
    putClaimMatchValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue): void;
    resetClaimMatchValue(): void;
    get claimMatchValueInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | undefined;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#authorizing_claim_match_value BedrockagentcoreHarness#authorizing_claim_match_value}
    */
    readonly authorizingClaimMatchValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#inbound_token_claim_name BedrockagentcoreHarness#inbound_token_claim_name}
    */
    readonly inboundTokenClaimName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#inbound_token_claim_value_type BedrockagentcoreHarness#inbound_token_claim_value_type}
    */
    readonly inboundTokenClaimValueType?: string;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined);
    private _authorizingClaimMatchValue;
    get authorizingClaimMatchValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference;
    putAuthorizingClaimMatchValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue): void;
    resetAuthorizingClaimMatchValue(): void;
    get authorizingClaimMatchValueInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | undefined;
    private _inboundTokenClaimName?;
    get inboundTokenClaimName(): string;
    set inboundTokenClaimName(value: string);
    resetInboundTokenClaimName(): void;
    get inboundTokenClaimNameInput(): string | undefined;
    private _inboundTokenClaimValueType?;
    get inboundTokenClaimValueType(): string;
    set inboundTokenClaimValueType(value: string);
    resetInboundTokenClaimValueType(): void;
    get inboundTokenClaimValueTypeInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#allowed_audience BedrockagentcoreHarness#allowed_audience}
    */
    readonly allowedAudience?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#allowed_clients BedrockagentcoreHarness#allowed_clients}
    */
    readonly allowedClients?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#allowed_scopes BedrockagentcoreHarness#allowed_scopes}
    */
    readonly allowedScopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#custom_claims BedrockagentcoreHarness#custom_claims}
    */
    readonly customClaims?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#discovery_url BedrockagentcoreHarness#discovery_url}
    */
    readonly discoveryUrl?: string;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined);
    private _allowedAudience?;
    get allowedAudience(): string[];
    set allowedAudience(value: string[]);
    resetAllowedAudience(): void;
    get allowedAudienceInput(): string[] | undefined;
    private _allowedClients?;
    get allowedClients(): string[];
    set allowedClients(value: string[]);
    resetAllowedClients(): void;
    get allowedClientsInput(): string[] | undefined;
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
    private _customClaims;
    get customClaims(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList;
    putCustomClaims(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable): void;
    resetCustomClaims(): void;
    get customClaimsInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | undefined;
    private _discoveryUrl?;
    get discoveryUrl(): string;
    set discoveryUrl(value: string);
    resetDiscoveryUrl(): void;
    get discoveryUrlInput(): string | undefined;
}
export interface BedrockagentcoreHarnessAuthorizerConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#custom_jwt_authorizer BedrockagentcoreHarness#custom_jwt_authorizer}
    */
    readonly customJwtAuthorizer?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfiguration | cdktn.IResolvable | undefined);
    private _customJwtAuthorizer;
    get customJwtAuthorizer(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerOutputReference;
    putCustomJwtAuthorizer(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer): void;
    resetCustomJwtAuthorizer(): void;
    get customJwtAuthorizerInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | undefined;
}
export interface BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#mount_path BedrockagentcoreHarness#mount_path}
    */
    readonly mountPath?: string;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorageToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorage | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorageToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorage | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorage | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
}
export interface BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#session_storage BedrockagentcoreHarness#session_storage}
    */
    readonly sessionStorage?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorage;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations | cdktn.IResolvable | undefined);
    private _sessionStorage;
    get sessionStorage(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorageOutputReference;
    putSessionStorage(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorage): void;
    resetSessionStorage(): void;
    get sessionStorageInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsSessionStorage | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#idle_runtime_session_timeout BedrockagentcoreHarness#idle_runtime_session_timeout}
    */
    readonly idleRuntimeSessionTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#max_lifetime BedrockagentcoreHarness#max_lifetime}
    */
    readonly maxLifetime?: number;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfiguration | cdktn.IResolvable | undefined);
    private _idleRuntimeSessionTimeout?;
    get idleRuntimeSessionTimeout(): number;
    set idleRuntimeSessionTimeout(value: number);
    resetIdleRuntimeSessionTimeout(): void;
    get idleRuntimeSessionTimeoutInput(): number | undefined;
    private _maxLifetime?;
    get maxLifetime(): number;
    set maxLifetime(value: number);
    resetMaxLifetime(): void;
    get maxLifetimeInput(): number | undefined;
}
export interface BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#security_groups BedrockagentcoreHarness#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#subnets BedrockagentcoreHarness#subnets}
    */
    readonly subnets?: string[];
}
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | cdktn.IResolvable | undefined);
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
export interface BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#network_mode BedrockagentcoreHarness#network_mode}
    */
    readonly networkMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#network_mode_config BedrockagentcoreHarness#network_mode_config}
    */
    readonly networkModeConfig?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfiguration | cdktn.IResolvable | undefined);
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    resetNetworkMode(): void;
    get networkModeInput(): string | undefined;
    private _networkModeConfig;
    get networkModeConfig(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigOutputReference;
    putNetworkModeConfig(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig): void;
    resetNetworkModeConfig(): void;
    get networkModeConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | undefined;
}
export interface BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#filesystem_configurations BedrockagentcoreHarness#filesystem_configurations}
    */
    readonly filesystemConfigurations?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#lifecycle_configuration BedrockagentcoreHarness#lifecycle_configuration}
    */
    readonly lifecycleConfiguration?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#network_configuration BedrockagentcoreHarness#network_configuration}
    */
    readonly networkConfiguration?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfiguration;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironment | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironment | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironment | cdktn.IResolvable | undefined);
    get agentRuntimeArn(): string;
    get agentRuntimeId(): string;
    get agentRuntimeName(): string;
    private _filesystemConfigurations;
    get filesystemConfigurations(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurationsList;
    putFilesystemConfigurations(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations[] | cdktn.IResolvable): void;
    resetFilesystemConfigurations(): void;
    get filesystemConfigurationsInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentFilesystemConfigurations[] | undefined;
    private _lifecycleConfiguration;
    get lifecycleConfiguration(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfigurationOutputReference;
    putLifecycleConfiguration(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfiguration): void;
    resetLifecycleConfiguration(): void;
    get lifecycleConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentLifecycleConfiguration | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfigurationOutputReference;
    putNetworkConfiguration(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfiguration): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentNetworkConfiguration | undefined;
}
export interface BedrockagentcoreHarnessEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#agent_core_runtime_environment BedrockagentcoreHarness#agent_core_runtime_environment}
    */
    readonly agentCoreRuntimeEnvironment?: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironment;
}
export declare function bedrockagentcoreHarnessEnvironmentToTerraform(struct?: BedrockagentcoreHarnessEnvironment | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentToHclTerraform(struct?: BedrockagentcoreHarnessEnvironment | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironment | cdktn.IResolvable | undefined);
    private _agentCoreRuntimeEnvironment;
    get agentCoreRuntimeEnvironment(): BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironmentOutputReference;
    putAgentCoreRuntimeEnvironment(value: BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironment): void;
    resetAgentCoreRuntimeEnvironment(): void;
    get agentCoreRuntimeEnvironmentInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentCoreRuntimeEnvironment | undefined;
}
export interface BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration {
    /**
    * The ECR URI of the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#container_uri BedrockagentcoreHarness#container_uri}
    */
    readonly containerUri?: string;
}
export declare function bedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | cdktn.IResolvable | undefined);
    private _containerUri?;
    get containerUri(): string;
    set containerUri(value: string);
    resetContainerUri(): void;
    get containerUriInput(): string | undefined;
}
export interface BedrockagentcoreHarnessEnvironmentArtifact {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#container_configuration BedrockagentcoreHarness#container_configuration}
    */
    readonly containerConfiguration?: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration;
}
export declare function bedrockagentcoreHarnessEnvironmentArtifactToTerraform(struct?: BedrockagentcoreHarnessEnvironmentArtifact | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentArtifactToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentArtifact | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentArtifactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessEnvironmentArtifact | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentArtifact | cdktn.IResolvable | undefined);
    private _containerConfiguration;
    get containerConfiguration(): BedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationOutputReference;
    putContainerConfiguration(value: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration): void;
    resetContainerConfiguration(): void;
    get containerConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | undefined;
}
export interface BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#relevance_score BedrockagentcoreHarness#relevance_score}
    */
    readonly relevanceScore?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#strategy_id BedrockagentcoreHarness#strategy_id}
    */
    readonly strategyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#top_k BedrockagentcoreHarness#top_k}
    */
    readonly topK?: number;
}
export declare function bedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfigToTerraform(struct?: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfigToHclTerraform(struct?: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig | cdktn.IResolvable | undefined);
    private _relevanceScore?;
    get relevanceScore(): number;
    set relevanceScore(value: number);
    resetRelevanceScore(): void;
    get relevanceScoreInput(): number | undefined;
    private _strategyId?;
    get strategyId(): string;
    set strategyId(value: string);
    resetStrategyId(): void;
    get strategyIdInput(): string | undefined;
    private _topK?;
    get topK(): number;
    set topK(value: number);
    resetTopK(): void;
    get topKInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfigMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfigOutputReference;
}
export interface BedrockagentcoreHarnessMemoryAgentCoreMemoryConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#actor_id BedrockagentcoreHarness#actor_id}
    */
    readonly actorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#arn BedrockagentcoreHarness#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#messages_count BedrockagentcoreHarness#messages_count}
    */
    readonly messagesCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#retrieval_config BedrockagentcoreHarness#retrieval_config}
    */
    readonly retrievalConfig?: {
        [key: string]: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig;
    } | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationToTerraform(struct?: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessMemoryAgentCoreMemoryConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfiguration | cdktn.IResolvable | undefined);
    private _actorId?;
    get actorId(): string;
    set actorId(value: string);
    resetActorId(): void;
    get actorIdInput(): string | undefined;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _messagesCount?;
    get messagesCount(): number;
    set messagesCount(value: number);
    resetMessagesCount(): void;
    get messagesCountInput(): number | undefined;
    private _retrievalConfig;
    get retrievalConfig(): BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfigMap;
    putRetrievalConfig(value: {
        [key: string]: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig;
    } | cdktn.IResolvable): void;
    resetRetrievalConfig(): void;
    get retrievalConfigInput(): cdktn.IResolvable | {
        [key: string]: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationRetrievalConfig;
    } | undefined;
}
export interface BedrockagentcoreHarnessMemory {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#agent_core_memory_configuration BedrockagentcoreHarness#agent_core_memory_configuration}
    */
    readonly agentCoreMemoryConfiguration?: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfiguration;
}
export declare function bedrockagentcoreHarnessMemoryToTerraform(struct?: BedrockagentcoreHarnessMemory | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessMemoryToHclTerraform(struct?: BedrockagentcoreHarnessMemory | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessMemory | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemory | cdktn.IResolvable | undefined);
    private _agentCoreMemoryConfiguration;
    get agentCoreMemoryConfiguration(): BedrockagentcoreHarnessMemoryAgentCoreMemoryConfigurationOutputReference;
    putAgentCoreMemoryConfiguration(value: BedrockagentcoreHarnessMemoryAgentCoreMemoryConfiguration): void;
    resetAgentCoreMemoryConfiguration(): void;
    get agentCoreMemoryConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessMemoryAgentCoreMemoryConfiguration | undefined;
}
export interface BedrockagentcoreHarnessModelBedrockModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#model_id BedrockagentcoreHarness#model_id}
    */
    readonly modelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#temperature BedrockagentcoreHarness#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#top_p BedrockagentcoreHarness#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreHarnessModelBedrockModelConfigToTerraform(struct?: BedrockagentcoreHarnessModelBedrockModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelBedrockModelConfigToHclTerraform(struct?: BedrockagentcoreHarnessModelBedrockModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelBedrockModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessModelBedrockModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModelBedrockModelConfig | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockagentcoreHarnessModelGeminiModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#api_key_arn BedrockagentcoreHarness#api_key_arn}
    */
    readonly apiKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#model_id BedrockagentcoreHarness#model_id}
    */
    readonly modelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#temperature BedrockagentcoreHarness#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#top_k BedrockagentcoreHarness#top_k}
    */
    readonly topK?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#top_p BedrockagentcoreHarness#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreHarnessModelGeminiModelConfigToTerraform(struct?: BedrockagentcoreHarnessModelGeminiModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelGeminiModelConfigToHclTerraform(struct?: BedrockagentcoreHarnessModelGeminiModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelGeminiModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessModelGeminiModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModelGeminiModelConfig | cdktn.IResolvable | undefined);
    private _apiKeyArn?;
    get apiKeyArn(): string;
    set apiKeyArn(value: string);
    resetApiKeyArn(): void;
    get apiKeyArnInput(): string | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topK?;
    get topK(): number;
    set topK(value: number);
    resetTopK(): void;
    get topKInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockagentcoreHarnessModelOpenAiModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#api_key_arn BedrockagentcoreHarness#api_key_arn}
    */
    readonly apiKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#model_id BedrockagentcoreHarness#model_id}
    */
    readonly modelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#temperature BedrockagentcoreHarness#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#top_p BedrockagentcoreHarness#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreHarnessModelOpenAiModelConfigToTerraform(struct?: BedrockagentcoreHarnessModelOpenAiModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelOpenAiModelConfigToHclTerraform(struct?: BedrockagentcoreHarnessModelOpenAiModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelOpenAiModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessModelOpenAiModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModelOpenAiModelConfig | cdktn.IResolvable | undefined);
    private _apiKeyArn?;
    get apiKeyArn(): string;
    set apiKeyArn(value: string);
    resetApiKeyArn(): void;
    get apiKeyArnInput(): string | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockagentcoreHarnessModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#bedrock_model_config BedrockagentcoreHarness#bedrock_model_config}
    */
    readonly bedrockModelConfig?: BedrockagentcoreHarnessModelBedrockModelConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#gemini_model_config BedrockagentcoreHarness#gemini_model_config}
    */
    readonly geminiModelConfig?: BedrockagentcoreHarnessModelGeminiModelConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#open_ai_model_config BedrockagentcoreHarness#open_ai_model_config}
    */
    readonly openAiModelConfig?: BedrockagentcoreHarnessModelOpenAiModelConfig;
}
export declare function bedrockagentcoreHarnessModelToTerraform(struct?: BedrockagentcoreHarnessModel | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelToHclTerraform(struct?: BedrockagentcoreHarnessModel | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModel | cdktn.IResolvable | undefined);
    private _bedrockModelConfig;
    get bedrockModelConfig(): BedrockagentcoreHarnessModelBedrockModelConfigOutputReference;
    putBedrockModelConfig(value: BedrockagentcoreHarnessModelBedrockModelConfig): void;
    resetBedrockModelConfig(): void;
    get bedrockModelConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessModelBedrockModelConfig | undefined;
    private _geminiModelConfig;
    get geminiModelConfig(): BedrockagentcoreHarnessModelGeminiModelConfigOutputReference;
    putGeminiModelConfig(value: BedrockagentcoreHarnessModelGeminiModelConfig): void;
    resetGeminiModelConfig(): void;
    get geminiModelConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessModelGeminiModelConfig | undefined;
    private _openAiModelConfig;
    get openAiModelConfig(): BedrockagentcoreHarnessModelOpenAiModelConfigOutputReference;
    putOpenAiModelConfig(value: BedrockagentcoreHarnessModelOpenAiModelConfig): void;
    resetOpenAiModelConfig(): void;
    get openAiModelConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessModelOpenAiModelConfig | undefined;
}
export interface BedrockagentcoreHarnessSkills {
    /**
    * The filesystem path to the skill definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#path BedrockagentcoreHarness#path}
    */
    readonly path?: string;
}
export declare function bedrockagentcoreHarnessSkillsToTerraform(struct?: BedrockagentcoreHarnessSkills | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessSkillsToHclTerraform(struct?: BedrockagentcoreHarnessSkills | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessSkillsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessSkills | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessSkills | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessSkillsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessSkills[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessSkillsOutputReference;
}
export interface BedrockagentcoreHarnessSystemPrompt {
    /**
    * The text content of the system prompt block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#text BedrockagentcoreHarness#text}
    */
    readonly text?: string;
}
export declare function bedrockagentcoreHarnessSystemPromptToTerraform(struct?: BedrockagentcoreHarnessSystemPrompt | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessSystemPromptToHclTerraform(struct?: BedrockagentcoreHarnessSystemPrompt | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessSystemPromptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessSystemPrompt | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessSystemPrompt | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessSystemPromptList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessSystemPrompt[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessSystemPromptOutputReference;
}
export interface BedrockagentcoreHarnessTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#key BedrockagentcoreHarness#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#value BedrockagentcoreHarness#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcoreHarnessTagsToTerraform(struct?: BedrockagentcoreHarnessTags | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTagsToHclTerraform(struct?: BedrockagentcoreHarnessTags | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessTagsOutputReference;
}
export interface BedrockagentcoreHarnessToolsConfigAgentCoreBrowser {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#browser_arn BedrockagentcoreHarness#browser_arn}
    */
    readonly browserArn?: string;
}
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreBrowserToTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreBrowser | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreBrowserToHclTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreBrowser | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsConfigAgentCoreBrowserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessToolsConfigAgentCoreBrowser | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolsConfigAgentCoreBrowser | cdktn.IResolvable | undefined);
    private _browserArn?;
    get browserArn(): string;
    set browserArn(value: string);
    resetBrowserArn(): void;
    get browserArnInput(): string | undefined;
}
export interface BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#code_interpreter_arn BedrockagentcoreHarness#code_interpreter_arn}
    */
    readonly codeInterpreterArn?: string;
}
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreterToTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreter | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreterToHclTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreter | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreter | cdktn.IResolvable | undefined);
    private _codeInterpreterArn?;
    get codeInterpreterArn(): string;
    set codeInterpreterArn(value: string);
    resetCodeInterpreterArn(): void;
    get codeInterpreterArnInput(): string | undefined;
}
export interface BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#custom_parameters BedrockagentcoreHarness#custom_parameters}
    */
    readonly customParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#default_return_url BedrockagentcoreHarness#default_return_url}
    */
    readonly defaultReturnUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#grant_type BedrockagentcoreHarness#grant_type}
    */
    readonly grantType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#provider_arn BedrockagentcoreHarness#provider_arn}
    */
    readonly providerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#scopes BedrockagentcoreHarness#scopes}
    */
    readonly scopes?: string[];
}
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauthToTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauth | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauthToHclTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauth | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauth | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauth | cdktn.IResolvable | undefined);
    private _customParameters?;
    get customParameters(): {
        [key: string]: string;
    };
    set customParameters(value: {
        [key: string]: string;
    });
    resetCustomParameters(): void;
    get customParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultReturnUrl?;
    get defaultReturnUrl(): string;
    set defaultReturnUrl(value: string);
    resetDefaultReturnUrl(): void;
    get defaultReturnUrlInput(): string | undefined;
    private _grantType?;
    get grantType(): string;
    set grantType(value: string);
    resetGrantType(): void;
    get grantTypeInput(): string | undefined;
    private _providerArn?;
    get providerArn(): string;
    set providerArn(value: string);
    resetProviderArn(): void;
    get providerArnInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#aws_iam BedrockagentcoreHarness#aws_iam}
    */
    readonly awsIam?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#none BedrockagentcoreHarness#none}
    */
    readonly none?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#oauth BedrockagentcoreHarness#oauth}
    */
    readonly oauth?: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauth;
}
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthToTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuth | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthToHclTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuth | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuth | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuth | cdktn.IResolvable | undefined);
    private _awsIam?;
    get awsIam(): string;
    set awsIam(value: string);
    resetAwsIam(): void;
    get awsIamInput(): string | undefined;
    private _none?;
    get none(): string;
    set none(value: string);
    resetNone(): void;
    get noneInput(): string | undefined;
    private _oauth;
    get oauth(): BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauthOutputReference;
    putOauth(value: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauth): void;
    resetOauth(): void;
    get oauthInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOauth | undefined;
}
export interface BedrockagentcoreHarnessToolsConfigAgentCoreGateway {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#gateway_arn BedrockagentcoreHarness#gateway_arn}
    */
    readonly gatewayArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#outbound_auth BedrockagentcoreHarness#outbound_auth}
    */
    readonly outboundAuth?: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuth;
}
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreGatewayToTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreGateway | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsConfigAgentCoreGatewayToHclTerraform(struct?: BedrockagentcoreHarnessToolsConfigAgentCoreGateway | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessToolsConfigAgentCoreGateway | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolsConfigAgentCoreGateway | cdktn.IResolvable | undefined);
    private _gatewayArn?;
    get gatewayArn(): string;
    set gatewayArn(value: string);
    resetGatewayArn(): void;
    get gatewayArnInput(): string | undefined;
    private _outboundAuth;
    get outboundAuth(): BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuthOutputReference;
    putOutboundAuth(value: BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuth): void;
    resetOutboundAuth(): void;
    get outboundAuthInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutboundAuth | undefined;
}
export interface BedrockagentcoreHarnessToolsConfigInlineFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#description BedrockagentcoreHarness#description}
    */
    readonly description?: string;
    /**
    * JSON Schema describing the tool's input parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#input_schema BedrockagentcoreHarness#input_schema}
    */
    readonly inputSchema?: string;
}
export declare function bedrockagentcoreHarnessToolsConfigInlineFunctionToTerraform(struct?: BedrockagentcoreHarnessToolsConfigInlineFunction | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsConfigInlineFunctionToHclTerraform(struct?: BedrockagentcoreHarnessToolsConfigInlineFunction | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsConfigInlineFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessToolsConfigInlineFunction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolsConfigInlineFunction | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inputSchema?;
    get inputSchema(): string;
    set inputSchema(value: string);
    resetInputSchema(): void;
    get inputSchemaInput(): string | undefined;
}
export interface BedrockagentcoreHarnessToolsConfigRemoteMcp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#headers BedrockagentcoreHarness#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#url BedrockagentcoreHarness#url}
    */
    readonly url?: string;
}
export declare function bedrockagentcoreHarnessToolsConfigRemoteMcpToTerraform(struct?: BedrockagentcoreHarnessToolsConfigRemoteMcp | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsConfigRemoteMcpToHclTerraform(struct?: BedrockagentcoreHarnessToolsConfigRemoteMcp | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsConfigRemoteMcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessToolsConfigRemoteMcp | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolsConfigRemoteMcp | cdktn.IResolvable | undefined);
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface BedrockagentcoreHarnessToolsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#agent_core_browser BedrockagentcoreHarness#agent_core_browser}
    */
    readonly agentCoreBrowser?: BedrockagentcoreHarnessToolsConfigAgentCoreBrowser;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#agent_core_code_interpreter BedrockagentcoreHarness#agent_core_code_interpreter}
    */
    readonly agentCoreCodeInterpreter?: BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreter;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#agent_core_gateway BedrockagentcoreHarness#agent_core_gateway}
    */
    readonly agentCoreGateway?: BedrockagentcoreHarnessToolsConfigAgentCoreGateway;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#inline_function BedrockagentcoreHarness#inline_function}
    */
    readonly inlineFunction?: BedrockagentcoreHarnessToolsConfigInlineFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#remote_mcp BedrockagentcoreHarness#remote_mcp}
    */
    readonly remoteMcp?: BedrockagentcoreHarnessToolsConfigRemoteMcp;
}
export declare function bedrockagentcoreHarnessToolsConfigToTerraform(struct?: BedrockagentcoreHarnessToolsConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsConfigToHclTerraform(struct?: BedrockagentcoreHarnessToolsConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessToolsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolsConfig | cdktn.IResolvable | undefined);
    private _agentCoreBrowser;
    get agentCoreBrowser(): BedrockagentcoreHarnessToolsConfigAgentCoreBrowserOutputReference;
    putAgentCoreBrowser(value: BedrockagentcoreHarnessToolsConfigAgentCoreBrowser): void;
    resetAgentCoreBrowser(): void;
    get agentCoreBrowserInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolsConfigAgentCoreBrowser | undefined;
    private _agentCoreCodeInterpreter;
    get agentCoreCodeInterpreter(): BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreterOutputReference;
    putAgentCoreCodeInterpreter(value: BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreter): void;
    resetAgentCoreCodeInterpreter(): void;
    get agentCoreCodeInterpreterInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolsConfigAgentCoreCodeInterpreter | undefined;
    private _agentCoreGateway;
    get agentCoreGateway(): BedrockagentcoreHarnessToolsConfigAgentCoreGatewayOutputReference;
    putAgentCoreGateway(value: BedrockagentcoreHarnessToolsConfigAgentCoreGateway): void;
    resetAgentCoreGateway(): void;
    get agentCoreGatewayInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolsConfigAgentCoreGateway | undefined;
    private _inlineFunction;
    get inlineFunction(): BedrockagentcoreHarnessToolsConfigInlineFunctionOutputReference;
    putInlineFunction(value: BedrockagentcoreHarnessToolsConfigInlineFunction): void;
    resetInlineFunction(): void;
    get inlineFunctionInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolsConfigInlineFunction | undefined;
    private _remoteMcp;
    get remoteMcp(): BedrockagentcoreHarnessToolsConfigRemoteMcpOutputReference;
    putRemoteMcp(value: BedrockagentcoreHarnessToolsConfigRemoteMcp): void;
    resetRemoteMcp(): void;
    get remoteMcpInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolsConfigRemoteMcp | undefined;
}
export interface BedrockagentcoreHarnessTools {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#config BedrockagentcoreHarness#config}
    */
    readonly config?: BedrockagentcoreHarnessToolsConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#name BedrockagentcoreHarness#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#type BedrockagentcoreHarness#type}
    */
    readonly type?: string;
}
export declare function bedrockagentcoreHarnessToolsToTerraform(struct?: BedrockagentcoreHarnessTools | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolsToHclTerraform(struct?: BedrockagentcoreHarnessTools | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessTools | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTools | cdktn.IResolvable | undefined);
    private _config;
    get config(): BedrockagentcoreHarnessToolsConfigOutputReference;
    putConfig(value: BedrockagentcoreHarnessToolsConfig): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolsConfig | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessToolsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessTools[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolsOutputReference;
}
export interface BedrockagentcoreHarnessTruncationConfigSlidingWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#messages_count BedrockagentcoreHarness#messages_count}
    */
    readonly messagesCount?: number;
}
export declare function bedrockagentcoreHarnessTruncationConfigSlidingWindowToTerraform(struct?: BedrockagentcoreHarnessTruncationConfigSlidingWindow | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTruncationConfigSlidingWindowToHclTerraform(struct?: BedrockagentcoreHarnessTruncationConfigSlidingWindow | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTruncationConfigSlidingWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessTruncationConfigSlidingWindow | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTruncationConfigSlidingWindow | cdktn.IResolvable | undefined);
    private _messagesCount?;
    get messagesCount(): number;
    set messagesCount(value: number);
    resetMessagesCount(): void;
    get messagesCountInput(): number | undefined;
}
export interface BedrockagentcoreHarnessTruncationConfigSummarization {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#preserve_recent_messages BedrockagentcoreHarness#preserve_recent_messages}
    */
    readonly preserveRecentMessages?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#summarization_system_prompt BedrockagentcoreHarness#summarization_system_prompt}
    */
    readonly summarizationSystemPrompt?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#summary_ratio BedrockagentcoreHarness#summary_ratio}
    */
    readonly summaryRatio?: number;
}
export declare function bedrockagentcoreHarnessTruncationConfigSummarizationToTerraform(struct?: BedrockagentcoreHarnessTruncationConfigSummarization | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTruncationConfigSummarizationToHclTerraform(struct?: BedrockagentcoreHarnessTruncationConfigSummarization | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTruncationConfigSummarizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessTruncationConfigSummarization | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTruncationConfigSummarization | cdktn.IResolvable | undefined);
    private _preserveRecentMessages?;
    get preserveRecentMessages(): number;
    set preserveRecentMessages(value: number);
    resetPreserveRecentMessages(): void;
    get preserveRecentMessagesInput(): number | undefined;
    private _summarizationSystemPrompt?;
    get summarizationSystemPrompt(): string;
    set summarizationSystemPrompt(value: string);
    resetSummarizationSystemPrompt(): void;
    get summarizationSystemPromptInput(): string | undefined;
    private _summaryRatio?;
    get summaryRatio(): number;
    set summaryRatio(value: number);
    resetSummaryRatio(): void;
    get summaryRatioInput(): number | undefined;
}
export interface BedrockagentcoreHarnessTruncationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#sliding_window BedrockagentcoreHarness#sliding_window}
    */
    readonly slidingWindow?: BedrockagentcoreHarnessTruncationConfigSlidingWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#summarization BedrockagentcoreHarness#summarization}
    */
    readonly summarization?: BedrockagentcoreHarnessTruncationConfigSummarization;
}
export declare function bedrockagentcoreHarnessTruncationConfigToTerraform(struct?: BedrockagentcoreHarnessTruncationConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTruncationConfigToHclTerraform(struct?: BedrockagentcoreHarnessTruncationConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTruncationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessTruncationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTruncationConfig | cdktn.IResolvable | undefined);
    private _slidingWindow;
    get slidingWindow(): BedrockagentcoreHarnessTruncationConfigSlidingWindowOutputReference;
    putSlidingWindow(value: BedrockagentcoreHarnessTruncationConfigSlidingWindow): void;
    resetSlidingWindow(): void;
    get slidingWindowInput(): cdktn.IResolvable | BedrockagentcoreHarnessTruncationConfigSlidingWindow | undefined;
    private _summarization;
    get summarization(): BedrockagentcoreHarnessTruncationConfigSummarizationOutputReference;
    putSummarization(value: BedrockagentcoreHarnessTruncationConfigSummarization): void;
    resetSummarization(): void;
    get summarizationInput(): cdktn.IResolvable | BedrockagentcoreHarnessTruncationConfigSummarization | undefined;
}
export interface BedrockagentcoreHarnessTruncation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#config BedrockagentcoreHarness#config}
    */
    readonly config?: BedrockagentcoreHarnessTruncationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#strategy BedrockagentcoreHarness#strategy}
    */
    readonly strategy?: string;
}
export declare function bedrockagentcoreHarnessTruncationToTerraform(struct?: BedrockagentcoreHarnessTruncation | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTruncationToHclTerraform(struct?: BedrockagentcoreHarnessTruncation | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTruncationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessTruncation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTruncation | cdktn.IResolvable | undefined);
    private _config;
    get config(): BedrockagentcoreHarnessTruncationConfigOutputReference;
    putConfig(value: BedrockagentcoreHarnessTruncationConfig): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | BedrockagentcoreHarnessTruncationConfig | undefined;
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    resetStrategy(): void;
    get strategyInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness awscc_bedrockagentcore_harness}
*/
export declare class BedrockagentcoreHarness extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_harness";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreHarness resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreHarness to import
    * @param importFromId The id of the existing BedrockagentcoreHarness that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreHarness to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_harness awscc_bedrockagentcore_harness} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreHarnessConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreHarnessConfig);
    private _allowedTools?;
    get allowedTools(): string[];
    set allowedTools(value: string[]);
    resetAllowedTools(): void;
    get allowedToolsInput(): string[] | undefined;
    get arn(): string;
    private _authorizerConfiguration;
    get authorizerConfiguration(): BedrockagentcoreHarnessAuthorizerConfigurationOutputReference;
    putAuthorizerConfiguration(value: BedrockagentcoreHarnessAuthorizerConfiguration): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfiguration | undefined;
    get createdAt(): string;
    private _environment;
    get environment(): BedrockagentcoreHarnessEnvironmentOutputReference;
    putEnvironment(value: BedrockagentcoreHarnessEnvironment): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironment | undefined;
    private _environmentArtifact;
    get environmentArtifact(): BedrockagentcoreHarnessEnvironmentArtifactOutputReference;
    putEnvironmentArtifact(value: BedrockagentcoreHarnessEnvironmentArtifact): void;
    resetEnvironmentArtifact(): void;
    get environmentArtifactInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentArtifact | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    get harnessId(): string;
    private _harnessName?;
    get harnessName(): string;
    set harnessName(value: string);
    get harnessNameInput(): string | undefined;
    get id(): string;
    private _maxIterations?;
    get maxIterations(): number;
    set maxIterations(value: number);
    resetMaxIterations(): void;
    get maxIterationsInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _memory;
    get memory(): BedrockagentcoreHarnessMemoryOutputReference;
    putMemory(value: BedrockagentcoreHarnessMemory): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | BedrockagentcoreHarnessMemory | undefined;
    private _model;
    get model(): BedrockagentcoreHarnessModelOutputReference;
    putModel(value: BedrockagentcoreHarnessModel): void;
    get modelInput(): cdktn.IResolvable | BedrockagentcoreHarnessModel | undefined;
    private _skills;
    get skills(): BedrockagentcoreHarnessSkillsList;
    putSkills(value: BedrockagentcoreHarnessSkills[] | cdktn.IResolvable): void;
    resetSkills(): void;
    get skillsInput(): cdktn.IResolvable | BedrockagentcoreHarnessSkills[] | undefined;
    get status(): string;
    private _systemPrompt;
    get systemPrompt(): BedrockagentcoreHarnessSystemPromptList;
    putSystemPrompt(value: BedrockagentcoreHarnessSystemPrompt[] | cdktn.IResolvable): void;
    resetSystemPrompt(): void;
    get systemPromptInput(): cdktn.IResolvable | BedrockagentcoreHarnessSystemPrompt[] | undefined;
    private _tags;
    get tags(): BedrockagentcoreHarnessTagsList;
    putTags(value: BedrockagentcoreHarnessTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcoreHarnessTags[] | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _tools;
    get tools(): BedrockagentcoreHarnessToolsList;
    putTools(value: BedrockagentcoreHarnessTools[] | cdktn.IResolvable): void;
    resetTools(): void;
    get toolsInput(): cdktn.IResolvable | BedrockagentcoreHarnessTools[] | undefined;
    private _truncation;
    get truncation(): BedrockagentcoreHarnessTruncationOutputReference;
    putTruncation(value: BedrockagentcoreHarnessTruncation): void;
    resetTruncation(): void;
    get truncationInput(): cdktn.IResolvable | BedrockagentcoreHarnessTruncation | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
