/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayDomainNameConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#certificate_arn ApigatewayDomainName#certificate_arn}
    */
    readonly certificateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#domain_name ApigatewayDomainName#domain_name}
    */
    readonly domainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#endpoint_access_mode ApigatewayDomainName#endpoint_access_mode}
    */
    readonly endpointAccessMode?: string;
    /**
    * The endpoint configuration of this DomainName showing the endpoint types and IP address types of the domain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#endpoint_configuration ApigatewayDomainName#endpoint_configuration}
    */
    readonly endpointConfiguration?: ApigatewayDomainNameEndpointConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#mutual_tls_authentication ApigatewayDomainName#mutual_tls_authentication}
    */
    readonly mutualTlsAuthentication?: ApigatewayDomainNameMutualTlsAuthentication;
    /**
    * The ARN of the public certificate issued by ACM to validate ownership of your custom domain. Only required when configuring mutual TLS and using an ACM imported or private CA certificate ARN as the RegionalCertificateArn.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#ownership_verification_certificate_arn ApigatewayDomainName#ownership_verification_certificate_arn}
    */
    readonly ownershipVerificationCertificateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#regional_certificate_arn ApigatewayDomainName#regional_certificate_arn}
    */
    readonly regionalCertificateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#routing_mode ApigatewayDomainName#routing_mode}
    */
    readonly routingMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#security_policy ApigatewayDomainName#security_policy}
    */
    readonly securityPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#tags ApigatewayDomainName#tags}
    */
    readonly tags?: ApigatewayDomainNameTags[] | cdktn.IResolvable;
}
export interface ApigatewayDomainNameEndpointConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#ip_address_type ApigatewayDomainName#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#types ApigatewayDomainName#types}
    */
    readonly types?: string[];
}
export declare function apigatewayDomainNameEndpointConfigurationToTerraform(struct?: ApigatewayDomainNameEndpointConfiguration | cdktn.IResolvable): any;
export declare function apigatewayDomainNameEndpointConfigurationToHclTerraform(struct?: ApigatewayDomainNameEndpointConfiguration | cdktn.IResolvable): any;
export declare class ApigatewayDomainNameEndpointConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayDomainNameEndpointConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDomainNameEndpointConfiguration | cdktn.IResolvable | undefined);
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface ApigatewayDomainNameMutualTlsAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#truststore_uri ApigatewayDomainName#truststore_uri}
    */
    readonly truststoreUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#truststore_version ApigatewayDomainName#truststore_version}
    */
    readonly truststoreVersion?: string;
}
export declare function apigatewayDomainNameMutualTlsAuthenticationToTerraform(struct?: ApigatewayDomainNameMutualTlsAuthentication | cdktn.IResolvable): any;
export declare function apigatewayDomainNameMutualTlsAuthenticationToHclTerraform(struct?: ApigatewayDomainNameMutualTlsAuthentication | cdktn.IResolvable): any;
export declare class ApigatewayDomainNameMutualTlsAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayDomainNameMutualTlsAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDomainNameMutualTlsAuthentication | cdktn.IResolvable | undefined);
    private _truststoreUri?;
    get truststoreUri(): string;
    set truststoreUri(value: string);
    resetTruststoreUri(): void;
    get truststoreUriInput(): string | undefined;
    private _truststoreVersion?;
    get truststoreVersion(): string;
    set truststoreVersion(value: string);
    resetTruststoreVersion(): void;
    get truststoreVersionInput(): string | undefined;
}
export interface ApigatewayDomainNameTags {
    /**
    * A string you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#key ApigatewayDomainName#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#value ApigatewayDomainName#value}
    */
    readonly value?: string;
}
export declare function apigatewayDomainNameTagsToTerraform(struct?: ApigatewayDomainNameTags | cdktn.IResolvable): any;
export declare function apigatewayDomainNameTagsToHclTerraform(struct?: ApigatewayDomainNameTags | cdktn.IResolvable): any;
export declare class ApigatewayDomainNameTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayDomainNameTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDomainNameTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigatewayDomainNameTagsList extends cdktn.ComplexList {
    internalValue?: ApigatewayDomainNameTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayDomainNameTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name awscc_apigateway_domain_name}
*/
export declare class ApigatewayDomainName extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_domain_name";
    /**
    * Generates CDKTN code for importing a ApigatewayDomainName resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayDomainName to import
    * @param importFromId The id of the existing ApigatewayDomainName that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayDomainName to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name awscc_apigateway_domain_name} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayDomainNameConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApigatewayDomainNameConfig);
    private _certificateArn?;
    get certificateArn(): string;
    set certificateArn(value: string);
    resetCertificateArn(): void;
    get certificateArnInput(): string | undefined;
    get distributionDomainName(): string;
    get distributionHostedZoneId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    resetDomainName(): void;
    get domainNameInput(): string | undefined;
    get domainNameArn(): string;
    private _endpointAccessMode?;
    get endpointAccessMode(): string;
    set endpointAccessMode(value: string);
    resetEndpointAccessMode(): void;
    get endpointAccessModeInput(): string | undefined;
    private _endpointConfiguration;
    get endpointConfiguration(): ApigatewayDomainNameEndpointConfigurationOutputReference;
    putEndpointConfiguration(value: ApigatewayDomainNameEndpointConfiguration): void;
    resetEndpointConfiguration(): void;
    get endpointConfigurationInput(): cdktn.IResolvable | ApigatewayDomainNameEndpointConfiguration | undefined;
    get id(): string;
    private _mutualTlsAuthentication;
    get mutualTlsAuthentication(): ApigatewayDomainNameMutualTlsAuthenticationOutputReference;
    putMutualTlsAuthentication(value: ApigatewayDomainNameMutualTlsAuthentication): void;
    resetMutualTlsAuthentication(): void;
    get mutualTlsAuthenticationInput(): cdktn.IResolvable | ApigatewayDomainNameMutualTlsAuthentication | undefined;
    private _ownershipVerificationCertificateArn?;
    get ownershipVerificationCertificateArn(): string;
    set ownershipVerificationCertificateArn(value: string);
    resetOwnershipVerificationCertificateArn(): void;
    get ownershipVerificationCertificateArnInput(): string | undefined;
    private _regionalCertificateArn?;
    get regionalCertificateArn(): string;
    set regionalCertificateArn(value: string);
    resetRegionalCertificateArn(): void;
    get regionalCertificateArnInput(): string | undefined;
    get regionalDomainName(): string;
    get regionalHostedZoneId(): string;
    private _routingMode?;
    get routingMode(): string;
    set routingMode(value: string);
    resetRoutingMode(): void;
    get routingModeInput(): string | undefined;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    resetSecurityPolicy(): void;
    get securityPolicyInput(): string | undefined;
    private _tags;
    get tags(): ApigatewayDomainNameTagsList;
    putTags(value: ApigatewayDomainNameTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApigatewayDomainNameTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
