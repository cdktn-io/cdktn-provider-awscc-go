/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#attributes_to_delete AppstreamFleet#attributes_to_delete}
    */
    readonly attributesToDelete?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#compute_capacity AppstreamFleet#compute_capacity}
    */
    readonly computeCapacity?: AppstreamFleetComputeCapacity;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#description AppstreamFleet#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#disable_imdsv1 AppstreamFleet#disable_imdsv1}
    */
    readonly disableImdsv1?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#disconnect_timeout_in_seconds AppstreamFleet#disconnect_timeout_in_seconds}
    */
    readonly disconnectTimeoutInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#display_name AppstreamFleet#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#domain_join_info AppstreamFleet#domain_join_info}
    */
    readonly domainJoinInfo?: AppstreamFleetDomainJoinInfo;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#enable_default_internet_access AppstreamFleet#enable_default_internet_access}
    */
    readonly enableDefaultInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#fleet_type AppstreamFleet#fleet_type}
    */
    readonly fleetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#iam_role_arn AppstreamFleet#iam_role_arn}
    */
    readonly iamRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#idle_disconnect_timeout_in_seconds AppstreamFleet#idle_disconnect_timeout_in_seconds}
    */
    readonly idleDisconnectTimeoutInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#image_arn AppstreamFleet#image_arn}
    */
    readonly imageArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#image_name AppstreamFleet#image_name}
    */
    readonly imageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#instance_type AppstreamFleet#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#max_concurrent_sessions AppstreamFleet#max_concurrent_sessions}
    */
    readonly maxConcurrentSessions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#max_sessions_per_instance AppstreamFleet#max_sessions_per_instance}
    */
    readonly maxSessionsPerInstance?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#max_user_duration_in_seconds AppstreamFleet#max_user_duration_in_seconds}
    */
    readonly maxUserDurationInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#name AppstreamFleet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#platform AppstreamFleet#platform}
    */
    readonly platform?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#root_volume_config AppstreamFleet#root_volume_config}
    */
    readonly rootVolumeConfig?: AppstreamFleetRootVolumeConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#session_script_s3_location AppstreamFleet#session_script_s3_location}
    */
    readonly sessionScriptS3Location?: AppstreamFleetSessionScriptS3Location;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#stream_view AppstreamFleet#stream_view}
    */
    readonly streamView?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#tags AppstreamFleet#tags}
    */
    readonly tags?: AppstreamFleetTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#usb_device_filter_strings AppstreamFleet#usb_device_filter_strings}
    */
    readonly usbDeviceFilterStrings?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#vpc_config AppstreamFleet#vpc_config}
    */
    readonly vpcConfig?: AppstreamFleetVpcConfig;
}
export interface AppstreamFleetComputeCapacity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#desired_instances AppstreamFleet#desired_instances}
    */
    readonly desiredInstances?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#desired_sessions AppstreamFleet#desired_sessions}
    */
    readonly desiredSessions?: number;
}
export declare function appstreamFleetComputeCapacityToTerraform(struct?: AppstreamFleetComputeCapacity | cdktn.IResolvable): any;
export declare function appstreamFleetComputeCapacityToHclTerraform(struct?: AppstreamFleetComputeCapacity | cdktn.IResolvable): any;
export declare class AppstreamFleetComputeCapacityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamFleetComputeCapacity | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamFleetComputeCapacity | cdktn.IResolvable | undefined);
    private _desiredInstances?;
    get desiredInstances(): number;
    set desiredInstances(value: number);
    resetDesiredInstances(): void;
    get desiredInstancesInput(): number | undefined;
    private _desiredSessions?;
    get desiredSessions(): number;
    set desiredSessions(value: number);
    resetDesiredSessions(): void;
    get desiredSessionsInput(): number | undefined;
}
export interface AppstreamFleetDomainJoinInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#directory_name AppstreamFleet#directory_name}
    */
    readonly directoryName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#organizational_unit_distinguished_name AppstreamFleet#organizational_unit_distinguished_name}
    */
    readonly organizationalUnitDistinguishedName?: string;
}
export declare function appstreamFleetDomainJoinInfoToTerraform(struct?: AppstreamFleetDomainJoinInfo | cdktn.IResolvable): any;
export declare function appstreamFleetDomainJoinInfoToHclTerraform(struct?: AppstreamFleetDomainJoinInfo | cdktn.IResolvable): any;
export declare class AppstreamFleetDomainJoinInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamFleetDomainJoinInfo | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamFleetDomainJoinInfo | cdktn.IResolvable | undefined);
    private _directoryName?;
    get directoryName(): string;
    set directoryName(value: string);
    resetDirectoryName(): void;
    get directoryNameInput(): string | undefined;
    private _organizationalUnitDistinguishedName?;
    get organizationalUnitDistinguishedName(): string;
    set organizationalUnitDistinguishedName(value: string);
    resetOrganizationalUnitDistinguishedName(): void;
    get organizationalUnitDistinguishedNameInput(): string | undefined;
}
export interface AppstreamFleetRootVolumeConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#volume_size_in_gb AppstreamFleet#volume_size_in_gb}
    */
    readonly volumeSizeInGb?: number;
}
export declare function appstreamFleetRootVolumeConfigToTerraform(struct?: AppstreamFleetRootVolumeConfig | cdktn.IResolvable): any;
export declare function appstreamFleetRootVolumeConfigToHclTerraform(struct?: AppstreamFleetRootVolumeConfig | cdktn.IResolvable): any;
export declare class AppstreamFleetRootVolumeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamFleetRootVolumeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamFleetRootVolumeConfig | cdktn.IResolvable | undefined);
    private _volumeSizeInGb?;
    get volumeSizeInGb(): number;
    set volumeSizeInGb(value: number);
    resetVolumeSizeInGb(): void;
    get volumeSizeInGbInput(): number | undefined;
}
export interface AppstreamFleetSessionScriptS3Location {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#s3_bucket AppstreamFleet#s3_bucket}
    */
    readonly s3Bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#s3_key AppstreamFleet#s3_key}
    */
    readonly s3Key?: string;
}
export declare function appstreamFleetSessionScriptS3LocationToTerraform(struct?: AppstreamFleetSessionScriptS3Location | cdktn.IResolvable): any;
export declare function appstreamFleetSessionScriptS3LocationToHclTerraform(struct?: AppstreamFleetSessionScriptS3Location | cdktn.IResolvable): any;
export declare class AppstreamFleetSessionScriptS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamFleetSessionScriptS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamFleetSessionScriptS3Location | cdktn.IResolvable | undefined);
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    resetS3Bucket(): void;
    get s3BucketInput(): string | undefined;
    private _s3Key?;
    get s3Key(): string;
    set s3Key(value: string);
    resetS3Key(): void;
    get s3KeyInput(): string | undefined;
}
export interface AppstreamFleetTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#key AppstreamFleet#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#value AppstreamFleet#value}
    */
    readonly value?: string;
}
export declare function appstreamFleetTagsToTerraform(struct?: AppstreamFleetTags | cdktn.IResolvable): any;
export declare function appstreamFleetTagsToHclTerraform(struct?: AppstreamFleetTags | cdktn.IResolvable): any;
export declare class AppstreamFleetTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamFleetTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamFleetTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppstreamFleetTagsList extends cdktn.ComplexList {
    internalValue?: AppstreamFleetTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamFleetTagsOutputReference;
}
export interface AppstreamFleetVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#security_group_ids AppstreamFleet#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#subnet_ids AppstreamFleet#subnet_ids}
    */
    readonly subnetIds?: string[];
}
export declare function appstreamFleetVpcConfigToTerraform(struct?: AppstreamFleetVpcConfig | cdktn.IResolvable): any;
export declare function appstreamFleetVpcConfigToHclTerraform(struct?: AppstreamFleetVpcConfig | cdktn.IResolvable): any;
export declare class AppstreamFleetVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamFleetVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamFleetVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet awscc_appstream_fleet}
*/
export declare class AppstreamFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_fleet";
    /**
    * Generates CDKTN code for importing a AppstreamFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamFleet to import
    * @param importFromId The id of the existing AppstreamFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_fleet awscc_appstream_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamFleetConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamFleetConfig);
    get arn(): string;
    private _attributesToDelete?;
    get attributesToDelete(): string[];
    set attributesToDelete(value: string[]);
    resetAttributesToDelete(): void;
    get attributesToDeleteInput(): string[] | undefined;
    private _computeCapacity;
    get computeCapacity(): AppstreamFleetComputeCapacityOutputReference;
    putComputeCapacity(value: AppstreamFleetComputeCapacity): void;
    resetComputeCapacity(): void;
    get computeCapacityInput(): cdktn.IResolvable | AppstreamFleetComputeCapacity | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableImdsv1?;
    get disableImdsv1(): boolean | cdktn.IResolvable;
    set disableImdsv1(value: boolean | cdktn.IResolvable);
    resetDisableImdsv1(): void;
    get disableImdsv1Input(): boolean | cdktn.IResolvable | undefined;
    private _disconnectTimeoutInSeconds?;
    get disconnectTimeoutInSeconds(): number;
    set disconnectTimeoutInSeconds(value: number);
    resetDisconnectTimeoutInSeconds(): void;
    get disconnectTimeoutInSecondsInput(): number | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _domainJoinInfo;
    get domainJoinInfo(): AppstreamFleetDomainJoinInfoOutputReference;
    putDomainJoinInfo(value: AppstreamFleetDomainJoinInfo): void;
    resetDomainJoinInfo(): void;
    get domainJoinInfoInput(): cdktn.IResolvable | AppstreamFleetDomainJoinInfo | undefined;
    private _enableDefaultInternetAccess?;
    get enableDefaultInternetAccess(): boolean | cdktn.IResolvable;
    set enableDefaultInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableDefaultInternetAccess(): void;
    get enableDefaultInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _fleetType?;
    get fleetType(): string;
    set fleetType(value: string);
    resetFleetType(): void;
    get fleetTypeInput(): string | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    resetIamRoleArn(): void;
    get iamRoleArnInput(): string | undefined;
    get id(): string;
    private _idleDisconnectTimeoutInSeconds?;
    get idleDisconnectTimeoutInSeconds(): number;
    set idleDisconnectTimeoutInSeconds(value: number);
    resetIdleDisconnectTimeoutInSeconds(): void;
    get idleDisconnectTimeoutInSecondsInput(): number | undefined;
    private _imageArn?;
    get imageArn(): string;
    set imageArn(value: string);
    resetImageArn(): void;
    get imageArnInput(): string | undefined;
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    resetImageName(): void;
    get imageNameInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _maxConcurrentSessions?;
    get maxConcurrentSessions(): number;
    set maxConcurrentSessions(value: number);
    resetMaxConcurrentSessions(): void;
    get maxConcurrentSessionsInput(): number | undefined;
    private _maxSessionsPerInstance?;
    get maxSessionsPerInstance(): number;
    set maxSessionsPerInstance(value: number);
    resetMaxSessionsPerInstance(): void;
    get maxSessionsPerInstanceInput(): number | undefined;
    private _maxUserDurationInSeconds?;
    get maxUserDurationInSeconds(): number;
    set maxUserDurationInSeconds(value: number);
    resetMaxUserDurationInSeconds(): void;
    get maxUserDurationInSecondsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _platform?;
    get platform(): string;
    set platform(value: string);
    resetPlatform(): void;
    get platformInput(): string | undefined;
    private _rootVolumeConfig;
    get rootVolumeConfig(): AppstreamFleetRootVolumeConfigOutputReference;
    putRootVolumeConfig(value: AppstreamFleetRootVolumeConfig): void;
    resetRootVolumeConfig(): void;
    get rootVolumeConfigInput(): cdktn.IResolvable | AppstreamFleetRootVolumeConfig | undefined;
    private _sessionScriptS3Location;
    get sessionScriptS3Location(): AppstreamFleetSessionScriptS3LocationOutputReference;
    putSessionScriptS3Location(value: AppstreamFleetSessionScriptS3Location): void;
    resetSessionScriptS3Location(): void;
    get sessionScriptS3LocationInput(): cdktn.IResolvable | AppstreamFleetSessionScriptS3Location | undefined;
    private _streamView?;
    get streamView(): string;
    set streamView(value: string);
    resetStreamView(): void;
    get streamViewInput(): string | undefined;
    private _tags;
    get tags(): AppstreamFleetTagsList;
    putTags(value: AppstreamFleetTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppstreamFleetTags[] | undefined;
    private _usbDeviceFilterStrings?;
    get usbDeviceFilterStrings(): string[];
    set usbDeviceFilterStrings(value: string[]);
    resetUsbDeviceFilterStrings(): void;
    get usbDeviceFilterStringsInput(): string[] | undefined;
    private _vpcConfig;
    get vpcConfig(): AppstreamFleetVpcConfigOutputReference;
    putVpcConfig(value: AppstreamFleetVpcConfig): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | AppstreamFleetVpcConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
