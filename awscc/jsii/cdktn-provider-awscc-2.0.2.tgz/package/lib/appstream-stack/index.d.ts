/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamStackConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of virtual private cloud (VPC) interface endpoint objects. Users of the stack can connect to AppStream 2.0 only through the specified endpoints.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#access_endpoints AppstreamStack#access_endpoints}
    */
    readonly accessEndpoints?: AppstreamStackAccessEndpoints[] | cdktn.IResolvable;
    /**
    * The configuration for agent access on the stack. If specified, agent access is enabled for the stack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#agent_access_config AppstreamStack#agent_access_config}
    */
    readonly agentAccessConfig?: AppstreamStackAgentAccessConfig;
    /**
    * The persistent application settings for users of the stack. When these settings are enabled, changes that users make to applications and Windows settings are automatically saved after each session and applied to the next session.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#application_settings AppstreamStack#application_settings}
    */
    readonly applicationSettings?: AppstreamStackApplicationSettings;
    /**
    * The stack attributes to delete.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#attributes_to_delete AppstreamStack#attributes_to_delete}
    */
    readonly attributesToDelete?: string[];
    /**
    * The content redirection settings for the stack. These settings control URL redirection between the streaming session and the local device.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#content_redirection AppstreamStack#content_redirection}
    */
    readonly contentRedirection?: AppstreamStackContentRedirection;
    /**
    * This parameter has been deprecated. Deletes the storage connectors currently enabled for the stack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#delete_storage_connectors AppstreamStack#delete_storage_connectors}
    */
    readonly deleteStorageConnectors?: boolean | cdktn.IResolvable;
    /**
    * The description to display.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#description AppstreamStack#description}
    */
    readonly description?: string;
    /**
    * The stack name to display.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#display_name AppstreamStack#display_name}
    */
    readonly displayName?: string;
    /**
    * The domains where AppStream 2.0 streaming sessions can be embedded in an iframe. You must approve the domains that you want to host embedded AppStream 2.0 streaming sessions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#embed_host_domains AppstreamStack#embed_host_domains}
    */
    readonly embedHostDomains?: string[];
    /**
    * The URL that users are redirected to after they click the Send Feedback link. If no URL is specified, no Send Feedback link is displayed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#feedback_url AppstreamStack#feedback_url}
    */
    readonly feedbackUrl?: string;
    /**
    * The name of the stack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#name AppstreamStack#name}
    */
    readonly name?: string;
    /**
    * The URL that users are redirected to after their streaming session ends.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#redirect_url AppstreamStack#redirect_url}
    */
    readonly redirectUrl?: string;
    /**
    * Controls whether stored OneDrive and Google Drive authentication is retained between streaming sessions. Valid values: FORCE_REAUTHENTICATION | REUSE_CREDENTIALS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#storage_connector_authentication AppstreamStack#storage_connector_authentication}
    */
    readonly storageConnectorAuthentication?: string;
    /**
    * The storage connectors to enable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#storage_connectors AppstreamStack#storage_connectors}
    */
    readonly storageConnectors?: AppstreamStackStorageConnectors[] | cdktn.IResolvable;
    /**
    * The streaming protocol that you want your stack to prefer. This can be UDP or TCP. Currently, UDP is only supported in the Windows native client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#streaming_experience_settings AppstreamStack#streaming_experience_settings}
    */
    readonly streamingExperienceSettings?: AppstreamStackStreamingExperienceSettings;
    /**
    * An array of key-value pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#tags AppstreamStack#tags}
    */
    readonly tags?: AppstreamStackTags[] | cdktn.IResolvable;
    /**
    * The actions that are enabled or disabled for users during their streaming sessions. By default, these actions are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#user_settings AppstreamStack#user_settings}
    */
    readonly userSettings?: AppstreamStackUserSettings[] | cdktn.IResolvable;
}
export interface AppstreamStackAccessEndpoints {
    /**
    * The type of interface endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#endpoint_type AppstreamStack#endpoint_type}
    */
    readonly endpointType?: string;
    /**
    * The identifier (ID) of the VPC in which the interface endpoint is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#vpce_id AppstreamStack#vpce_id}
    */
    readonly vpceId?: string;
}
export declare function appstreamStackAccessEndpointsToTerraform(struct?: AppstreamStackAccessEndpoints | cdktn.IResolvable): any;
export declare function appstreamStackAccessEndpointsToHclTerraform(struct?: AppstreamStackAccessEndpoints | cdktn.IResolvable): any;
export declare class AppstreamStackAccessEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamStackAccessEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackAccessEndpoints | cdktn.IResolvable | undefined);
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    resetEndpointType(): void;
    get endpointTypeInput(): string | undefined;
    private _vpceId?;
    get vpceId(): string;
    set vpceId(value: string);
    resetVpceId(): void;
    get vpceIdInput(): string | undefined;
}
export declare class AppstreamStackAccessEndpointsList extends cdktn.ComplexList {
    internalValue?: AppstreamStackAccessEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamStackAccessEndpointsOutputReference;
}
export interface AppstreamStackAgentAccessConfigSettings {
    /**
    * The agent action to configure. Valid values are COMPUTER_VISION, COMPUTER_INPUT, and FORWARD_MCP_TOOLS. COMPUTER_VISION allows agents to take screenshots of the desktop. COMPUTER_INPUT allows agents to click, type, and scroll on the desktop and requires COMPUTER_VISION to also be enabled. FORWARD_MCP_TOOLS allows agents to interact with applications and the desktop operating system through direct MCP calls rather than using computer use tools. Forwards MCP tools configured on the WorkSpaces application session to the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#agent_action AppstreamStack#agent_action}
    */
    readonly agentAction?: string;
    /**
    * Whether the agent action is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#permission AppstreamStack#permission}
    */
    readonly permission?: string;
}
export declare function appstreamStackAgentAccessConfigSettingsToTerraform(struct?: AppstreamStackAgentAccessConfigSettings | cdktn.IResolvable): any;
export declare function appstreamStackAgentAccessConfigSettingsToHclTerraform(struct?: AppstreamStackAgentAccessConfigSettings | cdktn.IResolvable): any;
export declare class AppstreamStackAgentAccessConfigSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamStackAgentAccessConfigSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackAgentAccessConfigSettings | cdktn.IResolvable | undefined);
    private _agentAction?;
    get agentAction(): string;
    set agentAction(value: string);
    resetAgentAction(): void;
    get agentActionInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AppstreamStackAgentAccessConfigSettingsList extends cdktn.ComplexList {
    internalValue?: AppstreamStackAgentAccessConfigSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamStackAgentAccessConfigSettingsOutputReference;
}
export interface AppstreamStackAgentAccessConfig {
    /**
    * The Amazon Resource Name (ARN) of the Amazon S3 bucket where agent screenshots are stored. Required when ScreenshotsUploadEnabled is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#s3_bucket_arn AppstreamStack#s3_bucket_arn}
    */
    readonly s3BucketArn?: string;
    /**
    * The image format for agent screen captures.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#screen_image_format AppstreamStack#screen_image_format}
    */
    readonly screenImageFormat?: string;
    /**
    * The screen resolution for the agent streaming environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#screen_resolution AppstreamStack#screen_resolution}
    */
    readonly screenResolution?: string;
    /**
    * Indicates whether screenshot uploads to Amazon S3 are enabled for agent sessions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#screenshots_upload_enabled AppstreamStack#screenshots_upload_enabled}
    */
    readonly screenshotsUploadEnabled?: boolean | cdktn.IResolvable;
    /**
    * The list of agent access settings that define permissions for each agent action. You must specify at least one setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#settings AppstreamStack#settings}
    */
    readonly settings?: AppstreamStackAgentAccessConfigSettings[] | cdktn.IResolvable;
    /**
    * The user control mode for agent sessions. This setting determines how users can interact with agent sessions. Valid values are VIEW_ONLY, VIEW_STOP, and DISABLED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#user_control_mode AppstreamStack#user_control_mode}
    */
    readonly userControlMode?: string;
}
export declare function appstreamStackAgentAccessConfigToTerraform(struct?: AppstreamStackAgentAccessConfig | cdktn.IResolvable): any;
export declare function appstreamStackAgentAccessConfigToHclTerraform(struct?: AppstreamStackAgentAccessConfig | cdktn.IResolvable): any;
export declare class AppstreamStackAgentAccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamStackAgentAccessConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackAgentAccessConfig | cdktn.IResolvable | undefined);
    private _s3BucketArn?;
    get s3BucketArn(): string;
    set s3BucketArn(value: string);
    resetS3BucketArn(): void;
    get s3BucketArnInput(): string | undefined;
    private _screenImageFormat?;
    get screenImageFormat(): string;
    set screenImageFormat(value: string);
    resetScreenImageFormat(): void;
    get screenImageFormatInput(): string | undefined;
    private _screenResolution?;
    get screenResolution(): string;
    set screenResolution(value: string);
    resetScreenResolution(): void;
    get screenResolutionInput(): string | undefined;
    private _screenshotsUploadEnabled?;
    get screenshotsUploadEnabled(): boolean | cdktn.IResolvable;
    set screenshotsUploadEnabled(value: boolean | cdktn.IResolvable);
    resetScreenshotsUploadEnabled(): void;
    get screenshotsUploadEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _settings;
    get settings(): AppstreamStackAgentAccessConfigSettingsList;
    putSettings(value: AppstreamStackAgentAccessConfigSettings[] | cdktn.IResolvable): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | AppstreamStackAgentAccessConfigSettings[] | undefined;
    private _userControlMode?;
    get userControlMode(): string;
    set userControlMode(value: string);
    resetUserControlMode(): void;
    get userControlModeInput(): string | undefined;
}
export interface AppstreamStackApplicationSettings {
    /**
    * Enables or disables persistent application settings for users during their streaming sessions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#enabled AppstreamStack#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The path prefix for the S3 bucket where users' persistent application settings are stored. You can allow the same persistent application settings to be used across multiple stacks by specifying the same settings group for each stack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#settings_group AppstreamStack#settings_group}
    */
    readonly settingsGroup?: string;
}
export declare function appstreamStackApplicationSettingsToTerraform(struct?: AppstreamStackApplicationSettings | cdktn.IResolvable): any;
export declare function appstreamStackApplicationSettingsToHclTerraform(struct?: AppstreamStackApplicationSettings | cdktn.IResolvable): any;
export declare class AppstreamStackApplicationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamStackApplicationSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackApplicationSettings | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _settingsGroup?;
    get settingsGroup(): string;
    set settingsGroup(value: string);
    resetSettingsGroup(): void;
    get settingsGroupInput(): string | undefined;
}
export interface AppstreamStackContentRedirectionHostToClient {
    /**
    * The URLs that are allowed for redirection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#allowed_urls AppstreamStack#allowed_urls}
    */
    readonly allowedUrls?: string[];
    /**
    * The URLs that are denied for redirection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#denied_urls AppstreamStack#denied_urls}
    */
    readonly deniedUrls?: string[];
    /**
    * Specifies whether URL redirection is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#enabled AppstreamStack#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function appstreamStackContentRedirectionHostToClientToTerraform(struct?: AppstreamStackContentRedirectionHostToClient | cdktn.IResolvable): any;
export declare function appstreamStackContentRedirectionHostToClientToHclTerraform(struct?: AppstreamStackContentRedirectionHostToClient | cdktn.IResolvable): any;
export declare class AppstreamStackContentRedirectionHostToClientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamStackContentRedirectionHostToClient | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackContentRedirectionHostToClient | cdktn.IResolvable | undefined);
    private _allowedUrls?;
    get allowedUrls(): string[];
    set allowedUrls(value: string[]);
    resetAllowedUrls(): void;
    get allowedUrlsInput(): string[] | undefined;
    private _deniedUrls?;
    get deniedUrls(): string[];
    set deniedUrls(value: string[]);
    resetDeniedUrls(): void;
    get deniedUrlsInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppstreamStackContentRedirection {
    /**
    * The URL redirection configuration from the streaming session host to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#host_to_client AppstreamStack#host_to_client}
    */
    readonly hostToClient?: AppstreamStackContentRedirectionHostToClient;
}
export declare function appstreamStackContentRedirectionToTerraform(struct?: AppstreamStackContentRedirection | cdktn.IResolvable): any;
export declare function appstreamStackContentRedirectionToHclTerraform(struct?: AppstreamStackContentRedirection | cdktn.IResolvable): any;
export declare class AppstreamStackContentRedirectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamStackContentRedirection | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackContentRedirection | cdktn.IResolvable | undefined);
    private _hostToClient;
    get hostToClient(): AppstreamStackContentRedirectionHostToClientOutputReference;
    putHostToClient(value: AppstreamStackContentRedirectionHostToClient): void;
    resetHostToClient(): void;
    get hostToClientInput(): cdktn.IResolvable | AppstreamStackContentRedirectionHostToClient | undefined;
}
export interface AppstreamStackStorageConnectors {
    /**
    * The type of storage connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#connector_type AppstreamStack#connector_type}
    */
    readonly connectorType?: string;
    /**
    * The names of the domains for the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#domains AppstreamStack#domains}
    */
    readonly domains?: string[];
    /**
    * The ARN of the storage connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#resource_identifier AppstreamStack#resource_identifier}
    */
    readonly resourceIdentifier?: string;
}
export declare function appstreamStackStorageConnectorsToTerraform(struct?: AppstreamStackStorageConnectors | cdktn.IResolvable): any;
export declare function appstreamStackStorageConnectorsToHclTerraform(struct?: AppstreamStackStorageConnectors | cdktn.IResolvable): any;
export declare class AppstreamStackStorageConnectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamStackStorageConnectors | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackStorageConnectors | cdktn.IResolvable | undefined);
    private _connectorType?;
    get connectorType(): string;
    set connectorType(value: string);
    resetConnectorType(): void;
    get connectorTypeInput(): string | undefined;
    private _domains?;
    get domains(): string[];
    set domains(value: string[]);
    resetDomains(): void;
    get domainsInput(): string[] | undefined;
    private _resourceIdentifier?;
    get resourceIdentifier(): string;
    set resourceIdentifier(value: string);
    resetResourceIdentifier(): void;
    get resourceIdentifierInput(): string | undefined;
}
export declare class AppstreamStackStorageConnectorsList extends cdktn.ComplexList {
    internalValue?: AppstreamStackStorageConnectors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamStackStorageConnectorsOutputReference;
}
export interface AppstreamStackStreamingExperienceSettings {
    /**
    * The preferred protocol that you want to use while streaming your application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#preferred_protocol AppstreamStack#preferred_protocol}
    */
    readonly preferredProtocol?: string;
}
export declare function appstreamStackStreamingExperienceSettingsToTerraform(struct?: AppstreamStackStreamingExperienceSettings | cdktn.IResolvable): any;
export declare function appstreamStackStreamingExperienceSettingsToHclTerraform(struct?: AppstreamStackStreamingExperienceSettings | cdktn.IResolvable): any;
export declare class AppstreamStackStreamingExperienceSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamStackStreamingExperienceSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackStreamingExperienceSettings | cdktn.IResolvable | undefined);
    private _preferredProtocol?;
    get preferredProtocol(): string;
    set preferredProtocol(value: string);
    resetPreferredProtocol(): void;
    get preferredProtocolInput(): string | undefined;
}
export interface AppstreamStackTags {
    /**
    * The key of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#key AppstreamStack#key}
    */
    readonly key?: string;
    /**
    * The value of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#value AppstreamStack#value}
    */
    readonly value?: string;
}
export declare function appstreamStackTagsToTerraform(struct?: AppstreamStackTags | cdktn.IResolvable): any;
export declare function appstreamStackTagsToHclTerraform(struct?: AppstreamStackTags | cdktn.IResolvable): any;
export declare class AppstreamStackTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamStackTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppstreamStackTagsList extends cdktn.ComplexList {
    internalValue?: AppstreamStackTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamStackTagsOutputReference;
}
export interface AppstreamStackUserSettings {
    /**
    * The action that is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#action AppstreamStack#action}
    */
    readonly action?: string;
    /**
    * Specifies the number of characters that can be copied by end users from the local device to the remote session, and to the local device from the remote session. This can be specified only for the CLIPBOARD_COPY_FROM_LOCAL_DEVICE and CLIPBOARD_COPY_TO_LOCAL_DEVICE actions. This defaults to 20,971,520 (20 MB) when unspecified and the permission is ENABLED. This can't be specified when the permission is DISABLED. The value can be between 1 and 20,971,520 (20 MB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#maximum_length AppstreamStack#maximum_length}
    */
    readonly maximumLength?: number;
    /**
    * Indicates whether the action is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#permission AppstreamStack#permission}
    */
    readonly permission?: string;
}
export declare function appstreamStackUserSettingsToTerraform(struct?: AppstreamStackUserSettings | cdktn.IResolvable): any;
export declare function appstreamStackUserSettingsToHclTerraform(struct?: AppstreamStackUserSettings | cdktn.IResolvable): any;
export declare class AppstreamStackUserSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamStackUserSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamStackUserSettings | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _maximumLength?;
    get maximumLength(): number;
    set maximumLength(value: number);
    resetMaximumLength(): void;
    get maximumLengthInput(): number | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export declare class AppstreamStackUserSettingsList extends cdktn.ComplexList {
    internalValue?: AppstreamStackUserSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamStackUserSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack awscc_appstream_stack}
*/
export declare class AppstreamStack extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_stack";
    /**
    * Generates CDKTN code for importing a AppstreamStack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamStack to import
    * @param importFromId The id of the existing AppstreamStack that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamStack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_stack awscc_appstream_stack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamStackConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AppstreamStackConfig);
    private _accessEndpoints;
    get accessEndpoints(): AppstreamStackAccessEndpointsList;
    putAccessEndpoints(value: AppstreamStackAccessEndpoints[] | cdktn.IResolvable): void;
    resetAccessEndpoints(): void;
    get accessEndpointsInput(): cdktn.IResolvable | AppstreamStackAccessEndpoints[] | undefined;
    private _agentAccessConfig;
    get agentAccessConfig(): AppstreamStackAgentAccessConfigOutputReference;
    putAgentAccessConfig(value: AppstreamStackAgentAccessConfig): void;
    resetAgentAccessConfig(): void;
    get agentAccessConfigInput(): cdktn.IResolvable | AppstreamStackAgentAccessConfig | undefined;
    private _applicationSettings;
    get applicationSettings(): AppstreamStackApplicationSettingsOutputReference;
    putApplicationSettings(value: AppstreamStackApplicationSettings): void;
    resetApplicationSettings(): void;
    get applicationSettingsInput(): cdktn.IResolvable | AppstreamStackApplicationSettings | undefined;
    private _attributesToDelete?;
    get attributesToDelete(): string[];
    set attributesToDelete(value: string[]);
    resetAttributesToDelete(): void;
    get attributesToDeleteInput(): string[] | undefined;
    private _contentRedirection;
    get contentRedirection(): AppstreamStackContentRedirectionOutputReference;
    putContentRedirection(value: AppstreamStackContentRedirection): void;
    resetContentRedirection(): void;
    get contentRedirectionInput(): cdktn.IResolvable | AppstreamStackContentRedirection | undefined;
    private _deleteStorageConnectors?;
    get deleteStorageConnectors(): boolean | cdktn.IResolvable;
    set deleteStorageConnectors(value: boolean | cdktn.IResolvable);
    resetDeleteStorageConnectors(): void;
    get deleteStorageConnectorsInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _embedHostDomains?;
    get embedHostDomains(): string[];
    set embedHostDomains(value: string[]);
    resetEmbedHostDomains(): void;
    get embedHostDomainsInput(): string[] | undefined;
    private _feedbackUrl?;
    get feedbackUrl(): string;
    set feedbackUrl(value: string);
    resetFeedbackUrl(): void;
    get feedbackUrlInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _redirectUrl?;
    get redirectUrl(): string;
    set redirectUrl(value: string);
    resetRedirectUrl(): void;
    get redirectUrlInput(): string | undefined;
    private _storageConnectorAuthentication?;
    get storageConnectorAuthentication(): string;
    set storageConnectorAuthentication(value: string);
    resetStorageConnectorAuthentication(): void;
    get storageConnectorAuthenticationInput(): string | undefined;
    private _storageConnectors;
    get storageConnectors(): AppstreamStackStorageConnectorsList;
    putStorageConnectors(value: AppstreamStackStorageConnectors[] | cdktn.IResolvable): void;
    resetStorageConnectors(): void;
    get storageConnectorsInput(): cdktn.IResolvable | AppstreamStackStorageConnectors[] | undefined;
    private _streamingExperienceSettings;
    get streamingExperienceSettings(): AppstreamStackStreamingExperienceSettingsOutputReference;
    putStreamingExperienceSettings(value: AppstreamStackStreamingExperienceSettings): void;
    resetStreamingExperienceSettings(): void;
    get streamingExperienceSettingsInput(): cdktn.IResolvable | AppstreamStackStreamingExperienceSettings | undefined;
    private _tags;
    get tags(): AppstreamStackTagsList;
    putTags(value: AppstreamStackTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppstreamStackTags[] | undefined;
    private _userSettings;
    get userSettings(): AppstreamStackUserSettingsList;
    putUserSettings(value: AppstreamStackUserSettings[] | cdktn.IResolvable): void;
    resetUserSettings(): void;
    get userSettingsInput(): cdktn.IResolvable | AppstreamStackUserSettings[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
