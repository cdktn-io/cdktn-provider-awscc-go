/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreWorkloadIdentityConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of allowed OAuth2 return URLs for resources associated with this workload identity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_workload_identity#allowed_resource_oauth_2_return_urls BedrockagentcoreWorkloadIdentity#allowed_resource_oauth_2_return_urls}
    */
    readonly allowedResourceOauth2ReturnUrls?: string[];
    /**
    * The name of the workload identity. The name must be unique within your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_workload_identity#name BedrockagentcoreWorkloadIdentity#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_workload_identity#tags BedrockagentcoreWorkloadIdentity#tags}
    */
    readonly tags?: BedrockagentcoreWorkloadIdentityTags[] | cdktn.IResolvable;
}
export interface BedrockagentcoreWorkloadIdentityTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_workload_identity#key BedrockagentcoreWorkloadIdentity#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_workload_identity#value BedrockagentcoreWorkloadIdentity#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcoreWorkloadIdentityTagsToTerraform(struct?: BedrockagentcoreWorkloadIdentityTags | cdktn.IResolvable): any;
export declare function bedrockagentcoreWorkloadIdentityTagsToHclTerraform(struct?: BedrockagentcoreWorkloadIdentityTags | cdktn.IResolvable): any;
export declare class BedrockagentcoreWorkloadIdentityTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreWorkloadIdentityTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreWorkloadIdentityTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcoreWorkloadIdentityTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreWorkloadIdentityTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreWorkloadIdentityTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_workload_identity awscc_bedrockagentcore_workload_identity}
*/
export declare class BedrockagentcoreWorkloadIdentity extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_workload_identity";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreWorkloadIdentity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreWorkloadIdentity to import
    * @param importFromId The id of the existing BedrockagentcoreWorkloadIdentity that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_workload_identity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreWorkloadIdentity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrockagentcore_workload_identity awscc_bedrockagentcore_workload_identity} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreWorkloadIdentityConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreWorkloadIdentityConfig);
    private _allowedResourceOauth2ReturnUrls?;
    get allowedResourceOauth2ReturnUrls(): string[];
    set allowedResourceOauth2ReturnUrls(value: string[]);
    resetAllowedResourceOauth2ReturnUrls(): void;
    get allowedResourceOauth2ReturnUrlsInput(): string[] | undefined;
    get createdTime(): number;
    get id(): string;
    get lastUpdatedTime(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): BedrockagentcoreWorkloadIdentityTagsList;
    putTags(value: BedrockagentcoreWorkloadIdentityTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcoreWorkloadIdentityTags[] | undefined;
    get workloadIdentityArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
