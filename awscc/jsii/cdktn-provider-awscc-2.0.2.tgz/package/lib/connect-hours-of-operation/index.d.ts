/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectHoursOfOperationConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of child hours of operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#child_hours_of_operations ConnectHoursOfOperation#child_hours_of_operations}
    */
    readonly childHoursOfOperations?: ConnectHoursOfOperationChildHoursOfOperations[] | cdktn.IResolvable;
    /**
    * Configuration information for the hours of operation: day, start time, and end time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#config ConnectHoursOfOperation#config}
    */
    readonly config: ConnectHoursOfOperationConfigA[] | cdktn.IResolvable;
    /**
    * The description of the hours of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#description ConnectHoursOfOperation#description}
    */
    readonly description?: string;
    /**
    * One or more hours of operation overrides assigned to an hour of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#hours_of_operation_overrides ConnectHoursOfOperation#hours_of_operation_overrides}
    */
    readonly hoursOfOperationOverrides?: ConnectHoursOfOperationHoursOfOperationOverrides[] | cdktn.IResolvable;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#instance_arn ConnectHoursOfOperation#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the hours of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#name ConnectHoursOfOperation#name}
    */
    readonly name: string;
    /**
    * List of parent hours of operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#parent_hours_of_operations ConnectHoursOfOperation#parent_hours_of_operations}
    */
    readonly parentHoursOfOperations?: ConnectHoursOfOperationParentHoursOfOperations[] | cdktn.IResolvable;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#tags ConnectHoursOfOperation#tags}
    */
    readonly tags?: ConnectHoursOfOperationTags[] | cdktn.IResolvable;
    /**
    * The time zone of the hours of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#time_zone ConnectHoursOfOperation#time_zone}
    */
    readonly timeZone: string;
}
export interface ConnectHoursOfOperationChildHoursOfOperations {
    /**
    * The identifier for the hours of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#id ConnectHoursOfOperation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the hours of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#name ConnectHoursOfOperation#name}
    */
    readonly name?: string;
}
export declare function connectHoursOfOperationChildHoursOfOperationsToTerraform(struct?: ConnectHoursOfOperationChildHoursOfOperations | cdktn.IResolvable): any;
export declare function connectHoursOfOperationChildHoursOfOperationsToHclTerraform(struct?: ConnectHoursOfOperationChildHoursOfOperations | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationChildHoursOfOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectHoursOfOperationChildHoursOfOperations | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationChildHoursOfOperations | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class ConnectHoursOfOperationChildHoursOfOperationsList extends cdktn.ComplexList {
    internalValue?: ConnectHoursOfOperationChildHoursOfOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectHoursOfOperationChildHoursOfOperationsOutputReference;
}
export interface ConnectHoursOfOperationConfigEndTime {
    /**
    * The hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#hours ConnectHoursOfOperation#hours}
    */
    readonly hours: number;
    /**
    * The minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#minutes ConnectHoursOfOperation#minutes}
    */
    readonly minutes: number;
}
export declare function connectHoursOfOperationConfigEndTimeToTerraform(struct?: ConnectHoursOfOperationConfigEndTime | cdktn.IResolvable): any;
export declare function connectHoursOfOperationConfigEndTimeToHclTerraform(struct?: ConnectHoursOfOperationConfigEndTime | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationConfigEndTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectHoursOfOperationConfigEndTime | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationConfigEndTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    get minutesInput(): number | undefined;
}
export interface ConnectHoursOfOperationConfigStartTime {
    /**
    * The hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#hours ConnectHoursOfOperation#hours}
    */
    readonly hours: number;
    /**
    * The minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#minutes ConnectHoursOfOperation#minutes}
    */
    readonly minutes: number;
}
export declare function connectHoursOfOperationConfigStartTimeToTerraform(struct?: ConnectHoursOfOperationConfigStartTime | cdktn.IResolvable): any;
export declare function connectHoursOfOperationConfigStartTimeToHclTerraform(struct?: ConnectHoursOfOperationConfigStartTime | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationConfigStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectHoursOfOperationConfigStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationConfigStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    get minutesInput(): number | undefined;
}
export interface ConnectHoursOfOperationConfigA {
    /**
    * The day that the hours of operation applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#day ConnectHoursOfOperation#day}
    */
    readonly day: string;
    /**
    * The end time that your contact center closes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#end_time ConnectHoursOfOperation#end_time}
    */
    readonly endTime: ConnectHoursOfOperationConfigEndTime;
    /**
    * The start time that your contact center opens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#start_time ConnectHoursOfOperation#start_time}
    */
    readonly startTime: ConnectHoursOfOperationConfigStartTime;
}
export declare function connectHoursOfOperationConfigAToTerraform(struct?: ConnectHoursOfOperationConfigA | cdktn.IResolvable): any;
export declare function connectHoursOfOperationConfigAToHclTerraform(struct?: ConnectHoursOfOperationConfigA | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectHoursOfOperationConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationConfigA | cdktn.IResolvable | undefined);
    private _day?;
    get day(): string;
    set day(value: string);
    get dayInput(): string | undefined;
    private _endTime;
    get endTime(): ConnectHoursOfOperationConfigEndTimeOutputReference;
    putEndTime(value: ConnectHoursOfOperationConfigEndTime): void;
    get endTimeInput(): cdktn.IResolvable | ConnectHoursOfOperationConfigEndTime | undefined;
    private _startTime;
    get startTime(): ConnectHoursOfOperationConfigStartTimeOutputReference;
    putStartTime(value: ConnectHoursOfOperationConfigStartTime): void;
    get startTimeInput(): cdktn.IResolvable | ConnectHoursOfOperationConfigStartTime | undefined;
}
export declare class ConnectHoursOfOperationConfigAList extends cdktn.ComplexList {
    internalValue?: ConnectHoursOfOperationConfigA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectHoursOfOperationConfigAOutputReference;
}
export interface ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTime {
    /**
    * The hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#hours ConnectHoursOfOperation#hours}
    */
    readonly hours?: number;
    /**
    * The minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#minutes ConnectHoursOfOperation#minutes}
    */
    readonly minutes?: number;
}
export declare function connectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTimeToTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTime | cdktn.IResolvable): any;
export declare function connectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTimeToHclTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTime | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTime | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTime {
    /**
    * The hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#hours ConnectHoursOfOperation#hours}
    */
    readonly hours?: number;
    /**
    * The minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#minutes ConnectHoursOfOperation#minutes}
    */
    readonly minutes?: number;
}
export declare function connectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTimeToTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTime | cdktn.IResolvable): any;
export declare function connectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTimeToHclTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTime | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig {
    /**
    * The day that the hours of operation override applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#day ConnectHoursOfOperation#day}
    */
    readonly day?: string;
    /**
    * The new end time that your contact center closes for the overriden days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#end_time ConnectHoursOfOperation#end_time}
    */
    readonly endTime?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTime;
    /**
    * The new start time that your contact center opens for the overriden days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#start_time ConnectHoursOfOperation#start_time}
    */
    readonly startTime?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTime;
}
export declare function connectHoursOfOperationHoursOfOperationOverridesOverrideConfigToTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig | cdktn.IResolvable): any;
export declare function connectHoursOfOperationHoursOfOperationOverridesOverrideConfigToHclTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig | cdktn.IResolvable | undefined);
    private _day?;
    get day(): string;
    set day(value: string);
    resetDay(): void;
    get dayInput(): string | undefined;
    private _endTime;
    get endTime(): ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTimeOutputReference;
    putEndTime(value: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTime): void;
    resetEndTime(): void;
    get endTimeInput(): cdktn.IResolvable | ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigEndTime | undefined;
    private _startTime;
    get startTime(): ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTimeOutputReference;
    putStartTime(value: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTime): void;
    resetStartTime(): void;
    get startTimeInput(): cdktn.IResolvable | ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigStartTime | undefined;
}
export declare class ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigList extends cdktn.ComplexList {
    internalValue?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigOutputReference;
}
export interface ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePattern {
    /**
    * List of months (1-12) for recurrence pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#by_month ConnectHoursOfOperation#by_month}
    */
    readonly byMonth?: number[];
    /**
    * List of month days (-1 to 31) for recurrence pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#by_month_day ConnectHoursOfOperation#by_month_day}
    */
    readonly byMonthDay?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#by_weekday_occurrence ConnectHoursOfOperation#by_weekday_occurrence}
    */
    readonly byWeekdayOccurrence?: number[];
    /**
    * The frequency of recurrence for hours of operation overrides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#frequency ConnectHoursOfOperation#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#interval ConnectHoursOfOperation#interval}
    */
    readonly interval?: number;
}
export declare function connectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePatternToTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePattern | cdktn.IResolvable): any;
export declare function connectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePatternToHclTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePattern | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePattern | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePattern | cdktn.IResolvable | undefined);
    private _byMonth?;
    get byMonth(): number[];
    set byMonth(value: number[]);
    resetByMonth(): void;
    get byMonthInput(): number[] | undefined;
    private _byMonthDay?;
    get byMonthDay(): number[];
    set byMonthDay(value: number[]);
    resetByMonthDay(): void;
    get byMonthDayInput(): number[] | undefined;
    private _byWeekdayOccurrence?;
    get byWeekdayOccurrence(): number[];
    set byWeekdayOccurrence(value: number[]);
    resetByWeekdayOccurrence(): void;
    get byWeekdayOccurrenceInput(): number[] | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfig {
    /**
    * Pattern for recurring hours of operation overrides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#recurrence_pattern ConnectHoursOfOperation#recurrence_pattern}
    */
    readonly recurrencePattern?: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePattern;
}
export declare function connectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigToTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfig | cdktn.IResolvable): any;
export declare function connectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigToHclTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfig | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfig | cdktn.IResolvable | undefined);
    private _recurrencePattern;
    get recurrencePattern(): ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePatternOutputReference;
    putRecurrencePattern(value: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePattern): void;
    resetRecurrencePattern(): void;
    get recurrencePatternInput(): cdktn.IResolvable | ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigRecurrencePattern | undefined;
}
export interface ConnectHoursOfOperationHoursOfOperationOverrides {
    /**
    * The date from which the hours of operation override would be effective.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#effective_from ConnectHoursOfOperation#effective_from}
    */
    readonly effectiveFrom?: string;
    /**
    * The date till which the hours of operation override would be effective.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#effective_till ConnectHoursOfOperation#effective_till}
    */
    readonly effectiveTill?: string;
    /**
    * The Resource Identifier for the hours of operation override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#hours_of_operation_override_id ConnectHoursOfOperation#hours_of_operation_override_id}
    */
    readonly hoursOfOperationOverrideId?: string;
    /**
    * Configuration information for the hours of operation override: day, start time, and end time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#override_config ConnectHoursOfOperation#override_config}
    */
    readonly overrideConfig?: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig[] | cdktn.IResolvable;
    /**
    * The description of the hours of operation override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#override_description ConnectHoursOfOperation#override_description}
    */
    readonly overrideDescription?: string;
    /**
    * The name of the hours of operation override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#override_name ConnectHoursOfOperation#override_name}
    */
    readonly overrideName?: string;
    /**
    * The type of hours of operation override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#override_type ConnectHoursOfOperation#override_type}
    */
    readonly overrideType?: string;
    /**
    * Configuration for recurring hours of operation overrides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#recurrence_config ConnectHoursOfOperation#recurrence_config}
    */
    readonly recurrenceConfig?: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfig;
}
export declare function connectHoursOfOperationHoursOfOperationOverridesToTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverrides | cdktn.IResolvable): any;
export declare function connectHoursOfOperationHoursOfOperationOverridesToHclTerraform(struct?: ConnectHoursOfOperationHoursOfOperationOverrides | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationHoursOfOperationOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectHoursOfOperationHoursOfOperationOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationHoursOfOperationOverrides | cdktn.IResolvable | undefined);
    private _effectiveFrom?;
    get effectiveFrom(): string;
    set effectiveFrom(value: string);
    resetEffectiveFrom(): void;
    get effectiveFromInput(): string | undefined;
    private _effectiveTill?;
    get effectiveTill(): string;
    set effectiveTill(value: string);
    resetEffectiveTill(): void;
    get effectiveTillInput(): string | undefined;
    private _hoursOfOperationOverrideId?;
    get hoursOfOperationOverrideId(): string;
    set hoursOfOperationOverrideId(value: string);
    resetHoursOfOperationOverrideId(): void;
    get hoursOfOperationOverrideIdInput(): string | undefined;
    private _overrideConfig;
    get overrideConfig(): ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfigList;
    putOverrideConfig(value: ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig[] | cdktn.IResolvable): void;
    resetOverrideConfig(): void;
    get overrideConfigInput(): cdktn.IResolvable | ConnectHoursOfOperationHoursOfOperationOverridesOverrideConfig[] | undefined;
    private _overrideDescription?;
    get overrideDescription(): string;
    set overrideDescription(value: string);
    resetOverrideDescription(): void;
    get overrideDescriptionInput(): string | undefined;
    private _overrideName?;
    get overrideName(): string;
    set overrideName(value: string);
    resetOverrideName(): void;
    get overrideNameInput(): string | undefined;
    private _overrideType?;
    get overrideType(): string;
    set overrideType(value: string);
    resetOverrideType(): void;
    get overrideTypeInput(): string | undefined;
    private _recurrenceConfig;
    get recurrenceConfig(): ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfigOutputReference;
    putRecurrenceConfig(value: ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfig): void;
    resetRecurrenceConfig(): void;
    get recurrenceConfigInput(): cdktn.IResolvable | ConnectHoursOfOperationHoursOfOperationOverridesRecurrenceConfig | undefined;
}
export declare class ConnectHoursOfOperationHoursOfOperationOverridesList extends cdktn.ComplexList {
    internalValue?: ConnectHoursOfOperationHoursOfOperationOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectHoursOfOperationHoursOfOperationOverridesOutputReference;
}
export interface ConnectHoursOfOperationParentHoursOfOperations {
    /**
    * The identifier for the hours of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#id ConnectHoursOfOperation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the hours of operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#name ConnectHoursOfOperation#name}
    */
    readonly name?: string;
}
export declare function connectHoursOfOperationParentHoursOfOperationsToTerraform(struct?: ConnectHoursOfOperationParentHoursOfOperations | cdktn.IResolvable): any;
export declare function connectHoursOfOperationParentHoursOfOperationsToHclTerraform(struct?: ConnectHoursOfOperationParentHoursOfOperations | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationParentHoursOfOperationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectHoursOfOperationParentHoursOfOperations | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationParentHoursOfOperations | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class ConnectHoursOfOperationParentHoursOfOperationsList extends cdktn.ComplexList {
    internalValue?: ConnectHoursOfOperationParentHoursOfOperations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectHoursOfOperationParentHoursOfOperationsOutputReference;
}
export interface ConnectHoursOfOperationTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#key ConnectHoursOfOperation#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#value ConnectHoursOfOperation#value}
    */
    readonly value?: string;
}
export declare function connectHoursOfOperationTagsToTerraform(struct?: ConnectHoursOfOperationTags | cdktn.IResolvable): any;
export declare function connectHoursOfOperationTagsToHclTerraform(struct?: ConnectHoursOfOperationTags | cdktn.IResolvable): any;
export declare class ConnectHoursOfOperationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectHoursOfOperationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectHoursOfOperationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectHoursOfOperationTagsList extends cdktn.ComplexList {
    internalValue?: ConnectHoursOfOperationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectHoursOfOperationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation awscc_connect_hours_of_operation}
*/
export declare class ConnectHoursOfOperation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_hours_of_operation";
    /**
    * Generates CDKTN code for importing a ConnectHoursOfOperation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectHoursOfOperation to import
    * @param importFromId The id of the existing ConnectHoursOfOperation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectHoursOfOperation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_hours_of_operation awscc_connect_hours_of_operation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectHoursOfOperationConfig
    */
    constructor(scope: Construct, id: string, config: ConnectHoursOfOperationConfig);
    private _childHoursOfOperations;
    get childHoursOfOperations(): ConnectHoursOfOperationChildHoursOfOperationsList;
    putChildHoursOfOperations(value: ConnectHoursOfOperationChildHoursOfOperations[] | cdktn.IResolvable): void;
    resetChildHoursOfOperations(): void;
    get childHoursOfOperationsInput(): cdktn.IResolvable | ConnectHoursOfOperationChildHoursOfOperations[] | undefined;
    private _config;
    get config(): ConnectHoursOfOperationConfigAList;
    putConfig(value: ConnectHoursOfOperationConfigA[] | cdktn.IResolvable): void;
    get configInput(): cdktn.IResolvable | ConnectHoursOfOperationConfigA[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get hoursOfOperationArn(): string;
    private _hoursOfOperationOverrides;
    get hoursOfOperationOverrides(): ConnectHoursOfOperationHoursOfOperationOverridesList;
    putHoursOfOperationOverrides(value: ConnectHoursOfOperationHoursOfOperationOverrides[] | cdktn.IResolvable): void;
    resetHoursOfOperationOverrides(): void;
    get hoursOfOperationOverridesInput(): cdktn.IResolvable | ConnectHoursOfOperationHoursOfOperationOverrides[] | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentHoursOfOperations;
    get parentHoursOfOperations(): ConnectHoursOfOperationParentHoursOfOperationsList;
    putParentHoursOfOperations(value: ConnectHoursOfOperationParentHoursOfOperations[] | cdktn.IResolvable): void;
    resetParentHoursOfOperations(): void;
    get parentHoursOfOperationsInput(): cdktn.IResolvable | ConnectHoursOfOperationParentHoursOfOperations[] | undefined;
    private _tags;
    get tags(): ConnectHoursOfOperationTagsList;
    putTags(value: ConnectHoursOfOperationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectHoursOfOperationTags[] | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
