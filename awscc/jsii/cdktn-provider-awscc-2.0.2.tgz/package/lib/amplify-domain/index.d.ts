/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AmplifyDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#app_id AmplifyDomain#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#auto_sub_domain_creation_patterns AmplifyDomain#auto_sub_domain_creation_patterns}
    */
    readonly autoSubDomainCreationPatterns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#auto_sub_domain_iam_role AmplifyDomain#auto_sub_domain_iam_role}
    */
    readonly autoSubDomainIamRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#certificate_settings AmplifyDomain#certificate_settings}
    */
    readonly certificateSettings?: AmplifyDomainCertificateSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#domain_name AmplifyDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#enable_auto_sub_domain AmplifyDomain#enable_auto_sub_domain}
    */
    readonly enableAutoSubDomain?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#sub_domain_settings AmplifyDomain#sub_domain_settings}
    */
    readonly subDomainSettings: AmplifyDomainSubDomainSettings[] | cdktn.IResolvable;
}
export interface AmplifyDomainCertificate {
}
export declare function amplifyDomainCertificateToTerraform(struct?: AmplifyDomainCertificate): any;
export declare function amplifyDomainCertificateToHclTerraform(struct?: AmplifyDomainCertificate): any;
export declare class AmplifyDomainCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyDomainCertificate | undefined;
    set internalValue(value: AmplifyDomainCertificate | undefined);
    get certificateArn(): string;
    get certificateType(): string;
    get certificateVerificationDnsRecord(): string;
}
export interface AmplifyDomainCertificateSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#certificate_type AmplifyDomain#certificate_type}
    */
    readonly certificateType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#custom_certificate_arn AmplifyDomain#custom_certificate_arn}
    */
    readonly customCertificateArn?: string;
}
export declare function amplifyDomainCertificateSettingsToTerraform(struct?: AmplifyDomainCertificateSettings | cdktn.IResolvable): any;
export declare function amplifyDomainCertificateSettingsToHclTerraform(struct?: AmplifyDomainCertificateSettings | cdktn.IResolvable): any;
export declare class AmplifyDomainCertificateSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyDomainCertificateSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyDomainCertificateSettings | cdktn.IResolvable | undefined);
    private _certificateType?;
    get certificateType(): string;
    set certificateType(value: string);
    resetCertificateType(): void;
    get certificateTypeInput(): string | undefined;
    private _customCertificateArn?;
    get customCertificateArn(): string;
    set customCertificateArn(value: string);
    resetCustomCertificateArn(): void;
    get customCertificateArnInput(): string | undefined;
}
export interface AmplifyDomainSubDomainSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#branch_name AmplifyDomain#branch_name}
    */
    readonly branchName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#prefix AmplifyDomain#prefix}
    */
    readonly prefix: string;
}
export declare function amplifyDomainSubDomainSettingsToTerraform(struct?: AmplifyDomainSubDomainSettings | cdktn.IResolvable): any;
export declare function amplifyDomainSubDomainSettingsToHclTerraform(struct?: AmplifyDomainSubDomainSettings | cdktn.IResolvable): any;
export declare class AmplifyDomainSubDomainSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmplifyDomainSubDomainSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyDomainSubDomainSettings | cdktn.IResolvable | undefined);
    private _branchName?;
    get branchName(): string;
    set branchName(value: string);
    get branchNameInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
}
export declare class AmplifyDomainSubDomainSettingsList extends cdktn.ComplexList {
    internalValue?: AmplifyDomainSubDomainSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmplifyDomainSubDomainSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain awscc_amplify_domain}
*/
export declare class AmplifyDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_amplify_domain";
    /**
    * Generates CDKTN code for importing a AmplifyDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AmplifyDomain to import
    * @param importFromId The id of the existing AmplifyDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AmplifyDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_domain awscc_amplify_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AmplifyDomainConfig
    */
    constructor(scope: Construct, id: string, config: AmplifyDomainConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    get arn(): string;
    private _autoSubDomainCreationPatterns?;
    get autoSubDomainCreationPatterns(): string[];
    set autoSubDomainCreationPatterns(value: string[]);
    resetAutoSubDomainCreationPatterns(): void;
    get autoSubDomainCreationPatternsInput(): string[] | undefined;
    private _autoSubDomainIamRole?;
    get autoSubDomainIamRole(): string;
    set autoSubDomainIamRole(value: string);
    resetAutoSubDomainIamRole(): void;
    get autoSubDomainIamRoleInput(): string | undefined;
    private _certificate;
    get certificate(): AmplifyDomainCertificateOutputReference;
    get certificateRecord(): string;
    private _certificateSettings;
    get certificateSettings(): AmplifyDomainCertificateSettingsOutputReference;
    putCertificateSettings(value: AmplifyDomainCertificateSettings): void;
    resetCertificateSettings(): void;
    get certificateSettingsInput(): cdktn.IResolvable | AmplifyDomainCertificateSettings | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get domainStatus(): string;
    private _enableAutoSubDomain?;
    get enableAutoSubDomain(): boolean | cdktn.IResolvable;
    set enableAutoSubDomain(value: boolean | cdktn.IResolvable);
    resetEnableAutoSubDomain(): void;
    get enableAutoSubDomainInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get statusReason(): string;
    private _subDomainSettings;
    get subDomainSettings(): AmplifyDomainSubDomainSettingsList;
    putSubDomainSettings(value: AmplifyDomainSubDomainSettings[] | cdktn.IResolvable): void;
    get subDomainSettingsInput(): cdktn.IResolvable | AmplifyDomainSubDomainSettings[] | undefined;
    get updateStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
