/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectPhoneNumberConfig extends cdktn.TerraformMetaArguments {
    /**
    * The phone number country code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#country_code ConnectPhoneNumber#country_code}
    */
    readonly countryCode?: string;
    /**
    * The description of the phone number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#description ConnectPhoneNumber#description}
    */
    readonly description?: string;
    /**
    * The phone number prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#prefix ConnectPhoneNumber#prefix}
    */
    readonly prefix?: string;
    /**
    * The source phone number arn.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#source_phone_number_arn ConnectPhoneNumber#source_phone_number_arn}
    */
    readonly sourcePhoneNumberArn?: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#tags ConnectPhoneNumber#tags}
    */
    readonly tags?: ConnectPhoneNumberTags[] | cdktn.IResolvable;
    /**
    * The ARN of the target the phone number is claimed to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#target_arn ConnectPhoneNumber#target_arn}
    */
    readonly targetArn: string;
    /**
    * The phone number type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#type ConnectPhoneNumber#type}
    */
    readonly type?: string;
}
export interface ConnectPhoneNumberTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#key ConnectPhoneNumber#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#value ConnectPhoneNumber#value}
    */
    readonly value?: string;
}
export declare function connectPhoneNumberTagsToTerraform(struct?: ConnectPhoneNumberTags | cdktn.IResolvable): any;
export declare function connectPhoneNumberTagsToHclTerraform(struct?: ConnectPhoneNumberTags | cdktn.IResolvable): any;
export declare class ConnectPhoneNumberTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectPhoneNumberTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectPhoneNumberTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectPhoneNumberTagsList extends cdktn.ComplexList {
    internalValue?: ConnectPhoneNumberTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectPhoneNumberTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number awscc_connect_phone_number}
*/
export declare class ConnectPhoneNumber extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_phone_number";
    /**
    * Generates CDKTN code for importing a ConnectPhoneNumber resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectPhoneNumber to import
    * @param importFromId The id of the existing ConnectPhoneNumber that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectPhoneNumber to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_phone_number awscc_connect_phone_number} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectPhoneNumberConfig
    */
    constructor(scope: Construct, id: string, config: ConnectPhoneNumberConfig);
    get address(): string;
    private _countryCode?;
    get countryCode(): string;
    set countryCode(value: string);
    resetCountryCode(): void;
    get countryCodeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get phoneNumberArn(): string;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _sourcePhoneNumberArn?;
    get sourcePhoneNumberArn(): string;
    set sourcePhoneNumberArn(value: string);
    resetSourcePhoneNumberArn(): void;
    get sourcePhoneNumberArnInput(): string | undefined;
    private _tags;
    get tags(): ConnectPhoneNumberTagsList;
    putTags(value: ConnectPhoneNumberTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectPhoneNumberTags[] | undefined;
    private _targetArn?;
    get targetArn(): string;
    set targetArn(value: string);
    get targetArnInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
