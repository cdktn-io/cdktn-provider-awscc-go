/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChatbotMicrosoftTeamsChannelConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#configuration_name ChatbotMicrosoftTeamsChannelConfiguration#configuration_name}
    */
    readonly configurationName: string;
    /**
    * ARNs of Custom Actions to associate with notifications in the provided chat channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#customization_resource_arns ChatbotMicrosoftTeamsChannelConfiguration#customization_resource_arns}
    */
    readonly customizationResourceArns?: string[];
    /**
    * The list of IAM policy ARNs that are applied as channel guardrails. The AWS managed 'AdministratorAccess' policy is applied as a default if this is not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#guardrail_policies ChatbotMicrosoftTeamsChannelConfiguration#guardrail_policies}
    */
    readonly guardrailPolicies?: string[];
    /**
    * The ARN of the IAM role that defines the permissions for AWS Chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#iam_role_arn ChatbotMicrosoftTeamsChannelConfiguration#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Specifies the logging level for this configuration:ERROR,INFO or NONE. This property affects the log entries pushed to Amazon CloudWatch logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#logging_level ChatbotMicrosoftTeamsChannelConfiguration#logging_level}
    */
    readonly loggingLevel?: string;
    /**
    * ARNs of SNS topics which delivers notifications to AWS Chatbot, for example CloudWatch alarm notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#sns_topic_arns ChatbotMicrosoftTeamsChannelConfiguration#sns_topic_arns}
    */
    readonly snsTopicArns?: string[];
    /**
    * The tags to add to the configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#tags ChatbotMicrosoftTeamsChannelConfiguration#tags}
    */
    readonly tags?: ChatbotMicrosoftTeamsChannelConfigurationTags[] | cdktn.IResolvable;
    /**
    * The id of the Microsoft Teams team
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#team_id ChatbotMicrosoftTeamsChannelConfiguration#team_id}
    */
    readonly teamId: string;
    /**
    * The id of the Microsoft Teams channel
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#teams_channel_id ChatbotMicrosoftTeamsChannelConfiguration#teams_channel_id}
    */
    readonly teamsChannelId: string;
    /**
    * The name of the Microsoft Teams channel
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#teams_channel_name ChatbotMicrosoftTeamsChannelConfiguration#teams_channel_name}
    */
    readonly teamsChannelName?: string;
    /**
    * The id of the Microsoft Teams tenant
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#teams_tenant_id ChatbotMicrosoftTeamsChannelConfiguration#teams_tenant_id}
    */
    readonly teamsTenantId: string;
    /**
    * Enables use of a user role requirement in your chat configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#user_role_required ChatbotMicrosoftTeamsChannelConfiguration#user_role_required}
    */
    readonly userRoleRequired?: boolean | cdktn.IResolvable;
}
export interface ChatbotMicrosoftTeamsChannelConfigurationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#key ChatbotMicrosoftTeamsChannelConfiguration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#value ChatbotMicrosoftTeamsChannelConfiguration#value}
    */
    readonly value?: string;
}
export declare function chatbotMicrosoftTeamsChannelConfigurationTagsToTerraform(struct?: ChatbotMicrosoftTeamsChannelConfigurationTags | cdktn.IResolvable): any;
export declare function chatbotMicrosoftTeamsChannelConfigurationTagsToHclTerraform(struct?: ChatbotMicrosoftTeamsChannelConfigurationTags | cdktn.IResolvable): any;
export declare class ChatbotMicrosoftTeamsChannelConfigurationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChatbotMicrosoftTeamsChannelConfigurationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChatbotMicrosoftTeamsChannelConfigurationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChatbotMicrosoftTeamsChannelConfigurationTagsList extends cdktn.ComplexList {
    internalValue?: ChatbotMicrosoftTeamsChannelConfigurationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChatbotMicrosoftTeamsChannelConfigurationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration awscc_chatbot_microsoft_teams_channel_configuration}
*/
export declare class ChatbotMicrosoftTeamsChannelConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chatbot_microsoft_teams_channel_configuration";
    /**
    * Generates CDKTN code for importing a ChatbotMicrosoftTeamsChannelConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChatbotMicrosoftTeamsChannelConfiguration to import
    * @param importFromId The id of the existing ChatbotMicrosoftTeamsChannelConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChatbotMicrosoftTeamsChannelConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chatbot_microsoft_teams_channel_configuration awscc_chatbot_microsoft_teams_channel_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChatbotMicrosoftTeamsChannelConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: ChatbotMicrosoftTeamsChannelConfigurationConfig);
    get arn(): string;
    private _configurationName?;
    get configurationName(): string;
    set configurationName(value: string);
    get configurationNameInput(): string | undefined;
    private _customizationResourceArns?;
    get customizationResourceArns(): string[];
    set customizationResourceArns(value: string[]);
    resetCustomizationResourceArns(): void;
    get customizationResourceArnsInput(): string[] | undefined;
    private _guardrailPolicies?;
    get guardrailPolicies(): string[];
    set guardrailPolicies(value: string[]);
    resetGuardrailPolicies(): void;
    get guardrailPoliciesInput(): string[] | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    get id(): string;
    private _loggingLevel?;
    get loggingLevel(): string;
    set loggingLevel(value: string);
    resetLoggingLevel(): void;
    get loggingLevelInput(): string | undefined;
    private _snsTopicArns?;
    get snsTopicArns(): string[];
    set snsTopicArns(value: string[]);
    resetSnsTopicArns(): void;
    get snsTopicArnsInput(): string[] | undefined;
    private _tags;
    get tags(): ChatbotMicrosoftTeamsChannelConfigurationTagsList;
    putTags(value: ChatbotMicrosoftTeamsChannelConfigurationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChatbotMicrosoftTeamsChannelConfigurationTags[] | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _teamsChannelId?;
    get teamsChannelId(): string;
    set teamsChannelId(value: string);
    get teamsChannelIdInput(): string | undefined;
    private _teamsChannelName?;
    get teamsChannelName(): string;
    set teamsChannelName(value: string);
    resetTeamsChannelName(): void;
    get teamsChannelNameInput(): string | undefined;
    private _teamsTenantId?;
    get teamsTenantId(): string;
    set teamsTenantId(value: string);
    get teamsTenantIdInput(): string | undefined;
    private _userRoleRequired?;
    get userRoleRequired(): boolean | cdktn.IResolvable;
    set userRoleRequired(value: boolean | cdktn.IResolvable);
    resetUserRoleRequired(): void;
    get userRoleRequiredInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
