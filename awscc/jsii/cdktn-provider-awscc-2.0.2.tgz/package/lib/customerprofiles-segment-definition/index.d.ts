/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesSegmentDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the segment definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#description CustomerprofilesSegmentDefinition#description}
    */
    readonly description?: string;
    /**
    * The display name of the segment definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#display_name CustomerprofilesSegmentDefinition#display_name}
    */
    readonly displayName: string;
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#domain_name CustomerprofilesSegmentDefinition#domain_name}
    */
    readonly domainName: string;
    /**
    * The unique name of the segment definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#segment_definition_name CustomerprofilesSegmentDefinition#segment_definition_name}
    */
    readonly segmentDefinitionName: string;
    /**
    * An array that defines the set of segment criteria to evaluate when handling segment groups for the segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#segment_groups CustomerprofilesSegmentDefinition#segment_groups}
    */
    readonly segmentGroups?: CustomerprofilesSegmentDefinitionSegmentGroups;
    /**
    * The segment sort configuration for ordering segment results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#segment_sort CustomerprofilesSegmentDefinition#segment_sort}
    */
    readonly segmentSort?: CustomerprofilesSegmentDefinitionSegmentSort;
    /**
    * The SQL query that defines the segment criteria.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#segment_sql_query CustomerprofilesSegmentDefinition#segment_sql_query}
    */
    readonly segmentSqlQuery?: string;
    /**
    * The tags used to organize, track, or control access for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#tags CustomerprofilesSegmentDefinition#tags}
    */
    readonly tags?: CustomerprofilesSegmentDefinitionTags[] | cdktn.IResolvable;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRange {
    /**
    * The ending point for this overridden range. Positive numbers indicate how many days in the past data should be included, and negative numbers indicate how many days in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#end CustomerprofilesSegmentDefinition#end}
    */
    readonly end?: number;
    /**
    * The starting point for this overridden range. Positive numbers indicate how many days in the past data should be included, and negative numbers indicate how many days in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#start CustomerprofilesSegmentDefinition#start}
    */
    readonly start?: number;
    /**
    * The unit to be applied to the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#unit CustomerprofilesSegmentDefinition#unit}
    */
    readonly unit?: string;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRangeToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRange | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRangeToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRange | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRange | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRange | cdktn.IResolvable | undefined);
    private _end?;
    get end(): number;
    set end(value: number);
    resetEnd(): void;
    get endInput(): number | undefined;
    private _start?;
    get start(): number;
    set start(value: number);
    resetStart(): void;
    get startInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverrides {
    /**
    * Defines the range to be applied to the calculated attribute definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#range CustomerprofilesSegmentDefinition#range}
    */
    readonly range?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRange;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverrides | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverrides | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverrides | cdktn.IResolvable | undefined);
    private _range;
    get range(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRangeOutputReference;
    putRange(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRange): void;
    resetRange(): void;
    get rangeInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesRange | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes {
    /**
    * Overrides the condition block within the original calculated attribute definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#condition_overrides CustomerprofilesSegmentDefinition#condition_overrides}
    */
    readonly conditionOverrides?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverrides;
    /**
    * The type of segment dimension to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes | cdktn.IResolvable | undefined);
    private _conditionOverrides;
    get conditionOverrides(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverridesOutputReference;
    putConditionOverrides(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverrides): void;
    resetConditionOverrides(): void;
    get conditionOverridesInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesConditionOverrides | undefined;
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesOutputReference;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumber {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumberToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumber | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumberToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumber | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumber | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumber | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformation {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformationToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformation | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformationToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformation | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformation | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformation | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCity {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCityToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCity | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCityToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCity | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCity | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCity | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountry {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountryToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountry | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountryToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountry | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountry | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountry | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCounty {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountyToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCounty | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountyToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCounty | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCounty | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCounty | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCode {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCodeToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCode | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCodeToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCode | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCode | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCode | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvince {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvinceToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvince | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvinceToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvince | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvinceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvince | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvince | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressState {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressStateToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressState | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressStateToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressState | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressState | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressState | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddress {
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#city CustomerprofilesSegmentDefinition#city}
    */
    readonly city?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCity;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#country CustomerprofilesSegmentDefinition#country}
    */
    readonly country?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountry;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#county CustomerprofilesSegmentDefinition#county}
    */
    readonly county?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCounty;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#postal_code CustomerprofilesSegmentDefinition#postal_code}
    */
    readonly postalCode?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCode;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#province CustomerprofilesSegmentDefinition#province}
    */
    readonly province?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvince;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#state CustomerprofilesSegmentDefinition#state}
    */
    readonly state?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressState;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddress | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddress | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddress | cdktn.IResolvable | undefined);
    private _city;
    get city(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCityOutputReference;
    putCity(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCity): void;
    resetCity(): void;
    get cityInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCity | undefined;
    private _country;
    get country(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountryOutputReference;
    putCountry(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountry): void;
    resetCountry(): void;
    get countryInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountry | undefined;
    private _county;
    get county(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCountyOutputReference;
    putCounty(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCounty): void;
    resetCounty(): void;
    get countyInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressCounty | undefined;
    private _postalCode;
    get postalCode(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCodeOutputReference;
    putPostalCode(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCode): void;
    resetPostalCode(): void;
    get postalCodeInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressPostalCode | undefined;
    private _province;
    get province(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvinceOutputReference;
    putProvince(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvince): void;
    resetProvince(): void;
    get provinceInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressProvince | undefined;
    private _state;
    get state(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressStateOutputReference;
    putState(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressState): void;
    resetState(): void;
    get stateInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressState | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes {
    /**
    * The type of segment dimension to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributesToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributesToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributesMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributesOutputReference;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCity {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCityToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCity | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCityToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCity | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCity | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCity | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountry {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountryToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountry | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountryToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountry | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountry | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountry | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCounty {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountyToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCounty | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountyToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCounty | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCounty | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCounty | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCode {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCodeToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCode | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCodeToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCode | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCode | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCode | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvince {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvinceToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvince | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvinceToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvince | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvinceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvince | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvince | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressState {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressStateToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressState | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressStateToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressState | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressState | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressState | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddress {
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#city CustomerprofilesSegmentDefinition#city}
    */
    readonly city?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCity;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#country CustomerprofilesSegmentDefinition#country}
    */
    readonly country?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountry;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#county CustomerprofilesSegmentDefinition#county}
    */
    readonly county?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCounty;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#postal_code CustomerprofilesSegmentDefinition#postal_code}
    */
    readonly postalCode?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCode;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#province CustomerprofilesSegmentDefinition#province}
    */
    readonly province?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvince;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#state CustomerprofilesSegmentDefinition#state}
    */
    readonly state?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressState;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddress | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddress | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddress | cdktn.IResolvable | undefined);
    private _city;
    get city(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCityOutputReference;
    putCity(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCity): void;
    resetCity(): void;
    get cityInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCity | undefined;
    private _country;
    get country(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountryOutputReference;
    putCountry(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountry): void;
    resetCountry(): void;
    get countryInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountry | undefined;
    private _county;
    get county(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCountyOutputReference;
    putCounty(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCounty): void;
    resetCounty(): void;
    get countyInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressCounty | undefined;
    private _postalCode;
    get postalCode(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCodeOutputReference;
    putPostalCode(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCode): void;
    resetPostalCode(): void;
    get postalCodeInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressPostalCode | undefined;
    private _province;
    get province(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvinceOutputReference;
    putProvince(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvince): void;
    resetProvince(): void;
    get provinceInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressProvince | undefined;
    private _state;
    get state(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressStateOutputReference;
    putState(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressState): void;
    resetState(): void;
    get stateInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressState | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDate {
    /**
    * The type of segment dimension to use for a date dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDateToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDate | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDateToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDate | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDate | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDate | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddress {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddressToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddress | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddressToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddress | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddress | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessName {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessNameToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessName | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessNameToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessName | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessName | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessName | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumber {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumberToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumber | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumberToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumber | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumber | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumber | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddress {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddressToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddress | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddressToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddress | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddress | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstName {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstNameToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstName | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstNameToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstName | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstName | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstName | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderString {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderStringToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderString | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderStringToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderString | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderString | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderString | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumber {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumberToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumber | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumberToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumber | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumber | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumber | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastName {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastNameToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastName | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastNameToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastName | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastName | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastName | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCity {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCityToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCity | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCityToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCity | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCity | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCity | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountry {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountryToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountry | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountryToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountry | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountry | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountry | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCounty {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountyToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCounty | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountyToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCounty | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCounty | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCounty | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCode {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCodeToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCode | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCodeToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCode | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCode | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCode | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvince {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvinceToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvince | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvinceToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvince | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvinceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvince | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvince | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressState {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressStateToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressState | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressStateToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressState | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressState | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressState | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddress {
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#city CustomerprofilesSegmentDefinition#city}
    */
    readonly city?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCity;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#country CustomerprofilesSegmentDefinition#country}
    */
    readonly country?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountry;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#county CustomerprofilesSegmentDefinition#county}
    */
    readonly county?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCounty;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#postal_code CustomerprofilesSegmentDefinition#postal_code}
    */
    readonly postalCode?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCode;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#province CustomerprofilesSegmentDefinition#province}
    */
    readonly province?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvince;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#state CustomerprofilesSegmentDefinition#state}
    */
    readonly state?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressState;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddress | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddress | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddress | cdktn.IResolvable | undefined);
    private _city;
    get city(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCityOutputReference;
    putCity(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCity): void;
    resetCity(): void;
    get cityInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCity | undefined;
    private _country;
    get country(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountryOutputReference;
    putCountry(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountry): void;
    resetCountry(): void;
    get countryInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountry | undefined;
    private _county;
    get county(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCountyOutputReference;
    putCounty(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCounty): void;
    resetCounty(): void;
    get countyInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressCounty | undefined;
    private _postalCode;
    get postalCode(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCodeOutputReference;
    putPostalCode(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCode): void;
    resetPostalCode(): void;
    get postalCodeInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressPostalCode | undefined;
    private _province;
    get province(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvinceOutputReference;
    putProvince(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvince): void;
    resetProvince(): void;
    get provinceInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressProvince | undefined;
    private _state;
    get state(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressStateOutputReference;
    putState(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressState): void;
    resetState(): void;
    get stateInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressState | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleName {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleNameToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleName | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleNameToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleName | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleName | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleName | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumber {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumberToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumber | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumberToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumber | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumber | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumber | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeString {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeStringToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeString | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeStringToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeString | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeString | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeString | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddress {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddressToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddress | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddressToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddress | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddress | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumber {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumberToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumber | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumberToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumber | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumber | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumber | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileType {
    /**
    * The type of segment dimension to use for a profile type dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileTypeToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileType | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileTypeToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileType | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileType | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileType | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCity {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCityToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCity | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCityToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCity | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCity | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCity | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountry {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountryToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountry | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountryToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountry | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountry | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountry | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCounty {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountyToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCounty | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountyToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCounty | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCounty | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCounty | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCode {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCodeToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCode | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCodeToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCode | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCode | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCode | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvince {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvinceToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvince | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvinceToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvince | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvinceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvince | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvince | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressState {
    /**
    * The type of segment dimension to use for a string dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimension_type CustomerprofilesSegmentDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#values CustomerprofilesSegmentDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressStateToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressState | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressStateToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressState | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressState | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressState | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddress {
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#city CustomerprofilesSegmentDefinition#city}
    */
    readonly city?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCity;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#country CustomerprofilesSegmentDefinition#country}
    */
    readonly country?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountry;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#county CustomerprofilesSegmentDefinition#county}
    */
    readonly county?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCounty;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#postal_code CustomerprofilesSegmentDefinition#postal_code}
    */
    readonly postalCode?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCode;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#province CustomerprofilesSegmentDefinition#province}
    */
    readonly province?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvince;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#state CustomerprofilesSegmentDefinition#state}
    */
    readonly state?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressState;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddress | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddress | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddress | cdktn.IResolvable | undefined);
    private _city;
    get city(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCityOutputReference;
    putCity(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCity): void;
    resetCity(): void;
    get cityInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCity | undefined;
    private _country;
    get country(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountryOutputReference;
    putCountry(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountry): void;
    resetCountry(): void;
    get countryInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountry | undefined;
    private _county;
    get county(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCountyOutputReference;
    putCounty(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCounty): void;
    resetCounty(): void;
    get countyInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressCounty | undefined;
    private _postalCode;
    get postalCode(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCodeOutputReference;
    putPostalCode(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCode): void;
    resetPostalCode(): void;
    get postalCodeInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressPostalCode | undefined;
    private _province;
    get province(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvinceOutputReference;
    putProvince(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvince): void;
    resetProvince(): void;
    get provinceInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressProvince | undefined;
    private _state;
    get state(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressStateOutputReference;
    putState(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressState): void;
    resetState(): void;
    get stateInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressState | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributes {
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#account_number CustomerprofilesSegmentDefinition#account_number}
    */
    readonly accountNumber?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumber;
    /**
    * Specifies criteria for a segment using extended-length string values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#additional_information CustomerprofilesSegmentDefinition#additional_information}
    */
    readonly additionalInformation?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformation;
    /**
    * The address based criteria for the segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#address CustomerprofilesSegmentDefinition#address}
    */
    readonly address?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddress;
    /**
    * One or more custom attributes to use as criteria for the segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#attributes CustomerprofilesSegmentDefinition#attributes}
    */
    readonly attributes?: {
        [key: string]: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes;
    } | cdktn.IResolvable;
    /**
    * The address based criteria for the segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#billing_address CustomerprofilesSegmentDefinition#billing_address}
    */
    readonly billingAddress?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddress;
    /**
    * Specifies date based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#birth_date CustomerprofilesSegmentDefinition#birth_date}
    */
    readonly birthDate?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDate;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#business_email_address CustomerprofilesSegmentDefinition#business_email_address}
    */
    readonly businessEmailAddress?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddress;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#business_name CustomerprofilesSegmentDefinition#business_name}
    */
    readonly businessName?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessName;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#business_phone_number CustomerprofilesSegmentDefinition#business_phone_number}
    */
    readonly businessPhoneNumber?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumber;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#email_address CustomerprofilesSegmentDefinition#email_address}
    */
    readonly emailAddress?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddress;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#first_name CustomerprofilesSegmentDefinition#first_name}
    */
    readonly firstName?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstName;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#gender_string CustomerprofilesSegmentDefinition#gender_string}
    */
    readonly genderString?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderString;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#home_phone_number CustomerprofilesSegmentDefinition#home_phone_number}
    */
    readonly homePhoneNumber?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumber;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#last_name CustomerprofilesSegmentDefinition#last_name}
    */
    readonly lastName?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastName;
    /**
    * The address based criteria for the segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#mailing_address CustomerprofilesSegmentDefinition#mailing_address}
    */
    readonly mailingAddress?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddress;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#middle_name CustomerprofilesSegmentDefinition#middle_name}
    */
    readonly middleName?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleName;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#mobile_phone_number CustomerprofilesSegmentDefinition#mobile_phone_number}
    */
    readonly mobilePhoneNumber?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumber;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#party_type_string CustomerprofilesSegmentDefinition#party_type_string}
    */
    readonly partyTypeString?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeString;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#personal_email_address CustomerprofilesSegmentDefinition#personal_email_address}
    */
    readonly personalEmailAddress?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddress;
    /**
    * Specifies profile based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#phone_number CustomerprofilesSegmentDefinition#phone_number}
    */
    readonly phoneNumber?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumber;
    /**
    * Specifies profile type based criteria for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#profile_type CustomerprofilesSegmentDefinition#profile_type}
    */
    readonly profileType?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileType;
    /**
    * The address based criteria for the segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#shipping_address CustomerprofilesSegmentDefinition#shipping_address}
    */
    readonly shippingAddress?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddress;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributes | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributes | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributes | cdktn.IResolvable | undefined);
    private _accountNumber;
    get accountNumber(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumberOutputReference;
    putAccountNumber(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumber): void;
    resetAccountNumber(): void;
    get accountNumberInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAccountNumber | undefined;
    private _additionalInformation;
    get additionalInformation(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformationOutputReference;
    putAdditionalInformation(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformation): void;
    resetAdditionalInformation(): void;
    get additionalInformationInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAdditionalInformation | undefined;
    private _address;
    get address(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddressOutputReference;
    putAddress(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddress): void;
    resetAddress(): void;
    get addressInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAddress | undefined;
    private _attributes;
    get attributes(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributesMap;
    putAttributes(value: {
        [key: string]: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes;
    } | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | {
        [key: string]: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesAttributes;
    } | undefined;
    private _billingAddress;
    get billingAddress(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddressOutputReference;
    putBillingAddress(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddress): void;
    resetBillingAddress(): void;
    get billingAddressInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBillingAddress | undefined;
    private _birthDate;
    get birthDate(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDateOutputReference;
    putBirthDate(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDate): void;
    resetBirthDate(): void;
    get birthDateInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBirthDate | undefined;
    private _businessEmailAddress;
    get businessEmailAddress(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddressOutputReference;
    putBusinessEmailAddress(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddress): void;
    resetBusinessEmailAddress(): void;
    get businessEmailAddressInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessEmailAddress | undefined;
    private _businessName;
    get businessName(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessNameOutputReference;
    putBusinessName(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessName): void;
    resetBusinessName(): void;
    get businessNameInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessName | undefined;
    private _businessPhoneNumber;
    get businessPhoneNumber(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumberOutputReference;
    putBusinessPhoneNumber(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumber): void;
    resetBusinessPhoneNumber(): void;
    get businessPhoneNumberInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesBusinessPhoneNumber | undefined;
    private _emailAddress;
    get emailAddress(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddressOutputReference;
    putEmailAddress(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddress): void;
    resetEmailAddress(): void;
    get emailAddressInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesEmailAddress | undefined;
    private _firstName;
    get firstName(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstNameOutputReference;
    putFirstName(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstName): void;
    resetFirstName(): void;
    get firstNameInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesFirstName | undefined;
    private _genderString;
    get genderString(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderStringOutputReference;
    putGenderString(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderString): void;
    resetGenderString(): void;
    get genderStringInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesGenderString | undefined;
    private _homePhoneNumber;
    get homePhoneNumber(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumberOutputReference;
    putHomePhoneNumber(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumber): void;
    resetHomePhoneNumber(): void;
    get homePhoneNumberInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesHomePhoneNumber | undefined;
    private _lastName;
    get lastName(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastNameOutputReference;
    putLastName(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastName): void;
    resetLastName(): void;
    get lastNameInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesLastName | undefined;
    private _mailingAddress;
    get mailingAddress(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddressOutputReference;
    putMailingAddress(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddress): void;
    resetMailingAddress(): void;
    get mailingAddressInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMailingAddress | undefined;
    private _middleName;
    get middleName(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleNameOutputReference;
    putMiddleName(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleName): void;
    resetMiddleName(): void;
    get middleNameInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMiddleName | undefined;
    private _mobilePhoneNumber;
    get mobilePhoneNumber(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumberOutputReference;
    putMobilePhoneNumber(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumber): void;
    resetMobilePhoneNumber(): void;
    get mobilePhoneNumberInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesMobilePhoneNumber | undefined;
    private _partyTypeString;
    get partyTypeString(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeStringOutputReference;
    putPartyTypeString(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeString): void;
    resetPartyTypeString(): void;
    get partyTypeStringInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPartyTypeString | undefined;
    private _personalEmailAddress;
    get personalEmailAddress(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddressOutputReference;
    putPersonalEmailAddress(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddress): void;
    resetPersonalEmailAddress(): void;
    get personalEmailAddressInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPersonalEmailAddress | undefined;
    private _phoneNumber;
    get phoneNumber(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumberOutputReference;
    putPhoneNumber(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumber): void;
    resetPhoneNumber(): void;
    get phoneNumberInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesPhoneNumber | undefined;
    private _profileType;
    get profileType(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileTypeOutputReference;
    putProfileType(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileType): void;
    resetProfileType(): void;
    get profileTypeInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesProfileType | undefined;
    private _shippingAddress;
    get shippingAddress(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddressOutputReference;
    putShippingAddress(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddress): void;
    resetShippingAddress(): void;
    get shippingAddressInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesShippingAddress | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions {
    /**
    * One or more calculated attributes to use as criteria for the segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#calculated_attributes CustomerprofilesSegmentDefinition#calculated_attributes}
    */
    readonly calculatedAttributes?: {
        [key: string]: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes;
    } | cdktn.IResolvable;
    /**
    * Specifies the dimension settings within profile attributes for a segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#profile_attributes CustomerprofilesSegmentDefinition#profile_attributes}
    */
    readonly profileAttributes?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributes;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions | cdktn.IResolvable | undefined);
    private _calculatedAttributes;
    get calculatedAttributes(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributesMap;
    putCalculatedAttributes(value: {
        [key: string]: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes;
    } | cdktn.IResolvable): void;
    resetCalculatedAttributes(): void;
    get calculatedAttributesInput(): cdktn.IResolvable | {
        [key: string]: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsCalculatedAttributes;
    } | undefined;
    private _profileAttributes;
    get profileAttributes(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributesOutputReference;
    putProfileAttributes(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributes): void;
    resetProfileAttributes(): void;
    get profileAttributesInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsProfileAttributes | undefined;
}
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsOutputReference;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#segment_definition_name CustomerprofilesSegmentDefinition#segment_definition_name}
    */
    readonly segmentDefinitionName?: string;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegmentsToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegmentsToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments | cdktn.IResolvable | undefined);
    private _segmentDefinitionName?;
    get segmentDefinitionName(): string;
    set segmentDefinitionName(value: string);
    resetSegmentDefinitionName(): void;
    get segmentDefinitionNameInput(): string | undefined;
}
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegmentsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegmentsOutputReference;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroupsGroups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#dimensions CustomerprofilesSegmentDefinition#dimensions}
    */
    readonly dimensions?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#source_segments CustomerprofilesSegmentDefinition#source_segments}
    */
    readonly sourceSegments?: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments[] | cdktn.IResolvable;
    /**
    * Specifies the operator on how to handle multiple groups within the same segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#source_type CustomerprofilesSegmentDefinition#source_type}
    */
    readonly sourceType?: string;
    /**
    * Specifies the operator on how to handle multiple groups within the same segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#type CustomerprofilesSegmentDefinition#type}
    */
    readonly type?: string;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroups | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsGroupsToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroupsGroups | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroupsGroups | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroups | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensionsList;
    putDimensions(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsDimensions[] | undefined;
    private _sourceSegments;
    get sourceSegments(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegmentsList;
    putSourceSegments(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments[] | cdktn.IResolvable): void;
    resetSourceSegments(): void;
    get sourceSegmentsInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroupsSourceSegments[] | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    resetSourceType(): void;
    get sourceTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsGroupsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesSegmentDefinitionSegmentGroupsGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsOutputReference;
}
export interface CustomerprofilesSegmentDefinitionSegmentGroups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#groups CustomerprofilesSegmentDefinition#groups}
    */
    readonly groups?: CustomerprofilesSegmentDefinitionSegmentGroupsGroups[] | cdktn.IResolvable;
    /**
    * Specifies the operator on how to handle multiple groups within the same segment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#include CustomerprofilesSegmentDefinition#include}
    */
    readonly include?: string;
}
export declare function customerprofilesSegmentDefinitionSegmentGroupsToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroups | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentGroupsToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentGroups | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentGroups | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentGroups | cdktn.IResolvable | undefined);
    private _groups;
    get groups(): CustomerprofilesSegmentDefinitionSegmentGroupsGroupsList;
    putGroups(value: CustomerprofilesSegmentDefinitionSegmentGroupsGroups[] | cdktn.IResolvable): void;
    resetGroups(): void;
    get groupsInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroupsGroups[] | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    resetInclude(): void;
    get includeInput(): string | undefined;
}
export interface CustomerprofilesSegmentDefinitionSegmentSortAttributes {
    /**
    * The data type of the sort attribute (e.g., string, number, date).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#data_type CustomerprofilesSegmentDefinition#data_type}
    */
    readonly dataType?: string;
    /**
    * The name of the attribute to sort by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#name CustomerprofilesSegmentDefinition#name}
    */
    readonly name?: string;
    /**
    * The sort order for the attribute (ascending or descending).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#order CustomerprofilesSegmentDefinition#order}
    */
    readonly order?: string;
    /**
    * The type of attribute (e.g., profile, calculated).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#type CustomerprofilesSegmentDefinition#type}
    */
    readonly type?: string;
}
export declare function customerprofilesSegmentDefinitionSegmentSortAttributesToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentSortAttributes | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentSortAttributesToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentSortAttributes | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentSortAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentSortAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentSortAttributes | cdktn.IResolvable | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    resetDataType(): void;
    get dataTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CustomerprofilesSegmentDefinitionSegmentSortAttributesList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesSegmentDefinitionSegmentSortAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesSegmentDefinitionSegmentSortAttributesOutputReference;
}
export interface CustomerprofilesSegmentDefinitionSegmentSort {
    /**
    * A list of attributes used to sort the segments and their ordering preferences.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#attributes CustomerprofilesSegmentDefinition#attributes}
    */
    readonly attributes?: CustomerprofilesSegmentDefinitionSegmentSortAttributes[] | cdktn.IResolvable;
}
export declare function customerprofilesSegmentDefinitionSegmentSortToTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentSort | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionSegmentSortToHclTerraform(struct?: CustomerprofilesSegmentDefinitionSegmentSort | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionSegmentSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesSegmentDefinitionSegmentSort | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionSegmentSort | cdktn.IResolvable | undefined);
    private _attributes;
    get attributes(): CustomerprofilesSegmentDefinitionSegmentSortAttributesList;
    putAttributes(value: CustomerprofilesSegmentDefinitionSegmentSortAttributes[] | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentSortAttributes[] | undefined;
}
export interface CustomerprofilesSegmentDefinitionTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#key CustomerprofilesSegmentDefinition#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#value CustomerprofilesSegmentDefinition#value}
    */
    readonly value?: string;
}
export declare function customerprofilesSegmentDefinitionTagsToTerraform(struct?: CustomerprofilesSegmentDefinitionTags | cdktn.IResolvable): any;
export declare function customerprofilesSegmentDefinitionTagsToHclTerraform(struct?: CustomerprofilesSegmentDefinitionTags | cdktn.IResolvable): any;
export declare class CustomerprofilesSegmentDefinitionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesSegmentDefinitionTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesSegmentDefinitionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesSegmentDefinitionTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesSegmentDefinitionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesSegmentDefinitionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition awscc_customerprofiles_segment_definition}
*/
export declare class CustomerprofilesSegmentDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_segment_definition";
    /**
    * Generates CDKTN code for importing a CustomerprofilesSegmentDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesSegmentDefinition to import
    * @param importFromId The id of the existing CustomerprofilesSegmentDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesSegmentDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_segment_definition awscc_customerprofiles_segment_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesSegmentDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesSegmentDefinitionConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get id(): string;
    get segmentDefinitionArn(): string;
    private _segmentDefinitionName?;
    get segmentDefinitionName(): string;
    set segmentDefinitionName(value: string);
    get segmentDefinitionNameInput(): string | undefined;
    private _segmentGroups;
    get segmentGroups(): CustomerprofilesSegmentDefinitionSegmentGroupsOutputReference;
    putSegmentGroups(value: CustomerprofilesSegmentDefinitionSegmentGroups): void;
    resetSegmentGroups(): void;
    get segmentGroupsInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentGroups | undefined;
    private _segmentSort;
    get segmentSort(): CustomerprofilesSegmentDefinitionSegmentSortOutputReference;
    putSegmentSort(value: CustomerprofilesSegmentDefinitionSegmentSort): void;
    resetSegmentSort(): void;
    get segmentSortInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionSegmentSort | undefined;
    private _segmentSqlQuery?;
    get segmentSqlQuery(): string;
    set segmentSqlQuery(value: string);
    resetSegmentSqlQuery(): void;
    get segmentSqlQueryInput(): string | undefined;
    get segmentType(): string;
    private _tags;
    get tags(): CustomerprofilesSegmentDefinitionTagsList;
    putTags(value: CustomerprofilesSegmentDefinitionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesSegmentDefinitionTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
