/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CeAnomalyMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * The dimensions to evaluate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor#monitor_dimension CeAnomalyMonitor#monitor_dimension}
    */
    readonly monitorDimension?: string;
    /**
    * The name of the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor#monitor_name CeAnomalyMonitor#monitor_name}
    */
    readonly monitorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor#monitor_specification CeAnomalyMonitor#monitor_specification}
    */
    readonly monitorSpecification?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor#monitor_type CeAnomalyMonitor#monitor_type}
    */
    readonly monitorType: string;
    /**
    * Tags to assign to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor#resource_tags CeAnomalyMonitor#resource_tags}
    */
    readonly resourceTags?: CeAnomalyMonitorResourceTags[] | cdktn.IResolvable;
}
export interface CeAnomalyMonitorResourceTags {
    /**
    * The key name for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor#key CeAnomalyMonitor#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor#value CeAnomalyMonitor#value}
    */
    readonly value?: string;
}
export declare function ceAnomalyMonitorResourceTagsToTerraform(struct?: CeAnomalyMonitorResourceTags | cdktn.IResolvable): any;
export declare function ceAnomalyMonitorResourceTagsToHclTerraform(struct?: CeAnomalyMonitorResourceTags | cdktn.IResolvable): any;
export declare class CeAnomalyMonitorResourceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CeAnomalyMonitorResourceTags | cdktn.IResolvable | undefined;
    set internalValue(value: CeAnomalyMonitorResourceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CeAnomalyMonitorResourceTagsList extends cdktn.ComplexList {
    internalValue?: CeAnomalyMonitorResourceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CeAnomalyMonitorResourceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor awscc_ce_anomaly_monitor}
*/
export declare class CeAnomalyMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_ce_anomaly_monitor";
    /**
    * Generates CDKTN code for importing a CeAnomalyMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CeAnomalyMonitor to import
    * @param importFromId The id of the existing CeAnomalyMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CeAnomalyMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_monitor awscc_ce_anomaly_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CeAnomalyMonitorConfig
    */
    constructor(scope: Construct, id: string, config: CeAnomalyMonitorConfig);
    get creationDate(): string;
    get dimensionalValueCount(): number;
    get id(): string;
    get lastEvaluatedDate(): string;
    get lastUpdatedDate(): string;
    get monitorArn(): string;
    private _monitorDimension?;
    get monitorDimension(): string;
    set monitorDimension(value: string);
    resetMonitorDimension(): void;
    get monitorDimensionInput(): string | undefined;
    private _monitorName?;
    get monitorName(): string;
    set monitorName(value: string);
    get monitorNameInput(): string | undefined;
    private _monitorSpecification?;
    get monitorSpecification(): string;
    set monitorSpecification(value: string);
    resetMonitorSpecification(): void;
    get monitorSpecificationInput(): string | undefined;
    private _monitorType?;
    get monitorType(): string;
    set monitorType(value: string);
    get monitorTypeInput(): string | undefined;
    private _resourceTags;
    get resourceTags(): CeAnomalyMonitorResourceTagsList;
    putResourceTags(value: CeAnomalyMonitorResourceTags[] | cdktn.IResolvable): void;
    resetResourceTags(): void;
    get resourceTagsInput(): cdktn.IResolvable | CeAnomalyMonitorResourceTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
