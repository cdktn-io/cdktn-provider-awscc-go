/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigExperimentRunConfig extends cdktn.TerraformMetaArguments {
    /**
    * The application name or ID used to create the experiment run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#application_identifier AppconfigExperimentRun#application_identifier}
    */
    readonly applicationIdentifier: string;
    /**
    * Description of the experiment run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#description AppconfigExperimentRun#description}
    */
    readonly description?: string;
    /**
    * The experiment definition name or ID used to create the experiment run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#experiment_definition_identifier AppconfigExperimentRun#experiment_definition_identifier}
    */
    readonly experimentDefinitionIdentifier: string;
    /**
    * Percentage of traffic exposed to the experiment (0-100).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#exposure_percentage AppconfigExperimentRun#exposure_percentage}
    */
    readonly exposurePercentage: number;
    /**
    * Tags to associate with the experiment run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#tags AppconfigExperimentRun#tags}
    */
    readonly tags?: AppconfigExperimentRunTags[] | cdktn.IResolvable;
    /**
    * Treatment overrides for specific entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#treatment_overrides AppconfigExperimentRun#treatment_overrides}
    */
    readonly treatmentOverrides?: AppconfigExperimentRunTreatmentOverrides;
}
export interface AppconfigExperimentRunTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#key AppconfigExperimentRun#key}
    */
    readonly key?: string;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#value AppconfigExperimentRun#value}
    */
    readonly value?: string;
}
export declare function appconfigExperimentRunTagsToTerraform(struct?: AppconfigExperimentRunTags | cdktn.IResolvable): any;
export declare function appconfigExperimentRunTagsToHclTerraform(struct?: AppconfigExperimentRunTags | cdktn.IResolvable): any;
export declare class AppconfigExperimentRunTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigExperimentRunTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExperimentRunTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppconfigExperimentRunTagsList extends cdktn.ComplexList {
    internalValue?: AppconfigExperimentRunTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigExperimentRunTagsOutputReference;
}
export interface AppconfigExperimentRunTreatmentOverrides {
    /**
    * Map of entity ID to treatment key (t1, t2, ..., or c for control).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#inline AppconfigExperimentRun#inline}
    */
    readonly inline?: {
        [key: string]: string;
    };
}
export declare function appconfigExperimentRunTreatmentOverridesToTerraform(struct?: AppconfigExperimentRunTreatmentOverrides | cdktn.IResolvable): any;
export declare function appconfigExperimentRunTreatmentOverridesToHclTerraform(struct?: AppconfigExperimentRunTreatmentOverrides | cdktn.IResolvable): any;
export declare class AppconfigExperimentRunTreatmentOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppconfigExperimentRunTreatmentOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExperimentRunTreatmentOverrides | cdktn.IResolvable | undefined);
    private _inline?;
    get inline(): {
        [key: string]: string;
    };
    set inline(value: {
        [key: string]: string;
    });
    resetInline(): void;
    get inlineInput(): {
        [key: string]: string;
    } | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run awscc_appconfig_experiment_run}
*/
export declare class AppconfigExperimentRun extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appconfig_experiment_run";
    /**
    * Generates CDKTN code for importing a AppconfigExperimentRun resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigExperimentRun to import
    * @param importFromId The id of the existing AppconfigExperimentRun that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigExperimentRun to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_experiment_run awscc_appconfig_experiment_run} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigExperimentRunConfig
    */
    constructor(scope: Construct, id: string, config: AppconfigExperimentRunConfig);
    get applicationId(): string;
    private _applicationIdentifier?;
    get applicationIdentifier(): string;
    set applicationIdentifier(value: string);
    get applicationIdentifierInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get experimentDefinitionId(): string;
    private _experimentDefinitionIdentifier?;
    get experimentDefinitionIdentifier(): string;
    set experimentDefinitionIdentifier(value: string);
    get experimentDefinitionIdentifierInput(): string | undefined;
    private _exposurePercentage?;
    get exposurePercentage(): number;
    set exposurePercentage(value: number);
    get exposurePercentageInput(): number | undefined;
    get id(): string;
    get run(): string;
    get startedAt(): string;
    get status(): string;
    private _tags;
    get tags(): AppconfigExperimentRunTagsList;
    putTags(value: AppconfigExperimentRunTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppconfigExperimentRunTags[] | undefined;
    private _treatmentOverrides;
    get treatmentOverrides(): AppconfigExperimentRunTreatmentOverridesOutputReference;
    putTreatmentOverrides(value: AppconfigExperimentRunTreatmentOverrides): void;
    resetTreatmentOverrides(): void;
    get treatmentOverridesInput(): cdktn.IResolvable | AppconfigExperimentRunTreatmentOverrides | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
