/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamImageBuilderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#access_endpoints AppstreamImageBuilder#access_endpoints}
    */
    readonly accessEndpoints?: AppstreamImageBuilderAccessEndpoints[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#appstream_agent_version AppstreamImageBuilder#appstream_agent_version}
    */
    readonly appstreamAgentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#description AppstreamImageBuilder#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#disable_imdsv1 AppstreamImageBuilder#disable_imdsv1}
    */
    readonly disableImdsv1?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#display_name AppstreamImageBuilder#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#domain_join_info AppstreamImageBuilder#domain_join_info}
    */
    readonly domainJoinInfo?: AppstreamImageBuilderDomainJoinInfo;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#enable_default_internet_access AppstreamImageBuilder#enable_default_internet_access}
    */
    readonly enableDefaultInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#iam_role_arn AppstreamImageBuilder#iam_role_arn}
    */
    readonly iamRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#image_arn AppstreamImageBuilder#image_arn}
    */
    readonly imageArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#image_name AppstreamImageBuilder#image_name}
    */
    readonly imageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#instance_type AppstreamImageBuilder#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#name AppstreamImageBuilder#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#root_volume_config AppstreamImageBuilder#root_volume_config}
    */
    readonly rootVolumeConfig?: AppstreamImageBuilderRootVolumeConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#softwares_to_install AppstreamImageBuilder#softwares_to_install}
    */
    readonly softwaresToInstall?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#softwares_to_uninstall AppstreamImageBuilder#softwares_to_uninstall}
    */
    readonly softwaresToUninstall?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#tags AppstreamImageBuilder#tags}
    */
    readonly tags?: AppstreamImageBuilderTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#vpc_config AppstreamImageBuilder#vpc_config}
    */
    readonly vpcConfig?: AppstreamImageBuilderVpcConfig;
}
export interface AppstreamImageBuilderAccessEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#endpoint_type AppstreamImageBuilder#endpoint_type}
    */
    readonly endpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#vpce_id AppstreamImageBuilder#vpce_id}
    */
    readonly vpceId?: string;
}
export declare function appstreamImageBuilderAccessEndpointsToTerraform(struct?: AppstreamImageBuilderAccessEndpoints | cdktn.IResolvable): any;
export declare function appstreamImageBuilderAccessEndpointsToHclTerraform(struct?: AppstreamImageBuilderAccessEndpoints | cdktn.IResolvable): any;
export declare class AppstreamImageBuilderAccessEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamImageBuilderAccessEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamImageBuilderAccessEndpoints | cdktn.IResolvable | undefined);
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    resetEndpointType(): void;
    get endpointTypeInput(): string | undefined;
    private _vpceId?;
    get vpceId(): string;
    set vpceId(value: string);
    resetVpceId(): void;
    get vpceIdInput(): string | undefined;
}
export declare class AppstreamImageBuilderAccessEndpointsList extends cdktn.ComplexList {
    internalValue?: AppstreamImageBuilderAccessEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamImageBuilderAccessEndpointsOutputReference;
}
export interface AppstreamImageBuilderDomainJoinInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#directory_name AppstreamImageBuilder#directory_name}
    */
    readonly directoryName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#organizational_unit_distinguished_name AppstreamImageBuilder#organizational_unit_distinguished_name}
    */
    readonly organizationalUnitDistinguishedName?: string;
}
export declare function appstreamImageBuilderDomainJoinInfoToTerraform(struct?: AppstreamImageBuilderDomainJoinInfo | cdktn.IResolvable): any;
export declare function appstreamImageBuilderDomainJoinInfoToHclTerraform(struct?: AppstreamImageBuilderDomainJoinInfo | cdktn.IResolvable): any;
export declare class AppstreamImageBuilderDomainJoinInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamImageBuilderDomainJoinInfo | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamImageBuilderDomainJoinInfo | cdktn.IResolvable | undefined);
    private _directoryName?;
    get directoryName(): string;
    set directoryName(value: string);
    resetDirectoryName(): void;
    get directoryNameInput(): string | undefined;
    private _organizationalUnitDistinguishedName?;
    get organizationalUnitDistinguishedName(): string;
    set organizationalUnitDistinguishedName(value: string);
    resetOrganizationalUnitDistinguishedName(): void;
    get organizationalUnitDistinguishedNameInput(): string | undefined;
}
export interface AppstreamImageBuilderRootVolumeConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#volume_size_in_gb AppstreamImageBuilder#volume_size_in_gb}
    */
    readonly volumeSizeInGb?: number;
}
export declare function appstreamImageBuilderRootVolumeConfigToTerraform(struct?: AppstreamImageBuilderRootVolumeConfig | cdktn.IResolvable): any;
export declare function appstreamImageBuilderRootVolumeConfigToHclTerraform(struct?: AppstreamImageBuilderRootVolumeConfig | cdktn.IResolvable): any;
export declare class AppstreamImageBuilderRootVolumeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamImageBuilderRootVolumeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamImageBuilderRootVolumeConfig | cdktn.IResolvable | undefined);
    private _volumeSizeInGb?;
    get volumeSizeInGb(): number;
    set volumeSizeInGb(value: number);
    resetVolumeSizeInGb(): void;
    get volumeSizeInGbInput(): number | undefined;
}
export interface AppstreamImageBuilderTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#key AppstreamImageBuilder#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#value AppstreamImageBuilder#value}
    */
    readonly value?: string;
}
export declare function appstreamImageBuilderTagsToTerraform(struct?: AppstreamImageBuilderTags | cdktn.IResolvable): any;
export declare function appstreamImageBuilderTagsToHclTerraform(struct?: AppstreamImageBuilderTags | cdktn.IResolvable): any;
export declare class AppstreamImageBuilderTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppstreamImageBuilderTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamImageBuilderTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppstreamImageBuilderTagsList extends cdktn.ComplexList {
    internalValue?: AppstreamImageBuilderTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppstreamImageBuilderTagsOutputReference;
}
export interface AppstreamImageBuilderVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#security_group_ids AppstreamImageBuilder#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#subnet_ids AppstreamImageBuilder#subnet_ids}
    */
    readonly subnetIds?: string[];
}
export declare function appstreamImageBuilderVpcConfigToTerraform(struct?: AppstreamImageBuilderVpcConfig | cdktn.IResolvable): any;
export declare function appstreamImageBuilderVpcConfigToHclTerraform(struct?: AppstreamImageBuilderVpcConfig | cdktn.IResolvable): any;
export declare class AppstreamImageBuilderVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamImageBuilderVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamImageBuilderVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder awscc_appstream_image_builder}
*/
export declare class AppstreamImageBuilder extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_image_builder";
    /**
    * Generates CDKTN code for importing a AppstreamImageBuilder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamImageBuilder to import
    * @param importFromId The id of the existing AppstreamImageBuilder that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamImageBuilder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appstream_image_builder awscc_appstream_image_builder} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamImageBuilderConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamImageBuilderConfig);
    private _accessEndpoints;
    get accessEndpoints(): AppstreamImageBuilderAccessEndpointsList;
    putAccessEndpoints(value: AppstreamImageBuilderAccessEndpoints[] | cdktn.IResolvable): void;
    resetAccessEndpoints(): void;
    get accessEndpointsInput(): cdktn.IResolvable | AppstreamImageBuilderAccessEndpoints[] | undefined;
    private _appstreamAgentVersion?;
    get appstreamAgentVersion(): string;
    set appstreamAgentVersion(value: string);
    resetAppstreamAgentVersion(): void;
    get appstreamAgentVersionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableImdsv1?;
    get disableImdsv1(): boolean | cdktn.IResolvable;
    set disableImdsv1(value: boolean | cdktn.IResolvable);
    resetDisableImdsv1(): void;
    get disableImdsv1Input(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _domainJoinInfo;
    get domainJoinInfo(): AppstreamImageBuilderDomainJoinInfoOutputReference;
    putDomainJoinInfo(value: AppstreamImageBuilderDomainJoinInfo): void;
    resetDomainJoinInfo(): void;
    get domainJoinInfoInput(): cdktn.IResolvable | AppstreamImageBuilderDomainJoinInfo | undefined;
    private _enableDefaultInternetAccess?;
    get enableDefaultInternetAccess(): boolean | cdktn.IResolvable;
    set enableDefaultInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableDefaultInternetAccess(): void;
    get enableDefaultInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    resetIamRoleArn(): void;
    get iamRoleArnInput(): string | undefined;
    get id(): string;
    private _imageArn?;
    get imageArn(): string;
    set imageArn(value: string);
    resetImageArn(): void;
    get imageArnInput(): string | undefined;
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    resetImageName(): void;
    get imageNameInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rootVolumeConfig;
    get rootVolumeConfig(): AppstreamImageBuilderRootVolumeConfigOutputReference;
    putRootVolumeConfig(value: AppstreamImageBuilderRootVolumeConfig): void;
    resetRootVolumeConfig(): void;
    get rootVolumeConfigInput(): cdktn.IResolvable | AppstreamImageBuilderRootVolumeConfig | undefined;
    private _softwaresToInstall?;
    get softwaresToInstall(): string[];
    set softwaresToInstall(value: string[]);
    resetSoftwaresToInstall(): void;
    get softwaresToInstallInput(): string[] | undefined;
    private _softwaresToUninstall?;
    get softwaresToUninstall(): string[];
    set softwaresToUninstall(value: string[]);
    resetSoftwaresToUninstall(): void;
    get softwaresToUninstallInput(): string[] | undefined;
    get streamingUrl(): string;
    private _tags;
    get tags(): AppstreamImageBuilderTagsList;
    putTags(value: AppstreamImageBuilderTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppstreamImageBuilderTags[] | undefined;
    private _vpcConfig;
    get vpcConfig(): AppstreamImageBuilderVpcConfigOutputReference;
    putVpcConfig(value: AppstreamImageBuilderVpcConfig): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | AppstreamImageBuilderVpcConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
