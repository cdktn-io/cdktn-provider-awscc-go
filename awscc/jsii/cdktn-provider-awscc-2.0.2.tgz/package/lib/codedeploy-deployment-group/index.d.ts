/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodedeployDeploymentGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Information about the Amazon CloudWatch alarms that are associated with the deployment group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#alarm_configuration CodedeployDeploymentGroup#alarm_configuration}
    */
    readonly alarmConfiguration?: CodedeployDeploymentGroupAlarmConfiguration;
    /**
    * The name of an existing CodeDeploy application to associate this deployment group with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#application_name CodedeployDeploymentGroup#application_name}
    */
    readonly applicationName: string;
    /**
    * Information about the automatic rollback configuration that is associated with the deployment group. If you specify this property, don't specify the Deployment property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#auto_rollback_configuration CodedeployDeploymentGroup#auto_rollback_configuration}
    */
    readonly autoRollbackConfiguration?: CodedeployDeploymentGroupAutoRollbackConfiguration;
    /**
    * A list of associated Auto Scaling groups that CodeDeploy automatically deploys revisions to when new instances are created. Duplicates are not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#auto_scaling_groups CodedeployDeploymentGroup#auto_scaling_groups}
    */
    readonly autoScalingGroups?: string[];
    /**
    * Information about blue/green deployment options for a deployment group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#blue_green_deployment_configuration CodedeployDeploymentGroup#blue_green_deployment_configuration}
    */
    readonly blueGreenDeploymentConfiguration?: CodedeployDeploymentGroupBlueGreenDeploymentConfiguration;
    /**
    * The application revision to deploy to this deployment group. If you specify this property, your target application revision is deployed as soon as the provisioning process is complete. If you specify this property, don't specify the AutoRollbackConfiguration property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#deployment CodedeployDeploymentGroup#deployment}
    */
    readonly deployment?: CodedeployDeploymentGroupDeployment;
    /**
    * A deployment configuration name or a predefined configuration name. With predefined configurations, you can deploy application revisions to one instance at a time (CodeDeployDefault.OneAtATime), half of the instances at a time (CodeDeployDefault.HalfAtATime), or all the instances at once (CodeDeployDefault.AllAtOnce).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#deployment_config_name CodedeployDeploymentGroup#deployment_config_name}
    */
    readonly deploymentConfigName?: string;
    /**
    * A name for the deployment group. If you don't specify a name, AWS CloudFormation generates a unique physical ID and uses that ID for the deployment group name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#deployment_group_name CodedeployDeploymentGroup#deployment_group_name}
    */
    readonly deploymentGroupName?: string;
    /**
    * Attributes that determine the type of deployment to run and whether to route deployment traffic behind a load balancer. If you specify this property with a blue/green deployment type, don't specify the AutoScalingGroups, LoadBalancerInfo, or Deployment properties.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#deployment_style CodedeployDeploymentGroup#deployment_style}
    */
    readonly deploymentStyle?: CodedeployDeploymentGroupDeploymentStyle;
    /**
    * Options that control how CodeDeploy manages Amazon EC2 Auto Scaling groups during deployments to the deployment group. Applies only to in-place deployment groups on the EC2/On-premises compute platform that include at least one Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#ec_2_deployment_options CodedeployDeploymentGroup#ec_2_deployment_options}
    */
    readonly ec2DeploymentOptions?: CodedeployDeploymentGroupEc2DeploymentOptions;
    /**
    * The Amazon EC2 tags that are already applied to Amazon EC2 instances that you want to include in the deployment group. CodeDeploy includes all Amazon EC2 instances identified by any of the tags you specify in this deployment group. Duplicates are not allowed. You can specify EC2TagFilters or Ec2TagSet, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#ec_2_tag_filters CodedeployDeploymentGroup#ec_2_tag_filters}
    */
    readonly ec2TagFilters?: CodedeployDeploymentGroupEc2TagFilters[] | cdktn.IResolvable;
    /**
    * Information about groups of tags applied to Amazon EC2 instances. Use when the deployment group includes only Amazon EC2 instances identified by all the tag groups. Cannot be used in the same call as ec2TagFilter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#ec_2_tag_set CodedeployDeploymentGroup#ec_2_tag_set}
    */
    readonly ec2TagSet?: CodedeployDeploymentGroupEc2TagSet;
    /**
    * The target Amazon ECS services in the deployment group. This applies only to deployment groups that use the Amazon ECS compute platform. A target Amazon ECS service is specified as an Amazon ECS cluster and service name pair using the format <clustername>:<servicename>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#ecs_services CodedeployDeploymentGroup#ecs_services}
    */
    readonly ecsServices?: CodedeployDeploymentGroupEcsServices[] | cdktn.IResolvable;
    /**
    * Information about the load balancer to use in a deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#load_balancer_info CodedeployDeploymentGroup#load_balancer_info}
    */
    readonly loadBalancerInfo?: CodedeployDeploymentGroupLoadBalancerInfo;
    /**
    * The on-premises instance tags already applied to on-premises instances that you want to include in the deployment group. CodeDeploy includes all on-premises instances identified by any of the tags you specify in this deployment group. Duplicates are not allowed. You can specify OnPremisesInstanceTagFilters or OnPremisesInstanceTagSet, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#on_premises_instance_tag_filters CodedeployDeploymentGroup#on_premises_instance_tag_filters}
    */
    readonly onPremisesInstanceTagFilters?: CodedeployDeploymentGroupOnPremisesInstanceTagFilters[] | cdktn.IResolvable;
    /**
    * Information about groups of tags applied to on-premises instances. The deployment group includes only on-premises instances identified by all the tag groups. You can specify OnPremisesInstanceTagFilters or OnPremisesInstanceTagSet, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#on_premises_tag_set CodedeployDeploymentGroup#on_premises_tag_set}
    */
    readonly onPremisesTagSet?: CodedeployDeploymentGroupOnPremisesTagSet;
    /**
    * Indicates what happens when new Amazon EC2 instances are launched mid-deployment and do not receive the deployed application revision. If this option is set to UPDATE or is unspecified, CodeDeploy initiates one or more 'auto-update outdated instances' deployments to apply the deployed application revision to the new Amazon EC2 instances. If this option is set to IGNORE, CodeDeploy does not initiate a deployment to update the new Amazon EC2 instances. This may result in instances having different revisions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#outdated_instances_strategy CodedeployDeploymentGroup#outdated_instances_strategy}
    */
    readonly outdatedInstancesStrategy?: string;
    /**
    * A service role Amazon Resource Name (ARN) that grants CodeDeploy permission to make calls to AWS services on your behalf. For more information, see 'Create a Service Role for AWS CodeDeploy' in the AWS CodeDeploy User Guide.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#service_role_arn CodedeployDeploymentGroup#service_role_arn}
    */
    readonly serviceRoleArn: string;
    /**
    * The metadata that you apply to CodeDeploy deployment groups to help you organize and categorize them. Each tag consists of a key and an optional value, both of which you define.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#tags CodedeployDeploymentGroup#tags}
    */
    readonly tags?: CodedeployDeploymentGroupTags[] | cdktn.IResolvable;
    /**
    * Indicates whether the deployment group was configured to have CodeDeploy install a termination hook into an Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#termination_hook_enabled CodedeployDeploymentGroup#termination_hook_enabled}
    */
    readonly terminationHookEnabled?: boolean | cdktn.IResolvable;
    /**
    * Information about triggers associated with the deployment group. Duplicates are not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#trigger_configurations CodedeployDeploymentGroup#trigger_configurations}
    */
    readonly triggerConfigurations?: CodedeployDeploymentGroupTriggerConfigurations[] | cdktn.IResolvable;
}
export interface CodedeployDeploymentGroupAlarmConfigurationAlarms {
    /**
    * The name of the alarm. Maximum length is 255 characters. Each alarm name can be used only once in a list of alarms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#name CodedeployDeploymentGroup#name}
    */
    readonly name?: string;
}
export declare function codedeployDeploymentGroupAlarmConfigurationAlarmsToTerraform(struct?: CodedeployDeploymentGroupAlarmConfigurationAlarms | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupAlarmConfigurationAlarmsToHclTerraform(struct?: CodedeployDeploymentGroupAlarmConfigurationAlarms | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupAlarmConfigurationAlarmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupAlarmConfigurationAlarms | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupAlarmConfigurationAlarms | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupAlarmConfigurationAlarmsList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupAlarmConfigurationAlarms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupAlarmConfigurationAlarmsOutputReference;
}
export interface CodedeployDeploymentGroupAlarmConfiguration {
    /**
    * A list of alarms configured for the deployment or deployment group. A maximum of 10 alarms can be added.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#alarms CodedeployDeploymentGroup#alarms}
    */
    readonly alarms?: CodedeployDeploymentGroupAlarmConfigurationAlarms[] | cdktn.IResolvable;
    /**
    * Indicates whether the alarm configuration is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#enabled CodedeployDeploymentGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether a deployment should continue if information about the current state of alarms cannot be retrieved from Amazon CloudWatch. The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#ignore_poll_alarm_failure CodedeployDeploymentGroup#ignore_poll_alarm_failure}
    */
    readonly ignorePollAlarmFailure?: boolean | cdktn.IResolvable;
}
export declare function codedeployDeploymentGroupAlarmConfigurationToTerraform(struct?: CodedeployDeploymentGroupAlarmConfiguration | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupAlarmConfigurationToHclTerraform(struct?: CodedeployDeploymentGroupAlarmConfiguration | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupAlarmConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupAlarmConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupAlarmConfiguration | cdktn.IResolvable | undefined);
    private _alarms;
    get alarms(): CodedeployDeploymentGroupAlarmConfigurationAlarmsList;
    putAlarms(value: CodedeployDeploymentGroupAlarmConfigurationAlarms[] | cdktn.IResolvable): void;
    resetAlarms(): void;
    get alarmsInput(): cdktn.IResolvable | CodedeployDeploymentGroupAlarmConfigurationAlarms[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ignorePollAlarmFailure?;
    get ignorePollAlarmFailure(): boolean | cdktn.IResolvable;
    set ignorePollAlarmFailure(value: boolean | cdktn.IResolvable);
    resetIgnorePollAlarmFailure(): void;
    get ignorePollAlarmFailureInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CodedeployDeploymentGroupAutoRollbackConfiguration {
    /**
    * Indicates whether a defined automatic rollback configuration is currently enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#enabled CodedeployDeploymentGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The event type or types that trigger a rollback.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#events CodedeployDeploymentGroup#events}
    */
    readonly events?: string[];
}
export declare function codedeployDeploymentGroupAutoRollbackConfigurationToTerraform(struct?: CodedeployDeploymentGroupAutoRollbackConfiguration | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupAutoRollbackConfigurationToHclTerraform(struct?: CodedeployDeploymentGroupAutoRollbackConfiguration | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupAutoRollbackConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupAutoRollbackConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupAutoRollbackConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _events?;
    get events(): string[];
    set events(value: string[]);
    resetEvents(): void;
    get eventsInput(): string[] | undefined;
}
export interface CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOption {
    /**
    * Information about when to reroute traffic from an original environment to a replacement environment in a blue/green deployment. CONTINUE_DEPLOYMENT: Register new instances with the load balancer immediately after the new application revision is installed on the instances in the replacement environment. STOP_DEPLOYMENT: Do not register new instances with a load balancer unless traffic rerouting is started using ContinueDeployment . If traffic rerouting is not started before the end of the specified wait period, the deployment status is changed to Stopped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#action_on_timeout CodedeployDeploymentGroup#action_on_timeout}
    */
    readonly actionOnTimeout?: string;
    /**
    * The number of minutes to wait before the status of a blue/green deployment is changed to Stopped if rerouting is not started manually. Applies only to the STOP_DEPLOYMENT option for actionOnTimeout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#wait_time_in_minutes CodedeployDeploymentGroup#wait_time_in_minutes}
    */
    readonly waitTimeInMinutes?: number;
}
export declare function codedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOptionToTerraform(struct?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOption | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOptionToHclTerraform(struct?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOption | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOption | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOption | cdktn.IResolvable | undefined);
    private _actionOnTimeout?;
    get actionOnTimeout(): string;
    set actionOnTimeout(value: string);
    resetActionOnTimeout(): void;
    get actionOnTimeoutInput(): string | undefined;
    private _waitTimeInMinutes?;
    get waitTimeInMinutes(): number;
    set waitTimeInMinutes(value: number);
    resetWaitTimeInMinutes(): void;
    get waitTimeInMinutesInput(): number | undefined;
}
export interface CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOption {
    /**
    * The method used to add instances to a replacement environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#action CodedeployDeploymentGroup#action}
    */
    readonly action?: string;
}
export declare function codedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOptionToTerraform(struct?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOption | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOptionToHclTerraform(struct?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOption | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOption | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOption | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
}
export interface CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccess {
    /**
    * The action to take on instances in the original environment after a successful blue/green deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#action CodedeployDeploymentGroup#action}
    */
    readonly action?: string;
    /**
    * For an Amazon EC2 deployment, the number of minutes to wait after a successful blue/green deployment before terminating instances from the original environment. For an Amazon ECS deployment, the number of minutes before deleting the original (blue) task set. During an Amazon ECS deployment, CodeDeploy shifts traffic from the original (blue) task set to a replacement (green) task set. The maximum setting is 2880 minutes (2 days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#termination_wait_time_in_minutes CodedeployDeploymentGroup#termination_wait_time_in_minutes}
    */
    readonly terminationWaitTimeInMinutes?: number;
}
export declare function codedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccessToTerraform(struct?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccess | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccessToHclTerraform(struct?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccess | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccess | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _terminationWaitTimeInMinutes?;
    get terminationWaitTimeInMinutes(): number;
    set terminationWaitTimeInMinutes(value: number);
    resetTerminationWaitTimeInMinutes(): void;
    get terminationWaitTimeInMinutesInput(): number | undefined;
}
export interface CodedeployDeploymentGroupBlueGreenDeploymentConfiguration {
    /**
    * Information about the action to take when newly provisioned instances are ready to receive traffic in a blue/green deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#deployment_ready_option CodedeployDeploymentGroup#deployment_ready_option}
    */
    readonly deploymentReadyOption?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOption;
    /**
    * Information about how instances are provisioned for a replacement environment in a blue/green deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#green_fleet_provisioning_option CodedeployDeploymentGroup#green_fleet_provisioning_option}
    */
    readonly greenFleetProvisioningOption?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOption;
    /**
    * Information about whether to terminate instances in the original fleet during a blue/green deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#terminate_blue_instances_on_deployment_success CodedeployDeploymentGroup#terminate_blue_instances_on_deployment_success}
    */
    readonly terminateBlueInstancesOnDeploymentSuccess?: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccess;
}
export declare function codedeployDeploymentGroupBlueGreenDeploymentConfigurationToTerraform(struct?: CodedeployDeploymentGroupBlueGreenDeploymentConfiguration | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupBlueGreenDeploymentConfigurationToHclTerraform(struct?: CodedeployDeploymentGroupBlueGreenDeploymentConfiguration | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupBlueGreenDeploymentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupBlueGreenDeploymentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupBlueGreenDeploymentConfiguration | cdktn.IResolvable | undefined);
    private _deploymentReadyOption;
    get deploymentReadyOption(): CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOptionOutputReference;
    putDeploymentReadyOption(value: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOption): void;
    resetDeploymentReadyOption(): void;
    get deploymentReadyOptionInput(): cdktn.IResolvable | CodedeployDeploymentGroupBlueGreenDeploymentConfigurationDeploymentReadyOption | undefined;
    private _greenFleetProvisioningOption;
    get greenFleetProvisioningOption(): CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOptionOutputReference;
    putGreenFleetProvisioningOption(value: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOption): void;
    resetGreenFleetProvisioningOption(): void;
    get greenFleetProvisioningOptionInput(): cdktn.IResolvable | CodedeployDeploymentGroupBlueGreenDeploymentConfigurationGreenFleetProvisioningOption | undefined;
    private _terminateBlueInstancesOnDeploymentSuccess;
    get terminateBlueInstancesOnDeploymentSuccess(): CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccessOutputReference;
    putTerminateBlueInstancesOnDeploymentSuccess(value: CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccess): void;
    resetTerminateBlueInstancesOnDeploymentSuccess(): void;
    get terminateBlueInstancesOnDeploymentSuccessInput(): cdktn.IResolvable | CodedeployDeploymentGroupBlueGreenDeploymentConfigurationTerminateBlueInstancesOnDeploymentSuccess | undefined;
}
export interface CodedeployDeploymentGroupDeploymentRevisionGitHubLocation {
    /**
    * The SHA1 commit ID of the GitHub commit that represents the bundled artifacts for the application revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#commit_id CodedeployDeploymentGroup#commit_id}
    */
    readonly commitId?: string;
    /**
    * The GitHub account and repository pair that stores the application revision to be deployed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#repository CodedeployDeploymentGroup#repository}
    */
    readonly repository?: string;
}
export declare function codedeployDeploymentGroupDeploymentRevisionGitHubLocationToTerraform(struct?: CodedeployDeploymentGroupDeploymentRevisionGitHubLocation | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupDeploymentRevisionGitHubLocationToHclTerraform(struct?: CodedeployDeploymentGroupDeploymentRevisionGitHubLocation | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupDeploymentRevisionGitHubLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupDeploymentRevisionGitHubLocation | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupDeploymentRevisionGitHubLocation | cdktn.IResolvable | undefined);
    private _commitId?;
    get commitId(): string;
    set commitId(value: string);
    resetCommitId(): void;
    get commitIdInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
}
export interface CodedeployDeploymentGroupDeploymentRevisionS3Location {
    /**
    * The name of the Amazon S3 bucket where the application revision is stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#bucket CodedeployDeploymentGroup#bucket}
    */
    readonly bucket?: string;
    /**
    * The file type of the application revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#bundle_type CodedeployDeploymentGroup#bundle_type}
    */
    readonly bundleType?: string;
    /**
    * The ETag of the Amazon S3 object that represents the bundled artifacts for the application revision. If the ETag is not specified as an input parameter, ETag validation of the object is skipped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#e_tag CodedeployDeploymentGroup#e_tag}
    */
    readonly eTag?: string;
    /**
    * The name of the Amazon S3 object that represents the bundled artifacts for the application revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#key CodedeployDeploymentGroup#key}
    */
    readonly key?: string;
    /**
    * A specific version of the Amazon S3 object that represents the bundled artifacts for the application revision. If the version is not specified, the system uses the most recent version by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#version CodedeployDeploymentGroup#version}
    */
    readonly version?: string;
}
export declare function codedeployDeploymentGroupDeploymentRevisionS3LocationToTerraform(struct?: CodedeployDeploymentGroupDeploymentRevisionS3Location | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupDeploymentRevisionS3LocationToHclTerraform(struct?: CodedeployDeploymentGroupDeploymentRevisionS3Location | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupDeploymentRevisionS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupDeploymentRevisionS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupDeploymentRevisionS3Location | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _bundleType?;
    get bundleType(): string;
    set bundleType(value: string);
    resetBundleType(): void;
    get bundleTypeInput(): string | undefined;
    private _eTag?;
    get eTag(): string;
    set eTag(value: string);
    resetETag(): void;
    get eTagInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CodedeployDeploymentGroupDeploymentRevision {
    /**
    * Specifies the location of an application revision that is stored in GitHub.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#git_hub_location CodedeployDeploymentGroup#git_hub_location}
    */
    readonly gitHubLocation?: CodedeployDeploymentGroupDeploymentRevisionGitHubLocation;
    /**
    * The type of application revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#revision_type CodedeployDeploymentGroup#revision_type}
    */
    readonly revisionType?: string;
    /**
    * Information about the location of application artifacts stored in Amazon S3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#s3_location CodedeployDeploymentGroup#s3_location}
    */
    readonly s3Location?: CodedeployDeploymentGroupDeploymentRevisionS3Location;
}
export declare function codedeployDeploymentGroupDeploymentRevisionToTerraform(struct?: CodedeployDeploymentGroupDeploymentRevision | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupDeploymentRevisionToHclTerraform(struct?: CodedeployDeploymentGroupDeploymentRevision | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupDeploymentRevisionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupDeploymentRevision | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupDeploymentRevision | cdktn.IResolvable | undefined);
    private _gitHubLocation;
    get gitHubLocation(): CodedeployDeploymentGroupDeploymentRevisionGitHubLocationOutputReference;
    putGitHubLocation(value: CodedeployDeploymentGroupDeploymentRevisionGitHubLocation): void;
    resetGitHubLocation(): void;
    get gitHubLocationInput(): cdktn.IResolvable | CodedeployDeploymentGroupDeploymentRevisionGitHubLocation | undefined;
    private _revisionType?;
    get revisionType(): string;
    set revisionType(value: string);
    resetRevisionType(): void;
    get revisionTypeInput(): string | undefined;
    private _s3Location;
    get s3Location(): CodedeployDeploymentGroupDeploymentRevisionS3LocationOutputReference;
    putS3Location(value: CodedeployDeploymentGroupDeploymentRevisionS3Location): void;
    resetS3Location(): void;
    get s3LocationInput(): cdktn.IResolvable | CodedeployDeploymentGroupDeploymentRevisionS3Location | undefined;
}
export interface CodedeployDeploymentGroupDeployment {
    /**
    * A description of the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#description CodedeployDeploymentGroup#description}
    */
    readonly description?: string;
    /**
    * If true, then if an ApplicationStop, BeforeBlockTraffic, or AfterBlockTraffic deployment lifecycle event to an instance fails, then the deployment continues to the next deployment lifecycle event. If false or not specified, then if a lifecycle event fails during a deployment to an instance, that deployment fails. If deployment to that instance is part of an overall deployment and the number of healthy hosts is not less than the minimum number of healthy hosts, then a deployment to the next instance is attempted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#ignore_application_stop_failures CodedeployDeploymentGroup#ignore_application_stop_failures}
    */
    readonly ignoreApplicationStopFailures?: boolean | cdktn.IResolvable;
    /**
    * Information about the location of stored application artifacts and the service from which to retrieve them.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#revision CodedeployDeploymentGroup#revision}
    */
    readonly revision?: CodedeployDeploymentGroupDeploymentRevision;
}
export declare function codedeployDeploymentGroupDeploymentToTerraform(struct?: CodedeployDeploymentGroupDeployment | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupDeploymentToHclTerraform(struct?: CodedeployDeploymentGroupDeployment | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupDeployment | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupDeployment | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _ignoreApplicationStopFailures?;
    get ignoreApplicationStopFailures(): boolean | cdktn.IResolvable;
    set ignoreApplicationStopFailures(value: boolean | cdktn.IResolvable);
    resetIgnoreApplicationStopFailures(): void;
    get ignoreApplicationStopFailuresInput(): boolean | cdktn.IResolvable | undefined;
    private _revision;
    get revision(): CodedeployDeploymentGroupDeploymentRevisionOutputReference;
    putRevision(value: CodedeployDeploymentGroupDeploymentRevision): void;
    resetRevision(): void;
    get revisionInput(): cdktn.IResolvable | CodedeployDeploymentGroupDeploymentRevision | undefined;
}
export interface CodedeployDeploymentGroupDeploymentStyle {
    /**
    * Indicates whether to route deployment traffic behind a load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#deployment_option CodedeployDeploymentGroup#deployment_option}
    */
    readonly deploymentOption?: string;
    /**
    * Indicates whether to run an in-place or blue/green deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#deployment_type CodedeployDeploymentGroup#deployment_type}
    */
    readonly deploymentType?: string;
}
export declare function codedeployDeploymentGroupDeploymentStyleToTerraform(struct?: CodedeployDeploymentGroupDeploymentStyle | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupDeploymentStyleToHclTerraform(struct?: CodedeployDeploymentGroupDeploymentStyle | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupDeploymentStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupDeploymentStyle | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupDeploymentStyle | cdktn.IResolvable | undefined);
    private _deploymentOption?;
    get deploymentOption(): string;
    set deploymentOption(value: string);
    resetDeploymentOption(): void;
    get deploymentOptionInput(): string | undefined;
    private _deploymentType?;
    get deploymentType(): string;
    set deploymentType(value: string);
    resetDeploymentType(): void;
    get deploymentTypeInput(): string | undefined;
}
export interface CodedeployDeploymentGroupEc2DeploymentOptions {
    /**
    * The Amazon EC2 Auto Scaling processes to suspend during an in-place deployment. CodeDeploy suspends these processes before it deploys to instances in an Auto Scaling group, and resumes them when the deployment succeeds, fails, or is stopped. Valid values are Terminate, AZRebalance, InstanceRefresh, and ScheduledActions. Process names are case sensitive. To stop suspending processes, remove the property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#auto_scaling_group_processes_to_suspend CodedeployDeploymentGroup#auto_scaling_group_processes_to_suspend}
    */
    readonly autoScalingGroupProcessesToSuspend?: string[];
}
export declare function codedeployDeploymentGroupEc2DeploymentOptionsToTerraform(struct?: CodedeployDeploymentGroupEc2DeploymentOptions | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupEc2DeploymentOptionsToHclTerraform(struct?: CodedeployDeploymentGroupEc2DeploymentOptions | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupEc2DeploymentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupEc2DeploymentOptions | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupEc2DeploymentOptions | cdktn.IResolvable | undefined);
    private _autoScalingGroupProcessesToSuspend?;
    get autoScalingGroupProcessesToSuspend(): string[];
    set autoScalingGroupProcessesToSuspend(value: string[]);
    resetAutoScalingGroupProcessesToSuspend(): void;
    get autoScalingGroupProcessesToSuspendInput(): string[] | undefined;
}
export interface CodedeployDeploymentGroupEc2TagFilters {
    /**
    * The tag filter key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#key CodedeployDeploymentGroup#key}
    */
    readonly key?: string;
    /**
    * The tag filter type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#type CodedeployDeploymentGroup#type}
    */
    readonly type?: string;
    /**
    * The tag filter value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#value CodedeployDeploymentGroup#value}
    */
    readonly value?: string;
}
export declare function codedeployDeploymentGroupEc2TagFiltersToTerraform(struct?: CodedeployDeploymentGroupEc2TagFilters | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupEc2TagFiltersToHclTerraform(struct?: CodedeployDeploymentGroupEc2TagFilters | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupEc2TagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupEc2TagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupEc2TagFilters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupEc2TagFiltersList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupEc2TagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupEc2TagFiltersOutputReference;
}
export interface CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup {
    /**
    * The tag filter key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#key CodedeployDeploymentGroup#key}
    */
    readonly key?: string;
    /**
    * The tag filter type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#type CodedeployDeploymentGroup#type}
    */
    readonly type?: string;
    /**
    * The tag filter value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#value CodedeployDeploymentGroup#value}
    */
    readonly value?: string;
}
export declare function codedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroupToTerraform(struct?: CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroupToHclTerraform(struct?: CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroupList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroupOutputReference;
}
export interface CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct {
    /**
    * A list that contains other lists of Amazon EC2 instance tag groups. For an instance to be included in the deployment group, it must be identified by all of the tag groups in the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#ec_2_tag_group CodedeployDeploymentGroup#ec_2_tag_group}
    */
    readonly ec2TagGroup?: CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup[] | cdktn.IResolvable;
}
export declare function codedeployDeploymentGroupEc2TagSetEc2TagSetListStructToTerraform(struct?: CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupEc2TagSetEc2TagSetListStructToHclTerraform(struct?: CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupEc2TagSetEc2TagSetListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct | cdktn.IResolvable | undefined);
    private _ec2TagGroup;
    get ec2TagGroup(): CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroupList;
    putEc2TagGroup(value: CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup[] | cdktn.IResolvable): void;
    resetEc2TagGroup(): void;
    get ec2TagGroupInput(): cdktn.IResolvable | CodedeployDeploymentGroupEc2TagSetEc2TagSetListEc2TagGroup[] | undefined;
}
export declare class CodedeployDeploymentGroupEc2TagSetEc2TagSetListStructList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupEc2TagSetEc2TagSetListStructOutputReference;
}
export interface CodedeployDeploymentGroupEc2TagSet {
    /**
    * The Amazon EC2 tags that are already applied to Amazon EC2 instances that you want to include in the deployment group. CodeDeploy includes all Amazon EC2 instances identified by any of the tags you specify in this deployment group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#ec_2_tag_set_list CodedeployDeploymentGroup#ec_2_tag_set_list}
    */
    readonly ec2TagSetList?: CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct[] | cdktn.IResolvable;
}
export declare function codedeployDeploymentGroupEc2TagSetToTerraform(struct?: CodedeployDeploymentGroupEc2TagSet | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupEc2TagSetToHclTerraform(struct?: CodedeployDeploymentGroupEc2TagSet | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupEc2TagSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupEc2TagSet | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupEc2TagSet | cdktn.IResolvable | undefined);
    private _ec2TagSetList;
    get ec2TagSetList(): CodedeployDeploymentGroupEc2TagSetEc2TagSetListStructList;
    putEc2TagSetList(value: CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct[] | cdktn.IResolvable): void;
    resetEc2TagSetList(): void;
    get ec2TagSetListInput(): cdktn.IResolvable | CodedeployDeploymentGroupEc2TagSetEc2TagSetListStruct[] | undefined;
}
export interface CodedeployDeploymentGroupEcsServices {
    /**
    * The name of the cluster that the Amazon ECS service is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#cluster_name CodedeployDeploymentGroup#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * The name of the target Amazon ECS service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#service_name CodedeployDeploymentGroup#service_name}
    */
    readonly serviceName?: string;
}
export declare function codedeployDeploymentGroupEcsServicesToTerraform(struct?: CodedeployDeploymentGroupEcsServices | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupEcsServicesToHclTerraform(struct?: CodedeployDeploymentGroupEcsServices | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupEcsServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupEcsServices | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupEcsServices | cdktn.IResolvable | undefined);
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupEcsServicesList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupEcsServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupEcsServicesOutputReference;
}
export interface CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct {
    /**
    * For blue/green deployments, the name of the load balancer that is used to route traffic from original instances to replacement instances in a blue/green deployment. For in-place deployments, the name of the load balancer that instances are deregistered from so they are not serving traffic during a deployment, and then re-registered with after the deployment is complete.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#name CodedeployDeploymentGroup#name}
    */
    readonly name?: string;
}
export declare function codedeployDeploymentGroupLoadBalancerInfoElbInfoListStructToTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupLoadBalancerInfoElbInfoListStructToHclTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStructList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStructOutputReference;
}
export interface CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct {
    /**
    * For blue/green deployments, the name of the target group that instances in the original environment are deregistered from, and instances in the replacement environment registered with. For in-place deployments, the name of the target group that instances are deregistered from, so they are not serving traffic during a deployment, and then re-registered with after the deployment completes. No duplicates allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#name CodedeployDeploymentGroup#name}
    */
    readonly name?: string;
}
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStructToTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStructToHclTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStructList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStructOutputReference;
}
export interface CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRoute {
    /**
    * The Amazon Resource Name (ARN) of one listener. The listener identifies the route between a target group and a load balancer. This is an array of strings with a maximum size of one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#listener_arns CodedeployDeploymentGroup#listener_arns}
    */
    readonly listenerArns?: string[];
}
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRouteToTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRoute | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRouteToHclTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRoute | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRoute | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRoute | cdktn.IResolvable | undefined);
    private _listenerArns?;
    get listenerArns(): string[];
    set listenerArns(value: string[]);
    resetListenerArns(): void;
    get listenerArnsInput(): string[] | undefined;
}
export interface CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups {
    /**
    * For blue/green deployments, the name of the target group that instances in the original environment are deregistered from, and instances in the replacement environment registered with. For in-place deployments, the name of the target group that instances are deregistered from, so they are not serving traffic during a deployment, and then re-registered with after the deployment completes. No duplicates allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#name CodedeployDeploymentGroup#name}
    */
    readonly name?: string;
}
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroupsToTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroupsToHclTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroupsList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroupsOutputReference;
}
export interface CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRoute {
    /**
    * The Amazon Resource Name (ARN) of one listener. The listener identifies the route between a target group and a load balancer. This is an array of strings with a maximum size of one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#listener_arns CodedeployDeploymentGroup#listener_arns}
    */
    readonly listenerArns?: string[];
}
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRouteToTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRoute | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRouteToHclTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRoute | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRoute | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRoute | cdktn.IResolvable | undefined);
    private _listenerArns?;
    get listenerArns(): string[];
    set listenerArns(value: string[]);
    resetListenerArns(): void;
    get listenerArnsInput(): string[] | undefined;
}
export interface CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct {
    /**
    * The path used by a load balancer to route production traffic when an Amazon ECS deployment is complete.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#prod_traffic_route CodedeployDeploymentGroup#prod_traffic_route}
    */
    readonly prodTrafficRoute?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRoute;
    /**
    * One pair of target groups. One is associated with the original task set. The second is associated with the task set that serves traffic after the deployment is complete.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#target_groups CodedeployDeploymentGroup#target_groups}
    */
    readonly targetGroups?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups[] | cdktn.IResolvable;
    /**
    * An optional path used by a load balancer to route test traffic after an Amazon ECS deployment. Validation can occur while test traffic is served during a deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#test_traffic_route CodedeployDeploymentGroup#test_traffic_route}
    */
    readonly testTrafficRoute?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRoute;
}
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStructToTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStructToHclTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct | cdktn.IResolvable | undefined);
    private _prodTrafficRoute;
    get prodTrafficRoute(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRouteOutputReference;
    putProdTrafficRoute(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRoute): void;
    resetProdTrafficRoute(): void;
    get prodTrafficRouteInput(): cdktn.IResolvable | CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListProdTrafficRoute | undefined;
    private _targetGroups;
    get targetGroups(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroupsList;
    putTargetGroups(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups[] | cdktn.IResolvable): void;
    resetTargetGroups(): void;
    get targetGroupsInput(): cdktn.IResolvable | CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTargetGroups[] | undefined;
    private _testTrafficRoute;
    get testTrafficRoute(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRouteOutputReference;
    putTestTrafficRoute(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRoute): void;
    resetTestTrafficRoute(): void;
    get testTrafficRouteInput(): cdktn.IResolvable | CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListTestTrafficRoute | undefined;
}
export declare class CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStructList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStructOutputReference;
}
export interface CodedeployDeploymentGroupLoadBalancerInfo {
    /**
    * An array that contains information about the load balancers to use for load balancing in a deployment. If you're using Classic Load Balancers, specify those load balancers in this array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#elb_info_list CodedeployDeploymentGroup#elb_info_list}
    */
    readonly elbInfoList?: CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct[] | cdktn.IResolvable;
    /**
    * An array that contains information about the target groups to use for load balancing in a deployment. If you're using Application Load Balancers and Network Load Balancers, specify their associated target groups in this array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#target_group_info_list CodedeployDeploymentGroup#target_group_info_list}
    */
    readonly targetGroupInfoList?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct[] | cdktn.IResolvable;
    /**
    * The target group pair information. This is an array of TargeGroupPairInfo objects with a maximum size of one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#target_group_pair_info_list CodedeployDeploymentGroup#target_group_pair_info_list}
    */
    readonly targetGroupPairInfoList?: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct[] | cdktn.IResolvable;
}
export declare function codedeployDeploymentGroupLoadBalancerInfoToTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfo | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupLoadBalancerInfoToHclTerraform(struct?: CodedeployDeploymentGroupLoadBalancerInfo | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupLoadBalancerInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupLoadBalancerInfo | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupLoadBalancerInfo | cdktn.IResolvable | undefined);
    private _elbInfoList;
    get elbInfoList(): CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStructList;
    putElbInfoList(value: CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct[] | cdktn.IResolvable): void;
    resetElbInfoList(): void;
    get elbInfoListInput(): cdktn.IResolvable | CodedeployDeploymentGroupLoadBalancerInfoElbInfoListStruct[] | undefined;
    private _targetGroupInfoList;
    get targetGroupInfoList(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStructList;
    putTargetGroupInfoList(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct[] | cdktn.IResolvable): void;
    resetTargetGroupInfoList(): void;
    get targetGroupInfoListInput(): cdktn.IResolvable | CodedeployDeploymentGroupLoadBalancerInfoTargetGroupInfoListStruct[] | undefined;
    private _targetGroupPairInfoList;
    get targetGroupPairInfoList(): CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStructList;
    putTargetGroupPairInfoList(value: CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct[] | cdktn.IResolvable): void;
    resetTargetGroupPairInfoList(): void;
    get targetGroupPairInfoListInput(): cdktn.IResolvable | CodedeployDeploymentGroupLoadBalancerInfoTargetGroupPairInfoListStruct[] | undefined;
}
export interface CodedeployDeploymentGroupOnPremisesInstanceTagFilters {
    /**
    * The on-premises instance tag filter key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#key CodedeployDeploymentGroup#key}
    */
    readonly key?: string;
    /**
    * The on-premises instance tag filter type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#type CodedeployDeploymentGroup#type}
    */
    readonly type?: string;
    /**
    * The on-premises instance tag filter value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#value CodedeployDeploymentGroup#value}
    */
    readonly value?: string;
}
export declare function codedeployDeploymentGroupOnPremisesInstanceTagFiltersToTerraform(struct?: CodedeployDeploymentGroupOnPremisesInstanceTagFilters | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupOnPremisesInstanceTagFiltersToHclTerraform(struct?: CodedeployDeploymentGroupOnPremisesInstanceTagFilters | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupOnPremisesInstanceTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupOnPremisesInstanceTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupOnPremisesInstanceTagFilters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupOnPremisesInstanceTagFiltersList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupOnPremisesInstanceTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupOnPremisesInstanceTagFiltersOutputReference;
}
export interface CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup {
    /**
    * The on-premises instance tag filter key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#key CodedeployDeploymentGroup#key}
    */
    readonly key?: string;
    /**
    * The on-premises instance tag filter type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#type CodedeployDeploymentGroup#type}
    */
    readonly type?: string;
    /**
    * The on-premises instance tag filter value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#value CodedeployDeploymentGroup#value}
    */
    readonly value?: string;
}
export declare function codedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroupToTerraform(struct?: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroupToHclTerraform(struct?: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroupList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroupOutputReference;
}
export interface CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct {
    /**
    * Information about groups of on-premises instance tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#on_premises_tag_group CodedeployDeploymentGroup#on_premises_tag_group}
    */
    readonly onPremisesTagGroup?: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup[] | cdktn.IResolvable;
}
export declare function codedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStructToTerraform(struct?: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStructToHclTerraform(struct?: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct | cdktn.IResolvable | undefined);
    private _onPremisesTagGroup;
    get onPremisesTagGroup(): CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroupList;
    putOnPremisesTagGroup(value: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup[] | cdktn.IResolvable): void;
    resetOnPremisesTagGroup(): void;
    get onPremisesTagGroupInput(): cdktn.IResolvable | CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListOnPremisesTagGroup[] | undefined;
}
export declare class CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStructList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStructOutputReference;
}
export interface CodedeployDeploymentGroupOnPremisesTagSet {
    /**
    * A list that contains other lists of on-premises instance tag groups. For an instance to be included in the deployment group, it must be identified by all of the tag groups in the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#on_premises_tag_set_list CodedeployDeploymentGroup#on_premises_tag_set_list}
    */
    readonly onPremisesTagSetList?: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct[] | cdktn.IResolvable;
}
export declare function codedeployDeploymentGroupOnPremisesTagSetToTerraform(struct?: CodedeployDeploymentGroupOnPremisesTagSet | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupOnPremisesTagSetToHclTerraform(struct?: CodedeployDeploymentGroupOnPremisesTagSet | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupOnPremisesTagSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentGroupOnPremisesTagSet | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupOnPremisesTagSet | cdktn.IResolvable | undefined);
    private _onPremisesTagSetList;
    get onPremisesTagSetList(): CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStructList;
    putOnPremisesTagSetList(value: CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct[] | cdktn.IResolvable): void;
    resetOnPremisesTagSetList(): void;
    get onPremisesTagSetListInput(): cdktn.IResolvable | CodedeployDeploymentGroupOnPremisesTagSetOnPremisesTagSetListStruct[] | undefined;
}
export interface CodedeployDeploymentGroupTags {
    /**
    * The tag's key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#key CodedeployDeploymentGroup#key}
    */
    readonly key?: string;
    /**
    * The tag's value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#value CodedeployDeploymentGroup#value}
    */
    readonly value?: string;
}
export declare function codedeployDeploymentGroupTagsToTerraform(struct?: CodedeployDeploymentGroupTags | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupTagsToHclTerraform(struct?: CodedeployDeploymentGroupTags | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupTagsList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupTagsOutputReference;
}
export interface CodedeployDeploymentGroupTriggerConfigurations {
    /**
    * The event type or types that trigger notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#trigger_events CodedeployDeploymentGroup#trigger_events}
    */
    readonly triggerEvents?: string[];
    /**
    * The name of the notification trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#trigger_name CodedeployDeploymentGroup#trigger_name}
    */
    readonly triggerName?: string;
    /**
    * The Amazon Resource Name (ARN) of the Amazon Simple Notification Service topic through which notifications about deployment or instance events are sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#trigger_target_arn CodedeployDeploymentGroup#trigger_target_arn}
    */
    readonly triggerTargetArn?: string;
}
export declare function codedeployDeploymentGroupTriggerConfigurationsToTerraform(struct?: CodedeployDeploymentGroupTriggerConfigurations | cdktn.IResolvable): any;
export declare function codedeployDeploymentGroupTriggerConfigurationsToHclTerraform(struct?: CodedeployDeploymentGroupTriggerConfigurations | cdktn.IResolvable): any;
export declare class CodedeployDeploymentGroupTriggerConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployDeploymentGroupTriggerConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentGroupTriggerConfigurations | cdktn.IResolvable | undefined);
    private _triggerEvents?;
    get triggerEvents(): string[];
    set triggerEvents(value: string[]);
    resetTriggerEvents(): void;
    get triggerEventsInput(): string[] | undefined;
    private _triggerName?;
    get triggerName(): string;
    set triggerName(value: string);
    resetTriggerName(): void;
    get triggerNameInput(): string | undefined;
    private _triggerTargetArn?;
    get triggerTargetArn(): string;
    set triggerTargetArn(value: string);
    resetTriggerTargetArn(): void;
    get triggerTargetArnInput(): string | undefined;
}
export declare class CodedeployDeploymentGroupTriggerConfigurationsList extends cdktn.ComplexList {
    internalValue?: CodedeployDeploymentGroupTriggerConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployDeploymentGroupTriggerConfigurationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group awscc_codedeploy_deployment_group}
*/
export declare class CodedeployDeploymentGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codedeploy_deployment_group";
    /**
    * Generates CDKTN code for importing a CodedeployDeploymentGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodedeployDeploymentGroup to import
    * @param importFromId The id of the existing CodedeployDeploymentGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodedeployDeploymentGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codedeploy_deployment_group awscc_codedeploy_deployment_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodedeployDeploymentGroupConfig
    */
    constructor(scope: Construct, id: string, config: CodedeployDeploymentGroupConfig);
    private _alarmConfiguration;
    get alarmConfiguration(): CodedeployDeploymentGroupAlarmConfigurationOutputReference;
    putAlarmConfiguration(value: CodedeployDeploymentGroupAlarmConfiguration): void;
    resetAlarmConfiguration(): void;
    get alarmConfigurationInput(): cdktn.IResolvable | CodedeployDeploymentGroupAlarmConfiguration | undefined;
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    get applicationNameInput(): string | undefined;
    private _autoRollbackConfiguration;
    get autoRollbackConfiguration(): CodedeployDeploymentGroupAutoRollbackConfigurationOutputReference;
    putAutoRollbackConfiguration(value: CodedeployDeploymentGroupAutoRollbackConfiguration): void;
    resetAutoRollbackConfiguration(): void;
    get autoRollbackConfigurationInput(): cdktn.IResolvable | CodedeployDeploymentGroupAutoRollbackConfiguration | undefined;
    private _autoScalingGroups?;
    get autoScalingGroups(): string[];
    set autoScalingGroups(value: string[]);
    resetAutoScalingGroups(): void;
    get autoScalingGroupsInput(): string[] | undefined;
    private _blueGreenDeploymentConfiguration;
    get blueGreenDeploymentConfiguration(): CodedeployDeploymentGroupBlueGreenDeploymentConfigurationOutputReference;
    putBlueGreenDeploymentConfiguration(value: CodedeployDeploymentGroupBlueGreenDeploymentConfiguration): void;
    resetBlueGreenDeploymentConfiguration(): void;
    get blueGreenDeploymentConfigurationInput(): cdktn.IResolvable | CodedeployDeploymentGroupBlueGreenDeploymentConfiguration | undefined;
    private _deployment;
    get deployment(): CodedeployDeploymentGroupDeploymentOutputReference;
    putDeployment(value: CodedeployDeploymentGroupDeployment): void;
    resetDeployment(): void;
    get deploymentInput(): cdktn.IResolvable | CodedeployDeploymentGroupDeployment | undefined;
    private _deploymentConfigName?;
    get deploymentConfigName(): string;
    set deploymentConfigName(value: string);
    resetDeploymentConfigName(): void;
    get deploymentConfigNameInput(): string | undefined;
    private _deploymentGroupName?;
    get deploymentGroupName(): string;
    set deploymentGroupName(value: string);
    resetDeploymentGroupName(): void;
    get deploymentGroupNameInput(): string | undefined;
    private _deploymentStyle;
    get deploymentStyle(): CodedeployDeploymentGroupDeploymentStyleOutputReference;
    putDeploymentStyle(value: CodedeployDeploymentGroupDeploymentStyle): void;
    resetDeploymentStyle(): void;
    get deploymentStyleInput(): cdktn.IResolvable | CodedeployDeploymentGroupDeploymentStyle | undefined;
    private _ec2DeploymentOptions;
    get ec2DeploymentOptions(): CodedeployDeploymentGroupEc2DeploymentOptionsOutputReference;
    putEc2DeploymentOptions(value: CodedeployDeploymentGroupEc2DeploymentOptions): void;
    resetEc2DeploymentOptions(): void;
    get ec2DeploymentOptionsInput(): cdktn.IResolvable | CodedeployDeploymentGroupEc2DeploymentOptions | undefined;
    private _ec2TagFilters;
    get ec2TagFilters(): CodedeployDeploymentGroupEc2TagFiltersList;
    putEc2TagFilters(value: CodedeployDeploymentGroupEc2TagFilters[] | cdktn.IResolvable): void;
    resetEc2TagFilters(): void;
    get ec2TagFiltersInput(): cdktn.IResolvable | CodedeployDeploymentGroupEc2TagFilters[] | undefined;
    private _ec2TagSet;
    get ec2TagSet(): CodedeployDeploymentGroupEc2TagSetOutputReference;
    putEc2TagSet(value: CodedeployDeploymentGroupEc2TagSet): void;
    resetEc2TagSet(): void;
    get ec2TagSetInput(): cdktn.IResolvable | CodedeployDeploymentGroupEc2TagSet | undefined;
    private _ecsServices;
    get ecsServices(): CodedeployDeploymentGroupEcsServicesList;
    putEcsServices(value: CodedeployDeploymentGroupEcsServices[] | cdktn.IResolvable): void;
    resetEcsServices(): void;
    get ecsServicesInput(): cdktn.IResolvable | CodedeployDeploymentGroupEcsServices[] | undefined;
    get id(): string;
    private _loadBalancerInfo;
    get loadBalancerInfo(): CodedeployDeploymentGroupLoadBalancerInfoOutputReference;
    putLoadBalancerInfo(value: CodedeployDeploymentGroupLoadBalancerInfo): void;
    resetLoadBalancerInfo(): void;
    get loadBalancerInfoInput(): cdktn.IResolvable | CodedeployDeploymentGroupLoadBalancerInfo | undefined;
    private _onPremisesInstanceTagFilters;
    get onPremisesInstanceTagFilters(): CodedeployDeploymentGroupOnPremisesInstanceTagFiltersList;
    putOnPremisesInstanceTagFilters(value: CodedeployDeploymentGroupOnPremisesInstanceTagFilters[] | cdktn.IResolvable): void;
    resetOnPremisesInstanceTagFilters(): void;
    get onPremisesInstanceTagFiltersInput(): cdktn.IResolvable | CodedeployDeploymentGroupOnPremisesInstanceTagFilters[] | undefined;
    private _onPremisesTagSet;
    get onPremisesTagSet(): CodedeployDeploymentGroupOnPremisesTagSetOutputReference;
    putOnPremisesTagSet(value: CodedeployDeploymentGroupOnPremisesTagSet): void;
    resetOnPremisesTagSet(): void;
    get onPremisesTagSetInput(): cdktn.IResolvable | CodedeployDeploymentGroupOnPremisesTagSet | undefined;
    private _outdatedInstancesStrategy?;
    get outdatedInstancesStrategy(): string;
    set outdatedInstancesStrategy(value: string);
    resetOutdatedInstancesStrategy(): void;
    get outdatedInstancesStrategyInput(): string | undefined;
    private _serviceRoleArn?;
    get serviceRoleArn(): string;
    set serviceRoleArn(value: string);
    get serviceRoleArnInput(): string | undefined;
    private _tags;
    get tags(): CodedeployDeploymentGroupTagsList;
    putTags(value: CodedeployDeploymentGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodedeployDeploymentGroupTags[] | undefined;
    private _terminationHookEnabled?;
    get terminationHookEnabled(): boolean | cdktn.IResolvable;
    set terminationHookEnabled(value: boolean | cdktn.IResolvable);
    resetTerminationHookEnabled(): void;
    get terminationHookEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _triggerConfigurations;
    get triggerConfigurations(): CodedeployDeploymentGroupTriggerConfigurationsList;
    putTriggerConfigurations(value: CodedeployDeploymentGroupTriggerConfigurations[] | cdktn.IResolvable): void;
    resetTriggerConfigurations(): void;
    get triggerConfigurationsInput(): cdktn.IResolvable | CodedeployDeploymentGroupTriggerConfigurations[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
