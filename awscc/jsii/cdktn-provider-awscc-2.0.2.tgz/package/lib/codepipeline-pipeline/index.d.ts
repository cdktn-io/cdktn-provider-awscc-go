/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodepipelinePipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * The S3 bucket where artifacts for the pipeline are stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#artifact_store CodepipelinePipeline#artifact_store}
    */
    readonly artifactStore?: CodepipelinePipelineArtifactStore;
    /**
    * A mapping of artifactStore objects and their corresponding AWS Regions. There must be an artifact store for the pipeline Region and for each cross-region action in the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#artifact_stores CodepipelinePipeline#artifact_stores}
    */
    readonly artifactStores?: CodepipelinePipelineArtifactStores[] | cdktn.IResolvable;
    /**
    * Represents the input of a DisableStageTransition action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#disable_inbound_stage_transitions CodepipelinePipeline#disable_inbound_stage_transitions}
    */
    readonly disableInboundStageTransitions?: CodepipelinePipelineDisableInboundStageTransitions[] | cdktn.IResolvable;
    /**
    * The method that the pipeline will use to handle multiple executions. The default mode is SUPERSEDED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#execution_mode CodepipelinePipeline#execution_mode}
    */
    readonly executionMode?: string;
    /**
    * The name of the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
    /**
    * CodePipeline provides the following pipeline types, which differ in characteristics and price, so that you can tailor your pipeline features and cost to the needs of your applications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#pipeline_type CodepipelinePipeline#pipeline_type}
    */
    readonly pipelineType?: string;
    /**
    * Indicates whether to rerun the CodePipeline pipeline after you update it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#restart_execution_on_update CodepipelinePipeline#restart_execution_on_update}
    */
    readonly restartExecutionOnUpdate?: boolean | cdktn.IResolvable;
    /**
    * The Amazon Resource Name (ARN) for CodePipeline to use to either perform actions with no actionRoleArn, or to use to assume roles for actions with an actionRoleArn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#role_arn CodepipelinePipeline#role_arn}
    */
    readonly roleArn: string;
    /**
    * Represents information about a stage and its definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#stages CodepipelinePipeline#stages}
    */
    readonly stages: CodepipelinePipelineStages[] | cdktn.IResolvable;
    /**
    * Specifies the tags applied to the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#tags CodepipelinePipeline#tags}
    */
    readonly tags?: CodepipelinePipelineTags[] | cdktn.IResolvable;
    /**
    * The trigger configuration specifying a type of event, such as Git tags, that starts the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#triggers CodepipelinePipeline#triggers}
    */
    readonly triggers?: CodepipelinePipelineTriggers[] | cdktn.IResolvable;
    /**
    * A list that defines the pipeline variables for a pipeline resource. Variable names can have alphanumeric and underscore characters, and the values must match [A-Za-z0-9@\-_]+.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#variables CodepipelinePipeline#variables}
    */
    readonly variables?: CodepipelinePipelineVariables[] | cdktn.IResolvable;
}
export interface CodepipelinePipelineArtifactStoreEncryptionKey {
    /**
    * The ID used to identify the key. For an AWS KMS key, you can use the key ID, the key ARN, or the alias ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#id CodepipelinePipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The type of encryption key, such as an AWS KMS key. When creating or updating a pipeline, the value must be set to 'KMS'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#type CodepipelinePipeline#type}
    */
    readonly type?: string;
}
export declare function codepipelinePipelineArtifactStoreEncryptionKeyToTerraform(struct?: CodepipelinePipelineArtifactStoreEncryptionKey | cdktn.IResolvable): any;
export declare function codepipelinePipelineArtifactStoreEncryptionKeyToHclTerraform(struct?: CodepipelinePipelineArtifactStoreEncryptionKey | cdktn.IResolvable): any;
export declare class CodepipelinePipelineArtifactStoreEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineArtifactStoreEncryptionKey | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineArtifactStoreEncryptionKey | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CodepipelinePipelineArtifactStore {
    /**
    * Represents information about the key used to encrypt data in the artifact store, such as an AWS Key Management Service (AWS KMS) key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#encryption_key CodepipelinePipeline#encryption_key}
    */
    readonly encryptionKey?: CodepipelinePipelineArtifactStoreEncryptionKey;
    /**
    * The S3 bucket used for storing the artifacts for a pipeline. You can specify the name of an S3 bucket but not a folder in the bucket. A folder to contain the pipeline artifacts is created for you based on the name of the pipeline. You can use any S3 bucket in the same AWS Region as the pipeline to store your pipeline artifacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#location CodepipelinePipeline#location}
    */
    readonly location?: string;
    /**
    * The type of the artifact store, such as S3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#type CodepipelinePipeline#type}
    */
    readonly type?: string;
}
export declare function codepipelinePipelineArtifactStoreToTerraform(struct?: CodepipelinePipelineArtifactStore | cdktn.IResolvable): any;
export declare function codepipelinePipelineArtifactStoreToHclTerraform(struct?: CodepipelinePipelineArtifactStore | cdktn.IResolvable): any;
export declare class CodepipelinePipelineArtifactStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineArtifactStore | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineArtifactStore | cdktn.IResolvable | undefined);
    private _encryptionKey;
    get encryptionKey(): CodepipelinePipelineArtifactStoreEncryptionKeyOutputReference;
    putEncryptionKey(value: CodepipelinePipelineArtifactStoreEncryptionKey): void;
    resetEncryptionKey(): void;
    get encryptionKeyInput(): cdktn.IResolvable | CodepipelinePipelineArtifactStoreEncryptionKey | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKey {
    /**
    * The ID used to identify the key. For an AWS KMS key, you can use the key ID, the key ARN, or the alias ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#id CodepipelinePipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The type of encryption key, such as an AWS KMS key. When creating or updating a pipeline, the value must be set to 'KMS'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#type CodepipelinePipeline#type}
    */
    readonly type?: string;
}
export declare function codepipelinePipelineArtifactStoresArtifactStoreEncryptionKeyToTerraform(struct?: CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKey | cdktn.IResolvable): any;
export declare function codepipelinePipelineArtifactStoresArtifactStoreEncryptionKeyToHclTerraform(struct?: CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKey | cdktn.IResolvable): any;
export declare class CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKey | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKey | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CodepipelinePipelineArtifactStoresArtifactStore {
    /**
    * Represents information about the key used to encrypt data in the artifact store, such as an AWS Key Management Service (AWS KMS) key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#encryption_key CodepipelinePipeline#encryption_key}
    */
    readonly encryptionKey?: CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKey;
    /**
    * The S3 bucket used for storing the artifacts for a pipeline. You can specify the name of an S3 bucket but not a folder in the bucket. A folder to contain the pipeline artifacts is created for you based on the name of the pipeline. You can use any S3 bucket in the same AWS Region as the pipeline to store your pipeline artifacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#location CodepipelinePipeline#location}
    */
    readonly location?: string;
    /**
    * The type of the artifact store, such as S3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#type CodepipelinePipeline#type}
    */
    readonly type?: string;
}
export declare function codepipelinePipelineArtifactStoresArtifactStoreToTerraform(struct?: CodepipelinePipelineArtifactStoresArtifactStore | cdktn.IResolvable): any;
export declare function codepipelinePipelineArtifactStoresArtifactStoreToHclTerraform(struct?: CodepipelinePipelineArtifactStoresArtifactStore | cdktn.IResolvable): any;
export declare class CodepipelinePipelineArtifactStoresArtifactStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineArtifactStoresArtifactStore | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineArtifactStoresArtifactStore | cdktn.IResolvable | undefined);
    private _encryptionKey;
    get encryptionKey(): CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKeyOutputReference;
    putEncryptionKey(value: CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKey): void;
    resetEncryptionKey(): void;
    get encryptionKeyInput(): cdktn.IResolvable | CodepipelinePipelineArtifactStoresArtifactStoreEncryptionKey | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CodepipelinePipelineArtifactStores {
    /**
    * The S3 bucket where artifacts for the pipeline are stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#artifact_store CodepipelinePipeline#artifact_store}
    */
    readonly artifactStore?: CodepipelinePipelineArtifactStoresArtifactStore;
    /**
    * The action declaration's AWS Region, such as us-east-1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#region CodepipelinePipeline#region}
    */
    readonly region?: string;
}
export declare function codepipelinePipelineArtifactStoresToTerraform(struct?: CodepipelinePipelineArtifactStores | cdktn.IResolvable): any;
export declare function codepipelinePipelineArtifactStoresToHclTerraform(struct?: CodepipelinePipelineArtifactStores | cdktn.IResolvable): any;
export declare class CodepipelinePipelineArtifactStoresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineArtifactStores | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineArtifactStores | cdktn.IResolvable | undefined);
    private _artifactStore;
    get artifactStore(): CodepipelinePipelineArtifactStoresArtifactStoreOutputReference;
    putArtifactStore(value: CodepipelinePipelineArtifactStoresArtifactStore): void;
    resetArtifactStore(): void;
    get artifactStoreInput(): cdktn.IResolvable | CodepipelinePipelineArtifactStoresArtifactStore | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export declare class CodepipelinePipelineArtifactStoresList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineArtifactStores[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineArtifactStoresOutputReference;
}
export interface CodepipelinePipelineDisableInboundStageTransitions {
    /**
    * The reason given to the user that a stage is disabled, such as waiting for manual approval or manual tests. This message is displayed in the pipeline console UI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#reason CodepipelinePipeline#reason}
    */
    readonly reason?: string;
    /**
    * The name of the stage where you want to disable the inbound or outbound transition of artifacts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#stage_name CodepipelinePipeline#stage_name}
    */
    readonly stageName?: string;
}
export declare function codepipelinePipelineDisableInboundStageTransitionsToTerraform(struct?: CodepipelinePipelineDisableInboundStageTransitions | cdktn.IResolvable): any;
export declare function codepipelinePipelineDisableInboundStageTransitionsToHclTerraform(struct?: CodepipelinePipelineDisableInboundStageTransitions | cdktn.IResolvable): any;
export declare class CodepipelinePipelineDisableInboundStageTransitionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineDisableInboundStageTransitions | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineDisableInboundStageTransitions | cdktn.IResolvable | undefined);
    private _reason?;
    get reason(): string;
    set reason(value: string);
    resetReason(): void;
    get reasonInput(): string | undefined;
    private _stageName?;
    get stageName(): string;
    set stageName(value: string);
    resetStageName(): void;
    get stageNameInput(): string | undefined;
}
export declare class CodepipelinePipelineDisableInboundStageTransitionsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineDisableInboundStageTransitions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineDisableInboundStageTransitionsOutputReference;
}
export interface CodepipelinePipelineStagesActionsActionTypeId {
    /**
    * A category defines what kind of action can be taken in the stage, and constrains the provider type for the action. Valid categories are limited to one of the values below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#category CodepipelinePipeline#category}
    */
    readonly category: string;
    /**
    * The creator of the action being called. There are three valid values for the Owner field in the action category section within your pipeline structure: AWS, ThirdParty, and Custom.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#owner CodepipelinePipeline#owner}
    */
    readonly owner: string;
    /**
    * The provider of the service being called by the action. Valid providers are determined by the action category. For example, an action in the Deploy category type might have a provider of CodeDeploy, which would be specified as CodeDeploy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#provider CodepipelinePipeline#provider}
    */
    readonly provider: string;
    /**
    * A string that describes the action version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#version CodepipelinePipeline#version}
    */
    readonly version: string;
}
export declare function codepipelinePipelineStagesActionsActionTypeIdToTerraform(struct?: CodepipelinePipelineStagesActionsActionTypeId | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesActionsActionTypeIdToHclTerraform(struct?: CodepipelinePipelineStagesActionsActionTypeId | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesActionsActionTypeIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineStagesActionsActionTypeId | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesActionsActionTypeId | cdktn.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    get ownerInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export interface CodepipelinePipelineStagesActionsEnvironmentVariables {
    /**
    * The name of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
    /**
    * The type of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#type CodepipelinePipeline#type}
    */
    readonly type?: string;
    /**
    * The value of the environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#value CodepipelinePipeline#value}
    */
    readonly value?: string;
}
export declare function codepipelinePipelineStagesActionsEnvironmentVariablesToTerraform(struct?: CodepipelinePipelineStagesActionsEnvironmentVariables | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesActionsEnvironmentVariablesToHclTerraform(struct?: CodepipelinePipelineStagesActionsEnvironmentVariables | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesActionsEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesActionsEnvironmentVariables | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesActionsEnvironmentVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodepipelinePipelineStagesActionsEnvironmentVariablesList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesActionsEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesActionsEnvironmentVariablesOutputReference;
}
export interface CodepipelinePipelineStagesActionsInputArtifacts {
    /**
    * The name of the artifact to be worked on (for example, "My App").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
}
export declare function codepipelinePipelineStagesActionsInputArtifactsToTerraform(struct?: CodepipelinePipelineStagesActionsInputArtifacts | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesActionsInputArtifactsToHclTerraform(struct?: CodepipelinePipelineStagesActionsInputArtifacts | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesActionsInputArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesActionsInputArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesActionsInputArtifacts | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodepipelinePipelineStagesActionsInputArtifactsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesActionsInputArtifacts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesActionsInputArtifactsOutputReference;
}
export interface CodepipelinePipelineStagesActionsOutputArtifacts {
    /**
    * The files that you want to associate with the output artifact that will be exported from the compute action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#files CodepipelinePipeline#files}
    */
    readonly files?: string[];
    /**
    * The name of the output of an artifact, such as "My App".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
}
export declare function codepipelinePipelineStagesActionsOutputArtifactsToTerraform(struct?: CodepipelinePipelineStagesActionsOutputArtifacts | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesActionsOutputArtifactsToHclTerraform(struct?: CodepipelinePipelineStagesActionsOutputArtifacts | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesActionsOutputArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesActionsOutputArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesActionsOutputArtifacts | cdktn.IResolvable | undefined);
    private _files?;
    get files(): string[];
    set files(value: string[]);
    resetFiles(): void;
    get filesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodepipelinePipelineStagesActionsOutputArtifactsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesActionsOutputArtifacts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesActionsOutputArtifactsOutputReference;
}
export interface CodepipelinePipelineStagesActions {
    /**
    * Represents information about an action type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#action_type_id CodepipelinePipeline#action_type_id}
    */
    readonly actionTypeId: CodepipelinePipelineStagesActionsActionTypeId;
    /**
    * The shell commands to run with your compute action in CodePipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#commands CodepipelinePipeline#commands}
    */
    readonly commands?: string[];
    /**
    * The action's configuration. These are key-value pairs that specify input values for an action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#configuration CodepipelinePipeline#configuration}
    */
    readonly configuration?: string;
    /**
    * The list of environment variables that are input to a compute based action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#environment_variables CodepipelinePipeline#environment_variables}
    */
    readonly environmentVariables?: CodepipelinePipelineStagesActionsEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#input_artifacts CodepipelinePipeline#input_artifacts}
    */
    readonly inputArtifacts?: CodepipelinePipelineStagesActionsInputArtifacts[] | cdktn.IResolvable;
    /**
    * The action declaration's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name: string;
    /**
    * The variable namespace associated with the action. All variables produced as output by this action fall under this namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#namespace CodepipelinePipeline#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#output_artifacts CodepipelinePipeline#output_artifacts}
    */
    readonly outputArtifacts?: CodepipelinePipelineStagesActionsOutputArtifacts[] | cdktn.IResolvable;
    /**
    * The list of variables that are to be exported from the compute action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#output_variables CodepipelinePipeline#output_variables}
    */
    readonly outputVariables?: string[];
    /**
    * The action declaration's AWS Region, such as us-east-1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#region CodepipelinePipeline#region}
    */
    readonly region?: string;
    /**
    * The ARN of the IAM service role that performs the declared action. This is assumed through the roleArn for the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#role_arn CodepipelinePipeline#role_arn}
    */
    readonly roleArn?: string;
    /**
    * The order in which actions are run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#run_order CodepipelinePipeline#run_order}
    */
    readonly runOrder?: number;
    /**
    * A timeout duration in minutes that can be applied against the ActionType?s default timeout value specified in Quotas for AWS CodePipeline. This attribute is available only to the manual approval ActionType.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#timeout_in_minutes CodepipelinePipeline#timeout_in_minutes}
    */
    readonly timeoutInMinutes?: number;
}
export declare function codepipelinePipelineStagesActionsToTerraform(struct?: CodepipelinePipelineStagesActions | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesActionsToHclTerraform(struct?: CodepipelinePipelineStagesActions | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesActions | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesActions | cdktn.IResolvable | undefined);
    private _actionTypeId;
    get actionTypeId(): CodepipelinePipelineStagesActionsActionTypeIdOutputReference;
    putActionTypeId(value: CodepipelinePipelineStagesActionsActionTypeId): void;
    get actionTypeIdInput(): cdktn.IResolvable | CodepipelinePipelineStagesActionsActionTypeId | undefined;
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    resetCommands(): void;
    get commandsInput(): string[] | undefined;
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
    private _environmentVariables;
    get environmentVariables(): CodepipelinePipelineStagesActionsEnvironmentVariablesList;
    putEnvironmentVariables(value: CodepipelinePipelineStagesActionsEnvironmentVariables[] | cdktn.IResolvable): void;
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): cdktn.IResolvable | CodepipelinePipelineStagesActionsEnvironmentVariables[] | undefined;
    private _inputArtifacts;
    get inputArtifacts(): CodepipelinePipelineStagesActionsInputArtifactsList;
    putInputArtifacts(value: CodepipelinePipelineStagesActionsInputArtifacts[] | cdktn.IResolvable): void;
    resetInputArtifacts(): void;
    get inputArtifactsInput(): cdktn.IResolvable | CodepipelinePipelineStagesActionsInputArtifacts[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _outputArtifacts;
    get outputArtifacts(): CodepipelinePipelineStagesActionsOutputArtifactsList;
    putOutputArtifacts(value: CodepipelinePipelineStagesActionsOutputArtifacts[] | cdktn.IResolvable): void;
    resetOutputArtifacts(): void;
    get outputArtifactsInput(): cdktn.IResolvable | CodepipelinePipelineStagesActionsOutputArtifacts[] | undefined;
    private _outputVariables?;
    get outputVariables(): string[];
    set outputVariables(value: string[]);
    resetOutputVariables(): void;
    get outputVariablesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _runOrder?;
    get runOrder(): number;
    set runOrder(value: number);
    resetRunOrder(): void;
    get runOrderInput(): number | undefined;
    private _timeoutInMinutes?;
    get timeoutInMinutes(): number;
    set timeoutInMinutes(value: number);
    resetTimeoutInMinutes(): void;
    get timeoutInMinutesInput(): number | undefined;
}
export declare class CodepipelinePipelineStagesActionsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesActionsOutputReference;
}
export interface CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts {
    /**
    * The name of the artifact to be worked on (for example, "My App").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
}
export declare function codepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifactsToTerraform(struct?: CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifactsToHclTerraform(struct?: CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifactsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifactsOutputReference;
}
export interface CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeId {
    /**
    * A category for the provider type for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#category CodepipelinePipeline#category}
    */
    readonly category?: string;
    /**
    * The creator of the rule being called. Only AWS is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#owner CodepipelinePipeline#owner}
    */
    readonly owner?: string;
    /**
    * The provider of the service being called by the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#provider CodepipelinePipeline#provider}
    */
    readonly provider?: string;
    /**
    * A string that describes the rule version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#version CodepipelinePipeline#version}
    */
    readonly version?: string;
}
export declare function codepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeIdToTerraform(struct?: CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeId | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeIdToHclTerraform(struct?: CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeId | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeId | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeId | cdktn.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CodepipelinePipelineStagesBeforeEntryConditionsRules {
    /**
    * The shell commands to run with your compute action in CodePipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#commands CodepipelinePipeline#commands}
    */
    readonly commands?: string[];
    /**
    * The rule's configuration. These are key-value pairs that specify input values for a rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#configuration CodepipelinePipeline#configuration}
    */
    readonly configuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#input_artifacts CodepipelinePipeline#input_artifacts}
    */
    readonly inputArtifacts?: CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts[] | cdktn.IResolvable;
    /**
    * The rule declaration's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
    /**
    * The rule declaration's AWS Region, such as us-east-1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#region CodepipelinePipeline#region}
    */
    readonly region?: string;
    /**
    * The ARN of the IAM service role that performs the declared rule. This is assumed through the roleArn for the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#role_arn CodepipelinePipeline#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Represents information about a rule type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#rule_type_id CodepipelinePipeline#rule_type_id}
    */
    readonly ruleTypeId?: CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeId;
}
export declare function codepipelinePipelineStagesBeforeEntryConditionsRulesToTerraform(struct?: CodepipelinePipelineStagesBeforeEntryConditionsRules | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesBeforeEntryConditionsRulesToHclTerraform(struct?: CodepipelinePipelineStagesBeforeEntryConditionsRules | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesBeforeEntryConditionsRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesBeforeEntryConditionsRules | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesBeforeEntryConditionsRules | cdktn.IResolvable | undefined);
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    resetCommands(): void;
    get commandsInput(): string[] | undefined;
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
    private _inputArtifacts;
    get inputArtifacts(): CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifactsList;
    putInputArtifacts(value: CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts[] | cdktn.IResolvable): void;
    resetInputArtifacts(): void;
    get inputArtifactsInput(): cdktn.IResolvable | CodepipelinePipelineStagesBeforeEntryConditionsRulesInputArtifacts[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _ruleTypeId;
    get ruleTypeId(): CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeIdOutputReference;
    putRuleTypeId(value: CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeId): void;
    resetRuleTypeId(): void;
    get ruleTypeIdInput(): cdktn.IResolvable | CodepipelinePipelineStagesBeforeEntryConditionsRulesRuleTypeId | undefined;
}
export declare class CodepipelinePipelineStagesBeforeEntryConditionsRulesList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesBeforeEntryConditionsRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesBeforeEntryConditionsRulesOutputReference;
}
export interface CodepipelinePipelineStagesBeforeEntryConditions {
    /**
    * The specified result for when the failure conditions are met, such as rolling back the stage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#result CodepipelinePipeline#result}
    */
    readonly result?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#rules CodepipelinePipeline#rules}
    */
    readonly rules?: CodepipelinePipelineStagesBeforeEntryConditionsRules[] | cdktn.IResolvable;
}
export declare function codepipelinePipelineStagesBeforeEntryConditionsToTerraform(struct?: CodepipelinePipelineStagesBeforeEntryConditions | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesBeforeEntryConditionsToHclTerraform(struct?: CodepipelinePipelineStagesBeforeEntryConditions | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesBeforeEntryConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesBeforeEntryConditions | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesBeforeEntryConditions | cdktn.IResolvable | undefined);
    private _result?;
    get result(): string;
    set result(value: string);
    resetResult(): void;
    get resultInput(): string | undefined;
    private _rules;
    get rules(): CodepipelinePipelineStagesBeforeEntryConditionsRulesList;
    putRules(value: CodepipelinePipelineStagesBeforeEntryConditionsRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | CodepipelinePipelineStagesBeforeEntryConditionsRules[] | undefined;
}
export declare class CodepipelinePipelineStagesBeforeEntryConditionsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesBeforeEntryConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesBeforeEntryConditionsOutputReference;
}
export interface CodepipelinePipelineStagesBeforeEntry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#conditions CodepipelinePipeline#conditions}
    */
    readonly conditions?: CodepipelinePipelineStagesBeforeEntryConditions[] | cdktn.IResolvable;
}
export declare function codepipelinePipelineStagesBeforeEntryToTerraform(struct?: CodepipelinePipelineStagesBeforeEntry | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesBeforeEntryToHclTerraform(struct?: CodepipelinePipelineStagesBeforeEntry | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesBeforeEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineStagesBeforeEntry | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesBeforeEntry | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): CodepipelinePipelineStagesBeforeEntryConditionsList;
    putConditions(value: CodepipelinePipelineStagesBeforeEntryConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | CodepipelinePipelineStagesBeforeEntryConditions[] | undefined;
}
export interface CodepipelinePipelineStagesBlockers {
    /**
    * Reserved for future use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
    /**
    * Reserved for future use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#type CodepipelinePipeline#type}
    */
    readonly type?: string;
}
export declare function codepipelinePipelineStagesBlockersToTerraform(struct?: CodepipelinePipelineStagesBlockers | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesBlockersToHclTerraform(struct?: CodepipelinePipelineStagesBlockers | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesBlockersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesBlockers | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesBlockers | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CodepipelinePipelineStagesBlockersList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesBlockers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesBlockersOutputReference;
}
export interface CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts {
    /**
    * The name of the artifact to be worked on (for example, "My App").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
}
export declare function codepipelinePipelineStagesOnFailureConditionsRulesInputArtifactsToTerraform(struct?: CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnFailureConditionsRulesInputArtifactsToHclTerraform(struct?: CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifactsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifactsOutputReference;
}
export interface CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeId {
    /**
    * A category for the provider type for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#category CodepipelinePipeline#category}
    */
    readonly category?: string;
    /**
    * The creator of the rule being called. Only AWS is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#owner CodepipelinePipeline#owner}
    */
    readonly owner?: string;
    /**
    * The provider of the service being called by the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#provider CodepipelinePipeline#provider}
    */
    readonly provider?: string;
    /**
    * A string that describes the rule version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#version CodepipelinePipeline#version}
    */
    readonly version?: string;
}
export declare function codepipelinePipelineStagesOnFailureConditionsRulesRuleTypeIdToTerraform(struct?: CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeId | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnFailureConditionsRulesRuleTypeIdToHclTerraform(struct?: CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeId | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeId | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeId | cdktn.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CodepipelinePipelineStagesOnFailureConditionsRules {
    /**
    * The shell commands to run with your compute action in CodePipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#commands CodepipelinePipeline#commands}
    */
    readonly commands?: string[];
    /**
    * The rule's configuration. These are key-value pairs that specify input values for a rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#configuration CodepipelinePipeline#configuration}
    */
    readonly configuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#input_artifacts CodepipelinePipeline#input_artifacts}
    */
    readonly inputArtifacts?: CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts[] | cdktn.IResolvable;
    /**
    * The rule declaration's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
    /**
    * The rule declaration's AWS Region, such as us-east-1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#region CodepipelinePipeline#region}
    */
    readonly region?: string;
    /**
    * The ARN of the IAM service role that performs the declared rule. This is assumed through the roleArn for the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#role_arn CodepipelinePipeline#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Represents information about a rule type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#rule_type_id CodepipelinePipeline#rule_type_id}
    */
    readonly ruleTypeId?: CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeId;
}
export declare function codepipelinePipelineStagesOnFailureConditionsRulesToTerraform(struct?: CodepipelinePipelineStagesOnFailureConditionsRules | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnFailureConditionsRulesToHclTerraform(struct?: CodepipelinePipelineStagesOnFailureConditionsRules | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnFailureConditionsRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesOnFailureConditionsRules | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnFailureConditionsRules | cdktn.IResolvable | undefined);
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    resetCommands(): void;
    get commandsInput(): string[] | undefined;
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
    private _inputArtifacts;
    get inputArtifacts(): CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifactsList;
    putInputArtifacts(value: CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts[] | cdktn.IResolvable): void;
    resetInputArtifacts(): void;
    get inputArtifactsInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnFailureConditionsRulesInputArtifacts[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _ruleTypeId;
    get ruleTypeId(): CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeIdOutputReference;
    putRuleTypeId(value: CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeId): void;
    resetRuleTypeId(): void;
    get ruleTypeIdInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnFailureConditionsRulesRuleTypeId | undefined;
}
export declare class CodepipelinePipelineStagesOnFailureConditionsRulesList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesOnFailureConditionsRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesOnFailureConditionsRulesOutputReference;
}
export interface CodepipelinePipelineStagesOnFailureConditions {
    /**
    * The specified result for when the failure conditions are met, such as rolling back the stage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#result CodepipelinePipeline#result}
    */
    readonly result?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#rules CodepipelinePipeline#rules}
    */
    readonly rules?: CodepipelinePipelineStagesOnFailureConditionsRules[] | cdktn.IResolvable;
}
export declare function codepipelinePipelineStagesOnFailureConditionsToTerraform(struct?: CodepipelinePipelineStagesOnFailureConditions | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnFailureConditionsToHclTerraform(struct?: CodepipelinePipelineStagesOnFailureConditions | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnFailureConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesOnFailureConditions | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnFailureConditions | cdktn.IResolvable | undefined);
    private _result?;
    get result(): string;
    set result(value: string);
    resetResult(): void;
    get resultInput(): string | undefined;
    private _rules;
    get rules(): CodepipelinePipelineStagesOnFailureConditionsRulesList;
    putRules(value: CodepipelinePipelineStagesOnFailureConditionsRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnFailureConditionsRules[] | undefined;
}
export declare class CodepipelinePipelineStagesOnFailureConditionsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesOnFailureConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesOnFailureConditionsOutputReference;
}
export interface CodepipelinePipelineStagesOnFailureRetryConfiguration {
    /**
    * The specified retry mode type for the given stage. FAILED_ACTIONS will retry only the failed actions. ALL_ACTIONS will retry both failed and successful
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#retry_mode CodepipelinePipeline#retry_mode}
    */
    readonly retryMode?: string;
}
export declare function codepipelinePipelineStagesOnFailureRetryConfigurationToTerraform(struct?: CodepipelinePipelineStagesOnFailureRetryConfiguration | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnFailureRetryConfigurationToHclTerraform(struct?: CodepipelinePipelineStagesOnFailureRetryConfiguration | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnFailureRetryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineStagesOnFailureRetryConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnFailureRetryConfiguration | cdktn.IResolvable | undefined);
    private _retryMode?;
    get retryMode(): string;
    set retryMode(value: string);
    resetRetryMode(): void;
    get retryModeInput(): string | undefined;
}
export interface CodepipelinePipelineStagesOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#conditions CodepipelinePipeline#conditions}
    */
    readonly conditions?: CodepipelinePipelineStagesOnFailureConditions[] | cdktn.IResolvable;
    /**
    * The specified result for when the failure conditions are met, such as rolling back the stage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#result CodepipelinePipeline#result}
    */
    readonly result?: string;
    /**
    * The configuration that specifies the retry configuration for a stage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#retry_configuration CodepipelinePipeline#retry_configuration}
    */
    readonly retryConfiguration?: CodepipelinePipelineStagesOnFailureRetryConfiguration;
}
export declare function codepipelinePipelineStagesOnFailureToTerraform(struct?: CodepipelinePipelineStagesOnFailure | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnFailureToHclTerraform(struct?: CodepipelinePipelineStagesOnFailure | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineStagesOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnFailure | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): CodepipelinePipelineStagesOnFailureConditionsList;
    putConditions(value: CodepipelinePipelineStagesOnFailureConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnFailureConditions[] | undefined;
    private _result?;
    get result(): string;
    set result(value: string);
    resetResult(): void;
    get resultInput(): string | undefined;
    private _retryConfiguration;
    get retryConfiguration(): CodepipelinePipelineStagesOnFailureRetryConfigurationOutputReference;
    putRetryConfiguration(value: CodepipelinePipelineStagesOnFailureRetryConfiguration): void;
    resetRetryConfiguration(): void;
    get retryConfigurationInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnFailureRetryConfiguration | undefined;
}
export interface CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts {
    /**
    * The name of the artifact to be worked on (for example, "My App").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
}
export declare function codepipelinePipelineStagesOnSuccessConditionsRulesInputArtifactsToTerraform(struct?: CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnSuccessConditionsRulesInputArtifactsToHclTerraform(struct?: CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifactsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifactsOutputReference;
}
export interface CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeId {
    /**
    * A category for the provider type for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#category CodepipelinePipeline#category}
    */
    readonly category?: string;
    /**
    * The creator of the rule being called. Only AWS is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#owner CodepipelinePipeline#owner}
    */
    readonly owner?: string;
    /**
    * The provider of the service being called by the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#provider CodepipelinePipeline#provider}
    */
    readonly provider?: string;
    /**
    * A string that describes the rule version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#version CodepipelinePipeline#version}
    */
    readonly version?: string;
}
export declare function codepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeIdToTerraform(struct?: CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeId | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeIdToHclTerraform(struct?: CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeId | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeId | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeId | cdktn.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CodepipelinePipelineStagesOnSuccessConditionsRules {
    /**
    * The shell commands to run with your compute action in CodePipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#commands CodepipelinePipeline#commands}
    */
    readonly commands?: string[];
    /**
    * The rule's configuration. These are key-value pairs that specify input values for a rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#configuration CodepipelinePipeline#configuration}
    */
    readonly configuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#input_artifacts CodepipelinePipeline#input_artifacts}
    */
    readonly inputArtifacts?: CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts[] | cdktn.IResolvable;
    /**
    * The rule declaration's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
    /**
    * The rule declaration's AWS Region, such as us-east-1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#region CodepipelinePipeline#region}
    */
    readonly region?: string;
    /**
    * The ARN of the IAM service role that performs the declared rule. This is assumed through the roleArn for the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#role_arn CodepipelinePipeline#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Represents information about a rule type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#rule_type_id CodepipelinePipeline#rule_type_id}
    */
    readonly ruleTypeId?: CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeId;
}
export declare function codepipelinePipelineStagesOnSuccessConditionsRulesToTerraform(struct?: CodepipelinePipelineStagesOnSuccessConditionsRules | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnSuccessConditionsRulesToHclTerraform(struct?: CodepipelinePipelineStagesOnSuccessConditionsRules | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnSuccessConditionsRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesOnSuccessConditionsRules | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnSuccessConditionsRules | cdktn.IResolvable | undefined);
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    resetCommands(): void;
    get commandsInput(): string[] | undefined;
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
    private _inputArtifacts;
    get inputArtifacts(): CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifactsList;
    putInputArtifacts(value: CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts[] | cdktn.IResolvable): void;
    resetInputArtifacts(): void;
    get inputArtifactsInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnSuccessConditionsRulesInputArtifacts[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _ruleTypeId;
    get ruleTypeId(): CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeIdOutputReference;
    putRuleTypeId(value: CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeId): void;
    resetRuleTypeId(): void;
    get ruleTypeIdInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnSuccessConditionsRulesRuleTypeId | undefined;
}
export declare class CodepipelinePipelineStagesOnSuccessConditionsRulesList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesOnSuccessConditionsRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesOnSuccessConditionsRulesOutputReference;
}
export interface CodepipelinePipelineStagesOnSuccessConditions {
    /**
    * The specified result for when the failure conditions are met, such as rolling back the stage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#result CodepipelinePipeline#result}
    */
    readonly result?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#rules CodepipelinePipeline#rules}
    */
    readonly rules?: CodepipelinePipelineStagesOnSuccessConditionsRules[] | cdktn.IResolvable;
}
export declare function codepipelinePipelineStagesOnSuccessConditionsToTerraform(struct?: CodepipelinePipelineStagesOnSuccessConditions | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnSuccessConditionsToHclTerraform(struct?: CodepipelinePipelineStagesOnSuccessConditions | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnSuccessConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStagesOnSuccessConditions | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnSuccessConditions | cdktn.IResolvable | undefined);
    private _result?;
    get result(): string;
    set result(value: string);
    resetResult(): void;
    get resultInput(): string | undefined;
    private _rules;
    get rules(): CodepipelinePipelineStagesOnSuccessConditionsRulesList;
    putRules(value: CodepipelinePipelineStagesOnSuccessConditionsRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnSuccessConditionsRules[] | undefined;
}
export declare class CodepipelinePipelineStagesOnSuccessConditionsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStagesOnSuccessConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesOnSuccessConditionsOutputReference;
}
export interface CodepipelinePipelineStagesOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#conditions CodepipelinePipeline#conditions}
    */
    readonly conditions?: CodepipelinePipelineStagesOnSuccessConditions[] | cdktn.IResolvable;
}
export declare function codepipelinePipelineStagesOnSuccessToTerraform(struct?: CodepipelinePipelineStagesOnSuccess | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesOnSuccessToHclTerraform(struct?: CodepipelinePipelineStagesOnSuccess | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineStagesOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStagesOnSuccess | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): CodepipelinePipelineStagesOnSuccessConditionsList;
    putConditions(value: CodepipelinePipelineStagesOnSuccessConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnSuccessConditions[] | undefined;
}
export interface CodepipelinePipelineStages {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#actions CodepipelinePipeline#actions}
    */
    readonly actions: CodepipelinePipelineStagesActions[] | cdktn.IResolvable;
    /**
    * The method to use before stage runs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#before_entry CodepipelinePipeline#before_entry}
    */
    readonly beforeEntry?: CodepipelinePipelineStagesBeforeEntry;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#blockers CodepipelinePipeline#blockers}
    */
    readonly blockers?: CodepipelinePipelineStagesBlockers[] | cdktn.IResolvable;
    /**
    * The name of the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name: string;
    /**
    * The method to use when a stage has not completed successfully
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#on_failure CodepipelinePipeline#on_failure}
    */
    readonly onFailure?: CodepipelinePipelineStagesOnFailure;
    /**
    * The method to use when a stage has completed successfully
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#on_success CodepipelinePipeline#on_success}
    */
    readonly onSuccess?: CodepipelinePipelineStagesOnSuccess;
}
export declare function codepipelinePipelineStagesToTerraform(struct?: CodepipelinePipelineStages | cdktn.IResolvable): any;
export declare function codepipelinePipelineStagesToHclTerraform(struct?: CodepipelinePipelineStages | cdktn.IResolvable): any;
export declare class CodepipelinePipelineStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineStages | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineStages | cdktn.IResolvable | undefined);
    private _actions;
    get actions(): CodepipelinePipelineStagesActionsList;
    putActions(value: CodepipelinePipelineStagesActions[] | cdktn.IResolvable): void;
    get actionsInput(): cdktn.IResolvable | CodepipelinePipelineStagesActions[] | undefined;
    private _beforeEntry;
    get beforeEntry(): CodepipelinePipelineStagesBeforeEntryOutputReference;
    putBeforeEntry(value: CodepipelinePipelineStagesBeforeEntry): void;
    resetBeforeEntry(): void;
    get beforeEntryInput(): cdktn.IResolvable | CodepipelinePipelineStagesBeforeEntry | undefined;
    private _blockers;
    get blockers(): CodepipelinePipelineStagesBlockersList;
    putBlockers(value: CodepipelinePipelineStagesBlockers[] | cdktn.IResolvable): void;
    resetBlockers(): void;
    get blockersInput(): cdktn.IResolvable | CodepipelinePipelineStagesBlockers[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onFailure;
    get onFailure(): CodepipelinePipelineStagesOnFailureOutputReference;
    putOnFailure(value: CodepipelinePipelineStagesOnFailure): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnFailure | undefined;
    private _onSuccess;
    get onSuccess(): CodepipelinePipelineStagesOnSuccessOutputReference;
    putOnSuccess(value: CodepipelinePipelineStagesOnSuccess): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | CodepipelinePipelineStagesOnSuccess | undefined;
}
export declare class CodepipelinePipelineStagesList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineStages[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineStagesOutputReference;
}
export interface CodepipelinePipelineTags {
    /**
    * The tag's key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#key CodepipelinePipeline#key}
    */
    readonly key?: string;
    /**
    * The tag's value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#value CodepipelinePipeline#value}
    */
    readonly value?: string;
}
export declare function codepipelinePipelineTagsToTerraform(struct?: CodepipelinePipelineTags | cdktn.IResolvable): any;
export declare function codepipelinePipelineTagsToHclTerraform(struct?: CodepipelinePipelineTags | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodepipelinePipelineTagsList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineTagsOutputReference;
}
export interface CodepipelinePipelineTriggersGitConfigurationPullRequestBranches {
    /**
    * The list of patterns of Git branches that, when a commit is pushed, are to be excluded from starting the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#excludes CodepipelinePipeline#excludes}
    */
    readonly excludes?: string[];
    /**
    * The list of patterns of Git branches that, when a commit is pushed, are to be included as criteria that starts the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#includes CodepipelinePipeline#includes}
    */
    readonly includes?: string[];
}
export declare function codepipelinePipelineTriggersGitConfigurationPullRequestBranchesToTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPullRequestBranches | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersGitConfigurationPullRequestBranchesToHclTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPullRequestBranches | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersGitConfigurationPullRequestBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineTriggersGitConfigurationPullRequestBranches | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggersGitConfigurationPullRequestBranches | cdktn.IResolvable | undefined);
    private _excludes?;
    get excludes(): string[];
    set excludes(value: string[]);
    resetExcludes(): void;
    get excludesInput(): string[] | undefined;
    private _includes?;
    get includes(): string[];
    set includes(value: string[]);
    resetIncludes(): void;
    get includesInput(): string[] | undefined;
}
export interface CodepipelinePipelineTriggersGitConfigurationPullRequestFilePaths {
    /**
    * The list of patterns of Git repository file paths that, when a commit is pushed, are to be excluded from starting the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#excludes CodepipelinePipeline#excludes}
    */
    readonly excludes?: string[];
    /**
    * The list of patterns of Git repository file paths that, when a commit is pushed, are to be included as criteria that starts the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#includes CodepipelinePipeline#includes}
    */
    readonly includes?: string[];
}
export declare function codepipelinePipelineTriggersGitConfigurationPullRequestFilePathsToTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPullRequestFilePaths | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersGitConfigurationPullRequestFilePathsToHclTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPullRequestFilePaths | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersGitConfigurationPullRequestFilePathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineTriggersGitConfigurationPullRequestFilePaths | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggersGitConfigurationPullRequestFilePaths | cdktn.IResolvable | undefined);
    private _excludes?;
    get excludes(): string[];
    set excludes(value: string[]);
    resetExcludes(): void;
    get excludesInput(): string[] | undefined;
    private _includes?;
    get includes(): string[];
    set includes(value: string[]);
    resetIncludes(): void;
    get includesInput(): string[] | undefined;
}
export interface CodepipelinePipelineTriggersGitConfigurationPullRequest {
    /**
    * The Git repository branches specified as filter criteria to start the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#branches CodepipelinePipeline#branches}
    */
    readonly branches?: CodepipelinePipelineTriggersGitConfigurationPullRequestBranches;
    /**
    * The field that specifies which pull request events to filter on (opened, updated, closed) for the trigger configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#events CodepipelinePipeline#events}
    */
    readonly events?: string[];
    /**
    * The Git repository file paths specified as filter criteria to start the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#file_paths CodepipelinePipeline#file_paths}
    */
    readonly filePaths?: CodepipelinePipelineTriggersGitConfigurationPullRequestFilePaths;
}
export declare function codepipelinePipelineTriggersGitConfigurationPullRequestToTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPullRequest | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersGitConfigurationPullRequestToHclTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPullRequest | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersGitConfigurationPullRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineTriggersGitConfigurationPullRequest | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggersGitConfigurationPullRequest | cdktn.IResolvable | undefined);
    private _branches;
    get branches(): CodepipelinePipelineTriggersGitConfigurationPullRequestBranchesOutputReference;
    putBranches(value: CodepipelinePipelineTriggersGitConfigurationPullRequestBranches): void;
    resetBranches(): void;
    get branchesInput(): cdktn.IResolvable | CodepipelinePipelineTriggersGitConfigurationPullRequestBranches | undefined;
    private _events?;
    get events(): string[];
    set events(value: string[]);
    resetEvents(): void;
    get eventsInput(): string[] | undefined;
    private _filePaths;
    get filePaths(): CodepipelinePipelineTriggersGitConfigurationPullRequestFilePathsOutputReference;
    putFilePaths(value: CodepipelinePipelineTriggersGitConfigurationPullRequestFilePaths): void;
    resetFilePaths(): void;
    get filePathsInput(): cdktn.IResolvable | CodepipelinePipelineTriggersGitConfigurationPullRequestFilePaths | undefined;
}
export declare class CodepipelinePipelineTriggersGitConfigurationPullRequestList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineTriggersGitConfigurationPullRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineTriggersGitConfigurationPullRequestOutputReference;
}
export interface CodepipelinePipelineTriggersGitConfigurationPushBranches {
    /**
    * The list of patterns of Git branches that, when a commit is pushed, are to be excluded from starting the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#excludes CodepipelinePipeline#excludes}
    */
    readonly excludes?: string[];
    /**
    * The list of patterns of Git branches that, when a commit is pushed, are to be included as criteria that starts the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#includes CodepipelinePipeline#includes}
    */
    readonly includes?: string[];
}
export declare function codepipelinePipelineTriggersGitConfigurationPushBranchesToTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPushBranches | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersGitConfigurationPushBranchesToHclTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPushBranches | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersGitConfigurationPushBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineTriggersGitConfigurationPushBranches | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggersGitConfigurationPushBranches | cdktn.IResolvable | undefined);
    private _excludes?;
    get excludes(): string[];
    set excludes(value: string[]);
    resetExcludes(): void;
    get excludesInput(): string[] | undefined;
    private _includes?;
    get includes(): string[];
    set includes(value: string[]);
    resetIncludes(): void;
    get includesInput(): string[] | undefined;
}
export interface CodepipelinePipelineTriggersGitConfigurationPushFilePaths {
    /**
    * The list of patterns of Git repository file paths that, when a commit is pushed, are to be excluded from starting the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#excludes CodepipelinePipeline#excludes}
    */
    readonly excludes?: string[];
    /**
    * The list of patterns of Git repository file paths that, when a commit is pushed, are to be included as criteria that starts the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#includes CodepipelinePipeline#includes}
    */
    readonly includes?: string[];
}
export declare function codepipelinePipelineTriggersGitConfigurationPushFilePathsToTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPushFilePaths | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersGitConfigurationPushFilePathsToHclTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPushFilePaths | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersGitConfigurationPushFilePathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineTriggersGitConfigurationPushFilePaths | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggersGitConfigurationPushFilePaths | cdktn.IResolvable | undefined);
    private _excludes?;
    get excludes(): string[];
    set excludes(value: string[]);
    resetExcludes(): void;
    get excludesInput(): string[] | undefined;
    private _includes?;
    get includes(): string[];
    set includes(value: string[]);
    resetIncludes(): void;
    get includesInput(): string[] | undefined;
}
export interface CodepipelinePipelineTriggersGitConfigurationPushTags {
    /**
    * The list of patterns of Git tags that, when pushed, are to be excluded from starting the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#excludes CodepipelinePipeline#excludes}
    */
    readonly excludes?: string[];
    /**
    * The list of patterns of Git tags that, when pushed, are to be included as criteria that starts the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#includes CodepipelinePipeline#includes}
    */
    readonly includes?: string[];
}
export declare function codepipelinePipelineTriggersGitConfigurationPushTagsToTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPushTags | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersGitConfigurationPushTagsToHclTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPushTags | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersGitConfigurationPushTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineTriggersGitConfigurationPushTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggersGitConfigurationPushTags | cdktn.IResolvable | undefined);
    private _excludes?;
    get excludes(): string[];
    set excludes(value: string[]);
    resetExcludes(): void;
    get excludesInput(): string[] | undefined;
    private _includes?;
    get includes(): string[];
    set includes(value: string[]);
    resetIncludes(): void;
    get includesInput(): string[] | undefined;
}
export interface CodepipelinePipelineTriggersGitConfigurationPush {
    /**
    * The Git repository branches specified as filter criteria to start the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#branches CodepipelinePipeline#branches}
    */
    readonly branches?: CodepipelinePipelineTriggersGitConfigurationPushBranches;
    /**
    * The Git repository file paths specified as filter criteria to start the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#file_paths CodepipelinePipeline#file_paths}
    */
    readonly filePaths?: CodepipelinePipelineTriggersGitConfigurationPushFilePaths;
    /**
    * The Git tags specified as filter criteria for whether a Git tag repository event will start the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#tags CodepipelinePipeline#tags}
    */
    readonly tags?: CodepipelinePipelineTriggersGitConfigurationPushTags;
}
export declare function codepipelinePipelineTriggersGitConfigurationPushToTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPush | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersGitConfigurationPushToHclTerraform(struct?: CodepipelinePipelineTriggersGitConfigurationPush | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersGitConfigurationPushOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineTriggersGitConfigurationPush | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggersGitConfigurationPush | cdktn.IResolvable | undefined);
    private _branches;
    get branches(): CodepipelinePipelineTriggersGitConfigurationPushBranchesOutputReference;
    putBranches(value: CodepipelinePipelineTriggersGitConfigurationPushBranches): void;
    resetBranches(): void;
    get branchesInput(): cdktn.IResolvable | CodepipelinePipelineTriggersGitConfigurationPushBranches | undefined;
    private _filePaths;
    get filePaths(): CodepipelinePipelineTriggersGitConfigurationPushFilePathsOutputReference;
    putFilePaths(value: CodepipelinePipelineTriggersGitConfigurationPushFilePaths): void;
    resetFilePaths(): void;
    get filePathsInput(): cdktn.IResolvable | CodepipelinePipelineTriggersGitConfigurationPushFilePaths | undefined;
    private _tags;
    get tags(): CodepipelinePipelineTriggersGitConfigurationPushTagsOutputReference;
    putTags(value: CodepipelinePipelineTriggersGitConfigurationPushTags): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodepipelinePipelineTriggersGitConfigurationPushTags | undefined;
}
export declare class CodepipelinePipelineTriggersGitConfigurationPushList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineTriggersGitConfigurationPush[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineTriggersGitConfigurationPushOutputReference;
}
export interface CodepipelinePipelineTriggersGitConfiguration {
    /**
    * The field where the repository event that will start the pipeline is specified as pull requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#pull_request CodepipelinePipeline#pull_request}
    */
    readonly pullRequest?: CodepipelinePipelineTriggersGitConfigurationPullRequest[] | cdktn.IResolvable;
    /**
    * The field where the repository event that will start the pipeline, such as pushing Git tags, is specified with details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#push CodepipelinePipeline#push}
    */
    readonly push?: CodepipelinePipelineTriggersGitConfigurationPush[] | cdktn.IResolvable;
    /**
    * The name of the pipeline source action where the trigger configuration, such as Git tags, is specified. The trigger configuration will start the pipeline upon the specified change only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#source_action_name CodepipelinePipeline#source_action_name}
    */
    readonly sourceActionName?: string;
}
export declare function codepipelinePipelineTriggersGitConfigurationToTerraform(struct?: CodepipelinePipelineTriggersGitConfiguration | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersGitConfigurationToHclTerraform(struct?: CodepipelinePipelineTriggersGitConfiguration | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersGitConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelinePipelineTriggersGitConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggersGitConfiguration | cdktn.IResolvable | undefined);
    private _pullRequest;
    get pullRequest(): CodepipelinePipelineTriggersGitConfigurationPullRequestList;
    putPullRequest(value: CodepipelinePipelineTriggersGitConfigurationPullRequest[] | cdktn.IResolvable): void;
    resetPullRequest(): void;
    get pullRequestInput(): cdktn.IResolvable | CodepipelinePipelineTriggersGitConfigurationPullRequest[] | undefined;
    private _push;
    get push(): CodepipelinePipelineTriggersGitConfigurationPushList;
    putPush(value: CodepipelinePipelineTriggersGitConfigurationPush[] | cdktn.IResolvable): void;
    resetPush(): void;
    get pushInput(): cdktn.IResolvable | CodepipelinePipelineTriggersGitConfigurationPush[] | undefined;
    private _sourceActionName?;
    get sourceActionName(): string;
    set sourceActionName(value: string);
    resetSourceActionName(): void;
    get sourceActionNameInput(): string | undefined;
}
export interface CodepipelinePipelineTriggers {
    /**
    * A type of trigger configuration for Git-based source actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#git_configuration CodepipelinePipeline#git_configuration}
    */
    readonly gitConfiguration?: CodepipelinePipelineTriggersGitConfiguration;
    /**
    * The source provider for the event, such as connections configured for a repository with Git tags, for the specified trigger configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#provider_type CodepipelinePipeline#provider_type}
    */
    readonly providerType?: string;
}
export declare function codepipelinePipelineTriggersToTerraform(struct?: CodepipelinePipelineTriggers | cdktn.IResolvable): any;
export declare function codepipelinePipelineTriggersToHclTerraform(struct?: CodepipelinePipelineTriggers | cdktn.IResolvable): any;
export declare class CodepipelinePipelineTriggersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineTriggers | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineTriggers | cdktn.IResolvable | undefined);
    private _gitConfiguration;
    get gitConfiguration(): CodepipelinePipelineTriggersGitConfigurationOutputReference;
    putGitConfiguration(value: CodepipelinePipelineTriggersGitConfiguration): void;
    resetGitConfiguration(): void;
    get gitConfigurationInput(): cdktn.IResolvable | CodepipelinePipelineTriggersGitConfiguration | undefined;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    resetProviderType(): void;
    get providerTypeInput(): string | undefined;
}
export declare class CodepipelinePipelineTriggersList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineTriggers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineTriggersOutputReference;
}
export interface CodepipelinePipelineVariables {
    /**
    * The value of a pipeline-level variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#default_value CodepipelinePipeline#default_value}
    */
    readonly defaultValue?: string;
    /**
    * The description of a pipeline-level variable. It's used to add additional context about the variable, and not being used at time when pipeline executes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#description CodepipelinePipeline#description}
    */
    readonly description?: string;
    /**
    * The name of a pipeline-level variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#name CodepipelinePipeline#name}
    */
    readonly name?: string;
}
export declare function codepipelinePipelineVariablesToTerraform(struct?: CodepipelinePipelineVariables | cdktn.IResolvable): any;
export declare function codepipelinePipelineVariablesToHclTerraform(struct?: CodepipelinePipelineVariables | cdktn.IResolvable): any;
export declare class CodepipelinePipelineVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelinePipelineVariables | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelinePipelineVariables | cdktn.IResolvable | undefined);
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodepipelinePipelineVariablesList extends cdktn.ComplexList {
    internalValue?: CodepipelinePipelineVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelinePipelineVariablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline awscc_codepipeline_pipeline}
*/
export declare class CodepipelinePipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codepipeline_pipeline";
    /**
    * Generates CDKTN code for importing a CodepipelinePipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodepipelinePipeline to import
    * @param importFromId The id of the existing CodepipelinePipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodepipelinePipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codepipeline_pipeline awscc_codepipeline_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodepipelinePipelineConfig
    */
    constructor(scope: Construct, id: string, config: CodepipelinePipelineConfig);
    get arn(): string;
    private _artifactStore;
    get artifactStore(): CodepipelinePipelineArtifactStoreOutputReference;
    putArtifactStore(value: CodepipelinePipelineArtifactStore): void;
    resetArtifactStore(): void;
    get artifactStoreInput(): cdktn.IResolvable | CodepipelinePipelineArtifactStore | undefined;
    private _artifactStores;
    get artifactStores(): CodepipelinePipelineArtifactStoresList;
    putArtifactStores(value: CodepipelinePipelineArtifactStores[] | cdktn.IResolvable): void;
    resetArtifactStores(): void;
    get artifactStoresInput(): cdktn.IResolvable | CodepipelinePipelineArtifactStores[] | undefined;
    private _disableInboundStageTransitions;
    get disableInboundStageTransitions(): CodepipelinePipelineDisableInboundStageTransitionsList;
    putDisableInboundStageTransitions(value: CodepipelinePipelineDisableInboundStageTransitions[] | cdktn.IResolvable): void;
    resetDisableInboundStageTransitions(): void;
    get disableInboundStageTransitionsInput(): cdktn.IResolvable | CodepipelinePipelineDisableInboundStageTransitions[] | undefined;
    private _executionMode?;
    get executionMode(): string;
    set executionMode(value: string);
    resetExecutionMode(): void;
    get executionModeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _pipelineType?;
    get pipelineType(): string;
    set pipelineType(value: string);
    resetPipelineType(): void;
    get pipelineTypeInput(): string | undefined;
    private _restartExecutionOnUpdate?;
    get restartExecutionOnUpdate(): boolean | cdktn.IResolvable;
    set restartExecutionOnUpdate(value: boolean | cdktn.IResolvable);
    resetRestartExecutionOnUpdate(): void;
    get restartExecutionOnUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _stages;
    get stages(): CodepipelinePipelineStagesList;
    putStages(value: CodepipelinePipelineStages[] | cdktn.IResolvable): void;
    get stagesInput(): cdktn.IResolvable | CodepipelinePipelineStages[] | undefined;
    private _tags;
    get tags(): CodepipelinePipelineTagsList;
    putTags(value: CodepipelinePipelineTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodepipelinePipelineTags[] | undefined;
    private _triggers;
    get triggers(): CodepipelinePipelineTriggersList;
    putTriggers(value: CodepipelinePipelineTriggers[] | cdktn.IResolvable): void;
    resetTriggers(): void;
    get triggersInput(): cdktn.IResolvable | CodepipelinePipelineTriggers[] | undefined;
    private _variables;
    get variables(): CodepipelinePipelineVariablesList;
    putVariables(value: CodepipelinePipelineVariables[] | cdktn.IResolvable): void;
    resetVariables(): void;
    get variablesInput(): cdktn.IResolvable | CodepipelinePipelineVariables[] | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
