/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeAppInstanceBotConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the AppInstance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#app_instance_arn ChimeAppInstanceBot#app_instance_arn}
    */
    readonly appInstanceArn: string;
    /**
    * A structure that contains configuration data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#configuration ChimeAppInstanceBot#configuration}
    */
    readonly configuration: ChimeAppInstanceBotConfiguration;
    /**
    * The metadata of the AppInstanceBot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#metadata ChimeAppInstanceBot#metadata}
    */
    readonly metadata?: string;
    /**
    * The name of the AppInstanceBot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#name ChimeAppInstanceBot#name}
    */
    readonly name?: string;
    /**
    * The tags assigned to the AppInstanceBot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#tags ChimeAppInstanceBot#tags}
    */
    readonly tags?: ChimeAppInstanceBotTags[] | cdktn.IResolvable;
}
export interface ChimeAppInstanceBotConfigurationLexInvokedBy {
    /**
    * Sets standard messages as the bot trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#standard_messages ChimeAppInstanceBot#standard_messages}
    */
    readonly standardMessages?: string;
    /**
    * Sets targeted messages as the bot trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#targeted_messages ChimeAppInstanceBot#targeted_messages}
    */
    readonly targetedMessages?: string;
}
export declare function chimeAppInstanceBotConfigurationLexInvokedByToTerraform(struct?: ChimeAppInstanceBotConfigurationLexInvokedBy | cdktn.IResolvable): any;
export declare function chimeAppInstanceBotConfigurationLexInvokedByToHclTerraform(struct?: ChimeAppInstanceBotConfigurationLexInvokedBy | cdktn.IResolvable): any;
export declare class ChimeAppInstanceBotConfigurationLexInvokedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeAppInstanceBotConfigurationLexInvokedBy | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeAppInstanceBotConfigurationLexInvokedBy | cdktn.IResolvable | undefined);
    private _standardMessages?;
    get standardMessages(): string;
    set standardMessages(value: string);
    resetStandardMessages(): void;
    get standardMessagesInput(): string | undefined;
    private _targetedMessages?;
    get targetedMessages(): string;
    set targetedMessages(value: string);
    resetTargetedMessages(): void;
    get targetedMessagesInput(): string | undefined;
}
export interface ChimeAppInstanceBotConfigurationLex {
    /**
    * Specifies the type of message that triggers a bot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#invoked_by ChimeAppInstanceBot#invoked_by}
    */
    readonly invokedBy?: ChimeAppInstanceBotConfigurationLexInvokedBy;
    /**
    * The ARN of the Amazon Lex V2 bot's alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#lex_bot_alias_arn ChimeAppInstanceBot#lex_bot_alias_arn}
    */
    readonly lexBotAliasArn: string;
    /**
    * Identifies the Amazon Lex V2 bot's language and locale.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#locale_id ChimeAppInstanceBot#locale_id}
    */
    readonly localeId: string;
    /**
    * Determines whether the Amazon Lex V2 bot responds to all standard messages. Control messages are not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#responds_to ChimeAppInstanceBot#responds_to}
    */
    readonly respondsTo?: string;
    /**
    * The name of the welcome intent configured in the Amazon Lex V2 bot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#welcome_intent ChimeAppInstanceBot#welcome_intent}
    */
    readonly welcomeIntent?: string;
}
export declare function chimeAppInstanceBotConfigurationLexToTerraform(struct?: ChimeAppInstanceBotConfigurationLex | cdktn.IResolvable): any;
export declare function chimeAppInstanceBotConfigurationLexToHclTerraform(struct?: ChimeAppInstanceBotConfigurationLex | cdktn.IResolvable): any;
export declare class ChimeAppInstanceBotConfigurationLexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeAppInstanceBotConfigurationLex | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeAppInstanceBotConfigurationLex | cdktn.IResolvable | undefined);
    private _invokedBy;
    get invokedBy(): ChimeAppInstanceBotConfigurationLexInvokedByOutputReference;
    putInvokedBy(value: ChimeAppInstanceBotConfigurationLexInvokedBy): void;
    resetInvokedBy(): void;
    get invokedByInput(): cdktn.IResolvable | ChimeAppInstanceBotConfigurationLexInvokedBy | undefined;
    private _lexBotAliasArn?;
    get lexBotAliasArn(): string;
    set lexBotAliasArn(value: string);
    get lexBotAliasArnInput(): string | undefined;
    private _localeId?;
    get localeId(): string;
    set localeId(value: string);
    get localeIdInput(): string | undefined;
    private _respondsTo?;
    get respondsTo(): string;
    set respondsTo(value: string);
    resetRespondsTo(): void;
    get respondsToInput(): string | undefined;
    private _welcomeIntent?;
    get welcomeIntent(): string;
    set welcomeIntent(value: string);
    resetWelcomeIntent(): void;
    get welcomeIntentInput(): string | undefined;
}
export interface ChimeAppInstanceBotConfiguration {
    /**
    * The configuration for an Amazon Lex V2 bot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#lex ChimeAppInstanceBot#lex}
    */
    readonly lex: ChimeAppInstanceBotConfigurationLex;
}
export declare function chimeAppInstanceBotConfigurationToTerraform(struct?: ChimeAppInstanceBotConfiguration | cdktn.IResolvable): any;
export declare function chimeAppInstanceBotConfigurationToHclTerraform(struct?: ChimeAppInstanceBotConfiguration | cdktn.IResolvable): any;
export declare class ChimeAppInstanceBotConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeAppInstanceBotConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeAppInstanceBotConfiguration | cdktn.IResolvable | undefined);
    private _lex;
    get lex(): ChimeAppInstanceBotConfigurationLexOutputReference;
    putLex(value: ChimeAppInstanceBotConfigurationLex): void;
    get lexInput(): cdktn.IResolvable | ChimeAppInstanceBotConfigurationLex | undefined;
}
export interface ChimeAppInstanceBotTags {
    /**
    * The key in a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#key ChimeAppInstanceBot#key}
    */
    readonly key?: string;
    /**
    * The value in a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#value ChimeAppInstanceBot#value}
    */
    readonly value?: string;
}
export declare function chimeAppInstanceBotTagsToTerraform(struct?: ChimeAppInstanceBotTags | cdktn.IResolvable): any;
export declare function chimeAppInstanceBotTagsToHclTerraform(struct?: ChimeAppInstanceBotTags | cdktn.IResolvable): any;
export declare class ChimeAppInstanceBotTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeAppInstanceBotTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeAppInstanceBotTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeAppInstanceBotTagsList extends cdktn.ComplexList {
    internalValue?: ChimeAppInstanceBotTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeAppInstanceBotTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot awscc_chime_app_instance_bot}
*/
export declare class ChimeAppInstanceBot extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_app_instance_bot";
    /**
    * Generates CDKTN code for importing a ChimeAppInstanceBot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeAppInstanceBot to import
    * @param importFromId The id of the existing ChimeAppInstanceBot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeAppInstanceBot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_app_instance_bot awscc_chime_app_instance_bot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeAppInstanceBotConfig
    */
    constructor(scope: Construct, id: string, config: ChimeAppInstanceBotConfig);
    private _appInstanceArn?;
    get appInstanceArn(): string;
    set appInstanceArn(value: string);
    get appInstanceArnInput(): string | undefined;
    get appInstanceBotArn(): string;
    private _configuration;
    get configuration(): ChimeAppInstanceBotConfigurationOutputReference;
    putConfiguration(value: ChimeAppInstanceBotConfiguration): void;
    get configurationInput(): cdktn.IResolvable | ChimeAppInstanceBotConfiguration | undefined;
    get createdTimestamp(): string;
    get id(): string;
    get lastUpdatedTimestamp(): string;
    private _metadata?;
    get metadata(): string;
    set metadata(value: string);
    resetMetadata(): void;
    get metadataInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _tags;
    get tags(): ChimeAppInstanceBotTagsList;
    putTags(value: ChimeAppInstanceBotTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeAppInstanceBotTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
