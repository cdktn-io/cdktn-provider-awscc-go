/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BillingconductorCustomLineItemConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account which this custom line item will be charged to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#account_id BillingconductorCustomLineItem#account_id}
    */
    readonly accountId?: string;
    /**
    * Billing Group ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#billing_group_arn BillingconductorCustomLineItem#billing_group_arn}
    */
    readonly billingGroupArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#billing_period_range BillingconductorCustomLineItem#billing_period_range}
    */
    readonly billingPeriodRange?: BillingconductorCustomLineItemBillingPeriodRange;
    /**
    * The display settings of the Custom Line Item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#computation_rule BillingconductorCustomLineItem#computation_rule}
    */
    readonly computationRule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#custom_line_item_charge_details BillingconductorCustomLineItem#custom_line_item_charge_details}
    */
    readonly customLineItemChargeDetails?: BillingconductorCustomLineItemCustomLineItemChargeDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#description BillingconductorCustomLineItem#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#name BillingconductorCustomLineItem#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#presentation_details BillingconductorCustomLineItem#presentation_details}
    */
    readonly presentationDetails?: BillingconductorCustomLineItemPresentationDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#tags BillingconductorCustomLineItem#tags}
    */
    readonly tags?: BillingconductorCustomLineItemTags[] | cdktn.IResolvable;
}
export interface BillingconductorCustomLineItemBillingPeriodRange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#exclusive_end_billing_period BillingconductorCustomLineItem#exclusive_end_billing_period}
    */
    readonly exclusiveEndBillingPeriod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#inclusive_start_billing_period BillingconductorCustomLineItem#inclusive_start_billing_period}
    */
    readonly inclusiveStartBillingPeriod?: string;
}
export declare function billingconductorCustomLineItemBillingPeriodRangeToTerraform(struct?: BillingconductorCustomLineItemBillingPeriodRange | cdktn.IResolvable): any;
export declare function billingconductorCustomLineItemBillingPeriodRangeToHclTerraform(struct?: BillingconductorCustomLineItemBillingPeriodRange | cdktn.IResolvable): any;
export declare class BillingconductorCustomLineItemBillingPeriodRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorCustomLineItemBillingPeriodRange | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorCustomLineItemBillingPeriodRange | cdktn.IResolvable | undefined);
    private _exclusiveEndBillingPeriod?;
    get exclusiveEndBillingPeriod(): string;
    set exclusiveEndBillingPeriod(value: string);
    resetExclusiveEndBillingPeriod(): void;
    get exclusiveEndBillingPeriodInput(): string | undefined;
    private _inclusiveStartBillingPeriod?;
    get inclusiveStartBillingPeriod(): string;
    set inclusiveStartBillingPeriod(value: string);
    resetInclusiveStartBillingPeriod(): void;
    get inclusiveStartBillingPeriodInput(): string | undefined;
}
export interface BillingconductorCustomLineItemCustomLineItemChargeDetailsFlat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#charge_value BillingconductorCustomLineItem#charge_value}
    */
    readonly chargeValue?: number;
}
export declare function billingconductorCustomLineItemCustomLineItemChargeDetailsFlatToTerraform(struct?: BillingconductorCustomLineItemCustomLineItemChargeDetailsFlat | cdktn.IResolvable): any;
export declare function billingconductorCustomLineItemCustomLineItemChargeDetailsFlatToHclTerraform(struct?: BillingconductorCustomLineItemCustomLineItemChargeDetailsFlat | cdktn.IResolvable): any;
export declare class BillingconductorCustomLineItemCustomLineItemChargeDetailsFlatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorCustomLineItemCustomLineItemChargeDetailsFlat | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorCustomLineItemCustomLineItemChargeDetailsFlat | cdktn.IResolvable | undefined);
    private _chargeValue?;
    get chargeValue(): number;
    set chargeValue(value: number);
    resetChargeValue(): void;
    get chargeValueInput(): number | undefined;
}
export interface BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#attribute BillingconductorCustomLineItem#attribute}
    */
    readonly attribute?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#attribute_values BillingconductorCustomLineItem#attribute_values}
    */
    readonly attributeValues?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#match_option BillingconductorCustomLineItem#match_option}
    */
    readonly matchOption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#values BillingconductorCustomLineItem#values}
    */
    readonly values?: string[];
}
export declare function billingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFiltersToTerraform(struct?: BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters | cdktn.IResolvable): any;
export declare function billingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFiltersToHclTerraform(struct?: BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters | cdktn.IResolvable): any;
export declare class BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _attributeValues?;
    get attributeValues(): string[];
    set attributeValues(value: string[]);
    resetAttributeValues(): void;
    get attributeValuesInput(): string[] | undefined;
    private _matchOption?;
    get matchOption(): string;
    set matchOption(value: string);
    resetMatchOption(): void;
    get matchOptionInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFiltersList extends cdktn.ComplexList {
    internalValue?: BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFiltersOutputReference;
}
export interface BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#child_associated_resources BillingconductorCustomLineItem#child_associated_resources}
    */
    readonly childAssociatedResources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#percentage_value BillingconductorCustomLineItem#percentage_value}
    */
    readonly percentageValue?: number;
}
export declare function billingconductorCustomLineItemCustomLineItemChargeDetailsPercentageToTerraform(struct?: BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentage | cdktn.IResolvable): any;
export declare function billingconductorCustomLineItemCustomLineItemChargeDetailsPercentageToHclTerraform(struct?: BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentage | cdktn.IResolvable): any;
export declare class BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentage | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentage | cdktn.IResolvable | undefined);
    private _childAssociatedResources?;
    get childAssociatedResources(): string[];
    set childAssociatedResources(value: string[]);
    resetChildAssociatedResources(): void;
    get childAssociatedResourcesInput(): string[] | undefined;
    private _percentageValue?;
    get percentageValue(): number;
    set percentageValue(value: number);
    resetPercentageValue(): void;
    get percentageValueInput(): number | undefined;
}
export interface BillingconductorCustomLineItemCustomLineItemChargeDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#flat BillingconductorCustomLineItem#flat}
    */
    readonly flat?: BillingconductorCustomLineItemCustomLineItemChargeDetailsFlat;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#line_item_filters BillingconductorCustomLineItem#line_item_filters}
    */
    readonly lineItemFilters?: BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#percentage BillingconductorCustomLineItem#percentage}
    */
    readonly percentage?: BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#type BillingconductorCustomLineItem#type}
    */
    readonly type?: string;
}
export declare function billingconductorCustomLineItemCustomLineItemChargeDetailsToTerraform(struct?: BillingconductorCustomLineItemCustomLineItemChargeDetails | cdktn.IResolvable): any;
export declare function billingconductorCustomLineItemCustomLineItemChargeDetailsToHclTerraform(struct?: BillingconductorCustomLineItemCustomLineItemChargeDetails | cdktn.IResolvable): any;
export declare class BillingconductorCustomLineItemCustomLineItemChargeDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorCustomLineItemCustomLineItemChargeDetails | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorCustomLineItemCustomLineItemChargeDetails | cdktn.IResolvable | undefined);
    private _flat;
    get flat(): BillingconductorCustomLineItemCustomLineItemChargeDetailsFlatOutputReference;
    putFlat(value: BillingconductorCustomLineItemCustomLineItemChargeDetailsFlat): void;
    resetFlat(): void;
    get flatInput(): cdktn.IResolvable | BillingconductorCustomLineItemCustomLineItemChargeDetailsFlat | undefined;
    private _lineItemFilters;
    get lineItemFilters(): BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFiltersList;
    putLineItemFilters(value: BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters[] | cdktn.IResolvable): void;
    resetLineItemFilters(): void;
    get lineItemFiltersInput(): cdktn.IResolvable | BillingconductorCustomLineItemCustomLineItemChargeDetailsLineItemFilters[] | undefined;
    private _percentage;
    get percentage(): BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentageOutputReference;
    putPercentage(value: BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentage): void;
    resetPercentage(): void;
    get percentageInput(): cdktn.IResolvable | BillingconductorCustomLineItemCustomLineItemChargeDetailsPercentage | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BillingconductorCustomLineItemPresentationDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#service BillingconductorCustomLineItem#service}
    */
    readonly service?: string;
}
export declare function billingconductorCustomLineItemPresentationDetailsToTerraform(struct?: BillingconductorCustomLineItemPresentationDetails | cdktn.IResolvable): any;
export declare function billingconductorCustomLineItemPresentationDetailsToHclTerraform(struct?: BillingconductorCustomLineItemPresentationDetails | cdktn.IResolvable): any;
export declare class BillingconductorCustomLineItemPresentationDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorCustomLineItemPresentationDetails | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorCustomLineItemPresentationDetails | cdktn.IResolvable | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface BillingconductorCustomLineItemTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#key BillingconductorCustomLineItem#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#value BillingconductorCustomLineItem#value}
    */
    readonly value?: string;
}
export declare function billingconductorCustomLineItemTagsToTerraform(struct?: BillingconductorCustomLineItemTags | cdktn.IResolvable): any;
export declare function billingconductorCustomLineItemTagsToHclTerraform(struct?: BillingconductorCustomLineItemTags | cdktn.IResolvable): any;
export declare class BillingconductorCustomLineItemTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingconductorCustomLineItemTags | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorCustomLineItemTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BillingconductorCustomLineItemTagsList extends cdktn.ComplexList {
    internalValue?: BillingconductorCustomLineItemTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingconductorCustomLineItemTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item awscc_billingconductor_custom_line_item}
*/
export declare class BillingconductorCustomLineItem extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_billingconductor_custom_line_item";
    /**
    * Generates CDKTN code for importing a BillingconductorCustomLineItem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BillingconductorCustomLineItem to import
    * @param importFromId The id of the existing BillingconductorCustomLineItem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BillingconductorCustomLineItem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/billingconductor_custom_line_item awscc_billingconductor_custom_line_item} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BillingconductorCustomLineItemConfig
    */
    constructor(scope: Construct, id: string, config: BillingconductorCustomLineItemConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get arn(): string;
    get associationSize(): number;
    private _billingGroupArn?;
    get billingGroupArn(): string;
    set billingGroupArn(value: string);
    get billingGroupArnInput(): string | undefined;
    private _billingPeriodRange;
    get billingPeriodRange(): BillingconductorCustomLineItemBillingPeriodRangeOutputReference;
    putBillingPeriodRange(value: BillingconductorCustomLineItemBillingPeriodRange): void;
    resetBillingPeriodRange(): void;
    get billingPeriodRangeInput(): cdktn.IResolvable | BillingconductorCustomLineItemBillingPeriodRange | undefined;
    private _computationRule?;
    get computationRule(): string;
    set computationRule(value: string);
    resetComputationRule(): void;
    get computationRuleInput(): string | undefined;
    get creationTime(): number;
    get currencyCode(): string;
    private _customLineItemChargeDetails;
    get customLineItemChargeDetails(): BillingconductorCustomLineItemCustomLineItemChargeDetailsOutputReference;
    putCustomLineItemChargeDetails(value: BillingconductorCustomLineItemCustomLineItemChargeDetails): void;
    resetCustomLineItemChargeDetails(): void;
    get customLineItemChargeDetailsInput(): cdktn.IResolvable | BillingconductorCustomLineItemCustomLineItemChargeDetails | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _presentationDetails;
    get presentationDetails(): BillingconductorCustomLineItemPresentationDetailsOutputReference;
    putPresentationDetails(value: BillingconductorCustomLineItemPresentationDetails): void;
    resetPresentationDetails(): void;
    get presentationDetailsInput(): cdktn.IResolvable | BillingconductorCustomLineItemPresentationDetails | undefined;
    get productCode(): string;
    private _tags;
    get tags(): BillingconductorCustomLineItemTagsList;
    putTags(value: BillingconductorCustomLineItemTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BillingconductorCustomLineItemTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
