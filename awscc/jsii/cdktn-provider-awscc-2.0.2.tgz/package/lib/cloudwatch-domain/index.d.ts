/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identity provider configuration for the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#identity_provider_configuration CloudwatchDomain#identity_provider_configuration}
    */
    readonly identityProviderConfiguration?: CloudwatchDomainIdentityProviderConfiguration;
    /**
    * The identity providers configured for the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#identity_providers CloudwatchDomain#identity_providers}
    */
    readonly identityProviders: string[];
    /**
    * A name that identifies the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#name CloudwatchDomain#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#tags CloudwatchDomain#tags}
    */
    readonly tags?: CloudwatchDomainTags[] | cdktn.IResolvable;
}
export interface CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfiguration {
    /**
    * Identity Center instance ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#identity_center_instance_arn CloudwatchDomain#identity_center_instance_arn}
    */
    readonly identityCenterInstanceArn?: string;
}
export declare function cloudwatchDomainIdentityProviderConfigurationIdentityCenterConfigurationToTerraform(struct?: CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchDomainIdentityProviderConfigurationIdentityCenterConfigurationToHclTerraform(struct?: CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable | undefined);
    private _identityCenterInstanceArn?;
    get identityCenterInstanceArn(): string;
    set identityCenterInstanceArn(value: string);
    resetIdentityCenterInstanceArn(): void;
    get identityCenterInstanceArnInput(): string | undefined;
}
export interface CloudwatchDomainIdentityProviderConfiguration {
    /**
    * Identity Center configuration. Required when identityProviders includes IDC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#identity_center_configuration CloudwatchDomain#identity_center_configuration}
    */
    readonly identityCenterConfiguration?: CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfiguration;
}
export declare function cloudwatchDomainIdentityProviderConfigurationToTerraform(struct?: CloudwatchDomainIdentityProviderConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchDomainIdentityProviderConfigurationToHclTerraform(struct?: CloudwatchDomainIdentityProviderConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchDomainIdentityProviderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchDomainIdentityProviderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainIdentityProviderConfiguration | cdktn.IResolvable | undefined);
    private _identityCenterConfiguration;
    get identityCenterConfiguration(): CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfigurationOutputReference;
    putIdentityCenterConfiguration(value: CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfiguration): void;
    resetIdentityCenterConfiguration(): void;
    get identityCenterConfigurationInput(): cdktn.IResolvable | CloudwatchDomainIdentityProviderConfigurationIdentityCenterConfiguration | undefined;
}
export interface CloudwatchDomainTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#key CloudwatchDomain#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#value CloudwatchDomain#value}
    */
    readonly value?: string;
}
export declare function cloudwatchDomainTagsToTerraform(struct?: CloudwatchDomainTags | cdktn.IResolvable): any;
export declare function cloudwatchDomainTagsToHclTerraform(struct?: CloudwatchDomainTags | cdktn.IResolvable): any;
export declare class CloudwatchDomainTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchDomainTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchDomainTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchDomainTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchDomainTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain awscc_cloudwatch_domain}
*/
export declare class CloudwatchDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_domain";
    /**
    * Generates CDKTN code for importing a CloudwatchDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchDomain to import
    * @param importFromId The id of the existing CloudwatchDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain awscc_cloudwatch_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchDomainConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchDomainConfig);
    get arn(): string;
    get createdAt(): string;
    get customEndpointUrls(): string[];
    get domainEndpointUrl(): string;
    get domainId(): string;
    get id(): string;
    get identityCenterApplicationArn(): string;
    private _identityProviderConfiguration;
    get identityProviderConfiguration(): CloudwatchDomainIdentityProviderConfigurationOutputReference;
    putIdentityProviderConfiguration(value: CloudwatchDomainIdentityProviderConfiguration): void;
    resetIdentityProviderConfiguration(): void;
    get identityProviderConfigurationInput(): cdktn.IResolvable | CloudwatchDomainIdentityProviderConfiguration | undefined;
    private _identityProviders?;
    get identityProviders(): string[];
    set identityProviders(value: string[]);
    get identityProvidersInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get status(): string;
    private _tags;
    get tags(): CloudwatchDomainTagsList;
    putTags(value: CloudwatchDomainTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchDomainTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
