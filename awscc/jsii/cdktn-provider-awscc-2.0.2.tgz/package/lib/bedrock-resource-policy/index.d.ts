/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockResourcePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The IAM policy document defining access permissions for the guardrail and guardrail profile resources
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_resource_policy#policy_document BedrockResourcePolicy#policy_document}
    */
    readonly policyDocument: string;
    /**
    * The ARN of the Bedrock Guardrail or Guardrail Profile resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_resource_policy#resource_arn BedrockResourcePolicy#resource_arn}
    */
    readonly resourceArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_resource_policy awscc_bedrock_resource_policy}
*/
export declare class BedrockResourcePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_resource_policy";
    /**
    * Generates CDKTN code for importing a BedrockResourcePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockResourcePolicy to import
    * @param importFromId The id of the existing BedrockResourcePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_resource_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockResourcePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_resource_policy awscc_bedrock_resource_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockResourcePolicyConfig
    */
    constructor(scope: Construct, id: string, config: BedrockResourcePolicyConfig);
    get id(): string;
    private _policyDocument?;
    get policyDocument(): string;
    set policyDocument(value: string);
    get policyDocumentInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
