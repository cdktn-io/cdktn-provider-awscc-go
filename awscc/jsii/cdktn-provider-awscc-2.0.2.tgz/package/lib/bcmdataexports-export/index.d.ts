/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BcmdataexportsExportConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#export BcmdataexportsExport#export}
    */
    readonly export: BcmdataexportsExportExport;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#tags BcmdataexportsExport#tags}
    */
    readonly tags?: BcmdataexportsExportTags[] | cdktn.IResolvable;
}
export interface BcmdataexportsExportExportDataQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#query_statement BcmdataexportsExport#query_statement}
    */
    readonly queryStatement: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#table_configurations BcmdataexportsExport#table_configurations}
    */
    readonly tableConfigurations?: {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable;
}
export declare function bcmdataexportsExportExportDataQueryToTerraform(struct?: BcmdataexportsExportExportDataQuery | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportDataQueryToHclTerraform(struct?: BcmdataexportsExportExportDataQuery | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportDataQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmdataexportsExportExportDataQuery | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportDataQuery | cdktn.IResolvable | undefined);
    private _queryStatement?;
    get queryStatement(): string;
    set queryStatement(value: string);
    get queryStatementInput(): string | undefined;
    private _tableConfigurations?;
    get tableConfigurations(): {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable;
    set tableConfigurations(value: {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable);
    resetTableConfigurations(): void;
    get tableConfigurationsInput(): cdktn.IResolvable | {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined;
}
export interface BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#compression BcmdataexportsExport#compression}
    */
    readonly compression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#format BcmdataexportsExport#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#output_type BcmdataexportsExport#output_type}
    */
    readonly outputType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#overwrite BcmdataexportsExport#overwrite}
    */
    readonly overwrite: string;
}
export declare function bcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsToTerraform(struct?: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsToHclTerraform(struct?: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | cdktn.IResolvable | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    get compressionInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    get outputTypeInput(): string | undefined;
    private _overwrite?;
    get overwrite(): string;
    set overwrite(value: string);
    get overwriteInput(): string | undefined;
}
export interface BcmdataexportsExportExportDestinationConfigurationsS3Destination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#s3_bucket BcmdataexportsExport#s3_bucket}
    */
    readonly s3Bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#s3_bucket_owner BcmdataexportsExport#s3_bucket_owner}
    */
    readonly s3BucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#s3_output_configurations BcmdataexportsExport#s3_output_configurations}
    */
    readonly s3OutputConfigurations: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#s3_prefix BcmdataexportsExport#s3_prefix}
    */
    readonly s3Prefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#s3_region BcmdataexportsExport#s3_region}
    */
    readonly s3Region: string;
}
export declare function bcmdataexportsExportExportDestinationConfigurationsS3DestinationToTerraform(struct?: BcmdataexportsExportExportDestinationConfigurationsS3Destination | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportDestinationConfigurationsS3DestinationToHclTerraform(struct?: BcmdataexportsExportExportDestinationConfigurationsS3Destination | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportDestinationConfigurationsS3DestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmdataexportsExportExportDestinationConfigurationsS3Destination | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportDestinationConfigurationsS3Destination | cdktn.IResolvable | undefined);
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    get s3BucketInput(): string | undefined;
    private _s3BucketOwner?;
    get s3BucketOwner(): string;
    set s3BucketOwner(value: string);
    resetS3BucketOwner(): void;
    get s3BucketOwnerInput(): string | undefined;
    private _s3OutputConfigurations;
    get s3OutputConfigurations(): BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsOutputReference;
    putS3OutputConfigurations(value: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations): void;
    get s3OutputConfigurationsInput(): cdktn.IResolvable | BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | undefined;
    private _s3Prefix?;
    get s3Prefix(): string;
    set s3Prefix(value: string);
    get s3PrefixInput(): string | undefined;
    private _s3Region?;
    get s3Region(): string;
    set s3Region(value: string);
    get s3RegionInput(): string | undefined;
}
export interface BcmdataexportsExportExportDestinationConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#s3_destination BcmdataexportsExport#s3_destination}
    */
    readonly s3Destination: BcmdataexportsExportExportDestinationConfigurationsS3Destination;
}
export declare function bcmdataexportsExportExportDestinationConfigurationsToTerraform(struct?: BcmdataexportsExportExportDestinationConfigurations | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportDestinationConfigurationsToHclTerraform(struct?: BcmdataexportsExportExportDestinationConfigurations | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportDestinationConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmdataexportsExportExportDestinationConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportDestinationConfigurations | cdktn.IResolvable | undefined);
    private _s3Destination;
    get s3Destination(): BcmdataexportsExportExportDestinationConfigurationsS3DestinationOutputReference;
    putS3Destination(value: BcmdataexportsExportExportDestinationConfigurationsS3Destination): void;
    get s3DestinationInput(): cdktn.IResolvable | BcmdataexportsExportExportDestinationConfigurationsS3Destination | undefined;
}
export interface BcmdataexportsExportExportRefreshCadence {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#frequency BcmdataexportsExport#frequency}
    */
    readonly frequency: string;
}
export declare function bcmdataexportsExportExportRefreshCadenceToTerraform(struct?: BcmdataexportsExportExportRefreshCadence | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportRefreshCadenceToHclTerraform(struct?: BcmdataexportsExportExportRefreshCadence | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportRefreshCadenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmdataexportsExportExportRefreshCadence | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportRefreshCadence | cdktn.IResolvable | undefined);
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    get frequencyInput(): string | undefined;
}
export interface BcmdataexportsExportExport {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#data_query BcmdataexportsExport#data_query}
    */
    readonly dataQuery: BcmdataexportsExportExportDataQuery;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#description BcmdataexportsExport#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#destination_configurations BcmdataexportsExport#destination_configurations}
    */
    readonly destinationConfigurations: BcmdataexportsExportExportDestinationConfigurations;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#name BcmdataexportsExport#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#refresh_cadence BcmdataexportsExport#refresh_cadence}
    */
    readonly refreshCadence: BcmdataexportsExportExportRefreshCadence;
}
export declare function bcmdataexportsExportExportToTerraform(struct?: BcmdataexportsExportExport | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportToHclTerraform(struct?: BcmdataexportsExportExport | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmdataexportsExportExport | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExport | cdktn.IResolvable | undefined);
    private _dataQuery;
    get dataQuery(): BcmdataexportsExportExportDataQueryOutputReference;
    putDataQuery(value: BcmdataexportsExportExportDataQuery): void;
    get dataQueryInput(): cdktn.IResolvable | BcmdataexportsExportExportDataQuery | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destinationConfigurations;
    get destinationConfigurations(): BcmdataexportsExportExportDestinationConfigurationsOutputReference;
    putDestinationConfigurations(value: BcmdataexportsExportExportDestinationConfigurations): void;
    get destinationConfigurationsInput(): cdktn.IResolvable | BcmdataexportsExportExportDestinationConfigurations | undefined;
    get exportArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _refreshCadence;
    get refreshCadence(): BcmdataexportsExportExportRefreshCadenceOutputReference;
    putRefreshCadence(value: BcmdataexportsExportExportRefreshCadence): void;
    get refreshCadenceInput(): cdktn.IResolvable | BcmdataexportsExportExportRefreshCadence | undefined;
}
export interface BcmdataexportsExportTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#key BcmdataexportsExport#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#value BcmdataexportsExport#value}
    */
    readonly value?: string;
}
export declare function bcmdataexportsExportTagsToTerraform(struct?: BcmdataexportsExportTags | cdktn.IResolvable): any;
export declare function bcmdataexportsExportTagsToHclTerraform(struct?: BcmdataexportsExportTags | cdktn.IResolvable): any;
export declare class BcmdataexportsExportTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmdataexportsExportTags | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BcmdataexportsExportTagsList extends cdktn.ComplexList {
    internalValue?: BcmdataexportsExportTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmdataexportsExportTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export awscc_bcmdataexports_export}
*/
export declare class BcmdataexportsExport extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bcmdataexports_export";
    /**
    * Generates CDKTN code for importing a BcmdataexportsExport resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BcmdataexportsExport to import
    * @param importFromId The id of the existing BcmdataexportsExport that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BcmdataexportsExport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmdataexports_export awscc_bcmdataexports_export} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BcmdataexportsExportConfig
    */
    constructor(scope: Construct, id: string, config: BcmdataexportsExportConfig);
    private _export;
    get export(): BcmdataexportsExportExportOutputReference;
    putExport(value: BcmdataexportsExportExport): void;
    get exportInput(): cdktn.IResolvable | BcmdataexportsExportExport | undefined;
    get exportArn(): string;
    get id(): string;
    private _tags;
    get tags(): BcmdataexportsExportTagsList;
    putTags(value: BcmdataexportsExportTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BcmdataexportsExportTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
