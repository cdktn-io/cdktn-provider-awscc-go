/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_deployment#id DataAwsccApigatewayDeployment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayDeploymentDeploymentCanarySettings {
}
export declare function dataAwsccApigatewayDeploymentDeploymentCanarySettingsToTerraform(struct?: DataAwsccApigatewayDeploymentDeploymentCanarySettings): any;
export declare function dataAwsccApigatewayDeploymentDeploymentCanarySettingsToHclTerraform(struct?: DataAwsccApigatewayDeploymentDeploymentCanarySettings): any;
export declare class DataAwsccApigatewayDeploymentDeploymentCanarySettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayDeploymentDeploymentCanarySettings | undefined;
    set internalValue(value: DataAwsccApigatewayDeploymentDeploymentCanarySettings | undefined);
    get percentTraffic(): number;
    private _stageVariableOverrides;
    get stageVariableOverrides(): cdktn.StringMap;
    get useStageCache(): cdktn.IResolvable;
}
export interface DataAwsccApigatewayDeploymentStageDescriptionAccessLogSetting {
}
export declare function dataAwsccApigatewayDeploymentStageDescriptionAccessLogSettingToTerraform(struct?: DataAwsccApigatewayDeploymentStageDescriptionAccessLogSetting): any;
export declare function dataAwsccApigatewayDeploymentStageDescriptionAccessLogSettingToHclTerraform(struct?: DataAwsccApigatewayDeploymentStageDescriptionAccessLogSetting): any;
export declare class DataAwsccApigatewayDeploymentStageDescriptionAccessLogSettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayDeploymentStageDescriptionAccessLogSetting | undefined;
    set internalValue(value: DataAwsccApigatewayDeploymentStageDescriptionAccessLogSetting | undefined);
    get destinationArn(): string;
    get format(): string;
}
export interface DataAwsccApigatewayDeploymentStageDescriptionCanarySetting {
}
export declare function dataAwsccApigatewayDeploymentStageDescriptionCanarySettingToTerraform(struct?: DataAwsccApigatewayDeploymentStageDescriptionCanarySetting): any;
export declare function dataAwsccApigatewayDeploymentStageDescriptionCanarySettingToHclTerraform(struct?: DataAwsccApigatewayDeploymentStageDescriptionCanarySetting): any;
export declare class DataAwsccApigatewayDeploymentStageDescriptionCanarySettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayDeploymentStageDescriptionCanarySetting | undefined;
    set internalValue(value: DataAwsccApigatewayDeploymentStageDescriptionCanarySetting | undefined);
    get percentTraffic(): number;
    private _stageVariableOverrides;
    get stageVariableOverrides(): cdktn.StringMap;
    get useStageCache(): cdktn.IResolvable;
}
export interface DataAwsccApigatewayDeploymentStageDescriptionMethodSettings {
}
export declare function dataAwsccApigatewayDeploymentStageDescriptionMethodSettingsToTerraform(struct?: DataAwsccApigatewayDeploymentStageDescriptionMethodSettings): any;
export declare function dataAwsccApigatewayDeploymentStageDescriptionMethodSettingsToHclTerraform(struct?: DataAwsccApigatewayDeploymentStageDescriptionMethodSettings): any;
export declare class DataAwsccApigatewayDeploymentStageDescriptionMethodSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayDeploymentStageDescriptionMethodSettings | undefined;
    set internalValue(value: DataAwsccApigatewayDeploymentStageDescriptionMethodSettings | undefined);
    get cacheDataEncrypted(): cdktn.IResolvable;
    get cacheTtlInSeconds(): number;
    get cachingEnabled(): cdktn.IResolvable;
    get dataTraceEnabled(): cdktn.IResolvable;
    get httpMethod(): string;
    get loggingLevel(): string;
    get metricsEnabled(): cdktn.IResolvable;
    get resourcePath(): string;
    get throttlingBurstLimit(): number;
    get throttlingRateLimit(): number;
}
export declare class DataAwsccApigatewayDeploymentStageDescriptionMethodSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayDeploymentStageDescriptionMethodSettingsOutputReference;
}
export interface DataAwsccApigatewayDeploymentStageDescriptionTags {
}
export declare function dataAwsccApigatewayDeploymentStageDescriptionTagsToTerraform(struct?: DataAwsccApigatewayDeploymentStageDescriptionTags): any;
export declare function dataAwsccApigatewayDeploymentStageDescriptionTagsToHclTerraform(struct?: DataAwsccApigatewayDeploymentStageDescriptionTags): any;
export declare class DataAwsccApigatewayDeploymentStageDescriptionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayDeploymentStageDescriptionTags | undefined;
    set internalValue(value: DataAwsccApigatewayDeploymentStageDescriptionTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayDeploymentStageDescriptionTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayDeploymentStageDescriptionTagsOutputReference;
}
export interface DataAwsccApigatewayDeploymentStageDescription {
}
export declare function dataAwsccApigatewayDeploymentStageDescriptionToTerraform(struct?: DataAwsccApigatewayDeploymentStageDescription): any;
export declare function dataAwsccApigatewayDeploymentStageDescriptionToHclTerraform(struct?: DataAwsccApigatewayDeploymentStageDescription): any;
export declare class DataAwsccApigatewayDeploymentStageDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayDeploymentStageDescription | undefined;
    set internalValue(value: DataAwsccApigatewayDeploymentStageDescription | undefined);
    private _accessLogSetting;
    get accessLogSetting(): DataAwsccApigatewayDeploymentStageDescriptionAccessLogSettingOutputReference;
    get cacheClusterEnabled(): cdktn.IResolvable;
    get cacheClusterSize(): string;
    get cacheDataEncrypted(): cdktn.IResolvable;
    get cacheTtlInSeconds(): number;
    get cachingEnabled(): cdktn.IResolvable;
    private _canarySetting;
    get canarySetting(): DataAwsccApigatewayDeploymentStageDescriptionCanarySettingOutputReference;
    get clientCertificateId(): string;
    get dataTraceEnabled(): cdktn.IResolvable;
    get description(): string;
    get documentationVersion(): string;
    get loggingLevel(): string;
    private _methodSettings;
    get methodSettings(): DataAwsccApigatewayDeploymentStageDescriptionMethodSettingsList;
    get metricsEnabled(): cdktn.IResolvable;
    private _tags;
    get tags(): DataAwsccApigatewayDeploymentStageDescriptionTagsList;
    get throttlingBurstLimit(): number;
    get throttlingRateLimit(): number;
    get tracingEnabled(): cdktn.IResolvable;
    private _variables;
    get variables(): cdktn.StringMap;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_deployment awscc_apigateway_deployment}
*/
export declare class DataAwsccApigatewayDeployment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_deployment";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayDeployment to import
    * @param importFromId The id of the existing DataAwsccApigatewayDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_deployment awscc_apigateway_deployment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayDeploymentConfig);
    private _deploymentCanarySettings;
    get deploymentCanarySettings(): DataAwsccApigatewayDeploymentDeploymentCanarySettingsOutputReference;
    get deploymentId(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get restApiId(): string;
    private _stageDescription;
    get stageDescription(): DataAwsccApigatewayDeploymentStageDescriptionOutputReference;
    get stageName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
