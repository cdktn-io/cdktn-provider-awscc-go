/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationsignalsGroupingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationsignals_grouping_configuration#grouping_attribute_definitions ApplicationsignalsGroupingConfiguration#grouping_attribute_definitions}
    */
    readonly groupingAttributeDefinitions: ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions[] | cdktn.IResolvable;
}
export interface ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationsignals_grouping_configuration#default_grouping_value ApplicationsignalsGroupingConfiguration#default_grouping_value}
    */
    readonly defaultGroupingValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationsignals_grouping_configuration#grouping_name ApplicationsignalsGroupingConfiguration#grouping_name}
    */
    readonly groupingName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationsignals_grouping_configuration#grouping_source_keys ApplicationsignalsGroupingConfiguration#grouping_source_keys}
    */
    readonly groupingSourceKeys: string[];
}
export declare function applicationsignalsGroupingConfigurationGroupingAttributeDefinitionsToTerraform(struct?: ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions | cdktn.IResolvable): any;
export declare function applicationsignalsGroupingConfigurationGroupingAttributeDefinitionsToHclTerraform(struct?: ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions | cdktn.IResolvable): any;
export declare class ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions | cdktn.IResolvable | undefined);
    private _defaultGroupingValue?;
    get defaultGroupingValue(): string;
    set defaultGroupingValue(value: string);
    resetDefaultGroupingValue(): void;
    get defaultGroupingValueInput(): string | undefined;
    private _groupingName?;
    get groupingName(): string;
    set groupingName(value: string);
    get groupingNameInput(): string | undefined;
    private _groupingSourceKeys?;
    get groupingSourceKeys(): string[];
    set groupingSourceKeys(value: string[]);
    get groupingSourceKeysInput(): string[] | undefined;
}
export declare class ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitionsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationsignals_grouping_configuration awscc_applicationsignals_grouping_configuration}
*/
export declare class ApplicationsignalsGroupingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_applicationsignals_grouping_configuration";
    /**
    * Generates CDKTN code for importing a ApplicationsignalsGroupingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationsignalsGroupingConfiguration to import
    * @param importFromId The id of the existing ApplicationsignalsGroupingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationsignals_grouping_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationsignalsGroupingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationsignals_grouping_configuration awscc_applicationsignals_grouping_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationsignalsGroupingConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationsignalsGroupingConfigurationConfig);
    get accountId(): string;
    private _groupingAttributeDefinitions;
    get groupingAttributeDefinitions(): ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitionsList;
    putGroupingAttributeDefinitions(value: ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions[] | cdktn.IResolvable): void;
    get groupingAttributeDefinitionsInput(): cdktn.IResolvable | ApplicationsignalsGroupingConfigurationGroupingAttributeDefinitions[] | undefined;
    get id(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
