/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAccountaccessEntitlementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/accountaccess_entitlement#id DataAwsccAccountaccessEntitlement#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter {
}
export declare function dataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterToTerraform(struct?: DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter): any;
export declare function dataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterToHclTerraform(struct?: DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter): any;
export declare class DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | undefined;
    set internalValue(value: DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | undefined);
    get groupId(): string;
    get userId(): string;
}
export interface DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipal {
}
export declare function dataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalToTerraform(struct?: DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipal): any;
export declare function dataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalToHclTerraform(struct?: DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipal): any;
export declare class DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipal | undefined;
    set internalValue(value: DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipal | undefined);
    private _identityCenter;
    get identityCenter(): DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterOutputReference;
}
export interface DataAwsccAccountaccessEntitlementEntitlementPrincipalRole {
}
export declare function dataAwsccAccountaccessEntitlementEntitlementPrincipalRoleToTerraform(struct?: DataAwsccAccountaccessEntitlementEntitlementPrincipalRole): any;
export declare function dataAwsccAccountaccessEntitlementEntitlementPrincipalRoleToHclTerraform(struct?: DataAwsccAccountaccessEntitlementEntitlementPrincipalRole): any;
export declare class DataAwsccAccountaccessEntitlementEntitlementPrincipalRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccountaccessEntitlementEntitlementPrincipalRole | undefined;
    set internalValue(value: DataAwsccAccountaccessEntitlementEntitlementPrincipalRole | undefined);
    get account(): string;
    private _principal;
    get principal(): DataAwsccAccountaccessEntitlementEntitlementPrincipalRolePrincipalOutputReference;
    get roleArn(): string;
}
export interface DataAwsccAccountaccessEntitlementEntitlement {
}
export declare function dataAwsccAccountaccessEntitlementEntitlementToTerraform(struct?: DataAwsccAccountaccessEntitlementEntitlement): any;
export declare function dataAwsccAccountaccessEntitlementEntitlementToHclTerraform(struct?: DataAwsccAccountaccessEntitlementEntitlement): any;
export declare class DataAwsccAccountaccessEntitlementEntitlementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccountaccessEntitlementEntitlement | undefined;
    set internalValue(value: DataAwsccAccountaccessEntitlementEntitlement | undefined);
    private _principalRole;
    get principalRole(): DataAwsccAccountaccessEntitlementEntitlementPrincipalRoleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/accountaccess_entitlement awscc_accountaccess_entitlement}
*/
export declare class DataAwsccAccountaccessEntitlement extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_accountaccess_entitlement";
    /**
    * Generates CDKTN code for importing a DataAwsccAccountaccessEntitlement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAccountaccessEntitlement to import
    * @param importFromId The id of the existing DataAwsccAccountaccessEntitlement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/accountaccess_entitlement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAccountaccessEntitlement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/accountaccess_entitlement awscc_accountaccess_entitlement} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAccountaccessEntitlementConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAccountaccessEntitlementConfig);
    get applicationArn(): string;
    get createdAt(): string;
    private _entitlement;
    get entitlement(): DataAwsccAccountaccessEntitlementEntitlementOutputReference;
    get entitlementId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
