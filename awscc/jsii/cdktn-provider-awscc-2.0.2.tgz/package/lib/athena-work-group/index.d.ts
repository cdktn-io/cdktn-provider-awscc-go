/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AthenaWorkGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The workgroup description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#description AthenaWorkGroup#description}
    */
    readonly description?: string;
    /**
    * The workGroup name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#name AthenaWorkGroup#name}
    */
    readonly name: string;
    /**
    * The option to delete the workgroup and its contents even if the workgroup contains any named queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#recursive_delete_option AthenaWorkGroup#recursive_delete_option}
    */
    readonly recursiveDeleteOption?: boolean | cdktn.IResolvable;
    /**
    * The state of the workgroup: ENABLED or DISABLED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#state AthenaWorkGroup#state}
    */
    readonly state?: string;
    /**
    * One or more tags, separated by commas, that you want to attach to the workgroup as you create it
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#tags AthenaWorkGroup#tags}
    */
    readonly tags?: AthenaWorkGroupTags[] | cdktn.IResolvable;
    /**
    * The workgroup configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#work_group_configuration AthenaWorkGroup#work_group_configuration}
    */
    readonly workGroupConfiguration?: AthenaWorkGroupWorkGroupConfiguration;
    /**
    * The workgroup configuration update object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#work_group_configuration_updates AthenaWorkGroup#work_group_configuration_updates}
    */
    readonly workGroupConfigurationUpdates?: AthenaWorkGroupWorkGroupConfigurationUpdates;
}
export interface AthenaWorkGroupTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#key AthenaWorkGroup#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#value AthenaWorkGroup#value}
    */
    readonly value?: string;
}
export declare function athenaWorkGroupTagsToTerraform(struct?: AthenaWorkGroupTags | cdktn.IResolvable): any;
export declare function athenaWorkGroupTagsToHclTerraform(struct?: AthenaWorkGroupTags | cdktn.IResolvable): any;
export declare class AthenaWorkGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AthenaWorkGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AthenaWorkGroupTagsList extends cdktn.ComplexList {
    internalValue?: AthenaWorkGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AthenaWorkGroupTagsOutputReference;
}
export interface AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfiguration {
    /**
    * For SSE-KMS and CSE-KMS, this is the KMS key ARN or ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications {
    /**
    * The name of the configuration classification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#name AthenaWorkGroup#name}
    */
    readonly name?: string;
    /**
    * A set of properties specified within a configuration classification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#properties AthenaWorkGroup#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
}
export declare function athenaWorkGroupWorkGroupConfigurationEngineConfigurationClassificationsToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationEngineConfigurationClassificationsToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassificationsList extends cdktn.ComplexList {
    internalValue?: AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassificationsOutputReference;
}
export interface AthenaWorkGroupWorkGroupConfigurationEngineConfiguration {
    /**
    * Contains additional notebook engine MAP<string, string> parameter mappings in the form of key-value pairs. To specify an Athena notebook that the Jupyter server will download and serve, specify a value for the StartSessionRequest$NotebookVersion field, and then add a key named NotebookId to AdditionalConfigs that has the value of the Athena notebook ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#additional_configs AthenaWorkGroup#additional_configs}
    */
    readonly additionalConfigs?: {
        [key: string]: string;
    };
    /**
    * The configuration classifications that can be specified for the engine.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#classifications AthenaWorkGroup#classifications}
    */
    readonly classifications?: AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications[] | cdktn.IResolvable;
    /**
    * The number of DPUs to use for the coordinator. A coordinator is a special executor that orchestrates processing work and manages other executors in a notebook session. The default is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#coordinator_dpu_size AthenaWorkGroup#coordinator_dpu_size}
    */
    readonly coordinatorDpuSize?: number;
    /**
    * The default number of DPUs to use for executors. An executor is the smallest unit of compute that a notebook session can request from Athena. The default is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#default_executor_dpu_size AthenaWorkGroup#default_executor_dpu_size}
    */
    readonly defaultExecutorDpuSize?: number;
    /**
    * The maximum number of DPUs that can run concurrently.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#max_concurrent_dpus AthenaWorkGroup#max_concurrent_dpus}
    */
    readonly maxConcurrentDpus?: number;
    /**
    * Specifies custom jar files and Spark properties for use cases like cluster encryption, table formats, and general Spark tuning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#spark_properties AthenaWorkGroup#spark_properties}
    */
    readonly sparkProperties?: {
        [key: string]: string;
    };
}
export declare function athenaWorkGroupWorkGroupConfigurationEngineConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationEngineConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationEngineConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationEngineConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationEngineConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationEngineConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationEngineConfiguration | cdktn.IResolvable | undefined);
    private _additionalConfigs?;
    get additionalConfigs(): {
        [key: string]: string;
    };
    set additionalConfigs(value: {
        [key: string]: string;
    });
    resetAdditionalConfigs(): void;
    get additionalConfigsInput(): {
        [key: string]: string;
    } | undefined;
    private _classifications;
    get classifications(): AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassificationsList;
    putClassifications(value: AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications[] | cdktn.IResolvable): void;
    resetClassifications(): void;
    get classificationsInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationEngineConfigurationClassifications[] | undefined;
    private _coordinatorDpuSize?;
    get coordinatorDpuSize(): number;
    set coordinatorDpuSize(value: number);
    resetCoordinatorDpuSize(): void;
    get coordinatorDpuSizeInput(): number | undefined;
    private _defaultExecutorDpuSize?;
    get defaultExecutorDpuSize(): number;
    set defaultExecutorDpuSize(value: number);
    resetDefaultExecutorDpuSize(): void;
    get defaultExecutorDpuSizeInput(): number | undefined;
    private _maxConcurrentDpus?;
    get maxConcurrentDpus(): number;
    set maxConcurrentDpus(value: number);
    resetMaxConcurrentDpus(): void;
    get maxConcurrentDpusInput(): number | undefined;
    private _sparkProperties?;
    get sparkProperties(): {
        [key: string]: string;
    };
    set sparkProperties(value: {
        [key: string]: string;
    });
    resetSparkProperties(): void;
    get sparkPropertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationEngineVersion {
    /**
    * The engine version requested by the user. Possible values are determined by the output of ListEngineVersions, including Auto. The default is Auto.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#selected_engine_version AthenaWorkGroup#selected_engine_version}
    */
    readonly selectedEngineVersion?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationEngineVersionToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationEngineVersion | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationEngineVersionToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationEngineVersion | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationEngineVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationEngineVersion | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationEngineVersion | cdktn.IResolvable | undefined);
    get effectiveEngineVersion(): string;
    private _selectedEngineVersion?;
    get selectedEngineVersion(): string;
    set selectedEngineVersion(value: string);
    resetSelectedEngineVersion(): void;
    get selectedEngineVersionInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration {
    /**
    * For SSE-KMS and CSE-KMS, this is the KMS key ARN or ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enabled AthenaWorkGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Indicates the encryption configuration for Athena Managed Storage. If not setting this field, Managed Storage will encrypt the query results with Athena's encryption key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#encryption_configuration AthenaWorkGroup#encryption_configuration}
    */
    readonly encryptionConfiguration?: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration;
}
export declare function athenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfiguration {
    /**
    * Enables CloudWatch logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enabled AthenaWorkGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the log group in Amazon CloudWatch Logs where you want to publish your logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#log_group AthenaWorkGroup#log_group}
    */
    readonly logGroup?: string;
    /**
    * Prefix for the CloudWatch log stream name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#log_stream_name_prefix AthenaWorkGroup#log_stream_name_prefix}
    */
    readonly logStreamNamePrefix?: string;
    /**
    * The types of logs that you want to publish to CloudWatch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#log_types AthenaWorkGroup#log_types}
    */
    readonly logTypes?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
}
export declare function athenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _logGroup?;
    get logGroup(): string;
    set logGroup(value: string);
    resetLogGroup(): void;
    get logGroupInput(): string | undefined;
    private _logStreamNamePrefix?;
    get logStreamNamePrefix(): string;
    set logStreamNamePrefix(value: string);
    resetLogStreamNamePrefix(): void;
    get logStreamNamePrefixInput(): string | undefined;
    private _logTypes?;
    get logTypes(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set logTypes(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetLogTypes(): void;
    get logTypesInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfiguration {
    /**
    * Enables managed log persistence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enabled AthenaWorkGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The KMS key ARN to encrypt the logs stored in managed log persistence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfiguration {
    /**
    * Enables S3 log delivery.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enabled AthenaWorkGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The KMS key ARN to encrypt the logs published to the given Amazon S3 destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * The Amazon S3 destination URI for log publishing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#log_location AthenaWorkGroup#log_location}
    */
    readonly logLocation?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _logLocation?;
    get logLocation(): string;
    set logLocation(value: string);
    resetLogLocation(): void;
    get logLocationInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationMonitoringConfiguration {
    /**
    * Configuration settings for delivering logs to Amazon CloudWatch log groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#cloudwatch_logging_configuration AthenaWorkGroup#cloudwatch_logging_configuration}
    */
    readonly cloudwatchLoggingConfiguration?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfiguration;
    /**
    * Configuration settings for managed log persistence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#managed_logging_configuration AthenaWorkGroup#managed_logging_configuration}
    */
    readonly managedLoggingConfiguration?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfiguration;
    /**
    * Configuration settings for delivering logs to Amazon S3 buckets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#s3_logging_configuration AthenaWorkGroup#s3_logging_configuration}
    */
    readonly s3LoggingConfiguration?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfiguration;
}
export declare function athenaWorkGroupWorkGroupConfigurationMonitoringConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationMonitoringConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationMonitoringConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationMonitoringConfiguration | cdktn.IResolvable | undefined);
    private _cloudwatchLoggingConfiguration;
    get cloudwatchLoggingConfiguration(): AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfigurationOutputReference;
    putCloudwatchLoggingConfiguration(value: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfiguration): void;
    resetCloudwatchLoggingConfiguration(): void;
    get cloudwatchLoggingConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationCloudwatchLoggingConfiguration | undefined;
    private _managedLoggingConfiguration;
    get managedLoggingConfiguration(): AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfigurationOutputReference;
    putManagedLoggingConfiguration(value: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfiguration): void;
    resetManagedLoggingConfiguration(): void;
    get managedLoggingConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationManagedLoggingConfiguration | undefined;
    private _s3LoggingConfiguration;
    get s3LoggingConfiguration(): AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfigurationOutputReference;
    putS3LoggingConfiguration(value: AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfiguration): void;
    resetS3LoggingConfiguration(): void;
    get s3LoggingConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationS3LoggingConfiguration | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfiguration {
    /**
    * The Amazon S3 canned ACL that Athena should specify when storing query results. Currently the only supported canned ACL is BUCKET_OWNER_FULL_CONTROL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#s3_acl_option AthenaWorkGroup#s3_acl_option}
    */
    readonly s3AclOption?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfiguration | cdktn.IResolvable | undefined);
    private _s3AclOption?;
    get s3AclOption(): string;
    set s3AclOption(value: string);
    resetS3AclOption(): void;
    get s3AclOptionInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfiguration {
    /**
    * Indicates whether Amazon S3 server-side encryption with Amazon S3-managed keys (SSE-S3), server-side encryption with KMS-managed keys (SSE-KMS), or client-side encryption with KMS-managed keys (CSE-KMS) is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#encryption_option AthenaWorkGroup#encryption_option}
    */
    readonly encryptionOption?: string;
    /**
    * For SSE-KMS and CSE-KMS, this is the KMS key ARN or ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _encryptionOption?;
    get encryptionOption(): string;
    set encryptionOption(value: string);
    resetEncryptionOption(): void;
    get encryptionOptionInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationResultConfiguration {
    /**
    * Indicates that an Amazon S3 canned ACL should be set to control ownership of stored query results
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#acl_configuration AthenaWorkGroup#acl_configuration}
    */
    readonly aclConfiguration?: AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfiguration;
    /**
    * If query results are encrypted in Amazon S3, indicates the encryption option used (for example, SSE-KMS or CSE-KMS) and key information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#encryption_configuration AthenaWorkGroup#encryption_configuration}
    */
    readonly encryptionConfiguration?: AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfiguration;
    /**
    * The AWS account ID of the owner of S3 bucket where query results are stored
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#expected_bucket_owner AthenaWorkGroup#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * The location in Amazon S3 where your query results are stored, such as s3://path/to/query/bucket/. To run the query, you must specify the query results location using one of the ways: either for individual queries using either this setting (client-side), or in the workgroup, using WorkGroupConfiguration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#output_location AthenaWorkGroup#output_location}
    */
    readonly outputLocation?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationResultConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationResultConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationResultConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationResultConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationResultConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationResultConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationResultConfiguration | cdktn.IResolvable | undefined);
    private _aclConfiguration;
    get aclConfiguration(): AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfigurationOutputReference;
    putAclConfiguration(value: AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfiguration): void;
    resetAclConfiguration(): void;
    get aclConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationResultConfigurationAclConfiguration | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationResultConfigurationEncryptionConfiguration | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _outputLocation?;
    get outputLocation(): string;
    set outputLocation(value: string);
    resetOutputLocation(): void;
    get outputLocationInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfiguration {
    /**
    * Additional Configuration that are passed to Athena Spark Calculations running in this workgroup
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#additional_configuration AthenaWorkGroup#additional_configuration}
    */
    readonly additionalConfiguration?: string;
    /**
    * The upper data usage limit (cutoff) for the amount of bytes a single query in a workgroup is allowed to scan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#bytes_scanned_cutoff_per_query AthenaWorkGroup#bytes_scanned_cutoff_per_query}
    */
    readonly bytesScannedCutoffPerQuery?: number;
    /**
    * Indicates the KMS key for encrypting notebook content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#customer_content_encryption_configuration AthenaWorkGroup#customer_content_encryption_configuration}
    */
    readonly customerContentEncryptionConfiguration?: AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfiguration;
    /**
    * If set to "true", the settings for the workgroup override client-side settings. If set to "false", client-side settings are used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enforce_work_group_configuration AthenaWorkGroup#enforce_work_group_configuration}
    */
    readonly enforceWorkGroupConfiguration?: boolean | cdktn.IResolvable;
    /**
    * The engine configuration for running queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#engine_configuration AthenaWorkGroup#engine_configuration}
    */
    readonly engineConfiguration?: AthenaWorkGroupWorkGroupConfigurationEngineConfiguration;
    /**
    * The Athena engine version for running queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#engine_version AthenaWorkGroup#engine_version}
    */
    readonly engineVersion?: AthenaWorkGroupWorkGroupConfigurationEngineVersion;
    /**
    * The ARN of the execution role used to access user resources for Spark sessions and Identity Center enabled workgroups. This property applies only to Spark enabled workgroups and Identity Center enabled workgroups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#execution_role AthenaWorkGroup#execution_role}
    */
    readonly executionRole?: string;
    /**
    * The configuration for the managed query results and encryption option. ResultConfiguration and ManagedQueryResultsConfiguration cannot be set at the same time
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#managed_query_results_configuration AthenaWorkGroup#managed_query_results_configuration}
    */
    readonly managedQueryResultsConfiguration?: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfiguration;
    /**
    * Contains the configuration settings for managed log persistence, delivering logs to Amazon S3 buckets, Amazon CloudWatch log groups etc.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#monitoring_configuration AthenaWorkGroup#monitoring_configuration}
    */
    readonly monitoringConfiguration?: AthenaWorkGroupWorkGroupConfigurationMonitoringConfiguration;
    /**
    * Indicates that the Amazon CloudWatch metrics are enabled for the workgroup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#publish_cloudwatch_metrics_enabled AthenaWorkGroup#publish_cloudwatch_metrics_enabled}
    */
    readonly publishCloudwatchMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * If set to true, allows members assigned to a workgroup to reference Amazon S3 Requester Pays buckets in queries. If set to false, workgroup members cannot query data from Requester Pays buckets, and queries that retrieve data from Requester Pays buckets cause an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#requester_pays_enabled AthenaWorkGroup#requester_pays_enabled}
    */
    readonly requesterPaysEnabled?: boolean | cdktn.IResolvable;
    /**
    * The location in Amazon S3 where query results are stored and the encryption option, if any, used for query results. These are known as "client-side settings". If workgroup settings override client-side settings, then the query uses the workgroup settings.
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#result_configuration AthenaWorkGroup#result_configuration}
    */
    readonly resultConfiguration?: AthenaWorkGroupWorkGroupConfigurationResultConfiguration;
}
export declare function athenaWorkGroupWorkGroupConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfiguration | cdktn.IResolvable | undefined);
    private _additionalConfiguration?;
    get additionalConfiguration(): string;
    set additionalConfiguration(value: string);
    resetAdditionalConfiguration(): void;
    get additionalConfigurationInput(): string | undefined;
    private _bytesScannedCutoffPerQuery?;
    get bytesScannedCutoffPerQuery(): number;
    set bytesScannedCutoffPerQuery(value: number);
    resetBytesScannedCutoffPerQuery(): void;
    get bytesScannedCutoffPerQueryInput(): number | undefined;
    private _customerContentEncryptionConfiguration;
    get customerContentEncryptionConfiguration(): AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfigurationOutputReference;
    putCustomerContentEncryptionConfiguration(value: AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfiguration): void;
    resetCustomerContentEncryptionConfiguration(): void;
    get customerContentEncryptionConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationCustomerContentEncryptionConfiguration | undefined;
    private _enforceWorkGroupConfiguration?;
    get enforceWorkGroupConfiguration(): boolean | cdktn.IResolvable;
    set enforceWorkGroupConfiguration(value: boolean | cdktn.IResolvable);
    resetEnforceWorkGroupConfiguration(): void;
    get enforceWorkGroupConfigurationInput(): boolean | cdktn.IResolvable | undefined;
    private _engineConfiguration;
    get engineConfiguration(): AthenaWorkGroupWorkGroupConfigurationEngineConfigurationOutputReference;
    putEngineConfiguration(value: AthenaWorkGroupWorkGroupConfigurationEngineConfiguration): void;
    resetEngineConfiguration(): void;
    get engineConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationEngineConfiguration | undefined;
    private _engineVersion;
    get engineVersion(): AthenaWorkGroupWorkGroupConfigurationEngineVersionOutputReference;
    putEngineVersion(value: AthenaWorkGroupWorkGroupConfigurationEngineVersion): void;
    resetEngineVersion(): void;
    get engineVersionInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationEngineVersion | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    resetExecutionRole(): void;
    get executionRoleInput(): string | undefined;
    private _managedQueryResultsConfiguration;
    get managedQueryResultsConfiguration(): AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfigurationOutputReference;
    putManagedQueryResultsConfiguration(value: AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfiguration): void;
    resetManagedQueryResultsConfiguration(): void;
    get managedQueryResultsConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationManagedQueryResultsConfiguration | undefined;
    private _monitoringConfiguration;
    get monitoringConfiguration(): AthenaWorkGroupWorkGroupConfigurationMonitoringConfigurationOutputReference;
    putMonitoringConfiguration(value: AthenaWorkGroupWorkGroupConfigurationMonitoringConfiguration): void;
    resetMonitoringConfiguration(): void;
    get monitoringConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationMonitoringConfiguration | undefined;
    private _publishCloudwatchMetricsEnabled?;
    get publishCloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
    set publishCloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetPublishCloudwatchMetricsEnabled(): void;
    get publishCloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _requesterPaysEnabled?;
    get requesterPaysEnabled(): boolean | cdktn.IResolvable;
    set requesterPaysEnabled(value: boolean | cdktn.IResolvable);
    resetRequesterPaysEnabled(): void;
    get requesterPaysEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _resultConfiguration;
    get resultConfiguration(): AthenaWorkGroupWorkGroupConfigurationResultConfigurationOutputReference;
    putResultConfiguration(value: AthenaWorkGroupWorkGroupConfigurationResultConfiguration): void;
    resetResultConfiguration(): void;
    get resultConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationResultConfiguration | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfiguration {
    /**
    * For SSE-KMS and CSE-KMS, this is the KMS key ARN or ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications {
    /**
    * The name of the configuration classification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#name AthenaWorkGroup#name}
    */
    readonly name?: string;
    /**
    * A set of properties specified within a configuration classification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#properties AthenaWorkGroup#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassificationsToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassificationsToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassificationsList extends cdktn.ComplexList {
    internalValue?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassificationsOutputReference;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfiguration {
    /**
    * Contains additional notebook engine MAP<string, string> parameter mappings in the form of key-value pairs. To specify an Athena notebook that the Jupyter server will download and serve, specify a value for the StartSessionRequest$NotebookVersion field, and then add a key named NotebookId to AdditionalConfigs that has the value of the Athena notebook ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#additional_configs AthenaWorkGroup#additional_configs}
    */
    readonly additionalConfigs?: {
        [key: string]: string;
    };
    /**
    * The configuration classifications that can be specified for the engine.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#classifications AthenaWorkGroup#classifications}
    */
    readonly classifications?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications[] | cdktn.IResolvable;
    /**
    * The number of DPUs to use for the coordinator. A coordinator is a special executor that orchestrates processing work and manages other executors in a notebook session. The default is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#coordinator_dpu_size AthenaWorkGroup#coordinator_dpu_size}
    */
    readonly coordinatorDpuSize?: number;
    /**
    * The default number of DPUs to use for executors. An executor is the smallest unit of compute that a notebook session can request from Athena. The default is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#default_executor_dpu_size AthenaWorkGroup#default_executor_dpu_size}
    */
    readonly defaultExecutorDpuSize?: number;
    /**
    * The maximum number of DPUs that can run concurrently.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#max_concurrent_dpus AthenaWorkGroup#max_concurrent_dpus}
    */
    readonly maxConcurrentDpus?: number;
    /**
    * Specifies custom jar files and Spark properties for use cases like cluster encryption, table formats, and general Spark tuning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#spark_properties AthenaWorkGroup#spark_properties}
    */
    readonly sparkProperties?: {
        [key: string]: string;
    };
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfiguration | cdktn.IResolvable | undefined);
    private _additionalConfigs?;
    get additionalConfigs(): {
        [key: string]: string;
    };
    set additionalConfigs(value: {
        [key: string]: string;
    });
    resetAdditionalConfigs(): void;
    get additionalConfigsInput(): {
        [key: string]: string;
    } | undefined;
    private _classifications;
    get classifications(): AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassificationsList;
    putClassifications(value: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications[] | cdktn.IResolvable): void;
    resetClassifications(): void;
    get classificationsInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationClassifications[] | undefined;
    private _coordinatorDpuSize?;
    get coordinatorDpuSize(): number;
    set coordinatorDpuSize(value: number);
    resetCoordinatorDpuSize(): void;
    get coordinatorDpuSizeInput(): number | undefined;
    private _defaultExecutorDpuSize?;
    get defaultExecutorDpuSize(): number;
    set defaultExecutorDpuSize(value: number);
    resetDefaultExecutorDpuSize(): void;
    get defaultExecutorDpuSizeInput(): number | undefined;
    private _maxConcurrentDpus?;
    get maxConcurrentDpus(): number;
    set maxConcurrentDpus(value: number);
    resetMaxConcurrentDpus(): void;
    get maxConcurrentDpusInput(): number | undefined;
    private _sparkProperties?;
    get sparkProperties(): {
        [key: string]: string;
    };
    set sparkProperties(value: {
        [key: string]: string;
    });
    resetSparkProperties(): void;
    get sparkPropertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersion {
    /**
    * The engine version requested by the user. Possible values are determined by the output of ListEngineVersions, including Auto. The default is Auto.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#selected_engine_version AthenaWorkGroup#selected_engine_version}
    */
    readonly selectedEngineVersion?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesEngineVersionToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersion | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesEngineVersionToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersion | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersion | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersion | cdktn.IResolvable | undefined);
    get effectiveEngineVersion(): string;
    private _selectedEngineVersion?;
    get selectedEngineVersion(): string;
    set selectedEngineVersion(value: string);
    resetSelectedEngineVersion(): void;
    get selectedEngineVersionInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfiguration {
    /**
    * For SSE-KMS and CSE-KMS, this is the KMS key ARN or ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enabled AthenaWorkGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Indicates the encryption configuration for Athena Managed Storage. If not setting this field, Managed Storage will encrypt the query results with Athena's encryption key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#encryption_configuration AthenaWorkGroup#encryption_configuration}
    */
    readonly encryptionConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfiguration;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationEncryptionConfiguration | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfiguration {
    /**
    * Enables CloudWatch logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enabled AthenaWorkGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the log group in Amazon CloudWatch Logs where you want to publish your logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#log_group AthenaWorkGroup#log_group}
    */
    readonly logGroup?: string;
    /**
    * Prefix for the CloudWatch log stream name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#log_stream_name_prefix AthenaWorkGroup#log_stream_name_prefix}
    */
    readonly logStreamNamePrefix?: string;
    /**
    * The types of logs that you want to publish to CloudWatch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#log_types AthenaWorkGroup#log_types}
    */
    readonly logTypes?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _logGroup?;
    get logGroup(): string;
    set logGroup(value: string);
    resetLogGroup(): void;
    get logGroupInput(): string | undefined;
    private _logStreamNamePrefix?;
    get logStreamNamePrefix(): string;
    set logStreamNamePrefix(value: string);
    resetLogStreamNamePrefix(): void;
    get logStreamNamePrefixInput(): string | undefined;
    private _logTypes?;
    get logTypes(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set logTypes(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetLogTypes(): void;
    get logTypesInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfiguration {
    /**
    * Enables managed log persistence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enabled AthenaWorkGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The KMS key ARN to encrypt the logs stored in managed log persistence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfiguration {
    /**
    * Enables S3 log delivery.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enabled AthenaWorkGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The KMS key ARN to encrypt the logs published to the given Amazon S3 destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * The Amazon S3 destination URI for log publishing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#log_location AthenaWorkGroup#log_location}
    */
    readonly logLocation?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _logLocation?;
    get logLocation(): string;
    set logLocation(value: string);
    resetLogLocation(): void;
    get logLocationInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfiguration {
    /**
    * Configuration settings for delivering logs to Amazon CloudWatch log groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#cloudwatch_logging_configuration AthenaWorkGroup#cloudwatch_logging_configuration}
    */
    readonly cloudwatchLoggingConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfiguration;
    /**
    * Configuration settings for managed log persistence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#managed_logging_configuration AthenaWorkGroup#managed_logging_configuration}
    */
    readonly managedLoggingConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfiguration;
    /**
    * Configuration settings for delivering logs to Amazon S3 buckets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#s3_logging_configuration AthenaWorkGroup#s3_logging_configuration}
    */
    readonly s3LoggingConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfiguration;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfiguration | cdktn.IResolvable | undefined);
    private _cloudwatchLoggingConfiguration;
    get cloudwatchLoggingConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfigurationOutputReference;
    putCloudwatchLoggingConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfiguration): void;
    resetCloudwatchLoggingConfiguration(): void;
    get cloudwatchLoggingConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationCloudwatchLoggingConfiguration | undefined;
    private _managedLoggingConfiguration;
    get managedLoggingConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfigurationOutputReference;
    putManagedLoggingConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfiguration): void;
    resetManagedLoggingConfiguration(): void;
    get managedLoggingConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationManagedLoggingConfiguration | undefined;
    private _s3LoggingConfiguration;
    get s3LoggingConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfigurationOutputReference;
    putS3LoggingConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfiguration): void;
    resetS3LoggingConfiguration(): void;
    get s3LoggingConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationS3LoggingConfiguration | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfiguration {
    /**
    * The Amazon S3 canned ACL that Athena should specify when storing query results. Currently the only supported canned ACL is BUCKET_OWNER_FULL_CONTROL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#s3_acl_option AthenaWorkGroup#s3_acl_option}
    */
    readonly s3AclOption?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfiguration | cdktn.IResolvable | undefined);
    private _s3AclOption?;
    get s3AclOption(): string;
    set s3AclOption(value: string);
    resetS3AclOption(): void;
    get s3AclOptionInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfiguration {
    /**
    * Indicates whether Amazon S3 server-side encryption with Amazon S3-managed keys (SSE-S3), server-side encryption with KMS-managed keys (SSE-KMS), or client-side encryption with KMS-managed keys (CSE-KMS) is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#encryption_option AthenaWorkGroup#encryption_option}
    */
    readonly encryptionOption?: string;
    /**
    * For SSE-KMS and CSE-KMS, this is the KMS key ARN or ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#kms_key AthenaWorkGroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfigurationToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfiguration | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfigurationToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfiguration | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _encryptionOption?;
    get encryptionOption(): string;
    set encryptionOption(value: string);
    resetEncryptionOption(): void;
    get encryptionOptionInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdates {
    /**
    * Indicates that an Amazon S3 canned ACL should be set to control ownership of stored query results
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#acl_configuration AthenaWorkGroup#acl_configuration}
    */
    readonly aclConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfiguration;
    /**
    * If query results are encrypted in Amazon S3, indicates the encryption option used (for example, SSE-KMS or CSE-KMS) and key information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#encryption_configuration AthenaWorkGroup#encryption_configuration}
    */
    readonly encryptionConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfiguration;
    /**
    * The AWS account ID of the owner of S3 bucket where query results are stored
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#expected_bucket_owner AthenaWorkGroup#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * The location in Amazon S3 where your query results are stored, such as s3://path/to/query/bucket/. To run the query, you must specify the query results location using one of the ways: either for individual queries using either this setting (client-side), or in the workgroup, using WorkGroupConfiguration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#output_location AthenaWorkGroup#output_location}
    */
    readonly outputLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#remove_acl_configuration AthenaWorkGroup#remove_acl_configuration}
    */
    readonly removeAclConfiguration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#remove_encryption_configuration AthenaWorkGroup#remove_encryption_configuration}
    */
    readonly removeEncryptionConfiguration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#remove_expected_bucket_owner AthenaWorkGroup#remove_expected_bucket_owner}
    */
    readonly removeExpectedBucketOwner?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#remove_output_location AthenaWorkGroup#remove_output_location}
    */
    readonly removeOutputLocation?: boolean | cdktn.IResolvable;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdates | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdates | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdates | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdates | cdktn.IResolvable | undefined);
    private _aclConfiguration;
    get aclConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfigurationOutputReference;
    putAclConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfiguration): void;
    resetAclConfiguration(): void;
    get aclConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesAclConfiguration | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesEncryptionConfiguration | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _outputLocation?;
    get outputLocation(): string;
    set outputLocation(value: string);
    resetOutputLocation(): void;
    get outputLocationInput(): string | undefined;
    private _removeAclConfiguration?;
    get removeAclConfiguration(): boolean | cdktn.IResolvable;
    set removeAclConfiguration(value: boolean | cdktn.IResolvable);
    resetRemoveAclConfiguration(): void;
    get removeAclConfigurationInput(): boolean | cdktn.IResolvable | undefined;
    private _removeEncryptionConfiguration?;
    get removeEncryptionConfiguration(): boolean | cdktn.IResolvable;
    set removeEncryptionConfiguration(value: boolean | cdktn.IResolvable);
    resetRemoveEncryptionConfiguration(): void;
    get removeEncryptionConfigurationInput(): boolean | cdktn.IResolvable | undefined;
    private _removeExpectedBucketOwner?;
    get removeExpectedBucketOwner(): boolean | cdktn.IResolvable;
    set removeExpectedBucketOwner(value: boolean | cdktn.IResolvable);
    resetRemoveExpectedBucketOwner(): void;
    get removeExpectedBucketOwnerInput(): boolean | cdktn.IResolvable | undefined;
    private _removeOutputLocation?;
    get removeOutputLocation(): boolean | cdktn.IResolvable;
    set removeOutputLocation(value: boolean | cdktn.IResolvable);
    resetRemoveOutputLocation(): void;
    get removeOutputLocationInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AthenaWorkGroupWorkGroupConfigurationUpdates {
    /**
    * Additional Configuration that are passed to Athena Spark Calculations running in this workgroup
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#additional_configuration AthenaWorkGroup#additional_configuration}
    */
    readonly additionalConfiguration?: string;
    /**
    * The upper data usage limit (cutoff) for the amount of bytes a single query in a workgroup is allowed to scan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#bytes_scanned_cutoff_per_query AthenaWorkGroup#bytes_scanned_cutoff_per_query}
    */
    readonly bytesScannedCutoffPerQuery?: number;
    /**
    * Indicates the KMS key for encrypting notebook content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#customer_content_encryption_configuration AthenaWorkGroup#customer_content_encryption_configuration}
    */
    readonly customerContentEncryptionConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfiguration;
    /**
    * If set to "true", the settings for the workgroup override client-side settings. If set to "false", client-side settings are used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#enforce_work_group_configuration AthenaWorkGroup#enforce_work_group_configuration}
    */
    readonly enforceWorkGroupConfiguration?: boolean | cdktn.IResolvable;
    /**
    * The engine configuration for running queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#engine_configuration AthenaWorkGroup#engine_configuration}
    */
    readonly engineConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfiguration;
    /**
    * The Athena engine version for running queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#engine_version AthenaWorkGroup#engine_version}
    */
    readonly engineVersion?: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersion;
    /**
    * The ARN of the execution role used to access user resources for Spark sessions and Identity Center enabled workgroups. This property applies only to Spark enabled workgroups and Identity Center enabled workgroups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#execution_role AthenaWorkGroup#execution_role}
    */
    readonly executionRole?: string;
    /**
    * The configuration for the managed query results and encryption option. ResultConfiguration and ManagedQueryResultsConfiguration cannot be set at the same time
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#managed_query_results_configuration AthenaWorkGroup#managed_query_results_configuration}
    */
    readonly managedQueryResultsConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfiguration;
    /**
    * Contains the configuration settings for managed log persistence, delivering logs to Amazon S3 buckets, Amazon CloudWatch log groups etc.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#monitoring_configuration AthenaWorkGroup#monitoring_configuration}
    */
    readonly monitoringConfiguration?: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfiguration;
    /**
    * Indicates that the Amazon CloudWatch metrics are enabled for the workgroup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#publish_cloudwatch_metrics_enabled AthenaWorkGroup#publish_cloudwatch_metrics_enabled}
    */
    readonly publishCloudwatchMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Indicates that the data usage control limit per query is removed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#remove_bytes_scanned_cutoff_per_query AthenaWorkGroup#remove_bytes_scanned_cutoff_per_query}
    */
    readonly removeBytesScannedCutoffPerQuery?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#remove_customer_content_encryption_configuration AthenaWorkGroup#remove_customer_content_encryption_configuration}
    */
    readonly removeCustomerContentEncryptionConfiguration?: boolean | cdktn.IResolvable;
    /**
    * If set to true, allows members assigned to a workgroup to reference Amazon S3 Requester Pays buckets in queries. If set to false, workgroup members cannot query data from Requester Pays buckets, and queries that retrieve data from Requester Pays buckets cause an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#requester_pays_enabled AthenaWorkGroup#requester_pays_enabled}
    */
    readonly requesterPaysEnabled?: boolean | cdktn.IResolvable;
    /**
    * The result configuration information about the queries in this workgroup that will be updated. Includes the updated results location and an updated option for encrypting query results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#result_configuration_updates AthenaWorkGroup#result_configuration_updates}
    */
    readonly resultConfigurationUpdates?: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdates;
}
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesToTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdates | cdktn.IResolvable): any;
export declare function athenaWorkGroupWorkGroupConfigurationUpdatesToHclTerraform(struct?: AthenaWorkGroupWorkGroupConfigurationUpdates | cdktn.IResolvable): any;
export declare class AthenaWorkGroupWorkGroupConfigurationUpdatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkGroupWorkGroupConfigurationUpdates | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkGroupWorkGroupConfigurationUpdates | cdktn.IResolvable | undefined);
    private _additionalConfiguration?;
    get additionalConfiguration(): string;
    set additionalConfiguration(value: string);
    resetAdditionalConfiguration(): void;
    get additionalConfigurationInput(): string | undefined;
    private _bytesScannedCutoffPerQuery?;
    get bytesScannedCutoffPerQuery(): number;
    set bytesScannedCutoffPerQuery(value: number);
    resetBytesScannedCutoffPerQuery(): void;
    get bytesScannedCutoffPerQueryInput(): number | undefined;
    private _customerContentEncryptionConfiguration;
    get customerContentEncryptionConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfigurationOutputReference;
    putCustomerContentEncryptionConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfiguration): void;
    resetCustomerContentEncryptionConfiguration(): void;
    get customerContentEncryptionConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesCustomerContentEncryptionConfiguration | undefined;
    private _enforceWorkGroupConfiguration?;
    get enforceWorkGroupConfiguration(): boolean | cdktn.IResolvable;
    set enforceWorkGroupConfiguration(value: boolean | cdktn.IResolvable);
    resetEnforceWorkGroupConfiguration(): void;
    get enforceWorkGroupConfigurationInput(): boolean | cdktn.IResolvable | undefined;
    private _engineConfiguration;
    get engineConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfigurationOutputReference;
    putEngineConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfiguration): void;
    resetEngineConfiguration(): void;
    get engineConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesEngineConfiguration | undefined;
    private _engineVersion;
    get engineVersion(): AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersionOutputReference;
    putEngineVersion(value: AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersion): void;
    resetEngineVersion(): void;
    get engineVersionInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesEngineVersion | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    resetExecutionRole(): void;
    get executionRoleInput(): string | undefined;
    private _managedQueryResultsConfiguration;
    get managedQueryResultsConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfigurationOutputReference;
    putManagedQueryResultsConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfiguration): void;
    resetManagedQueryResultsConfiguration(): void;
    get managedQueryResultsConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesManagedQueryResultsConfiguration | undefined;
    private _monitoringConfiguration;
    get monitoringConfiguration(): AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfigurationOutputReference;
    putMonitoringConfiguration(value: AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfiguration): void;
    resetMonitoringConfiguration(): void;
    get monitoringConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesMonitoringConfiguration | undefined;
    private _publishCloudwatchMetricsEnabled?;
    get publishCloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
    set publishCloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetPublishCloudwatchMetricsEnabled(): void;
    get publishCloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _removeBytesScannedCutoffPerQuery?;
    get removeBytesScannedCutoffPerQuery(): boolean | cdktn.IResolvable;
    set removeBytesScannedCutoffPerQuery(value: boolean | cdktn.IResolvable);
    resetRemoveBytesScannedCutoffPerQuery(): void;
    get removeBytesScannedCutoffPerQueryInput(): boolean | cdktn.IResolvable | undefined;
    private _removeCustomerContentEncryptionConfiguration?;
    get removeCustomerContentEncryptionConfiguration(): boolean | cdktn.IResolvable;
    set removeCustomerContentEncryptionConfiguration(value: boolean | cdktn.IResolvable);
    resetRemoveCustomerContentEncryptionConfiguration(): void;
    get removeCustomerContentEncryptionConfigurationInput(): boolean | cdktn.IResolvable | undefined;
    private _requesterPaysEnabled?;
    get requesterPaysEnabled(): boolean | cdktn.IResolvable;
    set requesterPaysEnabled(value: boolean | cdktn.IResolvable);
    resetRequesterPaysEnabled(): void;
    get requesterPaysEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _resultConfigurationUpdates;
    get resultConfigurationUpdates(): AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdatesOutputReference;
    putResultConfigurationUpdates(value: AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdates): void;
    resetResultConfigurationUpdates(): void;
    get resultConfigurationUpdatesInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdatesResultConfigurationUpdates | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group awscc_athena_work_group}
*/
export declare class AthenaWorkGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_athena_work_group";
    /**
    * Generates CDKTN code for importing a AthenaWorkGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AthenaWorkGroup to import
    * @param importFromId The id of the existing AthenaWorkGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AthenaWorkGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/athena_work_group awscc_athena_work_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AthenaWorkGroupConfig
    */
    constructor(scope: Construct, id: string, config: AthenaWorkGroupConfig);
    get creationTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _recursiveDeleteOption?;
    get recursiveDeleteOption(): boolean | cdktn.IResolvable;
    set recursiveDeleteOption(value: boolean | cdktn.IResolvable);
    resetRecursiveDeleteOption(): void;
    get recursiveDeleteOptionInput(): boolean | cdktn.IResolvable | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags;
    get tags(): AthenaWorkGroupTagsList;
    putTags(value: AthenaWorkGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AthenaWorkGroupTags[] | undefined;
    private _workGroupConfiguration;
    get workGroupConfiguration(): AthenaWorkGroupWorkGroupConfigurationOutputReference;
    putWorkGroupConfiguration(value: AthenaWorkGroupWorkGroupConfiguration): void;
    resetWorkGroupConfiguration(): void;
    get workGroupConfigurationInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfiguration | undefined;
    private _workGroupConfigurationUpdates;
    get workGroupConfigurationUpdates(): AthenaWorkGroupWorkGroupConfigurationUpdatesOutputReference;
    putWorkGroupConfigurationUpdates(value: AthenaWorkGroupWorkGroupConfigurationUpdates): void;
    resetWorkGroupConfigurationUpdates(): void;
    get workGroupConfigurationUpdatesInput(): cdktn.IResolvable | AthenaWorkGroupWorkGroupConfigurationUpdates | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
