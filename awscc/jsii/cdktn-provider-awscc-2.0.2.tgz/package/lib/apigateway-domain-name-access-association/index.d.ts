/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayDomainNameAccessAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The source of the domain name access association resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association#access_association_source ApigatewayDomainNameAccessAssociation#access_association_source}
    */
    readonly accessAssociationSource: string;
    /**
    * The source type of the domain name access association resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association#access_association_source_type ApigatewayDomainNameAccessAssociation#access_association_source_type}
    */
    readonly accessAssociationSourceType: string;
    /**
    * The amazon resource name (ARN) of the domain name resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association#domain_name_arn ApigatewayDomainNameAccessAssociation#domain_name_arn}
    */
    readonly domainNameArn: string;
    /**
    * An array of arbitrary tags (key-value pairs) to associate with the domainname access association.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association#tags ApigatewayDomainNameAccessAssociation#tags}
    */
    readonly tags?: ApigatewayDomainNameAccessAssociationTags[] | cdktn.IResolvable;
}
export interface ApigatewayDomainNameAccessAssociationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association#key ApigatewayDomainNameAccessAssociation#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association#value ApigatewayDomainNameAccessAssociation#value}
    */
    readonly value?: string;
}
export declare function apigatewayDomainNameAccessAssociationTagsToTerraform(struct?: ApigatewayDomainNameAccessAssociationTags | cdktn.IResolvable): any;
export declare function apigatewayDomainNameAccessAssociationTagsToHclTerraform(struct?: ApigatewayDomainNameAccessAssociationTags | cdktn.IResolvable): any;
export declare class ApigatewayDomainNameAccessAssociationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayDomainNameAccessAssociationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDomainNameAccessAssociationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigatewayDomainNameAccessAssociationTagsList extends cdktn.ComplexList {
    internalValue?: ApigatewayDomainNameAccessAssociationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayDomainNameAccessAssociationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association awscc_apigateway_domain_name_access_association}
*/
export declare class ApigatewayDomainNameAccessAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_domain_name_access_association";
    /**
    * Generates CDKTN code for importing a ApigatewayDomainNameAccessAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayDomainNameAccessAssociation to import
    * @param importFromId The id of the existing ApigatewayDomainNameAccessAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayDomainNameAccessAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_domain_name_access_association awscc_apigateway_domain_name_access_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayDomainNameAccessAssociationConfig
    */
    constructor(scope: Construct, id: string, config: ApigatewayDomainNameAccessAssociationConfig);
    private _accessAssociationSource?;
    get accessAssociationSource(): string;
    set accessAssociationSource(value: string);
    get accessAssociationSourceInput(): string | undefined;
    private _accessAssociationSourceType?;
    get accessAssociationSourceType(): string;
    set accessAssociationSourceType(value: string);
    get accessAssociationSourceTypeInput(): string | undefined;
    get domainNameAccessAssociationArn(): string;
    private _domainNameArn?;
    get domainNameArn(): string;
    set domainNameArn(value: string);
    get domainNameArnInput(): string | undefined;
    get id(): string;
    private _tags;
    get tags(): ApigatewayDomainNameAccessAssociationTagsList;
    putTags(value: ApigatewayDomainNameAccessAssociationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApigatewayDomainNameAccessAssociationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
