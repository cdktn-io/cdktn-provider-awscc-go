/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodestarconnectionsRepositoryLinkConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the CodeStarConnection. The ARN is used as the connection reference when the connection is shared between AWS services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link#connection_arn CodestarconnectionsRepositoryLink#connection_arn}
    */
    readonly connectionArn: string;
    /**
    * The ARN of the KMS key that the customer can optionally specify to use to encrypt RepositoryLink properties. If not specified, a default key will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link#encryption_key_arn CodestarconnectionsRepositoryLink#encryption_key_arn}
    */
    readonly encryptionKeyArn?: string;
    /**
    * the ID of the entity that owns the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link#owner_id CodestarconnectionsRepositoryLink#owner_id}
    */
    readonly ownerId: string;
    /**
    * The repository for which the link is being created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link#repository_name CodestarconnectionsRepositoryLink#repository_name}
    */
    readonly repositoryName: string;
    /**
    * Specifies the tags applied to a RepositoryLink.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link#tags CodestarconnectionsRepositoryLink#tags}
    */
    readonly tags?: CodestarconnectionsRepositoryLinkTags[] | cdktn.IResolvable;
}
export interface CodestarconnectionsRepositoryLinkTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, , ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link#key CodestarconnectionsRepositoryLink#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, , ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link#value CodestarconnectionsRepositoryLink#value}
    */
    readonly value?: string;
}
export declare function codestarconnectionsRepositoryLinkTagsToTerraform(struct?: CodestarconnectionsRepositoryLinkTags | cdktn.IResolvable): any;
export declare function codestarconnectionsRepositoryLinkTagsToHclTerraform(struct?: CodestarconnectionsRepositoryLinkTags | cdktn.IResolvable): any;
export declare class CodestarconnectionsRepositoryLinkTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodestarconnectionsRepositoryLinkTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodestarconnectionsRepositoryLinkTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodestarconnectionsRepositoryLinkTagsList extends cdktn.ComplexList {
    internalValue?: CodestarconnectionsRepositoryLinkTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodestarconnectionsRepositoryLinkTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link awscc_codestarconnections_repository_link}
*/
export declare class CodestarconnectionsRepositoryLink extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codestarconnections_repository_link";
    /**
    * Generates CDKTN code for importing a CodestarconnectionsRepositoryLink resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodestarconnectionsRepositoryLink to import
    * @param importFromId The id of the existing CodestarconnectionsRepositoryLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodestarconnectionsRepositoryLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codestarconnections_repository_link awscc_codestarconnections_repository_link} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodestarconnectionsRepositoryLinkConfig
    */
    constructor(scope: Construct, id: string, config: CodestarconnectionsRepositoryLinkConfig);
    private _connectionArn?;
    get connectionArn(): string;
    set connectionArn(value: string);
    get connectionArnInput(): string | undefined;
    private _encryptionKeyArn?;
    get encryptionKeyArn(): string;
    set encryptionKeyArn(value: string);
    resetEncryptionKeyArn(): void;
    get encryptionKeyArnInput(): string | undefined;
    get id(): string;
    private _ownerId?;
    get ownerId(): string;
    set ownerId(value: string);
    get ownerIdInput(): string | undefined;
    get providerType(): string;
    get repositoryLinkArn(): string;
    get repositoryLinkId(): string;
    private _repositoryName?;
    get repositoryName(): string;
    set repositoryName(value: string);
    get repositoryNameInput(): string | undefined;
    private _tags;
    get tags(): CodestarconnectionsRepositoryLinkTagsList;
    putTags(value: CodestarconnectionsRepositoryLinkTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodestarconnectionsRepositoryLinkTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
