/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BcmpricingcalculatorWorkloadEstimateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The timestamp when the workload estimate will expire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate#expires_at BcmpricingcalculatorWorkloadEstimate#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The name of the workload estimate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate#name BcmpricingcalculatorWorkloadEstimate#name}
    */
    readonly name: string;
    /**
    * The type of pricing rates used for the estimate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate#rate_type BcmpricingcalculatorWorkloadEstimate#rate_type}
    */
    readonly rateType?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate#tags BcmpricingcalculatorWorkloadEstimate#tags}
    */
    readonly tags?: BcmpricingcalculatorWorkloadEstimateTags[] | cdktn.IResolvable;
}
export interface BcmpricingcalculatorWorkloadEstimateTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate#key BcmpricingcalculatorWorkloadEstimate#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate#value BcmpricingcalculatorWorkloadEstimate#value}
    */
    readonly value?: string;
}
export declare function bcmpricingcalculatorWorkloadEstimateTagsToTerraform(struct?: BcmpricingcalculatorWorkloadEstimateTags | cdktn.IResolvable): any;
export declare function bcmpricingcalculatorWorkloadEstimateTagsToHclTerraform(struct?: BcmpricingcalculatorWorkloadEstimateTags | cdktn.IResolvable): any;
export declare class BcmpricingcalculatorWorkloadEstimateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmpricingcalculatorWorkloadEstimateTags | cdktn.IResolvable | undefined;
    set internalValue(value: BcmpricingcalculatorWorkloadEstimateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BcmpricingcalculatorWorkloadEstimateTagsList extends cdktn.ComplexList {
    internalValue?: BcmpricingcalculatorWorkloadEstimateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmpricingcalculatorWorkloadEstimateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate awscc_bcmpricingcalculator_workload_estimate}
*/
export declare class BcmpricingcalculatorWorkloadEstimate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bcmpricingcalculator_workload_estimate";
    /**
    * Generates CDKTN code for importing a BcmpricingcalculatorWorkloadEstimate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BcmpricingcalculatorWorkloadEstimate to import
    * @param importFromId The id of the existing BcmpricingcalculatorWorkloadEstimate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BcmpricingcalculatorWorkloadEstimate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bcmpricingcalculator_workload_estimate awscc_bcmpricingcalculator_workload_estimate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BcmpricingcalculatorWorkloadEstimateConfig
    */
    constructor(scope: Construct, id: string, config: BcmpricingcalculatorWorkloadEstimateConfig);
    get arn(): string;
    get costCurrency(): string;
    get createdAt(): string;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    get failureMessage(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get rateTimestamp(): string;
    private _rateType?;
    get rateType(): string;
    set rateType(value: string);
    resetRateType(): void;
    get rateTypeInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): BcmpricingcalculatorWorkloadEstimateTagsList;
    putTags(value: BcmpricingcalculatorWorkloadEstimateTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BcmpricingcalculatorWorkloadEstimateTags[] | undefined;
    get totalCost(): number;
    get workloadEstimateId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
