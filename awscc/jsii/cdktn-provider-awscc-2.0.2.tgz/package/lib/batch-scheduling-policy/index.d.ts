/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BatchSchedulingPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Fair Share Policy for the Job Queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#fairshare_policy BatchSchedulingPolicy#fairshare_policy}
    */
    readonly fairsharePolicy?: BatchSchedulingPolicyFairsharePolicy;
    /**
    * Name of Scheduling Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#name BatchSchedulingPolicy#name}
    */
    readonly name?: string;
    /**
    * Quota Share Policy for the Job Queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#quota_share_policy BatchSchedulingPolicy#quota_share_policy}
    */
    readonly quotaSharePolicy?: BatchSchedulingPolicyQuotaSharePolicy;
    /**
    * A key-value pair to associate with a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#tags BatchSchedulingPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BatchSchedulingPolicyFairsharePolicyShareDistribution {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#share_identifier BatchSchedulingPolicy#share_identifier}
    */
    readonly shareIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#weight_factor BatchSchedulingPolicy#weight_factor}
    */
    readonly weightFactor?: number;
}
export declare function batchSchedulingPolicyFairsharePolicyShareDistributionToTerraform(struct?: BatchSchedulingPolicyFairsharePolicyShareDistribution | cdktn.IResolvable): any;
export declare function batchSchedulingPolicyFairsharePolicyShareDistributionToHclTerraform(struct?: BatchSchedulingPolicyFairsharePolicyShareDistribution | cdktn.IResolvable): any;
export declare class BatchSchedulingPolicyFairsharePolicyShareDistributionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchSchedulingPolicyFairsharePolicyShareDistribution | cdktn.IResolvable | undefined;
    set internalValue(value: BatchSchedulingPolicyFairsharePolicyShareDistribution | cdktn.IResolvable | undefined);
    private _shareIdentifier?;
    get shareIdentifier(): string;
    set shareIdentifier(value: string);
    resetShareIdentifier(): void;
    get shareIdentifierInput(): string | undefined;
    private _weightFactor?;
    get weightFactor(): number;
    set weightFactor(value: number);
    resetWeightFactor(): void;
    get weightFactorInput(): number | undefined;
}
export declare class BatchSchedulingPolicyFairsharePolicyShareDistributionList extends cdktn.ComplexList {
    internalValue?: BatchSchedulingPolicyFairsharePolicyShareDistribution[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchSchedulingPolicyFairsharePolicyShareDistributionOutputReference;
}
export interface BatchSchedulingPolicyFairsharePolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#compute_reservation BatchSchedulingPolicy#compute_reservation}
    */
    readonly computeReservation?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#share_decay_seconds BatchSchedulingPolicy#share_decay_seconds}
    */
    readonly shareDecaySeconds?: number;
    /**
    * List of Share Attributes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#share_distribution BatchSchedulingPolicy#share_distribution}
    */
    readonly shareDistribution?: BatchSchedulingPolicyFairsharePolicyShareDistribution[] | cdktn.IResolvable;
}
export declare function batchSchedulingPolicyFairsharePolicyToTerraform(struct?: BatchSchedulingPolicyFairsharePolicy | cdktn.IResolvable): any;
export declare function batchSchedulingPolicyFairsharePolicyToHclTerraform(struct?: BatchSchedulingPolicyFairsharePolicy | cdktn.IResolvable): any;
export declare class BatchSchedulingPolicyFairsharePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchSchedulingPolicyFairsharePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: BatchSchedulingPolicyFairsharePolicy | cdktn.IResolvable | undefined);
    private _computeReservation?;
    get computeReservation(): number;
    set computeReservation(value: number);
    resetComputeReservation(): void;
    get computeReservationInput(): number | undefined;
    private _shareDecaySeconds?;
    get shareDecaySeconds(): number;
    set shareDecaySeconds(value: number);
    resetShareDecaySeconds(): void;
    get shareDecaySecondsInput(): number | undefined;
    private _shareDistribution;
    get shareDistribution(): BatchSchedulingPolicyFairsharePolicyShareDistributionList;
    putShareDistribution(value: BatchSchedulingPolicyFairsharePolicyShareDistribution[] | cdktn.IResolvable): void;
    resetShareDistribution(): void;
    get shareDistributionInput(): cdktn.IResolvable | BatchSchedulingPolicyFairsharePolicyShareDistribution[] | undefined;
}
export interface BatchSchedulingPolicyQuotaSharePolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#idle_resource_assignment_strategy BatchSchedulingPolicy#idle_resource_assignment_strategy}
    */
    readonly idleResourceAssignmentStrategy?: string;
}
export declare function batchSchedulingPolicyQuotaSharePolicyToTerraform(struct?: BatchSchedulingPolicyQuotaSharePolicy | cdktn.IResolvable): any;
export declare function batchSchedulingPolicyQuotaSharePolicyToHclTerraform(struct?: BatchSchedulingPolicyQuotaSharePolicy | cdktn.IResolvable): any;
export declare class BatchSchedulingPolicyQuotaSharePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchSchedulingPolicyQuotaSharePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: BatchSchedulingPolicyQuotaSharePolicy | cdktn.IResolvable | undefined);
    private _idleResourceAssignmentStrategy?;
    get idleResourceAssignmentStrategy(): string;
    set idleResourceAssignmentStrategy(value: string);
    resetIdleResourceAssignmentStrategy(): void;
    get idleResourceAssignmentStrategyInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy awscc_batch_scheduling_policy}
*/
export declare class BatchSchedulingPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_batch_scheduling_policy";
    /**
    * Generates CDKTN code for importing a BatchSchedulingPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BatchSchedulingPolicy to import
    * @param importFromId The id of the existing BatchSchedulingPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BatchSchedulingPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/batch_scheduling_policy awscc_batch_scheduling_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BatchSchedulingPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: BatchSchedulingPolicyConfig);
    get arn(): string;
    private _fairsharePolicy;
    get fairsharePolicy(): BatchSchedulingPolicyFairsharePolicyOutputReference;
    putFairsharePolicy(value: BatchSchedulingPolicyFairsharePolicy): void;
    resetFairsharePolicy(): void;
    get fairsharePolicyInput(): cdktn.IResolvable | BatchSchedulingPolicyFairsharePolicy | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _quotaSharePolicy;
    get quotaSharePolicy(): BatchSchedulingPolicyQuotaSharePolicyOutputReference;
    putQuotaSharePolicy(value: BatchSchedulingPolicyQuotaSharePolicy): void;
    resetQuotaSharePolicy(): void;
    get quotaSharePolicyInput(): cdktn.IResolvable | BatchSchedulingPolicyQuotaSharePolicy | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
