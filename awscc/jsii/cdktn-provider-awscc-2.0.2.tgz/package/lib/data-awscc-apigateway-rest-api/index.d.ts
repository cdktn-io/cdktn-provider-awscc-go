/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayRestApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_rest_api#id DataAwsccApigatewayRestApi#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayRestApiBodyS3Location {
}
export declare function dataAwsccApigatewayRestApiBodyS3LocationToTerraform(struct?: DataAwsccApigatewayRestApiBodyS3Location): any;
export declare function dataAwsccApigatewayRestApiBodyS3LocationToHclTerraform(struct?: DataAwsccApigatewayRestApiBodyS3Location): any;
export declare class DataAwsccApigatewayRestApiBodyS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayRestApiBodyS3Location | undefined;
    set internalValue(value: DataAwsccApigatewayRestApiBodyS3Location | undefined);
    get bucket(): string;
    get eTag(): string;
    get key(): string;
    get version(): string;
}
export interface DataAwsccApigatewayRestApiEndpointConfiguration {
}
export declare function dataAwsccApigatewayRestApiEndpointConfigurationToTerraform(struct?: DataAwsccApigatewayRestApiEndpointConfiguration): any;
export declare function dataAwsccApigatewayRestApiEndpointConfigurationToHclTerraform(struct?: DataAwsccApigatewayRestApiEndpointConfiguration): any;
export declare class DataAwsccApigatewayRestApiEndpointConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayRestApiEndpointConfiguration | undefined;
    set internalValue(value: DataAwsccApigatewayRestApiEndpointConfiguration | undefined);
    get ipAddressType(): string;
    get types(): string[];
    get vpcEndpointIds(): string[];
}
export interface DataAwsccApigatewayRestApiTags {
}
export declare function dataAwsccApigatewayRestApiTagsToTerraform(struct?: DataAwsccApigatewayRestApiTags): any;
export declare function dataAwsccApigatewayRestApiTagsToHclTerraform(struct?: DataAwsccApigatewayRestApiTags): any;
export declare class DataAwsccApigatewayRestApiTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayRestApiTags | undefined;
    set internalValue(value: DataAwsccApigatewayRestApiTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayRestApiTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayRestApiTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_rest_api awscc_apigateway_rest_api}
*/
export declare class DataAwsccApigatewayRestApi extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_rest_api";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayRestApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayRestApi to import
    * @param importFromId The id of the existing DataAwsccApigatewayRestApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_rest_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayRestApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_rest_api awscc_apigateway_rest_api} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayRestApiConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayRestApiConfig);
    get apiKeySourceType(): string;
    get binaryMediaTypes(): string[];
    get body(): string;
    private _bodyS3Location;
    get bodyS3Location(): DataAwsccApigatewayRestApiBodyS3LocationOutputReference;
    get cloneFrom(): string;
    get description(): string;
    get disableExecuteApiEndpoint(): cdktn.IResolvable;
    get endpointAccessMode(): string;
    private _endpointConfiguration;
    get endpointConfiguration(): DataAwsccApigatewayRestApiEndpointConfigurationOutputReference;
    get failOnWarnings(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get minimumCompressionSize(): number;
    get mode(): string;
    get name(): string;
    get parameters(): string;
    get policy(): string;
    get restApiId(): string;
    get rootResourceId(): string;
    get securityPolicy(): string;
    private _tags;
    get tags(): DataAwsccApigatewayRestApiTagsList;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
