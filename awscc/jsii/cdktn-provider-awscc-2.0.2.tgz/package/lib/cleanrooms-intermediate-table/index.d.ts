/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsIntermediateTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#analysis_rules CleanroomsIntermediateTable#analysis_rules}
    */
    readonly analysisRules?: CleanroomsIntermediateTableAnalysisRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#description CleanroomsIntermediateTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#kms_key_arn CleanroomsIntermediateTable#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#membership_identifier CleanroomsIntermediateTable#membership_identifier}
    */
    readonly membershipIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#name CleanroomsIntermediateTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#population_analysis_configuration CleanroomsIntermediateTable#population_analysis_configuration}
    */
    readonly populationAnalysisConfiguration: CleanroomsIntermediateTablePopulationAnalysisConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#tags CleanroomsIntermediateTable#tags}
    */
    readonly tags?: CleanroomsIntermediateTableTags[] | cdktn.IResolvable;
}
export interface CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#minimum_identity_count CleanroomsIntermediateTable#minimum_identity_count}
    */
    readonly minimumIdentityCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#output_column_name CleanroomsIntermediateTable#output_column_name}
    */
    readonly outputColumnName?: string;
}
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsToTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds | cdktn.IResolvable | undefined);
    private _minimumIdentityCount?;
    get minimumIdentityCount(): number;
    set minimumIdentityCount(value: number);
    resetMinimumIdentityCount(): void;
    get minimumIdentityCountInput(): number | undefined;
    private _outputColumnName?;
    get outputColumnName(): string;
    set outputColumnName(value: string);
    resetOutputColumnName(): void;
    get outputColumnNameInput(): string | undefined;
}
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsList extends cdktn.ComplexList {
    internalValue?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsOutputReference;
}
export interface CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#allowed_aggregate_expression_type CleanroomsIntermediateTable#allowed_aggregate_expression_type}
    */
    readonly allowedAggregateExpressionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#identity_columns CleanroomsIntermediateTable#identity_columns}
    */
    readonly identityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#minimum_identity_count CleanroomsIntermediateTable#minimum_identity_count}
    */
    readonly minimumIdentityCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#output_column_thresholds CleanroomsIntermediateTable#output_column_thresholds}
    */
    readonly outputColumnThresholds?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#type CleanroomsIntermediateTable#type}
    */
    readonly type?: string;
}
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsToTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds | cdktn.IResolvable | undefined);
    private _allowedAggregateExpressionType?;
    get allowedAggregateExpressionType(): string;
    set allowedAggregateExpressionType(value: string);
    resetAllowedAggregateExpressionType(): void;
    get allowedAggregateExpressionTypeInput(): string | undefined;
    private _identityColumns?;
    get identityColumns(): string[];
    set identityColumns(value: string[]);
    resetIdentityColumns(): void;
    get identityColumnsInput(): string[] | undefined;
    private _minimumIdentityCount?;
    get minimumIdentityCount(): number;
    set minimumIdentityCount(value: number);
    resetMinimumIdentityCount(): void;
    get minimumIdentityCountInput(): number | undefined;
    private _outputColumnThresholds;
    get outputColumnThresholds(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsList;
    putOutputColumnThresholds(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds[] | cdktn.IResolvable): void;
    resetOutputColumnThresholds(): void;
    get outputColumnThresholdsInput(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsList extends cdktn.ComplexList {
    internalValue?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputReference;
}
export interface CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#allowed_column_comparison_columns CleanroomsIntermediateTable#allowed_column_comparison_columns}
    */
    readonly allowedColumnComparisonColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#allowed_literal_comparison_columns CleanroomsIntermediateTable#allowed_literal_comparison_columns}
    */
    readonly allowedLiteralComparisonColumns?: string[];
}
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControlsToTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControls | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControlsToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControls | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControls | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControls | cdktn.IResolvable | undefined);
    private _allowedColumnComparisonColumns?;
    get allowedColumnComparisonColumns(): string[];
    set allowedColumnComparisonColumns(value: string[]);
    resetAllowedColumnComparisonColumns(): void;
    get allowedColumnComparisonColumnsInput(): string[] | undefined;
    private _allowedLiteralComparisonColumns?;
    get allowedLiteralComparisonColumns(): string[];
    set allowedLiteralComparisonColumns(value: string[]);
    resetAllowedLiteralComparisonColumns(): void;
    get allowedLiteralComparisonColumnsInput(): string[] | undefined;
}
export interface CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#name CleanroomsIntermediateTable#name}
    */
    readonly name?: string;
}
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsToTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsList extends cdktn.ComplexList {
    internalValue?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsOutputReference;
}
export interface CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#columns CleanroomsIntermediateTable#columns}
    */
    readonly columns?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns[] | cdktn.IResolvable;
}
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyToTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | cdktn.IResolvable | undefined);
    private _columns;
    get columns(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsList;
    putColumns(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns[] | cdktn.IResolvable): void;
    resetColumns(): void;
    get columnsInput(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns[] | undefined;
}
export interface CleanroomsIntermediateTableAnalysisRulesPolicyV1Custom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#additional_analyses CleanroomsIntermediateTable#additional_analyses}
    */
    readonly additionalAnalyses?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#aggregation_thresholds CleanroomsIntermediateTable#aggregation_thresholds}
    */
    readonly aggregationThresholds?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#allowed_analyses CleanroomsIntermediateTable#allowed_analyses}
    */
    readonly allowedAnalyses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#allowed_analysis_providers CleanroomsIntermediateTable#allowed_analysis_providers}
    */
    readonly allowedAnalysisProviders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#allowed_result_receivers CleanroomsIntermediateTable#allowed_result_receivers}
    */
    readonly allowedResultReceivers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#comparison_controls CleanroomsIntermediateTable#comparison_controls}
    */
    readonly comparisonControls?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControls;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#differential_privacy CleanroomsIntermediateTable#differential_privacy}
    */
    readonly differentialPrivacy?: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#disallowed_output_columns CleanroomsIntermediateTable#disallowed_output_columns}
    */
    readonly disallowedOutputColumns?: string[];
}
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomToTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1Custom | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1CustomToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1Custom | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIntermediateTableAnalysisRulesPolicyV1Custom | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1Custom | cdktn.IResolvable | undefined);
    private _additionalAnalyses?;
    get additionalAnalyses(): string;
    set additionalAnalyses(value: string);
    resetAdditionalAnalyses(): void;
    get additionalAnalysesInput(): string | undefined;
    private _aggregationThresholds;
    get aggregationThresholds(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholdsList;
    putAggregationThresholds(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds[] | cdktn.IResolvable): void;
    resetAggregationThresholds(): void;
    get aggregationThresholdsInput(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomAggregationThresholds[] | undefined;
    private _allowedAnalyses?;
    get allowedAnalyses(): string[];
    set allowedAnalyses(value: string[]);
    resetAllowedAnalyses(): void;
    get allowedAnalysesInput(): string[] | undefined;
    private _allowedAnalysisProviders?;
    get allowedAnalysisProviders(): string[];
    set allowedAnalysisProviders(value: string[]);
    resetAllowedAnalysisProviders(): void;
    get allowedAnalysisProvidersInput(): string[] | undefined;
    private _allowedResultReceivers?;
    get allowedResultReceivers(): string[];
    set allowedResultReceivers(value: string[]);
    resetAllowedResultReceivers(): void;
    get allowedResultReceiversInput(): string[] | undefined;
    private _comparisonControls;
    get comparisonControls(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControlsOutputReference;
    putComparisonControls(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControls): void;
    resetComparisonControls(): void;
    get comparisonControlsInput(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomComparisonControls | undefined;
    private _differentialPrivacy;
    get differentialPrivacy(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacyOutputReference;
    putDifferentialPrivacy(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacy): void;
    resetDifferentialPrivacy(): void;
    get differentialPrivacyInput(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | undefined;
    private _disallowedOutputColumns?;
    get disallowedOutputColumns(): string[];
    set disallowedOutputColumns(value: string[]);
    resetDisallowedOutputColumns(): void;
    get disallowedOutputColumnsInput(): string[] | undefined;
}
export interface CleanroomsIntermediateTableAnalysisRulesPolicyV1 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#custom CleanroomsIntermediateTable#custom}
    */
    readonly custom?: CleanroomsIntermediateTableAnalysisRulesPolicyV1Custom;
}
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1ToTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1 | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyV1ToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicyV1 | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyV1OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIntermediateTableAnalysisRulesPolicyV1 | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1 | cdktn.IResolvable | undefined);
    private _custom;
    get custom(): CleanroomsIntermediateTableAnalysisRulesPolicyV1CustomOutputReference;
    putCustom(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1Custom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRulesPolicyV1Custom | undefined;
}
export interface CleanroomsIntermediateTableAnalysisRulesPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#v1 CleanroomsIntermediateTable#v1}
    */
    readonly v1?: CleanroomsIntermediateTableAnalysisRulesPolicyV1;
}
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyToTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicy | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesPolicyToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRulesPolicy | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIntermediateTableAnalysisRulesPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRulesPolicy | cdktn.IResolvable | undefined);
    private _v1;
    get v1(): CleanroomsIntermediateTableAnalysisRulesPolicyV1OutputReference;
    putV1(value: CleanroomsIntermediateTableAnalysisRulesPolicyV1): void;
    resetV1(): void;
    get v1Input(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRulesPolicyV1 | undefined;
}
export interface CleanroomsIntermediateTableAnalysisRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#policy CleanroomsIntermediateTable#policy}
    */
    readonly policy?: CleanroomsIntermediateTableAnalysisRulesPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#type CleanroomsIntermediateTable#type}
    */
    readonly type?: string;
}
export declare function cleanroomsIntermediateTableAnalysisRulesToTerraform(struct?: CleanroomsIntermediateTableAnalysisRules | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableAnalysisRulesToHclTerraform(struct?: CleanroomsIntermediateTableAnalysisRules | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableAnalysisRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsIntermediateTableAnalysisRules | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableAnalysisRules | cdktn.IResolvable | undefined);
    private _policy;
    get policy(): CleanroomsIntermediateTableAnalysisRulesPolicyOutputReference;
    putPolicy(value: CleanroomsIntermediateTableAnalysisRulesPolicy): void;
    resetPolicy(): void;
    get policyInput(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRulesPolicy | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CleanroomsIntermediateTableAnalysisRulesList extends cdktn.ComplexList {
    internalValue?: CleanroomsIntermediateTableAnalysisRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsIntermediateTableAnalysisRulesOutputReference;
}
export interface CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#analysis_template_arn CleanroomsIntermediateTable#analysis_template_arn}
    */
    readonly analysisTemplateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#query_string CleanroomsIntermediateTable#query_string}
    */
    readonly queryString?: string;
}
export declare function cleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParametersToTerraform(struct?: CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParameters | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParametersToHclTerraform(struct?: CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParameters | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParameters | cdktn.IResolvable | undefined);
    private _analysisTemplateArn?;
    get analysisTemplateArn(): string;
    set analysisTemplateArn(value: string);
    resetAnalysisTemplateArn(): void;
    get analysisTemplateArnInput(): string | undefined;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    resetQueryString(): void;
    get queryStringInput(): string | undefined;
}
export interface CleanroomsIntermediateTablePopulationAnalysisConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#sql_parameters CleanroomsIntermediateTable#sql_parameters}
    */
    readonly sqlParameters?: CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParameters;
}
export declare function cleanroomsIntermediateTablePopulationAnalysisConfigurationToTerraform(struct?: CleanroomsIntermediateTablePopulationAnalysisConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTablePopulationAnalysisConfigurationToHclTerraform(struct?: CleanroomsIntermediateTablePopulationAnalysisConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTablePopulationAnalysisConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIntermediateTablePopulationAnalysisConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTablePopulationAnalysisConfiguration | cdktn.IResolvable | undefined);
    private _sqlParameters;
    get sqlParameters(): CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParametersOutputReference;
    putSqlParameters(value: CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParameters): void;
    resetSqlParameters(): void;
    get sqlParametersInput(): cdktn.IResolvable | CleanroomsIntermediateTablePopulationAnalysisConfigurationSqlParameters | undefined;
}
export interface CleanroomsIntermediateTableTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#key CleanroomsIntermediateTable#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#value CleanroomsIntermediateTable#value}
    */
    readonly value?: string;
}
export declare function cleanroomsIntermediateTableTagsToTerraform(struct?: CleanroomsIntermediateTableTags | cdktn.IResolvable): any;
export declare function cleanroomsIntermediateTableTagsToHclTerraform(struct?: CleanroomsIntermediateTableTags | cdktn.IResolvable): any;
export declare class CleanroomsIntermediateTableTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsIntermediateTableTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIntermediateTableTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsIntermediateTableTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsIntermediateTableTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsIntermediateTableTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table awscc_cleanrooms_intermediate_table}
*/
export declare class CleanroomsIntermediateTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanrooms_intermediate_table";
    /**
    * Generates CDKTN code for importing a CleanroomsIntermediateTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsIntermediateTable to import
    * @param importFromId The id of the existing CleanroomsIntermediateTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsIntermediateTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_intermediate_table awscc_cleanrooms_intermediate_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsIntermediateTableConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsIntermediateTableConfig);
    private _analysisRules;
    get analysisRules(): CleanroomsIntermediateTableAnalysisRulesList;
    putAnalysisRules(value: CleanroomsIntermediateTableAnalysisRules[] | cdktn.IResolvable): void;
    resetAnalysisRules(): void;
    get analysisRulesInput(): cdktn.IResolvable | CleanroomsIntermediateTableAnalysisRules[] | undefined;
    get arn(): string;
    get collaborationArn(): string;
    get collaborationIdentifier(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get intermediateTableIdentifier(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    get membershipArn(): string;
    private _membershipIdentifier?;
    get membershipIdentifier(): string;
    set membershipIdentifier(value: string);
    get membershipIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _populationAnalysisConfiguration;
    get populationAnalysisConfiguration(): CleanroomsIntermediateTablePopulationAnalysisConfigurationOutputReference;
    putPopulationAnalysisConfiguration(value: CleanroomsIntermediateTablePopulationAnalysisConfiguration): void;
    get populationAnalysisConfigurationInput(): cdktn.IResolvable | CleanroomsIntermediateTablePopulationAnalysisConfiguration | undefined;
    get status(): string;
    private _tags;
    get tags(): CleanroomsIntermediateTableTagsList;
    putTags(value: CleanroomsIntermediateTableTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsIntermediateTableTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
