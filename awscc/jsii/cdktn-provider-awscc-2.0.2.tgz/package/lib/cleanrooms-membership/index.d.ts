/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsMembershipConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#collaboration_identifier CleanroomsMembership#collaboration_identifier}
    */
    readonly collaborationIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#default_job_result_configuration CleanroomsMembership#default_job_result_configuration}
    */
    readonly defaultJobResultConfiguration?: CleanroomsMembershipDefaultJobResultConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#default_result_configuration CleanroomsMembership#default_result_configuration}
    */
    readonly defaultResultConfiguration?: CleanroomsMembershipDefaultResultConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#is_metrics_enabled CleanroomsMembership#is_metrics_enabled}
    */
    readonly isMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#job_log_status CleanroomsMembership#job_log_status}
    */
    readonly jobLogStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#payment_configuration CleanroomsMembership#payment_configuration}
    */
    readonly paymentConfiguration?: CleanroomsMembershipPaymentConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#query_log_status CleanroomsMembership#query_log_status}
    */
    readonly queryLogStatus: string;
    /**
    * An arbitrary set of tags (key-value pairs) for this cleanrooms membership.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#tags CleanroomsMembership#tags}
    */
    readonly tags?: CleanroomsMembershipTags[] | cdktn.IResolvable;
}
export interface CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#bucket CleanroomsMembership#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#key_prefix CleanroomsMembership#key_prefix}
    */
    readonly keyPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#result_format CleanroomsMembership#result_format}
    */
    readonly resultFormat?: string;
}
export declare function cleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3ToTerraform(struct?: CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3 | cdktn.IResolvable): any;
export declare function cleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3ToHclTerraform(struct?: CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3 | cdktn.IResolvable): any;
export declare class CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3 | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3 | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _keyPrefix?;
    get keyPrefix(): string;
    set keyPrefix(value: string);
    resetKeyPrefix(): void;
    get keyPrefixInput(): string | undefined;
    private _resultFormat?;
    get resultFormat(): string;
    set resultFormat(value: string);
    resetResultFormat(): void;
    get resultFormatInput(): string | undefined;
}
export interface CleanroomsMembershipDefaultJobResultConfigurationOutputConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#s3 CleanroomsMembership#s3}
    */
    readonly s3?: CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3;
}
export declare function cleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationToTerraform(struct?: CleanroomsMembershipDefaultJobResultConfigurationOutputConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationToHclTerraform(struct?: CleanroomsMembershipDefaultJobResultConfigurationOutputConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipDefaultJobResultConfigurationOutputConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipDefaultJobResultConfigurationOutputConfiguration | cdktn.IResolvable | undefined);
    private _s3;
    get s3(): CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3OutputReference;
    putS3(value: CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationS3 | undefined;
}
export interface CleanroomsMembershipDefaultJobResultConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#output_configuration CleanroomsMembership#output_configuration}
    */
    readonly outputConfiguration?: CleanroomsMembershipDefaultJobResultConfigurationOutputConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#role_arn CleanroomsMembership#role_arn}
    */
    readonly roleArn?: string;
}
export declare function cleanroomsMembershipDefaultJobResultConfigurationToTerraform(struct?: CleanroomsMembershipDefaultJobResultConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsMembershipDefaultJobResultConfigurationToHclTerraform(struct?: CleanroomsMembershipDefaultJobResultConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsMembershipDefaultJobResultConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipDefaultJobResultConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipDefaultJobResultConfiguration | cdktn.IResolvable | undefined);
    private _outputConfiguration;
    get outputConfiguration(): CleanroomsMembershipDefaultJobResultConfigurationOutputConfigurationOutputReference;
    putOutputConfiguration(value: CleanroomsMembershipDefaultJobResultConfigurationOutputConfiguration): void;
    resetOutputConfiguration(): void;
    get outputConfigurationInput(): cdktn.IResolvable | CleanroomsMembershipDefaultJobResultConfigurationOutputConfiguration | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
}
export interface CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#bucket CleanroomsMembership#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#key_prefix CleanroomsMembership#key_prefix}
    */
    readonly keyPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#result_format CleanroomsMembership#result_format}
    */
    readonly resultFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#single_file_output CleanroomsMembership#single_file_output}
    */
    readonly singleFileOutput?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3ToTerraform(struct?: CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3 | cdktn.IResolvable): any;
export declare function cleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3ToHclTerraform(struct?: CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3 | cdktn.IResolvable): any;
export declare class CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3 | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3 | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _keyPrefix?;
    get keyPrefix(): string;
    set keyPrefix(value: string);
    resetKeyPrefix(): void;
    get keyPrefixInput(): string | undefined;
    private _resultFormat?;
    get resultFormat(): string;
    set resultFormat(value: string);
    resetResultFormat(): void;
    get resultFormatInput(): string | undefined;
    private _singleFileOutput?;
    get singleFileOutput(): boolean | cdktn.IResolvable;
    set singleFileOutput(value: boolean | cdktn.IResolvable);
    resetSingleFileOutput(): void;
    get singleFileOutputInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsMembershipDefaultResultConfigurationOutputConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#s3 CleanroomsMembership#s3}
    */
    readonly s3?: CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3;
}
export declare function cleanroomsMembershipDefaultResultConfigurationOutputConfigurationToTerraform(struct?: CleanroomsMembershipDefaultResultConfigurationOutputConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsMembershipDefaultResultConfigurationOutputConfigurationToHclTerraform(struct?: CleanroomsMembershipDefaultResultConfigurationOutputConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsMembershipDefaultResultConfigurationOutputConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipDefaultResultConfigurationOutputConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipDefaultResultConfigurationOutputConfiguration | cdktn.IResolvable | undefined);
    private _s3;
    get s3(): CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3OutputReference;
    putS3(value: CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | CleanroomsMembershipDefaultResultConfigurationOutputConfigurationS3 | undefined;
}
export interface CleanroomsMembershipDefaultResultConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#output_configuration CleanroomsMembership#output_configuration}
    */
    readonly outputConfiguration?: CleanroomsMembershipDefaultResultConfigurationOutputConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#role_arn CleanroomsMembership#role_arn}
    */
    readonly roleArn?: string;
}
export declare function cleanroomsMembershipDefaultResultConfigurationToTerraform(struct?: CleanroomsMembershipDefaultResultConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsMembershipDefaultResultConfigurationToHclTerraform(struct?: CleanroomsMembershipDefaultResultConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsMembershipDefaultResultConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipDefaultResultConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipDefaultResultConfiguration | cdktn.IResolvable | undefined);
    private _outputConfiguration;
    get outputConfiguration(): CleanroomsMembershipDefaultResultConfigurationOutputConfigurationOutputReference;
    putOutputConfiguration(value: CleanroomsMembershipDefaultResultConfigurationOutputConfiguration): void;
    resetOutputConfiguration(): void;
    get outputConfigurationInput(): cdktn.IResolvable | CleanroomsMembershipDefaultResultConfigurationOutputConfiguration | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
}
export interface CleanroomsMembershipPaymentConfigurationJobCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#is_responsible CleanroomsMembership#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsMembershipPaymentConfigurationJobComputeToTerraform(struct?: CleanroomsMembershipPaymentConfigurationJobCompute | cdktn.IResolvable): any;
export declare function cleanroomsMembershipPaymentConfigurationJobComputeToHclTerraform(struct?: CleanroomsMembershipPaymentConfigurationJobCompute | cdktn.IResolvable): any;
export declare class CleanroomsMembershipPaymentConfigurationJobComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipPaymentConfigurationJobCompute | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipPaymentConfigurationJobCompute | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsMembershipPaymentConfigurationMachineLearningModelInference {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#is_responsible CleanroomsMembership#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsMembershipPaymentConfigurationMachineLearningModelInferenceToTerraform(struct?: CleanroomsMembershipPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable): any;
export declare function cleanroomsMembershipPaymentConfigurationMachineLearningModelInferenceToHclTerraform(struct?: CleanroomsMembershipPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable): any;
export declare class CleanroomsMembershipPaymentConfigurationMachineLearningModelInferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsMembershipPaymentConfigurationMachineLearningModelTraining {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#is_responsible CleanroomsMembership#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsMembershipPaymentConfigurationMachineLearningModelTrainingToTerraform(struct?: CleanroomsMembershipPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable): any;
export declare function cleanroomsMembershipPaymentConfigurationMachineLearningModelTrainingToHclTerraform(struct?: CleanroomsMembershipPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable): any;
export declare class CleanroomsMembershipPaymentConfigurationMachineLearningModelTrainingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGeneration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#is_responsible CleanroomsMembership#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGenerationToTerraform(struct?: CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable): any;
export declare function cleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGenerationToHclTerraform(struct?: CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable): any;
export declare class CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGenerationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsMembershipPaymentConfigurationMachineLearning {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#model_inference CleanroomsMembership#model_inference}
    */
    readonly modelInference?: CleanroomsMembershipPaymentConfigurationMachineLearningModelInference;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#model_training CleanroomsMembership#model_training}
    */
    readonly modelTraining?: CleanroomsMembershipPaymentConfigurationMachineLearningModelTraining;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#synthetic_data_generation CleanroomsMembership#synthetic_data_generation}
    */
    readonly syntheticDataGeneration?: CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGeneration;
}
export declare function cleanroomsMembershipPaymentConfigurationMachineLearningToTerraform(struct?: CleanroomsMembershipPaymentConfigurationMachineLearning | cdktn.IResolvable): any;
export declare function cleanroomsMembershipPaymentConfigurationMachineLearningToHclTerraform(struct?: CleanroomsMembershipPaymentConfigurationMachineLearning | cdktn.IResolvable): any;
export declare class CleanroomsMembershipPaymentConfigurationMachineLearningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipPaymentConfigurationMachineLearning | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipPaymentConfigurationMachineLearning | cdktn.IResolvable | undefined);
    private _modelInference;
    get modelInference(): CleanroomsMembershipPaymentConfigurationMachineLearningModelInferenceOutputReference;
    putModelInference(value: CleanroomsMembershipPaymentConfigurationMachineLearningModelInference): void;
    resetModelInference(): void;
    get modelInferenceInput(): cdktn.IResolvable | CleanroomsMembershipPaymentConfigurationMachineLearningModelInference | undefined;
    private _modelTraining;
    get modelTraining(): CleanroomsMembershipPaymentConfigurationMachineLearningModelTrainingOutputReference;
    putModelTraining(value: CleanroomsMembershipPaymentConfigurationMachineLearningModelTraining): void;
    resetModelTraining(): void;
    get modelTrainingInput(): cdktn.IResolvable | CleanroomsMembershipPaymentConfigurationMachineLearningModelTraining | undefined;
    private _syntheticDataGeneration;
    get syntheticDataGeneration(): CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGenerationOutputReference;
    putSyntheticDataGeneration(value: CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGeneration): void;
    resetSyntheticDataGeneration(): void;
    get syntheticDataGenerationInput(): cdktn.IResolvable | CleanroomsMembershipPaymentConfigurationMachineLearningSyntheticDataGeneration | undefined;
}
export interface CleanroomsMembershipPaymentConfigurationQueryCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#is_responsible CleanroomsMembership#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsMembershipPaymentConfigurationQueryComputeToTerraform(struct?: CleanroomsMembershipPaymentConfigurationQueryCompute | cdktn.IResolvable): any;
export declare function cleanroomsMembershipPaymentConfigurationQueryComputeToHclTerraform(struct?: CleanroomsMembershipPaymentConfigurationQueryCompute | cdktn.IResolvable): any;
export declare class CleanroomsMembershipPaymentConfigurationQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipPaymentConfigurationQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipPaymentConfigurationQueryCompute | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsMembershipPaymentConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#job_compute CleanroomsMembership#job_compute}
    */
    readonly jobCompute?: CleanroomsMembershipPaymentConfigurationJobCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#machine_learning CleanroomsMembership#machine_learning}
    */
    readonly machineLearning?: CleanroomsMembershipPaymentConfigurationMachineLearning;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#query_compute CleanroomsMembership#query_compute}
    */
    readonly queryCompute?: CleanroomsMembershipPaymentConfigurationQueryCompute;
}
export declare function cleanroomsMembershipPaymentConfigurationToTerraform(struct?: CleanroomsMembershipPaymentConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsMembershipPaymentConfigurationToHclTerraform(struct?: CleanroomsMembershipPaymentConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsMembershipPaymentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsMembershipPaymentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipPaymentConfiguration | cdktn.IResolvable | undefined);
    private _jobCompute;
    get jobCompute(): CleanroomsMembershipPaymentConfigurationJobComputeOutputReference;
    putJobCompute(value: CleanroomsMembershipPaymentConfigurationJobCompute): void;
    resetJobCompute(): void;
    get jobComputeInput(): cdktn.IResolvable | CleanroomsMembershipPaymentConfigurationJobCompute | undefined;
    private _machineLearning;
    get machineLearning(): CleanroomsMembershipPaymentConfigurationMachineLearningOutputReference;
    putMachineLearning(value: CleanroomsMembershipPaymentConfigurationMachineLearning): void;
    resetMachineLearning(): void;
    get machineLearningInput(): cdktn.IResolvable | CleanroomsMembershipPaymentConfigurationMachineLearning | undefined;
    private _queryCompute;
    get queryCompute(): CleanroomsMembershipPaymentConfigurationQueryComputeOutputReference;
    putQueryCompute(value: CleanroomsMembershipPaymentConfigurationQueryCompute): void;
    resetQueryCompute(): void;
    get queryComputeInput(): cdktn.IResolvable | CleanroomsMembershipPaymentConfigurationQueryCompute | undefined;
}
export interface CleanroomsMembershipTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#key CleanroomsMembership#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#value CleanroomsMembership#value}
    */
    readonly value?: string;
}
export declare function cleanroomsMembershipTagsToTerraform(struct?: CleanroomsMembershipTags | cdktn.IResolvable): any;
export declare function cleanroomsMembershipTagsToHclTerraform(struct?: CleanroomsMembershipTags | cdktn.IResolvable): any;
export declare class CleanroomsMembershipTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsMembershipTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsMembershipTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsMembershipTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsMembershipTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsMembershipTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership awscc_cleanrooms_membership}
*/
export declare class CleanroomsMembership extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanrooms_membership";
    /**
    * Generates CDKTN code for importing a CleanroomsMembership resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsMembership to import
    * @param importFromId The id of the existing CleanroomsMembership that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsMembership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cleanrooms_membership awscc_cleanrooms_membership} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsMembershipConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsMembershipConfig);
    get arn(): string;
    get collaborationArn(): string;
    get collaborationCreatorAccountId(): string;
    private _collaborationIdentifier?;
    get collaborationIdentifier(): string;
    set collaborationIdentifier(value: string);
    get collaborationIdentifierInput(): string | undefined;
    private _defaultJobResultConfiguration;
    get defaultJobResultConfiguration(): CleanroomsMembershipDefaultJobResultConfigurationOutputReference;
    putDefaultJobResultConfiguration(value: CleanroomsMembershipDefaultJobResultConfiguration): void;
    resetDefaultJobResultConfiguration(): void;
    get defaultJobResultConfigurationInput(): cdktn.IResolvable | CleanroomsMembershipDefaultJobResultConfiguration | undefined;
    private _defaultResultConfiguration;
    get defaultResultConfiguration(): CleanroomsMembershipDefaultResultConfigurationOutputReference;
    putDefaultResultConfiguration(value: CleanroomsMembershipDefaultResultConfiguration): void;
    resetDefaultResultConfiguration(): void;
    get defaultResultConfigurationInput(): cdktn.IResolvable | CleanroomsMembershipDefaultResultConfiguration | undefined;
    get id(): string;
    private _isMetricsEnabled?;
    get isMetricsEnabled(): boolean | cdktn.IResolvable;
    set isMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetIsMetricsEnabled(): void;
    get isMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _jobLogStatus?;
    get jobLogStatus(): string;
    set jobLogStatus(value: string);
    resetJobLogStatus(): void;
    get jobLogStatusInput(): string | undefined;
    get membershipIdentifier(): string;
    private _paymentConfiguration;
    get paymentConfiguration(): CleanroomsMembershipPaymentConfigurationOutputReference;
    putPaymentConfiguration(value: CleanroomsMembershipPaymentConfiguration): void;
    resetPaymentConfiguration(): void;
    get paymentConfigurationInput(): cdktn.IResolvable | CleanroomsMembershipPaymentConfiguration | undefined;
    private _queryLogStatus?;
    get queryLogStatus(): string;
    set queryLogStatus(value: string);
    get queryLogStatusInput(): string | undefined;
    private _tags;
    get tags(): CleanroomsMembershipTagsList;
    putTags(value: CleanroomsMembershipTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsMembershipTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
