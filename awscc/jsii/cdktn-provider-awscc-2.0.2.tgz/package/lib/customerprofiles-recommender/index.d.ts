/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesRecommenderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the recommender.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#description CustomerprofilesRecommender#description}
    */
    readonly description?: string;
    /**
    * The name of the domain for which the recommender will be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#domain_name CustomerprofilesRecommender#domain_name}
    */
    readonly domainName: string;
    /**
    * Configuration for the recommender
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#recommender_config CustomerprofilesRecommender#recommender_config}
    */
    readonly recommenderConfig?: CustomerprofilesRecommenderRecommenderConfig;
    /**
    * The name of the recommender
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#recommender_name CustomerprofilesRecommender#recommender_name}
    */
    readonly recommenderName: string;
    /**
    * The name of the recommender recipe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#recommender_recipe_name CustomerprofilesRecommender#recommender_recipe_name}
    */
    readonly recommenderRecipeName: string;
    /**
    * The tags used to organize, track, or control access for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#tags CustomerprofilesRecommender#tags}
    */
    readonly tags?: CustomerprofilesRecommenderTags[] | cdktn.IResolvable;
}
export interface CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStruct {
}
export declare function customerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStructToTerraform(struct?: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStruct): any;
export declare function customerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStructToHclTerraform(struct?: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStruct): any;
export declare class CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStruct | undefined;
    set internalValue(value: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStruct | undefined);
    get eventType(): string;
    get eventValueThreshold(): number;
}
export declare class CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStructOutputReference;
}
export interface CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfig {
}
export declare function customerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigToTerraform(struct?: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfig): any;
export declare function customerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigToHclTerraform(struct?: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfig): any;
export declare class CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfig | undefined;
    set internalValue(value: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfig | undefined);
    private _eventParametersList;
    get eventParametersList(): CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigEventParametersListStructList;
}
export interface CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfig {
}
export declare function customerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigToTerraform(struct?: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfig): any;
export declare function customerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigToHclTerraform(struct?: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfig): any;
export declare class CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfig | undefined;
    set internalValue(value: CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfig | undefined);
    private _eventsConfig;
    get eventsConfig(): CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigEventsConfigOutputReference;
}
export interface CustomerprofilesRecommenderLatestRecommenderUpdate {
}
export declare function customerprofilesRecommenderLatestRecommenderUpdateToTerraform(struct?: CustomerprofilesRecommenderLatestRecommenderUpdate): any;
export declare function customerprofilesRecommenderLatestRecommenderUpdateToHclTerraform(struct?: CustomerprofilesRecommenderLatestRecommenderUpdate): any;
export declare class CustomerprofilesRecommenderLatestRecommenderUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesRecommenderLatestRecommenderUpdate | undefined;
    set internalValue(value: CustomerprofilesRecommenderLatestRecommenderUpdate | undefined);
    get creationDateTime(): string;
    get failureReason(): string;
    get lastUpdatedDateTime(): string;
    private _recommenderConfig;
    get recommenderConfig(): CustomerprofilesRecommenderLatestRecommenderUpdateRecommenderConfigOutputReference;
    get status(): string;
}
export interface CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct {
    /**
    * The type of event
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#event_type CustomerprofilesRecommender#event_type}
    */
    readonly eventType?: string;
    /**
    * The threshold of the event type. Only events with a value greater or equal to this threshold will be considered for solution creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#event_value_threshold CustomerprofilesRecommender#event_value_threshold}
    */
    readonly eventValueThreshold?: number;
}
export declare function customerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStructToTerraform(struct?: CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct | cdktn.IResolvable): any;
export declare function customerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStructToHclTerraform(struct?: CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct | cdktn.IResolvable): any;
export declare class CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct | cdktn.IResolvable | undefined);
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    resetEventType(): void;
    get eventTypeInput(): string | undefined;
    private _eventValueThreshold?;
    get eventValueThreshold(): number;
    set eventValueThreshold(value: number);
    resetEventValueThreshold(): void;
    get eventValueThresholdInput(): number | undefined;
}
export declare class CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStructList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStructOutputReference;
}
export interface CustomerprofilesRecommenderRecommenderConfigEventsConfig {
    /**
    * List of event parameters with their value thresholds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#event_parameters_list CustomerprofilesRecommender#event_parameters_list}
    */
    readonly eventParametersList?: CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct[] | cdktn.IResolvable;
}
export declare function customerprofilesRecommenderRecommenderConfigEventsConfigToTerraform(struct?: CustomerprofilesRecommenderRecommenderConfigEventsConfig | cdktn.IResolvable): any;
export declare function customerprofilesRecommenderRecommenderConfigEventsConfigToHclTerraform(struct?: CustomerprofilesRecommenderRecommenderConfigEventsConfig | cdktn.IResolvable): any;
export declare class CustomerprofilesRecommenderRecommenderConfigEventsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesRecommenderRecommenderConfigEventsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesRecommenderRecommenderConfigEventsConfig | cdktn.IResolvable | undefined);
    private _eventParametersList;
    get eventParametersList(): CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStructList;
    putEventParametersList(value: CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct[] | cdktn.IResolvable): void;
    resetEventParametersList(): void;
    get eventParametersListInput(): cdktn.IResolvable | CustomerprofilesRecommenderRecommenderConfigEventsConfigEventParametersListStruct[] | undefined;
}
export interface CustomerprofilesRecommenderRecommenderConfig {
    /**
    * Configuration for events used in the recommender
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#events_config CustomerprofilesRecommender#events_config}
    */
    readonly eventsConfig?: CustomerprofilesRecommenderRecommenderConfigEventsConfig;
}
export declare function customerprofilesRecommenderRecommenderConfigToTerraform(struct?: CustomerprofilesRecommenderRecommenderConfig | cdktn.IResolvable): any;
export declare function customerprofilesRecommenderRecommenderConfigToHclTerraform(struct?: CustomerprofilesRecommenderRecommenderConfig | cdktn.IResolvable): any;
export declare class CustomerprofilesRecommenderRecommenderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesRecommenderRecommenderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesRecommenderRecommenderConfig | cdktn.IResolvable | undefined);
    private _eventsConfig;
    get eventsConfig(): CustomerprofilesRecommenderRecommenderConfigEventsConfigOutputReference;
    putEventsConfig(value: CustomerprofilesRecommenderRecommenderConfigEventsConfig): void;
    resetEventsConfig(): void;
    get eventsConfigInput(): cdktn.IResolvable | CustomerprofilesRecommenderRecommenderConfigEventsConfig | undefined;
}
export interface CustomerprofilesRecommenderTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#key CustomerprofilesRecommender#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#value CustomerprofilesRecommender#value}
    */
    readonly value?: string;
}
export declare function customerprofilesRecommenderTagsToTerraform(struct?: CustomerprofilesRecommenderTags | cdktn.IResolvable): any;
export declare function customerprofilesRecommenderTagsToHclTerraform(struct?: CustomerprofilesRecommenderTags | cdktn.IResolvable): any;
export declare class CustomerprofilesRecommenderTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesRecommenderTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesRecommenderTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesRecommenderTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesRecommenderTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesRecommenderTagsOutputReference;
}
export interface CustomerprofilesRecommenderTrainingMetricsMetrics {
}
export declare function customerprofilesRecommenderTrainingMetricsMetricsToTerraform(struct?: CustomerprofilesRecommenderTrainingMetricsMetrics): any;
export declare function customerprofilesRecommenderTrainingMetricsMetricsToHclTerraform(struct?: CustomerprofilesRecommenderTrainingMetricsMetrics): any;
export declare class CustomerprofilesRecommenderTrainingMetricsMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesRecommenderTrainingMetricsMetrics | undefined;
    set internalValue(value: CustomerprofilesRecommenderTrainingMetricsMetrics | undefined);
    get coverage(): number;
    get freshness(): number;
    get hit(): number;
    get popularity(): number;
    get recall(): number;
    get similarity(): number;
}
export interface CustomerprofilesRecommenderTrainingMetrics {
}
export declare function customerprofilesRecommenderTrainingMetricsToTerraform(struct?: CustomerprofilesRecommenderTrainingMetrics): any;
export declare function customerprofilesRecommenderTrainingMetricsToHclTerraform(struct?: CustomerprofilesRecommenderTrainingMetrics): any;
export declare class CustomerprofilesRecommenderTrainingMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesRecommenderTrainingMetrics | undefined;
    set internalValue(value: CustomerprofilesRecommenderTrainingMetrics | undefined);
    private _metrics;
    get metrics(): CustomerprofilesRecommenderTrainingMetricsMetricsOutputReference;
    get time(): string;
}
export declare class CustomerprofilesRecommenderTrainingMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesRecommenderTrainingMetricsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender awscc_customerprofiles_recommender}
*/
export declare class CustomerprofilesRecommender extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_recommender";
    /**
    * Generates CDKTN code for importing a CustomerprofilesRecommender resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesRecommender to import
    * @param importFromId The id of the existing CustomerprofilesRecommender that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesRecommender to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_recommender awscc_customerprofiles_recommender} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesRecommenderConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesRecommenderConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get failureReason(): string;
    get id(): string;
    get lastUpdatedAt(): string;
    private _latestRecommenderUpdate;
    get latestRecommenderUpdate(): CustomerprofilesRecommenderLatestRecommenderUpdateOutputReference;
    get recommenderArn(): string;
    private _recommenderConfig;
    get recommenderConfig(): CustomerprofilesRecommenderRecommenderConfigOutputReference;
    putRecommenderConfig(value: CustomerprofilesRecommenderRecommenderConfig): void;
    resetRecommenderConfig(): void;
    get recommenderConfigInput(): cdktn.IResolvable | CustomerprofilesRecommenderRecommenderConfig | undefined;
    private _recommenderName?;
    get recommenderName(): string;
    set recommenderName(value: string);
    get recommenderNameInput(): string | undefined;
    private _recommenderRecipeName?;
    get recommenderRecipeName(): string;
    set recommenderRecipeName(value: string);
    get recommenderRecipeNameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): CustomerprofilesRecommenderTagsList;
    putTags(value: CustomerprofilesRecommenderTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesRecommenderTags[] | undefined;
    private _trainingMetrics;
    get trainingMetrics(): CustomerprofilesRecommenderTrainingMetricsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
