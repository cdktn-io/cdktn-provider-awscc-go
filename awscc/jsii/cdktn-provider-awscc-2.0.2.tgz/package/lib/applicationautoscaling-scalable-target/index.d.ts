/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationautoscalingScalableTargetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The maximum value that you plan to scale out to. When a scaling policy is in effect, Application Auto Scaling can scale out (expand) as needed to the maximum capacity limit in response to changing demand.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#max_capacity ApplicationautoscalingScalableTarget#max_capacity}
    */
    readonly maxCapacity: number;
    /**
    * The minimum value that you plan to scale in to. When a scaling policy is in effect, Application Auto Scaling can scale in (contract) as needed to the minimum capacity limit in response to changing demand.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#min_capacity ApplicationautoscalingScalableTarget#min_capacity}
    */
    readonly minCapacity: number;
    /**
    * The identifier of the resource associated with the scalable target. This string consists of the resource type and unique identifier.
    *   +  ECS service - The resource type is ``service`` and the unique identifier is the cluster name and service name. Example: ``service/my-cluster/my-service``.
    *   +  Spot Fleet - The resource type is ``spot-fleet-request`` and the unique identifier is the Spot Fleet request ID. Example: ``spot-fleet-request/sfr-73fbd2ce-aa30-494c-8788-1cee4EXAMPLE``.
    *   +  EMR cluster - The resource type is ``instancegroup`` and the unique identifier is the cluster ID and instance group ID. Example: ``instancegroup/j-2EEZNYKUA1NTV/ig-1791Y4E1L8YI0``.
    *   +  AppStream 2.0 fleet - The resource type is ``fleet`` and the unique identifier is the fleet name. Example: ``fleet/sample-fleet``.
    *   +  DynamoDB table - The resource type is ``table`` and the unique identifier is the table name. Example: ``table/my-table``.
    *   +  DynamoDB global secondary index - The resource type is ``index`` and the unique identifier is the index name. Example: ``table/my-table/index/my-table-index``.
    *   +  Aurora DB cluster - The resource type is ``cluster`` and the unique identifier is the cluster name. Example: ``cluster:my-db-cluster``.
    *   +  SageMaker endpoint variant - The resource type is ``variant`` and the unique identifier is the resource ID. Example: ``endpoint/my-end-point/variant/KMeansClustering``.
    *   +  Custom resources are not supported with a resource type. This parameter must specify the ``OutputValue`` from the CloudFormation template stack used to access the resources. The unique identifier is defined by the service provider. More information is available in our [GitHub repository](https://docs.aws.amazon.com/https://github.com/aws/aws-auto-scaling-custom-resource).
    *   +  Amazon Comprehend document classification endpoint - The resource type and unique identifier are specified using the endpoint ARN. Example: ``arn:aws:comprehend:us-west-2:123456789012:document-classifier-endpoint/EXAMPLE``.
    *   +  Amazon Comprehend entity recognizer endpoint - The resource type and unique identifier are specified using the endpoint ARN. Example: ``arn:aws:comprehend:us-west-2:123456789012:entity-recognizer-endpoint/EXAMPLE``.
    *   +  Lambda provisioned concurrency - The resource type is ``function`` and the unique identifier is the function name with a function version or alias name suffix that is not ``$LATEST``. Example: ``function:my-function:prod`` or ``function:my-function:1``.
    *   +  Amazon Keyspaces table - The resource type is ``table`` and the unique identifier is the table name. Example: ``keyspace/mykeyspace/table/mytable``.
    *   +  Amazon MSK cluster - The resource type and unique identifier are specified using the cluster ARN. Example: ``arn:aws:kafka:us-east-1:123456789012:cluster/demo-cluster-1/6357e0b2-0e6a-4b86-a0b4-70df934c2e31-5``.
    *   +  Amazon ElastiCache replication group - The resource type is ``replication-group`` and the unique identifier is the replication group name. Example: ``replication-group/mycluster``.
    *   +  Amazon ElastiCache cache cluster - The resource type is ``cache-cluster`` and the unique identifier is the cache cluster name. Example: ``cache-cluster/mycluster``.
    *   +  Neptune cluster - The resource type is ``cluster`` and the unique identifier is the cluster name. Example: ``cluster:mycluster``.
    *   +  SageMaker serverless endpoint - The resource type is ``variant`` and the unique identifier is the resource ID. Example: ``endpoint/my-end-point/variant/KMeansClustering``.
    *   +  SageMaker inference component - The resource type is ``inference-component`` and the unique identifier is the resource ID. Example: ``inference-component/my-inference-component``.
    *   +  Pool of WorkSpaces - The resource type is ``workspacespool`` and the unique identifier is the pool ID. Example: ``workspacespool/wspool-123456``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#resource_id ApplicationautoscalingScalableTarget#resource_id}
    */
    readonly resourceId: string;
    /**
    * Specify the Amazon Resource Name (ARN) of an Identity and Access Management (IAM) role that allows Application Auto Scaling to modify the scalable target on your behalf. This can be either an IAM service role that Application Auto Scaling can assume to make calls to other AWS resources on your behalf, or a service-linked role for the specified service. For more information, see [How Application Auto Scaling works with IAM](https://docs.aws.amazon.com/autoscaling/application/userguide/security_iam_service-with-iam.html) in the *Application Auto Scaling User Guide*.
    *  To automatically create a service-linked role (recommended), specify the full ARN of the service-linked role in your stack template. To find the exact ARN of the service-linked role for your AWS or custom resource, see the [Service-linked roles](https://docs.aws.amazon.com/autoscaling/application/userguide/application-auto-scaling-service-linked-roles.html) topic in the *Application Auto Scaling User Guide*. Look for the ARN in the table at the bottom of the page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#role_arn ApplicationautoscalingScalableTarget#role_arn}
    */
    readonly roleArn?: string;
    /**
    * The scalable dimension associated with the scalable target. This string consists of the service namespace, resource type, and scaling property.
    *   +  ``ecs:service:DesiredCount`` - The task count of an ECS service.
    *   +  ``elasticmapreduce:instancegroup:InstanceCount`` - The instance count of an EMR Instance Group.
    *   +  ``ec2:spot-fleet-request:TargetCapacity`` - The target capacity of a Spot Fleet.
    *   +  ``appstream:fleet:DesiredCapacity`` - The capacity of an AppStream 2.0 fleet.
    *   +  ``dynamodb:table:ReadCapacityUnits`` - The provisioned read capacity for a DynamoDB table.
    *   +  ``dynamodb:table:WriteCapacityUnits`` - The provisioned write capacity for a DynamoDB table.
    *   +  ``dynamodb:index:ReadCapacityUnits`` - The provisioned read capacity for a DynamoDB global secondary index.
    *   +  ``dynamodb:index:WriteCapacityUnits`` - The provisioned write capacity for a DynamoDB global secondary index.
    *   +  ``rds:cluster:ReadReplicaCount`` - The count of Aurora Replicas in an Aurora DB cluster. Available for Aurora MySQL-compatible edition and Aurora PostgreSQL-compatible edition.
    *   +  ``sagemaker:variant:DesiredInstanceCount`` - The number of EC2 instances for a SageMaker model endpoint variant.
    *   +  ``custom-resource:ResourceType:Property`` - The scalable dimension for a custom resource provided by your own application or service.
    *   +  ``comprehend:document-classifier-endpoint:DesiredInferenceUnits`` - The number of inference units for an Amazon Comprehend document classification endpoint.
    *   +  ``comprehend:entity-recognizer-endpoint:DesiredInferenceUnits`` - The number of inference units for an Amazon Comprehend entity recognizer endpoint.
    *   +  ``lambda:function:ProvisionedConcurrency`` - The provisioned concurrency for a Lambda function.
    *   +  ``cassandra:table:ReadCapacityUnits`` - The provisioned read capacity for an Amazon Keyspaces table.
    *   +  ``cassandra:table:WriteCapacityUnits`` - The provisioned write capacity for an Amazon Keyspaces table.
    *   +  ``kafka:broker-storage:VolumeSize`` - The provisioned volume size (in GiB) for brokers in an Amazon MSK cluster.
    *   +  ``elasticache:cache-cluster:Nodes`` - The number of nodes for an Amazon ElastiCache cache cluster.
    *   +  ``elasticache:replication-group:NodeGroups`` - The number of node groups for an Amazon ElastiCache replication group.
    *   +  ``elasticache:replication-group:Replicas`` - The number of replicas per node group for an Amazon ElastiCache replication group.
    *   +  ``neptune:cluster:ReadReplicaCount`` - The count of read replicas in an Amazon Neptune DB cluster.
    *   +  ``sagemaker:variant:DesiredProvisionedConcurrency`` - The provisioned concurrency for a SageMaker serverless endpoint.
    *   +  ``sagemaker:inference-component:DesiredCopyCount`` - The number of copies across an endpoint for a SageMaker inference component.
    *   +  ``workspaces:workspacespool:DesiredUserSessions`` - The number of user sessions for the WorkSpaces in the pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#scalable_dimension ApplicationautoscalingScalableTarget#scalable_dimension}
    */
    readonly scalableDimension: string;
    /**
    * The scheduled actions for the scalable target. Duplicates aren't allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#scheduled_actions ApplicationautoscalingScalableTarget#scheduled_actions}
    */
    readonly scheduledActions?: ApplicationautoscalingScalableTargetScheduledActions[] | cdktn.IResolvable;
    /**
    * The namespace of the AWS service that provides the resource, or a ``custom-resource``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#service_namespace ApplicationautoscalingScalableTarget#service_namespace}
    */
    readonly serviceNamespace: string;
    /**
    * An embedded object that contains attributes and attribute values that are used to suspend and resume automatic scaling. Setting the value of an attribute to ``true`` suspends the specified scaling activities. Setting it to ``false`` (default) resumes the specified scaling activities.
    *   *Suspension Outcomes*
    *   +  For ``DynamicScalingInSuspended``, while a suspension is in effect, all scale-in activities that are triggered by a scaling policy are suspended.
    *   +  For ``DynamicScalingOutSuspended``, while a suspension is in effect, all scale-out activities that are triggered by a scaling policy are suspended.
    *   +  For ``ScheduledScalingSuspended``, while a suspension is in effect, all scaling activities that involve scheduled actions are suspended.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#suspended_state ApplicationautoscalingScalableTarget#suspended_state}
    */
    readonly suspendedState?: ApplicationautoscalingScalableTargetSuspendedState;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#tags ApplicationautoscalingScalableTarget#tags}
    */
    readonly tags?: ApplicationautoscalingScalableTargetTags[] | cdktn.IResolvable;
}
export interface ApplicationautoscalingScalableTargetScheduledActionsScalableTargetAction {
    /**
    * The maximum capacity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#max_capacity ApplicationautoscalingScalableTarget#max_capacity}
    */
    readonly maxCapacity?: number;
    /**
    * The minimum capacity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#min_capacity ApplicationautoscalingScalableTarget#min_capacity}
    */
    readonly minCapacity?: number;
}
export declare function applicationautoscalingScalableTargetScheduledActionsScalableTargetActionToTerraform(struct?: ApplicationautoscalingScalableTargetScheduledActionsScalableTargetAction | cdktn.IResolvable): any;
export declare function applicationautoscalingScalableTargetScheduledActionsScalableTargetActionToHclTerraform(struct?: ApplicationautoscalingScalableTargetScheduledActionsScalableTargetAction | cdktn.IResolvable): any;
export declare class ApplicationautoscalingScalableTargetScheduledActionsScalableTargetActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationautoscalingScalableTargetScheduledActionsScalableTargetAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationautoscalingScalableTargetScheduledActionsScalableTargetAction | cdktn.IResolvable | undefined);
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    resetMaxCapacity(): void;
    get maxCapacityInput(): number | undefined;
    private _minCapacity?;
    get minCapacity(): number;
    set minCapacity(value: number);
    resetMinCapacity(): void;
    get minCapacityInput(): number | undefined;
}
export interface ApplicationautoscalingScalableTargetScheduledActions {
    /**
    * The date and time that the action is scheduled to end, in UTC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#end_time ApplicationautoscalingScalableTarget#end_time}
    */
    readonly endTime?: string;
    /**
    * The new minimum and maximum capacity. You can set both values or just one. At the scheduled time, if the current capacity is below the minimum capacity, Application Auto Scaling scales out to the minimum capacity. If the current capacity is above the maximum capacity, Application Auto Scaling scales in to the maximum capacity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#scalable_target_action ApplicationautoscalingScalableTarget#scalable_target_action}
    */
    readonly scalableTargetAction?: ApplicationautoscalingScalableTargetScheduledActionsScalableTargetAction;
    /**
    * The schedule for this action. The following formats are supported:
    *   +  At expressions - "``at(yyyy-mm-ddThh:mm:ss)``"
    *   +  Rate expressions - "``rate(valueunit)``"
    *   +  Cron expressions - "``cron(fields)``"
    *
    *  At expressions are useful for one-time schedules. Cron expressions are useful for scheduled actions that run periodically at a specified date and time, and rate expressions are useful for scheduled actions that run at a regular interval.
    *  At and cron expressions use Universal Coordinated Time (UTC) by default.
    *  The cron format consists of six fields separated by white spaces: [Minutes] [Hours] [Day_of_Month] [Month] [Day_of_Week] [Year].
    *  For rate expressions, *value* is a positive integer and *unit* is ``minute`` | ``minutes`` | ``hour`` | ``hours`` | ``day`` | ``days``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#schedule ApplicationautoscalingScalableTarget#schedule}
    */
    readonly schedule?: string;
    /**
    * The name of the scheduled action. This name must be unique among all other scheduled actions on the specified scalable target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#scheduled_action_name ApplicationautoscalingScalableTarget#scheduled_action_name}
    */
    readonly scheduledActionName?: string;
    /**
    * The date and time that the action is scheduled to begin, in UTC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#start_time ApplicationautoscalingScalableTarget#start_time}
    */
    readonly startTime?: string;
    /**
    * The time zone used when referring to the date and time of a scheduled action, when the scheduled action uses an at or cron expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#timezone ApplicationautoscalingScalableTarget#timezone}
    */
    readonly timezone?: string;
}
export declare function applicationautoscalingScalableTargetScheduledActionsToTerraform(struct?: ApplicationautoscalingScalableTargetScheduledActions | cdktn.IResolvable): any;
export declare function applicationautoscalingScalableTargetScheduledActionsToHclTerraform(struct?: ApplicationautoscalingScalableTargetScheduledActions | cdktn.IResolvable): any;
export declare class ApplicationautoscalingScalableTargetScheduledActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationautoscalingScalableTargetScheduledActions | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationautoscalingScalableTargetScheduledActions | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _scalableTargetAction;
    get scalableTargetAction(): ApplicationautoscalingScalableTargetScheduledActionsScalableTargetActionOutputReference;
    putScalableTargetAction(value: ApplicationautoscalingScalableTargetScheduledActionsScalableTargetAction): void;
    resetScalableTargetAction(): void;
    get scalableTargetActionInput(): cdktn.IResolvable | ApplicationautoscalingScalableTargetScheduledActionsScalableTargetAction | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    private _scheduledActionName?;
    get scheduledActionName(): string;
    set scheduledActionName(value: string);
    resetScheduledActionName(): void;
    get scheduledActionNameInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
export declare class ApplicationautoscalingScalableTargetScheduledActionsList extends cdktn.ComplexList {
    internalValue?: ApplicationautoscalingScalableTargetScheduledActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationautoscalingScalableTargetScheduledActionsOutputReference;
}
export interface ApplicationautoscalingScalableTargetSuspendedState {
    /**
    * Whether scale in by a target tracking scaling policy or a step scaling policy is suspended. Set the value to ``true`` if you don't want Application Auto Scaling to remove capacity when a scaling policy is triggered. The default is ``false``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#dynamic_scaling_in_suspended ApplicationautoscalingScalableTarget#dynamic_scaling_in_suspended}
    */
    readonly dynamicScalingInSuspended?: boolean | cdktn.IResolvable;
    /**
    * Whether scale out by a target tracking scaling policy or a step scaling policy is suspended. Set the value to ``true`` if you don't want Application Auto Scaling to add capacity when a scaling policy is triggered. The default is ``false``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#dynamic_scaling_out_suspended ApplicationautoscalingScalableTarget#dynamic_scaling_out_suspended}
    */
    readonly dynamicScalingOutSuspended?: boolean | cdktn.IResolvable;
    /**
    * Whether scheduled scaling is suspended. Set the value to ``true`` if you don't want Application Auto Scaling to add or remove capacity by initiating scheduled actions. The default is ``false``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#scheduled_scaling_suspended ApplicationautoscalingScalableTarget#scheduled_scaling_suspended}
    */
    readonly scheduledScalingSuspended?: boolean | cdktn.IResolvable;
}
export declare function applicationautoscalingScalableTargetSuspendedStateToTerraform(struct?: ApplicationautoscalingScalableTargetSuspendedState | cdktn.IResolvable): any;
export declare function applicationautoscalingScalableTargetSuspendedStateToHclTerraform(struct?: ApplicationautoscalingScalableTargetSuspendedState | cdktn.IResolvable): any;
export declare class ApplicationautoscalingScalableTargetSuspendedStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationautoscalingScalableTargetSuspendedState | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationautoscalingScalableTargetSuspendedState | cdktn.IResolvable | undefined);
    private _dynamicScalingInSuspended?;
    get dynamicScalingInSuspended(): boolean | cdktn.IResolvable;
    set dynamicScalingInSuspended(value: boolean | cdktn.IResolvable);
    resetDynamicScalingInSuspended(): void;
    get dynamicScalingInSuspendedInput(): boolean | cdktn.IResolvable | undefined;
    private _dynamicScalingOutSuspended?;
    get dynamicScalingOutSuspended(): boolean | cdktn.IResolvable;
    set dynamicScalingOutSuspended(value: boolean | cdktn.IResolvable);
    resetDynamicScalingOutSuspended(): void;
    get dynamicScalingOutSuspendedInput(): boolean | cdktn.IResolvable | undefined;
    private _scheduledScalingSuspended?;
    get scheduledScalingSuspended(): boolean | cdktn.IResolvable;
    set scheduledScalingSuspended(value: boolean | cdktn.IResolvable);
    resetScheduledScalingSuspended(): void;
    get scheduledScalingSuspendedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApplicationautoscalingScalableTargetTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#key ApplicationautoscalingScalableTarget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#value ApplicationautoscalingScalableTarget#value}
    */
    readonly value?: string;
}
export declare function applicationautoscalingScalableTargetTagsToTerraform(struct?: ApplicationautoscalingScalableTargetTags | cdktn.IResolvable): any;
export declare function applicationautoscalingScalableTargetTagsToHclTerraform(struct?: ApplicationautoscalingScalableTargetTags | cdktn.IResolvable): any;
export declare class ApplicationautoscalingScalableTargetTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationautoscalingScalableTargetTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationautoscalingScalableTargetTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApplicationautoscalingScalableTargetTagsList extends cdktn.ComplexList {
    internalValue?: ApplicationautoscalingScalableTargetTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationautoscalingScalableTargetTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target awscc_applicationautoscaling_scalable_target}
*/
export declare class ApplicationautoscalingScalableTarget extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_applicationautoscaling_scalable_target";
    /**
    * Generates CDKTN code for importing a ApplicationautoscalingScalableTarget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationautoscalingScalableTarget to import
    * @param importFromId The id of the existing ApplicationautoscalingScalableTarget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationautoscalingScalableTarget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/applicationautoscaling_scalable_target awscc_applicationautoscaling_scalable_target} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationautoscalingScalableTargetConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationautoscalingScalableTargetConfig);
    get id(): string;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    get maxCapacityInput(): number | undefined;
    private _minCapacity?;
    get minCapacity(): number;
    set minCapacity(value: number);
    get minCapacityInput(): number | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _scalableDimension?;
    get scalableDimension(): string;
    set scalableDimension(value: string);
    get scalableDimensionInput(): string | undefined;
    get scalableTargetId(): string;
    private _scheduledActions;
    get scheduledActions(): ApplicationautoscalingScalableTargetScheduledActionsList;
    putScheduledActions(value: ApplicationautoscalingScalableTargetScheduledActions[] | cdktn.IResolvable): void;
    resetScheduledActions(): void;
    get scheduledActionsInput(): cdktn.IResolvable | ApplicationautoscalingScalableTargetScheduledActions[] | undefined;
    private _serviceNamespace?;
    get serviceNamespace(): string;
    set serviceNamespace(value: string);
    get serviceNamespaceInput(): string | undefined;
    private _suspendedState;
    get suspendedState(): ApplicationautoscalingScalableTargetSuspendedStateOutputReference;
    putSuspendedState(value: ApplicationautoscalingScalableTargetSuspendedState): void;
    resetSuspendedState(): void;
    get suspendedStateInput(): cdktn.IResolvable | ApplicationautoscalingScalableTargetSuspendedState | undefined;
    private _tags;
    get tags(): ApplicationautoscalingScalableTargetTagsList;
    putTags(value: ApplicationautoscalingScalableTargetTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApplicationautoscalingScalableTargetTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
