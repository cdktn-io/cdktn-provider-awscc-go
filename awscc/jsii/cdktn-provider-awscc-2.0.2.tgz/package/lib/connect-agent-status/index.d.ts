/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectAgentStatusConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#description ConnectAgentStatus#description}
    */
    readonly description?: string;
    /**
    * The display order of the status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#display_order ConnectAgentStatus#display_order}
    */
    readonly displayOrder?: number;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#instance_arn ConnectAgentStatus#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#name ConnectAgentStatus#name}
    */
    readonly name: string;
    /**
    * A number indicating the reset order of the agent status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#reset_order_number ConnectAgentStatus#reset_order_number}
    */
    readonly resetOrderNumber?: boolean | cdktn.IResolvable;
    /**
    * The state of the status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#state ConnectAgentStatus#state}
    */
    readonly state: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#tags ConnectAgentStatus#tags}
    */
    readonly tags?: ConnectAgentStatusTags[] | cdktn.IResolvable;
    /**
    * The type of agent status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#type ConnectAgentStatus#type}
    */
    readonly type?: string;
}
export interface ConnectAgentStatusTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#key ConnectAgentStatus#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#value ConnectAgentStatus#value}
    */
    readonly value?: string;
}
export declare function connectAgentStatusTagsToTerraform(struct?: ConnectAgentStatusTags | cdktn.IResolvable): any;
export declare function connectAgentStatusTagsToHclTerraform(struct?: ConnectAgentStatusTags | cdktn.IResolvable): any;
export declare class ConnectAgentStatusTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectAgentStatusTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectAgentStatusTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectAgentStatusTagsList extends cdktn.ComplexList {
    internalValue?: ConnectAgentStatusTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectAgentStatusTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status awscc_connect_agent_status}
*/
export declare class ConnectAgentStatus extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_agent_status";
    /**
    * Generates CDKTN code for importing a ConnectAgentStatus resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectAgentStatus to import
    * @param importFromId The id of the existing ConnectAgentStatus that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectAgentStatus to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_agent_status awscc_connect_agent_status} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectAgentStatusConfig
    */
    constructor(scope: Construct, id: string, config: ConnectAgentStatusConfig);
    get agentStatusArn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayOrder?;
    get displayOrder(): number;
    set displayOrder(value: number);
    resetDisplayOrder(): void;
    get displayOrderInput(): number | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get lastModifiedRegion(): string;
    get lastModifiedTime(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resetOrderNumber?;
    get resetOrderNumber(): boolean | cdktn.IResolvable;
    set resetOrderNumber(value: boolean | cdktn.IResolvable);
    resetResetOrderNumber(): void;
    get resetOrderNumberInput(): boolean | cdktn.IResolvable | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
    private _tags;
    get tags(): ConnectAgentStatusTagsList;
    putTags(value: ConnectAgentStatusTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectAgentStatusTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
