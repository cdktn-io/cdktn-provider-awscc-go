/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockFlowAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#concurrency_configuration BedrockFlowAlias#concurrency_configuration}
    */
    readonly concurrencyConfiguration?: BedrockFlowAliasConcurrencyConfiguration;
    /**
    * Description of the Resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#description BedrockFlowAlias#description}
    */
    readonly description?: string;
    /**
    * Arn representation of the Flow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#flow_arn BedrockFlowAlias#flow_arn}
    */
    readonly flowArn: string;
    /**
    * Name for a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#name BedrockFlowAlias#name}
    */
    readonly name: string;
    /**
    * Routing configuration for a Flow alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#routing_configuration BedrockFlowAlias#routing_configuration}
    */
    readonly routingConfiguration: BedrockFlowAliasRoutingConfiguration[] | cdktn.IResolvable;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#tags BedrockFlowAlias#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BedrockFlowAliasConcurrencyConfiguration {
    /**
    * Number of nodes executed concurrently at a time
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#max_concurrency BedrockFlowAlias#max_concurrency}
    */
    readonly maxConcurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#type BedrockFlowAlias#type}
    */
    readonly type?: string;
}
export declare function bedrockFlowAliasConcurrencyConfigurationToTerraform(struct?: BedrockFlowAliasConcurrencyConfiguration | cdktn.IResolvable): any;
export declare function bedrockFlowAliasConcurrencyConfigurationToHclTerraform(struct?: BedrockFlowAliasConcurrencyConfiguration | cdktn.IResolvable): any;
export declare class BedrockFlowAliasConcurrencyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockFlowAliasConcurrencyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockFlowAliasConcurrencyConfiguration | cdktn.IResolvable | undefined);
    private _maxConcurrency?;
    get maxConcurrency(): number;
    set maxConcurrency(value: number);
    resetMaxConcurrency(): void;
    get maxConcurrencyInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockFlowAliasRoutingConfiguration {
    /**
    * Version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#flow_version BedrockFlowAlias#flow_version}
    */
    readonly flowVersion?: string;
}
export declare function bedrockFlowAliasRoutingConfigurationToTerraform(struct?: BedrockFlowAliasRoutingConfiguration | cdktn.IResolvable): any;
export declare function bedrockFlowAliasRoutingConfigurationToHclTerraform(struct?: BedrockFlowAliasRoutingConfiguration | cdktn.IResolvable): any;
export declare class BedrockFlowAliasRoutingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockFlowAliasRoutingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockFlowAliasRoutingConfiguration | cdktn.IResolvable | undefined);
    private _flowVersion?;
    get flowVersion(): string;
    set flowVersion(value: string);
    resetFlowVersion(): void;
    get flowVersionInput(): string | undefined;
}
export declare class BedrockFlowAliasRoutingConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockFlowAliasRoutingConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockFlowAliasRoutingConfigurationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias awscc_bedrock_flow_alias}
*/
export declare class BedrockFlowAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_flow_alias";
    /**
    * Generates CDKTN code for importing a BedrockFlowAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockFlowAlias to import
    * @param importFromId The id of the existing BedrockFlowAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockFlowAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_flow_alias awscc_bedrock_flow_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockFlowAliasConfig
    */
    constructor(scope: Construct, id: string, config: BedrockFlowAliasConfig);
    get arn(): string;
    private _concurrencyConfiguration;
    get concurrencyConfiguration(): BedrockFlowAliasConcurrencyConfigurationOutputReference;
    putConcurrencyConfiguration(value: BedrockFlowAliasConcurrencyConfiguration): void;
    resetConcurrencyConfiguration(): void;
    get concurrencyConfigurationInput(): cdktn.IResolvable | BedrockFlowAliasConcurrencyConfiguration | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get flowAliasId(): string;
    private _flowArn?;
    get flowArn(): string;
    set flowArn(value: string);
    get flowArnInput(): string | undefined;
    get flowId(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _routingConfiguration;
    get routingConfiguration(): BedrockFlowAliasRoutingConfigurationList;
    putRoutingConfiguration(value: BedrockFlowAliasRoutingConfiguration[] | cdktn.IResolvable): void;
    get routingConfigurationInput(): cdktn.IResolvable | BedrockFlowAliasRoutingConfiguration[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
