/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * The configuration for the connector that specifies the third-party cloud provider connection details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector#connector_configuration ConfigConnector#connector_configuration}
    */
    readonly connectorConfiguration: ConfigConnectorConnectorConfiguration;
    /**
    * The tags for the connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector#tags ConfigConnector#tags}
    */
    readonly tags?: ConfigConnectorTags[] | cdktn.IResolvable;
}
export interface ConfigConnectorConnectorConfigurationAzure {
    /**
    * The Azure client (application) identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector#client_identifier ConfigConnector#client_identifier}
    */
    readonly clientIdentifier?: string;
    /**
    * The Azure tenant identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector#tenant_identifier ConfigConnector#tenant_identifier}
    */
    readonly tenantIdentifier?: string;
}
export declare function configConnectorConnectorConfigurationAzureToTerraform(struct?: ConfigConnectorConnectorConfigurationAzure | cdktn.IResolvable): any;
export declare function configConnectorConnectorConfigurationAzureToHclTerraform(struct?: ConfigConnectorConnectorConfigurationAzure | cdktn.IResolvable): any;
export declare class ConfigConnectorConnectorConfigurationAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConnectorConnectorConfigurationAzure | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConnectorConnectorConfigurationAzure | cdktn.IResolvable | undefined);
    private _clientIdentifier?;
    get clientIdentifier(): string;
    set clientIdentifier(value: string);
    resetClientIdentifier(): void;
    get clientIdentifierInput(): string | undefined;
    private _tenantIdentifier?;
    get tenantIdentifier(): string;
    set tenantIdentifier(value: string);
    resetTenantIdentifier(): void;
    get tenantIdentifierInput(): string | undefined;
}
export interface ConfigConnectorConnectorConfiguration {
    /**
    * The configuration for connecting to Microsoft Azure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector#azure ConfigConnector#azure}
    */
    readonly azure?: ConfigConnectorConnectorConfigurationAzure;
}
export declare function configConnectorConnectorConfigurationToTerraform(struct?: ConfigConnectorConnectorConfiguration | cdktn.IResolvable): any;
export declare function configConnectorConnectorConfigurationToHclTerraform(struct?: ConfigConnectorConnectorConfiguration | cdktn.IResolvable): any;
export declare class ConfigConnectorConnectorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConnectorConnectorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConnectorConnectorConfiguration | cdktn.IResolvable | undefined);
    private _azure;
    get azure(): ConfigConnectorConnectorConfigurationAzureOutputReference;
    putAzure(value: ConfigConnectorConnectorConfigurationAzure): void;
    resetAzure(): void;
    get azureInput(): cdktn.IResolvable | ConfigConnectorConnectorConfigurationAzure | undefined;
}
export interface ConfigConnectorTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector#key ConfigConnector#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector#value ConfigConnector#value}
    */
    readonly value?: string;
}
export declare function configConnectorTagsToTerraform(struct?: ConfigConnectorTags | cdktn.IResolvable): any;
export declare function configConnectorTagsToHclTerraform(struct?: ConfigConnectorTags | cdktn.IResolvable): any;
export declare class ConfigConnectorTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigConnectorTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConnectorTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConfigConnectorTagsList extends cdktn.ComplexList {
    internalValue?: ConfigConnectorTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigConnectorTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector awscc_config_connector}
*/
export declare class ConfigConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_connector";
    /**
    * Generates CDKTN code for importing a ConfigConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigConnector to import
    * @param importFromId The id of the existing ConfigConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_connector awscc_config_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigConnectorConfig
    */
    constructor(scope: Construct, id: string, config: ConfigConnectorConfig);
    get arn(): string;
    private _connectorConfiguration;
    get connectorConfiguration(): ConfigConnectorConnectorConfigurationOutputReference;
    putConnectorConfiguration(value: ConfigConnectorConnectorConfiguration): void;
    get connectorConfigurationInput(): cdktn.IResolvable | ConfigConnectorConnectorConfiguration | undefined;
    get createdTime(): string;
    get id(): string;
    get name(): string;
    private _tags;
    get tags(): ConfigConnectorTagsList;
    putTags(value: ConfigConnectorTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConfigConnectorTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
