/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchOtelEnrichmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Removes metrics from the include set. Absent or empty means nothing is removed. Evaluated after IncludeFilters, so ExcludeFilters always wins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment#exclude_filters CloudwatchOtelEnrichment#exclude_filters}
    */
    readonly excludeFilters?: CloudwatchOtelEnrichmentExcludeFilters[] | cdktn.IResolvable;
    /**
    * Scopes enrichment to a subset of the account's telemetry. Absent or empty means all namespaces are in scope. Present means only these are. The service enforces a combined cap of 100 selectors across IncludeFilters and ExcludeFilters, and rejects more than one selector for the same namespace within a direction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment#include_filters CloudwatchOtelEnrichment#include_filters}
    */
    readonly includeFilters?: CloudwatchOtelEnrichmentIncludeFilters[] | cdktn.IResolvable;
}
export interface CloudwatchOtelEnrichmentExcludeFilters {
    /**
    * Absent or empty means every metric in this namespace, in whichever direction this selector appears. Present means only these metric names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment#metric_names CloudwatchOtelEnrichment#metric_names}
    */
    readonly metricNames?: string[];
    /**
    * The CloudWatch namespace this selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment#namespace CloudwatchOtelEnrichment#namespace}
    */
    readonly namespace?: string;
}
export declare function cloudwatchOtelEnrichmentExcludeFiltersToTerraform(struct?: CloudwatchOtelEnrichmentExcludeFilters | cdktn.IResolvable): any;
export declare function cloudwatchOtelEnrichmentExcludeFiltersToHclTerraform(struct?: CloudwatchOtelEnrichmentExcludeFilters | cdktn.IResolvable): any;
export declare class CloudwatchOtelEnrichmentExcludeFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchOtelEnrichmentExcludeFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchOtelEnrichmentExcludeFilters | cdktn.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    resetMetricNames(): void;
    get metricNamesInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class CloudwatchOtelEnrichmentExcludeFiltersList extends cdktn.ComplexList {
    internalValue?: CloudwatchOtelEnrichmentExcludeFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchOtelEnrichmentExcludeFiltersOutputReference;
}
export interface CloudwatchOtelEnrichmentIncludeFilters {
    /**
    * Absent or empty means every metric in this namespace, in whichever direction this selector appears. Present means only these metric names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment#metric_names CloudwatchOtelEnrichment#metric_names}
    */
    readonly metricNames?: string[];
    /**
    * The CloudWatch namespace this selector applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment#namespace CloudwatchOtelEnrichment#namespace}
    */
    readonly namespace?: string;
}
export declare function cloudwatchOtelEnrichmentIncludeFiltersToTerraform(struct?: CloudwatchOtelEnrichmentIncludeFilters | cdktn.IResolvable): any;
export declare function cloudwatchOtelEnrichmentIncludeFiltersToHclTerraform(struct?: CloudwatchOtelEnrichmentIncludeFilters | cdktn.IResolvable): any;
export declare class CloudwatchOtelEnrichmentIncludeFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchOtelEnrichmentIncludeFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchOtelEnrichmentIncludeFilters | cdktn.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    resetMetricNames(): void;
    get metricNamesInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class CloudwatchOtelEnrichmentIncludeFiltersList extends cdktn.ComplexList {
    internalValue?: CloudwatchOtelEnrichmentIncludeFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchOtelEnrichmentIncludeFiltersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment awscc_cloudwatch_otel_enrichment}
*/
export declare class CloudwatchOtelEnrichment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_otel_enrichment";
    /**
    * Generates CDKTN code for importing a CloudwatchOtelEnrichment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchOtelEnrichment to import
    * @param importFromId The id of the existing CloudwatchOtelEnrichment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchOtelEnrichment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_otel_enrichment awscc_cloudwatch_otel_enrichment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchOtelEnrichmentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudwatchOtelEnrichmentConfig);
    get accountId(): string;
    private _excludeFilters;
    get excludeFilters(): CloudwatchOtelEnrichmentExcludeFiltersList;
    putExcludeFilters(value: CloudwatchOtelEnrichmentExcludeFilters[] | cdktn.IResolvable): void;
    resetExcludeFilters(): void;
    get excludeFiltersInput(): cdktn.IResolvable | CloudwatchOtelEnrichmentExcludeFilters[] | undefined;
    get id(): string;
    private _includeFilters;
    get includeFilters(): CloudwatchOtelEnrichmentIncludeFiltersList;
    putIncludeFilters(value: CloudwatchOtelEnrichmentIncludeFilters[] | cdktn.IResolvable): void;
    resetIncludeFilters(): void;
    get includeFiltersInput(): cdktn.IResolvable | CloudwatchOtelEnrichmentIncludeFilters[] | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
