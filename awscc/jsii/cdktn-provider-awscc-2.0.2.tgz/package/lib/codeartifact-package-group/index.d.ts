/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodeartifactPackageGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The contact info of the package group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#contact_info CodeartifactPackageGroup#contact_info}
    */
    readonly contactInfo?: string;
    /**
    * The text description of the package group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#description CodeartifactPackageGroup#description}
    */
    readonly description?: string;
    /**
    * The name of the domain that contains the package group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#domain_name CodeartifactPackageGroup#domain_name}
    */
    readonly domainName: string;
    /**
    * The 12-digit account ID of the AWS account that owns the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#domain_owner CodeartifactPackageGroup#domain_owner}
    */
    readonly domainOwner?: string;
    /**
    * The package origin configuration of the package group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#origin_configuration CodeartifactPackageGroup#origin_configuration}
    */
    readonly originConfiguration?: CodeartifactPackageGroupOriginConfiguration;
    /**
    * The package group pattern that is used to gather packages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#pattern CodeartifactPackageGroup#pattern}
    */
    readonly pattern: string;
    /**
    * An array of key-value pairs to apply to the package group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#tags CodeartifactPackageGroup#tags}
    */
    readonly tags?: CodeartifactPackageGroupTags[] | cdktn.IResolvable;
}
export interface CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstream {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#repositories CodeartifactPackageGroup#repositories}
    */
    readonly repositories?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#restriction_mode CodeartifactPackageGroup#restriction_mode}
    */
    readonly restrictionMode?: string;
}
export declare function codeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstreamToTerraform(struct?: CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstream | cdktn.IResolvable): any;
export declare function codeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstreamToHclTerraform(struct?: CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstream | cdktn.IResolvable): any;
export declare class CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstreamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstream | cdktn.IResolvable | undefined;
    set internalValue(value: CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstream | cdktn.IResolvable | undefined);
    private _repositories?;
    get repositories(): string[];
    set repositories(value: string[]);
    resetRepositories(): void;
    get repositoriesInput(): string[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    resetRestrictionMode(): void;
    get restrictionModeInput(): string | undefined;
}
export interface CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstream {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#repositories CodeartifactPackageGroup#repositories}
    */
    readonly repositories?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#restriction_mode CodeartifactPackageGroup#restriction_mode}
    */
    readonly restrictionMode?: string;
}
export declare function codeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstreamToTerraform(struct?: CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstream | cdktn.IResolvable): any;
export declare function codeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstreamToHclTerraform(struct?: CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstream | cdktn.IResolvable): any;
export declare class CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstreamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstream | cdktn.IResolvable | undefined;
    set internalValue(value: CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstream | cdktn.IResolvable | undefined);
    private _repositories?;
    get repositories(): string[];
    set repositories(value: string[]);
    resetRepositories(): void;
    get repositoriesInput(): string[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    resetRestrictionMode(): void;
    get restrictionModeInput(): string | undefined;
}
export interface CodeartifactPackageGroupOriginConfigurationRestrictionsPublish {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#repositories CodeartifactPackageGroup#repositories}
    */
    readonly repositories?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#restriction_mode CodeartifactPackageGroup#restriction_mode}
    */
    readonly restrictionMode?: string;
}
export declare function codeartifactPackageGroupOriginConfigurationRestrictionsPublishToTerraform(struct?: CodeartifactPackageGroupOriginConfigurationRestrictionsPublish | cdktn.IResolvable): any;
export declare function codeartifactPackageGroupOriginConfigurationRestrictionsPublishToHclTerraform(struct?: CodeartifactPackageGroupOriginConfigurationRestrictionsPublish | cdktn.IResolvable): any;
export declare class CodeartifactPackageGroupOriginConfigurationRestrictionsPublishOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodeartifactPackageGroupOriginConfigurationRestrictionsPublish | cdktn.IResolvable | undefined;
    set internalValue(value: CodeartifactPackageGroupOriginConfigurationRestrictionsPublish | cdktn.IResolvable | undefined);
    private _repositories?;
    get repositories(): string[];
    set repositories(value: string[]);
    resetRepositories(): void;
    get repositoriesInput(): string[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    resetRestrictionMode(): void;
    get restrictionModeInput(): string | undefined;
}
export interface CodeartifactPackageGroupOriginConfigurationRestrictions {
    /**
    * The external upstream restriction determines if new package versions can be ingested or retained from external connections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#external_upstream CodeartifactPackageGroup#external_upstream}
    */
    readonly externalUpstream?: CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstream;
    /**
    * The internal upstream restriction determines if new package versions can be ingested or retained from upstream repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#internal_upstream CodeartifactPackageGroup#internal_upstream}
    */
    readonly internalUpstream?: CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstream;
    /**
    * The publish restriction determines if new package versions can be published.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#publish CodeartifactPackageGroup#publish}
    */
    readonly publish?: CodeartifactPackageGroupOriginConfigurationRestrictionsPublish;
}
export declare function codeartifactPackageGroupOriginConfigurationRestrictionsToTerraform(struct?: CodeartifactPackageGroupOriginConfigurationRestrictions | cdktn.IResolvable): any;
export declare function codeartifactPackageGroupOriginConfigurationRestrictionsToHclTerraform(struct?: CodeartifactPackageGroupOriginConfigurationRestrictions | cdktn.IResolvable): any;
export declare class CodeartifactPackageGroupOriginConfigurationRestrictionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodeartifactPackageGroupOriginConfigurationRestrictions | cdktn.IResolvable | undefined;
    set internalValue(value: CodeartifactPackageGroupOriginConfigurationRestrictions | cdktn.IResolvable | undefined);
    private _externalUpstream;
    get externalUpstream(): CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstreamOutputReference;
    putExternalUpstream(value: CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstream): void;
    resetExternalUpstream(): void;
    get externalUpstreamInput(): cdktn.IResolvable | CodeartifactPackageGroupOriginConfigurationRestrictionsExternalUpstream | undefined;
    private _internalUpstream;
    get internalUpstream(): CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstreamOutputReference;
    putInternalUpstream(value: CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstream): void;
    resetInternalUpstream(): void;
    get internalUpstreamInput(): cdktn.IResolvable | CodeartifactPackageGroupOriginConfigurationRestrictionsInternalUpstream | undefined;
    private _publish;
    get publish(): CodeartifactPackageGroupOriginConfigurationRestrictionsPublishOutputReference;
    putPublish(value: CodeartifactPackageGroupOriginConfigurationRestrictionsPublish): void;
    resetPublish(): void;
    get publishInput(): cdktn.IResolvable | CodeartifactPackageGroupOriginConfigurationRestrictionsPublish | undefined;
}
export interface CodeartifactPackageGroupOriginConfiguration {
    /**
    * The origin configuration that is applied to the package group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#restrictions CodeartifactPackageGroup#restrictions}
    */
    readonly restrictions?: CodeartifactPackageGroupOriginConfigurationRestrictions;
}
export declare function codeartifactPackageGroupOriginConfigurationToTerraform(struct?: CodeartifactPackageGroupOriginConfiguration | cdktn.IResolvable): any;
export declare function codeartifactPackageGroupOriginConfigurationToHclTerraform(struct?: CodeartifactPackageGroupOriginConfiguration | cdktn.IResolvable): any;
export declare class CodeartifactPackageGroupOriginConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodeartifactPackageGroupOriginConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodeartifactPackageGroupOriginConfiguration | cdktn.IResolvable | undefined);
    private _restrictions;
    get restrictions(): CodeartifactPackageGroupOriginConfigurationRestrictionsOutputReference;
    putRestrictions(value: CodeartifactPackageGroupOriginConfigurationRestrictions): void;
    resetRestrictions(): void;
    get restrictionsInput(): cdktn.IResolvable | CodeartifactPackageGroupOriginConfigurationRestrictions | undefined;
}
export interface CodeartifactPackageGroupTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#key CodeartifactPackageGroup#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#value CodeartifactPackageGroup#value}
    */
    readonly value?: string;
}
export declare function codeartifactPackageGroupTagsToTerraform(struct?: CodeartifactPackageGroupTags | cdktn.IResolvable): any;
export declare function codeartifactPackageGroupTagsToHclTerraform(struct?: CodeartifactPackageGroupTags | cdktn.IResolvable): any;
export declare class CodeartifactPackageGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodeartifactPackageGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodeartifactPackageGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodeartifactPackageGroupTagsList extends cdktn.ComplexList {
    internalValue?: CodeartifactPackageGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodeartifactPackageGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group awscc_codeartifact_package_group}
*/
export declare class CodeartifactPackageGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codeartifact_package_group";
    /**
    * Generates CDKTN code for importing a CodeartifactPackageGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodeartifactPackageGroup to import
    * @param importFromId The id of the existing CodeartifactPackageGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodeartifactPackageGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeartifact_package_group awscc_codeartifact_package_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodeartifactPackageGroupConfig
    */
    constructor(scope: Construct, id: string, config: CodeartifactPackageGroupConfig);
    get arn(): string;
    private _contactInfo?;
    get contactInfo(): string;
    set contactInfo(value: string);
    resetContactInfo(): void;
    get contactInfoInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _domainOwner?;
    get domainOwner(): string;
    set domainOwner(value: string);
    resetDomainOwner(): void;
    get domainOwnerInput(): string | undefined;
    get id(): string;
    private _originConfiguration;
    get originConfiguration(): CodeartifactPackageGroupOriginConfigurationOutputReference;
    putOriginConfiguration(value: CodeartifactPackageGroupOriginConfiguration): void;
    resetOriginConfiguration(): void;
    get originConfigurationInput(): cdktn.IResolvable | CodeartifactPackageGroupOriginConfiguration | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    get patternInput(): string | undefined;
    private _tags;
    get tags(): CodeartifactPackageGroupTagsList;
    putTags(value: CodeartifactPackageGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodeartifactPackageGroupTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
