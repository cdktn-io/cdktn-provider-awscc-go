/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2DomainNameConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigatewayv2_domain_name#id DataAwsccApigatewayv2DomainName#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2DomainNameDomainNameConfigurations {
}
export declare function dataAwsccApigatewayv2DomainNameDomainNameConfigurationsToTerraform(struct?: DataAwsccApigatewayv2DomainNameDomainNameConfigurations): any;
export declare function dataAwsccApigatewayv2DomainNameDomainNameConfigurationsToHclTerraform(struct?: DataAwsccApigatewayv2DomainNameDomainNameConfigurations): any;
export declare class DataAwsccApigatewayv2DomainNameDomainNameConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayv2DomainNameDomainNameConfigurations | undefined;
    set internalValue(value: DataAwsccApigatewayv2DomainNameDomainNameConfigurations | undefined);
    get certificateArn(): string;
    get certificateName(): string;
    get endpointType(): string;
    get ipAddressType(): string;
    get ownershipVerificationCertificateArn(): string;
    get securityPolicy(): string;
}
export declare class DataAwsccApigatewayv2DomainNameDomainNameConfigurationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayv2DomainNameDomainNameConfigurationsOutputReference;
}
export interface DataAwsccApigatewayv2DomainNameMutualTlsAuthentication {
}
export declare function dataAwsccApigatewayv2DomainNameMutualTlsAuthenticationToTerraform(struct?: DataAwsccApigatewayv2DomainNameMutualTlsAuthentication): any;
export declare function dataAwsccApigatewayv2DomainNameMutualTlsAuthenticationToHclTerraform(struct?: DataAwsccApigatewayv2DomainNameMutualTlsAuthentication): any;
export declare class DataAwsccApigatewayv2DomainNameMutualTlsAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2DomainNameMutualTlsAuthentication | undefined;
    set internalValue(value: DataAwsccApigatewayv2DomainNameMutualTlsAuthentication | undefined);
    get truststoreUri(): string;
    get truststoreVersion(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigatewayv2_domain_name awscc_apigatewayv2_domain_name}
*/
export declare class DataAwsccApigatewayv2DomainName extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_domain_name";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2DomainName resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2DomainName to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2DomainName that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigatewayv2_domain_name#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2DomainName to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigatewayv2_domain_name awscc_apigatewayv2_domain_name} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2DomainNameConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2DomainNameConfig);
    get domainName(): string;
    get domainNameArn(): string;
    private _domainNameConfigurations;
    get domainNameConfigurations(): DataAwsccApigatewayv2DomainNameDomainNameConfigurationsList;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _mutualTlsAuthentication;
    get mutualTlsAuthentication(): DataAwsccApigatewayv2DomainNameMutualTlsAuthenticationOutputReference;
    get regionalDomainName(): string;
    get regionalHostedZoneId(): string;
    get routingMode(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
