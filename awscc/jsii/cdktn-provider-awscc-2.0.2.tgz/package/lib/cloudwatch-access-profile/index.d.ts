/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchAccessProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the access profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile#description CloudwatchAccessProfile#description}
    */
    readonly description?: string;
    /**
    * The name of the access profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile#name CloudwatchAccessProfile#name}
    */
    readonly name: string;
    /**
    * The unique identifier of the space the access profile belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile#space_id CloudwatchAccessProfile#space_id}
    */
    readonly spaceId: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile#tags CloudwatchAccessProfile#tags}
    */
    readonly tags?: CloudwatchAccessProfileTags[] | cdktn.IResolvable;
}
export interface CloudwatchAccessProfileTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile#key CloudwatchAccessProfile#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile#value CloudwatchAccessProfile#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAccessProfileTagsToTerraform(struct?: CloudwatchAccessProfileTags | cdktn.IResolvable): any;
export declare function cloudwatchAccessProfileTagsToHclTerraform(struct?: CloudwatchAccessProfileTags | cdktn.IResolvable): any;
export declare class CloudwatchAccessProfileTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAccessProfileTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAccessProfileTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAccessProfileTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAccessProfileTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAccessProfileTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile awscc_cloudwatch_access_profile}
*/
export declare class CloudwatchAccessProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_access_profile";
    /**
    * Generates CDKTN code for importing a CloudwatchAccessProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchAccessProfile to import
    * @param importFromId The id of the existing CloudwatchAccessProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchAccessProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_access_profile awscc_cloudwatch_access_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchAccessProfileConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchAccessProfileConfig);
    get arn(): string;
    get assumeStatus(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get profileId(): string;
    get profileType(): string;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
    private _tags;
    get tags(): CloudwatchAccessProfileTagsList;
    putTags(value: CloudwatchAccessProfileTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchAccessProfileTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
