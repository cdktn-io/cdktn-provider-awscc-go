/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CeAnomalySubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The frequency at which anomaly reports are sent over email.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#frequency CeAnomalySubscription#frequency}
    */
    readonly frequency: string;
    /**
    * A list of cost anomaly monitors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#monitor_arn_list CeAnomalySubscription#monitor_arn_list}
    */
    readonly monitorArnList: string[];
    /**
    * Tags to assign to subscription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#resource_tags CeAnomalySubscription#resource_tags}
    */
    readonly resourceTags?: CeAnomalySubscriptionResourceTags[] | cdktn.IResolvable;
    /**
    * A list of subscriber
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#subscribers CeAnomalySubscription#subscribers}
    */
    readonly subscribers: CeAnomalySubscriptionSubscribers[] | cdktn.IResolvable;
    /**
    * The name of the subscription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#subscription_name CeAnomalySubscription#subscription_name}
    */
    readonly subscriptionName: string;
    /**
    * The dollar value that triggers a notification if the threshold is exceeded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#threshold CeAnomalySubscription#threshold}
    */
    readonly threshold?: number;
    /**
    * An Expression object in JSON String format used to specify the anomalies that you want to generate alerts for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#threshold_expression CeAnomalySubscription#threshold_expression}
    */
    readonly thresholdExpression?: string;
}
export interface CeAnomalySubscriptionResourceTags {
    /**
    * The key name for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#key CeAnomalySubscription#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#value CeAnomalySubscription#value}
    */
    readonly value?: string;
}
export declare function ceAnomalySubscriptionResourceTagsToTerraform(struct?: CeAnomalySubscriptionResourceTags | cdktn.IResolvable): any;
export declare function ceAnomalySubscriptionResourceTagsToHclTerraform(struct?: CeAnomalySubscriptionResourceTags | cdktn.IResolvable): any;
export declare class CeAnomalySubscriptionResourceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CeAnomalySubscriptionResourceTags | cdktn.IResolvable | undefined;
    set internalValue(value: CeAnomalySubscriptionResourceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CeAnomalySubscriptionResourceTagsList extends cdktn.ComplexList {
    internalValue?: CeAnomalySubscriptionResourceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CeAnomalySubscriptionResourceTagsOutputReference;
}
export interface CeAnomalySubscriptionSubscribers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#address CeAnomalySubscription#address}
    */
    readonly address: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#status CeAnomalySubscription#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#type CeAnomalySubscription#type}
    */
    readonly type: string;
}
export declare function ceAnomalySubscriptionSubscribersToTerraform(struct?: CeAnomalySubscriptionSubscribers | cdktn.IResolvable): any;
export declare function ceAnomalySubscriptionSubscribersToHclTerraform(struct?: CeAnomalySubscriptionSubscribers | cdktn.IResolvable): any;
export declare class CeAnomalySubscriptionSubscribersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CeAnomalySubscriptionSubscribers | cdktn.IResolvable | undefined;
    set internalValue(value: CeAnomalySubscriptionSubscribers | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class CeAnomalySubscriptionSubscribersList extends cdktn.ComplexList {
    internalValue?: CeAnomalySubscriptionSubscribers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CeAnomalySubscriptionSubscribersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription awscc_ce_anomaly_subscription}
*/
export declare class CeAnomalySubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_ce_anomaly_subscription";
    /**
    * Generates CDKTN code for importing a CeAnomalySubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CeAnomalySubscription to import
    * @param importFromId The id of the existing CeAnomalySubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CeAnomalySubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/ce_anomaly_subscription awscc_ce_anomaly_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CeAnomalySubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: CeAnomalySubscriptionConfig);
    get accountId(): string;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    get frequencyInput(): string | undefined;
    get id(): string;
    private _monitorArnList?;
    get monitorArnList(): string[];
    set monitorArnList(value: string[]);
    get monitorArnListInput(): string[] | undefined;
    private _resourceTags;
    get resourceTags(): CeAnomalySubscriptionResourceTagsList;
    putResourceTags(value: CeAnomalySubscriptionResourceTags[] | cdktn.IResolvable): void;
    resetResourceTags(): void;
    get resourceTagsInput(): cdktn.IResolvable | CeAnomalySubscriptionResourceTags[] | undefined;
    private _subscribers;
    get subscribers(): CeAnomalySubscriptionSubscribersList;
    putSubscribers(value: CeAnomalySubscriptionSubscribers[] | cdktn.IResolvable): void;
    get subscribersInput(): cdktn.IResolvable | CeAnomalySubscriptionSubscribers[] | undefined;
    get subscriptionArn(): string;
    private _subscriptionName?;
    get subscriptionName(): string;
    set subscriptionName(value: string);
    get subscriptionNameInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
    private _thresholdExpression?;
    get thresholdExpression(): string;
    set thresholdExpression(value: string);
    resetThresholdExpression(): void;
    get thresholdExpressionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
