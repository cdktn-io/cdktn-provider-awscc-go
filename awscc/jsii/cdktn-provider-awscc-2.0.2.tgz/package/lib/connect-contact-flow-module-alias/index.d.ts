/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectContactFlowModuleAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the contact flow module (ARN) this alias is tied to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_module_alias#contact_flow_module_id ConnectContactFlowModuleAlias#contact_flow_module_id}
    */
    readonly contactFlowModuleId: string;
    /**
    * The version number of the contact flow module this alias points to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_module_alias#contact_flow_module_version ConnectContactFlowModuleAlias#contact_flow_module_version}
    */
    readonly contactFlowModuleVersion: number;
    /**
    * The description of the alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_module_alias#description ConnectContactFlowModuleAlias#description}
    */
    readonly description?: string;
    /**
    * The name of the alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_module_alias#name ConnectContactFlowModuleAlias#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_module_alias awscc_connect_contact_flow_module_alias}
*/
export declare class ConnectContactFlowModuleAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_contact_flow_module_alias";
    /**
    * Generates CDKTN code for importing a ConnectContactFlowModuleAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectContactFlowModuleAlias to import
    * @param importFromId The id of the existing ConnectContactFlowModuleAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_module_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectContactFlowModuleAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_contact_flow_module_alias awscc_connect_contact_flow_module_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectContactFlowModuleAliasConfig
    */
    constructor(scope: Construct, id: string, config: ConnectContactFlowModuleAliasConfig);
    get aliasId(): string;
    get contactFlowModuleAliasArn(): string;
    private _contactFlowModuleId?;
    get contactFlowModuleId(): string;
    set contactFlowModuleId(value: string);
    get contactFlowModuleIdInput(): string | undefined;
    private _contactFlowModuleVersion?;
    get contactFlowModuleVersion(): number;
    set contactFlowModuleVersion(value: number);
    get contactFlowModuleVersionInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
