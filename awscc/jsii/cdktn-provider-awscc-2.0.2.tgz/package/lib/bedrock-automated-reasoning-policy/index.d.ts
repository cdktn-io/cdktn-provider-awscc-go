/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockAutomatedReasoningPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#description BedrockAutomatedReasoningPolicy#description}
    */
    readonly description?: string;
    /**
    * Specifies whether to force delete the automated reasoning policy even if it has active resources. When false , Amazon Bedrock validates if all artifacts have been deleted (e.g. policy version, test case, test result) for a policy before deletion. When true , Amazon Bedrock will delete the policy and all its artifacts without validation. Default is false
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#force_delete BedrockAutomatedReasoningPolicy#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * The KMS key with which the Policy's assets will be encrypted at rest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#kms_key_id BedrockAutomatedReasoningPolicy#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#name BedrockAutomatedReasoningPolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#policy_definition BedrockAutomatedReasoningPolicy#policy_definition}
    */
    readonly policyDefinition?: BedrockAutomatedReasoningPolicyPolicyDefinition;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#tags BedrockAutomatedReasoningPolicy#tags}
    */
    readonly tags?: BedrockAutomatedReasoningPolicyTags[] | cdktn.IResolvable;
}
export interface BedrockAutomatedReasoningPolicyPolicyDefinitionRules {
    /**
    * An alternate expression for this rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#alternate_expression BedrockAutomatedReasoningPolicy#alternate_expression}
    */
    readonly alternateExpression?: string;
    /**
    * The SMT expression for this rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#expression BedrockAutomatedReasoningPolicy#expression}
    */
    readonly expression?: string;
    /**
    * A unique id within the PolicyDefinition
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#id BedrockAutomatedReasoningPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionRulesToTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinitionRules | cdktn.IResolvable): any;
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionRulesToHclTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinitionRules | cdktn.IResolvable): any;
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAutomatedReasoningPolicyPolicyDefinitionRules | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAutomatedReasoningPolicyPolicyDefinitionRules | cdktn.IResolvable | undefined);
    private _alternateExpression?;
    get alternateExpression(): string;
    set alternateExpression(value: string);
    resetAlternateExpression(): void;
    get alternateExpressionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionRulesList extends cdktn.ComplexList {
    internalValue?: BedrockAutomatedReasoningPolicyPolicyDefinitionRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAutomatedReasoningPolicyPolicyDefinitionRulesOutputReference;
}
export interface BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues {
    /**
    * A natural language description of the type's value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#description BedrockAutomatedReasoningPolicy#description}
    */
    readonly description?: string;
    /**
    * The value of the type value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#value BedrockAutomatedReasoningPolicy#value}
    */
    readonly value?: string;
}
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionTypesValuesToTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues | cdktn.IResolvable): any;
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionTypesValuesToHclTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues | cdktn.IResolvable): any;
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValuesList extends cdktn.ComplexList {
    internalValue?: BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValuesOutputReference;
}
export interface BedrockAutomatedReasoningPolicyPolicyDefinitionTypes {
    /**
    * A natural language description of this type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#description BedrockAutomatedReasoningPolicy#description}
    */
    readonly description?: string;
    /**
    * A name for this type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#name BedrockAutomatedReasoningPolicy#name}
    */
    readonly name?: string;
    /**
    * A list of valid values for this type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#values BedrockAutomatedReasoningPolicy#values}
    */
    readonly values?: BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues[] | cdktn.IResolvable;
}
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionTypesToTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinitionTypes | cdktn.IResolvable): any;
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionTypesToHclTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinitionTypes | cdktn.IResolvable): any;
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAutomatedReasoningPolicyPolicyDefinitionTypes | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAutomatedReasoningPolicyPolicyDefinitionTypes | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _values;
    get values(): BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValuesList;
    putValues(value: BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues[] | cdktn.IResolvable): void;
    resetValues(): void;
    get valuesInput(): cdktn.IResolvable | BedrockAutomatedReasoningPolicyPolicyDefinitionTypesValues[] | undefined;
}
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionTypesList extends cdktn.ComplexList {
    internalValue?: BedrockAutomatedReasoningPolicyPolicyDefinitionTypes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAutomatedReasoningPolicyPolicyDefinitionTypesOutputReference;
}
export interface BedrockAutomatedReasoningPolicyPolicyDefinitionVariables {
    /**
    * A natural language description of this variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#description BedrockAutomatedReasoningPolicy#description}
    */
    readonly description?: string;
    /**
    * A name from this variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#name BedrockAutomatedReasoningPolicy#name}
    */
    readonly name?: string;
    /**
    * A type for this variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#type BedrockAutomatedReasoningPolicy#type}
    */
    readonly type?: string;
}
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionVariablesToTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinitionVariables | cdktn.IResolvable): any;
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionVariablesToHclTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinitionVariables | cdktn.IResolvable): any;
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAutomatedReasoningPolicyPolicyDefinitionVariables | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAutomatedReasoningPolicyPolicyDefinitionVariables | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionVariablesList extends cdktn.ComplexList {
    internalValue?: BedrockAutomatedReasoningPolicyPolicyDefinitionVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAutomatedReasoningPolicyPolicyDefinitionVariablesOutputReference;
}
export interface BedrockAutomatedReasoningPolicyPolicyDefinition {
    /**
    * The rules definition block of an AutomatedReasoningPolicyDefinition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#rules BedrockAutomatedReasoningPolicy#rules}
    */
    readonly rules?: BedrockAutomatedReasoningPolicyPolicyDefinitionRules[] | cdktn.IResolvable;
    /**
    * The types definition block of an AutomatedReasoningPolicyDefinition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#types BedrockAutomatedReasoningPolicy#types}
    */
    readonly types?: BedrockAutomatedReasoningPolicyPolicyDefinitionTypes[] | cdktn.IResolvable;
    /**
    * The variables definition block of an AutomatedReasoningPolicyDefinition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#variables BedrockAutomatedReasoningPolicy#variables}
    */
    readonly variables?: BedrockAutomatedReasoningPolicyPolicyDefinitionVariables[] | cdktn.IResolvable;
    /**
    * The policy format version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#version BedrockAutomatedReasoningPolicy#version}
    */
    readonly version?: string;
}
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionToTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinition | cdktn.IResolvable): any;
export declare function bedrockAutomatedReasoningPolicyPolicyDefinitionToHclTerraform(struct?: BedrockAutomatedReasoningPolicyPolicyDefinition | cdktn.IResolvable): any;
export declare class BedrockAutomatedReasoningPolicyPolicyDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAutomatedReasoningPolicyPolicyDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAutomatedReasoningPolicyPolicyDefinition | cdktn.IResolvable | undefined);
    private _rules;
    get rules(): BedrockAutomatedReasoningPolicyPolicyDefinitionRulesList;
    putRules(value: BedrockAutomatedReasoningPolicyPolicyDefinitionRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | BedrockAutomatedReasoningPolicyPolicyDefinitionRules[] | undefined;
    private _types;
    get types(): BedrockAutomatedReasoningPolicyPolicyDefinitionTypesList;
    putTypes(value: BedrockAutomatedReasoningPolicyPolicyDefinitionTypes[] | cdktn.IResolvable): void;
    resetTypes(): void;
    get typesInput(): cdktn.IResolvable | BedrockAutomatedReasoningPolicyPolicyDefinitionTypes[] | undefined;
    private _variables;
    get variables(): BedrockAutomatedReasoningPolicyPolicyDefinitionVariablesList;
    putVariables(value: BedrockAutomatedReasoningPolicyPolicyDefinitionVariables[] | cdktn.IResolvable): void;
    resetVariables(): void;
    get variablesInput(): cdktn.IResolvable | BedrockAutomatedReasoningPolicyPolicyDefinitionVariables[] | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface BedrockAutomatedReasoningPolicyTags {
    /**
    * Tag Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#key BedrockAutomatedReasoningPolicy#key}
    */
    readonly key?: string;
    /**
    * Tag Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#value BedrockAutomatedReasoningPolicy#value}
    */
    readonly value?: string;
}
export declare function bedrockAutomatedReasoningPolicyTagsToTerraform(struct?: BedrockAutomatedReasoningPolicyTags | cdktn.IResolvable): any;
export declare function bedrockAutomatedReasoningPolicyTagsToHclTerraform(struct?: BedrockAutomatedReasoningPolicyTags | cdktn.IResolvable): any;
export declare class BedrockAutomatedReasoningPolicyTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAutomatedReasoningPolicyTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAutomatedReasoningPolicyTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockAutomatedReasoningPolicyTagsList extends cdktn.ComplexList {
    internalValue?: BedrockAutomatedReasoningPolicyTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAutomatedReasoningPolicyTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy awscc_bedrock_automated_reasoning_policy}
*/
export declare class BedrockAutomatedReasoningPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_automated_reasoning_policy";
    /**
    * Generates CDKTN code for importing a BedrockAutomatedReasoningPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockAutomatedReasoningPolicy to import
    * @param importFromId The id of the existing BedrockAutomatedReasoningPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockAutomatedReasoningPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_automated_reasoning_policy awscc_bedrock_automated_reasoning_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockAutomatedReasoningPolicyConfig
    */
    constructor(scope: Construct, id: string, config: BedrockAutomatedReasoningPolicyConfig);
    get createdAt(): string;
    get definitionHash(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get kmsKeyArn(): string;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyArn(): string;
    private _policyDefinition;
    get policyDefinition(): BedrockAutomatedReasoningPolicyPolicyDefinitionOutputReference;
    putPolicyDefinition(value: BedrockAutomatedReasoningPolicyPolicyDefinition): void;
    resetPolicyDefinition(): void;
    get policyDefinitionInput(): cdktn.IResolvable | BedrockAutomatedReasoningPolicyPolicyDefinition | undefined;
    get policyId(): string;
    private _tags;
    get tags(): BedrockAutomatedReasoningPolicyTagsList;
    putTags(value: BedrockAutomatedReasoningPolicyTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockAutomatedReasoningPolicyTags[] | undefined;
    get updatedAt(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
