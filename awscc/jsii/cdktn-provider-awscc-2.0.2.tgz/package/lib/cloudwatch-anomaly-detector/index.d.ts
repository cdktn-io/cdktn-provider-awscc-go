/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchAnomalyDetectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#configuration CloudwatchAnomalyDetector#configuration}
    */
    readonly configuration?: CloudwatchAnomalyDetectorConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#dimensions CloudwatchAnomalyDetector#dimensions}
    */
    readonly dimensions?: CloudwatchAnomalyDetectorDimensions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric_characteristics CloudwatchAnomalyDetector#metric_characteristics}
    */
    readonly metricCharacteristics?: CloudwatchAnomalyDetectorMetricCharacteristics;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric_math_anomaly_detector CloudwatchAnomalyDetector#metric_math_anomaly_detector}
    */
    readonly metricMathAnomalyDetector?: CloudwatchAnomalyDetectorMetricMathAnomalyDetector;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric_name CloudwatchAnomalyDetector#metric_name}
    */
    readonly metricName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#namespace CloudwatchAnomalyDetector#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#single_metric_anomaly_detector CloudwatchAnomalyDetector#single_metric_anomaly_detector}
    */
    readonly singleMetricAnomalyDetector?: CloudwatchAnomalyDetectorSingleMetricAnomalyDetector;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#stat CloudwatchAnomalyDetector#stat}
    */
    readonly stat?: string;
}
export interface CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#end_time CloudwatchAnomalyDetector#end_time}
    */
    readonly endTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#start_time CloudwatchAnomalyDetector#start_time}
    */
    readonly startTime?: string;
}
export declare function cloudwatchAnomalyDetectorConfigurationExcludedTimeRangesToTerraform(struct?: CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorConfigurationExcludedTimeRangesToHclTerraform(struct?: CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorConfigurationExcludedTimeRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export declare class CloudwatchAnomalyDetectorConfigurationExcludedTimeRangesList extends cdktn.ComplexList {
    internalValue?: CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAnomalyDetectorConfigurationExcludedTimeRangesOutputReference;
}
export interface CloudwatchAnomalyDetectorConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#excluded_time_ranges CloudwatchAnomalyDetector#excluded_time_ranges}
    */
    readonly excludedTimeRanges?: CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric_time_zone CloudwatchAnomalyDetector#metric_time_zone}
    */
    readonly metricTimeZone?: string;
}
export declare function cloudwatchAnomalyDetectorConfigurationToTerraform(struct?: CloudwatchAnomalyDetectorConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorConfigurationToHclTerraform(struct?: CloudwatchAnomalyDetectorConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAnomalyDetectorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorConfiguration | cdktn.IResolvable | undefined);
    private _excludedTimeRanges;
    get excludedTimeRanges(): CloudwatchAnomalyDetectorConfigurationExcludedTimeRangesList;
    putExcludedTimeRanges(value: CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges[] | cdktn.IResolvable): void;
    resetExcludedTimeRanges(): void;
    get excludedTimeRangesInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorConfigurationExcludedTimeRanges[] | undefined;
    private _metricTimeZone?;
    get metricTimeZone(): string;
    set metricTimeZone(value: string);
    resetMetricTimeZone(): void;
    get metricTimeZoneInput(): string | undefined;
}
export interface CloudwatchAnomalyDetectorDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#name CloudwatchAnomalyDetector#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#value CloudwatchAnomalyDetector#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAnomalyDetectorDimensionsToTerraform(struct?: CloudwatchAnomalyDetectorDimensions | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorDimensionsToHclTerraform(struct?: CloudwatchAnomalyDetectorDimensions | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAnomalyDetectorDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAnomalyDetectorDimensionsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAnomalyDetectorDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAnomalyDetectorDimensionsOutputReference;
}
export interface CloudwatchAnomalyDetectorMetricCharacteristics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#periodic_spikes CloudwatchAnomalyDetector#periodic_spikes}
    */
    readonly periodicSpikes?: boolean | cdktn.IResolvable;
}
export declare function cloudwatchAnomalyDetectorMetricCharacteristicsToTerraform(struct?: CloudwatchAnomalyDetectorMetricCharacteristics | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorMetricCharacteristicsToHclTerraform(struct?: CloudwatchAnomalyDetectorMetricCharacteristics | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorMetricCharacteristicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAnomalyDetectorMetricCharacteristics | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorMetricCharacteristics | cdktn.IResolvable | undefined);
    private _periodicSpikes?;
    get periodicSpikes(): boolean | cdktn.IResolvable;
    set periodicSpikes(value: boolean | cdktn.IResolvable);
    resetPeriodicSpikes(): void;
    get periodicSpikesInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#name CloudwatchAnomalyDetector#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#value CloudwatchAnomalyDetector#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensionsToTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensionsToHclTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensionsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensionsOutputReference;
}
export interface CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetric {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#dimensions CloudwatchAnomalyDetector#dimensions}
    */
    readonly dimensions?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric_name CloudwatchAnomalyDetector#metric_name}
    */
    readonly metricName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#namespace CloudwatchAnomalyDetector#namespace}
    */
    readonly namespace?: string;
}
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricToTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetric | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricToHclTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetric | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetric | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetric | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensionsList;
    putDimensions(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric CloudwatchAnomalyDetector#metric}
    */
    readonly metric?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetric;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#period CloudwatchAnomalyDetector#period}
    */
    readonly period?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#stat CloudwatchAnomalyDetector#stat}
    */
    readonly stat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#unit CloudwatchAnomalyDetector#unit}
    */
    readonly unit?: string;
}
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatToTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStat | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatToHclTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStat | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStat | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStat | cdktn.IResolvable | undefined);
    private _metric;
    get metric(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetricOutputReference;
    putMetric(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetric): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatMetric | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#account_id CloudwatchAnomalyDetector#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#expression CloudwatchAnomalyDetector#expression}
    */
    readonly expression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#id CloudwatchAnomalyDetector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#label CloudwatchAnomalyDetector#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric_stat CloudwatchAnomalyDetector#metric_stat}
    */
    readonly metricStat?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStat;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#period CloudwatchAnomalyDetector#period}
    */
    readonly period?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#return_data CloudwatchAnomalyDetector#return_data}
    */
    readonly returnData?: boolean | cdktn.IResolvable;
}
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesToTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesToHclTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _metricStat;
    get metricStat(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStatOutputReference;
    putMetricStat(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStat): void;
    resetMetricStat(): void;
    get metricStatInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesMetricStat | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _returnData?;
    get returnData(): boolean | cdktn.IResolvable;
    set returnData(value: boolean | cdktn.IResolvable);
    resetReturnData(): void;
    get returnDataInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesList extends cdktn.ComplexList {
    internalValue?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesOutputReference;
}
export interface CloudwatchAnomalyDetectorMetricMathAnomalyDetector {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric_data_queries CloudwatchAnomalyDetector#metric_data_queries}
    */
    readonly metricDataQueries?: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries[] | cdktn.IResolvable;
}
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorToTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetector | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorMetricMathAnomalyDetectorToHclTerraform(struct?: CloudwatchAnomalyDetectorMetricMathAnomalyDetector | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorMetricMathAnomalyDetectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAnomalyDetectorMetricMathAnomalyDetector | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetector | cdktn.IResolvable | undefined);
    private _metricDataQueries;
    get metricDataQueries(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueriesList;
    putMetricDataQueries(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries[] | cdktn.IResolvable): void;
    resetMetricDataQueries(): void;
    get metricDataQueriesInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorMetricMathAnomalyDetectorMetricDataQueries[] | undefined;
}
export interface CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#name CloudwatchAnomalyDetector#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#value CloudwatchAnomalyDetector#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensionsToTerraform(struct?: CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensionsToHclTerraform(struct?: CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensionsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensionsOutputReference;
}
export interface CloudwatchAnomalyDetectorSingleMetricAnomalyDetector {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#account_id CloudwatchAnomalyDetector#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#dimensions CloudwatchAnomalyDetector#dimensions}
    */
    readonly dimensions?: CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#metric_name CloudwatchAnomalyDetector#metric_name}
    */
    readonly metricName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#namespace CloudwatchAnomalyDetector#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#stat CloudwatchAnomalyDetector#stat}
    */
    readonly stat?: string;
}
export declare function cloudwatchAnomalyDetectorSingleMetricAnomalyDetectorToTerraform(struct?: CloudwatchAnomalyDetectorSingleMetricAnomalyDetector | cdktn.IResolvable): any;
export declare function cloudwatchAnomalyDetectorSingleMetricAnomalyDetectorToHclTerraform(struct?: CloudwatchAnomalyDetectorSingleMetricAnomalyDetector | cdktn.IResolvable): any;
export declare class CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAnomalyDetectorSingleMetricAnomalyDetector | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAnomalyDetectorSingleMetricAnomalyDetector | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _dimensions;
    get dimensions(): CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensionsList;
    putDimensions(value: CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector awscc_cloudwatch_anomaly_detector}
*/
export declare class CloudwatchAnomalyDetector extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_anomaly_detector";
    /**
    * Generates CDKTN code for importing a CloudwatchAnomalyDetector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchAnomalyDetector to import
    * @param importFromId The id of the existing CloudwatchAnomalyDetector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchAnomalyDetector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_anomaly_detector awscc_cloudwatch_anomaly_detector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchAnomalyDetectorConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudwatchAnomalyDetectorConfig);
    get anomalyDetectorId(): string;
    private _configuration;
    get configuration(): CloudwatchAnomalyDetectorConfigurationOutputReference;
    putConfiguration(value: CloudwatchAnomalyDetectorConfiguration): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorConfiguration | undefined;
    private _dimensions;
    get dimensions(): CloudwatchAnomalyDetectorDimensionsList;
    putDimensions(value: CloudwatchAnomalyDetectorDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorDimensions[] | undefined;
    get id(): string;
    private _metricCharacteristics;
    get metricCharacteristics(): CloudwatchAnomalyDetectorMetricCharacteristicsOutputReference;
    putMetricCharacteristics(value: CloudwatchAnomalyDetectorMetricCharacteristics): void;
    resetMetricCharacteristics(): void;
    get metricCharacteristicsInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorMetricCharacteristics | undefined;
    private _metricMathAnomalyDetector;
    get metricMathAnomalyDetector(): CloudwatchAnomalyDetectorMetricMathAnomalyDetectorOutputReference;
    putMetricMathAnomalyDetector(value: CloudwatchAnomalyDetectorMetricMathAnomalyDetector): void;
    resetMetricMathAnomalyDetector(): void;
    get metricMathAnomalyDetectorInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorMetricMathAnomalyDetector | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _singleMetricAnomalyDetector;
    get singleMetricAnomalyDetector(): CloudwatchAnomalyDetectorSingleMetricAnomalyDetectorOutputReference;
    putSingleMetricAnomalyDetector(value: CloudwatchAnomalyDetectorSingleMetricAnomalyDetector): void;
    resetSingleMetricAnomalyDetector(): void;
    get singleMetricAnomalyDetectorInput(): cdktn.IResolvable | CloudwatchAnomalyDetectorSingleMetricAnomalyDetector | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
