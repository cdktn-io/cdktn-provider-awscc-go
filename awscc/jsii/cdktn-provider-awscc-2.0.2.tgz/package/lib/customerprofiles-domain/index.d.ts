/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * The URL of the SQS dead letter queue
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain#dead_letter_queue_url CustomerprofilesDomain#dead_letter_queue_url}
    */
    readonly deadLetterQueueUrl?: string;
    /**
    * The default encryption key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain#default_encryption_key CustomerprofilesDomain#default_encryption_key}
    */
    readonly defaultEncryptionKey?: string;
    /**
    * The default number of days until the data within the domain expires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain#default_expiration_days CustomerprofilesDomain#default_expiration_days}
    */
    readonly defaultExpirationDays?: number;
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain#domain_name CustomerprofilesDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * The tags (keys and values) associated with the domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain#tags CustomerprofilesDomain#tags}
    */
    readonly tags?: CustomerprofilesDomainTags[] | cdktn.IResolvable;
}
export interface CustomerprofilesDomainTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain#key CustomerprofilesDomain#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain#value CustomerprofilesDomain#value}
    */
    readonly value?: string;
}
export declare function customerprofilesDomainTagsToTerraform(struct?: CustomerprofilesDomainTags | cdktn.IResolvable): any;
export declare function customerprofilesDomainTagsToHclTerraform(struct?: CustomerprofilesDomainTags | cdktn.IResolvable): any;
export declare class CustomerprofilesDomainTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesDomainTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesDomainTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesDomainTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesDomainTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesDomainTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain awscc_customerprofiles_domain}
*/
export declare class CustomerprofilesDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_domain";
    /**
    * Generates CDKTN code for importing a CustomerprofilesDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesDomain to import
    * @param importFromId The id of the existing CustomerprofilesDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_domain awscc_customerprofiles_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesDomainConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesDomainConfig);
    get createdAt(): string;
    private _deadLetterQueueUrl?;
    get deadLetterQueueUrl(): string;
    set deadLetterQueueUrl(value: string);
    resetDeadLetterQueueUrl(): void;
    get deadLetterQueueUrlInput(): string | undefined;
    private _defaultEncryptionKey?;
    get defaultEncryptionKey(): string;
    set defaultEncryptionKey(value: string);
    resetDefaultEncryptionKey(): void;
    get defaultEncryptionKeyInput(): string | undefined;
    private _defaultExpirationDays?;
    get defaultExpirationDays(): number;
    set defaultExpirationDays(value: number);
    resetDefaultExpirationDays(): void;
    get defaultExpirationDaysInput(): number | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    private _tags;
    get tags(): CustomerprofilesDomainTagsList;
    putTags(value: CustomerprofilesDomainTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesDomainTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
