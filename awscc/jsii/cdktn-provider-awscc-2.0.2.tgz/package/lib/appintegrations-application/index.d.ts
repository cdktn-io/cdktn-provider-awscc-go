/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppintegrationsApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The application configuration. Cannot be used when IsService is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#application_config AppintegrationsApplication#application_config}
    */
    readonly applicationConfig?: AppintegrationsApplicationApplicationConfig;
    /**
    * Application source config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#application_source_config AppintegrationsApplication#application_source_config}
    */
    readonly applicationSourceConfig: AppintegrationsApplicationApplicationSourceConfig;
    /**
    * The type of application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#application_type AppintegrationsApplication#application_type}
    */
    readonly applicationType?: string;
    /**
    * The application description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#description AppintegrationsApplication#description}
    */
    readonly description?: string;
    /**
    * The iframe configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#iframe_config AppintegrationsApplication#iframe_config}
    */
    readonly iframeConfig?: AppintegrationsApplicationIframeConfig;
    /**
    * The initialization timeout in milliseconds. Required when IsService is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#initialization_timeout AppintegrationsApplication#initialization_timeout}
    */
    readonly initializationTimeout?: number;
    /**
    * Indicates if the application is a service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#is_service AppintegrationsApplication#is_service}
    */
    readonly isService?: boolean | cdktn.IResolvable;
    /**
    * The name of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#name AppintegrationsApplication#name}
    */
    readonly name: string;
    /**
    * The namespace of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#namespace AppintegrationsApplication#namespace}
    */
    readonly namespace: string;
    /**
    * The configuration of events or requests that the application has access to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#permissions AppintegrationsApplication#permissions}
    */
    readonly permissions?: string[];
    /**
    * The tags (keys and values) associated with the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#tags AppintegrationsApplication#tags}
    */
    readonly tags?: AppintegrationsApplicationTags[] | cdktn.IResolvable;
}
export interface AppintegrationsApplicationApplicationConfigContactHandling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#scope AppintegrationsApplication#scope}
    */
    readonly scope?: string;
}
export declare function appintegrationsApplicationApplicationConfigContactHandlingToTerraform(struct?: AppintegrationsApplicationApplicationConfigContactHandling | cdktn.IResolvable): any;
export declare function appintegrationsApplicationApplicationConfigContactHandlingToHclTerraform(struct?: AppintegrationsApplicationApplicationConfigContactHandling | cdktn.IResolvable): any;
export declare class AppintegrationsApplicationApplicationConfigContactHandlingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppintegrationsApplicationApplicationConfigContactHandling | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsApplicationApplicationConfigContactHandling | cdktn.IResolvable | undefined);
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
}
export interface AppintegrationsApplicationApplicationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#contact_handling AppintegrationsApplication#contact_handling}
    */
    readonly contactHandling?: AppintegrationsApplicationApplicationConfigContactHandling;
}
export declare function appintegrationsApplicationApplicationConfigToTerraform(struct?: AppintegrationsApplicationApplicationConfig | cdktn.IResolvable): any;
export declare function appintegrationsApplicationApplicationConfigToHclTerraform(struct?: AppintegrationsApplicationApplicationConfig | cdktn.IResolvable): any;
export declare class AppintegrationsApplicationApplicationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppintegrationsApplicationApplicationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsApplicationApplicationConfig | cdktn.IResolvable | undefined);
    private _contactHandling;
    get contactHandling(): AppintegrationsApplicationApplicationConfigContactHandlingOutputReference;
    putContactHandling(value: AppintegrationsApplicationApplicationConfigContactHandling): void;
    resetContactHandling(): void;
    get contactHandlingInput(): cdktn.IResolvable | AppintegrationsApplicationApplicationConfigContactHandling | undefined;
}
export interface AppintegrationsApplicationApplicationSourceConfigExternalUrlConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#access_url AppintegrationsApplication#access_url}
    */
    readonly accessUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#approved_origins AppintegrationsApplication#approved_origins}
    */
    readonly approvedOrigins?: string[];
}
export declare function appintegrationsApplicationApplicationSourceConfigExternalUrlConfigToTerraform(struct?: AppintegrationsApplicationApplicationSourceConfigExternalUrlConfig | cdktn.IResolvable): any;
export declare function appintegrationsApplicationApplicationSourceConfigExternalUrlConfigToHclTerraform(struct?: AppintegrationsApplicationApplicationSourceConfigExternalUrlConfig | cdktn.IResolvable): any;
export declare class AppintegrationsApplicationApplicationSourceConfigExternalUrlConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppintegrationsApplicationApplicationSourceConfigExternalUrlConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsApplicationApplicationSourceConfigExternalUrlConfig | cdktn.IResolvable | undefined);
    private _accessUrl?;
    get accessUrl(): string;
    set accessUrl(value: string);
    get accessUrlInput(): string | undefined;
    private _approvedOrigins?;
    get approvedOrigins(): string[];
    set approvedOrigins(value: string[]);
    resetApprovedOrigins(): void;
    get approvedOriginsInput(): string[] | undefined;
}
export interface AppintegrationsApplicationApplicationSourceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#external_url_config AppintegrationsApplication#external_url_config}
    */
    readonly externalUrlConfig: AppintegrationsApplicationApplicationSourceConfigExternalUrlConfig;
}
export declare function appintegrationsApplicationApplicationSourceConfigToTerraform(struct?: AppintegrationsApplicationApplicationSourceConfig | cdktn.IResolvable): any;
export declare function appintegrationsApplicationApplicationSourceConfigToHclTerraform(struct?: AppintegrationsApplicationApplicationSourceConfig | cdktn.IResolvable): any;
export declare class AppintegrationsApplicationApplicationSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppintegrationsApplicationApplicationSourceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsApplicationApplicationSourceConfig | cdktn.IResolvable | undefined);
    private _externalUrlConfig;
    get externalUrlConfig(): AppintegrationsApplicationApplicationSourceConfigExternalUrlConfigOutputReference;
    putExternalUrlConfig(value: AppintegrationsApplicationApplicationSourceConfigExternalUrlConfig): void;
    get externalUrlConfigInput(): cdktn.IResolvable | AppintegrationsApplicationApplicationSourceConfigExternalUrlConfig | undefined;
}
export interface AppintegrationsApplicationIframeConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#allow AppintegrationsApplication#allow}
    */
    readonly allow?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#sandbox AppintegrationsApplication#sandbox}
    */
    readonly sandbox?: string[];
}
export declare function appintegrationsApplicationIframeConfigToTerraform(struct?: AppintegrationsApplicationIframeConfig | cdktn.IResolvable): any;
export declare function appintegrationsApplicationIframeConfigToHclTerraform(struct?: AppintegrationsApplicationIframeConfig | cdktn.IResolvable): any;
export declare class AppintegrationsApplicationIframeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppintegrationsApplicationIframeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsApplicationIframeConfig | cdktn.IResolvable | undefined);
    private _allow?;
    get allow(): string[];
    set allow(value: string[]);
    resetAllow(): void;
    get allowInput(): string[] | undefined;
    private _sandbox?;
    get sandbox(): string[];
    set sandbox(value: string[]);
    resetSandbox(): void;
    get sandboxInput(): string[] | undefined;
}
export interface AppintegrationsApplicationTags {
    /**
    * A key to identify the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#key AppintegrationsApplication#key}
    */
    readonly key?: string;
    /**
    * Corresponding tag value for the key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#value AppintegrationsApplication#value}
    */
    readonly value?: string;
}
export declare function appintegrationsApplicationTagsToTerraform(struct?: AppintegrationsApplicationTags | cdktn.IResolvable): any;
export declare function appintegrationsApplicationTagsToHclTerraform(struct?: AppintegrationsApplicationTags | cdktn.IResolvable): any;
export declare class AppintegrationsApplicationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppintegrationsApplicationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppintegrationsApplicationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppintegrationsApplicationTagsList extends cdktn.ComplexList {
    internalValue?: AppintegrationsApplicationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppintegrationsApplicationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application awscc_appintegrations_application}
*/
export declare class AppintegrationsApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appintegrations_application";
    /**
    * Generates CDKTN code for importing a AppintegrationsApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppintegrationsApplication to import
    * @param importFromId The id of the existing AppintegrationsApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppintegrationsApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appintegrations_application awscc_appintegrations_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppintegrationsApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AppintegrationsApplicationConfig);
    get applicationArn(): string;
    private _applicationConfig;
    get applicationConfig(): AppintegrationsApplicationApplicationConfigOutputReference;
    putApplicationConfig(value: AppintegrationsApplicationApplicationConfig): void;
    resetApplicationConfig(): void;
    get applicationConfigInput(): cdktn.IResolvable | AppintegrationsApplicationApplicationConfig | undefined;
    get applicationId(): string;
    private _applicationSourceConfig;
    get applicationSourceConfig(): AppintegrationsApplicationApplicationSourceConfigOutputReference;
    putApplicationSourceConfig(value: AppintegrationsApplicationApplicationSourceConfig): void;
    get applicationSourceConfigInput(): cdktn.IResolvable | AppintegrationsApplicationApplicationSourceConfig | undefined;
    private _applicationType?;
    get applicationType(): string;
    set applicationType(value: string);
    resetApplicationType(): void;
    get applicationTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _iframeConfig;
    get iframeConfig(): AppintegrationsApplicationIframeConfigOutputReference;
    putIframeConfig(value: AppintegrationsApplicationIframeConfig): void;
    resetIframeConfig(): void;
    get iframeConfigInput(): cdktn.IResolvable | AppintegrationsApplicationIframeConfig | undefined;
    private _initializationTimeout?;
    get initializationTimeout(): number;
    set initializationTimeout(value: number);
    resetInitializationTimeout(): void;
    get initializationTimeoutInput(): number | undefined;
    private _isService?;
    get isService(): boolean | cdktn.IResolvable;
    set isService(value: boolean | cdktn.IResolvable);
    resetIsService(): void;
    get isServiceInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    resetPermissions(): void;
    get permissionsInput(): string[] | undefined;
    private _tags;
    get tags(): AppintegrationsApplicationTagsList;
    putTags(value: AppintegrationsApplicationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppintegrationsApplicationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
