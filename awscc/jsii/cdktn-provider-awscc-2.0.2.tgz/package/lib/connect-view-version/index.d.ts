/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectViewVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description for the view version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_view_version#version_description ConnectViewVersion#version_description}
    */
    readonly versionDescription?: string;
    /**
    * The Amazon Resource Name (ARN) of the view for which a version is being created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_view_version#view_arn ConnectViewVersion#view_arn}
    */
    readonly viewArn: string;
    /**
    * The view content hash to be checked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_view_version#view_content_sha_256 ConnectViewVersion#view_content_sha_256}
    */
    readonly viewContentSha256?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_view_version awscc_connect_view_version}
*/
export declare class ConnectViewVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_view_version";
    /**
    * Generates CDKTN code for importing a ConnectViewVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectViewVersion to import
    * @param importFromId The id of the existing ConnectViewVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_view_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectViewVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_view_version awscc_connect_view_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectViewVersionConfig
    */
    constructor(scope: Construct, id: string, config: ConnectViewVersionConfig);
    get id(): string;
    get version(): number;
    private _versionDescription?;
    get versionDescription(): string;
    set versionDescription(value: string);
    resetVersionDescription(): void;
    get versionDescriptionInput(): string | undefined;
    private _viewArn?;
    get viewArn(): string;
    set viewArn(value: string);
    get viewArnInput(): string | undefined;
    private _viewContentSha256?;
    get viewContentSha256(): string;
    set viewContentSha256(value: string);
    resetViewContentSha256(): void;
    get viewContentSha256Input(): string | undefined;
    get viewVersionArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
