/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectWorkspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource ARNs associated with the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#associations ConnectWorkspace#associations}
    */
    readonly associations?: string[];
    /**
    * The description of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#description ConnectWorkspace#description}
    */
    readonly description?: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#instance_arn ConnectWorkspace#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The media items for the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#media ConnectWorkspace#media}
    */
    readonly media?: ConnectWorkspaceMedia[] | cdktn.IResolvable;
    /**
    * The name of the workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#name ConnectWorkspace#name}
    */
    readonly name: string;
    /**
    * The pages associated with the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#pages ConnectWorkspace#pages}
    */
    readonly pages?: ConnectWorkspacePages[] | cdktn.IResolvable;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#tags ConnectWorkspace#tags}
    */
    readonly tags?: ConnectWorkspaceTags[] | cdktn.IResolvable;
    /**
    * The theme configuration for the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#theme ConnectWorkspace#theme}
    */
    readonly theme?: ConnectWorkspaceTheme;
    /**
    * The title of the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#title ConnectWorkspace#title}
    */
    readonly title?: string;
    /**
    * The visibility of the workspace. Will always be set to ASSIGNED oninitial creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#visibility ConnectWorkspace#visibility}
    */
    readonly visibility?: string;
}
export interface ConnectWorkspaceMedia {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#source ConnectWorkspace#source}
    */
    readonly source?: string;
    /**
    * The type of media
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#type ConnectWorkspace#type}
    */
    readonly type?: string;
}
export declare function connectWorkspaceMediaToTerraform(struct?: ConnectWorkspaceMedia | cdktn.IResolvable): any;
export declare function connectWorkspaceMediaToHclTerraform(struct?: ConnectWorkspaceMedia | cdktn.IResolvable): any;
export declare class ConnectWorkspaceMediaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectWorkspaceMedia | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceMedia | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ConnectWorkspaceMediaList extends cdktn.ComplexList {
    internalValue?: ConnectWorkspaceMedia[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectWorkspaceMediaOutputReference;
}
export interface ConnectWorkspacePages {
    /**
    * The input data for the page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#input_data ConnectWorkspace#input_data}
    */
    readonly inputData?: string;
    /**
    * The page identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#page ConnectWorkspace#page}
    */
    readonly page?: string;
    /**
    * The Amazon Resource Name (ARN) of the resource associated with the page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#resource_arn ConnectWorkspace#resource_arn}
    */
    readonly resourceArn?: string;
    /**
    * The slug for the page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#slug ConnectWorkspace#slug}
    */
    readonly slug?: string;
}
export declare function connectWorkspacePagesToTerraform(struct?: ConnectWorkspacePages | cdktn.IResolvable): any;
export declare function connectWorkspacePagesToHclTerraform(struct?: ConnectWorkspacePages | cdktn.IResolvable): any;
export declare class ConnectWorkspacePagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectWorkspacePages | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspacePages | cdktn.IResolvable | undefined);
    private _inputData?;
    get inputData(): string;
    set inputData(value: string);
    resetInputData(): void;
    get inputDataInput(): string | undefined;
    private _page?;
    get page(): string;
    set page(value: string);
    resetPage(): void;
    get pageInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    resetResourceArn(): void;
    get resourceArnInput(): string | undefined;
    private _slug?;
    get slug(): string;
    set slug(value: string);
    resetSlug(): void;
    get slugInput(): string | undefined;
}
export declare class ConnectWorkspacePagesList extends cdktn.ComplexList {
    internalValue?: ConnectWorkspacePages[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectWorkspacePagesOutputReference;
}
export interface ConnectWorkspaceTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#key ConnectWorkspace#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#value ConnectWorkspace#value}
    */
    readonly value?: string;
}
export declare function connectWorkspaceTagsToTerraform(struct?: ConnectWorkspaceTags | cdktn.IResolvable): any;
export declare function connectWorkspaceTagsToHclTerraform(struct?: ConnectWorkspaceTags | cdktn.IResolvable): any;
export declare class ConnectWorkspaceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectWorkspaceTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectWorkspaceTagsList extends cdktn.ComplexList {
    internalValue?: ConnectWorkspaceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectWorkspaceTagsOutputReference;
}
export interface ConnectWorkspaceThemeDarkPaletteCanvas {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#active_background ConnectWorkspace#active_background}
    */
    readonly activeBackground?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#container_background ConnectWorkspace#container_background}
    */
    readonly containerBackground?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#page_background ConnectWorkspace#page_background}
    */
    readonly pageBackground?: string;
}
export declare function connectWorkspaceThemeDarkPaletteCanvasToTerraform(struct?: ConnectWorkspaceThemeDarkPaletteCanvas | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeDarkPaletteCanvasToHclTerraform(struct?: ConnectWorkspaceThemeDarkPaletteCanvas | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeDarkPaletteCanvasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeDarkPaletteCanvas | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeDarkPaletteCanvas | cdktn.IResolvable | undefined);
    private _activeBackground?;
    get activeBackground(): string;
    set activeBackground(value: string);
    resetActiveBackground(): void;
    get activeBackgroundInput(): string | undefined;
    private _containerBackground?;
    get containerBackground(): string;
    set containerBackground(value: string);
    resetContainerBackground(): void;
    get containerBackgroundInput(): string | undefined;
    private _pageBackground?;
    get pageBackground(): string;
    set pageBackground(value: string);
    resetPageBackground(): void;
    get pageBackgroundInput(): string | undefined;
}
export interface ConnectWorkspaceThemeDarkPaletteHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#background ConnectWorkspace#background}
    */
    readonly background?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#invert_actions_colors ConnectWorkspace#invert_actions_colors}
    */
    readonly invertActionsColors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text ConnectWorkspace#text}
    */
    readonly text?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_hover ConnectWorkspace#text_hover}
    */
    readonly textHover?: string;
}
export declare function connectWorkspaceThemeDarkPaletteHeaderToTerraform(struct?: ConnectWorkspaceThemeDarkPaletteHeader | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeDarkPaletteHeaderToHclTerraform(struct?: ConnectWorkspaceThemeDarkPaletteHeader | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeDarkPaletteHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeDarkPaletteHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeDarkPaletteHeader | cdktn.IResolvable | undefined);
    private _background?;
    get background(): string;
    set background(value: string);
    resetBackground(): void;
    get backgroundInput(): string | undefined;
    private _invertActionsColors?;
    get invertActionsColors(): boolean | cdktn.IResolvable;
    set invertActionsColors(value: boolean | cdktn.IResolvable);
    resetInvertActionsColors(): void;
    get invertActionsColorsInput(): boolean | cdktn.IResolvable | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _textHover?;
    get textHover(): string;
    set textHover(value: string);
    resetTextHover(): void;
    get textHoverInput(): string | undefined;
}
export interface ConnectWorkspaceThemeDarkPaletteNavigation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#background ConnectWorkspace#background}
    */
    readonly background?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#invert_actions_colors ConnectWorkspace#invert_actions_colors}
    */
    readonly invertActionsColors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text ConnectWorkspace#text}
    */
    readonly text?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_active ConnectWorkspace#text_active}
    */
    readonly textActive?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_background_active ConnectWorkspace#text_background_active}
    */
    readonly textBackgroundActive?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_background_hover ConnectWorkspace#text_background_hover}
    */
    readonly textBackgroundHover?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_hover ConnectWorkspace#text_hover}
    */
    readonly textHover?: string;
}
export declare function connectWorkspaceThemeDarkPaletteNavigationToTerraform(struct?: ConnectWorkspaceThemeDarkPaletteNavigation | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeDarkPaletteNavigationToHclTerraform(struct?: ConnectWorkspaceThemeDarkPaletteNavigation | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeDarkPaletteNavigationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeDarkPaletteNavigation | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeDarkPaletteNavigation | cdktn.IResolvable | undefined);
    private _background?;
    get background(): string;
    set background(value: string);
    resetBackground(): void;
    get backgroundInput(): string | undefined;
    private _invertActionsColors?;
    get invertActionsColors(): boolean | cdktn.IResolvable;
    set invertActionsColors(value: boolean | cdktn.IResolvable);
    resetInvertActionsColors(): void;
    get invertActionsColorsInput(): boolean | cdktn.IResolvable | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _textActive?;
    get textActive(): string;
    set textActive(value: string);
    resetTextActive(): void;
    get textActiveInput(): string | undefined;
    private _textBackgroundActive?;
    get textBackgroundActive(): string;
    set textBackgroundActive(value: string);
    resetTextBackgroundActive(): void;
    get textBackgroundActiveInput(): string | undefined;
    private _textBackgroundHover?;
    get textBackgroundHover(): string;
    set textBackgroundHover(value: string);
    resetTextBackgroundHover(): void;
    get textBackgroundHoverInput(): string | undefined;
    private _textHover?;
    get textHover(): string;
    set textHover(value: string);
    resetTextHover(): void;
    get textHoverInput(): string | undefined;
}
export interface ConnectWorkspaceThemeDarkPalettePrimary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#active ConnectWorkspace#active}
    */
    readonly active?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#contrast_text ConnectWorkspace#contrast_text}
    */
    readonly contrastText?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#default ConnectWorkspace#default}
    */
    readonly default?: string;
}
export declare function connectWorkspaceThemeDarkPalettePrimaryToTerraform(struct?: ConnectWorkspaceThemeDarkPalettePrimary | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeDarkPalettePrimaryToHclTerraform(struct?: ConnectWorkspaceThemeDarkPalettePrimary | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeDarkPalettePrimaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeDarkPalettePrimary | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeDarkPalettePrimary | cdktn.IResolvable | undefined);
    private _active?;
    get active(): string;
    set active(value: string);
    resetActive(): void;
    get activeInput(): string | undefined;
    private _contrastText?;
    get contrastText(): string;
    set contrastText(value: string);
    resetContrastText(): void;
    get contrastTextInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
export interface ConnectWorkspaceThemeDarkPalette {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#canvas ConnectWorkspace#canvas}
    */
    readonly canvas?: ConnectWorkspaceThemeDarkPaletteCanvas;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#header ConnectWorkspace#header}
    */
    readonly header?: ConnectWorkspaceThemeDarkPaletteHeader;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#navigation ConnectWorkspace#navigation}
    */
    readonly navigation?: ConnectWorkspaceThemeDarkPaletteNavigation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#primary ConnectWorkspace#primary}
    */
    readonly primary?: ConnectWorkspaceThemeDarkPalettePrimary;
}
export declare function connectWorkspaceThemeDarkPaletteToTerraform(struct?: ConnectWorkspaceThemeDarkPalette | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeDarkPaletteToHclTerraform(struct?: ConnectWorkspaceThemeDarkPalette | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeDarkPaletteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeDarkPalette | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeDarkPalette | cdktn.IResolvable | undefined);
    private _canvas;
    get canvas(): ConnectWorkspaceThemeDarkPaletteCanvasOutputReference;
    putCanvas(value: ConnectWorkspaceThemeDarkPaletteCanvas): void;
    resetCanvas(): void;
    get canvasInput(): cdktn.IResolvable | ConnectWorkspaceThemeDarkPaletteCanvas | undefined;
    private _header;
    get header(): ConnectWorkspaceThemeDarkPaletteHeaderOutputReference;
    putHeader(value: ConnectWorkspaceThemeDarkPaletteHeader): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | ConnectWorkspaceThemeDarkPaletteHeader | undefined;
    private _navigation;
    get navigation(): ConnectWorkspaceThemeDarkPaletteNavigationOutputReference;
    putNavigation(value: ConnectWorkspaceThemeDarkPaletteNavigation): void;
    resetNavigation(): void;
    get navigationInput(): cdktn.IResolvable | ConnectWorkspaceThemeDarkPaletteNavigation | undefined;
    private _primary;
    get primary(): ConnectWorkspaceThemeDarkPalettePrimaryOutputReference;
    putPrimary(value: ConnectWorkspaceThemeDarkPalettePrimary): void;
    resetPrimary(): void;
    get primaryInput(): cdktn.IResolvable | ConnectWorkspaceThemeDarkPalettePrimary | undefined;
}
export interface ConnectWorkspaceThemeDarkTypographyFontFamily {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#default ConnectWorkspace#default}
    */
    readonly default?: string;
}
export declare function connectWorkspaceThemeDarkTypographyFontFamilyToTerraform(struct?: ConnectWorkspaceThemeDarkTypographyFontFamily | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeDarkTypographyFontFamilyToHclTerraform(struct?: ConnectWorkspaceThemeDarkTypographyFontFamily | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeDarkTypographyFontFamilyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeDarkTypographyFontFamily | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeDarkTypographyFontFamily | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
export interface ConnectWorkspaceThemeDarkTypography {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#font_family ConnectWorkspace#font_family}
    */
    readonly fontFamily?: ConnectWorkspaceThemeDarkTypographyFontFamily;
}
export declare function connectWorkspaceThemeDarkTypographyToTerraform(struct?: ConnectWorkspaceThemeDarkTypography | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeDarkTypographyToHclTerraform(struct?: ConnectWorkspaceThemeDarkTypography | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeDarkTypographyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeDarkTypography | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeDarkTypography | cdktn.IResolvable | undefined);
    private _fontFamily;
    get fontFamily(): ConnectWorkspaceThemeDarkTypographyFontFamilyOutputReference;
    putFontFamily(value: ConnectWorkspaceThemeDarkTypographyFontFamily): void;
    resetFontFamily(): void;
    get fontFamilyInput(): cdktn.IResolvable | ConnectWorkspaceThemeDarkTypographyFontFamily | undefined;
}
export interface ConnectWorkspaceThemeDark {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#palette ConnectWorkspace#palette}
    */
    readonly palette?: ConnectWorkspaceThemeDarkPalette;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#typography ConnectWorkspace#typography}
    */
    readonly typography?: ConnectWorkspaceThemeDarkTypography;
}
export declare function connectWorkspaceThemeDarkToTerraform(struct?: ConnectWorkspaceThemeDark | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeDarkToHclTerraform(struct?: ConnectWorkspaceThemeDark | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeDarkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeDark | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeDark | cdktn.IResolvable | undefined);
    private _palette;
    get palette(): ConnectWorkspaceThemeDarkPaletteOutputReference;
    putPalette(value: ConnectWorkspaceThemeDarkPalette): void;
    resetPalette(): void;
    get paletteInput(): cdktn.IResolvable | ConnectWorkspaceThemeDarkPalette | undefined;
    private _typography;
    get typography(): ConnectWorkspaceThemeDarkTypographyOutputReference;
    putTypography(value: ConnectWorkspaceThemeDarkTypography): void;
    resetTypography(): void;
    get typographyInput(): cdktn.IResolvable | ConnectWorkspaceThemeDarkTypography | undefined;
}
export interface ConnectWorkspaceThemeLightPaletteCanvas {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#active_background ConnectWorkspace#active_background}
    */
    readonly activeBackground?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#container_background ConnectWorkspace#container_background}
    */
    readonly containerBackground?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#page_background ConnectWorkspace#page_background}
    */
    readonly pageBackground?: string;
}
export declare function connectWorkspaceThemeLightPaletteCanvasToTerraform(struct?: ConnectWorkspaceThemeLightPaletteCanvas | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeLightPaletteCanvasToHclTerraform(struct?: ConnectWorkspaceThemeLightPaletteCanvas | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeLightPaletteCanvasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeLightPaletteCanvas | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeLightPaletteCanvas | cdktn.IResolvable | undefined);
    private _activeBackground?;
    get activeBackground(): string;
    set activeBackground(value: string);
    resetActiveBackground(): void;
    get activeBackgroundInput(): string | undefined;
    private _containerBackground?;
    get containerBackground(): string;
    set containerBackground(value: string);
    resetContainerBackground(): void;
    get containerBackgroundInput(): string | undefined;
    private _pageBackground?;
    get pageBackground(): string;
    set pageBackground(value: string);
    resetPageBackground(): void;
    get pageBackgroundInput(): string | undefined;
}
export interface ConnectWorkspaceThemeLightPaletteHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#background ConnectWorkspace#background}
    */
    readonly background?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#invert_actions_colors ConnectWorkspace#invert_actions_colors}
    */
    readonly invertActionsColors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text ConnectWorkspace#text}
    */
    readonly text?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_hover ConnectWorkspace#text_hover}
    */
    readonly textHover?: string;
}
export declare function connectWorkspaceThemeLightPaletteHeaderToTerraform(struct?: ConnectWorkspaceThemeLightPaletteHeader | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeLightPaletteHeaderToHclTerraform(struct?: ConnectWorkspaceThemeLightPaletteHeader | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeLightPaletteHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeLightPaletteHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeLightPaletteHeader | cdktn.IResolvable | undefined);
    private _background?;
    get background(): string;
    set background(value: string);
    resetBackground(): void;
    get backgroundInput(): string | undefined;
    private _invertActionsColors?;
    get invertActionsColors(): boolean | cdktn.IResolvable;
    set invertActionsColors(value: boolean | cdktn.IResolvable);
    resetInvertActionsColors(): void;
    get invertActionsColorsInput(): boolean | cdktn.IResolvable | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _textHover?;
    get textHover(): string;
    set textHover(value: string);
    resetTextHover(): void;
    get textHoverInput(): string | undefined;
}
export interface ConnectWorkspaceThemeLightPaletteNavigation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#background ConnectWorkspace#background}
    */
    readonly background?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#invert_actions_colors ConnectWorkspace#invert_actions_colors}
    */
    readonly invertActionsColors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text ConnectWorkspace#text}
    */
    readonly text?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_active ConnectWorkspace#text_active}
    */
    readonly textActive?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_background_active ConnectWorkspace#text_background_active}
    */
    readonly textBackgroundActive?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_background_hover ConnectWorkspace#text_background_hover}
    */
    readonly textBackgroundHover?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#text_hover ConnectWorkspace#text_hover}
    */
    readonly textHover?: string;
}
export declare function connectWorkspaceThemeLightPaletteNavigationToTerraform(struct?: ConnectWorkspaceThemeLightPaletteNavigation | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeLightPaletteNavigationToHclTerraform(struct?: ConnectWorkspaceThemeLightPaletteNavigation | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeLightPaletteNavigationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeLightPaletteNavigation | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeLightPaletteNavigation | cdktn.IResolvable | undefined);
    private _background?;
    get background(): string;
    set background(value: string);
    resetBackground(): void;
    get backgroundInput(): string | undefined;
    private _invertActionsColors?;
    get invertActionsColors(): boolean | cdktn.IResolvable;
    set invertActionsColors(value: boolean | cdktn.IResolvable);
    resetInvertActionsColors(): void;
    get invertActionsColorsInput(): boolean | cdktn.IResolvable | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _textActive?;
    get textActive(): string;
    set textActive(value: string);
    resetTextActive(): void;
    get textActiveInput(): string | undefined;
    private _textBackgroundActive?;
    get textBackgroundActive(): string;
    set textBackgroundActive(value: string);
    resetTextBackgroundActive(): void;
    get textBackgroundActiveInput(): string | undefined;
    private _textBackgroundHover?;
    get textBackgroundHover(): string;
    set textBackgroundHover(value: string);
    resetTextBackgroundHover(): void;
    get textBackgroundHoverInput(): string | undefined;
    private _textHover?;
    get textHover(): string;
    set textHover(value: string);
    resetTextHover(): void;
    get textHoverInput(): string | undefined;
}
export interface ConnectWorkspaceThemeLightPalettePrimary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#active ConnectWorkspace#active}
    */
    readonly active?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#contrast_text ConnectWorkspace#contrast_text}
    */
    readonly contrastText?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#default ConnectWorkspace#default}
    */
    readonly default?: string;
}
export declare function connectWorkspaceThemeLightPalettePrimaryToTerraform(struct?: ConnectWorkspaceThemeLightPalettePrimary | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeLightPalettePrimaryToHclTerraform(struct?: ConnectWorkspaceThemeLightPalettePrimary | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeLightPalettePrimaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeLightPalettePrimary | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeLightPalettePrimary | cdktn.IResolvable | undefined);
    private _active?;
    get active(): string;
    set active(value: string);
    resetActive(): void;
    get activeInput(): string | undefined;
    private _contrastText?;
    get contrastText(): string;
    set contrastText(value: string);
    resetContrastText(): void;
    get contrastTextInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
export interface ConnectWorkspaceThemeLightPalette {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#canvas ConnectWorkspace#canvas}
    */
    readonly canvas?: ConnectWorkspaceThemeLightPaletteCanvas;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#header ConnectWorkspace#header}
    */
    readonly header?: ConnectWorkspaceThemeLightPaletteHeader;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#navigation ConnectWorkspace#navigation}
    */
    readonly navigation?: ConnectWorkspaceThemeLightPaletteNavigation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#primary ConnectWorkspace#primary}
    */
    readonly primary?: ConnectWorkspaceThemeLightPalettePrimary;
}
export declare function connectWorkspaceThemeLightPaletteToTerraform(struct?: ConnectWorkspaceThemeLightPalette | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeLightPaletteToHclTerraform(struct?: ConnectWorkspaceThemeLightPalette | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeLightPaletteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeLightPalette | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeLightPalette | cdktn.IResolvable | undefined);
    private _canvas;
    get canvas(): ConnectWorkspaceThemeLightPaletteCanvasOutputReference;
    putCanvas(value: ConnectWorkspaceThemeLightPaletteCanvas): void;
    resetCanvas(): void;
    get canvasInput(): cdktn.IResolvable | ConnectWorkspaceThemeLightPaletteCanvas | undefined;
    private _header;
    get header(): ConnectWorkspaceThemeLightPaletteHeaderOutputReference;
    putHeader(value: ConnectWorkspaceThemeLightPaletteHeader): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | ConnectWorkspaceThemeLightPaletteHeader | undefined;
    private _navigation;
    get navigation(): ConnectWorkspaceThemeLightPaletteNavigationOutputReference;
    putNavigation(value: ConnectWorkspaceThemeLightPaletteNavigation): void;
    resetNavigation(): void;
    get navigationInput(): cdktn.IResolvable | ConnectWorkspaceThemeLightPaletteNavigation | undefined;
    private _primary;
    get primary(): ConnectWorkspaceThemeLightPalettePrimaryOutputReference;
    putPrimary(value: ConnectWorkspaceThemeLightPalettePrimary): void;
    resetPrimary(): void;
    get primaryInput(): cdktn.IResolvable | ConnectWorkspaceThemeLightPalettePrimary | undefined;
}
export interface ConnectWorkspaceThemeLightTypographyFontFamily {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#default ConnectWorkspace#default}
    */
    readonly default?: string;
}
export declare function connectWorkspaceThemeLightTypographyFontFamilyToTerraform(struct?: ConnectWorkspaceThemeLightTypographyFontFamily | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeLightTypographyFontFamilyToHclTerraform(struct?: ConnectWorkspaceThemeLightTypographyFontFamily | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeLightTypographyFontFamilyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeLightTypographyFontFamily | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeLightTypographyFontFamily | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
export interface ConnectWorkspaceThemeLightTypography {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#font_family ConnectWorkspace#font_family}
    */
    readonly fontFamily?: ConnectWorkspaceThemeLightTypographyFontFamily;
}
export declare function connectWorkspaceThemeLightTypographyToTerraform(struct?: ConnectWorkspaceThemeLightTypography | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeLightTypographyToHclTerraform(struct?: ConnectWorkspaceThemeLightTypography | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeLightTypographyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeLightTypography | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeLightTypography | cdktn.IResolvable | undefined);
    private _fontFamily;
    get fontFamily(): ConnectWorkspaceThemeLightTypographyFontFamilyOutputReference;
    putFontFamily(value: ConnectWorkspaceThemeLightTypographyFontFamily): void;
    resetFontFamily(): void;
    get fontFamilyInput(): cdktn.IResolvable | ConnectWorkspaceThemeLightTypographyFontFamily | undefined;
}
export interface ConnectWorkspaceThemeLight {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#palette ConnectWorkspace#palette}
    */
    readonly palette?: ConnectWorkspaceThemeLightPalette;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#typography ConnectWorkspace#typography}
    */
    readonly typography?: ConnectWorkspaceThemeLightTypography;
}
export declare function connectWorkspaceThemeLightToTerraform(struct?: ConnectWorkspaceThemeLight | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeLightToHclTerraform(struct?: ConnectWorkspaceThemeLight | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeLightOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceThemeLight | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceThemeLight | cdktn.IResolvable | undefined);
    private _palette;
    get palette(): ConnectWorkspaceThemeLightPaletteOutputReference;
    putPalette(value: ConnectWorkspaceThemeLightPalette): void;
    resetPalette(): void;
    get paletteInput(): cdktn.IResolvable | ConnectWorkspaceThemeLightPalette | undefined;
    private _typography;
    get typography(): ConnectWorkspaceThemeLightTypographyOutputReference;
    putTypography(value: ConnectWorkspaceThemeLightTypography): void;
    resetTypography(): void;
    get typographyInput(): cdktn.IResolvable | ConnectWorkspaceThemeLightTypography | undefined;
}
export interface ConnectWorkspaceTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#dark ConnectWorkspace#dark}
    */
    readonly dark?: ConnectWorkspaceThemeDark;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#light ConnectWorkspace#light}
    */
    readonly light?: ConnectWorkspaceThemeLight;
}
export declare function connectWorkspaceThemeToTerraform(struct?: ConnectWorkspaceTheme | cdktn.IResolvable): any;
export declare function connectWorkspaceThemeToHclTerraform(struct?: ConnectWorkspaceTheme | cdktn.IResolvable): any;
export declare class ConnectWorkspaceThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectWorkspaceTheme | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectWorkspaceTheme | cdktn.IResolvable | undefined);
    private _dark;
    get dark(): ConnectWorkspaceThemeDarkOutputReference;
    putDark(value: ConnectWorkspaceThemeDark): void;
    resetDark(): void;
    get darkInput(): cdktn.IResolvable | ConnectWorkspaceThemeDark | undefined;
    private _light;
    get light(): ConnectWorkspaceThemeLightOutputReference;
    putLight(value: ConnectWorkspaceThemeLight): void;
    resetLight(): void;
    get lightInput(): cdktn.IResolvable | ConnectWorkspaceThemeLight | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace awscc_connect_workspace}
*/
export declare class ConnectWorkspace extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_workspace";
    /**
    * Generates CDKTN code for importing a ConnectWorkspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectWorkspace to import
    * @param importFromId The id of the existing ConnectWorkspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectWorkspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_workspace awscc_connect_workspace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectWorkspaceConfig
    */
    constructor(scope: Construct, id: string, config: ConnectWorkspaceConfig);
    get arn(): string;
    private _associations?;
    get associations(): string[];
    set associations(value: string[]);
    resetAssociations(): void;
    get associationsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _media;
    get media(): ConnectWorkspaceMediaList;
    putMedia(value: ConnectWorkspaceMedia[] | cdktn.IResolvable): void;
    resetMedia(): void;
    get mediaInput(): cdktn.IResolvable | ConnectWorkspaceMedia[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pages;
    get pages(): ConnectWorkspacePagesList;
    putPages(value: ConnectWorkspacePages[] | cdktn.IResolvable): void;
    resetPages(): void;
    get pagesInput(): cdktn.IResolvable | ConnectWorkspacePages[] | undefined;
    private _tags;
    get tags(): ConnectWorkspaceTagsList;
    putTags(value: ConnectWorkspaceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectWorkspaceTags[] | undefined;
    private _theme;
    get theme(): ConnectWorkspaceThemeOutputReference;
    putTheme(value: ConnectWorkspaceTheme): void;
    resetTheme(): void;
    get themeInput(): cdktn.IResolvable | ConnectWorkspaceTheme | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
    get workspaceId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
