/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayUsagePlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#api_stages ApigatewayUsagePlan#api_stages}
    */
    readonly apiStages?: ApigatewayUsagePlanApiStages[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#description ApigatewayUsagePlan#description}
    */
    readonly description?: string;
    /**
    * ``QuotaSettings`` is a property of the [AWS::ApiGateway::UsagePlan](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplan.html) resource that specifies a target for the maximum number of requests users can make to your REST APIs.
    *  In some cases clients can exceed the targets that you set. Don?t rely on usage plans to control costs. Consider using [](https://docs.aws.amazon.com/cost-management/latest/userguide/budgets-managing-costs.html) to monitor costs and [](https://docs.aws.amazon.com/waf/latest/developerguide/waf-chapter.html) to manage API requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#quota ApigatewayUsagePlan#quota}
    */
    readonly quota?: ApigatewayUsagePlanQuota;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#tags ApigatewayUsagePlan#tags}
    */
    readonly tags?: ApigatewayUsagePlanTags[] | cdktn.IResolvable;
    /**
    * ``ThrottleSettings`` is a property of the [AWS::ApiGateway::UsagePlan](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplan.html) resource that specifies the overall request rate (average requests per second) and burst capacity when users call your REST APIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#throttle ApigatewayUsagePlan#throttle}
    */
    readonly throttle?: ApigatewayUsagePlanThrottle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#usage_plan_name ApigatewayUsagePlan#usage_plan_name}
    */
    readonly usagePlanName?: string;
}
export interface ApigatewayUsagePlanApiStagesThrottle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#burst_limit ApigatewayUsagePlan#burst_limit}
    */
    readonly burstLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#rate_limit ApigatewayUsagePlan#rate_limit}
    */
    readonly rateLimit?: number;
}
export declare function apigatewayUsagePlanApiStagesThrottleToTerraform(struct?: ApigatewayUsagePlanApiStagesThrottle | cdktn.IResolvable): any;
export declare function apigatewayUsagePlanApiStagesThrottleToHclTerraform(struct?: ApigatewayUsagePlanApiStagesThrottle | cdktn.IResolvable): any;
export declare class ApigatewayUsagePlanApiStagesThrottleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): ApigatewayUsagePlanApiStagesThrottle | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayUsagePlanApiStagesThrottle | cdktn.IResolvable | undefined);
    private _burstLimit?;
    get burstLimit(): number;
    set burstLimit(value: number);
    resetBurstLimit(): void;
    get burstLimitInput(): number | undefined;
    private _rateLimit?;
    get rateLimit(): number;
    set rateLimit(value: number);
    resetRateLimit(): void;
    get rateLimitInput(): number | undefined;
}
export declare class ApigatewayUsagePlanApiStagesThrottleMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: ApigatewayUsagePlanApiStagesThrottle;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): ApigatewayUsagePlanApiStagesThrottleOutputReference;
}
export interface ApigatewayUsagePlanApiStages {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#api_id ApigatewayUsagePlan#api_id}
    */
    readonly apiId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#stage ApigatewayUsagePlan#stage}
    */
    readonly stage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#throttle ApigatewayUsagePlan#throttle}
    */
    readonly throttle?: {
        [key: string]: ApigatewayUsagePlanApiStagesThrottle;
    } | cdktn.IResolvable;
}
export declare function apigatewayUsagePlanApiStagesToTerraform(struct?: ApigatewayUsagePlanApiStages | cdktn.IResolvable): any;
export declare function apigatewayUsagePlanApiStagesToHclTerraform(struct?: ApigatewayUsagePlanApiStages | cdktn.IResolvable): any;
export declare class ApigatewayUsagePlanApiStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayUsagePlanApiStages | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayUsagePlanApiStages | cdktn.IResolvable | undefined);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    resetApiId(): void;
    get apiIdInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    resetStage(): void;
    get stageInput(): string | undefined;
    private _throttle;
    get throttle(): ApigatewayUsagePlanApiStagesThrottleMap;
    putThrottle(value: {
        [key: string]: ApigatewayUsagePlanApiStagesThrottle;
    } | cdktn.IResolvable): void;
    resetThrottle(): void;
    get throttleInput(): cdktn.IResolvable | {
        [key: string]: ApigatewayUsagePlanApiStagesThrottle;
    } | undefined;
}
export declare class ApigatewayUsagePlanApiStagesList extends cdktn.ComplexList {
    internalValue?: ApigatewayUsagePlanApiStages[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayUsagePlanApiStagesOutputReference;
}
export interface ApigatewayUsagePlanQuota {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#limit ApigatewayUsagePlan#limit}
    */
    readonly limit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#offset ApigatewayUsagePlan#offset}
    */
    readonly offset?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#period ApigatewayUsagePlan#period}
    */
    readonly period?: string;
}
export declare function apigatewayUsagePlanQuotaToTerraform(struct?: ApigatewayUsagePlanQuota | cdktn.IResolvable): any;
export declare function apigatewayUsagePlanQuotaToHclTerraform(struct?: ApigatewayUsagePlanQuota | cdktn.IResolvable): any;
export declare class ApigatewayUsagePlanQuotaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayUsagePlanQuota | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayUsagePlanQuota | cdktn.IResolvable | undefined);
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _offset?;
    get offset(): number;
    set offset(value: number);
    resetOffset(): void;
    get offsetInput(): number | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
}
export interface ApigatewayUsagePlanTags {
    /**
    * A string you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#key ApigatewayUsagePlan#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#value ApigatewayUsagePlan#value}
    */
    readonly value?: string;
}
export declare function apigatewayUsagePlanTagsToTerraform(struct?: ApigatewayUsagePlanTags | cdktn.IResolvable): any;
export declare function apigatewayUsagePlanTagsToHclTerraform(struct?: ApigatewayUsagePlanTags | cdktn.IResolvable): any;
export declare class ApigatewayUsagePlanTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayUsagePlanTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayUsagePlanTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigatewayUsagePlanTagsList extends cdktn.ComplexList {
    internalValue?: ApigatewayUsagePlanTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayUsagePlanTagsOutputReference;
}
export interface ApigatewayUsagePlanThrottle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#burst_limit ApigatewayUsagePlan#burst_limit}
    */
    readonly burstLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#rate_limit ApigatewayUsagePlan#rate_limit}
    */
    readonly rateLimit?: number;
}
export declare function apigatewayUsagePlanThrottleToTerraform(struct?: ApigatewayUsagePlanThrottle | cdktn.IResolvable): any;
export declare function apigatewayUsagePlanThrottleToHclTerraform(struct?: ApigatewayUsagePlanThrottle | cdktn.IResolvable): any;
export declare class ApigatewayUsagePlanThrottleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayUsagePlanThrottle | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayUsagePlanThrottle | cdktn.IResolvable | undefined);
    private _burstLimit?;
    get burstLimit(): number;
    set burstLimit(value: number);
    resetBurstLimit(): void;
    get burstLimitInput(): number | undefined;
    private _rateLimit?;
    get rateLimit(): number;
    set rateLimit(value: number);
    resetRateLimit(): void;
    get rateLimitInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan awscc_apigateway_usage_plan}
*/
export declare class ApigatewayUsagePlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_usage_plan";
    /**
    * Generates CDKTN code for importing a ApigatewayUsagePlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayUsagePlan to import
    * @param importFromId The id of the existing ApigatewayUsagePlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayUsagePlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_usage_plan awscc_apigateway_usage_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayUsagePlanConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApigatewayUsagePlanConfig);
    private _apiStages;
    get apiStages(): ApigatewayUsagePlanApiStagesList;
    putApiStages(value: ApigatewayUsagePlanApiStages[] | cdktn.IResolvable): void;
    resetApiStages(): void;
    get apiStagesInput(): cdktn.IResolvable | ApigatewayUsagePlanApiStages[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _quota;
    get quota(): ApigatewayUsagePlanQuotaOutputReference;
    putQuota(value: ApigatewayUsagePlanQuota): void;
    resetQuota(): void;
    get quotaInput(): cdktn.IResolvable | ApigatewayUsagePlanQuota | undefined;
    private _tags;
    get tags(): ApigatewayUsagePlanTagsList;
    putTags(value: ApigatewayUsagePlanTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApigatewayUsagePlanTags[] | undefined;
    private _throttle;
    get throttle(): ApigatewayUsagePlanThrottleOutputReference;
    putThrottle(value: ApigatewayUsagePlanThrottle): void;
    resetThrottle(): void;
    get throttleInput(): cdktn.IResolvable | ApigatewayUsagePlanThrottle | undefined;
    get usagePlanId(): string;
    private _usagePlanName?;
    get usagePlanName(): string;
    set usagePlanName(value: string);
    resetUsagePlanName(): void;
    get usagePlanNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
