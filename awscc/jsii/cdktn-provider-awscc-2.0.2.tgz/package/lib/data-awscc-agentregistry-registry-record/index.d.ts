/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAgentregistryRegistryRecordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/agentregistry_registry_record#id DataAwsccAgentregistryRegistryRecord#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | undefined);
    get region(): string;
    get roleArn(): string;
    get service(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | undefined);
    private _customParameters;
    get customParameters(): cdktn.StringMap;
    get grantType(): string;
    get providerArn(): string;
    get scopes(): string[];
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider | undefined);
    private _iamCredentialProvider;
    get iamCredentialProvider(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderOutputReference;
    private _oauthCredentialProvider;
    get oauthCredentialProvider(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations | undefined);
    private _credentialProvider;
    get credentialProvider(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOutputReference;
    get credentialProviderType(): string;
}
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl | undefined);
    private _credentialProviderConfigurations;
    get credentialProviderConfigurations(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsList;
    get url(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSource {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSource): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSource): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSource | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSource | undefined);
    private _fromUrl;
    get fromUrl(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCard {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCard): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCard): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCard | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCard | undefined);
    get data(): string;
    get dataSchemaVersion(): string;
    private _source;
    get source(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardSourceOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrlToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrlToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl | undefined);
    get url(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource | undefined);
    private _fromUrl;
    get fromUrl(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrlOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd | undefined);
    get data(): string;
    get dataSchemaVersion(): string;
    private _source;
    get source(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData | undefined);
    private _skillMd;
    get skillMd(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinition {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinition): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinition): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinition | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinition | undefined);
    private _additionalData;
    get additionalData(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataOutputReference;
    get data(): string;
    get dataSchemaVersion(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrl {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrlToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrl): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrlToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrl): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrl | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrl | undefined);
    get url(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsAguiSource {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAguiSource): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAguiSource): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsAguiSource | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsAguiSource | undefined);
    private _fromUrl;
    get fromUrl(): DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceFromUrlOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsAgui {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAguiToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgui): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsAguiToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsAgui): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsAguiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsAgui | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsAgui | undefined);
    private _source;
    get source(): DataAwsccAgentregistryRegistryRecordDescriptorsAguiSourceOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsCustom {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsCustomToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsCustom): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsCustomToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsCustom): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsCustom | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsCustom | undefined);
    get data(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrl {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrlToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrl): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrlToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrl): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrl | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrl | undefined);
    get url(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsHttpSource {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsHttpSource): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsHttpSource): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsHttpSource | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsHttpSource | undefined);
    private _fromUrl;
    get fromUrl(): DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceFromUrlOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsHttp {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsHttpToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsHttp): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsHttpToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsHttp): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsHttp | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsHttp | undefined);
    private _source;
    get source(): DataAwsccAgentregistryRegistryRecordDescriptorsHttpSourceOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToolsToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToolsToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools | undefined);
    get data(): string;
    get dataSchemaVersion(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalData {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalData): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalData): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalData | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalData | undefined);
    private _tools;
    get tools(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToolsOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | undefined);
    get region(): string;
    get roleArn(): string;
    get service(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | undefined);
    private _customParameters;
    get customParameters(): cdktn.StringMap;
    get grantType(): string;
    get providerArn(): string;
    get scopes(): string[];
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider | undefined);
    private _iamCredentialProvider;
    get iamCredentialProvider(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderOutputReference;
    private _oauthCredentialProvider;
    get oauthCredentialProvider(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations | undefined);
    private _credentialProvider;
    get credentialProvider(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOutputReference;
    get credentialProviderType(): string;
}
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl | undefined);
    private _credentialProviderConfigurations;
    get credentialProviderConfigurations(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsList;
    get url(): string;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSource {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSource): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSource): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSource | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSource | undefined);
    private _fromUrl;
    get fromUrl(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptorsMcpServer {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServer): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsMcpServerToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServer): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServer | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptorsMcpServer | undefined);
    private _additionalData;
    get additionalData(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataOutputReference;
    get data(): string;
    get dataSchemaVersion(): string;
    private _source;
    get source(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerSourceOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordDescriptors {
}
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsToTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptors): any;
export declare function dataAwsccAgentregistryRegistryRecordDescriptorsToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordDescriptors): any;
export declare class DataAwsccAgentregistryRegistryRecordDescriptorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAgentregistryRegistryRecordDescriptors | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordDescriptors | undefined);
    private _a2AAgentCard;
    get a2AAgentCard(): DataAwsccAgentregistryRegistryRecordDescriptorsA2AAgentCardOutputReference;
    private _agentSkillsDefinition;
    get agentSkillsDefinition(): DataAwsccAgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionOutputReference;
    private _agui;
    get agui(): DataAwsccAgentregistryRegistryRecordDescriptorsAguiOutputReference;
    private _custom;
    get custom(): DataAwsccAgentregistryRegistryRecordDescriptorsCustomOutputReference;
    private _http;
    get http(): DataAwsccAgentregistryRegistryRecordDescriptorsHttpOutputReference;
    private _mcpServer;
    get mcpServer(): DataAwsccAgentregistryRegistryRecordDescriptorsMcpServerOutputReference;
}
export interface DataAwsccAgentregistryRegistryRecordTags {
}
export declare function dataAwsccAgentregistryRegistryRecordTagsToTerraform(struct?: DataAwsccAgentregistryRegistryRecordTags): any;
export declare function dataAwsccAgentregistryRegistryRecordTagsToHclTerraform(struct?: DataAwsccAgentregistryRegistryRecordTags): any;
export declare class DataAwsccAgentregistryRegistryRecordTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAgentregistryRegistryRecordTags | undefined;
    set internalValue(value: DataAwsccAgentregistryRegistryRecordTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAgentregistryRegistryRecordTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAgentregistryRegistryRecordTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/agentregistry_registry_record awscc_agentregistry_registry_record}
*/
export declare class DataAwsccAgentregistryRegistryRecord extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_agentregistry_registry_record";
    /**
    * Generates CDKTN code for importing a DataAwsccAgentregistryRegistryRecord resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAgentregistryRegistryRecord to import
    * @param importFromId The id of the existing DataAwsccAgentregistryRegistryRecord that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/agentregistry_registry_record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAgentregistryRegistryRecord to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/agentregistry_registry_record awscc_agentregistry_registry_record} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAgentregistryRegistryRecordConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAgentregistryRegistryRecordConfig);
    get createdAt(): string;
    get createdBy(): string;
    get customMetadata(): string;
    get description(): string;
    private _descriptors;
    get descriptors(): DataAwsccAgentregistryRegistryRecordDescriptorsOutputReference;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    get recordArn(): string;
    get recordId(): string;
    get recordType(): string;
    get recordVersion(): string;
    get registryArn(): string;
    get registryId(): string;
    get status(): string;
    private _tags;
    get tags(): DataAwsccAgentregistryRegistryRecordTagsList;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
