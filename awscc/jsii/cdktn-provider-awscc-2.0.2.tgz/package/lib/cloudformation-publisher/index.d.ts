/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationPublisherConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether you accept the terms and conditions for publishing extensions in the CloudFormation registry. You must accept the terms and conditions in order to publish public extensions to the CloudFormation registry. The terms and conditions can be found at https://cloudformation-registry-documents.s3.amazonaws.com/Terms_and_Conditions_for_AWS_CloudFormation_Registry_Publishers.pdf
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_publisher#accept_terms_and_conditions CloudformationPublisher#accept_terms_and_conditions}
    */
    readonly acceptTermsAndConditions: boolean | cdktn.IResolvable;
    /**
    * If you are using a Bitbucket or GitHub account for identity verification, the Amazon Resource Name (ARN) for your connection to that account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_publisher#connection_arn CloudformationPublisher#connection_arn}
    */
    readonly connectionArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_publisher awscc_cloudformation_publisher}
*/
export declare class CloudformationPublisher extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_publisher";
    /**
    * Generates CDKTN code for importing a CloudformationPublisher resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationPublisher to import
    * @param importFromId The id of the existing CloudformationPublisher that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_publisher#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationPublisher to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudformation_publisher awscc_cloudformation_publisher} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationPublisherConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationPublisherConfig);
    private _acceptTermsAndConditions?;
    get acceptTermsAndConditions(): boolean | cdktn.IResolvable;
    set acceptTermsAndConditions(value: boolean | cdktn.IResolvable);
    get acceptTermsAndConditionsInput(): boolean | cdktn.IResolvable | undefined;
    private _connectionArn?;
    get connectionArn(): string;
    set connectionArn(value: string);
    resetConnectionArn(): void;
    get connectionArnInput(): string | undefined;
    get id(): string;
    get identityProvider(): string;
    get publisherId(): string;
    get publisherProfile(): string;
    get publisherStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
