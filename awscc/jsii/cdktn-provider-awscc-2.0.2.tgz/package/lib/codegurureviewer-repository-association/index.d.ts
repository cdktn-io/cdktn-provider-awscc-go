/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodegurureviewerRepositoryAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the S3 bucket associated with an associated S3 repository. It must start with `codeguru-reviewer-`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#bucket_name CodegurureviewerRepositoryAssociation#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The Amazon Resource Name (ARN) of an AWS CodeStar Connections connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#connection_arn CodegurureviewerRepositoryAssociation#connection_arn}
    */
    readonly connectionArn?: string;
    /**
    * Name of the repository to be associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#name CodegurureviewerRepositoryAssociation#name}
    */
    readonly name: string;
    /**
    * The owner of the repository. For a Bitbucket repository, this is the username for the account that owns the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#owner CodegurureviewerRepositoryAssociation#owner}
    */
    readonly owner?: string;
    /**
    * The tags associated with a repository association.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#tags CodegurureviewerRepositoryAssociation#tags}
    */
    readonly tags?: CodegurureviewerRepositoryAssociationTags[] | cdktn.IResolvable;
    /**
    * The type of repository to be associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#type CodegurureviewerRepositoryAssociation#type}
    */
    readonly type: string;
}
export interface CodegurureviewerRepositoryAssociationTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. The allowed characters across services are: letters, numbers, and spaces representable in UTF-8, and the following characters: + - = . _ : / @.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#key CodegurureviewerRepositoryAssociation#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length. The allowed characters across services are: letters, numbers, and spaces representable in UTF-8, and the following characters: + - = . _ : / @.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#value CodegurureviewerRepositoryAssociation#value}
    */
    readonly value?: string;
}
export declare function codegurureviewerRepositoryAssociationTagsToTerraform(struct?: CodegurureviewerRepositoryAssociationTags | cdktn.IResolvable): any;
export declare function codegurureviewerRepositoryAssociationTagsToHclTerraform(struct?: CodegurureviewerRepositoryAssociationTags | cdktn.IResolvable): any;
export declare class CodegurureviewerRepositoryAssociationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodegurureviewerRepositoryAssociationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodegurureviewerRepositoryAssociationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodegurureviewerRepositoryAssociationTagsList extends cdktn.ComplexList {
    internalValue?: CodegurureviewerRepositoryAssociationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodegurureviewerRepositoryAssociationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association awscc_codegurureviewer_repository_association}
*/
export declare class CodegurureviewerRepositoryAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codegurureviewer_repository_association";
    /**
    * Generates CDKTN code for importing a CodegurureviewerRepositoryAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodegurureviewerRepositoryAssociation to import
    * @param importFromId The id of the existing CodegurureviewerRepositoryAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodegurureviewerRepositoryAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codegurureviewer_repository_association awscc_codegurureviewer_repository_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodegurureviewerRepositoryAssociationConfig
    */
    constructor(scope: Construct, id: string, config: CodegurureviewerRepositoryAssociationConfig);
    get associationArn(): string;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _connectionArn?;
    get connectionArn(): string;
    set connectionArn(value: string);
    resetConnectionArn(): void;
    get connectionArnInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _tags;
    get tags(): CodegurureviewerRepositoryAssociationTagsList;
    putTags(value: CodegurureviewerRepositoryAssociationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodegurureviewerRepositoryAssociationTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
