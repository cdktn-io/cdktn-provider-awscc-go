/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockBlueprintConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the Blueprint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#blueprint_name BedrockBlueprint#blueprint_name}
    */
    readonly blueprintName: string;
    /**
    * KMS encryption context
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#kms_encryption_context BedrockBlueprint#kms_encryption_context}
    */
    readonly kmsEncryptionContext?: {
        [key: string]: string;
    };
    /**
    * KMS key identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#kms_key_id BedrockBlueprint#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Schema of the blueprint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#schema BedrockBlueprint#schema}
    */
    readonly schema: string;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#tags BedrockBlueprint#tags}
    */
    readonly tags?: BedrockBlueprintTags[] | cdktn.IResolvable;
    /**
    * Modality Type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#type BedrockBlueprint#type}
    */
    readonly type: string;
}
export interface BedrockBlueprintTags {
    /**
    * Key for the tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#key BedrockBlueprint#key}
    */
    readonly key?: string;
    /**
    * Value for the tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#value BedrockBlueprint#value}
    */
    readonly value?: string;
}
export declare function bedrockBlueprintTagsToTerraform(struct?: BedrockBlueprintTags | cdktn.IResolvable): any;
export declare function bedrockBlueprintTagsToHclTerraform(struct?: BedrockBlueprintTags | cdktn.IResolvable): any;
export declare class BedrockBlueprintTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockBlueprintTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockBlueprintTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockBlueprintTagsList extends cdktn.ComplexList {
    internalValue?: BedrockBlueprintTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockBlueprintTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint awscc_bedrock_blueprint}
*/
export declare class BedrockBlueprint extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_blueprint";
    /**
    * Generates CDKTN code for importing a BedrockBlueprint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockBlueprint to import
    * @param importFromId The id of the existing BedrockBlueprint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockBlueprint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_blueprint awscc_bedrock_blueprint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockBlueprintConfig
    */
    constructor(scope: Construct, id: string, config: BedrockBlueprintConfig);
    get blueprintArn(): string;
    private _blueprintName?;
    get blueprintName(): string;
    set blueprintName(value: string);
    get blueprintNameInput(): string | undefined;
    get blueprintStage(): string;
    get creationTime(): string;
    get id(): string;
    private _kmsEncryptionContext?;
    get kmsEncryptionContext(): {
        [key: string]: string;
    };
    set kmsEncryptionContext(value: {
        [key: string]: string;
    });
    resetKmsEncryptionContext(): void;
    get kmsEncryptionContextInput(): {
        [key: string]: string;
    } | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get lastModifiedTime(): string;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _tags;
    get tags(): BedrockBlueprintTagsList;
    putTags(value: BedrockBlueprintTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockBlueprintTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
