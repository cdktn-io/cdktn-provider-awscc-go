/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Apigatewayv2PortalProductConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the portal product.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigatewayv2_portal_product#description Apigatewayv2PortalProduct#description}
    */
    readonly description?: string;
    /**
    * The name of the portal product as it appears in a published portal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigatewayv2_portal_product#display_name Apigatewayv2PortalProduct#display_name}
    */
    readonly displayName: string;
    /**
    * The collection of tags associated with the portal product.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigatewayv2_portal_product#tags Apigatewayv2PortalProduct#tags}
    */
    readonly tags?: Apigatewayv2PortalProductTags[] | cdktn.IResolvable;
}
export interface Apigatewayv2PortalProductTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigatewayv2_portal_product#key Apigatewayv2PortalProduct#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigatewayv2_portal_product#value Apigatewayv2PortalProduct#value}
    */
    readonly value?: string;
}
export declare function apigatewayv2PortalProductTagsToTerraform(struct?: Apigatewayv2PortalProductTags | cdktn.IResolvable): any;
export declare function apigatewayv2PortalProductTagsToHclTerraform(struct?: Apigatewayv2PortalProductTags | cdktn.IResolvable): any;
export declare class Apigatewayv2PortalProductTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2PortalProductTags | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2PortalProductTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class Apigatewayv2PortalProductTagsList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2PortalProductTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2PortalProductTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigatewayv2_portal_product awscc_apigatewayv2_portal_product}
*/
export declare class Apigatewayv2PortalProduct extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigatewayv2_portal_product";
    /**
    * Generates CDKTN code for importing a Apigatewayv2PortalProduct resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Apigatewayv2PortalProduct to import
    * @param importFromId The id of the existing Apigatewayv2PortalProduct that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigatewayv2_portal_product#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Apigatewayv2PortalProduct to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigatewayv2_portal_product awscc_apigatewayv2_portal_product} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Apigatewayv2PortalProductConfig
    */
    constructor(scope: Construct, id: string, config: Apigatewayv2PortalProductConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    get lastModified(): string;
    get portalProductArn(): string;
    get portalProductId(): string;
    private _tags;
    get tags(): Apigatewayv2PortalProductTagsList;
    putTags(value: Apigatewayv2PortalProductTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | Apigatewayv2PortalProductTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
