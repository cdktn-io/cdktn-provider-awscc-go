/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayMethodConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#api_key_required ApigatewayMethod#api_key_required}
    */
    readonly apiKeyRequired?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#authorization_scopes ApigatewayMethod#authorization_scopes}
    */
    readonly authorizationScopes?: string[];
    /**
    * The method's authorization type. This parameter is required. For valid values, see [Method](https://docs.aws.amazon.com/apigateway/latest/api/API_Method.html) in the *API Gateway API Reference*.
    *   If you specify the ``AuthorizerId`` property, specify ``CUSTOM`` or ``COGNITO_USER_POOLS`` for this property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#authorization_type ApigatewayMethod#authorization_type}
    */
    readonly authorizationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#authorizer_id ApigatewayMethod#authorizer_id}
    */
    readonly authorizerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#http_method ApigatewayMethod#http_method}
    */
    readonly httpMethod: string;
    /**
    * ``Integration`` is a property of the [AWS::ApiGateway::Method](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-method.html) resource that specifies information about the target backend that a method calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#integration ApigatewayMethod#integration}
    */
    readonly integration?: ApigatewayMethodIntegration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#method_responses ApigatewayMethod#method_responses}
    */
    readonly methodResponses?: ApigatewayMethodMethodResponses[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#operation_name ApigatewayMethod#operation_name}
    */
    readonly operationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#request_models ApigatewayMethod#request_models}
    */
    readonly requestModels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#request_parameters ApigatewayMethod#request_parameters}
    */
    readonly requestParameters?: {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#request_validator_id ApigatewayMethod#request_validator_id}
    */
    readonly requestValidatorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#resource_id ApigatewayMethod#resource_id}
    */
    readonly resourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#rest_api_id ApigatewayMethod#rest_api_id}
    */
    readonly restApiId: string;
}
export interface ApigatewayMethodIntegrationIntegrationResponses {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#content_handling ApigatewayMethod#content_handling}
    */
    readonly contentHandling?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#response_parameters ApigatewayMethod#response_parameters}
    */
    readonly responseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#response_templates ApigatewayMethod#response_templates}
    */
    readonly responseTemplates?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#selection_pattern ApigatewayMethod#selection_pattern}
    */
    readonly selectionPattern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#status_code ApigatewayMethod#status_code}
    */
    readonly statusCode?: string;
}
export declare function apigatewayMethodIntegrationIntegrationResponsesToTerraform(struct?: ApigatewayMethodIntegrationIntegrationResponses | cdktn.IResolvable): any;
export declare function apigatewayMethodIntegrationIntegrationResponsesToHclTerraform(struct?: ApigatewayMethodIntegrationIntegrationResponses | cdktn.IResolvable): any;
export declare class ApigatewayMethodIntegrationIntegrationResponsesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayMethodIntegrationIntegrationResponses | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayMethodIntegrationIntegrationResponses | cdktn.IResolvable | undefined);
    private _contentHandling?;
    get contentHandling(): string;
    set contentHandling(value: string);
    resetContentHandling(): void;
    get contentHandlingInput(): string | undefined;
    private _responseParameters?;
    get responseParameters(): {
        [key: string]: string;
    };
    set responseParameters(value: {
        [key: string]: string;
    });
    resetResponseParameters(): void;
    get responseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _responseTemplates?;
    get responseTemplates(): {
        [key: string]: string;
    };
    set responseTemplates(value: {
        [key: string]: string;
    });
    resetResponseTemplates(): void;
    get responseTemplatesInput(): {
        [key: string]: string;
    } | undefined;
    private _selectionPattern?;
    get selectionPattern(): string;
    set selectionPattern(value: string);
    resetSelectionPattern(): void;
    get selectionPatternInput(): string | undefined;
    private _statusCode?;
    get statusCode(): string;
    set statusCode(value: string);
    resetStatusCode(): void;
    get statusCodeInput(): string | undefined;
}
export declare class ApigatewayMethodIntegrationIntegrationResponsesList extends cdktn.ComplexList {
    internalValue?: ApigatewayMethodIntegrationIntegrationResponses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayMethodIntegrationIntegrationResponsesOutputReference;
}
export interface ApigatewayMethodIntegration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#cache_key_parameters ApigatewayMethod#cache_key_parameters}
    */
    readonly cacheKeyParameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#cache_namespace ApigatewayMethod#cache_namespace}
    */
    readonly cacheNamespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#connection_id ApigatewayMethod#connection_id}
    */
    readonly connectionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#connection_type ApigatewayMethod#connection_type}
    */
    readonly connectionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#content_handling ApigatewayMethod#content_handling}
    */
    readonly contentHandling?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#credentials ApigatewayMethod#credentials}
    */
    readonly credentials?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#integration_http_method ApigatewayMethod#integration_http_method}
    */
    readonly integrationHttpMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#integration_responses ApigatewayMethod#integration_responses}
    */
    readonly integrationResponses?: ApigatewayMethodIntegrationIntegrationResponses[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#integration_target ApigatewayMethod#integration_target}
    */
    readonly integrationTarget?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#passthrough_behavior ApigatewayMethod#passthrough_behavior}
    */
    readonly passthroughBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#request_parameters ApigatewayMethod#request_parameters}
    */
    readonly requestParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#request_templates ApigatewayMethod#request_templates}
    */
    readonly requestTemplates?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#response_transfer_mode ApigatewayMethod#response_transfer_mode}
    */
    readonly responseTransferMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#timeout_in_millis ApigatewayMethod#timeout_in_millis}
    */
    readonly timeoutInMillis?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#type ApigatewayMethod#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#uri ApigatewayMethod#uri}
    */
    readonly uri?: string;
}
export declare function apigatewayMethodIntegrationToTerraform(struct?: ApigatewayMethodIntegration | cdktn.IResolvable): any;
export declare function apigatewayMethodIntegrationToHclTerraform(struct?: ApigatewayMethodIntegration | cdktn.IResolvable): any;
export declare class ApigatewayMethodIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayMethodIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayMethodIntegration | cdktn.IResolvable | undefined);
    private _cacheKeyParameters?;
    get cacheKeyParameters(): string[];
    set cacheKeyParameters(value: string[]);
    resetCacheKeyParameters(): void;
    get cacheKeyParametersInput(): string[] | undefined;
    private _cacheNamespace?;
    get cacheNamespace(): string;
    set cacheNamespace(value: string);
    resetCacheNamespace(): void;
    get cacheNamespaceInput(): string | undefined;
    private _connectionId?;
    get connectionId(): string;
    set connectionId(value: string);
    resetConnectionId(): void;
    get connectionIdInput(): string | undefined;
    private _connectionType?;
    get connectionType(): string;
    set connectionType(value: string);
    resetConnectionType(): void;
    get connectionTypeInput(): string | undefined;
    private _contentHandling?;
    get contentHandling(): string;
    set contentHandling(value: string);
    resetContentHandling(): void;
    get contentHandlingInput(): string | undefined;
    private _credentials?;
    get credentials(): string;
    set credentials(value: string);
    resetCredentials(): void;
    get credentialsInput(): string | undefined;
    private _integrationHttpMethod?;
    get integrationHttpMethod(): string;
    set integrationHttpMethod(value: string);
    resetIntegrationHttpMethod(): void;
    get integrationHttpMethodInput(): string | undefined;
    private _integrationResponses;
    get integrationResponses(): ApigatewayMethodIntegrationIntegrationResponsesList;
    putIntegrationResponses(value: ApigatewayMethodIntegrationIntegrationResponses[] | cdktn.IResolvable): void;
    resetIntegrationResponses(): void;
    get integrationResponsesInput(): cdktn.IResolvable | ApigatewayMethodIntegrationIntegrationResponses[] | undefined;
    private _integrationTarget?;
    get integrationTarget(): string;
    set integrationTarget(value: string);
    resetIntegrationTarget(): void;
    get integrationTargetInput(): string | undefined;
    private _passthroughBehavior?;
    get passthroughBehavior(): string;
    set passthroughBehavior(value: string);
    resetPassthroughBehavior(): void;
    get passthroughBehaviorInput(): string | undefined;
    private _requestParameters?;
    get requestParameters(): {
        [key: string]: string;
    };
    set requestParameters(value: {
        [key: string]: string;
    });
    resetRequestParameters(): void;
    get requestParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _requestTemplates?;
    get requestTemplates(): {
        [key: string]: string;
    };
    set requestTemplates(value: {
        [key: string]: string;
    });
    resetRequestTemplates(): void;
    get requestTemplatesInput(): {
        [key: string]: string;
    } | undefined;
    private _responseTransferMode?;
    get responseTransferMode(): string;
    set responseTransferMode(value: string);
    resetResponseTransferMode(): void;
    get responseTransferModeInput(): string | undefined;
    private _timeoutInMillis?;
    get timeoutInMillis(): number;
    set timeoutInMillis(value: number);
    resetTimeoutInMillis(): void;
    get timeoutInMillisInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface ApigatewayMethodMethodResponses {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#response_models ApigatewayMethod#response_models}
    */
    readonly responseModels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#response_parameters ApigatewayMethod#response_parameters}
    */
    readonly responseParameters?: {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#status_code ApigatewayMethod#status_code}
    */
    readonly statusCode?: string;
}
export declare function apigatewayMethodMethodResponsesToTerraform(struct?: ApigatewayMethodMethodResponses | cdktn.IResolvable): any;
export declare function apigatewayMethodMethodResponsesToHclTerraform(struct?: ApigatewayMethodMethodResponses | cdktn.IResolvable): any;
export declare class ApigatewayMethodMethodResponsesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayMethodMethodResponses | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayMethodMethodResponses | cdktn.IResolvable | undefined);
    private _responseModels?;
    get responseModels(): {
        [key: string]: string;
    };
    set responseModels(value: {
        [key: string]: string;
    });
    resetResponseModels(): void;
    get responseModelsInput(): {
        [key: string]: string;
    } | undefined;
    private _responseParameters?;
    get responseParameters(): {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    set responseParameters(value: {
        [key: string]: (boolean | cdktn.IResolvable);
    });
    resetResponseParameters(): void;
    get responseParametersInput(): {
        [key: string]: boolean | cdktn.IResolvable;
    } | undefined;
    private _statusCode?;
    get statusCode(): string;
    set statusCode(value: string);
    resetStatusCode(): void;
    get statusCodeInput(): string | undefined;
}
export declare class ApigatewayMethodMethodResponsesList extends cdktn.ComplexList {
    internalValue?: ApigatewayMethodMethodResponses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayMethodMethodResponsesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method awscc_apigateway_method}
*/
export declare class ApigatewayMethod extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_method";
    /**
    * Generates CDKTN code for importing a ApigatewayMethod resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayMethod to import
    * @param importFromId The id of the existing ApigatewayMethod that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayMethod to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/apigateway_method awscc_apigateway_method} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayMethodConfig
    */
    constructor(scope: Construct, id: string, config: ApigatewayMethodConfig);
    private _apiKeyRequired?;
    get apiKeyRequired(): boolean | cdktn.IResolvable;
    set apiKeyRequired(value: boolean | cdktn.IResolvable);
    resetApiKeyRequired(): void;
    get apiKeyRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _authorizationScopes?;
    get authorizationScopes(): string[];
    set authorizationScopes(value: string[]);
    resetAuthorizationScopes(): void;
    get authorizationScopesInput(): string[] | undefined;
    private _authorizationType?;
    get authorizationType(): string;
    set authorizationType(value: string);
    resetAuthorizationType(): void;
    get authorizationTypeInput(): string | undefined;
    private _authorizerId?;
    get authorizerId(): string;
    set authorizerId(value: string);
    resetAuthorizerId(): void;
    get authorizerIdInput(): string | undefined;
    private _httpMethod?;
    get httpMethod(): string;
    set httpMethod(value: string);
    get httpMethodInput(): string | undefined;
    get id(): string;
    private _integration;
    get integration(): ApigatewayMethodIntegrationOutputReference;
    putIntegration(value: ApigatewayMethodIntegration): void;
    resetIntegration(): void;
    get integrationInput(): cdktn.IResolvable | ApigatewayMethodIntegration | undefined;
    private _methodResponses;
    get methodResponses(): ApigatewayMethodMethodResponsesList;
    putMethodResponses(value: ApigatewayMethodMethodResponses[] | cdktn.IResolvable): void;
    resetMethodResponses(): void;
    get methodResponsesInput(): cdktn.IResolvable | ApigatewayMethodMethodResponses[] | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _requestModels?;
    get requestModels(): {
        [key: string]: string;
    };
    set requestModels(value: {
        [key: string]: string;
    });
    resetRequestModels(): void;
    get requestModelsInput(): {
        [key: string]: string;
    } | undefined;
    private _requestParameters?;
    get requestParameters(): {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    set requestParameters(value: {
        [key: string]: (boolean | cdktn.IResolvable);
    });
    resetRequestParameters(): void;
    get requestParametersInput(): {
        [key: string]: boolean | cdktn.IResolvable;
    } | undefined;
    private _requestValidatorId?;
    get requestValidatorId(): string;
    set requestValidatorId(value: string);
    resetRequestValidatorId(): void;
    get requestValidatorIdInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _restApiId?;
    get restApiId(): string;
    set restApiId(value: string);
    get restApiIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
