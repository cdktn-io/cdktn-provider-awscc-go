/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupTieringConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration#backup_vault_name BackupTieringConfiguration#backup_vault_name}
    */
    readonly backupVaultName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration#resource_selection BackupTieringConfiguration#resource_selection}
    */
    readonly resourceSelection: BackupTieringConfigurationResourceSelection[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration#tiering_configuration_name BackupTieringConfiguration#tiering_configuration_name}
    */
    readonly tieringConfigurationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration#tiering_configuration_tags BackupTieringConfiguration#tiering_configuration_tags}
    */
    readonly tieringConfigurationTags?: {
        [key: string]: string;
    };
}
export interface BackupTieringConfigurationResourceSelection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration#resource_type BackupTieringConfiguration#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration#resources BackupTieringConfiguration#resources}
    */
    readonly resources: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration#tiering_down_settings_in_days BackupTieringConfiguration#tiering_down_settings_in_days}
    */
    readonly tieringDownSettingsInDays: number;
}
export declare function backupTieringConfigurationResourceSelectionToTerraform(struct?: BackupTieringConfigurationResourceSelection | cdktn.IResolvable): any;
export declare function backupTieringConfigurationResourceSelectionToHclTerraform(struct?: BackupTieringConfigurationResourceSelection | cdktn.IResolvable): any;
export declare class BackupTieringConfigurationResourceSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupTieringConfigurationResourceSelection | cdktn.IResolvable | undefined;
    set internalValue(value: BackupTieringConfigurationResourceSelection | cdktn.IResolvable | undefined);
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    get resourcesInput(): string[] | undefined;
    private _tieringDownSettingsInDays?;
    get tieringDownSettingsInDays(): number;
    set tieringDownSettingsInDays(value: number);
    get tieringDownSettingsInDaysInput(): number | undefined;
}
export declare class BackupTieringConfigurationResourceSelectionList extends cdktn.ComplexList {
    internalValue?: BackupTieringConfigurationResourceSelection[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupTieringConfigurationResourceSelectionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration awscc_backup_tiering_configuration}
*/
export declare class BackupTieringConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_tiering_configuration";
    /**
    * Generates CDKTN code for importing a BackupTieringConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupTieringConfiguration to import
    * @param importFromId The id of the existing BackupTieringConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupTieringConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_tiering_configuration awscc_backup_tiering_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupTieringConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: BackupTieringConfigurationConfig);
    private _backupVaultName?;
    get backupVaultName(): string;
    set backupVaultName(value: string);
    get backupVaultNameInput(): string | undefined;
    get creationTime(): string;
    get id(): string;
    get lastUpdatedTime(): string;
    private _resourceSelection;
    get resourceSelection(): BackupTieringConfigurationResourceSelectionList;
    putResourceSelection(value: BackupTieringConfigurationResourceSelection[] | cdktn.IResolvable): void;
    get resourceSelectionInput(): cdktn.IResolvable | BackupTieringConfigurationResourceSelection[] | undefined;
    get tieringConfigurationArn(): string;
    private _tieringConfigurationName?;
    get tieringConfigurationName(): string;
    set tieringConfigurationName(value: string);
    get tieringConfigurationNameInput(): string | undefined;
    private _tieringConfigurationTags?;
    get tieringConfigurationTags(): {
        [key: string]: string;
    };
    set tieringConfigurationTags(value: {
        [key: string]: string;
    });
    resetTieringConfigurationTags(): void;
    get tieringConfigurationTagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
