/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AcmpcaCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies X.509 certificate information to be included in the issued certificate. An ``APIPassthrough`` or ``APICSRPassthrough`` template variant must be selected, or else this parameter is ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#api_passthrough AcmpcaCertificate#api_passthrough}
    */
    readonly apiPassthrough?: AcmpcaCertificateApiPassthrough;
    /**
    * The Amazon Resource Name (ARN) for the private CA issues the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#certificate_authority_arn AcmpcaCertificate#certificate_authority_arn}
    */
    readonly certificateAuthorityArn: string;
    /**
    * The certificate signing request (CSR) for the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#certificate_signing_request AcmpcaCertificate#certificate_signing_request}
    */
    readonly certificateSigningRequest: string;
    /**
    * The name of the algorithm that will be used to sign the certificate to be issued.
    *  This parameter should not be confused with the ``SigningAlgorithm`` parameter used to sign a CSR in the ``CreateCertificateAuthority`` action.
    *   The specified signing algorithm family (RSA or ECDSA) must match the algorithm family of the CA's secret key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#signing_algorithm AcmpcaCertificate#signing_algorithm}
    */
    readonly signingAlgorithm: string;
    /**
    * Specifies a custom configuration template to use when issuing a certificate. If this parameter is not provided, PCAshort defaults to the ``EndEntityCertificate/V1`` template. For more information about PCAshort templates, see [Using Templates](https://docs.aws.amazon.com/privateca/latest/userguide/UsingTemplates.html).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#template_arn AcmpcaCertificate#template_arn}
    */
    readonly templateArn?: string;
    /**
    * The period of time during which the certificate will be valid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#validity AcmpcaCertificate#validity}
    */
    readonly validity: AcmpcaCertificateValidity;
    /**
    * Information describing the start of the validity period of the certificate. This parameter sets the ?Not Before" date for the certificate.
    *  By default, when issuing a certificate, PCAshort sets the "Not Before" date to the issuance time minus 60 minutes. This compensates for clock inconsistencies across computer systems. The ``ValidityNotBefore`` parameter can be used to customize the ?Not Before? value.
    *  Unlike the ``Validity`` parameter, the ``ValidityNotBefore`` parameter is optional.
    *  The ``ValidityNotBefore`` value is expressed as an explicit date and time, using the ``Validity`` type value ``ABSOLUTE``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#validity_not_before AcmpcaCertificate#validity_not_before}
    */
    readonly validityNotBefore?: AcmpcaCertificateValidityNotBefore;
}
export interface AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier {
    /**
    * Contains a pointer to a certification practice statement (CPS) published by the CA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#cps_uri AcmpcaCertificate#cps_uri}
    */
    readonly cpsUri?: string;
}
export declare function acmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifierToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifierToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier | cdktn.IResolvable | undefined);
    private _cpsUri?;
    get cpsUri(): string;
    set cpsUri(value: string);
    resetCpsUri(): void;
    get cpsUriInput(): string | undefined;
}
export interface AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers {
    /**
    * Identifies the qualifier modifying a ``CertPolicyId``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#policy_qualifier_id AcmpcaCertificate#policy_qualifier_id}
    */
    readonly policyQualifierId?: string;
    /**
    * Defines the qualifier type. AWS Private CA supports the use of a URI for a CPS qualifier in this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#qualifier AcmpcaCertificate#qualifier}
    */
    readonly qualifier?: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier;
}
export declare function acmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers | cdktn.IResolvable | undefined);
    private _policyQualifierId?;
    get policyQualifierId(): string;
    set policyQualifierId(value: string);
    resetPolicyQualifierId(): void;
    get policyQualifierIdInput(): string | undefined;
    private _qualifier;
    get qualifier(): AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifierOutputReference;
    putQualifier(value: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier): void;
    resetQualifier(): void;
    get qualifierInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier | undefined;
}
export declare class AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersOutputReference;
}
export interface AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies {
    /**
    * Specifies the object identifier (OID) of the certificate policy under which the certificate was issued. For more information, see NIST's definition of [Object Identifier (OID)](https://docs.aws.amazon.com/https://csrc.nist.gov/glossary/term/Object_Identifier).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#cert_policy_id AcmpcaCertificate#cert_policy_id}
    */
    readonly certPolicyId?: string;
    /**
    * Modifies the given ``CertPolicyId`` with a qualifier. AWS Private CA supports the certification practice statement (CPS) qualifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#policy_qualifiers AcmpcaCertificate#policy_qualifiers}
    */
    readonly policyQualifiers?: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers[] | cdktn.IResolvable;
}
export declare function acmpcaCertificateApiPassthroughExtensionsCertificatePoliciesToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsCertificatePoliciesToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies | cdktn.IResolvable | undefined);
    private _certPolicyId?;
    get certPolicyId(): string;
    set certPolicyId(value: string);
    resetCertPolicyId(): void;
    get certPolicyIdInput(): string | undefined;
    private _policyQualifiers;
    get policyQualifiers(): AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersList;
    putPolicyQualifiers(value: AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers[] | cdktn.IResolvable): void;
    resetPolicyQualifiers(): void;
    get policyQualifiersInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers[] | undefined;
}
export declare class AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesOutputReference;
}
export interface AcmpcaCertificateApiPassthroughExtensionsCustomExtensions {
    /**
    * Specifies the critical flag of the X.509 extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#critical AcmpcaCertificate#critical}
    */
    readonly critical?: boolean | cdktn.IResolvable;
    /**
    * Specifies the object identifier (OID) of the X.509 extension. For more information, see the [Global OID reference database.](https://docs.aws.amazon.com/https://oidref.com/2.5.29)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#object_identifier AcmpcaCertificate#object_identifier}
    */
    readonly objectIdentifier?: string;
    /**
    * Specifies the base64-encoded value of the X.509 extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#value AcmpcaCertificate#value}
    */
    readonly value?: string;
}
export declare function acmpcaCertificateApiPassthroughExtensionsCustomExtensionsToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsCustomExtensions | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsCustomExtensionsToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsCustomExtensions | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsCustomExtensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsCustomExtensions | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsCustomExtensions | cdktn.IResolvable | undefined);
    private _critical?;
    get critical(): boolean | cdktn.IResolvable;
    set critical(value: boolean | cdktn.IResolvable);
    resetCritical(): void;
    get criticalInput(): boolean | cdktn.IResolvable | undefined;
    private _objectIdentifier?;
    get objectIdentifier(): string;
    set objectIdentifier(value: string);
    resetObjectIdentifier(): void;
    get objectIdentifierInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AcmpcaCertificateApiPassthroughExtensionsCustomExtensionsList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateApiPassthroughExtensionsCustomExtensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateApiPassthroughExtensionsCustomExtensionsOutputReference;
}
export interface AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage {
    /**
    * Specifies a custom ``ExtendedKeyUsage`` with an object identifier (OID).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#extended_key_usage_object_identifier AcmpcaCertificate#extended_key_usage_object_identifier}
    */
    readonly extendedKeyUsageObjectIdentifier?: string;
    /**
    * Specifies a standard ``ExtendedKeyUsage`` as defined as in [RFC 5280](https://docs.aws.amazon.com/https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.12).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#extended_key_usage_type AcmpcaCertificate#extended_key_usage_type}
    */
    readonly extendedKeyUsageType?: string;
}
export declare function acmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage | cdktn.IResolvable | undefined);
    private _extendedKeyUsageObjectIdentifier?;
    get extendedKeyUsageObjectIdentifier(): string;
    set extendedKeyUsageObjectIdentifier(value: string);
    resetExtendedKeyUsageObjectIdentifier(): void;
    get extendedKeyUsageObjectIdentifierInput(): string | undefined;
    private _extendedKeyUsageType?;
    get extendedKeyUsageType(): string;
    set extendedKeyUsageType(value: string);
    resetExtendedKeyUsageType(): void;
    get extendedKeyUsageTypeInput(): string | undefined;
}
export declare class AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageOutputReference;
}
export interface AcmpcaCertificateApiPassthroughExtensionsKeyUsage {
    /**
    * Key can be used to sign CRLs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#crl_sign AcmpcaCertificate#crl_sign}
    */
    readonly crlSign?: boolean | cdktn.IResolvable;
    /**
    * Key can be used to decipher data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#data_encipherment AcmpcaCertificate#data_encipherment}
    */
    readonly dataEncipherment?: boolean | cdktn.IResolvable;
    /**
    * Key can be used only to decipher data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#decipher_only AcmpcaCertificate#decipher_only}
    */
    readonly decipherOnly?: boolean | cdktn.IResolvable;
    /**
    * Key can be used for digital signing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#digital_signature AcmpcaCertificate#digital_signature}
    */
    readonly digitalSignature?: boolean | cdktn.IResolvable;
    /**
    * Key can be used only to encipher data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#encipher_only AcmpcaCertificate#encipher_only}
    */
    readonly encipherOnly?: boolean | cdktn.IResolvable;
    /**
    * Key can be used in a key-agreement protocol.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#key_agreement AcmpcaCertificate#key_agreement}
    */
    readonly keyAgreement?: boolean | cdktn.IResolvable;
    /**
    * Key can be used to sign certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#key_cert_sign AcmpcaCertificate#key_cert_sign}
    */
    readonly keyCertSign?: boolean | cdktn.IResolvable;
    /**
    * Key can be used to encipher data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#key_encipherment AcmpcaCertificate#key_encipherment}
    */
    readonly keyEncipherment?: boolean | cdktn.IResolvable;
    /**
    * Key can be used for non-repudiation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#non_repudiation AcmpcaCertificate#non_repudiation}
    */
    readonly nonRepudiation?: boolean | cdktn.IResolvable;
}
export declare function acmpcaCertificateApiPassthroughExtensionsKeyUsageToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsKeyUsage | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsKeyUsageToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsKeyUsage | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsKeyUsage | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsKeyUsage | cdktn.IResolvable | undefined);
    private _crlSign?;
    get crlSign(): boolean | cdktn.IResolvable;
    set crlSign(value: boolean | cdktn.IResolvable);
    resetCrlSign(): void;
    get crlSignInput(): boolean | cdktn.IResolvable | undefined;
    private _dataEncipherment?;
    get dataEncipherment(): boolean | cdktn.IResolvable;
    set dataEncipherment(value: boolean | cdktn.IResolvable);
    resetDataEncipherment(): void;
    get dataEnciphermentInput(): boolean | cdktn.IResolvable | undefined;
    private _decipherOnly?;
    get decipherOnly(): boolean | cdktn.IResolvable;
    set decipherOnly(value: boolean | cdktn.IResolvable);
    resetDecipherOnly(): void;
    get decipherOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _digitalSignature?;
    get digitalSignature(): boolean | cdktn.IResolvable;
    set digitalSignature(value: boolean | cdktn.IResolvable);
    resetDigitalSignature(): void;
    get digitalSignatureInput(): boolean | cdktn.IResolvable | undefined;
    private _encipherOnly?;
    get encipherOnly(): boolean | cdktn.IResolvable;
    set encipherOnly(value: boolean | cdktn.IResolvable);
    resetEncipherOnly(): void;
    get encipherOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _keyAgreement?;
    get keyAgreement(): boolean | cdktn.IResolvable;
    set keyAgreement(value: boolean | cdktn.IResolvable);
    resetKeyAgreement(): void;
    get keyAgreementInput(): boolean | cdktn.IResolvable | undefined;
    private _keyCertSign?;
    get keyCertSign(): boolean | cdktn.IResolvable;
    set keyCertSign(value: boolean | cdktn.IResolvable);
    resetKeyCertSign(): void;
    get keyCertSignInput(): boolean | cdktn.IResolvable | undefined;
    private _keyEncipherment?;
    get keyEncipherment(): boolean | cdktn.IResolvable;
    set keyEncipherment(value: boolean | cdktn.IResolvable);
    resetKeyEncipherment(): void;
    get keyEnciphermentInput(): boolean | cdktn.IResolvable | undefined;
    private _nonRepudiation?;
    get nonRepudiation(): boolean | cdktn.IResolvable;
    set nonRepudiation(value: boolean | cdktn.IResolvable);
    resetNonRepudiation(): void;
    get nonRepudiationInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes {
    /**
    * Specifies the object identifier (OID) of the attribute type of the relative distinguished name (RDN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#object_identifier AcmpcaCertificate#object_identifier}
    */
    readonly objectIdentifier?: string;
    /**
    * Specifies the attribute value of relative distinguished name (RDN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#value AcmpcaCertificate#value}
    */
    readonly value?: string;
}
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes | cdktn.IResolvable | undefined);
    private _objectIdentifier?;
    get objectIdentifier(): string;
    set objectIdentifier(value: string);
    resetObjectIdentifier(): void;
    get objectIdentifierInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesOutputReference;
}
export interface AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName {
    /**
    * For CA and end-entity certificates in a private PKI, the common name (CN) can be any string within the length limit.
    *  Note: In publicly trusted certificates, the common name must be a fully qualified domain name (FQDN) associated with the certificate subject.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#common_name AcmpcaCertificate#common_name}
    */
    readonly commonName?: string;
    /**
    * Two-digit code that specifies the country in which the certificate subject located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#country AcmpcaCertificate#country}
    */
    readonly country?: string;
    /**
    * Contains a sequence of one or more X.500 relative distinguished names (RDNs), each of which consists of an object identifier (OID) and a value. For more information, see NIST?s definition of [Object Identifier (OID)](https://docs.aws.amazon.com/https://csrc.nist.gov/glossary/term/Object_Identifier).
    *   Custom attributes cannot be used in combination with standard attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#custom_attributes AcmpcaCertificate#custom_attributes}
    */
    readonly customAttributes?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes[] | cdktn.IResolvable;
    /**
    * Disambiguating information for the certificate subject.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#distinguished_name_qualifier AcmpcaCertificate#distinguished_name_qualifier}
    */
    readonly distinguishedNameQualifier?: string;
    /**
    * Typically a qualifier appended to the name of an individual. Examples include Jr. for junior, Sr. for senior, and III for third.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#generation_qualifier AcmpcaCertificate#generation_qualifier}
    */
    readonly generationQualifier?: string;
    /**
    * First name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#given_name AcmpcaCertificate#given_name}
    */
    readonly givenName?: string;
    /**
    * Concatenation that typically contains the first letter of the *GivenName*, the first letter of the middle name if one exists, and the first letter of the *Surname*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#initials AcmpcaCertificate#initials}
    */
    readonly initials?: string;
    /**
    * The locality (such as a city or town) in which the certificate subject is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#locality AcmpcaCertificate#locality}
    */
    readonly locality?: string;
    /**
    * Legal name of the organization with which the certificate subject is affiliated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#organization AcmpcaCertificate#organization}
    */
    readonly organization?: string;
    /**
    * A subdivision or unit of the organization (such as sales or finance) with which the certificate subject is affiliated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#organizational_unit AcmpcaCertificate#organizational_unit}
    */
    readonly organizationalUnit?: string;
    /**
    * Typically a shortened version of a longer *GivenName*. For example, Jonathan is often shortened to John. Elizabeth is often shortened to Beth, Liz, or Eliza.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#pseudonym AcmpcaCertificate#pseudonym}
    */
    readonly pseudonym?: string;
    /**
    * The certificate serial number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#serial_number AcmpcaCertificate#serial_number}
    */
    readonly serialNumber?: string;
    /**
    * State in which the subject of the certificate is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#state AcmpcaCertificate#state}
    */
    readonly state?: string;
    /**
    * Family name. In the US and the UK, for example, the surname of an individual is ordered last. In Asian cultures the surname is typically ordered first.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#surname AcmpcaCertificate#surname}
    */
    readonly surname?: string;
    /**
    * A title such as Mr. or Ms., which is pre-pended to the name to refer formally to the certificate subject.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#title AcmpcaCertificate#title}
    */
    readonly title?: string;
}
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName | cdktn.IResolvable | undefined);
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _customAttributes;
    get customAttributes(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesList;
    putCustomAttributes(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes[] | cdktn.IResolvable): void;
    resetCustomAttributes(): void;
    get customAttributesInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes[] | undefined;
    private _distinguishedNameQualifier?;
    get distinguishedNameQualifier(): string;
    set distinguishedNameQualifier(value: string);
    resetDistinguishedNameQualifier(): void;
    get distinguishedNameQualifierInput(): string | undefined;
    private _generationQualifier?;
    get generationQualifier(): string;
    set generationQualifier(value: string);
    resetGenerationQualifier(): void;
    get generationQualifierInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
    private _initials?;
    get initials(): string;
    set initials(value: string);
    resetInitials(): void;
    get initialsInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _organizationalUnit?;
    get organizationalUnit(): string;
    set organizationalUnit(value: string);
    resetOrganizationalUnit(): void;
    get organizationalUnitInput(): string | undefined;
    private _pseudonym?;
    get pseudonym(): string;
    set pseudonym(value: string);
    resetPseudonym(): void;
    get pseudonymInput(): string | undefined;
    private _serialNumber?;
    get serialNumber(): string;
    set serialNumber(value: string);
    resetSerialNumber(): void;
    get serialNumberInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _surname?;
    get surname(): string;
    set surname(value: string);
    resetSurname(): void;
    get surnameInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName {
    /**
    * Specifies the name assigner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#name_assigner AcmpcaCertificate#name_assigner}
    */
    readonly nameAssigner?: string;
    /**
    * Specifies the party name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#party_name AcmpcaCertificate#party_name}
    */
    readonly partyName?: string;
}
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyNameToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyNameToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName | cdktn.IResolvable | undefined);
    private _nameAssigner?;
    get nameAssigner(): string;
    set nameAssigner(value: string);
    resetNameAssigner(): void;
    get nameAssignerInput(): string | undefined;
    private _partyName?;
    get partyName(): string;
    set partyName(value: string);
    resetPartyName(): void;
    get partyNameInput(): string | undefined;
}
export interface AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName {
    /**
    * Specifies an OID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#type_id AcmpcaCertificate#type_id}
    */
    readonly typeId?: string;
    /**
    * Specifies an OID value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#value AcmpcaCertificate#value}
    */
    readonly value?: string;
}
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherNameToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherNameToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName | cdktn.IResolvable | undefined);
    private _typeId?;
    get typeId(): string;
    set typeId(value: string);
    resetTypeId(): void;
    get typeIdInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames {
    /**
    * Contains information about the certificate subject. The certificate can be one issued by your private certificate authority (CA) or it can be your private CA certificate. The Subject field in the certificate identifies the entity that owns or controls the public key in the certificate. The entity can be a user, computer, device, or service. The Subject must contain an X.500 distinguished name (DN). A DN is a sequence of relative distinguished names (RDNs). The RDNs are separated by commas in the certificate. The DN must be unique for each entity, but your private CA can issue more than one certificate with the same DN to the same entity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#directory_name AcmpcaCertificate#directory_name}
    */
    readonly directoryName?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName;
    /**
    * Represents ``GeneralName`` as a DNS name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#dns_name AcmpcaCertificate#dns_name}
    */
    readonly dnsName?: string;
    /**
    * Represents ``GeneralName`` as an ``EdiPartyName`` object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#edi_party_name AcmpcaCertificate#edi_party_name}
    */
    readonly ediPartyName?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName;
    /**
    * Represents ``GeneralName`` as an IPv4 or IPv6 address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#ip_address AcmpcaCertificate#ip_address}
    */
    readonly ipAddress?: string;
    /**
    * Represents ``GeneralName`` using an ``OtherName`` object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#other_name AcmpcaCertificate#other_name}
    */
    readonly otherName?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName;
    /**
    * Represents ``GeneralName`` as an object identifier (OID).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#registered_id AcmpcaCertificate#registered_id}
    */
    readonly registeredId?: string;
    /**
    * Represents ``GeneralName`` as an [RFC 822](https://docs.aws.amazon.com/https://datatracker.ietf.org/doc/html/rfc822) email address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#rfc_822_name AcmpcaCertificate#rfc_822_name}
    */
    readonly rfc822Name?: string;
    /**
    * Represents ``GeneralName`` as a URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#uniform_resource_identifier AcmpcaCertificate#uniform_resource_identifier}
    */
    readonly uniformResourceIdentifier?: string;
}
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames | cdktn.IResolvable | undefined);
    private _directoryName;
    get directoryName(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameOutputReference;
    putDirectoryName(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName): void;
    resetDirectoryName(): void;
    get directoryNameInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName | undefined;
    private _dnsName?;
    get dnsName(): string;
    set dnsName(value: string);
    resetDnsName(): void;
    get dnsNameInput(): string | undefined;
    private _ediPartyName;
    get ediPartyName(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyNameOutputReference;
    putEdiPartyName(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName): void;
    resetEdiPartyName(): void;
    get ediPartyNameInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    resetIpAddress(): void;
    get ipAddressInput(): string | undefined;
    private _otherName;
    get otherName(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherNameOutputReference;
    putOtherName(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName): void;
    resetOtherName(): void;
    get otherNameInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName | undefined;
    private _registeredId?;
    get registeredId(): string;
    set registeredId(value: string);
    resetRegisteredId(): void;
    get registeredIdInput(): string | undefined;
    private _rfc822Name?;
    get rfc822Name(): string;
    set rfc822Name(value: string);
    resetRfc822Name(): void;
    get rfc822NameInput(): string | undefined;
    private _uniformResourceIdentifier?;
    get uniformResourceIdentifier(): string;
    set uniformResourceIdentifier(value: string);
    resetUniformResourceIdentifier(): void;
    get uniformResourceIdentifierInput(): string | undefined;
}
export declare class AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOutputReference;
}
export interface AcmpcaCertificateApiPassthroughExtensions {
    /**
    * Contains a sequence of one or more policy information terms, each of which consists of an object identifier (OID) and optional qualifiers. For more information, see NIST's definition of [Object Identifier (OID)](https://docs.aws.amazon.com/https://csrc.nist.gov/glossary/term/Object_Identifier).
    *  In an end-entity certificate, these terms indicate the policy under which the certificate was issued and the purposes for which it may be used. In a CA certificate, these terms limit the set of policies for certification paths that include this certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#certificate_policies AcmpcaCertificate#certificate_policies}
    */
    readonly certificatePolicies?: AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies[] | cdktn.IResolvable;
    /**
    * Contains a sequence of one or more X.509 extensions, each of which consists of an object identifier (OID), a base64-encoded value, and the critical flag. For more information, see the [Global OID reference database.](https://docs.aws.amazon.com/https://oidref.com/2.5.29)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#custom_extensions AcmpcaCertificate#custom_extensions}
    */
    readonly customExtensions?: AcmpcaCertificateApiPassthroughExtensionsCustomExtensions[] | cdktn.IResolvable;
    /**
    * Specifies additional purposes for which the certified public key may be used other than basic purposes indicated in the ``KeyUsage`` extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#extended_key_usage AcmpcaCertificate#extended_key_usage}
    */
    readonly extendedKeyUsage?: AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage[] | cdktn.IResolvable;
    /**
    * Defines one or more purposes for which the key contained in the certificate can be used. Default value for each option is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#key_usage AcmpcaCertificate#key_usage}
    */
    readonly keyUsage?: AcmpcaCertificateApiPassthroughExtensionsKeyUsage;
    /**
    * The subject alternative name extension allows identities to be bound to the subject of the certificate. These identities may be included in addition to or in place of the identity in the subject field of the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#subject_alternative_names AcmpcaCertificate#subject_alternative_names}
    */
    readonly subjectAlternativeNames?: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames[] | cdktn.IResolvable;
}
export declare function acmpcaCertificateApiPassthroughExtensionsToTerraform(struct?: AcmpcaCertificateApiPassthroughExtensions | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughExtensionsToHclTerraform(struct?: AcmpcaCertificateApiPassthroughExtensions | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughExtensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateApiPassthroughExtensions | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughExtensions | cdktn.IResolvable | undefined);
    private _certificatePolicies;
    get certificatePolicies(): AcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesList;
    putCertificatePolicies(value: AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies[] | cdktn.IResolvable): void;
    resetCertificatePolicies(): void;
    get certificatePoliciesInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsCertificatePolicies[] | undefined;
    private _customExtensions;
    get customExtensions(): AcmpcaCertificateApiPassthroughExtensionsCustomExtensionsList;
    putCustomExtensions(value: AcmpcaCertificateApiPassthroughExtensionsCustomExtensions[] | cdktn.IResolvable): void;
    resetCustomExtensions(): void;
    get customExtensionsInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsCustomExtensions[] | undefined;
    private _extendedKeyUsage;
    get extendedKeyUsage(): AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageList;
    putExtendedKeyUsage(value: AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage[] | cdktn.IResolvable): void;
    resetExtendedKeyUsage(): void;
    get extendedKeyUsageInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage[] | undefined;
    private _keyUsage;
    get keyUsage(): AcmpcaCertificateApiPassthroughExtensionsKeyUsageOutputReference;
    putKeyUsage(value: AcmpcaCertificateApiPassthroughExtensionsKeyUsage): void;
    resetKeyUsage(): void;
    get keyUsageInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsKeyUsage | undefined;
    private _subjectAlternativeNames;
    get subjectAlternativeNames(): AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesList;
    putSubjectAlternativeNames(value: AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames[] | cdktn.IResolvable): void;
    resetSubjectAlternativeNames(): void;
    get subjectAlternativeNamesInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames[] | undefined;
}
export interface AcmpcaCertificateApiPassthroughSubjectCustomAttributes {
    /**
    * Specifies the object identifier (OID) of the attribute type of the relative distinguished name (RDN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#object_identifier AcmpcaCertificate#object_identifier}
    */
    readonly objectIdentifier?: string;
    /**
    * Specifies the attribute value of relative distinguished name (RDN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#value AcmpcaCertificate#value}
    */
    readonly value?: string;
}
export declare function acmpcaCertificateApiPassthroughSubjectCustomAttributesToTerraform(struct?: AcmpcaCertificateApiPassthroughSubjectCustomAttributes | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughSubjectCustomAttributesToHclTerraform(struct?: AcmpcaCertificateApiPassthroughSubjectCustomAttributes | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughSubjectCustomAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AcmpcaCertificateApiPassthroughSubjectCustomAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughSubjectCustomAttributes | cdktn.IResolvable | undefined);
    private _objectIdentifier?;
    get objectIdentifier(): string;
    set objectIdentifier(value: string);
    resetObjectIdentifier(): void;
    get objectIdentifierInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AcmpcaCertificateApiPassthroughSubjectCustomAttributesList extends cdktn.ComplexList {
    internalValue?: AcmpcaCertificateApiPassthroughSubjectCustomAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AcmpcaCertificateApiPassthroughSubjectCustomAttributesOutputReference;
}
export interface AcmpcaCertificateApiPassthroughSubject {
    /**
    * For CA and end-entity certificates in a private PKI, the common name (CN) can be any string within the length limit.
    *  Note: In publicly trusted certificates, the common name must be a fully qualified domain name (FQDN) associated with the certificate subject.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#common_name AcmpcaCertificate#common_name}
    */
    readonly commonName?: string;
    /**
    * Two-digit code that specifies the country in which the certificate subject located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#country AcmpcaCertificate#country}
    */
    readonly country?: string;
    /**
    * Contains a sequence of one or more X.500 relative distinguished names (RDNs), each of which consists of an object identifier (OID) and a value. For more information, see NIST?s definition of [Object Identifier (OID)](https://docs.aws.amazon.com/https://csrc.nist.gov/glossary/term/Object_Identifier).
    *   Custom attributes cannot be used in combination with standard attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#custom_attributes AcmpcaCertificate#custom_attributes}
    */
    readonly customAttributes?: AcmpcaCertificateApiPassthroughSubjectCustomAttributes[] | cdktn.IResolvable;
    /**
    * Disambiguating information for the certificate subject.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#distinguished_name_qualifier AcmpcaCertificate#distinguished_name_qualifier}
    */
    readonly distinguishedNameQualifier?: string;
    /**
    * Typically a qualifier appended to the name of an individual. Examples include Jr. for junior, Sr. for senior, and III for third.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#generation_qualifier AcmpcaCertificate#generation_qualifier}
    */
    readonly generationQualifier?: string;
    /**
    * First name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#given_name AcmpcaCertificate#given_name}
    */
    readonly givenName?: string;
    /**
    * Concatenation that typically contains the first letter of the *GivenName*, the first letter of the middle name if one exists, and the first letter of the *Surname*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#initials AcmpcaCertificate#initials}
    */
    readonly initials?: string;
    /**
    * The locality (such as a city or town) in which the certificate subject is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#locality AcmpcaCertificate#locality}
    */
    readonly locality?: string;
    /**
    * Legal name of the organization with which the certificate subject is affiliated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#organization AcmpcaCertificate#organization}
    */
    readonly organization?: string;
    /**
    * A subdivision or unit of the organization (such as sales or finance) with which the certificate subject is affiliated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#organizational_unit AcmpcaCertificate#organizational_unit}
    */
    readonly organizationalUnit?: string;
    /**
    * Typically a shortened version of a longer *GivenName*. For example, Jonathan is often shortened to John. Elizabeth is often shortened to Beth, Liz, or Eliza.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#pseudonym AcmpcaCertificate#pseudonym}
    */
    readonly pseudonym?: string;
    /**
    * The certificate serial number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#serial_number AcmpcaCertificate#serial_number}
    */
    readonly serialNumber?: string;
    /**
    * State in which the subject of the certificate is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#state AcmpcaCertificate#state}
    */
    readonly state?: string;
    /**
    * Family name. In the US and the UK, for example, the surname of an individual is ordered last. In Asian cultures the surname is typically ordered first.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#surname AcmpcaCertificate#surname}
    */
    readonly surname?: string;
    /**
    * A title such as Mr. or Ms., which is pre-pended to the name to refer formally to the certificate subject.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#title AcmpcaCertificate#title}
    */
    readonly title?: string;
}
export declare function acmpcaCertificateApiPassthroughSubjectToTerraform(struct?: AcmpcaCertificateApiPassthroughSubject | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughSubjectToHclTerraform(struct?: AcmpcaCertificateApiPassthroughSubject | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughSubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateApiPassthroughSubject | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthroughSubject | cdktn.IResolvable | undefined);
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _customAttributes;
    get customAttributes(): AcmpcaCertificateApiPassthroughSubjectCustomAttributesList;
    putCustomAttributes(value: AcmpcaCertificateApiPassthroughSubjectCustomAttributes[] | cdktn.IResolvable): void;
    resetCustomAttributes(): void;
    get customAttributesInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughSubjectCustomAttributes[] | undefined;
    private _distinguishedNameQualifier?;
    get distinguishedNameQualifier(): string;
    set distinguishedNameQualifier(value: string);
    resetDistinguishedNameQualifier(): void;
    get distinguishedNameQualifierInput(): string | undefined;
    private _generationQualifier?;
    get generationQualifier(): string;
    set generationQualifier(value: string);
    resetGenerationQualifier(): void;
    get generationQualifierInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
    private _initials?;
    get initials(): string;
    set initials(value: string);
    resetInitials(): void;
    get initialsInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _organizationalUnit?;
    get organizationalUnit(): string;
    set organizationalUnit(value: string);
    resetOrganizationalUnit(): void;
    get organizationalUnitInput(): string | undefined;
    private _pseudonym?;
    get pseudonym(): string;
    set pseudonym(value: string);
    resetPseudonym(): void;
    get pseudonymInput(): string | undefined;
    private _serialNumber?;
    get serialNumber(): string;
    set serialNumber(value: string);
    resetSerialNumber(): void;
    get serialNumberInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _surname?;
    get surname(): string;
    set surname(value: string);
    resetSurname(): void;
    get surnameInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
}
export interface AcmpcaCertificateApiPassthrough {
    /**
    * Specifies X.509 extension information for a certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#extensions AcmpcaCertificate#extensions}
    */
    readonly extensions?: AcmpcaCertificateApiPassthroughExtensions;
    /**
    * Contains information about the certificate subject. The Subject field in the certificate identifies the entity that owns or controls the public key in the certificate. The entity can be a user, computer, device, or service. The Subject must contain an X.500 distinguished name (DN). A DN is a sequence of relative distinguished names (RDNs). The RDNs are separated by commas in the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#subject AcmpcaCertificate#subject}
    */
    readonly subject?: AcmpcaCertificateApiPassthroughSubject;
}
export declare function acmpcaCertificateApiPassthroughToTerraform(struct?: AcmpcaCertificateApiPassthrough | cdktn.IResolvable): any;
export declare function acmpcaCertificateApiPassthroughToHclTerraform(struct?: AcmpcaCertificateApiPassthrough | cdktn.IResolvable): any;
export declare class AcmpcaCertificateApiPassthroughOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateApiPassthrough | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateApiPassthrough | cdktn.IResolvable | undefined);
    private _extensions;
    get extensions(): AcmpcaCertificateApiPassthroughExtensionsOutputReference;
    putExtensions(value: AcmpcaCertificateApiPassthroughExtensions): void;
    resetExtensions(): void;
    get extensionsInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughExtensions | undefined;
    private _subject;
    get subject(): AcmpcaCertificateApiPassthroughSubjectOutputReference;
    putSubject(value: AcmpcaCertificateApiPassthroughSubject): void;
    resetSubject(): void;
    get subjectInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthroughSubject | undefined;
}
export interface AcmpcaCertificateValidity {
    /**
    * Specifies whether the ``Value`` parameter represents days, months, or years.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#type AcmpcaCertificate#type}
    */
    readonly type: string;
    /**
    * A long integer interpreted according to the value of ``Type``, below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#value AcmpcaCertificate#value}
    */
    readonly value: number;
}
export declare function acmpcaCertificateValidityToTerraform(struct?: AcmpcaCertificateValidity | cdktn.IResolvable): any;
export declare function acmpcaCertificateValidityToHclTerraform(struct?: AcmpcaCertificateValidity | cdktn.IResolvable): any;
export declare class AcmpcaCertificateValidityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateValidity | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateValidity | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export interface AcmpcaCertificateValidityNotBefore {
    /**
    * Specifies whether the ``Value`` parameter represents days, months, or years.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#type AcmpcaCertificate#type}
    */
    readonly type?: string;
    /**
    * A long integer interpreted according to the value of ``Type``, below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#value AcmpcaCertificate#value}
    */
    readonly value?: number;
}
export declare function acmpcaCertificateValidityNotBeforeToTerraform(struct?: AcmpcaCertificateValidityNotBefore | cdktn.IResolvable): any;
export declare function acmpcaCertificateValidityNotBeforeToHclTerraform(struct?: AcmpcaCertificateValidityNotBefore | cdktn.IResolvable): any;
export declare class AcmpcaCertificateValidityNotBeforeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AcmpcaCertificateValidityNotBefore | cdktn.IResolvable | undefined;
    set internalValue(value: AcmpcaCertificateValidityNotBefore | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate awscc_acmpca_certificate}
*/
export declare class AcmpcaCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_acmpca_certificate";
    /**
    * Generates CDKTN code for importing a AcmpcaCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AcmpcaCertificate to import
    * @param importFromId The id of the existing AcmpcaCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AcmpcaCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/acmpca_certificate awscc_acmpca_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AcmpcaCertificateConfig
    */
    constructor(scope: Construct, id: string, config: AcmpcaCertificateConfig);
    private _apiPassthrough;
    get apiPassthrough(): AcmpcaCertificateApiPassthroughOutputReference;
    putApiPassthrough(value: AcmpcaCertificateApiPassthrough): void;
    resetApiPassthrough(): void;
    get apiPassthroughInput(): cdktn.IResolvable | AcmpcaCertificateApiPassthrough | undefined;
    get arn(): string;
    get certificate(): string;
    private _certificateAuthorityArn?;
    get certificateAuthorityArn(): string;
    set certificateAuthorityArn(value: string);
    get certificateAuthorityArnInput(): string | undefined;
    private _certificateSigningRequest?;
    get certificateSigningRequest(): string;
    set certificateSigningRequest(value: string);
    get certificateSigningRequestInput(): string | undefined;
    get id(): string;
    private _signingAlgorithm?;
    get signingAlgorithm(): string;
    set signingAlgorithm(value: string);
    get signingAlgorithmInput(): string | undefined;
    private _templateArn?;
    get templateArn(): string;
    set templateArn(value: string);
    resetTemplateArn(): void;
    get templateArnInput(): string | undefined;
    private _validity;
    get validity(): AcmpcaCertificateValidityOutputReference;
    putValidity(value: AcmpcaCertificateValidity): void;
    get validityInput(): cdktn.IResolvable | AcmpcaCertificateValidity | undefined;
    private _validityNotBefore;
    get validityNotBefore(): AcmpcaCertificateValidityNotBeforeOutputReference;
    putValidityNotBefore(value: AcmpcaCertificateValidityNotBefore): void;
    resetValidityNotBefore(): void;
    get validityNotBeforeInput(): cdktn.IResolvable | AcmpcaCertificateValidityNotBefore | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
