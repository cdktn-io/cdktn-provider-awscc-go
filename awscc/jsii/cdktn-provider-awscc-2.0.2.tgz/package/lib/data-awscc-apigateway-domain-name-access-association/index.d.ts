/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayDomainNameAccessAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_domain_name_access_association#id DataAwsccApigatewayDomainNameAccessAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayDomainNameAccessAssociationTags {
}
export declare function dataAwsccApigatewayDomainNameAccessAssociationTagsToTerraform(struct?: DataAwsccApigatewayDomainNameAccessAssociationTags): any;
export declare function dataAwsccApigatewayDomainNameAccessAssociationTagsToHclTerraform(struct?: DataAwsccApigatewayDomainNameAccessAssociationTags): any;
export declare class DataAwsccApigatewayDomainNameAccessAssociationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayDomainNameAccessAssociationTags | undefined;
    set internalValue(value: DataAwsccApigatewayDomainNameAccessAssociationTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayDomainNameAccessAssociationTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayDomainNameAccessAssociationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_domain_name_access_association awscc_apigateway_domain_name_access_association}
*/
export declare class DataAwsccApigatewayDomainNameAccessAssociation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_domain_name_access_association";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayDomainNameAccessAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayDomainNameAccessAssociation to import
    * @param importFromId The id of the existing DataAwsccApigatewayDomainNameAccessAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_domain_name_access_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayDomainNameAccessAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_domain_name_access_association awscc_apigateway_domain_name_access_association} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayDomainNameAccessAssociationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayDomainNameAccessAssociationConfig);
    get accessAssociationSource(): string;
    get accessAssociationSourceType(): string;
    get domainNameAccessAssociationArn(): string;
    get domainNameArn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _tags;
    get tags(): DataAwsccApigatewayDomainNameAccessAssociationTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
