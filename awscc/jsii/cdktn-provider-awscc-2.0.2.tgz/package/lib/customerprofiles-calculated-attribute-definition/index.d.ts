/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesCalculatedAttributeDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Mathematical expression and a list of attribute items specified in that expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#attribute_details CustomerprofilesCalculatedAttributeDefinition#attribute_details}
    */
    readonly attributeDetails: CustomerprofilesCalculatedAttributeDefinitionAttributeDetails;
    /**
    * The unique name of the calculated attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#calculated_attribute_name CustomerprofilesCalculatedAttributeDefinition#calculated_attribute_name}
    */
    readonly calculatedAttributeName: string;
    /**
    * The conditions including range, object count, and threshold for the calculated attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#conditions CustomerprofilesCalculatedAttributeDefinition#conditions}
    */
    readonly conditions?: CustomerprofilesCalculatedAttributeDefinitionConditions;
    /**
    * The description of the calculated attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#description CustomerprofilesCalculatedAttributeDefinition#description}
    */
    readonly description?: string;
    /**
    * The display name of the calculated attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#display_name CustomerprofilesCalculatedAttributeDefinition#display_name}
    */
    readonly displayName?: string;
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#domain_name CustomerprofilesCalculatedAttributeDefinition#domain_name}
    */
    readonly domainName: string;
    /**
    * Defines how to filter the objects coming in for calculated attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#filter CustomerprofilesCalculatedAttributeDefinition#filter}
    */
    readonly filter?: CustomerprofilesCalculatedAttributeDefinitionFilter;
    /**
    * The aggregation operation to perform for the calculated attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#statistic CustomerprofilesCalculatedAttributeDefinition#statistic}
    */
    readonly statistic: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#tags CustomerprofilesCalculatedAttributeDefinition#tags}
    */
    readonly tags?: CustomerprofilesCalculatedAttributeDefinitionTags[] | cdktn.IResolvable;
    /**
    * Whether to use historical data for the calculated attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#use_historical_data CustomerprofilesCalculatedAttributeDefinition#use_historical_data}
    */
    readonly useHistoricalData?: boolean | cdktn.IResolvable;
}
export interface CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes {
    /**
    * The name of an attribute defined in a profile object type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#name CustomerprofilesCalculatedAttributeDefinition#name}
    */
    readonly name: string;
}
export declare function customerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributesToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributesToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributesList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributesOutputReference;
}
export interface CustomerprofilesCalculatedAttributeDefinitionAttributeDetails {
    /**
    * A list of attribute items specified in the mathematical expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#attributes CustomerprofilesCalculatedAttributeDefinition#attributes}
    */
    readonly attributes: CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes[] | cdktn.IResolvable;
    /**
    * Mathematical expression that is performed on attribute items provided in the attribute list. Each element in the expression should follow the structure of "{ObjectTypeName.AttributeName}".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#expression CustomerprofilesCalculatedAttributeDefinition#expression}
    */
    readonly expression: string;
}
export declare function customerprofilesCalculatedAttributeDefinitionAttributeDetailsToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionAttributeDetails | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionAttributeDetailsToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionAttributeDetails | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionAttributeDetails | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionAttributeDetails | cdktn.IResolvable | undefined);
    private _attributes;
    get attributes(): CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributesList;
    putAttributes(value: CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes[] | cdktn.IResolvable): void;
    get attributesInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsAttributes[] | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRange {
    /**
    * The ending point for this range. Positive numbers indicate how many days in the past data should be included, and negative numbers indicate how many days in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#end CustomerprofilesCalculatedAttributeDefinition#end}
    */
    readonly end?: number;
    /**
    * The starting point for this range. Positive numbers indicate how many days in the past data should be included, and negative numbers indicate how many days in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#start CustomerprofilesCalculatedAttributeDefinition#start}
    */
    readonly start?: number;
}
export declare function customerprofilesCalculatedAttributeDefinitionConditionsRangeValueRangeToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRange | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionConditionsRangeValueRangeToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRange | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRange | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRange | cdktn.IResolvable | undefined);
    private _end?;
    get end(): number;
    set end(value: number);
    resetEnd(): void;
    get endInput(): number | undefined;
    private _start?;
    get start(): number;
    set start(value: number);
    resetStart(): void;
    get startInput(): number | undefined;
}
export interface CustomerprofilesCalculatedAttributeDefinitionConditionsRange {
    /**
    * The format the timestamp field in your JSON object is specified. This value should be one of EPOCHMILLI or ISO_8601. E.g. if your object type is MyType and source JSON is {"generatedAt": {"timestamp": "2001-07-04T12:08:56.235Z"}}, then TimestampFormat should be "ISO_8601".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#timestamp_format CustomerprofilesCalculatedAttributeDefinition#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * An expression specifying the field in your JSON object from which the date should be parsed. The expression should follow the structure of \"{ObjectTypeName.<Location of timestamp field in JSON pointer format>}\". E.g. if your object type is MyType and source JSON is {"generatedAt": {"timestamp": "1737587945945"}}, then TimestampSource should be "{MyType.generatedAt.timestamp}".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#timestamp_source CustomerprofilesCalculatedAttributeDefinition#timestamp_source}
    */
    readonly timestampSource?: string;
    /**
    * The unit of time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#unit CustomerprofilesCalculatedAttributeDefinition#unit}
    */
    readonly unit?: string;
    /**
    * The amount of time of the specified unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#value CustomerprofilesCalculatedAttributeDefinition#value}
    */
    readonly value?: number;
    /**
    * A structure specifying the endpoints of the relative time period over which data is included in the aggregation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#value_range CustomerprofilesCalculatedAttributeDefinition#value_range}
    */
    readonly valueRange?: CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRange;
}
export declare function customerprofilesCalculatedAttributeDefinitionConditionsRangeToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionConditionsRange | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionConditionsRangeToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionConditionsRange | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionConditionsRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionConditionsRange | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionConditionsRange | cdktn.IResolvable | undefined);
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _timestampSource?;
    get timestampSource(): string;
    set timestampSource(value: string);
    resetTimestampSource(): void;
    get timestampSourceInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
    private _valueRange;
    get valueRange(): CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRangeOutputReference;
    putValueRange(value: CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRange): void;
    resetValueRange(): void;
    get valueRangeInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionConditionsRangeValueRange | undefined;
}
export interface CustomerprofilesCalculatedAttributeDefinitionConditionsThreshold {
    /**
    * The operator of the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#operator CustomerprofilesCalculatedAttributeDefinition#operator}
    */
    readonly operator?: string;
    /**
    * The value of the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#value CustomerprofilesCalculatedAttributeDefinition#value}
    */
    readonly value?: string;
}
export declare function customerprofilesCalculatedAttributeDefinitionConditionsThresholdToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionConditionsThreshold | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionConditionsThresholdToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionConditionsThreshold | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionConditionsThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionConditionsThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionConditionsThreshold | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface CustomerprofilesCalculatedAttributeDefinitionConditions {
    /**
    * The number of profile objects used for the calculated attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#object_count CustomerprofilesCalculatedAttributeDefinition#object_count}
    */
    readonly objectCount?: number;
    /**
    * The relative time period over which data is included in the aggregation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#range CustomerprofilesCalculatedAttributeDefinition#range}
    */
    readonly range?: CustomerprofilesCalculatedAttributeDefinitionConditionsRange;
    /**
    * The threshold for the calculated attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#threshold CustomerprofilesCalculatedAttributeDefinition#threshold}
    */
    readonly threshold?: CustomerprofilesCalculatedAttributeDefinitionConditionsThreshold;
}
export declare function customerprofilesCalculatedAttributeDefinitionConditionsToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionConditions | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionConditionsToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionConditions | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionConditions | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionConditions | cdktn.IResolvable | undefined);
    private _objectCount?;
    get objectCount(): number;
    set objectCount(value: number);
    resetObjectCount(): void;
    get objectCountInput(): number | undefined;
    private _range;
    get range(): CustomerprofilesCalculatedAttributeDefinitionConditionsRangeOutputReference;
    putRange(value: CustomerprofilesCalculatedAttributeDefinitionConditionsRange): void;
    resetRange(): void;
    get rangeInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionConditionsRange | undefined;
    private _threshold;
    get threshold(): CustomerprofilesCalculatedAttributeDefinitionConditionsThresholdOutputReference;
    putThreshold(value: CustomerprofilesCalculatedAttributeDefinitionConditionsThreshold): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionConditionsThreshold | undefined;
}
export interface CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes {
    /**
    * The action to filter with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#dimension_type CustomerprofilesCalculatedAttributeDefinition#dimension_type}
    */
    readonly dimensionType?: string;
    /**
    * The values to apply the DimensionType on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#values CustomerprofilesCalculatedAttributeDefinition#values}
    */
    readonly values?: string[];
}
export declare function customerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributesToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributesToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes | cdktn.IResolvable | undefined);
    private _dimensionType?;
    get dimensionType(): string;
    set dimensionType(value: string);
    resetDimensionType(): void;
    get dimensionTypeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributesMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributesOutputReference;
}
export interface CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions {
    /**
    * Is the attribute within the FilterDimension map
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#attributes CustomerprofilesCalculatedAttributeDefinition#attributes}
    */
    readonly attributes?: {
        [key: string]: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes;
    } | cdktn.IResolvable;
}
export declare function customerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions | cdktn.IResolvable | undefined);
    private _attributes;
    get attributes(): CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributesMap;
    putAttributes(value: {
        [key: string]: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes;
    } | cdktn.IResolvable): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | {
        [key: string]: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsAttributes;
    } | undefined;
}
export declare class CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsOutputReference;
}
export interface CustomerprofilesCalculatedAttributeDefinitionFilterGroups {
    /**
    * Object that holds the attributes to filter on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#dimensions CustomerprofilesCalculatedAttributeDefinition#dimensions}
    */
    readonly dimensions?: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions[] | cdktn.IResolvable;
    /**
    * The type of logical relationship between the dimensions of the Filter group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#type CustomerprofilesCalculatedAttributeDefinition#type}
    */
    readonly type?: string;
}
export declare function customerprofilesCalculatedAttributeDefinitionFilterGroupsToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionFilterGroups | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionFilterGroupsToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionFilterGroups | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionFilterGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionFilterGroups | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionFilterGroups | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensionsList;
    putDimensions(value: CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionFilterGroupsDimensions[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CustomerprofilesCalculatedAttributeDefinitionFilterGroupsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesCalculatedAttributeDefinitionFilterGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesCalculatedAttributeDefinitionFilterGroupsOutputReference;
}
export interface CustomerprofilesCalculatedAttributeDefinitionFilter {
    /**
    * Holds the list of Filter groups within the Filter definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#groups CustomerprofilesCalculatedAttributeDefinition#groups}
    */
    readonly groups?: CustomerprofilesCalculatedAttributeDefinitionFilterGroups[] | cdktn.IResolvable;
    /**
    * Define whether to include or exclude objects for Calculated Attributed calculation that fit the filter groups criteria.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#include CustomerprofilesCalculatedAttributeDefinition#include}
    */
    readonly include?: string;
}
export declare function customerprofilesCalculatedAttributeDefinitionFilterToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionFilter | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionFilterToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionFilter | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionFilter | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionFilter | cdktn.IResolvable | undefined);
    private _groups;
    get groups(): CustomerprofilesCalculatedAttributeDefinitionFilterGroupsList;
    putGroups(value: CustomerprofilesCalculatedAttributeDefinitionFilterGroups[] | cdktn.IResolvable): void;
    resetGroups(): void;
    get groupsInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionFilterGroups[] | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    resetInclude(): void;
    get includeInput(): string | undefined;
}
export interface CustomerprofilesCalculatedAttributeDefinitionReadiness {
}
export declare function customerprofilesCalculatedAttributeDefinitionReadinessToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionReadiness): any;
export declare function customerprofilesCalculatedAttributeDefinitionReadinessToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionReadiness): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionReadinessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionReadiness | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionReadiness | undefined);
    get message(): string;
    get progressPercentage(): number;
}
export interface CustomerprofilesCalculatedAttributeDefinitionTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#key CustomerprofilesCalculatedAttributeDefinition#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#value CustomerprofilesCalculatedAttributeDefinition#value}
    */
    readonly value?: string;
}
export declare function customerprofilesCalculatedAttributeDefinitionTagsToTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionTags | cdktn.IResolvable): any;
export declare function customerprofilesCalculatedAttributeDefinitionTagsToHclTerraform(struct?: CustomerprofilesCalculatedAttributeDefinitionTags | cdktn.IResolvable): any;
export declare class CustomerprofilesCalculatedAttributeDefinitionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesCalculatedAttributeDefinitionTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesCalculatedAttributeDefinitionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesCalculatedAttributeDefinitionTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesCalculatedAttributeDefinitionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesCalculatedAttributeDefinitionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition awscc_customerprofiles_calculated_attribute_definition}
*/
export declare class CustomerprofilesCalculatedAttributeDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_calculated_attribute_definition";
    /**
    * Generates CDKTN code for importing a CustomerprofilesCalculatedAttributeDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesCalculatedAttributeDefinition to import
    * @param importFromId The id of the existing CustomerprofilesCalculatedAttributeDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesCalculatedAttributeDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/customerprofiles_calculated_attribute_definition awscc_customerprofiles_calculated_attribute_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesCalculatedAttributeDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesCalculatedAttributeDefinitionConfig);
    private _attributeDetails;
    get attributeDetails(): CustomerprofilesCalculatedAttributeDefinitionAttributeDetailsOutputReference;
    putAttributeDetails(value: CustomerprofilesCalculatedAttributeDefinitionAttributeDetails): void;
    get attributeDetailsInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionAttributeDetails | undefined;
    private _calculatedAttributeName?;
    get calculatedAttributeName(): string;
    set calculatedAttributeName(value: string);
    get calculatedAttributeNameInput(): string | undefined;
    private _conditions;
    get conditions(): CustomerprofilesCalculatedAttributeDefinitionConditionsOutputReference;
    putConditions(value: CustomerprofilesCalculatedAttributeDefinitionConditions): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionConditions | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _filter;
    get filter(): CustomerprofilesCalculatedAttributeDefinitionFilterOutputReference;
    putFilter(value: CustomerprofilesCalculatedAttributeDefinitionFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionFilter | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    private _readiness;
    get readiness(): CustomerprofilesCalculatedAttributeDefinitionReadinessOutputReference;
    private _statistic?;
    get statistic(): string;
    set statistic(value: string);
    get statisticInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): CustomerprofilesCalculatedAttributeDefinitionTagsList;
    putTags(value: CustomerprofilesCalculatedAttributeDefinitionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesCalculatedAttributeDefinitionTags[] | undefined;
    private _useHistoricalData?;
    get useHistoricalData(): boolean | cdktn.IResolvable;
    set useHistoricalData(value: boolean | cdktn.IResolvable);
    resetUseHistoricalData(): void;
    get useHistoricalDataInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
