/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAmplifyAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/amplify_app#id DataAwsccAmplifyApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfig {
}
export declare function dataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfigToTerraform(struct?: DataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfig): any;
export declare function dataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfigToHclTerraform(struct?: DataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfig): any;
export declare class DataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfig | undefined;
    set internalValue(value: DataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfig | undefined);
    get enableBasicAuth(): cdktn.IResolvable;
    get password(): string;
    get username(): string;
}
export interface DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariables {
}
export declare function dataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariablesToTerraform(struct?: DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariables): any;
export declare function dataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariablesToHclTerraform(struct?: DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariables): any;
export declare class DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariables | undefined;
    set internalValue(value: DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariables | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariablesOutputReference;
}
export interface DataAwsccAmplifyAppAutoBranchCreationConfig {
}
export declare function dataAwsccAmplifyAppAutoBranchCreationConfigToTerraform(struct?: DataAwsccAmplifyAppAutoBranchCreationConfig): any;
export declare function dataAwsccAmplifyAppAutoBranchCreationConfigToHclTerraform(struct?: DataAwsccAmplifyAppAutoBranchCreationConfig): any;
export declare class DataAwsccAmplifyAppAutoBranchCreationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyAppAutoBranchCreationConfig | undefined;
    set internalValue(value: DataAwsccAmplifyAppAutoBranchCreationConfig | undefined);
    get autoBranchCreationPatterns(): string[];
    private _basicAuthConfig;
    get basicAuthConfig(): DataAwsccAmplifyAppAutoBranchCreationConfigBasicAuthConfigOutputReference;
    get buildSpec(): string;
    get enableAutoBranchCreation(): cdktn.IResolvable;
    get enableAutoBuild(): cdktn.IResolvable;
    get enablePerformanceMode(): cdktn.IResolvable;
    get enablePullRequestPreview(): cdktn.IResolvable;
    private _environmentVariables;
    get environmentVariables(): DataAwsccAmplifyAppAutoBranchCreationConfigEnvironmentVariablesList;
    get framework(): string;
    get pullRequestEnvironmentName(): string;
    get stage(): string;
}
export interface DataAwsccAmplifyAppBasicAuthConfig {
}
export declare function dataAwsccAmplifyAppBasicAuthConfigToTerraform(struct?: DataAwsccAmplifyAppBasicAuthConfig): any;
export declare function dataAwsccAmplifyAppBasicAuthConfigToHclTerraform(struct?: DataAwsccAmplifyAppBasicAuthConfig): any;
export declare class DataAwsccAmplifyAppBasicAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyAppBasicAuthConfig | undefined;
    set internalValue(value: DataAwsccAmplifyAppBasicAuthConfig | undefined);
    get enableBasicAuth(): cdktn.IResolvable;
    get password(): string;
    get username(): string;
}
export interface DataAwsccAmplifyAppCacheConfig {
}
export declare function dataAwsccAmplifyAppCacheConfigToTerraform(struct?: DataAwsccAmplifyAppCacheConfig): any;
export declare function dataAwsccAmplifyAppCacheConfigToHclTerraform(struct?: DataAwsccAmplifyAppCacheConfig): any;
export declare class DataAwsccAmplifyAppCacheConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyAppCacheConfig | undefined;
    set internalValue(value: DataAwsccAmplifyAppCacheConfig | undefined);
    get type(): string;
}
export interface DataAwsccAmplifyAppCustomRules {
}
export declare function dataAwsccAmplifyAppCustomRulesToTerraform(struct?: DataAwsccAmplifyAppCustomRules): any;
export declare function dataAwsccAmplifyAppCustomRulesToHclTerraform(struct?: DataAwsccAmplifyAppCustomRules): any;
export declare class DataAwsccAmplifyAppCustomRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAmplifyAppCustomRules | undefined;
    set internalValue(value: DataAwsccAmplifyAppCustomRules | undefined);
    get condition(): string;
    get source(): string;
    get status(): string;
    get target(): string;
}
export declare class DataAwsccAmplifyAppCustomRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAmplifyAppCustomRulesOutputReference;
}
export interface DataAwsccAmplifyAppEnvironmentVariables {
}
export declare function dataAwsccAmplifyAppEnvironmentVariablesToTerraform(struct?: DataAwsccAmplifyAppEnvironmentVariables): any;
export declare function dataAwsccAmplifyAppEnvironmentVariablesToHclTerraform(struct?: DataAwsccAmplifyAppEnvironmentVariables): any;
export declare class DataAwsccAmplifyAppEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAmplifyAppEnvironmentVariables | undefined;
    set internalValue(value: DataAwsccAmplifyAppEnvironmentVariables | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataAwsccAmplifyAppEnvironmentVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAmplifyAppEnvironmentVariablesOutputReference;
}
export interface DataAwsccAmplifyAppJobConfig {
}
export declare function dataAwsccAmplifyAppJobConfigToTerraform(struct?: DataAwsccAmplifyAppJobConfig): any;
export declare function dataAwsccAmplifyAppJobConfigToHclTerraform(struct?: DataAwsccAmplifyAppJobConfig): any;
export declare class DataAwsccAmplifyAppJobConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyAppJobConfig | undefined;
    set internalValue(value: DataAwsccAmplifyAppJobConfig | undefined);
    get buildComputeType(): string;
}
export interface DataAwsccAmplifyAppTags {
}
export declare function dataAwsccAmplifyAppTagsToTerraform(struct?: DataAwsccAmplifyAppTags): any;
export declare function dataAwsccAmplifyAppTagsToHclTerraform(struct?: DataAwsccAmplifyAppTags): any;
export declare class DataAwsccAmplifyAppTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAmplifyAppTags | undefined;
    set internalValue(value: DataAwsccAmplifyAppTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAmplifyAppTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAmplifyAppTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/amplify_app awscc_amplify_app}
*/
export declare class DataAwsccAmplifyApp extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_amplify_app";
    /**
    * Generates CDKTN code for importing a DataAwsccAmplifyApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAmplifyApp to import
    * @param importFromId The id of the existing DataAwsccAmplifyApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/amplify_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAmplifyApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/amplify_app awscc_amplify_app} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAmplifyAppConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAmplifyAppConfig);
    get accessToken(): string;
    get appId(): string;
    get appName(): string;
    get arn(): string;
    private _autoBranchCreationConfig;
    get autoBranchCreationConfig(): DataAwsccAmplifyAppAutoBranchCreationConfigOutputReference;
    private _basicAuthConfig;
    get basicAuthConfig(): DataAwsccAmplifyAppBasicAuthConfigOutputReference;
    get buildSpec(): string;
    private _cacheConfig;
    get cacheConfig(): DataAwsccAmplifyAppCacheConfigOutputReference;
    get computeRoleArn(): string;
    get customHeaders(): string;
    private _customRules;
    get customRules(): DataAwsccAmplifyAppCustomRulesList;
    get defaultDomain(): string;
    get description(): string;
    get enableBranchAutoDeletion(): cdktn.IResolvable;
    private _environmentVariables;
    get environmentVariables(): DataAwsccAmplifyAppEnvironmentVariablesList;
    get iamServiceRole(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _jobConfig;
    get jobConfig(): DataAwsccAmplifyAppJobConfigOutputReference;
    get name(): string;
    get oauthToken(): string;
    get platform(): string;
    get repository(): string;
    private _tags;
    get tags(): DataAwsccAmplifyAppTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
