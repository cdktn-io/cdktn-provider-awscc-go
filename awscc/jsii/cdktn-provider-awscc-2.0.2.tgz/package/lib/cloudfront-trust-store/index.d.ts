/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontTrustStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * A CA certificates bundle source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#ca_certificates_bundle_source CloudfrontTrustStore#ca_certificates_bundle_source}
    */
    readonly caCertificatesBundleSource?: CloudfrontTrustStoreCaCertificatesBundleSource;
    /**
    * The trust store's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#name CloudfrontTrustStore#name}
    */
    readonly name: string;
    /**
    * A complex type that contains zero or more ``Tag`` elements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#tags CloudfrontTrustStore#tags}
    */
    readonly tags?: CloudfrontTrustStoreTags[] | cdktn.IResolvable;
    /**
    * A boolean. When true, performs real-time certificate revocation checks by querying the OCSP endpoint specified within the client certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#use_client_certificate_ocsp_endpoint CloudfrontTrustStore#use_client_certificate_ocsp_endpoint}
    */
    readonly useClientCertificateOcspEndpoint?: boolean | cdktn.IResolvable;
}
export interface CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location {
    /**
    * The S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#bucket CloudfrontTrustStore#bucket}
    */
    readonly bucket?: string;
    /**
    * The location's key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#key CloudfrontTrustStore#key}
    */
    readonly key?: string;
    /**
    * The location's Region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#region CloudfrontTrustStore#region}
    */
    readonly region?: string;
    /**
    * The location's version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#version CloudfrontTrustStore#version}
    */
    readonly version?: string;
}
export declare function cloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationToTerraform(struct?: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | cdktn.IResolvable): any;
export declare function cloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationToHclTerraform(struct?: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | cdktn.IResolvable): any;
export declare class CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface CloudfrontTrustStoreCaCertificatesBundleSource {
    /**
    * The CA certificates bundle location in Amazon S3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#ca_certificates_bundle_s3_location CloudfrontTrustStore#ca_certificates_bundle_s3_location}
    */
    readonly caCertificatesBundleS3Location?: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location;
}
export declare function cloudfrontTrustStoreCaCertificatesBundleSourceToTerraform(struct?: CloudfrontTrustStoreCaCertificatesBundleSource | cdktn.IResolvable): any;
export declare function cloudfrontTrustStoreCaCertificatesBundleSourceToHclTerraform(struct?: CloudfrontTrustStoreCaCertificatesBundleSource | cdktn.IResolvable): any;
export declare class CloudfrontTrustStoreCaCertificatesBundleSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontTrustStoreCaCertificatesBundleSource | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontTrustStoreCaCertificatesBundleSource | cdktn.IResolvable | undefined);
    private _caCertificatesBundleS3Location;
    get caCertificatesBundleS3Location(): CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationOutputReference;
    putCaCertificatesBundleS3Location(value: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location): void;
    resetCaCertificatesBundleS3Location(): void;
    get caCertificatesBundleS3LocationInput(): cdktn.IResolvable | CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | undefined;
}
export interface CloudfrontTrustStoreTags {
    /**
    * A string that contains ``Tag`` key.
    *  The string length should be between 1 and 128 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#key CloudfrontTrustStore#key}
    */
    readonly key?: string;
    /**
    * A string that contains an optional ``Tag`` value.
    *  The string length should be between 0 and 256 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#value CloudfrontTrustStore#value}
    */
    readonly value?: string;
}
export declare function cloudfrontTrustStoreTagsToTerraform(struct?: CloudfrontTrustStoreTags | cdktn.IResolvable): any;
export declare function cloudfrontTrustStoreTagsToHclTerraform(struct?: CloudfrontTrustStoreTags | cdktn.IResolvable): any;
export declare class CloudfrontTrustStoreTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontTrustStoreTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontTrustStoreTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontTrustStoreTagsList extends cdktn.ComplexList {
    internalValue?: CloudfrontTrustStoreTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontTrustStoreTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store awscc_cloudfront_trust_store}
*/
export declare class CloudfrontTrustStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_trust_store";
    /**
    * Generates CDKTN code for importing a CloudfrontTrustStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontTrustStore to import
    * @param importFromId The id of the existing CloudfrontTrustStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontTrustStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_trust_store awscc_cloudfront_trust_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontTrustStoreConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontTrustStoreConfig);
    get arn(): string;
    private _caCertificatesBundleSource;
    get caCertificatesBundleSource(): CloudfrontTrustStoreCaCertificatesBundleSourceOutputReference;
    putCaCertificatesBundleSource(value: CloudfrontTrustStoreCaCertificatesBundleSource): void;
    resetCaCertificatesBundleSource(): void;
    get caCertificatesBundleSourceInput(): cdktn.IResolvable | CloudfrontTrustStoreCaCertificatesBundleSource | undefined;
    get eTag(): string;
    get id(): string;
    get lastModifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get numberOfCaCertificates(): number;
    get status(): string;
    private _tags;
    get tags(): CloudfrontTrustStoreTagsList;
    putTags(value: CloudfrontTrustStoreTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudfrontTrustStoreTags[] | undefined;
    get trustStoreId(): string;
    private _useClientCertificateOcspEndpoint?;
    get useClientCertificateOcspEndpoint(): boolean | cdktn.IResolvable;
    set useClientCertificateOcspEndpoint(value: boolean | cdktn.IResolvable);
    resetUseClientCertificateOcspEndpoint(): void;
    get useClientCertificateOcspEndpointInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
