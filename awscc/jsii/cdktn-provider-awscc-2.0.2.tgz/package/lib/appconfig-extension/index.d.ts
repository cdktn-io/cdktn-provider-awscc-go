/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigExtensionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#actions AppconfigExtension#actions}
    */
    readonly actions: {
        [key: string]: AppconfigExtensionActions;
    } | cdktn.IResolvable;
    /**
    * Description of the extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#description AppconfigExtension#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#latest_version_number AppconfigExtension#latest_version_number}
    */
    readonly latestVersionNumber?: number;
    /**
    * Name of the extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#name AppconfigExtension#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#parameters AppconfigExtension#parameters}
    */
    readonly parameters?: {
        [key: string]: AppconfigExtensionParameters;
    } | cdktn.IResolvable;
    /**
    * An array of key-value tags to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#tags AppconfigExtension#tags}
    */
    readonly tags?: AppconfigExtensionTags[] | cdktn.IResolvable;
}
export interface AppconfigExtensionActions {
    /**
    * The description of the extension Action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#description AppconfigExtension#description}
    */
    readonly description?: string;
    /**
    * The name of the extension action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#name AppconfigExtension#name}
    */
    readonly name?: string;
    /**
    * The ARN of the role for invoking the extension action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#role_arn AppconfigExtension#role_arn}
    */
    readonly roleArn?: string;
    /**
    * The URI of the extension action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#uri AppconfigExtension#uri}
    */
    readonly uri?: string;
}
export declare function appconfigExtensionActionsToTerraform(struct?: AppconfigExtensionActions | cdktn.IResolvable): any;
export declare function appconfigExtensionActionsToHclTerraform(struct?: AppconfigExtensionActions | cdktn.IResolvable): any;
export declare class AppconfigExtensionActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AppconfigExtensionActions | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExtensionActions | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export declare class AppconfigExtensionActionsMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: AppconfigExtensionActions;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AppconfigExtensionActionsOutputReference;
}
export interface AppconfigExtensionParameters {
    /**
    * The description of the extension Parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#description AppconfigExtension#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#dynamic AppconfigExtension#dynamic}
    */
    readonly dynamic?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#required AppconfigExtension#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
}
export declare function appconfigExtensionParametersToTerraform(struct?: AppconfigExtensionParameters | cdktn.IResolvable): any;
export declare function appconfigExtensionParametersToHclTerraform(struct?: AppconfigExtensionParameters | cdktn.IResolvable): any;
export declare class AppconfigExtensionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AppconfigExtensionParameters | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExtensionParameters | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dynamic?;
    get dynamic(): boolean | cdktn.IResolvable;
    set dynamic(value: boolean | cdktn.IResolvable);
    resetDynamic(): void;
    get dynamicInput(): boolean | cdktn.IResolvable | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AppconfigExtensionParametersMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: AppconfigExtensionParameters;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AppconfigExtensionParametersOutputReference;
}
export interface AppconfigExtensionTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#key AppconfigExtension#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#value AppconfigExtension#value}
    */
    readonly value?: string;
}
export declare function appconfigExtensionTagsToTerraform(struct?: AppconfigExtensionTags | cdktn.IResolvable): any;
export declare function appconfigExtensionTagsToHclTerraform(struct?: AppconfigExtensionTags | cdktn.IResolvable): any;
export declare class AppconfigExtensionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigExtensionTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExtensionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppconfigExtensionTagsList extends cdktn.ComplexList {
    internalValue?: AppconfigExtensionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigExtensionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension awscc_appconfig_extension}
*/
export declare class AppconfigExtension extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appconfig_extension";
    /**
    * Generates CDKTN code for importing a AppconfigExtension resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigExtension to import
    * @param importFromId The id of the existing AppconfigExtension that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigExtension to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appconfig_extension awscc_appconfig_extension} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigExtensionConfig
    */
    constructor(scope: Construct, id: string, config: AppconfigExtensionConfig);
    private _actions;
    get actions(): AppconfigExtensionActionsMap;
    putActions(value: {
        [key: string]: AppconfigExtensionActions;
    } | cdktn.IResolvable): void;
    get actionsInput(): cdktn.IResolvable | {
        [key: string]: AppconfigExtensionActions;
    } | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get extensionId(): string;
    get id(): string;
    private _latestVersionNumber?;
    get latestVersionNumber(): number;
    set latestVersionNumber(value: number);
    resetLatestVersionNumber(): void;
    get latestVersionNumberInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): AppconfigExtensionParametersMap;
    putParameters(value: {
        [key: string]: AppconfigExtensionParameters;
    } | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | {
        [key: string]: AppconfigExtensionParameters;
    } | undefined;
    private _tags;
    get tags(): AppconfigExtensionTagsList;
    putTags(value: AppconfigExtensionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppconfigExtensionTags[] | undefined;
    get versionNumber(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
