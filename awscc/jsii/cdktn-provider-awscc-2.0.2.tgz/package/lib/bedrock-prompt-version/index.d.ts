/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockPromptVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description for a prompt version resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt_version#description BedrockPromptVersion#description}
    */
    readonly description?: string;
    /**
    * ARN of a prompt resource possibly with a version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt_version#prompt_arn BedrockPromptVersion#prompt_arn}
    */
    readonly promptArn: string;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt_version#tags BedrockPromptVersion#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BedrockPromptVersionVariantsGenAiResourceAgent {
}
export declare function bedrockPromptVersionVariantsGenAiResourceAgentToTerraform(struct?: BedrockPromptVersionVariantsGenAiResourceAgent): any;
export declare function bedrockPromptVersionVariantsGenAiResourceAgentToHclTerraform(struct?: BedrockPromptVersionVariantsGenAiResourceAgent): any;
export declare class BedrockPromptVersionVariantsGenAiResourceAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsGenAiResourceAgent | undefined;
    set internalValue(value: BedrockPromptVersionVariantsGenAiResourceAgent | undefined);
    get agentIdentifier(): string;
}
export interface BedrockPromptVersionVariantsGenAiResource {
}
export declare function bedrockPromptVersionVariantsGenAiResourceToTerraform(struct?: BedrockPromptVersionVariantsGenAiResource): any;
export declare function bedrockPromptVersionVariantsGenAiResourceToHclTerraform(struct?: BedrockPromptVersionVariantsGenAiResource): any;
export declare class BedrockPromptVersionVariantsGenAiResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsGenAiResource | undefined;
    set internalValue(value: BedrockPromptVersionVariantsGenAiResource | undefined);
    private _agent;
    get agent(): BedrockPromptVersionVariantsGenAiResourceAgentOutputReference;
}
export interface BedrockPromptVersionVariantsInferenceConfigurationText {
}
export declare function bedrockPromptVersionVariantsInferenceConfigurationTextToTerraform(struct?: BedrockPromptVersionVariantsInferenceConfigurationText): any;
export declare function bedrockPromptVersionVariantsInferenceConfigurationTextToHclTerraform(struct?: BedrockPromptVersionVariantsInferenceConfigurationText): any;
export declare class BedrockPromptVersionVariantsInferenceConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsInferenceConfigurationText | undefined;
    set internalValue(value: BedrockPromptVersionVariantsInferenceConfigurationText | undefined);
    get maxTokens(): number;
    get stopSequences(): string[];
    get temperature(): number;
    get topP(): number;
}
export interface BedrockPromptVersionVariantsInferenceConfiguration {
}
export declare function bedrockPromptVersionVariantsInferenceConfigurationToTerraform(struct?: BedrockPromptVersionVariantsInferenceConfiguration): any;
export declare function bedrockPromptVersionVariantsInferenceConfigurationToHclTerraform(struct?: BedrockPromptVersionVariantsInferenceConfiguration): any;
export declare class BedrockPromptVersionVariantsInferenceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsInferenceConfiguration | undefined;
    set internalValue(value: BedrockPromptVersionVariantsInferenceConfiguration | undefined);
    private _text;
    get text(): BedrockPromptVersionVariantsInferenceConfigurationTextOutputReference;
}
export interface BedrockPromptVersionVariantsMetadata {
}
export declare function bedrockPromptVersionVariantsMetadataToTerraform(struct?: BedrockPromptVersionVariantsMetadata): any;
export declare function bedrockPromptVersionVariantsMetadataToHclTerraform(struct?: BedrockPromptVersionVariantsMetadata): any;
export declare class BedrockPromptVersionVariantsMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVersionVariantsMetadata | undefined;
    set internalValue(value: BedrockPromptVersionVariantsMetadata | undefined);
    get key(): string;
    get value(): string;
}
export declare class BedrockPromptVersionVariantsMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVersionVariantsMetadataOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatInputVariables {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatInputVariablesToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatInputVariables): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatInputVariablesToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatInputVariables): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatInputVariables | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatInputVariables | undefined);
    get name(): string;
}
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatInputVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVersionVariantsTemplateConfigurationChatInputVariablesOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePoint {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePointToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePoint): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePointToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePoint): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePoint | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePoint | undefined);
    get type(): string;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContent {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContent): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContent): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContent | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContent | undefined);
    private _cachePoint;
    get cachePoint(): BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentCachePointOutputReference;
    get text(): string;
}
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatMessages {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatMessagesToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatMessages): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatMessagesToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatMessages): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatMessagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatMessages | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatMessages | undefined);
    private _content;
    get content(): BedrockPromptVersionVariantsTemplateConfigurationChatMessagesContentList;
    get role(): string;
}
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatMessagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVersionVariantsTemplateConfigurationChatMessagesOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePoint {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePointToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePoint): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePointToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePoint): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePoint | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePoint | undefined);
    get type(): string;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatSystem {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatSystemToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatSystem): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatSystemToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatSystem): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatSystemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatSystem | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatSystem | undefined);
    private _cachePoint;
    get cachePoint(): BedrockPromptVersionVariantsTemplateConfigurationChatSystemCachePointOutputReference;
    get text(): string;
}
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatSystemList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVersionVariantsTemplateConfigurationChatSystemOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceToolToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceToolToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceTool | undefined);
    get name(): string;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoice {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoice): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoice): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoice | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoice | undefined);
    get any(): string;
    get auto(): string;
    private _tool;
    get tool(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceToolOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePointToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePointToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePoint | undefined);
    get type(): string;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchemaToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchemaToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchema | undefined);
    get json(): string;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpec | undefined);
    get description(): string;
    private _inputSchema;
    get inputSchema(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecInputSchemaOutputReference;
    get name(): string;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationTools {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationTools): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationTools): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationTools | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationTools | undefined);
    private _cachePoint;
    get cachePoint(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsCachePointOutputReference;
    private _toolSpec;
    get toolSpec(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsToolSpecOutputReference;
}
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChatToolConfiguration {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfiguration): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfiguration): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfiguration | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChatToolConfiguration | undefined);
    private _toolChoice;
    get toolChoice(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolChoiceOutputReference;
    private _tools;
    get tools(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationToolsList;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationChat {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChat): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationChatToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationChat): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationChatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationChat | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationChat | undefined);
    private _inputVariables;
    get inputVariables(): BedrockPromptVersionVariantsTemplateConfigurationChatInputVariablesList;
    private _messages;
    get messages(): BedrockPromptVersionVariantsTemplateConfigurationChatMessagesList;
    private _system;
    get systemAttribute(): BedrockPromptVersionVariantsTemplateConfigurationChatSystemList;
    private _toolConfiguration;
    get toolConfiguration(): BedrockPromptVersionVariantsTemplateConfigurationChatToolConfigurationOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationTextCachePoint {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationTextCachePointToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationTextCachePoint): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationTextCachePointToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationTextCachePoint): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationTextCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationTextCachePoint | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationTextCachePoint | undefined);
    get type(): string;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationTextInputVariables {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationTextInputVariablesToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationTextInputVariables): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationTextInputVariablesToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationTextInputVariables): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationTextInputVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationTextInputVariables | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationTextInputVariables | undefined);
    get name(): string;
}
export declare class BedrockPromptVersionVariantsTemplateConfigurationTextInputVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVersionVariantsTemplateConfigurationTextInputVariablesOutputReference;
}
export interface BedrockPromptVersionVariantsTemplateConfigurationText {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationTextToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationText): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationTextToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfigurationText): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfigurationText | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfigurationText | undefined);
    private _cachePoint;
    get cachePoint(): BedrockPromptVersionVariantsTemplateConfigurationTextCachePointOutputReference;
    private _inputVariables;
    get inputVariables(): BedrockPromptVersionVariantsTemplateConfigurationTextInputVariablesList;
    get text(): string;
}
export interface BedrockPromptVersionVariantsTemplateConfiguration {
}
export declare function bedrockPromptVersionVariantsTemplateConfigurationToTerraform(struct?: BedrockPromptVersionVariantsTemplateConfiguration): any;
export declare function bedrockPromptVersionVariantsTemplateConfigurationToHclTerraform(struct?: BedrockPromptVersionVariantsTemplateConfiguration): any;
export declare class BedrockPromptVersionVariantsTemplateConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockPromptVersionVariantsTemplateConfiguration | undefined;
    set internalValue(value: BedrockPromptVersionVariantsTemplateConfiguration | undefined);
    private _chat;
    get chat(): BedrockPromptVersionVariantsTemplateConfigurationChatOutputReference;
    private _text;
    get text(): BedrockPromptVersionVariantsTemplateConfigurationTextOutputReference;
}
export interface BedrockPromptVersionVariants {
}
export declare function bedrockPromptVersionVariantsToTerraform(struct?: BedrockPromptVersionVariants): any;
export declare function bedrockPromptVersionVariantsToHclTerraform(struct?: BedrockPromptVersionVariants): any;
export declare class BedrockPromptVersionVariantsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockPromptVersionVariants | undefined;
    set internalValue(value: BedrockPromptVersionVariants | undefined);
    get additionalModelRequestFields(): string;
    private _genAiResource;
    get genAiResource(): BedrockPromptVersionVariantsGenAiResourceOutputReference;
    private _inferenceConfiguration;
    get inferenceConfiguration(): BedrockPromptVersionVariantsInferenceConfigurationOutputReference;
    private _metadata;
    get metadata(): BedrockPromptVersionVariantsMetadataList;
    get modelId(): string;
    get name(): string;
    private _templateConfiguration;
    get templateConfiguration(): BedrockPromptVersionVariantsTemplateConfigurationOutputReference;
    get templateType(): string;
}
export declare class BedrockPromptVersionVariantsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockPromptVersionVariantsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt_version awscc_bedrock_prompt_version}
*/
export declare class BedrockPromptVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_prompt_version";
    /**
    * Generates CDKTN code for importing a BedrockPromptVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockPromptVersion to import
    * @param importFromId The id of the existing BedrockPromptVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockPromptVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_prompt_version awscc_bedrock_prompt_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockPromptVersionConfig
    */
    constructor(scope: Construct, id: string, config: BedrockPromptVersionConfig);
    get arn(): string;
    get createdAt(): string;
    get customerEncryptionKeyArn(): string;
    get defaultVariant(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _promptArn?;
    get promptArn(): string;
    set promptArn(value: string);
    get promptArnInput(): string | undefined;
    get promptId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    private _variants;
    get variants(): BedrockPromptVersionVariantsList;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
