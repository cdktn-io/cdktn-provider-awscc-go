/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupBackupAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * For continuous (point-in-time) recovery points, the timestamp in ISO 8601 format (for example 2021-11-27T03:30:27Z) that determines the point-in-time view of the backup data. The timestamp must be within the continuous backup's retention period at the time the access point is created. Do not specify this for snapshot recovery points. The service reports it back under AccessPointMetadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point#access_point_in_time BackupBackupAccessPoint#access_point_in_time}
    */
    readonly accessPointInTime?: string;
    /**
    * An optional resource-based policy document, in JSON, to apply to the underlying Amazon S3 access point. The policy controls how backup data can be accessed through the access point. If you do not specify a policy, access is governed by the caller's IAM permissions. The serialized policy may not exceed 200000 characters. This value is not returned by the service and cannot be updated in place.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point#access_point_policy BackupBackupAccessPoint#access_point_policy}
    */
    readonly accessPointPolicy?: string;
    /**
    * The name of the backup access point. This name is shared with the Amazon S3 access point namespace. It must be unique within your account and Region and cannot conflict with an existing Amazon S3 access point. If omitted, a name is generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point#name BackupBackupAccessPoint#name}
    */
    readonly name?: string;
    /**
    * The Amazon Resource Name (ARN) of the recovery point for which to create the backup access point. The recovery point must be an Amazon S3 recovery point in the AVAILABLE, STOPPED, or COMPLETED state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point#recovery_point_arn BackupBackupAccessPoint#recovery_point_arn}
    */
    readonly recoveryPointArn: string;
    /**
    * The tags to assign to the backup access point.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point#tags BackupBackupAccessPoint#tags}
    */
    readonly tags?: BackupBackupAccessPointTags[] | cdktn.IResolvable;
}
export interface BackupBackupAccessPointAccessPointMetadata {
}
export declare function backupBackupAccessPointAccessPointMetadataToTerraform(struct?: BackupBackupAccessPointAccessPointMetadata): any;
export declare function backupBackupAccessPointAccessPointMetadataToHclTerraform(struct?: BackupBackupAccessPointAccessPointMetadata): any;
export declare class BackupBackupAccessPointAccessPointMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupBackupAccessPointAccessPointMetadata | undefined;
    set internalValue(value: BackupBackupAccessPointAccessPointMetadata | undefined);
    get accessPointInTime(): string;
    get s3AccessPointAlias(): string;
    get s3AccessPointArn(): string;
}
export interface BackupBackupAccessPointTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point#key BackupBackupAccessPoint#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point#value BackupBackupAccessPoint#value}
    */
    readonly value?: string;
}
export declare function backupBackupAccessPointTagsToTerraform(struct?: BackupBackupAccessPointTags | cdktn.IResolvable): any;
export declare function backupBackupAccessPointTagsToHclTerraform(struct?: BackupBackupAccessPointTags | cdktn.IResolvable): any;
export declare class BackupBackupAccessPointTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupAccessPointTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupAccessPointTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupBackupAccessPointTagsList extends cdktn.ComplexList {
    internalValue?: BackupBackupAccessPointTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupAccessPointTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point awscc_backup_backup_access_point}
*/
export declare class BackupBackupAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_backup_access_point";
    /**
    * Generates CDKTN code for importing a BackupBackupAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupBackupAccessPoint to import
    * @param importFromId The id of the existing BackupBackupAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupBackupAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_access_point awscc_backup_backup_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupBackupAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: BackupBackupAccessPointConfig);
    private _accessPointInTime?;
    get accessPointInTime(): string;
    set accessPointInTime(value: string);
    resetAccessPointInTime(): void;
    get accessPointInTimeInput(): string | undefined;
    private _accessPointMetadata;
    get accessPointMetadata(): BackupBackupAccessPointAccessPointMetadataOutputReference;
    private _accessPointPolicy?;
    get accessPointPolicy(): string;
    set accessPointPolicy(value: string);
    resetAccessPointPolicy(): void;
    get accessPointPolicyInput(): string | undefined;
    get arn(): string;
    get backupVaultArn(): string;
    get backupVaultName(): string;
    get creationTime(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _recoveryPointArn?;
    get recoveryPointArn(): string;
    set recoveryPointArn(value: string);
    get recoveryPointArnInput(): string | undefined;
    get resourceArn(): string;
    get resourceType(): string;
    get status(): string;
    private _tags;
    get tags(): BackupBackupAccessPointTagsList;
    putTags(value: BackupBackupAccessPointTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BackupBackupAccessPointTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
