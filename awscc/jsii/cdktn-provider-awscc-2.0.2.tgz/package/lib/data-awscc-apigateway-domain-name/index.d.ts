/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayDomainNameConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_domain_name#id DataAwsccApigatewayDomainName#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayDomainNameEndpointConfiguration {
}
export declare function dataAwsccApigatewayDomainNameEndpointConfigurationToTerraform(struct?: DataAwsccApigatewayDomainNameEndpointConfiguration): any;
export declare function dataAwsccApigatewayDomainNameEndpointConfigurationToHclTerraform(struct?: DataAwsccApigatewayDomainNameEndpointConfiguration): any;
export declare class DataAwsccApigatewayDomainNameEndpointConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayDomainNameEndpointConfiguration | undefined;
    set internalValue(value: DataAwsccApigatewayDomainNameEndpointConfiguration | undefined);
    get ipAddressType(): string;
    get types(): string[];
}
export interface DataAwsccApigatewayDomainNameMutualTlsAuthentication {
}
export declare function dataAwsccApigatewayDomainNameMutualTlsAuthenticationToTerraform(struct?: DataAwsccApigatewayDomainNameMutualTlsAuthentication): any;
export declare function dataAwsccApigatewayDomainNameMutualTlsAuthenticationToHclTerraform(struct?: DataAwsccApigatewayDomainNameMutualTlsAuthentication): any;
export declare class DataAwsccApigatewayDomainNameMutualTlsAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayDomainNameMutualTlsAuthentication | undefined;
    set internalValue(value: DataAwsccApigatewayDomainNameMutualTlsAuthentication | undefined);
    get truststoreUri(): string;
    get truststoreVersion(): string;
}
export interface DataAwsccApigatewayDomainNameTags {
}
export declare function dataAwsccApigatewayDomainNameTagsToTerraform(struct?: DataAwsccApigatewayDomainNameTags): any;
export declare function dataAwsccApigatewayDomainNameTagsToHclTerraform(struct?: DataAwsccApigatewayDomainNameTags): any;
export declare class DataAwsccApigatewayDomainNameTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayDomainNameTags | undefined;
    set internalValue(value: DataAwsccApigatewayDomainNameTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayDomainNameTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayDomainNameTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_domain_name awscc_apigateway_domain_name}
*/
export declare class DataAwsccApigatewayDomainName extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_domain_name";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayDomainName resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayDomainName to import
    * @param importFromId The id of the existing DataAwsccApigatewayDomainName that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_domain_name#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayDomainName to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/apigateway_domain_name awscc_apigateway_domain_name} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayDomainNameConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayDomainNameConfig);
    get certificateArn(): string;
    get distributionDomainName(): string;
    get distributionHostedZoneId(): string;
    get domainName(): string;
    get domainNameArn(): string;
    get endpointAccessMode(): string;
    private _endpointConfiguration;
    get endpointConfiguration(): DataAwsccApigatewayDomainNameEndpointConfigurationOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _mutualTlsAuthentication;
    get mutualTlsAuthentication(): DataAwsccApigatewayDomainNameMutualTlsAuthenticationOutputReference;
    get ownershipVerificationCertificateArn(): string;
    get regionalCertificateArn(): string;
    get regionalDomainName(): string;
    get regionalHostedZoneId(): string;
    get routingMode(): string;
    get securityPolicy(): string;
    private _tags;
    get tags(): DataAwsccApigatewayDomainNameTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
