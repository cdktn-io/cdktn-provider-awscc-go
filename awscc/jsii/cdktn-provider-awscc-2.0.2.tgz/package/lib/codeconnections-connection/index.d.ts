/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodeconnectionsConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the connection. Connection names must be unique in an AWS user account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection#connection_name CodeconnectionsConnection#connection_name}
    */
    readonly connectionName: string;
    /**
    * The host arn configured to represent the infrastructure where your third-party provider is installed. You must specify either a ProviderType or a HostArn.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection#host_arn CodeconnectionsConnection#host_arn}
    */
    readonly hostArn?: string;
    /**
    * The name of the external provider where your third-party code repository is configured. You must specify either a ProviderType or a HostArn.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection#provider_type CodeconnectionsConnection#provider_type}
    */
    readonly providerType?: string;
    /**
    * Specifies the tags applied to a connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection#tags CodeconnectionsConnection#tags}
    */
    readonly tags?: CodeconnectionsConnectionTags[] | cdktn.IResolvable;
}
export interface CodeconnectionsConnectionTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection#key CodeconnectionsConnection#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection#value CodeconnectionsConnection#value}
    */
    readonly value?: string;
}
export declare function codeconnectionsConnectionTagsToTerraform(struct?: CodeconnectionsConnectionTags | cdktn.IResolvable): any;
export declare function codeconnectionsConnectionTagsToHclTerraform(struct?: CodeconnectionsConnectionTags | cdktn.IResolvable): any;
export declare class CodeconnectionsConnectionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodeconnectionsConnectionTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodeconnectionsConnectionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodeconnectionsConnectionTagsList extends cdktn.ComplexList {
    internalValue?: CodeconnectionsConnectionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodeconnectionsConnectionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection awscc_codeconnections_connection}
*/
export declare class CodeconnectionsConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codeconnections_connection";
    /**
    * Generates CDKTN code for importing a CodeconnectionsConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodeconnectionsConnection to import
    * @param importFromId The id of the existing CodeconnectionsConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodeconnectionsConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/codeconnections_connection awscc_codeconnections_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodeconnectionsConnectionConfig
    */
    constructor(scope: Construct, id: string, config: CodeconnectionsConnectionConfig);
    get connectionArn(): string;
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    get connectionNameInput(): string | undefined;
    get connectionStatus(): string;
    private _hostArn?;
    get hostArn(): string;
    set hostArn(value: string);
    resetHostArn(): void;
    get hostArnInput(): string | undefined;
    get id(): string;
    get ownerAccountId(): string;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    resetProviderType(): void;
    get providerTypeInput(): string | undefined;
    private _tags;
    get tags(): CodeconnectionsConnectionTagsList;
    putTags(value: CodeconnectionsConnectionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodeconnectionsConnectionTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
