/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeSipMediaApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AWS Region in which the SIP media application is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application#aws_region ChimeSipMediaApplication#aws_region}
    */
    readonly awsRegion: string;
    /**
    * List of endpoints (Lambda ARNs) specified for the SIP media application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application#endpoints ChimeSipMediaApplication#endpoints}
    */
    readonly endpoints: ChimeSipMediaApplicationEndpoints[] | cdktn.IResolvable;
    /**
    * The name of the SIP media application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application#name ChimeSipMediaApplication#name}
    */
    readonly name: string;
    /**
    * Tags assigned to the SIP media application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application#tags ChimeSipMediaApplication#tags}
    */
    readonly tags?: ChimeSipMediaApplicationTags[] | cdktn.IResolvable;
}
export interface ChimeSipMediaApplicationEndpoints {
    /**
    * Valid Amazon Resource Name (ARN) of the Lambda function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application#lambda_arn ChimeSipMediaApplication#lambda_arn}
    */
    readonly lambdaArn: string;
}
export declare function chimeSipMediaApplicationEndpointsToTerraform(struct?: ChimeSipMediaApplicationEndpoints | cdktn.IResolvable): any;
export declare function chimeSipMediaApplicationEndpointsToHclTerraform(struct?: ChimeSipMediaApplicationEndpoints | cdktn.IResolvable): any;
export declare class ChimeSipMediaApplicationEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeSipMediaApplicationEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeSipMediaApplicationEndpoints | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    get lambdaArnInput(): string | undefined;
}
export declare class ChimeSipMediaApplicationEndpointsList extends cdktn.ComplexList {
    internalValue?: ChimeSipMediaApplicationEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeSipMediaApplicationEndpointsOutputReference;
}
export interface ChimeSipMediaApplicationTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application#key ChimeSipMediaApplication#key}
    */
    readonly key?: string;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application#value ChimeSipMediaApplication#value}
    */
    readonly value?: string;
}
export declare function chimeSipMediaApplicationTagsToTerraform(struct?: ChimeSipMediaApplicationTags | cdktn.IResolvable): any;
export declare function chimeSipMediaApplicationTagsToHclTerraform(struct?: ChimeSipMediaApplicationTags | cdktn.IResolvable): any;
export declare class ChimeSipMediaApplicationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeSipMediaApplicationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeSipMediaApplicationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeSipMediaApplicationTagsList extends cdktn.ComplexList {
    internalValue?: ChimeSipMediaApplicationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeSipMediaApplicationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application awscc_chime_sip_media_application}
*/
export declare class ChimeSipMediaApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_sip_media_application";
    /**
    * Generates CDKTN code for importing a ChimeSipMediaApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeSipMediaApplication to import
    * @param importFromId The id of the existing ChimeSipMediaApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeSipMediaApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/chime_sip_media_application awscc_chime_sip_media_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeSipMediaApplicationConfig
    */
    constructor(scope: Construct, id: string, config: ChimeSipMediaApplicationConfig);
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    get awsRegionInput(): string | undefined;
    get createdTimestamp(): string;
    private _endpoints;
    get endpoints(): ChimeSipMediaApplicationEndpointsList;
    putEndpoints(value: ChimeSipMediaApplicationEndpoints[] | cdktn.IResolvable): void;
    get endpointsInput(): cdktn.IResolvable | ChimeSipMediaApplicationEndpoints[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get sipMediaApplicationArn(): string;
    get sipMediaApplicationId(): string;
    private _tags;
    get tags(): ChimeSipMediaApplicationTagsList;
    putTags(value: ChimeSipMediaApplicationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeSipMediaApplicationTags[] | undefined;
    get updatedTimestamp(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
