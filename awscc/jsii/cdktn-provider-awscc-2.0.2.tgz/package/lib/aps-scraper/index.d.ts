/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApsScraperConfig extends cdktn.TerraformMetaArguments {
    /**
    * Scraper alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#alias ApsScraper#alias}
    */
    readonly alias?: string;
    /**
    * Scraper metrics destination
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#destination ApsScraper#destination}
    */
    readonly destination: ApsScraperDestination;
    /**
    * Role configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#role_configuration ApsScraper#role_configuration}
    */
    readonly roleConfiguration?: ApsScraperRoleConfiguration;
    /**
    * Scraper configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#scrape_configuration ApsScraper#scrape_configuration}
    */
    readonly scrapeConfiguration: ApsScraperScrapeConfiguration;
    /**
    * Configuration for scraper logging
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#scraper_logging_configuration ApsScraper#scraper_logging_configuration}
    */
    readonly scraperLoggingConfiguration?: ApsScraperScraperLoggingConfiguration;
    /**
    * Scraper metrics source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#source ApsScraper#source}
    */
    readonly source: ApsScraperSource;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#tags ApsScraper#tags}
    */
    readonly tags?: ApsScraperTags[] | cdktn.IResolvable;
}
export interface ApsScraperDestinationAmpConfiguration {
    /**
    * ARN of an Amazon Managed Prometheus workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#workspace_arn ApsScraper#workspace_arn}
    */
    readonly workspaceArn?: string;
}
export declare function apsScraperDestinationAmpConfigurationToTerraform(struct?: ApsScraperDestinationAmpConfiguration | cdktn.IResolvable): any;
export declare function apsScraperDestinationAmpConfigurationToHclTerraform(struct?: ApsScraperDestinationAmpConfiguration | cdktn.IResolvable): any;
export declare class ApsScraperDestinationAmpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperDestinationAmpConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperDestinationAmpConfiguration | cdktn.IResolvable | undefined);
    private _workspaceArn?;
    get workspaceArn(): string;
    set workspaceArn(value: string);
    resetWorkspaceArn(): void;
    get workspaceArnInput(): string | undefined;
}
export interface ApsScraperDestinationCloudwatchConfiguration {
    /**
    * ARN of a CloudWatch dataset
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#dataset_arn ApsScraper#dataset_arn}
    */
    readonly datasetArn?: string;
}
export declare function apsScraperDestinationCloudwatchConfigurationToTerraform(struct?: ApsScraperDestinationCloudwatchConfiguration | cdktn.IResolvable): any;
export declare function apsScraperDestinationCloudwatchConfigurationToHclTerraform(struct?: ApsScraperDestinationCloudwatchConfiguration | cdktn.IResolvable): any;
export declare class ApsScraperDestinationCloudwatchConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperDestinationCloudwatchConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperDestinationCloudwatchConfiguration | cdktn.IResolvable | undefined);
    private _datasetArn?;
    get datasetArn(): string;
    set datasetArn(value: string);
    resetDatasetArn(): void;
    get datasetArnInput(): string | undefined;
}
export interface ApsScraperDestination {
    /**
    * Configuration for Amazon Managed Prometheus metrics destination
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#amp_configuration ApsScraper#amp_configuration}
    */
    readonly ampConfiguration?: ApsScraperDestinationAmpConfiguration;
    /**
    * Configuration for CloudWatch metrics destination
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#cloudwatch_configuration ApsScraper#cloudwatch_configuration}
    */
    readonly cloudwatchConfiguration?: ApsScraperDestinationCloudwatchConfiguration;
}
export declare function apsScraperDestinationToTerraform(struct?: ApsScraperDestination | cdktn.IResolvable): any;
export declare function apsScraperDestinationToHclTerraform(struct?: ApsScraperDestination | cdktn.IResolvable): any;
export declare class ApsScraperDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperDestination | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperDestination | cdktn.IResolvable | undefined);
    private _ampConfiguration;
    get ampConfiguration(): ApsScraperDestinationAmpConfigurationOutputReference;
    putAmpConfiguration(value: ApsScraperDestinationAmpConfiguration): void;
    resetAmpConfiguration(): void;
    get ampConfigurationInput(): cdktn.IResolvable | ApsScraperDestinationAmpConfiguration | undefined;
    private _cloudwatchConfiguration;
    get cloudwatchConfiguration(): ApsScraperDestinationCloudwatchConfigurationOutputReference;
    putCloudwatchConfiguration(value: ApsScraperDestinationCloudwatchConfiguration): void;
    resetCloudwatchConfiguration(): void;
    get cloudwatchConfigurationInput(): cdktn.IResolvable | ApsScraperDestinationCloudwatchConfiguration | undefined;
}
export interface ApsScraperRoleConfiguration {
    /**
    * IAM Role in source account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#source_role_arn ApsScraper#source_role_arn}
    */
    readonly sourceRoleArn?: string;
    /**
    * IAM Role in the target account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#target_role_arn ApsScraper#target_role_arn}
    */
    readonly targetRoleArn?: string;
}
export declare function apsScraperRoleConfigurationToTerraform(struct?: ApsScraperRoleConfiguration | cdktn.IResolvable): any;
export declare function apsScraperRoleConfigurationToHclTerraform(struct?: ApsScraperRoleConfiguration | cdktn.IResolvable): any;
export declare class ApsScraperRoleConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperRoleConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperRoleConfiguration | cdktn.IResolvable | undefined);
    private _sourceRoleArn?;
    get sourceRoleArn(): string;
    set sourceRoleArn(value: string);
    resetSourceRoleArn(): void;
    get sourceRoleArnInput(): string | undefined;
    private _targetRoleArn?;
    get targetRoleArn(): string;
    set targetRoleArn(value: string);
    resetTargetRoleArn(): void;
    get targetRoleArnInput(): string | undefined;
}
export interface ApsScraperScrapeConfiguration {
    /**
    * Prometheus compatible scrape configuration in base64 encoded blob format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#configuration_blob ApsScraper#configuration_blob}
    */
    readonly configurationBlob?: string;
}
export declare function apsScraperScrapeConfigurationToTerraform(struct?: ApsScraperScrapeConfiguration | cdktn.IResolvable): any;
export declare function apsScraperScrapeConfigurationToHclTerraform(struct?: ApsScraperScrapeConfiguration | cdktn.IResolvable): any;
export declare class ApsScraperScrapeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperScrapeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperScrapeConfiguration | cdktn.IResolvable | undefined);
    private _configurationBlob?;
    get configurationBlob(): string;
    set configurationBlob(value: string);
    resetConfigurationBlob(): void;
    get configurationBlobInput(): string | undefined;
}
export interface ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogs {
    /**
    * ARN of the CloudWatch log group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#log_group_arn ApsScraper#log_group_arn}
    */
    readonly logGroupArn?: string;
}
export declare function apsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogsToTerraform(struct?: ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogs | cdktn.IResolvable): any;
export declare function apsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogsToHclTerraform(struct?: ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogs | cdktn.IResolvable): any;
export declare class ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogs | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogs | cdktn.IResolvable | undefined);
    private _logGroupArn?;
    get logGroupArn(): string;
    set logGroupArn(value: string);
    resetLogGroupArn(): void;
    get logGroupArnInput(): string | undefined;
}
export interface ApsScraperScraperLoggingConfigurationLoggingDestination {
    /**
    * Represents a cloudwatch logs destination for scraper logging
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#cloudwatch_logs ApsScraper#cloudwatch_logs}
    */
    readonly cloudwatchLogs?: ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogs;
}
export declare function apsScraperScraperLoggingConfigurationLoggingDestinationToTerraform(struct?: ApsScraperScraperLoggingConfigurationLoggingDestination | cdktn.IResolvable): any;
export declare function apsScraperScraperLoggingConfigurationLoggingDestinationToHclTerraform(struct?: ApsScraperScraperLoggingConfigurationLoggingDestination | cdktn.IResolvable): any;
export declare class ApsScraperScraperLoggingConfigurationLoggingDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperScraperLoggingConfigurationLoggingDestination | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperScraperLoggingConfigurationLoggingDestination | cdktn.IResolvable | undefined);
    private _cloudwatchLogs;
    get cloudwatchLogs(): ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogsOutputReference;
    putCloudwatchLogs(value: ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogs): void;
    resetCloudwatchLogs(): void;
    get cloudwatchLogsInput(): cdktn.IResolvable | ApsScraperScraperLoggingConfigurationLoggingDestinationCloudwatchLogs | undefined;
}
export interface ApsScraperScraperLoggingConfigurationScraperComponentsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#options ApsScraper#options}
    */
    readonly options?: {
        [key: string]: string;
    };
}
export declare function apsScraperScraperLoggingConfigurationScraperComponentsConfigToTerraform(struct?: ApsScraperScraperLoggingConfigurationScraperComponentsConfig | cdktn.IResolvable): any;
export declare function apsScraperScraperLoggingConfigurationScraperComponentsConfigToHclTerraform(struct?: ApsScraperScraperLoggingConfigurationScraperComponentsConfig | cdktn.IResolvable): any;
export declare class ApsScraperScraperLoggingConfigurationScraperComponentsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperScraperLoggingConfigurationScraperComponentsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperScraperLoggingConfigurationScraperComponentsConfig | cdktn.IResolvable | undefined);
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ApsScraperScraperLoggingConfigurationScraperComponents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#config ApsScraper#config}
    */
    readonly config?: ApsScraperScraperLoggingConfigurationScraperComponentsConfig;
    /**
    * Type of scraper component
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#type ApsScraper#type}
    */
    readonly type?: string;
}
export declare function apsScraperScraperLoggingConfigurationScraperComponentsToTerraform(struct?: ApsScraperScraperLoggingConfigurationScraperComponents | cdktn.IResolvable): any;
export declare function apsScraperScraperLoggingConfigurationScraperComponentsToHclTerraform(struct?: ApsScraperScraperLoggingConfigurationScraperComponents | cdktn.IResolvable): any;
export declare class ApsScraperScraperLoggingConfigurationScraperComponentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsScraperScraperLoggingConfigurationScraperComponents | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperScraperLoggingConfigurationScraperComponents | cdktn.IResolvable | undefined);
    private _config;
    get config(): ApsScraperScraperLoggingConfigurationScraperComponentsConfigOutputReference;
    putConfig(value: ApsScraperScraperLoggingConfigurationScraperComponentsConfig): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | ApsScraperScraperLoggingConfigurationScraperComponentsConfig | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ApsScraperScraperLoggingConfigurationScraperComponentsList extends cdktn.ComplexList {
    internalValue?: ApsScraperScraperLoggingConfigurationScraperComponents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsScraperScraperLoggingConfigurationScraperComponentsOutputReference;
}
export interface ApsScraperScraperLoggingConfiguration {
    /**
    * Destination for scraper logging
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#logging_destination ApsScraper#logging_destination}
    */
    readonly loggingDestination?: ApsScraperScraperLoggingConfigurationLoggingDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#scraper_components ApsScraper#scraper_components}
    */
    readonly scraperComponents?: ApsScraperScraperLoggingConfigurationScraperComponents[] | cdktn.IResolvable;
}
export declare function apsScraperScraperLoggingConfigurationToTerraform(struct?: ApsScraperScraperLoggingConfiguration | cdktn.IResolvable): any;
export declare function apsScraperScraperLoggingConfigurationToHclTerraform(struct?: ApsScraperScraperLoggingConfiguration | cdktn.IResolvable): any;
export declare class ApsScraperScraperLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperScraperLoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperScraperLoggingConfiguration | cdktn.IResolvable | undefined);
    private _loggingDestination;
    get loggingDestination(): ApsScraperScraperLoggingConfigurationLoggingDestinationOutputReference;
    putLoggingDestination(value: ApsScraperScraperLoggingConfigurationLoggingDestination): void;
    resetLoggingDestination(): void;
    get loggingDestinationInput(): cdktn.IResolvable | ApsScraperScraperLoggingConfigurationLoggingDestination | undefined;
    private _scraperComponents;
    get scraperComponents(): ApsScraperScraperLoggingConfigurationScraperComponentsList;
    putScraperComponents(value: ApsScraperScraperLoggingConfigurationScraperComponents[] | cdktn.IResolvable): void;
    resetScraperComponents(): void;
    get scraperComponentsInput(): cdktn.IResolvable | ApsScraperScraperLoggingConfigurationScraperComponents[] | undefined;
}
export interface ApsScraperSourceEksConfiguration {
    /**
    * ARN of an EKS cluster
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#cluster_arn ApsScraper#cluster_arn}
    */
    readonly clusterArn?: string;
    /**
    * List of security group IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#security_group_ids ApsScraper#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * List of subnet IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#subnet_ids ApsScraper#subnet_ids}
    */
    readonly subnetIds?: string[];
}
export declare function apsScraperSourceEksConfigurationToTerraform(struct?: ApsScraperSourceEksConfiguration | cdktn.IResolvable): any;
export declare function apsScraperSourceEksConfigurationToHclTerraform(struct?: ApsScraperSourceEksConfiguration | cdktn.IResolvable): any;
export declare class ApsScraperSourceEksConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperSourceEksConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperSourceEksConfiguration | cdktn.IResolvable | undefined);
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    resetClusterArn(): void;
    get clusterArnInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
}
export interface ApsScraperSourceVpcConfiguration {
    /**
    * List of security group IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#security_group_ids ApsScraper#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * List of subnet IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#subnet_ids ApsScraper#subnet_ids}
    */
    readonly subnetIds?: string[];
}
export declare function apsScraperSourceVpcConfigurationToTerraform(struct?: ApsScraperSourceVpcConfiguration | cdktn.IResolvable): any;
export declare function apsScraperSourceVpcConfigurationToHclTerraform(struct?: ApsScraperSourceVpcConfiguration | cdktn.IResolvable): any;
export declare class ApsScraperSourceVpcConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperSourceVpcConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperSourceVpcConfiguration | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
}
export interface ApsScraperSource {
    /**
    * Configuration for EKS metrics source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#eks_configuration ApsScraper#eks_configuration}
    */
    readonly eksConfiguration?: ApsScraperSourceEksConfiguration;
    /**
    * Configuration for VPC metrics source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#vpc_configuration ApsScraper#vpc_configuration}
    */
    readonly vpcConfiguration?: ApsScraperSourceVpcConfiguration;
}
export declare function apsScraperSourceToTerraform(struct?: ApsScraperSource | cdktn.IResolvable): any;
export declare function apsScraperSourceToHclTerraform(struct?: ApsScraperSource | cdktn.IResolvable): any;
export declare class ApsScraperSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsScraperSource | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperSource | cdktn.IResolvable | undefined);
    private _eksConfiguration;
    get eksConfiguration(): ApsScraperSourceEksConfigurationOutputReference;
    putEksConfiguration(value: ApsScraperSourceEksConfiguration): void;
    resetEksConfiguration(): void;
    get eksConfigurationInput(): cdktn.IResolvable | ApsScraperSourceEksConfiguration | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): ApsScraperSourceVpcConfigurationOutputReference;
    putVpcConfiguration(value: ApsScraperSourceVpcConfiguration): void;
    resetVpcConfiguration(): void;
    get vpcConfigurationInput(): cdktn.IResolvable | ApsScraperSourceVpcConfiguration | undefined;
}
export interface ApsScraperTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#key ApsScraper#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#value ApsScraper#value}
    */
    readonly value?: string;
}
export declare function apsScraperTagsToTerraform(struct?: ApsScraperTags | cdktn.IResolvable): any;
export declare function apsScraperTagsToHclTerraform(struct?: ApsScraperTags | cdktn.IResolvable): any;
export declare class ApsScraperTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsScraperTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApsScraperTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApsScraperTagsList extends cdktn.ComplexList {
    internalValue?: ApsScraperTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsScraperTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper awscc_aps_scraper}
*/
export declare class ApsScraper extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_aps_scraper";
    /**
    * Generates CDKTN code for importing a ApsScraper resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApsScraper to import
    * @param importFromId The id of the existing ApsScraper that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApsScraper to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_scraper awscc_aps_scraper} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApsScraperConfig
    */
    constructor(scope: Construct, id: string, config: ApsScraperConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    get arn(): string;
    private _destination;
    get destination(): ApsScraperDestinationOutputReference;
    putDestination(value: ApsScraperDestination): void;
    get destinationInput(): cdktn.IResolvable | ApsScraperDestination | undefined;
    get id(): string;
    get roleArn(): string;
    private _roleConfiguration;
    get roleConfiguration(): ApsScraperRoleConfigurationOutputReference;
    putRoleConfiguration(value: ApsScraperRoleConfiguration): void;
    resetRoleConfiguration(): void;
    get roleConfigurationInput(): cdktn.IResolvable | ApsScraperRoleConfiguration | undefined;
    private _scrapeConfiguration;
    get scrapeConfiguration(): ApsScraperScrapeConfigurationOutputReference;
    putScrapeConfiguration(value: ApsScraperScrapeConfiguration): void;
    get scrapeConfigurationInput(): cdktn.IResolvable | ApsScraperScrapeConfiguration | undefined;
    get scraperId(): string;
    private _scraperLoggingConfiguration;
    get scraperLoggingConfiguration(): ApsScraperScraperLoggingConfigurationOutputReference;
    putScraperLoggingConfiguration(value: ApsScraperScraperLoggingConfiguration): void;
    resetScraperLoggingConfiguration(): void;
    get scraperLoggingConfigurationInput(): cdktn.IResolvable | ApsScraperScraperLoggingConfiguration | undefined;
    private _source;
    get source(): ApsScraperSourceOutputReference;
    putSource(value: ApsScraperSource): void;
    get sourceInput(): cdktn.IResolvable | ApsScraperSource | undefined;
    private _tags;
    get tags(): ApsScraperTagsList;
    putTags(value: ApsScraperTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApsScraperTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
