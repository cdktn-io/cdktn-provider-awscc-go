/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectEmailAddressConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of alias configurations for the email address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#alias_configurations ConnectEmailAddress#alias_configurations}
    */
    readonly aliasConfigurations?: ConnectEmailAddressAliasConfigurations[] | cdktn.IResolvable;
    /**
    * A description for the email address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#description ConnectEmailAddress#description}
    */
    readonly description?: string;
    /**
    * The display name for the email address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#display_name ConnectEmailAddress#display_name}
    */
    readonly displayName?: string;
    /**
    * Email address to be created for this instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#email_address ConnectEmailAddress#email_address}
    */
    readonly emailAddress: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#instance_arn ConnectEmailAddress#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#tags ConnectEmailAddress#tags}
    */
    readonly tags?: ConnectEmailAddressTags[] | cdktn.IResolvable;
}
export interface ConnectEmailAddressAliasConfigurations {
    /**
    * The identifier of the email address alias
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#email_address_arn ConnectEmailAddress#email_address_arn}
    */
    readonly emailAddressArn?: string;
}
export declare function connectEmailAddressAliasConfigurationsToTerraform(struct?: ConnectEmailAddressAliasConfigurations | cdktn.IResolvable): any;
export declare function connectEmailAddressAliasConfigurationsToHclTerraform(struct?: ConnectEmailAddressAliasConfigurations | cdktn.IResolvable): any;
export declare class ConnectEmailAddressAliasConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectEmailAddressAliasConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectEmailAddressAliasConfigurations | cdktn.IResolvable | undefined);
    private _emailAddressArn?;
    get emailAddressArn(): string;
    set emailAddressArn(value: string);
    resetEmailAddressArn(): void;
    get emailAddressArnInput(): string | undefined;
}
export declare class ConnectEmailAddressAliasConfigurationsList extends cdktn.ComplexList {
    internalValue?: ConnectEmailAddressAliasConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectEmailAddressAliasConfigurationsOutputReference;
}
export interface ConnectEmailAddressTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#key ConnectEmailAddress#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#value ConnectEmailAddress#value}
    */
    readonly value?: string;
}
export declare function connectEmailAddressTagsToTerraform(struct?: ConnectEmailAddressTags | cdktn.IResolvable): any;
export declare function connectEmailAddressTagsToHclTerraform(struct?: ConnectEmailAddressTags | cdktn.IResolvable): any;
export declare class ConnectEmailAddressTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectEmailAddressTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectEmailAddressTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectEmailAddressTagsList extends cdktn.ComplexList {
    internalValue?: ConnectEmailAddressTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectEmailAddressTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address awscc_connect_email_address}
*/
export declare class ConnectEmailAddress extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_email_address";
    /**
    * Generates CDKTN code for importing a ConnectEmailAddress resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectEmailAddress to import
    * @param importFromId The id of the existing ConnectEmailAddress that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectEmailAddress to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/connect_email_address awscc_connect_email_address} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectEmailAddressConfig
    */
    constructor(scope: Construct, id: string, config: ConnectEmailAddressConfig);
    private _aliasConfigurations;
    get aliasConfigurations(): ConnectEmailAddressAliasConfigurationsList;
    putAliasConfigurations(value: ConnectEmailAddressAliasConfigurations[] | cdktn.IResolvable): void;
    resetAliasConfigurations(): void;
    get aliasConfigurationsInput(): cdktn.IResolvable | ConnectEmailAddressAliasConfigurations[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    get emailAddressInput(): string | undefined;
    get emailAddressArn(): string;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _tags;
    get tags(): ConnectEmailAddressTagsList;
    putTags(value: ConnectEmailAddressTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectEmailAddressTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
