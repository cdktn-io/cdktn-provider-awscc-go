/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontResponseHeadersPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * A response headers policy configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#response_headers_policy_config CloudfrontResponseHeadersPolicy#response_headers_policy_config}
    */
    readonly responseHeadersPolicyConfig: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfig;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeaders {
    /**
    * The list of HTTP header names. You can specify ``*`` to allow all headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#items CloudfrontResponseHeadersPolicy#items}
    */
    readonly items?: string[];
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeadersToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeaders | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeadersToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeaders | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeaders | cdktn.IResolvable | undefined);
    private _items?;
    get items(): string[];
    set items(value: string[]);
    resetItems(): void;
    get itemsInput(): string[] | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethods {
    /**
    * The list of HTTP methods. Valid values are:
    *   +   ``GET``
    *   +   ``DELETE``
    *   +   ``HEAD``
    *   +   ``OPTIONS``
    *   +   ``PATCH``
    *   +   ``POST``
    *   +   ``PUT``
    *   +   ``ALL``
    *
    *  ``ALL`` is a special value that includes all of the listed HTTP methods.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#items CloudfrontResponseHeadersPolicy#items}
    */
    readonly items?: string[];
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethodsToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethods | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethodsToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethods | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethods | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethods | cdktn.IResolvable | undefined);
    private _items?;
    get items(): string[];
    set items(value: string[]);
    resetItems(): void;
    get itemsInput(): string[] | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOrigins {
    /**
    * The list of origins (domain names). You can specify ``*`` to allow all origins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#items CloudfrontResponseHeadersPolicy#items}
    */
    readonly items?: string[];
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOriginsToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOrigins | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOriginsToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOrigins | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOrigins | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOrigins | cdktn.IResolvable | undefined);
    private _items?;
    get items(): string[];
    set items(value: string[]);
    resetItems(): void;
    get itemsInput(): string[] | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeaders {
    /**
    * The list of HTTP headers. You can specify ``*`` to expose all headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#items CloudfrontResponseHeadersPolicy#items}
    */
    readonly items?: string[];
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeadersToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeaders | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeadersToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeaders | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeaders | cdktn.IResolvable | undefined);
    private _items?;
    get items(): string[];
    set items(value: string[]);
    resetItems(): void;
    get itemsInput(): string[] | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfig {
    /**
    * A Boolean that CloudFront uses as the value for the ``Access-Control-Allow-Credentials`` HTTP response header.
    *  For more information about the ``Access-Control-Allow-Credentials`` HTTP response header, see [Access-Control-Allow-Credentials](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Credentials) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_credentials CloudfrontResponseHeadersPolicy#access_control_allow_credentials}
    */
    readonly accessControlAllowCredentials?: boolean | cdktn.IResolvable;
    /**
    * A list of HTTP header names that CloudFront includes as values for the ``Access-Control-Allow-Headers`` HTTP response header.
    *  For more information about the ``Access-Control-Allow-Headers`` HTTP response header, see [Access-Control-Allow-Headers](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Headers) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_headers CloudfrontResponseHeadersPolicy#access_control_allow_headers}
    */
    readonly accessControlAllowHeaders?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeaders;
    /**
    * A list of HTTP methods that CloudFront includes as values for the ``Access-Control-Allow-Methods`` HTTP response header.
    *  For more information about the ``Access-Control-Allow-Methods`` HTTP response header, see [Access-Control-Allow-Methods](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Methods) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_methods CloudfrontResponseHeadersPolicy#access_control_allow_methods}
    */
    readonly accessControlAllowMethods?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethods;
    /**
    * A list of origins (domain names) that CloudFront can use as the value for the ``Access-Control-Allow-Origin`` HTTP response header.
    *  For more information about the ``Access-Control-Allow-Origin`` HTTP response header, see [Access-Control-Allow-Origin](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Origin) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_origins CloudfrontResponseHeadersPolicy#access_control_allow_origins}
    */
    readonly accessControlAllowOrigins?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOrigins;
    /**
    * A list of HTTP headers that CloudFront includes as values for the ``Access-Control-Expose-Headers`` HTTP response header.
    *  For more information about the ``Access-Control-Expose-Headers`` HTTP response header, see [Access-Control-Expose-Headers](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Expose-Headers) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#access_control_expose_headers CloudfrontResponseHeadersPolicy#access_control_expose_headers}
    */
    readonly accessControlExposeHeaders?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeaders;
    /**
    * A number that CloudFront uses as the value for the ``Access-Control-Max-Age`` HTTP response header.
    *  For more information about the ``Access-Control-Max-Age`` HTTP response header, see [Access-Control-Max-Age](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Max-Age) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#access_control_max_age_sec CloudfrontResponseHeadersPolicy#access_control_max_age_sec}
    */
    readonly accessControlMaxAgeSec?: number;
    /**
    * A Boolean that determines whether CloudFront overrides HTTP response headers received from the origin with the ones specified in this response headers policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#origin_override CloudfrontResponseHeadersPolicy#origin_override}
    */
    readonly originOverride?: boolean | cdktn.IResolvable;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfig | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfig | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfig | cdktn.IResolvable | undefined);
    private _accessControlAllowCredentials?;
    get accessControlAllowCredentials(): boolean | cdktn.IResolvable;
    set accessControlAllowCredentials(value: boolean | cdktn.IResolvable);
    resetAccessControlAllowCredentials(): void;
    get accessControlAllowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _accessControlAllowHeaders;
    get accessControlAllowHeaders(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeadersOutputReference;
    putAccessControlAllowHeaders(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeaders): void;
    resetAccessControlAllowHeaders(): void;
    get accessControlAllowHeadersInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowHeaders | undefined;
    private _accessControlAllowMethods;
    get accessControlAllowMethods(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethodsOutputReference;
    putAccessControlAllowMethods(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethods): void;
    resetAccessControlAllowMethods(): void;
    get accessControlAllowMethodsInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowMethods | undefined;
    private _accessControlAllowOrigins;
    get accessControlAllowOrigins(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOriginsOutputReference;
    putAccessControlAllowOrigins(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOrigins): void;
    resetAccessControlAllowOrigins(): void;
    get accessControlAllowOriginsInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlAllowOrigins | undefined;
    private _accessControlExposeHeaders;
    get accessControlExposeHeaders(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeadersOutputReference;
    putAccessControlExposeHeaders(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeaders): void;
    resetAccessControlExposeHeaders(): void;
    get accessControlExposeHeadersInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigAccessControlExposeHeaders | undefined;
    private _accessControlMaxAgeSec?;
    get accessControlMaxAgeSec(): number;
    set accessControlMaxAgeSec(value: number);
    resetAccessControlMaxAgeSec(): void;
    get accessControlMaxAgeSecInput(): number | undefined;
    private _originOverride?;
    get originOverride(): boolean | cdktn.IResolvable;
    set originOverride(value: boolean | cdktn.IResolvable);
    resetOriginOverride(): void;
    get originOverrideInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems {
    /**
    * The HTTP response header name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#header CloudfrontResponseHeadersPolicy#header}
    */
    readonly header?: string;
    /**
    * A Boolean that determines whether CloudFront overrides a response header with the same name received from the origin with the header specified here.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#override CloudfrontResponseHeadersPolicy#override}
    */
    readonly override?: boolean | cdktn.IResolvable;
    /**
    * The value for the HTTP response header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#value CloudfrontResponseHeadersPolicy#value}
    */
    readonly value?: string;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItemsToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItemsToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    resetHeader(): void;
    get headerInput(): string | undefined;
    private _override?;
    get override(): boolean | cdktn.IResolvable;
    set override(value: boolean | cdktn.IResolvable);
    resetOverride(): void;
    get overrideInput(): boolean | cdktn.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItemsList extends cdktn.ComplexList {
    internalValue?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItemsOutputReference;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfig {
    /**
    * The list of HTTP response headers and their values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#items CloudfrontResponseHeadersPolicy#items}
    */
    readonly items?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems[] | cdktn.IResolvable;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfig | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfig | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfig | cdktn.IResolvable | undefined);
    private _items;
    get items(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItemsList;
    putItems(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigItems[] | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems {
    /**
    * The HTTP header name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#header CloudfrontResponseHeadersPolicy#header}
    */
    readonly header?: string;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItemsToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItemsToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    resetHeader(): void;
    get headerInput(): string | undefined;
}
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItemsList extends cdktn.ComplexList {
    internalValue?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItemsOutputReference;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfig {
    /**
    * The list of HTTP header names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#items CloudfrontResponseHeadersPolicy#items}
    */
    readonly items?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems[] | cdktn.IResolvable;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfig | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfig | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfig | cdktn.IResolvable | undefined);
    private _items;
    get items(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItemsList;
    putItems(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigItems[] | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicy {
    /**
    * The policy directives and their values that CloudFront includes as values for the ``Content-Security-Policy`` HTTP response header.
    *  For more information about the ``Content-Security-Policy`` HTTP response header, see [Content-Security-Policy](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#content_security_policy CloudfrontResponseHeadersPolicy#content_security_policy}
    */
    readonly contentSecurityPolicy?: string;
    /**
    * A Boolean that determines whether CloudFront overrides the ``Content-Security-Policy`` HTTP response header received from the origin with the one specified in this response headers policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#override CloudfrontResponseHeadersPolicy#override}
    */
    readonly override?: boolean | cdktn.IResolvable;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicyToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicy | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicyToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicy | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicy | cdktn.IResolvable | undefined);
    private _contentSecurityPolicy?;
    get contentSecurityPolicy(): string;
    set contentSecurityPolicy(value: string);
    resetContentSecurityPolicy(): void;
    get contentSecurityPolicyInput(): string | undefined;
    private _override?;
    get override(): boolean | cdktn.IResolvable;
    set override(value: boolean | cdktn.IResolvable);
    resetOverride(): void;
    get overrideInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptions {
    /**
    * A Boolean that determines whether CloudFront overrides the ``X-Content-Type-Options`` HTTP response header received from the origin with the one specified in this response headers policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#override CloudfrontResponseHeadersPolicy#override}
    */
    readonly override?: boolean | cdktn.IResolvable;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptionsToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptions | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptionsToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptions | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptions | cdktn.IResolvable | undefined);
    private _override?;
    get override(): boolean | cdktn.IResolvable;
    set override(value: boolean | cdktn.IResolvable);
    resetOverride(): void;
    get overrideInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptions {
    /**
    * The value of the ``X-Frame-Options`` HTTP response header. Valid values are ``DENY`` and ``SAMEORIGIN``.
    *  For more information about these values, see [X-Frame-Options](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Frame-Options) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#frame_option CloudfrontResponseHeadersPolicy#frame_option}
    */
    readonly frameOption?: string;
    /**
    * A Boolean that determines whether CloudFront overrides the ``X-Frame-Options`` HTTP response header received from the origin with the one specified in this response headers policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#override CloudfrontResponseHeadersPolicy#override}
    */
    readonly override?: boolean | cdktn.IResolvable;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptionsToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptions | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptionsToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptions | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptions | cdktn.IResolvable | undefined);
    private _frameOption?;
    get frameOption(): string;
    set frameOption(value: string);
    resetFrameOption(): void;
    get frameOptionInput(): string | undefined;
    private _override?;
    get override(): boolean | cdktn.IResolvable;
    set override(value: boolean | cdktn.IResolvable);
    resetOverride(): void;
    get overrideInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicy {
    /**
    * A Boolean that determines whether CloudFront overrides the ``Referrer-Policy`` HTTP response header received from the origin with the one specified in this response headers policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#override CloudfrontResponseHeadersPolicy#override}
    */
    readonly override?: boolean | cdktn.IResolvable;
    /**
    * Determines whether CloudFront includes the ``Referrer-Policy`` HTTP response header and the header's value.
    *  For more information about the ``Referrer-Policy`` HTTP response header, see [Referrer-Policy](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referrer-Policy) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#referrer_policy CloudfrontResponseHeadersPolicy#referrer_policy}
    */
    readonly referrerPolicy?: string;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicyToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicy | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicyToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicy | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicy | cdktn.IResolvable | undefined);
    private _override?;
    get override(): boolean | cdktn.IResolvable;
    set override(value: boolean | cdktn.IResolvable);
    resetOverride(): void;
    get overrideInput(): boolean | cdktn.IResolvable | undefined;
    private _referrerPolicy?;
    get referrerPolicy(): string;
    set referrerPolicy(value: string);
    resetReferrerPolicy(): void;
    get referrerPolicyInput(): string | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurity {
    /**
    * A number that CloudFront uses as the value for the ``max-age`` directive in the ``Strict-Transport-Security`` HTTP response header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#access_control_max_age_sec CloudfrontResponseHeadersPolicy#access_control_max_age_sec}
    */
    readonly accessControlMaxAgeSec?: number;
    /**
    * A Boolean that determines whether CloudFront includes the ``includeSubDomains`` directive in the ``Strict-Transport-Security`` HTTP response header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#include_subdomains CloudfrontResponseHeadersPolicy#include_subdomains}
    */
    readonly includeSubdomains?: boolean | cdktn.IResolvable;
    /**
    * A Boolean that determines whether CloudFront overrides the ``Strict-Transport-Security`` HTTP response header received from the origin with the one specified in this response headers policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#override CloudfrontResponseHeadersPolicy#override}
    */
    readonly override?: boolean | cdktn.IResolvable;
    /**
    * A Boolean that determines whether CloudFront includes the ``preload`` directive in the ``Strict-Transport-Security`` HTTP response header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#preload CloudfrontResponseHeadersPolicy#preload}
    */
    readonly preload?: boolean | cdktn.IResolvable;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurityToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurity | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurityToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurity | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurity | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurity | cdktn.IResolvable | undefined);
    private _accessControlMaxAgeSec?;
    get accessControlMaxAgeSec(): number;
    set accessControlMaxAgeSec(value: number);
    resetAccessControlMaxAgeSec(): void;
    get accessControlMaxAgeSecInput(): number | undefined;
    private _includeSubdomains?;
    get includeSubdomains(): boolean | cdktn.IResolvable;
    set includeSubdomains(value: boolean | cdktn.IResolvable);
    resetIncludeSubdomains(): void;
    get includeSubdomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _override?;
    get override(): boolean | cdktn.IResolvable;
    set override(value: boolean | cdktn.IResolvable);
    resetOverride(): void;
    get overrideInput(): boolean | cdktn.IResolvable | undefined;
    private _preload?;
    get preload(): boolean | cdktn.IResolvable;
    set preload(value: boolean | cdktn.IResolvable);
    resetPreload(): void;
    get preloadInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtection {
    /**
    * A Boolean that determines whether CloudFront includes the ``mode=block`` directive in the ``X-XSS-Protection`` header.
    *  For more information about this directive, see [X-XSS-Protection](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-XSS-Protection) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#mode_block CloudfrontResponseHeadersPolicy#mode_block}
    */
    readonly modeBlock?: boolean | cdktn.IResolvable;
    /**
    * A Boolean that determines whether CloudFront overrides the ``X-XSS-Protection`` HTTP response header received from the origin with the one specified in this response headers policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#override CloudfrontResponseHeadersPolicy#override}
    */
    readonly override?: boolean | cdktn.IResolvable;
    /**
    * A Boolean that determines the value of the ``X-XSS-Protection`` HTTP response header. When this setting is ``true``, the value of the ``X-XSS-Protection`` header is ``1``. When this setting is ``false``, the value of the ``X-XSS-Protection`` header is ``0``.
    *  For more information about these settings, see [X-XSS-Protection](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-XSS-Protection) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#protection CloudfrontResponseHeadersPolicy#protection}
    */
    readonly protection?: boolean | cdktn.IResolvable;
    /**
    * A reporting URI, which CloudFront uses as the value of the ``report`` directive in the ``X-XSS-Protection`` header.
    *  You cannot specify a ``ReportUri`` when ``ModeBlock`` is ``true``.
    *  For more information about using a reporting URL, see [X-XSS-Protection](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-XSS-Protection) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#report_uri CloudfrontResponseHeadersPolicy#report_uri}
    */
    readonly reportUri?: string;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtectionToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtection | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtectionToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtection | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtection | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtection | cdktn.IResolvable | undefined);
    private _modeBlock?;
    get modeBlock(): boolean | cdktn.IResolvable;
    set modeBlock(value: boolean | cdktn.IResolvable);
    resetModeBlock(): void;
    get modeBlockInput(): boolean | cdktn.IResolvable | undefined;
    private _override?;
    get override(): boolean | cdktn.IResolvable;
    set override(value: boolean | cdktn.IResolvable);
    resetOverride(): void;
    get overrideInput(): boolean | cdktn.IResolvable | undefined;
    private _protection?;
    get protection(): boolean | cdktn.IResolvable;
    set protection(value: boolean | cdktn.IResolvable);
    resetProtection(): void;
    get protectionInput(): boolean | cdktn.IResolvable | undefined;
    private _reportUri?;
    get reportUri(): string;
    set reportUri(value: string);
    resetReportUri(): void;
    get reportUriInput(): string | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfig {
    /**
    * The policy directives and their values that CloudFront includes as values for the ``Content-Security-Policy`` HTTP response header.
    *  For more information about the ``Content-Security-Policy`` HTTP response header, see [Content-Security-Policy](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#content_security_policy CloudfrontResponseHeadersPolicy#content_security_policy}
    */
    readonly contentSecurityPolicy?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicy;
    /**
    * Determines whether CloudFront includes the ``X-Content-Type-Options`` HTTP response header with its value set to ``nosniff``.
    *  For more information about the ``X-Content-Type-Options`` HTTP response header, see [X-Content-Type-Options](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Content-Type-Options) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#content_type_options CloudfrontResponseHeadersPolicy#content_type_options}
    */
    readonly contentTypeOptions?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptions;
    /**
    * Determines whether CloudFront includes the ``X-Frame-Options`` HTTP response header and the header's value.
    *  For more information about the ``X-Frame-Options`` HTTP response header, see [X-Frame-Options](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Frame-Options) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#frame_options CloudfrontResponseHeadersPolicy#frame_options}
    */
    readonly frameOptions?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptions;
    /**
    * Determines whether CloudFront includes the ``Referrer-Policy`` HTTP response header and the header's value.
    *  For more information about the ``Referrer-Policy`` HTTP response header, see [Referrer-Policy](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referrer-Policy) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#referrer_policy CloudfrontResponseHeadersPolicy#referrer_policy}
    */
    readonly referrerPolicy?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicy;
    /**
    * Determines whether CloudFront includes the ``Strict-Transport-Security`` HTTP response header and the header's value.
    *  For more information about the ``Strict-Transport-Security`` HTTP response header, see [Security headers](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/understanding-response-headers-policies.html#understanding-response-headers-policies-security) in the *Amazon CloudFront Developer Guide* and [Strict-Transport-Security](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Strict-Transport-Security) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#strict_transport_security CloudfrontResponseHeadersPolicy#strict_transport_security}
    */
    readonly strictTransportSecurity?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurity;
    /**
    * Determines whether CloudFront includes the ``X-XSS-Protection`` HTTP response header and the header's value.
    *  For more information about the ``X-XSS-Protection`` HTTP response header, see [X-XSS-Protection](https://docs.aws.amazon.com/https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-XSS-Protection) in the MDN Web Docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#xss_protection CloudfrontResponseHeadersPolicy#xss_protection}
    */
    readonly xssProtection?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtection;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfig | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfig | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfig | cdktn.IResolvable | undefined);
    private _contentSecurityPolicy;
    get contentSecurityPolicy(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicyOutputReference;
    putContentSecurityPolicy(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicy): void;
    resetContentSecurityPolicy(): void;
    get contentSecurityPolicyInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentSecurityPolicy | undefined;
    private _contentTypeOptions;
    get contentTypeOptions(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptionsOutputReference;
    putContentTypeOptions(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptions): void;
    resetContentTypeOptions(): void;
    get contentTypeOptionsInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigContentTypeOptions | undefined;
    private _frameOptions;
    get frameOptions(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptionsOutputReference;
    putFrameOptions(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptions): void;
    resetFrameOptions(): void;
    get frameOptionsInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigFrameOptions | undefined;
    private _referrerPolicy;
    get referrerPolicy(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicyOutputReference;
    putReferrerPolicy(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicy): void;
    resetReferrerPolicy(): void;
    get referrerPolicyInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigReferrerPolicy | undefined;
    private _strictTransportSecurity;
    get strictTransportSecurity(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurityOutputReference;
    putStrictTransportSecurity(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurity): void;
    resetStrictTransportSecurity(): void;
    get strictTransportSecurityInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigStrictTransportSecurity | undefined;
    private _xssProtection;
    get xssProtection(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtectionOutputReference;
    putXssProtection(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtection): void;
    resetXssProtection(): void;
    get xssProtectionInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigXssProtection | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfig {
    /**
    * A Boolean that determines whether CloudFront adds the ``Server-Timing`` header to HTTP responses that it sends in response to requests that match a cache behavior that's associated with this response headers policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#enabled CloudfrontResponseHeadersPolicy#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * A number 0?100 (inclusive) that specifies the percentage of responses that you want CloudFront to add the ``Server-Timing`` header to. When you set the sampling rate to 100, CloudFront adds the ``Server-Timing`` header to the HTTP response for every request that matches the cache behavior that this response headers policy is attached to. When you set it to 50, CloudFront adds the header to 50% of the responses for requests that match the cache behavior. You can set the sampling rate to any number 0?100 with up to four decimal places.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#sampling_rate CloudfrontResponseHeadersPolicy#sampling_rate}
    */
    readonly samplingRate?: number;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfigToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfig | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfigToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfig | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfig | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _samplingRate?;
    get samplingRate(): number;
    set samplingRate(value: number);
    resetSamplingRate(): void;
    get samplingRateInput(): number | undefined;
}
export interface CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfig {
    /**
    * A comment to describe the response headers policy.
    *  The comment cannot be longer than 128 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#comment CloudfrontResponseHeadersPolicy#comment}
    */
    readonly comment?: string;
    /**
    * A configuration for a set of HTTP response headers that are used for cross-origin resource sharing (CORS).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#cors_config CloudfrontResponseHeadersPolicy#cors_config}
    */
    readonly corsConfig?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfig;
    /**
    * A configuration for a set of custom HTTP response headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#custom_headers_config CloudfrontResponseHeadersPolicy#custom_headers_config}
    */
    readonly customHeadersConfig?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfig;
    /**
    * A name to identify the response headers policy.
    *  The name must be unique for response headers policies in this AWS-account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#name CloudfrontResponseHeadersPolicy#name}
    */
    readonly name: string;
    /**
    * A configuration for a set of HTTP headers to remove from the HTTP response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#remove_headers_config CloudfrontResponseHeadersPolicy#remove_headers_config}
    */
    readonly removeHeadersConfig?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfig;
    /**
    * A configuration for a set of security-related HTTP response headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#security_headers_config CloudfrontResponseHeadersPolicy#security_headers_config}
    */
    readonly securityHeadersConfig?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfig;
    /**
    * A configuration for enabling the ``Server-Timing`` header in HTTP responses sent from CloudFront.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#server_timing_headers_config CloudfrontResponseHeadersPolicy#server_timing_headers_config}
    */
    readonly serverTimingHeadersConfig?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfig;
}
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigToTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfig | cdktn.IResolvable): any;
export declare function cloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigToHclTerraform(struct?: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfig | cdktn.IResolvable): any;
export declare class CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfig | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _corsConfig;
    get corsConfig(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfigOutputReference;
    putCorsConfig(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfig): void;
    resetCorsConfig(): void;
    get corsConfigInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCorsConfig | undefined;
    private _customHeadersConfig;
    get customHeadersConfig(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfigOutputReference;
    putCustomHeadersConfig(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfig): void;
    resetCustomHeadersConfig(): void;
    get customHeadersConfigInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigCustomHeadersConfig | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _removeHeadersConfig;
    get removeHeadersConfig(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfigOutputReference;
    putRemoveHeadersConfig(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfig): void;
    resetRemoveHeadersConfig(): void;
    get removeHeadersConfigInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigRemoveHeadersConfig | undefined;
    private _securityHeadersConfig;
    get securityHeadersConfig(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfigOutputReference;
    putSecurityHeadersConfig(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfig): void;
    resetSecurityHeadersConfig(): void;
    get securityHeadersConfigInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigSecurityHeadersConfig | undefined;
    private _serverTimingHeadersConfig;
    get serverTimingHeadersConfig(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfigOutputReference;
    putServerTimingHeadersConfig(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfig): void;
    resetServerTimingHeadersConfig(): void;
    get serverTimingHeadersConfigInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigServerTimingHeadersConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy awscc_cloudfront_response_headers_policy}
*/
export declare class CloudfrontResponseHeadersPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_response_headers_policy";
    /**
    * Generates CDKTN code for importing a CloudfrontResponseHeadersPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontResponseHeadersPolicy to import
    * @param importFromId The id of the existing CloudfrontResponseHeadersPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontResponseHeadersPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudfront_response_headers_policy awscc_cloudfront_response_headers_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontResponseHeadersPolicyConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontResponseHeadersPolicyConfig);
    get id(): string;
    get lastModifiedTime(): string;
    private _responseHeadersPolicyConfig;
    get responseHeadersPolicyConfig(): CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfigOutputReference;
    putResponseHeadersPolicyConfig(value: CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfig): void;
    get responseHeadersPolicyConfigInput(): cdktn.IResolvable | CloudfrontResponseHeadersPolicyResponseHeadersPolicyConfig | undefined;
    get responseHeadersPolicyId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
