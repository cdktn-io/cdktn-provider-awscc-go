/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAcmpcaCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/acmpca_certificate#id DataAwsccAcmpcaCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifierToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifierToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifier | undefined);
    get cpsUri(): string;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiers | undefined);
    get policyQualifierId(): string;
    private _qualifier;
    get qualifier(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersQualifierOutputReference;
}
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersOutputReference;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePolicies {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePolicies): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePolicies): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePolicies | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePolicies | undefined);
    get certPolicyId(): string;
    private _policyQualifiers;
    get policyQualifiers(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesPolicyQualifiersList;
}
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesOutputReference;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensions {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensionsToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensions): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensionsToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensions): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensions | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensions | undefined);
    get critical(): cdktn.IResolvable;
    get objectIdentifier(): string;
    get value(): string;
}
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensionsOutputReference;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsage | undefined);
    get extendedKeyUsageObjectIdentifier(): string;
    get extendedKeyUsageType(): string;
}
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageOutputReference;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsage {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsageToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsage): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsageToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsage): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsage | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsage | undefined);
    get crlSign(): cdktn.IResolvable;
    get dataEncipherment(): cdktn.IResolvable;
    get decipherOnly(): cdktn.IResolvable;
    get digitalSignature(): cdktn.IResolvable;
    get encipherOnly(): cdktn.IResolvable;
    get keyAgreement(): cdktn.IResolvable;
    get keyCertSign(): cdktn.IResolvable;
    get keyEncipherment(): cdktn.IResolvable;
    get nonRepudiation(): cdktn.IResolvable;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributes | undefined);
    get objectIdentifier(): string;
    get value(): string;
}
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesOutputReference;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryName | undefined);
    get commonName(): string;
    get country(): string;
    private _customAttributes;
    get customAttributes(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameCustomAttributesList;
    get distinguishedNameQualifier(): string;
    get generationQualifier(): string;
    get givenName(): string;
    get initials(): string;
    get locality(): string;
    get organization(): string;
    get organizationalUnit(): string;
    get pseudonym(): string;
    get serialNumber(): string;
    get state(): string;
    get surname(): string;
    get title(): string;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyNameToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyNameToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyName | undefined);
    get nameAssigner(): string;
    get partyName(): string;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherNameToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherNameToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherName | undefined);
    get typeId(): string;
    get value(): string;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNames | undefined);
    private _directoryName;
    get directoryName(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesDirectoryNameOutputReference;
    get dnsName(): string;
    private _ediPartyName;
    get ediPartyName(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesEdiPartyNameOutputReference;
    get ipAddress(): string;
    private _otherName;
    get otherName(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOtherNameOutputReference;
    get registeredId(): string;
    get rfc822Name(): string;
    get uniformResourceIdentifier(): string;
}
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesOutputReference;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughExtensions {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensions): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughExtensionsToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughExtensions): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughExtensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughExtensions | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughExtensions | undefined);
    private _certificatePolicies;
    get certificatePolicies(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCertificatePoliciesList;
    private _customExtensions;
    get customExtensions(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsCustomExtensionsList;
    private _extendedKeyUsage;
    get extendedKeyUsage(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsExtendedKeyUsageList;
    private _keyUsage;
    get keyUsage(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsKeyUsageOutputReference;
    private _subjectAlternativeNames;
    get subjectAlternativeNames(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsSubjectAlternativeNamesList;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributes {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributesToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributes): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributesToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributes): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributes | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributes | undefined);
    get objectIdentifier(): string;
    get value(): string;
}
export declare class DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributesOutputReference;
}
export interface DataAwsccAcmpcaCertificateApiPassthroughSubject {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughSubjectToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughSubject): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughSubjectToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthroughSubject): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughSubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthroughSubject | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthroughSubject | undefined);
    get commonName(): string;
    get country(): string;
    private _customAttributes;
    get customAttributes(): DataAwsccAcmpcaCertificateApiPassthroughSubjectCustomAttributesList;
    get distinguishedNameQualifier(): string;
    get generationQualifier(): string;
    get givenName(): string;
    get initials(): string;
    get locality(): string;
    get organization(): string;
    get organizationalUnit(): string;
    get pseudonym(): string;
    get serialNumber(): string;
    get state(): string;
    get surname(): string;
    get title(): string;
}
export interface DataAwsccAcmpcaCertificateApiPassthrough {
}
export declare function dataAwsccAcmpcaCertificateApiPassthroughToTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthrough): any;
export declare function dataAwsccAcmpcaCertificateApiPassthroughToHclTerraform(struct?: DataAwsccAcmpcaCertificateApiPassthrough): any;
export declare class DataAwsccAcmpcaCertificateApiPassthroughOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateApiPassthrough | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateApiPassthrough | undefined);
    private _extensions;
    get extensions(): DataAwsccAcmpcaCertificateApiPassthroughExtensionsOutputReference;
    private _subject;
    get subject(): DataAwsccAcmpcaCertificateApiPassthroughSubjectOutputReference;
}
export interface DataAwsccAcmpcaCertificateValidity {
}
export declare function dataAwsccAcmpcaCertificateValidityToTerraform(struct?: DataAwsccAcmpcaCertificateValidity): any;
export declare function dataAwsccAcmpcaCertificateValidityToHclTerraform(struct?: DataAwsccAcmpcaCertificateValidity): any;
export declare class DataAwsccAcmpcaCertificateValidityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateValidity | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateValidity | undefined);
    get type(): string;
    get value(): number;
}
export interface DataAwsccAcmpcaCertificateValidityNotBefore {
}
export declare function dataAwsccAcmpcaCertificateValidityNotBeforeToTerraform(struct?: DataAwsccAcmpcaCertificateValidityNotBefore): any;
export declare function dataAwsccAcmpcaCertificateValidityNotBeforeToHclTerraform(struct?: DataAwsccAcmpcaCertificateValidityNotBefore): any;
export declare class DataAwsccAcmpcaCertificateValidityNotBeforeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateValidityNotBefore | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateValidityNotBefore | undefined);
    get type(): string;
    get value(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/acmpca_certificate awscc_acmpca_certificate}
*/
export declare class DataAwsccAcmpcaCertificate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_acmpca_certificate";
    /**
    * Generates CDKTN code for importing a DataAwsccAcmpcaCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAcmpcaCertificate to import
    * @param importFromId The id of the existing DataAwsccAcmpcaCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/acmpca_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAcmpcaCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/data-sources/acmpca_certificate awscc_acmpca_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAcmpcaCertificateConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAcmpcaCertificateConfig);
    private _apiPassthrough;
    get apiPassthrough(): DataAwsccAcmpcaCertificateApiPassthroughOutputReference;
    get arn(): string;
    get certificate(): string;
    get certificateAuthorityArn(): string;
    get certificateSigningRequest(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get signingAlgorithm(): string;
    get templateArn(): string;
    private _validity;
    get validity(): DataAwsccAcmpcaCertificateValidityOutputReference;
    private _validityNotBefore;
    get validityNotBefore(): DataAwsccAcmpcaCertificateValidityNotBeforeOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
