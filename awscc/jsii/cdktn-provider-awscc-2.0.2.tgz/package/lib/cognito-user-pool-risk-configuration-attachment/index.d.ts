/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoUserPoolRiskConfigurationAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#account_takeover_risk_configuration CognitoUserPoolRiskConfigurationAttachment#account_takeover_risk_configuration}
    */
    readonly accountTakeoverRiskConfiguration?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#client_id CognitoUserPoolRiskConfigurationAttachment#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#compromised_credentials_risk_configuration CognitoUserPoolRiskConfigurationAttachment#compromised_credentials_risk_configuration}
    */
    readonly compromisedCredentialsRiskConfiguration?: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#risk_exception_configuration CognitoUserPoolRiskConfigurationAttachment#risk_exception_configuration}
    */
    readonly riskExceptionConfiguration?: CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#user_pool_id CognitoUserPoolRiskConfigurationAttachment#user_pool_id}
    */
    readonly userPoolId: string;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#event_action CognitoUserPoolRiskConfigurationAttachment#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#notify CognitoUserPoolRiskConfigurationAttachment#notify}
    */
    readonly notify?: boolean | cdktn.IResolvable;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighActionToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighAction | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighActionToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighAction | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighAction | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighAction | cdktn.IResolvable | undefined);
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _notify?;
    get notify(): boolean | cdktn.IResolvable;
    set notify(value: boolean | cdktn.IResolvable);
    resetNotify(): void;
    get notifyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#event_action CognitoUserPoolRiskConfigurationAttachment#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#notify CognitoUserPoolRiskConfigurationAttachment#notify}
    */
    readonly notify?: boolean | cdktn.IResolvable;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowActionToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowAction | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowActionToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowAction | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowAction | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowAction | cdktn.IResolvable | undefined);
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _notify?;
    get notify(): boolean | cdktn.IResolvable;
    set notify(value: boolean | cdktn.IResolvable);
    resetNotify(): void;
    get notifyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#event_action CognitoUserPoolRiskConfigurationAttachment#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#notify CognitoUserPoolRiskConfigurationAttachment#notify}
    */
    readonly notify?: boolean | cdktn.IResolvable;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumActionToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumAction | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumActionToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumAction | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumAction | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumAction | cdktn.IResolvable | undefined);
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _notify?;
    get notify(): boolean | cdktn.IResolvable;
    set notify(value: boolean | cdktn.IResolvable);
    resetNotify(): void;
    get notifyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#high_action CognitoUserPoolRiskConfigurationAttachment#high_action}
    */
    readonly highAction?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighAction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#low_action CognitoUserPoolRiskConfigurationAttachment#low_action}
    */
    readonly lowAction?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowAction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#medium_action CognitoUserPoolRiskConfigurationAttachment#medium_action}
    */
    readonly mediumAction?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumAction;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActions | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActions | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActions | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActions | cdktn.IResolvable | undefined);
    private _highAction;
    get highAction(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighActionOutputReference;
    putHighAction(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighAction): void;
    resetHighAction(): void;
    get highActionInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsHighAction | undefined;
    private _lowAction;
    get lowAction(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowActionOutputReference;
    putLowAction(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowAction): void;
    resetLowAction(): void;
    get lowActionInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsLowAction | undefined;
    private _mediumAction;
    get mediumAction(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumActionOutputReference;
    putMediumAction(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumAction): void;
    resetMediumAction(): void;
    get mediumActionInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsMediumAction | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#html_body CognitoUserPoolRiskConfigurationAttachment#html_body}
    */
    readonly htmlBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#subject CognitoUserPoolRiskConfigurationAttachment#subject}
    */
    readonly subject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#text_body CognitoUserPoolRiskConfigurationAttachment#text_body}
    */
    readonly textBody?: string;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmailToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmail | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmailToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmail | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmail | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmail | cdktn.IResolvable | undefined);
    private _htmlBody?;
    get htmlBody(): string;
    set htmlBody(value: string);
    resetHtmlBody(): void;
    get htmlBodyInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
    private _textBody?;
    get textBody(): string;
    set textBody(value: string);
    resetTextBody(): void;
    get textBodyInput(): string | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#html_body CognitoUserPoolRiskConfigurationAttachment#html_body}
    */
    readonly htmlBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#subject CognitoUserPoolRiskConfigurationAttachment#subject}
    */
    readonly subject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#text_body CognitoUserPoolRiskConfigurationAttachment#text_body}
    */
    readonly textBody?: string;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmailToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmail | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmailToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmail | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmail | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmail | cdktn.IResolvable | undefined);
    private _htmlBody?;
    get htmlBody(): string;
    set htmlBody(value: string);
    resetHtmlBody(): void;
    get htmlBodyInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
    private _textBody?;
    get textBody(): string;
    set textBody(value: string);
    resetTextBody(): void;
    get textBodyInput(): string | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#html_body CognitoUserPoolRiskConfigurationAttachment#html_body}
    */
    readonly htmlBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#subject CognitoUserPoolRiskConfigurationAttachment#subject}
    */
    readonly subject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#text_body CognitoUserPoolRiskConfigurationAttachment#text_body}
    */
    readonly textBody?: string;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmailToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmail | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmailToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmail | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmail | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmail | cdktn.IResolvable | undefined);
    private _htmlBody?;
    get htmlBody(): string;
    set htmlBody(value: string);
    resetHtmlBody(): void;
    get htmlBodyInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
    private _textBody?;
    get textBody(): string;
    set textBody(value: string);
    resetTextBody(): void;
    get textBodyInput(): string | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#block_email CognitoUserPoolRiskConfigurationAttachment#block_email}
    */
    readonly blockEmail?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmail;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#from CognitoUserPoolRiskConfigurationAttachment#from}
    */
    readonly from?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#mfa_email CognitoUserPoolRiskConfigurationAttachment#mfa_email}
    */
    readonly mfaEmail?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmail;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#no_action_email CognitoUserPoolRiskConfigurationAttachment#no_action_email}
    */
    readonly noActionEmail?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmail;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#reply_to CognitoUserPoolRiskConfigurationAttachment#reply_to}
    */
    readonly replyTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#source_arn CognitoUserPoolRiskConfigurationAttachment#source_arn}
    */
    readonly sourceArn?: string;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfiguration | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfiguration | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfiguration | cdktn.IResolvable | undefined);
    private _blockEmail;
    get blockEmail(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmailOutputReference;
    putBlockEmail(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmail): void;
    resetBlockEmail(): void;
    get blockEmailInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationBlockEmail | undefined;
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _mfaEmail;
    get mfaEmail(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmailOutputReference;
    putMfaEmail(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmail): void;
    resetMfaEmail(): void;
    get mfaEmailInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationMfaEmail | undefined;
    private _noActionEmail;
    get noActionEmail(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmailOutputReference;
    putNoActionEmail(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmail): void;
    resetNoActionEmail(): void;
    get noActionEmailInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationNoActionEmail | undefined;
    private _replyTo?;
    get replyTo(): string;
    set replyTo(value: string);
    resetReplyTo(): void;
    get replyToInput(): string | undefined;
    private _sourceArn?;
    get sourceArn(): string;
    set sourceArn(value: string);
    resetSourceArn(): void;
    get sourceArnInput(): string | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#actions CognitoUserPoolRiskConfigurationAttachment#actions}
    */
    readonly actions?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#notify_configuration CognitoUserPoolRiskConfigurationAttachment#notify_configuration}
    */
    readonly notifyConfiguration?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfiguration;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfiguration | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfiguration | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfiguration | cdktn.IResolvable | undefined);
    private _actions;
    get actions(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActionsOutputReference;
    putActions(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActions): void;
    resetActions(): void;
    get actionsInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationActions | undefined;
    private _notifyConfiguration;
    get notifyConfiguration(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfigurationOutputReference;
    putNotifyConfiguration(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfiguration): void;
    resetNotifyConfiguration(): void;
    get notifyConfigurationInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationNotifyConfiguration | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#event_action CognitoUserPoolRiskConfigurationAttachment#event_action}
    */
    readonly eventAction?: string;
}
export declare function cognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActionsToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActions | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActionsToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActions | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActions | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActions | cdktn.IResolvable | undefined);
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#actions CognitoUserPoolRiskConfigurationAttachment#actions}
    */
    readonly actions?: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#event_filter CognitoUserPoolRiskConfigurationAttachment#event_filter}
    */
    readonly eventFilter?: string[];
}
export declare function cognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfiguration | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfiguration | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfiguration | cdktn.IResolvable | undefined);
    private _actions;
    get actions(): CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActionsOutputReference;
    putActions(value: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActions): void;
    resetActions(): void;
    get actionsInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationActions | undefined;
    private _eventFilter?;
    get eventFilter(): string[];
    set eventFilter(value: string[]);
    resetEventFilter(): void;
    get eventFilterInput(): string[] | undefined;
}
export interface CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#blocked_ip_range_list CognitoUserPoolRiskConfigurationAttachment#blocked_ip_range_list}
    */
    readonly blockedIpRangeList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#skipped_ip_range_list CognitoUserPoolRiskConfigurationAttachment#skipped_ip_range_list}
    */
    readonly skippedIpRangeList?: string[];
}
export declare function cognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfigurationToTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfiguration | cdktn.IResolvable): any;
export declare function cognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfigurationToHclTerraform(struct?: CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfiguration | cdktn.IResolvable): any;
export declare class CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfiguration | cdktn.IResolvable | undefined);
    private _blockedIpRangeList?;
    get blockedIpRangeList(): string[];
    set blockedIpRangeList(value: string[]);
    resetBlockedIpRangeList(): void;
    get blockedIpRangeListInput(): string[] | undefined;
    private _skippedIpRangeList?;
    get skippedIpRangeList(): string[];
    set skippedIpRangeList(value: string[]);
    resetSkippedIpRangeList(): void;
    get skippedIpRangeListInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment awscc_cognito_user_pool_risk_configuration_attachment}
*/
export declare class CognitoUserPoolRiskConfigurationAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_user_pool_risk_configuration_attachment";
    /**
    * Generates CDKTN code for importing a CognitoUserPoolRiskConfigurationAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoUserPoolRiskConfigurationAttachment to import
    * @param importFromId The id of the existing CognitoUserPoolRiskConfigurationAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoUserPoolRiskConfigurationAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_risk_configuration_attachment awscc_cognito_user_pool_risk_configuration_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoUserPoolRiskConfigurationAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: CognitoUserPoolRiskConfigurationAttachmentConfig);
    private _accountTakeoverRiskConfiguration;
    get accountTakeoverRiskConfiguration(): CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfigurationOutputReference;
    putAccountTakeoverRiskConfiguration(value: CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfiguration): void;
    resetAccountTakeoverRiskConfiguration(): void;
    get accountTakeoverRiskConfigurationInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentAccountTakeoverRiskConfiguration | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _compromisedCredentialsRiskConfiguration;
    get compromisedCredentialsRiskConfiguration(): CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfigurationOutputReference;
    putCompromisedCredentialsRiskConfiguration(value: CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfiguration): void;
    resetCompromisedCredentialsRiskConfiguration(): void;
    get compromisedCredentialsRiskConfigurationInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentCompromisedCredentialsRiskConfiguration | undefined;
    get id(): string;
    private _riskExceptionConfiguration;
    get riskExceptionConfiguration(): CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfigurationOutputReference;
    putRiskExceptionConfiguration(value: CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfiguration): void;
    resetRiskExceptionConfiguration(): void;
    get riskExceptionConfigurationInput(): cdktn.IResolvable | CognitoUserPoolRiskConfigurationAttachmentRiskExceptionConfiguration | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
