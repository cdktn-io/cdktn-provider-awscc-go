/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchAlertConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#description CloudwatchAlert#description}
    */
    readonly description?: string;
    /**
    * The display name of the alert. Names don't need to be unique within a space; the alert is identified by AlertId.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#name CloudwatchAlert#name}
    */
    readonly name: string;
    /**
    * The notification rules that determine when and where notifications are sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#notification_rules CloudwatchAlert#notification_rules}
    */
    readonly notificationRules?: CloudwatchAlertNotificationRules[] | cdktn.IResolvable;
    /**
    * Whether the alert sends notifications. When false, the alert is still evaluated and records its state, but sends nothing. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#notifications_enabled CloudwatchAlert#notifications_enabled}
    */
    readonly notificationsEnabled?: boolean | cdktn.IResolvable;
    /**
    * The ID of the access profile the alert uses to run its query and send notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#profile_id CloudwatchAlert#profile_id}
    */
    readonly profileId: string;
    /**
    * The rule that defines how the alert is evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#rule CloudwatchAlert#rule}
    */
    readonly rule: CloudwatchAlertRule;
    /**
    * The ID of the space to create the alert in. Changing this value replaces the alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#space_id CloudwatchAlert#space_id}
    */
    readonly spaceId: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#tags CloudwatchAlert#tags}
    */
    readonly tags?: CloudwatchAlertTags[] | cdktn.IResolvable;
}
export interface CloudwatchAlertNotificationRulesTarget {
    /**
    * The ARN of the target. For sns, the ARN of the Amazon SNS topic. For slack and pagerduty, the ARN of a CloudWatch Omni integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#arn CloudwatchAlert#arn}
    */
    readonly arn?: string;
    /**
    * Settings specific to the target, as key-value pairs (up to 20). The keys depend on the integration type. Not used for sns targets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#metadata CloudwatchAlert#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * The target type. Valid values: sns, slack, pagerduty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#type CloudwatchAlert#type}
    */
    readonly type?: string;
}
export declare function cloudwatchAlertNotificationRulesTargetToTerraform(struct?: CloudwatchAlertNotificationRulesTarget | cdktn.IResolvable): any;
export declare function cloudwatchAlertNotificationRulesTargetToHclTerraform(struct?: CloudwatchAlertNotificationRulesTarget | cdktn.IResolvable): any;
export declare class CloudwatchAlertNotificationRulesTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlertNotificationRulesTarget | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertNotificationRulesTarget | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CloudwatchAlertNotificationRulesTrigger {
    /**
    * The alert states that trigger this rule. A notification is sent when the alert enters any listed state. If omitted or empty, every state triggers the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#state_values CloudwatchAlert#state_values}
    */
    readonly stateValues?: string[];
}
export declare function cloudwatchAlertNotificationRulesTriggerToTerraform(struct?: CloudwatchAlertNotificationRulesTrigger | cdktn.IResolvable): any;
export declare function cloudwatchAlertNotificationRulesTriggerToHclTerraform(struct?: CloudwatchAlertNotificationRulesTrigger | cdktn.IResolvable): any;
export declare class CloudwatchAlertNotificationRulesTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlertNotificationRulesTrigger | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertNotificationRulesTrigger | cdktn.IResolvable | undefined);
    private _stateValues?;
    get stateValues(): string[];
    set stateValues(value: string[]);
    resetStateValues(): void;
    get stateValuesInput(): string[] | undefined;
}
export interface CloudwatchAlertNotificationRules {
    /**
    * Where the notification is sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#target CloudwatchAlert#target}
    */
    readonly target?: CloudwatchAlertNotificationRulesTarget;
    /**
    * The alert states that trigger the notification rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#trigger CloudwatchAlert#trigger}
    */
    readonly trigger?: CloudwatchAlertNotificationRulesTrigger;
}
export declare function cloudwatchAlertNotificationRulesToTerraform(struct?: CloudwatchAlertNotificationRules | cdktn.IResolvable): any;
export declare function cloudwatchAlertNotificationRulesToHclTerraform(struct?: CloudwatchAlertNotificationRules | cdktn.IResolvable): any;
export declare class CloudwatchAlertNotificationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlertNotificationRules | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertNotificationRules | cdktn.IResolvable | undefined);
    private _target;
    get target(): CloudwatchAlertNotificationRulesTargetOutputReference;
    putTarget(value: CloudwatchAlertNotificationRulesTarget): void;
    resetTarget(): void;
    get targetInput(): cdktn.IResolvable | CloudwatchAlertNotificationRulesTarget | undefined;
    private _trigger;
    get trigger(): CloudwatchAlertNotificationRulesTriggerOutputReference;
    putTrigger(value: CloudwatchAlertNotificationRulesTrigger): void;
    resetTrigger(): void;
    get triggerInput(): cdktn.IResolvable | CloudwatchAlertNotificationRulesTrigger | undefined;
}
export declare class CloudwatchAlertNotificationRulesList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlertNotificationRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlertNotificationRulesOutputReference;
}
export interface CloudwatchAlertRuleTelemetryRuleCondition {
    /**
    * The comparison operator. Valid values: GT, GTE, LT, LTE (greater than, greater than or equal to, less than, less than or equal to).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#comparator CloudwatchAlert#comparator}
    */
    readonly comparator?: string;
    /**
    * The value at which the alert enters the CRITICAL state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#critical_threshold CloudwatchAlert#critical_threshold}
    */
    readonly criticalThreshold?: number;
    /**
    * The result field to compare against the threshold. Required when ThresholdMode is FIELD_VALUE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#threshold_field CloudwatchAlert#threshold_field}
    */
    readonly thresholdField?: string;
    /**
    * How the threshold is applied. COUNT_OF_RESULTS compares the number of rows the query returns. FIELD_VALUE compares the value of ThresholdField in each result row; each row is tracked separately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#threshold_mode CloudwatchAlert#threshold_mode}
    */
    readonly thresholdMode?: string;
    /**
    * The value at which the alert enters the WARNING state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#warning_threshold CloudwatchAlert#warning_threshold}
    */
    readonly warningThreshold?: number;
}
export declare function cloudwatchAlertRuleTelemetryRuleConditionToTerraform(struct?: CloudwatchAlertRuleTelemetryRuleCondition | cdktn.IResolvable): any;
export declare function cloudwatchAlertRuleTelemetryRuleConditionToHclTerraform(struct?: CloudwatchAlertRuleTelemetryRuleCondition | cdktn.IResolvable): any;
export declare class CloudwatchAlertRuleTelemetryRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlertRuleTelemetryRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertRuleTelemetryRuleCondition | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    resetComparator(): void;
    get comparatorInput(): string | undefined;
    private _criticalThreshold?;
    get criticalThreshold(): number;
    set criticalThreshold(value: number);
    resetCriticalThreshold(): void;
    get criticalThresholdInput(): number | undefined;
    private _thresholdField?;
    get thresholdField(): string;
    set thresholdField(value: string);
    resetThresholdField(): void;
    get thresholdFieldInput(): string | undefined;
    private _thresholdMode?;
    get thresholdMode(): string;
    set thresholdMode(value: string);
    resetThresholdMode(): void;
    get thresholdModeInput(): string | undefined;
    private _warningThreshold?;
    get warningThreshold(): number;
    set warningThreshold(value: number);
    resetWarningThreshold(): void;
    get warningThresholdInput(): number | undefined;
}
export interface CloudwatchAlertRuleTelemetryRuleEvaluation {
    /**
    * The time between evaluations, in seconds. Valid values: 30, 60, 120, 300, 600, 900, 1800, 3600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#interval_seconds CloudwatchAlert#interval_seconds}
    */
    readonly intervalSeconds: number;
    /**
    * How long a threshold breach must last before the alert changes state, in seconds. Must be a multiple of IntervalSeconds. 0 changes state immediately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#pending_duration_seconds CloudwatchAlert#pending_duration_seconds}
    */
    readonly pendingDurationSeconds?: number;
    /**
    * How long the result must stay within its thresholds before the alert returns to OK, in seconds. Must be a multiple of IntervalSeconds. 0 returns to OK immediately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#recovery_duration_seconds CloudwatchAlert#recovery_duration_seconds}
    */
    readonly recoveryDurationSeconds?: number;
}
export declare function cloudwatchAlertRuleTelemetryRuleEvaluationToTerraform(struct?: CloudwatchAlertRuleTelemetryRuleEvaluation | cdktn.IResolvable): any;
export declare function cloudwatchAlertRuleTelemetryRuleEvaluationToHclTerraform(struct?: CloudwatchAlertRuleTelemetryRuleEvaluation | cdktn.IResolvable): any;
export declare class CloudwatchAlertRuleTelemetryRuleEvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlertRuleTelemetryRuleEvaluation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertRuleTelemetryRuleEvaluation | cdktn.IResolvable | undefined);
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    get intervalSecondsInput(): number | undefined;
    private _pendingDurationSeconds?;
    get pendingDurationSeconds(): number;
    set pendingDurationSeconds(value: number);
    resetPendingDurationSeconds(): void;
    get pendingDurationSecondsInput(): number | undefined;
    private _recoveryDurationSeconds?;
    get recoveryDurationSeconds(): number;
    set recoveryDurationSeconds(value: number);
    resetRecoveryDurationSeconds(): void;
    get recoveryDurationSecondsInput(): number | undefined;
}
export interface CloudwatchAlertRuleTelemetryRuleNoData {
    /**
    * The state to report when an evaluation returns no data. Valid values: OK, WARNING, CRITICAL, NODATA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#treat_as CloudwatchAlert#treat_as}
    */
    readonly treatAs?: string;
}
export declare function cloudwatchAlertRuleTelemetryRuleNoDataToTerraform(struct?: CloudwatchAlertRuleTelemetryRuleNoData | cdktn.IResolvable): any;
export declare function cloudwatchAlertRuleTelemetryRuleNoDataToHclTerraform(struct?: CloudwatchAlertRuleTelemetryRuleNoData | cdktn.IResolvable): any;
export declare class CloudwatchAlertRuleTelemetryRuleNoDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlertRuleTelemetryRuleNoData | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertRuleTelemetryRuleNoData | cdktn.IResolvable | undefined);
    private _treatAs?;
    get treatAs(): string;
    set treatAs(value: string);
    resetTreatAs(): void;
    get treatAsInput(): string | undefined;
}
export interface CloudwatchAlertRuleTelemetryRuleQuery {
    /**
    * The query expression. For PromQL, the series value is returned in a field named value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#expression CloudwatchAlert#expression}
    */
    readonly expression: string;
    /**
    * The query language. Valid values: SQL, PROMQL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#language CloudwatchAlert#language}
    */
    readonly language: string;
}
export declare function cloudwatchAlertRuleTelemetryRuleQueryToTerraform(struct?: CloudwatchAlertRuleTelemetryRuleQuery | cdktn.IResolvable): any;
export declare function cloudwatchAlertRuleTelemetryRuleQueryToHclTerraform(struct?: CloudwatchAlertRuleTelemetryRuleQuery | cdktn.IResolvable): any;
export declare class CloudwatchAlertRuleTelemetryRuleQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlertRuleTelemetryRuleQuery | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertRuleTelemetryRuleQuery | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _language?;
    get language(): string;
    set language(value: string);
    get languageInput(): string | undefined;
}
export interface CloudwatchAlertRuleTelemetryRule {
    /**
    * The thresholds that set the alert's state. Specify at least one of WarningThreshold and CriticalThreshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#condition CloudwatchAlert#condition}
    */
    readonly condition: CloudwatchAlertRuleTelemetryRuleCondition;
    /**
    * How often the alert is evaluated, and how long a change must last before the state changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#evaluation CloudwatchAlert#evaluation}
    */
    readonly evaluation: CloudwatchAlertRuleTelemetryRuleEvaluation;
    /**
    * How the alert behaves when an evaluation returns no data. If omitted, the alert reports NODATA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#no_data CloudwatchAlert#no_data}
    */
    readonly noData?: CloudwatchAlertRuleTelemetryRuleNoData;
    /**
    * The query the alert runs, and the language it is written in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#query CloudwatchAlert#query}
    */
    readonly query: CloudwatchAlertRuleTelemetryRuleQuery;
}
export declare function cloudwatchAlertRuleTelemetryRuleToTerraform(struct?: CloudwatchAlertRuleTelemetryRule | cdktn.IResolvable): any;
export declare function cloudwatchAlertRuleTelemetryRuleToHclTerraform(struct?: CloudwatchAlertRuleTelemetryRule | cdktn.IResolvable): any;
export declare class CloudwatchAlertRuleTelemetryRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlertRuleTelemetryRule | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertRuleTelemetryRule | cdktn.IResolvable | undefined);
    private _condition;
    get condition(): CloudwatchAlertRuleTelemetryRuleConditionOutputReference;
    putCondition(value: CloudwatchAlertRuleTelemetryRuleCondition): void;
    get conditionInput(): cdktn.IResolvable | CloudwatchAlertRuleTelemetryRuleCondition | undefined;
    private _evaluation;
    get evaluation(): CloudwatchAlertRuleTelemetryRuleEvaluationOutputReference;
    putEvaluation(value: CloudwatchAlertRuleTelemetryRuleEvaluation): void;
    get evaluationInput(): cdktn.IResolvable | CloudwatchAlertRuleTelemetryRuleEvaluation | undefined;
    private _noData;
    get noData(): CloudwatchAlertRuleTelemetryRuleNoDataOutputReference;
    putNoData(value: CloudwatchAlertRuleTelemetryRuleNoData): void;
    resetNoData(): void;
    get noDataInput(): cdktn.IResolvable | CloudwatchAlertRuleTelemetryRuleNoData | undefined;
    private _query;
    get query(): CloudwatchAlertRuleTelemetryRuleQueryOutputReference;
    putQuery(value: CloudwatchAlertRuleTelemetryRuleQuery): void;
    get queryInput(): cdktn.IResolvable | CloudwatchAlertRuleTelemetryRuleQuery | undefined;
}
export interface CloudwatchAlertRule {
    /**
    * A rule that queries telemetry, evaluates the result against a condition, and sets how missing data is handled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#telemetry_rule CloudwatchAlert#telemetry_rule}
    */
    readonly telemetryRule: CloudwatchAlertRuleTelemetryRule;
}
export declare function cloudwatchAlertRuleToTerraform(struct?: CloudwatchAlertRule | cdktn.IResolvable): any;
export declare function cloudwatchAlertRuleToHclTerraform(struct?: CloudwatchAlertRule | cdktn.IResolvable): any;
export declare class CloudwatchAlertRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlertRule | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertRule | cdktn.IResolvable | undefined);
    private _telemetryRule;
    get telemetryRule(): CloudwatchAlertRuleTelemetryRuleOutputReference;
    putTelemetryRule(value: CloudwatchAlertRuleTelemetryRule): void;
    get telemetryRuleInput(): cdktn.IResolvable | CloudwatchAlertRuleTelemetryRule | undefined;
}
export interface CloudwatchAlertTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#key CloudwatchAlert#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#value CloudwatchAlert#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAlertTagsToTerraform(struct?: CloudwatchAlertTags | cdktn.IResolvable): any;
export declare function cloudwatchAlertTagsToHclTerraform(struct?: CloudwatchAlertTags | cdktn.IResolvable): any;
export declare class CloudwatchAlertTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlertTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlertTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAlertTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlertTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlertTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert awscc_cloudwatch_alert}
*/
export declare class CloudwatchAlert extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_alert";
    /**
    * Generates CDKTN code for importing a CloudwatchAlert resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchAlert to import
    * @param importFromId The id of the existing CloudwatchAlert that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchAlert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_alert awscc_cloudwatch_alert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchAlertConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchAlertConfig);
    get accountId(): string;
    get alertId(): string;
    get arn(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notificationRules;
    get notificationRules(): CloudwatchAlertNotificationRulesList;
    putNotificationRules(value: CloudwatchAlertNotificationRules[] | cdktn.IResolvable): void;
    resetNotificationRules(): void;
    get notificationRulesInput(): cdktn.IResolvable | CloudwatchAlertNotificationRules[] | undefined;
    private _notificationsEnabled?;
    get notificationsEnabled(): boolean | cdktn.IResolvable;
    set notificationsEnabled(value: boolean | cdktn.IResolvable);
    resetNotificationsEnabled(): void;
    get notificationsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _profileId?;
    get profileId(): string;
    set profileId(value: string);
    get profileIdInput(): string | undefined;
    private _rule;
    get rule(): CloudwatchAlertRuleOutputReference;
    putRule(value: CloudwatchAlertRule): void;
    get ruleInput(): cdktn.IResolvable | CloudwatchAlertRule | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
    private _tags;
    get tags(): CloudwatchAlertTagsList;
    putTags(value: CloudwatchAlertTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchAlertTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
