/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchDomainForOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the customer-provided IAM role in the management account used for domain access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#domain_access_role_arn CloudwatchDomainForOrganization#domain_access_role_arn}
    */
    readonly domainAccessRoleArn: string;
    /**
    * Identity provider configuration for the organization domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#identity_provider_configuration CloudwatchDomainForOrganization#identity_provider_configuration}
    */
    readonly identityProviderConfiguration?: CloudwatchDomainForOrganizationIdentityProviderConfiguration;
    /**
    * The identity providers configured for the organization domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#identity_providers CloudwatchDomainForOrganization#identity_providers}
    */
    readonly identityProviders: string[];
    /**
    * A name that identifies the organization domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#name CloudwatchDomainForOrganization#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#tags CloudwatchDomainForOrganization#tags}
    */
    readonly tags?: CloudwatchDomainForOrganizationTags[] | cdktn.IResolvable;
}
export interface CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfiguration {
    /**
    * Identity Center instance ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#identity_center_instance_arn CloudwatchDomainForOrganization#identity_center_instance_arn}
    */
    readonly identityCenterInstanceArn?: string;
}
export declare function cloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfigurationToTerraform(struct?: CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfigurationToHclTerraform(struct?: CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable | undefined);
    private _identityCenterInstanceArn?;
    get identityCenterInstanceArn(): string;
    set identityCenterInstanceArn(value: string);
    resetIdentityCenterInstanceArn(): void;
    get identityCenterInstanceArnInput(): string | undefined;
}
export interface CloudwatchDomainForOrganizationIdentityProviderConfiguration {
    /**
    * Identity Center configuration. Required when identityProviders includes IDC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#identity_center_configuration CloudwatchDomainForOrganization#identity_center_configuration}
    */
    readonly identityCenterConfiguration?: CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfiguration;
}
export declare function cloudwatchDomainForOrganizationIdentityProviderConfigurationToTerraform(struct?: CloudwatchDomainForOrganizationIdentityProviderConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchDomainForOrganizationIdentityProviderConfigurationToHclTerraform(struct?: CloudwatchDomainForOrganizationIdentityProviderConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchDomainForOrganizationIdentityProviderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchDomainForOrganizationIdentityProviderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainForOrganizationIdentityProviderConfiguration | cdktn.IResolvable | undefined);
    private _identityCenterConfiguration;
    get identityCenterConfiguration(): CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfigurationOutputReference;
    putIdentityCenterConfiguration(value: CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfiguration): void;
    resetIdentityCenterConfiguration(): void;
    get identityCenterConfigurationInput(): cdktn.IResolvable | CloudwatchDomainForOrganizationIdentityProviderConfigurationIdentityCenterConfiguration | undefined;
}
export interface CloudwatchDomainForOrganizationTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#key CloudwatchDomainForOrganization#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#value CloudwatchDomainForOrganization#value}
    */
    readonly value?: string;
}
export declare function cloudwatchDomainForOrganizationTagsToTerraform(struct?: CloudwatchDomainForOrganizationTags | cdktn.IResolvable): any;
export declare function cloudwatchDomainForOrganizationTagsToHclTerraform(struct?: CloudwatchDomainForOrganizationTags | cdktn.IResolvable): any;
export declare class CloudwatchDomainForOrganizationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchDomainForOrganizationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchDomainForOrganizationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchDomainForOrganizationTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchDomainForOrganizationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchDomainForOrganizationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization awscc_cloudwatch_domain_for_organization}
*/
export declare class CloudwatchDomainForOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_domain_for_organization";
    /**
    * Generates CDKTN code for importing a CloudwatchDomainForOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchDomainForOrganization to import
    * @param importFromId The id of the existing CloudwatchDomainForOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchDomainForOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cloudwatch_domain_for_organization awscc_cloudwatch_domain_for_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchDomainForOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchDomainForOrganizationConfig);
    get arn(): string;
    get createdAt(): string;
    get customEndpointUrls(): string[];
    private _domainAccessRoleArn?;
    get domainAccessRoleArn(): string;
    set domainAccessRoleArn(value: string);
    get domainAccessRoleArnInput(): string | undefined;
    get domainEndpointUrl(): string;
    get domainId(): string;
    get id(): string;
    get identityCenterApplicationArn(): string;
    private _identityProviderConfiguration;
    get identityProviderConfiguration(): CloudwatchDomainForOrganizationIdentityProviderConfigurationOutputReference;
    putIdentityProviderConfiguration(value: CloudwatchDomainForOrganizationIdentityProviderConfiguration): void;
    resetIdentityProviderConfiguration(): void;
    get identityProviderConfigurationInput(): cdktn.IResolvable | CloudwatchDomainForOrganizationIdentityProviderConfiguration | undefined;
    private _identityProviders?;
    get identityProviders(): string[];
    set identityProviders(value: string[]);
    get identityProvidersInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    get ownerAccountId(): string;
    get region(): string;
    get status(): string;
    private _tags;
    get tags(): CloudwatchDomainForOrganizationTagsList;
    putTags(value: CloudwatchDomainForOrganizationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchDomainForOrganizationTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
