/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppfabricIngestionDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the app bundle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#app_bundle_arn AppfabricIngestionDestination#app_bundle_arn}
    */
    readonly appBundleArn: string;
    /**
    * Contains information about the destination of ingested data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#destination_configuration AppfabricIngestionDestination#destination_configuration}
    */
    readonly destinationConfiguration: AppfabricIngestionDestinationDestinationConfiguration;
    /**
    * The Amazon Resource Name (ARN) of the ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#ingestion_arn AppfabricIngestionDestination#ingestion_arn}
    */
    readonly ingestionArn: string;
    /**
    * Contains information about how ingested data is processed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#processing_configuration AppfabricIngestionDestination#processing_configuration}
    */
    readonly processingConfiguration: AppfabricIngestionDestinationProcessingConfiguration;
    /**
    * A map of the key-value pairs of the tag or tags to assign to the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#tags AppfabricIngestionDestination#tags}
    */
    readonly tags?: AppfabricIngestionDestinationTags[] | cdktn.IResolvable;
}
export interface AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStream {
    /**
    * The name of the Amazon Kinesis Data Firehose delivery stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#stream_name AppfabricIngestionDestination#stream_name}
    */
    readonly streamName?: string;
}
export declare function appfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStreamToTerraform(struct?: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStream | cdktn.IResolvable): any;
export declare function appfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStreamToHclTerraform(struct?: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStream | cdktn.IResolvable): any;
export declare class AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStreamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStream | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStream | cdktn.IResolvable | undefined);
    private _streamName?;
    get streamName(): string;
    set streamName(value: string);
    resetStreamName(): void;
    get streamNameInput(): string | undefined;
}
export interface AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3Bucket {
    /**
    * The name of the Amazon S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#bucket_name AppfabricIngestionDestination#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The object key to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#prefix AppfabricIngestionDestination#prefix}
    */
    readonly prefix?: string;
}
export declare function appfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3BucketToTerraform(struct?: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3Bucket | cdktn.IResolvable): any;
export declare function appfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3BucketToHclTerraform(struct?: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3Bucket | cdktn.IResolvable): any;
export declare class AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3BucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3Bucket | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3Bucket | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
export interface AppfabricIngestionDestinationDestinationConfigurationAuditLogDestination {
    /**
    * Contains information about an Amazon Kinesis Data Firehose delivery stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#firehose_stream AppfabricIngestionDestination#firehose_stream}
    */
    readonly firehoseStream?: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStream;
    /**
    * Contains information about an Amazon S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#s3_bucket AppfabricIngestionDestination#s3_bucket}
    */
    readonly s3Bucket?: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3Bucket;
}
export declare function appfabricIngestionDestinationDestinationConfigurationAuditLogDestinationToTerraform(struct?: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestination | cdktn.IResolvable): any;
export declare function appfabricIngestionDestinationDestinationConfigurationAuditLogDestinationToHclTerraform(struct?: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestination | cdktn.IResolvable): any;
export declare class AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricIngestionDestinationDestinationConfigurationAuditLogDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestination | cdktn.IResolvable | undefined);
    private _firehoseStream;
    get firehoseStream(): AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStreamOutputReference;
    putFirehoseStream(value: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStream): void;
    resetFirehoseStream(): void;
    get firehoseStreamInput(): cdktn.IResolvable | AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationFirehoseStream | undefined;
    private _s3Bucket;
    get s3Bucket(): AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3BucketOutputReference;
    putS3Bucket(value: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3Bucket): void;
    resetS3Bucket(): void;
    get s3BucketInput(): cdktn.IResolvable | AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationS3Bucket | undefined;
}
export interface AppfabricIngestionDestinationDestinationConfigurationAuditLog {
    /**
    * Contains information about an audit log destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#destination AppfabricIngestionDestination#destination}
    */
    readonly destination: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestination;
}
export declare function appfabricIngestionDestinationDestinationConfigurationAuditLogToTerraform(struct?: AppfabricIngestionDestinationDestinationConfigurationAuditLog | cdktn.IResolvable): any;
export declare function appfabricIngestionDestinationDestinationConfigurationAuditLogToHclTerraform(struct?: AppfabricIngestionDestinationDestinationConfigurationAuditLog | cdktn.IResolvable): any;
export declare class AppfabricIngestionDestinationDestinationConfigurationAuditLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricIngestionDestinationDestinationConfigurationAuditLog | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricIngestionDestinationDestinationConfigurationAuditLog | cdktn.IResolvable | undefined);
    private _destination;
    get destination(): AppfabricIngestionDestinationDestinationConfigurationAuditLogDestinationOutputReference;
    putDestination(value: AppfabricIngestionDestinationDestinationConfigurationAuditLogDestination): void;
    get destinationInput(): cdktn.IResolvable | AppfabricIngestionDestinationDestinationConfigurationAuditLogDestination | undefined;
}
export interface AppfabricIngestionDestinationDestinationConfiguration {
    /**
    * Contains information about an audit log destination configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#audit_log AppfabricIngestionDestination#audit_log}
    */
    readonly auditLog: AppfabricIngestionDestinationDestinationConfigurationAuditLog;
}
export declare function appfabricIngestionDestinationDestinationConfigurationToTerraform(struct?: AppfabricIngestionDestinationDestinationConfiguration | cdktn.IResolvable): any;
export declare function appfabricIngestionDestinationDestinationConfigurationToHclTerraform(struct?: AppfabricIngestionDestinationDestinationConfiguration | cdktn.IResolvable): any;
export declare class AppfabricIngestionDestinationDestinationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricIngestionDestinationDestinationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricIngestionDestinationDestinationConfiguration | cdktn.IResolvable | undefined);
    private _auditLog;
    get auditLog(): AppfabricIngestionDestinationDestinationConfigurationAuditLogOutputReference;
    putAuditLog(value: AppfabricIngestionDestinationDestinationConfigurationAuditLog): void;
    get auditLogInput(): cdktn.IResolvable | AppfabricIngestionDestinationDestinationConfigurationAuditLog | undefined;
}
export interface AppfabricIngestionDestinationProcessingConfigurationAuditLog {
    /**
    * The format in which the audit logs need to be formatted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#format AppfabricIngestionDestination#format}
    */
    readonly format: string;
    /**
    * The event schema in which the audit logs need to be formatted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#schema AppfabricIngestionDestination#schema}
    */
    readonly schema: string;
}
export declare function appfabricIngestionDestinationProcessingConfigurationAuditLogToTerraform(struct?: AppfabricIngestionDestinationProcessingConfigurationAuditLog | cdktn.IResolvable): any;
export declare function appfabricIngestionDestinationProcessingConfigurationAuditLogToHclTerraform(struct?: AppfabricIngestionDestinationProcessingConfigurationAuditLog | cdktn.IResolvable): any;
export declare class AppfabricIngestionDestinationProcessingConfigurationAuditLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricIngestionDestinationProcessingConfigurationAuditLog | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricIngestionDestinationProcessingConfigurationAuditLog | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
}
export interface AppfabricIngestionDestinationProcessingConfiguration {
    /**
    * Contains information about an audit log processing configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#audit_log AppfabricIngestionDestination#audit_log}
    */
    readonly auditLog: AppfabricIngestionDestinationProcessingConfigurationAuditLog;
}
export declare function appfabricIngestionDestinationProcessingConfigurationToTerraform(struct?: AppfabricIngestionDestinationProcessingConfiguration | cdktn.IResolvable): any;
export declare function appfabricIngestionDestinationProcessingConfigurationToHclTerraform(struct?: AppfabricIngestionDestinationProcessingConfiguration | cdktn.IResolvable): any;
export declare class AppfabricIngestionDestinationProcessingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricIngestionDestinationProcessingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricIngestionDestinationProcessingConfiguration | cdktn.IResolvable | undefined);
    private _auditLog;
    get auditLog(): AppfabricIngestionDestinationProcessingConfigurationAuditLogOutputReference;
    putAuditLog(value: AppfabricIngestionDestinationProcessingConfigurationAuditLog): void;
    get auditLogInput(): cdktn.IResolvable | AppfabricIngestionDestinationProcessingConfigurationAuditLog | undefined;
}
export interface AppfabricIngestionDestinationTags {
    /**
    * Tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#key AppfabricIngestionDestination#key}
    */
    readonly key?: string;
    /**
    * Tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#value AppfabricIngestionDestination#value}
    */
    readonly value?: string;
}
export declare function appfabricIngestionDestinationTagsToTerraform(struct?: AppfabricIngestionDestinationTags | cdktn.IResolvable): any;
export declare function appfabricIngestionDestinationTagsToHclTerraform(struct?: AppfabricIngestionDestinationTags | cdktn.IResolvable): any;
export declare class AppfabricIngestionDestinationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppfabricIngestionDestinationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricIngestionDestinationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppfabricIngestionDestinationTagsList extends cdktn.ComplexList {
    internalValue?: AppfabricIngestionDestinationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppfabricIngestionDestinationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination awscc_appfabric_ingestion_destination}
*/
export declare class AppfabricIngestionDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appfabric_ingestion_destination";
    /**
    * Generates CDKTN code for importing a AppfabricIngestionDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppfabricIngestionDestination to import
    * @param importFromId The id of the existing AppfabricIngestionDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppfabricIngestionDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/appfabric_ingestion_destination awscc_appfabric_ingestion_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppfabricIngestionDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AppfabricIngestionDestinationConfig);
    private _appBundleArn?;
    get appBundleArn(): string;
    set appBundleArn(value: string);
    get appBundleArnInput(): string | undefined;
    get arn(): string;
    get createdAt(): string;
    private _destinationConfiguration;
    get destinationConfiguration(): AppfabricIngestionDestinationDestinationConfigurationOutputReference;
    putDestinationConfiguration(value: AppfabricIngestionDestinationDestinationConfiguration): void;
    get destinationConfigurationInput(): cdktn.IResolvable | AppfabricIngestionDestinationDestinationConfiguration | undefined;
    get id(): string;
    private _ingestionArn?;
    get ingestionArn(): string;
    set ingestionArn(value: string);
    get ingestionArnInput(): string | undefined;
    private _processingConfiguration;
    get processingConfiguration(): AppfabricIngestionDestinationProcessingConfigurationOutputReference;
    putProcessingConfiguration(value: AppfabricIngestionDestinationProcessingConfiguration): void;
    get processingConfigurationInput(): cdktn.IResolvable | AppfabricIngestionDestinationProcessingConfiguration | undefined;
    get status(): string;
    private _tags;
    get tags(): AppfabricIngestionDestinationTagsList;
    putTags(value: AppfabricIngestionDestinationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppfabricIngestionDestinationTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
