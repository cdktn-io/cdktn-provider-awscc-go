/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApsAnomalyDetectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AnomalyDetector alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#alias ApsAnomalyDetector#alias}
    */
    readonly alias: string;
    /**
    * Determines the anomaly detector's algorithm and its configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#configuration ApsAnomalyDetector#configuration}
    */
    readonly configuration: ApsAnomalyDetectorConfiguration;
    /**
    * The AnomalyDetector period of detection and metric generation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#evaluation_interval_in_seconds ApsAnomalyDetector#evaluation_interval_in_seconds}
    */
    readonly evaluationIntervalInSeconds?: number;
    /**
    * An array of key-value pairs to provide meta-data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#labels ApsAnomalyDetector#labels}
    */
    readonly labels?: ApsAnomalyDetectorLabels[] | cdktn.IResolvable;
    /**
    * The action to perform when running the expression returns no data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#missing_data_action ApsAnomalyDetector#missing_data_action}
    */
    readonly missingDataAction?: ApsAnomalyDetectorMissingDataAction;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#tags ApsAnomalyDetector#tags}
    */
    readonly tags?: ApsAnomalyDetectorTags[] | cdktn.IResolvable;
    /**
    * Required to identify a specific APS Workspace associated with this Anomaly Detector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#workspace ApsAnomalyDetector#workspace}
    */
    readonly workspace: string;
}
export interface ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAbove {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#amount ApsAnomalyDetector#amount}
    */
    readonly amount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#ratio ApsAnomalyDetector#ratio}
    */
    readonly ratio?: number;
}
export declare function apsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAboveToTerraform(struct?: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAbove | cdktn.IResolvable): any;
export declare function apsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAboveToHclTerraform(struct?: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAbove | cdktn.IResolvable): any;
export declare class ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAboveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAbove | cdktn.IResolvable | undefined;
    set internalValue(value: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAbove | cdktn.IResolvable | undefined);
    private _amount?;
    get amount(): number;
    set amount(value: number);
    resetAmount(): void;
    get amountInput(): number | undefined;
    private _ratio?;
    get ratio(): number;
    set ratio(value: number);
    resetRatio(): void;
    get ratioInput(): number | undefined;
}
export interface ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#amount ApsAnomalyDetector#amount}
    */
    readonly amount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#ratio ApsAnomalyDetector#ratio}
    */
    readonly ratio?: number;
}
export declare function apsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelowToTerraform(struct?: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelow | cdktn.IResolvable): any;
export declare function apsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelowToHclTerraform(struct?: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelow | cdktn.IResolvable): any;
export declare class ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelow | cdktn.IResolvable | undefined;
    set internalValue(value: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelow | cdktn.IResolvable | undefined);
    private _amount?;
    get amount(): number;
    set amount(value: number);
    resetAmount(): void;
    get amountInput(): number | undefined;
    private _ratio?;
    get ratio(): number;
    set ratio(value: number);
    resetRatio(): void;
    get ratioInput(): number | undefined;
}
export interface ApsAnomalyDetectorConfigurationRandomCutForest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#ignore_near_expected_from_above ApsAnomalyDetector#ignore_near_expected_from_above}
    */
    readonly ignoreNearExpectedFromAbove?: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAbove;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#ignore_near_expected_from_below ApsAnomalyDetector#ignore_near_expected_from_below}
    */
    readonly ignoreNearExpectedFromBelow?: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#query ApsAnomalyDetector#query}
    */
    readonly query: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#sample_size ApsAnomalyDetector#sample_size}
    */
    readonly sampleSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#shingle_size ApsAnomalyDetector#shingle_size}
    */
    readonly shingleSize?: number;
}
export declare function apsAnomalyDetectorConfigurationRandomCutForestToTerraform(struct?: ApsAnomalyDetectorConfigurationRandomCutForest | cdktn.IResolvable): any;
export declare function apsAnomalyDetectorConfigurationRandomCutForestToHclTerraform(struct?: ApsAnomalyDetectorConfigurationRandomCutForest | cdktn.IResolvable): any;
export declare class ApsAnomalyDetectorConfigurationRandomCutForestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsAnomalyDetectorConfigurationRandomCutForest | cdktn.IResolvable | undefined;
    set internalValue(value: ApsAnomalyDetectorConfigurationRandomCutForest | cdktn.IResolvable | undefined);
    private _ignoreNearExpectedFromAbove;
    get ignoreNearExpectedFromAbove(): ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAboveOutputReference;
    putIgnoreNearExpectedFromAbove(value: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAbove): void;
    resetIgnoreNearExpectedFromAbove(): void;
    get ignoreNearExpectedFromAboveInput(): cdktn.IResolvable | ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromAbove | undefined;
    private _ignoreNearExpectedFromBelow;
    get ignoreNearExpectedFromBelow(): ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelowOutputReference;
    putIgnoreNearExpectedFromBelow(value: ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelow): void;
    resetIgnoreNearExpectedFromBelow(): void;
    get ignoreNearExpectedFromBelowInput(): cdktn.IResolvable | ApsAnomalyDetectorConfigurationRandomCutForestIgnoreNearExpectedFromBelow | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _sampleSize?;
    get sampleSize(): number;
    set sampleSize(value: number);
    resetSampleSize(): void;
    get sampleSizeInput(): number | undefined;
    private _shingleSize?;
    get shingleSize(): number;
    set shingleSize(value: number);
    resetShingleSize(): void;
    get shingleSizeInput(): number | undefined;
}
export interface ApsAnomalyDetectorConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#random_cut_forest ApsAnomalyDetector#random_cut_forest}
    */
    readonly randomCutForest: ApsAnomalyDetectorConfigurationRandomCutForest;
}
export declare function apsAnomalyDetectorConfigurationToTerraform(struct?: ApsAnomalyDetectorConfiguration | cdktn.IResolvable): any;
export declare function apsAnomalyDetectorConfigurationToHclTerraform(struct?: ApsAnomalyDetectorConfiguration | cdktn.IResolvable): any;
export declare class ApsAnomalyDetectorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsAnomalyDetectorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsAnomalyDetectorConfiguration | cdktn.IResolvable | undefined);
    private _randomCutForest;
    get randomCutForest(): ApsAnomalyDetectorConfigurationRandomCutForestOutputReference;
    putRandomCutForest(value: ApsAnomalyDetectorConfigurationRandomCutForest): void;
    get randomCutForestInput(): cdktn.IResolvable | ApsAnomalyDetectorConfigurationRandomCutForest | undefined;
}
export interface ApsAnomalyDetectorLabels {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#key ApsAnomalyDetector#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#value ApsAnomalyDetector#value}
    */
    readonly value?: string;
}
export declare function apsAnomalyDetectorLabelsToTerraform(struct?: ApsAnomalyDetectorLabels | cdktn.IResolvable): any;
export declare function apsAnomalyDetectorLabelsToHclTerraform(struct?: ApsAnomalyDetectorLabels | cdktn.IResolvable): any;
export declare class ApsAnomalyDetectorLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsAnomalyDetectorLabels | cdktn.IResolvable | undefined;
    set internalValue(value: ApsAnomalyDetectorLabels | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApsAnomalyDetectorLabelsList extends cdktn.ComplexList {
    internalValue?: ApsAnomalyDetectorLabels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsAnomalyDetectorLabelsOutputReference;
}
export interface ApsAnomalyDetectorMissingDataAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#mark_as_anomaly ApsAnomalyDetector#mark_as_anomaly}
    */
    readonly markAsAnomaly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#skip ApsAnomalyDetector#skip}
    */
    readonly skip?: boolean | cdktn.IResolvable;
}
export declare function apsAnomalyDetectorMissingDataActionToTerraform(struct?: ApsAnomalyDetectorMissingDataAction | cdktn.IResolvable): any;
export declare function apsAnomalyDetectorMissingDataActionToHclTerraform(struct?: ApsAnomalyDetectorMissingDataAction | cdktn.IResolvable): any;
export declare class ApsAnomalyDetectorMissingDataActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsAnomalyDetectorMissingDataAction | cdktn.IResolvable | undefined;
    set internalValue(value: ApsAnomalyDetectorMissingDataAction | cdktn.IResolvable | undefined);
    private _markAsAnomaly?;
    get markAsAnomaly(): boolean | cdktn.IResolvable;
    set markAsAnomaly(value: boolean | cdktn.IResolvable);
    resetMarkAsAnomaly(): void;
    get markAsAnomalyInput(): boolean | cdktn.IResolvable | undefined;
    private _skip?;
    get skip(): boolean | cdktn.IResolvable;
    set skip(value: boolean | cdktn.IResolvable);
    resetSkip(): void;
    get skipInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApsAnomalyDetectorTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#key ApsAnomalyDetector#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#value ApsAnomalyDetector#value}
    */
    readonly value?: string;
}
export declare function apsAnomalyDetectorTagsToTerraform(struct?: ApsAnomalyDetectorTags | cdktn.IResolvable): any;
export declare function apsAnomalyDetectorTagsToHclTerraform(struct?: ApsAnomalyDetectorTags | cdktn.IResolvable): any;
export declare class ApsAnomalyDetectorTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsAnomalyDetectorTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApsAnomalyDetectorTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApsAnomalyDetectorTagsList extends cdktn.ComplexList {
    internalValue?: ApsAnomalyDetectorTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsAnomalyDetectorTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector awscc_aps_anomaly_detector}
*/
export declare class ApsAnomalyDetector extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_aps_anomaly_detector";
    /**
    * Generates CDKTN code for importing a ApsAnomalyDetector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApsAnomalyDetector to import
    * @param importFromId The id of the existing ApsAnomalyDetector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApsAnomalyDetector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/aps_anomaly_detector awscc_aps_anomaly_detector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApsAnomalyDetectorConfig
    */
    constructor(scope: Construct, id: string, config: ApsAnomalyDetectorConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    get aliasInput(): string | undefined;
    get arn(): string;
    private _configuration;
    get configuration(): ApsAnomalyDetectorConfigurationOutputReference;
    putConfiguration(value: ApsAnomalyDetectorConfiguration): void;
    get configurationInput(): cdktn.IResolvable | ApsAnomalyDetectorConfiguration | undefined;
    private _evaluationIntervalInSeconds?;
    get evaluationIntervalInSeconds(): number;
    set evaluationIntervalInSeconds(value: number);
    resetEvaluationIntervalInSeconds(): void;
    get evaluationIntervalInSecondsInput(): number | undefined;
    get id(): string;
    private _labels;
    get labels(): ApsAnomalyDetectorLabelsList;
    putLabels(value: ApsAnomalyDetectorLabels[] | cdktn.IResolvable): void;
    resetLabels(): void;
    get labelsInput(): cdktn.IResolvable | ApsAnomalyDetectorLabels[] | undefined;
    private _missingDataAction;
    get missingDataAction(): ApsAnomalyDetectorMissingDataActionOutputReference;
    putMissingDataAction(value: ApsAnomalyDetectorMissingDataAction): void;
    resetMissingDataAction(): void;
    get missingDataActionInput(): cdktn.IResolvable | ApsAnomalyDetectorMissingDataAction | undefined;
    private _tags;
    get tags(): ApsAnomalyDetectorTagsList;
    putTags(value: ApsAnomalyDetectorTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApsAnomalyDetectorTags[] | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
