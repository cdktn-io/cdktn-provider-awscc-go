/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AmplifyWebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique ID for an Amplify app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook#app_id AmplifyWebhook#app_id}
    */
    readonly appId?: string;
    /**
    * The name for a branch that is part of an Amplify app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook#branch_name AmplifyWebhook#branch_name}
    */
    readonly branchName: string;
    /**
    * The description for a webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook#description AmplifyWebhook#description}
    */
    readonly description?: string;
    /**
    * Tags for the webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook#tags AmplifyWebhook#tags}
    */
    readonly tags?: AmplifyWebhookTags[] | cdktn.IResolvable;
}
export interface AmplifyWebhookTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook#key AmplifyWebhook#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook#value AmplifyWebhook#value}
    */
    readonly value?: string;
}
export declare function amplifyWebhookTagsToTerraform(struct?: AmplifyWebhookTags | cdktn.IResolvable): any;
export declare function amplifyWebhookTagsToHclTerraform(struct?: AmplifyWebhookTags | cdktn.IResolvable): any;
export declare class AmplifyWebhookTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmplifyWebhookTags | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyWebhookTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AmplifyWebhookTagsList extends cdktn.ComplexList {
    internalValue?: AmplifyWebhookTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmplifyWebhookTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook awscc_amplify_webhook}
*/
export declare class AmplifyWebhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_amplify_webhook";
    /**
    * Generates CDKTN code for importing a AmplifyWebhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AmplifyWebhook to import
    * @param importFromId The id of the existing AmplifyWebhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AmplifyWebhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/amplify_webhook awscc_amplify_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AmplifyWebhookConfig
    */
    constructor(scope: Construct, id: string, config: AmplifyWebhookConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    resetAppId(): void;
    get appIdInput(): string | undefined;
    get arn(): string;
    private _branchName?;
    get branchName(): string;
    set branchName(value: string);
    get branchNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _tags;
    get tags(): AmplifyWebhookTagsList;
    putTags(value: AmplifyWebhookTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AmplifyWebhookTags[] | undefined;
    get webhookId(): string;
    get webhookUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
