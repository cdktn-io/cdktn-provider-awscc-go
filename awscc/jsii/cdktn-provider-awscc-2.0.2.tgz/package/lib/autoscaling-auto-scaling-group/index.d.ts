/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AutoscalingAutoScalingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Auto Scaling group. This name must be unique per Region per account.
    *  The name can contain any ASCII character 33 to 126 including most punctuation characters, digits, and upper and lowercased letters.
    *   You cannot use a colon (:) in the name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#auto_scaling_group_name AutoscalingAutoScalingGroup#auto_scaling_group_name}
    */
    readonly autoScalingGroupName?: string;
    /**
    * The EC2 instance capacity distribution across Availability Zones for the Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#availability_zone_distribution AutoscalingAutoScalingGroup#availability_zone_distribution}
    */
    readonly availabilityZoneDistribution?: AutoscalingAutoScalingGroupAvailabilityZoneDistribution;
    /**
    * The Availability Zone IDs where the Auto Scaling group can launch instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#availability_zone_ids AutoscalingAutoScalingGroup#availability_zone_ids}
    */
    readonly availabilityZoneIds?: string[];
    /**
    * The Availability Zone impairment policy for the Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#availability_zone_impairment_policy AutoscalingAutoScalingGroup#availability_zone_impairment_policy}
    */
    readonly availabilityZoneImpairmentPolicy?: AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicy;
    /**
    * A list of Availability Zones where instances in the Auto Scaling group can be created. Used for launching into the default VPC subnet in each Availability Zone when not using the ``VPCZoneIdentifier`` property, or for attaching a network interface when an existing network interface ID is specified in a launch template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#availability_zones AutoscalingAutoScalingGroup#availability_zones}
    */
    readonly availabilityZones?: string[];
    /**
    * Indicates whether Capacity Rebalancing is enabled. Otherwise, Capacity Rebalancing is disabled. When you turn on Capacity Rebalancing, Amazon EC2 Auto Scaling attempts to launch a Spot Instance whenever Amazon EC2 notifies that a Spot Instance is at an elevated risk of interruption. After launching a new instance, it then terminates an old instance. For more information, see [Use Capacity Rebalancing to handle Amazon EC2 Spot Interruptions](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-capacity-rebalancing.html) in the in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#capacity_rebalance AutoscalingAutoScalingGroup#capacity_rebalance}
    */
    readonly capacityRebalance?: boolean | cdktn.IResolvable;
    /**
    * The capacity reservation specification for the Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#capacity_reservation_specification AutoscalingAutoScalingGroup#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: AutoscalingAutoScalingGroupCapacityReservationSpecification;
    /**
    * Reserved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#context AutoscalingAutoScalingGroup#context}
    */
    readonly context?: string;
    /**
    * *Only needed if you use simple scaling policies.*
    *  The amount of time, in seconds, between one scaling activity ending and another one starting due to simple scaling policies. For more information, see [Scaling cooldowns for Amazon EC2 Auto Scaling](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-scaling-cooldowns.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  Default: ``300`` seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#cooldown AutoscalingAutoScalingGroup#cooldown}
    */
    readonly cooldown?: string;
    /**
    * The amount of time, in seconds, until a new instance is considered to have finished initializing and resource consumption to become stable after it enters the ``InService`` state.
    *  During an instance refresh, Amazon EC2 Auto Scaling waits for the warm-up period after it replaces an instance before it moves on to replacing the next instance. Amazon EC2 Auto Scaling also waits for the warm-up period before aggregating the metrics for new instances with existing instances in the Amazon CloudWatch metrics that are used for scaling, resulting in more reliable usage data. For more information, see [Set the default instance warmup for an Auto Scaling group](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-default-instance-warmup.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *   To manage various warm-up settings at the group level, we recommend that you set the default instance warmup, *even if it is set to 0 seconds*. To remove a value that you previously set, include the property but specify ``-1`` for the value. However, we strongly recommend keeping the default instance warmup enabled by specifying a value of ``0`` or other nominal value.
    *   Default: None
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#default_instance_warmup AutoscalingAutoScalingGroup#default_instance_warmup}
    */
    readonly defaultInstanceWarmup?: number;
    /**
    * The deletion protection setting for the Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#deletion_protection AutoscalingAutoScalingGroup#deletion_protection}
    */
    readonly deletionProtection?: string;
    /**
    * The desired capacity is the initial capacity of the Auto Scaling group at the time of its creation and the capacity it attempts to maintain. It can scale beyond this capacity if you configure automatic scaling.
    *  The number must be greater than or equal to the minimum size of the group and less than or equal to the maximum size of the group. If you do not specify a desired capacity when creating the stack, the default is the minimum size of the group.
    *  CloudFormation marks the Auto Scaling group as successful (by setting its status to CREATE_COMPLETE) when the desired capacity is reached. However, if a maximum Spot price is set in the launch template or launch configuration that you specified, then desired capacity is not used as a criteria for success. Whether your request is fulfilled depends on Spot Instance capacity and your maximum price.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#desired_capacity AutoscalingAutoScalingGroup#desired_capacity}
    */
    readonly desiredCapacity?: string;
    /**
    * The unit of measurement for the value specified for desired capacity. Amazon EC2 Auto Scaling supports ``DesiredCapacityType`` for attribute-based instance type selection only. For more information, see [Create a mixed instances group using attribute-based instance type selection](https://docs.aws.amazon.com/autoscaling/ec2/userguide/create-mixed-instances-group-attribute-based-instance-type-selection.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  By default, Amazon EC2 Auto Scaling specifies ``units``, which translates into number of instances.
    *  Valid values: ``units`` | ``vcpu`` | ``memory-mib``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#desired_capacity_type AutoscalingAutoScalingGroup#desired_capacity_type}
    */
    readonly desiredCapacityType?: string;
    /**
    * The amount of time, in seconds, that Amazon EC2 Auto Scaling waits before checking the health status of an EC2 instance that has come into service and marking it unhealthy due to a failed health check. This is useful if your instances do not immediately pass their health checks after they enter the ``InService`` state. For more information, see [Set the health check grace period for an Auto Scaling group](https://docs.aws.amazon.com/autoscaling/ec2/userguide/health-check-grace-period.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  Default: ``0`` seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#health_check_grace_period AutoscalingAutoScalingGroup#health_check_grace_period}
    */
    readonly healthCheckGracePeriod?: number;
    /**
    * A comma-separated value string of one or more health check types.
    *  The valid values are ``EC2``, ``EBS``, ``ELB``, and ``VPC_LATTICE``. ``EC2`` is the default health check and cannot be disabled. For more information, see [Health checks for instances in an Auto Scaling group](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-health-checks.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  Only specify ``EC2`` if you must clear a value that was previously set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#health_check_type AutoscalingAutoScalingGroup#health_check_type}
    */
    readonly healthCheckType?: string;
    /**
    * The ID of the instance used to base the launch configuration on. For more information, see [Create an Auto Scaling group using an EC2 instance](https://docs.aws.amazon.com/autoscaling/ec2/userguide/create-asg-from-instance.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  If you specify ``LaunchTemplate``, ``MixedInstancesPolicy``, or ``LaunchConfigurationName``, don't specify ``InstanceId``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#instance_id AutoscalingAutoScalingGroup#instance_id}
    */
    readonly instanceId?: string;
    /**
    * The instance lifecycle policy for the Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#instance_lifecycle_policy AutoscalingAutoScalingGroup#instance_lifecycle_policy}
    */
    readonly instanceLifecyclePolicy?: AutoscalingAutoScalingGroupInstanceLifecyclePolicy;
    /**
    * An instance maintenance policy. For more information, see [Set instance maintenance policy](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-instance-maintenance-policy.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#instance_maintenance_policy AutoscalingAutoScalingGroup#instance_maintenance_policy}
    */
    readonly instanceMaintenancePolicy?: AutoscalingAutoScalingGroupInstanceMaintenancePolicy;
    /**
    * The name of the launch configuration to use to launch instances.
    *  Required only if you don't specify ``LaunchTemplate``, ``MixedInstancesPolicy``, or ``InstanceId``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_configuration_name AutoscalingAutoScalingGroup#launch_configuration_name}
    */
    readonly launchConfigurationName?: string;
    /**
    * Information used to specify the launch template and version to use to launch instances. You can alternatively associate a launch template to the Auto Scaling group by specifying a ``MixedInstancesPolicy``. For more information about creating launch templates, see [Create a launch template for an Auto Scaling group](https://docs.aws.amazon.com/autoscaling/ec2/userguide/create-launch-template.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  If you omit this property, you must specify ``MixedInstancesPolicy``, ``LaunchConfigurationName``, or ``InstanceId``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template AutoscalingAutoScalingGroup#launch_template}
    */
    readonly launchTemplate?: AutoscalingAutoScalingGroupLaunchTemplate;
    /**
    * One or more lifecycle hooks to add to the Auto Scaling group before instances are launched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#lifecycle_hook_specification_list AutoscalingAutoScalingGroup#lifecycle_hook_specification_list}
    */
    readonly lifecycleHookSpecificationList?: AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct[] | cdktn.IResolvable;
    /**
    * A list of Classic Load Balancers associated with this Auto Scaling group. For Application Load Balancers, Network Load Balancers, and Gateway Load Balancers, specify the ``TargetGroupARNs`` property instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#load_balancer_names AutoscalingAutoScalingGroup#load_balancer_names}
    */
    readonly loadBalancerNames?: string[];
    /**
    * The maximum amount of time, in seconds, that an instance can be in service. The default is null. If specified, the value must be either 0 or a number equal to or greater than 86,400 seconds (1 day). For more information, see [Replace Auto Scaling instances based on maximum instance lifetime](https://docs.aws.amazon.com/autoscaling/ec2/userguide/asg-max-instance-lifetime.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max_instance_lifetime AutoscalingAutoScalingGroup#max_instance_lifetime}
    */
    readonly maxInstanceLifetime?: number;
    /**
    * The maximum size of the group.
    *   With a mixed instances policy that uses instance weighting, Amazon EC2 Auto Scaling may need to go above ``MaxSize`` to meet your capacity requirements. In this event, Amazon EC2 Auto Scaling will never go above ``MaxSize`` by more than your largest instance weight (weights that define how many units each instance contributes to the desired capacity of the group).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max_size AutoscalingAutoScalingGroup#max_size}
    */
    readonly maxSize: string;
    /**
    * Enables the monitoring of group metrics of an Auto Scaling group. By default, these metrics are disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#metrics_collection AutoscalingAutoScalingGroup#metrics_collection}
    */
    readonly metricsCollection?: AutoscalingAutoScalingGroupMetricsCollection[] | cdktn.IResolvable;
    /**
    * The minimum size of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min_size AutoscalingAutoScalingGroup#min_size}
    */
    readonly minSize: string;
    /**
    * An embedded object that specifies a mixed instances policy.
    *  The policy includes properties that not only define the distribution of On-Demand Instances and Spot Instances, the maximum price to pay for Spot Instances (optional), and how the Auto Scaling group allocates instance types to fulfill On-Demand and Spot capacities, but also the properties that specify the instance configuration information—the launch template and instance types. The policy can also include a weight for each instance type and different launch templates for individual instance types.
    *  For more information, see [Auto Scaling groups with multiple instance types and purchase options](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-mixed-instances-groups.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#mixed_instances_policy AutoscalingAutoScalingGroup#mixed_instances_policy}
    */
    readonly mixedInstancesPolicy?: AutoscalingAutoScalingGroupMixedInstancesPolicy;
    /**
    * Indicates whether newly launched instances are protected from termination by Amazon EC2 Auto Scaling when scaling in. For more information about preventing instances from terminating on scale in, see [Use instance scale-in protection](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-instance-protection.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#new_instances_protected_from_scale_in AutoscalingAutoScalingGroup#new_instances_protected_from_scale_in}
    */
    readonly newInstancesProtectedFromScaleIn?: boolean | cdktn.IResolvable;
    /**
    * A structure that specifies an Amazon SNS notification configuration for the ``NotificationConfigurations`` property of the [AWS::AutoScaling::AutoScalingGroup](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-autoscaling-autoscalinggroup.html) resource.
    *  For an example template snippet, see [Configure Amazon EC2 Auto Scaling resources](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/quickref-ec2-auto-scaling.html).
    *  For more information, see [Get Amazon SNS notifications when your Auto Scaling group scales](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ASGettingNotifications.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#notification_configuration AutoscalingAutoScalingGroup#notification_configuration}
    */
    readonly notificationConfiguration?: AutoscalingAutoScalingGroupNotificationConfiguration;
    /**
    * Configures an Auto Scaling group to send notifications when specified events take place.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#notification_configurations AutoscalingAutoScalingGroup#notification_configurations}
    */
    readonly notificationConfigurations?: AutoscalingAutoScalingGroupNotificationConfigurations[] | cdktn.IResolvable;
    /**
    * The name of the placement group into which to launch your instances. For more information, see [Placement groups](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/placement-groups.html) in the *Amazon EC2 User Guide*.
    *   A *cluster* placement group is a logical grouping of instances within a single Availability Zone. You cannot specify multiple Availability Zones and a cluster placement group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#placement_group AutoscalingAutoScalingGroup#placement_group}
    */
    readonly placementGroup?: string;
    /**
    * The Amazon Resource Name (ARN) of the service-linked role that the Auto Scaling group uses to call other AWS service on your behalf. By default, Amazon EC2 Auto Scaling uses a service-linked role named ``AWSServiceRoleForAutoScaling``, which it creates if it does not exist. For more information, see [Service-linked roles](https://docs.aws.amazon.com/autoscaling/ec2/userguide/autoscaling-service-linked-role.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#service_linked_role_arn AutoscalingAutoScalingGroup#service_linked_role_arn}
    */
    readonly serviceLinkedRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#skip_zonal_shift_validation AutoscalingAutoScalingGroup#skip_zonal_shift_validation}
    */
    readonly skipZonalShiftValidation?: boolean | cdktn.IResolvable;
    /**
    * One or more tags. You can tag your Auto Scaling group and propagate the tags to the Amazon EC2 instances it launches. Tags are not propagated to Amazon EBS volumes. To add tags to Amazon EBS volumes, specify the tags in a launch template but use caution. If the launch template specifies an instance tag with a key that is also specified for the Auto Scaling group, Amazon EC2 Auto Scaling overrides the value of that instance tag with the value specified by the Auto Scaling group. For more information, see [Tag Auto Scaling groups and instances](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-tagging.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#tags AutoscalingAutoScalingGroup#tags}
    */
    readonly tags?: AutoscalingAutoScalingGroupTags[] | cdktn.IResolvable;
    /**
    * The Amazon Resource Names (ARN) of the Elastic Load Balancing target groups to associate with the Auto Scaling group. Instances are registered as targets with the target groups. The target groups receive incoming traffic and route requests to one or more registered targets. For more information, see [Use Elastic Load Balancing to distribute traffic across the instances in your Auto Scaling group](https://docs.aws.amazon.com/autoscaling/ec2/userguide/autoscaling-load-balancer.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#target_group_ar_ns AutoscalingAutoScalingGroup#target_group_ar_ns}
    */
    readonly targetGroupArNs?: string[];
    /**
    * A policy or a list of policies that are used to select the instance to terminate. These policies are executed in the order that you list them. For more information, see [Configure termination policies for Amazon EC2 Auto Scaling](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-termination-policies.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  Valid values: ``Default`` | ``AllocationStrategy`` | ``ClosestToNextInstanceHour`` | ``NewestInstance`` | ``OldestInstance`` | ``OldestLaunchConfiguration`` | ``OldestLaunchTemplate`` | ``arn:aws:lambda:region:account-id:function:my-function:my-alias``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#termination_policies AutoscalingAutoScalingGroup#termination_policies}
    */
    readonly terminationPolicies?: string[];
    /**
    * The traffic sources associated with this Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#traffic_sources AutoscalingAutoScalingGroup#traffic_sources}
    */
    readonly trafficSources?: AutoscalingAutoScalingGroupTrafficSources[] | cdktn.IResolvable;
    /**
    * A list of subnet IDs for a virtual private cloud (VPC) where instances in the Auto Scaling group can be created.
    *  If this resource specifies public subnets and is also in a VPC that is defined in the same stack template, you must use the [DependsOn attribute](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-dependson.html) to declare a dependency on the [VPC-gateway attachment](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-vpc-gateway-attachment.html).
    *   When you update ``VPCZoneIdentifier``, this retains the same Auto Scaling group and replaces old instances with new ones, according to the specified subnets. To control how CloudFormation replaces the instances, add an [UpdatePolicy attribute](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-updatepolicy.html) to your stack. Set the update policy to ``AutoScalingInstanceRefresh``. For more information, see the [AutoScalingInstanceRefresh policy](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-updatepolicy.html#cfn-attributes-updatepolicy-instancerefresh).
    *   Required to launch instances into a nondefault VPC. If you specify ``VPCZoneIdentifier`` with ``AvailabilityZones``, the subnets that you specify for this property must reside in those Availability Zones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#vpc_zone_identifier AutoscalingAutoScalingGroup#vpc_zone_identifier}
    */
    readonly vpcZoneIdentifier?: string[];
}
export interface AutoscalingAutoScalingGroupAvailabilityZoneDistribution {
    /**
    * If launches fail in an Availability Zone, the following strategies are available. The default is ``balanced-best-effort``.
    *   +  ``balanced-only`` - If launches fail in an Availability Zone, Auto Scaling will continue to attempt to launch in the unhealthy zone to preserve a balanced distribution.
    *   +  ``balanced-best-effort`` - If launches fail in an Availability Zone, Auto Scaling will attempt to launch in another healthy Availability Zone instead.
    *   +  ``reservations-then-balanced`` - Auto Scaling will first attempt to launch into your Capacity Reservations, and then balance any remaining capacity across healthy Availability Zones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#capacity_distribution_strategy AutoscalingAutoScalingGroup#capacity_distribution_strategy}
    */
    readonly capacityDistributionStrategy?: string;
}
export declare function autoscalingAutoScalingGroupAvailabilityZoneDistributionToTerraform(struct?: AutoscalingAutoScalingGroupAvailabilityZoneDistribution | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupAvailabilityZoneDistributionToHclTerraform(struct?: AutoscalingAutoScalingGroupAvailabilityZoneDistribution | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupAvailabilityZoneDistributionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupAvailabilityZoneDistribution | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupAvailabilityZoneDistribution | cdktn.IResolvable | undefined);
    private _capacityDistributionStrategy?;
    get capacityDistributionStrategy(): string;
    set capacityDistributionStrategy(value: string);
    resetCapacityDistributionStrategy(): void;
    get capacityDistributionStrategyInput(): string | undefined;
}
export interface AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicy {
    /**
    * Specifies the health check behavior for the impaired Availability Zone in an active zonal shift. If you select ``Replace unhealthy``, instances that appear unhealthy will be replaced in all Availability Zones. If you select ``Ignore unhealthy``, instances will not be replaced in the Availability Zone with the active zonal shift. For more information, see [Auto Scaling group zonal shift](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-zonal-shift.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#impaired_zone_health_check_behavior AutoscalingAutoScalingGroup#impaired_zone_health_check_behavior}
    */
    readonly impairedZoneHealthCheckBehavior?: string;
    /**
    * If ``true``, enable zonal shift for your Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#zonal_shift_enabled AutoscalingAutoScalingGroup#zonal_shift_enabled}
    */
    readonly zonalShiftEnabled?: boolean | cdktn.IResolvable;
}
export declare function autoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicyToTerraform(struct?: AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicy | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicyToHclTerraform(struct?: AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicy | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicy | cdktn.IResolvable | undefined);
    private _impairedZoneHealthCheckBehavior?;
    get impairedZoneHealthCheckBehavior(): string;
    set impairedZoneHealthCheckBehavior(value: string);
    resetImpairedZoneHealthCheckBehavior(): void;
    get impairedZoneHealthCheckBehaviorInput(): string | undefined;
    private _zonalShiftEnabled?;
    get zonalShiftEnabled(): boolean | cdktn.IResolvable;
    set zonalShiftEnabled(value: boolean | cdktn.IResolvable);
    resetZonalShiftEnabled(): void;
    get zonalShiftEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTarget {
    /**
    * The Capacity Reservation IDs to launch instances into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#capacity_reservation_ids AutoscalingAutoScalingGroup#capacity_reservation_ids}
    */
    readonly capacityReservationIds?: string[];
    /**
    * The resource group ARNs of the Capacity Reservation to launch instances into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#capacity_reservation_resource_group_arns AutoscalingAutoScalingGroup#capacity_reservation_resource_group_arns}
    */
    readonly capacityReservationResourceGroupArns?: string[];
}
export declare function autoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTargetToTerraform(struct?: AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTarget | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTargetToHclTerraform(struct?: AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTarget | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTarget | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTarget | cdktn.IResolvable | undefined);
    private _capacityReservationIds?;
    get capacityReservationIds(): string[];
    set capacityReservationIds(value: string[]);
    resetCapacityReservationIds(): void;
    get capacityReservationIdsInput(): string[] | undefined;
    private _capacityReservationResourceGroupArns?;
    get capacityReservationResourceGroupArns(): string[];
    set capacityReservationResourceGroupArns(value: string[]);
    resetCapacityReservationResourceGroupArns(): void;
    get capacityReservationResourceGroupArnsInput(): string[] | undefined;
}
export interface AutoscalingAutoScalingGroupCapacityReservationSpecification {
    /**
    * The capacity reservation preference. The following options are available:
    *   +  ``capacity-reservations-only`` - Auto Scaling will only launch instances into a Capacity Reservation or Capacity Reservation resource group. If capacity isn't available, instances will fail to launch.
    *   +  ``capacity-reservations-first`` - Auto Scaling will try to launch instances into a Capacity Reservation or Capacity Reservation resource group first. If capacity isn't available, instances will run in On-Demand capacity.
    *   +  ``none`` - Auto Scaling will not launch instances into a Capacity Reservation. Instances will run in On-Demand capacity.
    *   +  ``default`` - Auto Scaling uses the Capacity Reservation preference from your launch template or an open Capacity Reservation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#capacity_reservation_preference AutoscalingAutoScalingGroup#capacity_reservation_preference}
    */
    readonly capacityReservationPreference?: string;
    /**
    * Describes a target Capacity Reservation or Capacity Reservation resource group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#capacity_reservation_target AutoscalingAutoScalingGroup#capacity_reservation_target}
    */
    readonly capacityReservationTarget?: AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTarget;
}
export declare function autoscalingAutoScalingGroupCapacityReservationSpecificationToTerraform(struct?: AutoscalingAutoScalingGroupCapacityReservationSpecification | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupCapacityReservationSpecificationToHclTerraform(struct?: AutoscalingAutoScalingGroupCapacityReservationSpecification | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupCapacityReservationSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupCapacityReservationSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupCapacityReservationSpecification | cdktn.IResolvable | undefined);
    private _capacityReservationPreference?;
    get capacityReservationPreference(): string;
    set capacityReservationPreference(value: string);
    resetCapacityReservationPreference(): void;
    get capacityReservationPreferenceInput(): string | undefined;
    private _capacityReservationTarget;
    get capacityReservationTarget(): AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTargetOutputReference;
    putCapacityReservationTarget(value: AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTarget): void;
    resetCapacityReservationTarget(): void;
    get capacityReservationTargetInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupCapacityReservationSpecificationCapacityReservationTarget | undefined;
}
export interface AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggers {
    /**
    * Specifies the action when a termination lifecycle hook is abandoned due to failure, timeout, or explicit abandonment (calling CompleteLifecycleAction).
    *   Set to ``retain`` to move instances to a retained state. Set to ``terminate`` for default termination behavior.
    *   Retained instances don't count toward desired capacity and remain until you call ``TerminateInstanceInAutoScalingGroup``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#terminate_hook_abandon AutoscalingAutoScalingGroup#terminate_hook_abandon}
    */
    readonly terminateHookAbandon?: string;
}
export declare function autoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggersToTerraform(struct?: AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggers | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggersToHclTerraform(struct?: AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggers | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggers | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggers | cdktn.IResolvable | undefined);
    private _terminateHookAbandon?;
    get terminateHookAbandon(): string;
    set terminateHookAbandon(value: string);
    resetTerminateHookAbandon(): void;
    get terminateHookAbandonInput(): string | undefined;
}
export interface AutoscalingAutoScalingGroupInstanceLifecyclePolicy {
    /**
    * Specifies the conditions that trigger instance retention behavior. These triggers determine when instances should move to a ``Retained`` state instead of automatic termination. This allows you to maintain control over instance management when lifecycles transition and operations fail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#retention_triggers AutoscalingAutoScalingGroup#retention_triggers}
    */
    readonly retentionTriggers?: AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggers;
}
export declare function autoscalingAutoScalingGroupInstanceLifecyclePolicyToTerraform(struct?: AutoscalingAutoScalingGroupInstanceLifecyclePolicy | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupInstanceLifecyclePolicyToHclTerraform(struct?: AutoscalingAutoScalingGroupInstanceLifecyclePolicy | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupInstanceLifecyclePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupInstanceLifecyclePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupInstanceLifecyclePolicy | cdktn.IResolvable | undefined);
    private _retentionTriggers;
    get retentionTriggers(): AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggersOutputReference;
    putRetentionTriggers(value: AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggers): void;
    resetRetentionTriggers(): void;
    get retentionTriggersInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupInstanceLifecyclePolicyRetentionTriggers | undefined;
}
export interface AutoscalingAutoScalingGroupInstanceMaintenancePolicy {
    /**
    * Specifies the upper threshold as a percentage of the desired capacity of the Auto Scaling group. It represents the maximum percentage of the group that can be in service and healthy, or pending, to support your workload when replacing instances. Value range is 100 to 200. To clear a previously set value, specify a value of ``-1``.
    *  Both ``MinHealthyPercentage`` and ``MaxHealthyPercentage`` must be specified, and the difference between them cannot be greater than 100. A large range increases the number of instances that can be replaced at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max_healthy_percentage AutoscalingAutoScalingGroup#max_healthy_percentage}
    */
    readonly maxHealthyPercentage?: number;
    /**
    * Specifies the lower threshold as a percentage of the desired capacity of the Auto Scaling group. It represents the minimum percentage of the group to keep in service, healthy, and ready to use to support your workload when replacing instances. Value range is 0 to 100. To clear a previously set value, specify a value of ``-1``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min_healthy_percentage AutoscalingAutoScalingGroup#min_healthy_percentage}
    */
    readonly minHealthyPercentage?: number;
}
export declare function autoscalingAutoScalingGroupInstanceMaintenancePolicyToTerraform(struct?: AutoscalingAutoScalingGroupInstanceMaintenancePolicy | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupInstanceMaintenancePolicyToHclTerraform(struct?: AutoscalingAutoScalingGroupInstanceMaintenancePolicy | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupInstanceMaintenancePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupInstanceMaintenancePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupInstanceMaintenancePolicy | cdktn.IResolvable | undefined);
    private _maxHealthyPercentage?;
    get maxHealthyPercentage(): number;
    set maxHealthyPercentage(value: number);
    resetMaxHealthyPercentage(): void;
    get maxHealthyPercentageInput(): number | undefined;
    private _minHealthyPercentage?;
    get minHealthyPercentage(): number;
    set minHealthyPercentage(value: number);
    resetMinHealthyPercentage(): void;
    get minHealthyPercentageInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupLaunchTemplate {
    /**
    * The ID of the launch template.
    *  You must specify the ``LaunchTemplateID`` or the ``LaunchTemplateName``, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template_id AutoscalingAutoScalingGroup#launch_template_id}
    */
    readonly launchTemplateId?: string;
    /**
    * The name of the launch template.
    *  You must specify the ``LaunchTemplateName`` or the ``LaunchTemplateID``, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template_name AutoscalingAutoScalingGroup#launch_template_name}
    */
    readonly launchTemplateName?: string;
    /**
    * The version number of the launch template.
    *  Specifying ``$Latest`` or ``$Default`` for the template version number is not supported. However, you can specify ``LatestVersionNumber`` or ``DefaultVersionNumber`` using the ``Fn::GetAtt`` intrinsic function. For more information, see [Fn::GetAtt](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/intrinsic-function-reference-getatt.html).
    *   For an example of using the ``Fn::GetAtt`` function, see the [Examples](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-autoscaling-autoscalinggroup.html#aws-resource-autoscaling-autoscalinggroup--examples) section of the ``AWS::AutoScaling::AutoScalingGroup`` resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#version AutoscalingAutoScalingGroup#version}
    */
    readonly version?: string;
}
export declare function autoscalingAutoScalingGroupLaunchTemplateToTerraform(struct?: AutoscalingAutoScalingGroupLaunchTemplate | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupLaunchTemplateToHclTerraform(struct?: AutoscalingAutoScalingGroupLaunchTemplate | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupLaunchTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupLaunchTemplate | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupLaunchTemplate | cdktn.IResolvable | undefined);
    private _launchTemplateId?;
    get launchTemplateId(): string;
    set launchTemplateId(value: string);
    resetLaunchTemplateId(): void;
    get launchTemplateIdInput(): string | undefined;
    private _launchTemplateName?;
    get launchTemplateName(): string;
    set launchTemplateName(value: string);
    resetLaunchTemplateName(): void;
    get launchTemplateNameInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct {
    /**
    * The action the Auto Scaling group takes when the lifecycle hook timeout elapses or if an unexpected failure occurs. The default value is ``ABANDON``.
    *  Valid values: ``CONTINUE`` | ``ABANDON``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#default_result AutoscalingAutoScalingGroup#default_result}
    */
    readonly defaultResult?: string;
    /**
    * The maximum time, in seconds, that can elapse before the lifecycle hook times out. The range is from ``30`` to ``7200`` seconds. The default value is ``3600`` seconds (1 hour).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#heartbeat_timeout AutoscalingAutoScalingGroup#heartbeat_timeout}
    */
    readonly heartbeatTimeout?: number;
    /**
    * The name of the lifecycle hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#lifecycle_hook_name AutoscalingAutoScalingGroup#lifecycle_hook_name}
    */
    readonly lifecycleHookName?: string;
    /**
    * The lifecycle transition. For Auto Scaling groups, there are two major lifecycle transitions.
    *   +  To create a lifecycle hook for scale-out events, specify ``autoscaling:EC2_INSTANCE_LAUNCHING``.
    *   +  To create a lifecycle hook for scale-in events, specify ``autoscaling:EC2_INSTANCE_TERMINATING``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#lifecycle_transition AutoscalingAutoScalingGroup#lifecycle_transition}
    */
    readonly lifecycleTransition?: string;
    /**
    * Additional information that you want to include any time Amazon EC2 Auto Scaling sends a message to the notification target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#notification_metadata AutoscalingAutoScalingGroup#notification_metadata}
    */
    readonly notificationMetadata?: string;
    /**
    * The Amazon Resource Name (ARN) of the notification target that Amazon EC2 Auto Scaling sends notifications to when an instance is in a wait state for the lifecycle hook. You can specify an Amazon SNS topic or an Amazon SQS queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#notification_target_arn AutoscalingAutoScalingGroup#notification_target_arn}
    */
    readonly notificationTargetArn?: string;
    /**
    * The ARN of the IAM role that allows the Auto Scaling group to publish to the specified notification target. For information about creating this role, see [Prepare to add a lifecycle hook to your Auto Scaling group](https://docs.aws.amazon.com/autoscaling/ec2/userguide/prepare-for-lifecycle-notifications.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  Valid only if the notification target is an Amazon SNS topic or an Amazon SQS queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#role_arn AutoscalingAutoScalingGroup#role_arn}
    */
    readonly roleArn?: string;
}
export declare function autoscalingAutoScalingGroupLifecycleHookSpecificationListStructToTerraform(struct?: AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupLifecycleHookSpecificationListStructToHclTerraform(struct?: AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupLifecycleHookSpecificationListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct | cdktn.IResolvable | undefined);
    private _defaultResult?;
    get defaultResult(): string;
    set defaultResult(value: string);
    resetDefaultResult(): void;
    get defaultResultInput(): string | undefined;
    private _heartbeatTimeout?;
    get heartbeatTimeout(): number;
    set heartbeatTimeout(value: number);
    resetHeartbeatTimeout(): void;
    get heartbeatTimeoutInput(): number | undefined;
    private _lifecycleHookName?;
    get lifecycleHookName(): string;
    set lifecycleHookName(value: string);
    resetLifecycleHookName(): void;
    get lifecycleHookNameInput(): string | undefined;
    private _lifecycleTransition?;
    get lifecycleTransition(): string;
    set lifecycleTransition(value: string);
    resetLifecycleTransition(): void;
    get lifecycleTransitionInput(): string | undefined;
    private _notificationMetadata?;
    get notificationMetadata(): string;
    set notificationMetadata(value: string);
    resetNotificationMetadata(): void;
    get notificationMetadataInput(): string | undefined;
    private _notificationTargetArn?;
    get notificationTargetArn(): string;
    set notificationTargetArn(value: string);
    resetNotificationTargetArn(): void;
    get notificationTargetArnInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
}
export declare class AutoscalingAutoScalingGroupLifecycleHookSpecificationListStructList extends cdktn.ComplexList {
    internalValue?: AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingAutoScalingGroupLifecycleHookSpecificationListStructOutputReference;
}
export interface AutoscalingAutoScalingGroupMetricsCollection {
    /**
    * The frequency at which Amazon EC2 Auto Scaling sends aggregated data to CloudWatch. The only valid value is ``1Minute``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#granularity AutoscalingAutoScalingGroup#granularity}
    */
    readonly granularity?: string;
    /**
    * Identifies the metrics to enable.
    *  You can specify one or more of the following metrics:
    *   +   ``GroupMinSize``
    *   +   ``GroupMaxSize``
    *   +   ``GroupDesiredCapacity``
    *   +   ``GroupInServiceInstances``
    *   +   ``GroupPendingInstances``
    *   +   ``GroupStandbyInstances``
    *   +   ``GroupTerminatingInstances``
    *   +   ``GroupTotalInstances``
    *   +   ``GroupInServiceCapacity``
    *   +   ``GroupPendingCapacity``
    *   +   ``GroupStandbyCapacity``
    *   +   ``GroupTerminatingCapacity``
    *   +   ``GroupTotalCapacity``
    *   +   ``WarmPoolDesiredCapacity``
    *   +   ``WarmPoolWarmedCapacity``
    *   +   ``WarmPoolPendingCapacity``
    *   +   ``WarmPoolTerminatingCapacity``
    *   +   ``WarmPoolTotalCapacity``
    *   +   ``GroupAndWarmPoolDesiredCapacity``
    *   +   ``GroupAndWarmPoolTotalCapacity``
    *
    *  If you specify ``Granularity`` and don't specify any metrics, all metrics are enabled.
    *  For more information, see [Amazon CloudWatch metrics for Amazon EC2 Auto Scaling](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-metrics.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#metrics AutoscalingAutoScalingGroup#metrics}
    */
    readonly metrics?: string[];
}
export declare function autoscalingAutoScalingGroupMetricsCollectionToTerraform(struct?: AutoscalingAutoScalingGroupMetricsCollection | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMetricsCollectionToHclTerraform(struct?: AutoscalingAutoScalingGroupMetricsCollection | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMetricsCollectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingAutoScalingGroupMetricsCollection | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMetricsCollection | cdktn.IResolvable | undefined);
    private _granularity?;
    get granularity(): string;
    set granularity(value: string);
    resetGranularity(): void;
    get granularityInput(): string | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
}
export declare class AutoscalingAutoScalingGroupMetricsCollectionList extends cdktn.ComplexList {
    internalValue?: AutoscalingAutoScalingGroupMetricsCollection[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingAutoScalingGroupMetricsCollectionOutputReference;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments {
    /**
    * The capacity types to prioritize, in order. Amazon EC2 Auto Scaling attempts to launch instances in the priority order of the capacity types, and within each capacity type, in the order of instance types listed in your launch template ``Overrides``.
    *  The following lists the valid values:
    *   + on-demand-capacity-reservation On-Demand Capacity Reservations. + capacity-block Capacity Blocks. + interruptible-capacity-reservation Interruptible Capacity Reservations. + on-demand On-Demand capacity. Include this value to allow the group to fall back to On-Demand capacity when the preceding capacity types are unavailable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#target_capacity_types AutoscalingAutoScalingGroup#target_capacity_types}
    */
    readonly targetCapacityTypes?: string[];
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegmentsToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegmentsToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments | cdktn.IResolvable | undefined);
    private _targetCapacityTypes?;
    get targetCapacityTypes(): string[];
    set targetCapacityTypes(value: string[]);
    resetTargetCapacityTypes(): void;
    get targetCapacityTypesInput(): string[] | undefined;
}
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegmentsList extends cdktn.ComplexList {
    internalValue?: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegmentsOutputReference;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistribution {
    /**
    * The Distribution Segments configuration. Each segment contains an ordered list of capacity types to prioritize.
    *  For more information, see [Use Distribution Segments to target multiple capacity types](https://docs.aws.amazon.com/autoscaling/ec2/userguide/use-distribution-segments.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#distribution_segments AutoscalingAutoScalingGroup#distribution_segments}
    */
    readonly distributionSegments?: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments[] | cdktn.IResolvable;
    /**
    * The allocation strategy to apply to your On-Demand Instances when they are launched. Possible instance types are determined by the launch template overrides that you specify.
    *  The following lists the valid values:
    *   + lowest-price Uses price to determine which instance types are the highest priority, launching the lowest priced instance types within an Availability Zone first. This is the default value for Auto Scaling groups that specify InstanceRequirements. + prioritized You set the order of instance types for the launch template overrides from highest to lowest priority (from first to last in the list). Amazon EC2 Auto Scaling launches your highest priority instance types first. If all your On-Demand capacity cannot be fulfilled using your highest priority instance type, then Amazon EC2 Auto Scaling launches the remaining capacity using the second priority instance type, and so on. This is the default value for Auto Scaling groups that don't specify InstanceRequirements and cannot be used for groups that do.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#on_demand_allocation_strategy AutoscalingAutoScalingGroup#on_demand_allocation_strategy}
    */
    readonly onDemandAllocationStrategy?: string;
    /**
    * The minimum amount of the Auto Scaling group's capacity that must be fulfilled by On-Demand Instances. This base portion is launched first as your group scales.
    *  This number has the same unit of measurement as the group's desired capacity. If you change the default unit of measurement (number of instances) by specifying weighted capacity values in your launch template overrides list, or by changing the default desired capacity type setting of the group, you must specify this number using the same unit of measurement.
    *  Default: 0
    *   An update to this setting means a gradual replacement of instances to adjust the current On-Demand Instance levels. When replacing instances, Amazon EC2 Auto Scaling launches new instances before terminating the previous ones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#on_demand_base_capacity AutoscalingAutoScalingGroup#on_demand_base_capacity}
    */
    readonly onDemandBaseCapacity?: number;
    /**
    * Controls the percentages of On-Demand Instances and Spot Instances for your additional capacity beyond ``OnDemandBaseCapacity``. Expressed as a number (for example, 20 specifies 20% On-Demand Instances, 80% Spot Instances). If set to 100, only On-Demand Instances are used.
    *  Default: 100
    *   An update to this setting means a gradual replacement of instances to adjust the current On-Demand and Spot Instance levels for your additional capacity higher than the base capacity. When replacing instances, Amazon EC2 Auto Scaling launches new instances before terminating the previous ones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#on_demand_percentage_above_base_capacity AutoscalingAutoScalingGroup#on_demand_percentage_above_base_capacity}
    */
    readonly onDemandPercentageAboveBaseCapacity?: number;
    /**
    * The allocation strategy to apply to your Spot Instances when they are launched. Possible instance types are determined by the launch template overrides that you specify.
    *  The following lists the valid values:
    *   + capacity-optimized Requests Spot Instances using pools that are optimally chosen based on the available Spot capacity. This strategy has the lowest risk of interruption. To give certain instance types a higher chance of launching first, use capacity-optimized-prioritized. + capacity-optimized-prioritized You set the order of instance types for the launch template overrides from highest to lowest priority (from first to last in the list). Amazon EC2 Auto Scaling honors the instance type priorities on a best effort basis but optimizes for capacity first. Note that if the On-Demand allocation strategy is set to prioritized, the same priority is applied when fulfilling On-Demand capacity. This is not a valid value for Auto Scaling groups that specify InstanceRequirements. + lowest-price Requests Spot Instances using the lowest priced pools within an Availability Zone, across the number of Spot pools that you specify for the SpotInstancePools property. To ensure that your desired capacity is met, you might receive Spot Instances from several pools. This is the default value, but it might lead to high interruption rates because this strategy only considers instance price and not available capacity. + price-capacity-optimized (recommended) The price and capacity optimized allocation strategy looks at both price and capacity to select the Spot Instance pools that are the least likely to be interrupted and have the lowest possible price.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#spot_allocation_strategy AutoscalingAutoScalingGroup#spot_allocation_strategy}
    */
    readonly spotAllocationStrategy?: string;
    /**
    * The number of Spot Instance pools across which to allocate your Spot Instances. The Spot pools are determined from the different instance types in the overrides. Valid only when the ``SpotAllocationStrategy`` is ``lowest-price``. Value must be in the range of 1–20.
    *  Default: 2
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#spot_instance_pools AutoscalingAutoScalingGroup#spot_instance_pools}
    */
    readonly spotInstancePools?: number;
    /**
    * The maximum price per unit hour that you are willing to pay for a Spot Instance. If your maximum price is lower than the Spot price for the instance types that you selected, your Spot Instances are not launched. We do not recommend specifying a maximum price because it can lead to increased interruptions. When Spot Instances launch, you pay the current Spot price. To remove a maximum price that you previously set, include the property but specify an empty string ("") for the value.
    *   If you specify a maximum price, your instances will be interrupted more frequently than if you do not specify one.
    *   Valid Range: Minimum value of 0.001
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#spot_max_price AutoscalingAutoScalingGroup#spot_max_price}
    */
    readonly spotMaxPrice?: string;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistribution | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistribution | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistribution | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistribution | cdktn.IResolvable | undefined);
    private _distributionSegments;
    get distributionSegments(): AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegmentsList;
    putDistributionSegments(value: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments[] | cdktn.IResolvable): void;
    resetDistributionSegments(): void;
    get distributionSegmentsInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDistributionSegments[] | undefined;
    private _onDemandAllocationStrategy?;
    get onDemandAllocationStrategy(): string;
    set onDemandAllocationStrategy(value: string);
    resetOnDemandAllocationStrategy(): void;
    get onDemandAllocationStrategyInput(): string | undefined;
    private _onDemandBaseCapacity?;
    get onDemandBaseCapacity(): number;
    set onDemandBaseCapacity(value: number);
    resetOnDemandBaseCapacity(): void;
    get onDemandBaseCapacityInput(): number | undefined;
    private _onDemandPercentageAboveBaseCapacity?;
    get onDemandPercentageAboveBaseCapacity(): number;
    set onDemandPercentageAboveBaseCapacity(value: number);
    resetOnDemandPercentageAboveBaseCapacity(): void;
    get onDemandPercentageAboveBaseCapacityInput(): number | undefined;
    private _spotAllocationStrategy?;
    get spotAllocationStrategy(): string;
    set spotAllocationStrategy(value: string);
    resetSpotAllocationStrategy(): void;
    get spotAllocationStrategyInput(): string | undefined;
    private _spotInstancePools?;
    get spotInstancePools(): number;
    set spotInstancePools(value: number);
    resetSpotInstancePools(): void;
    get spotInstancePoolsInput(): number | undefined;
    private _spotMaxPrice?;
    get spotMaxPrice(): string;
    set spotMaxPrice(value: string);
    resetSpotMaxPrice(): void;
    get spotMaxPriceInput(): string | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification {
    /**
    * The ID of the launch template.
    *  You must specify the ``LaunchTemplateID`` or the ``LaunchTemplateName``, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template_id AutoscalingAutoScalingGroup#launch_template_id}
    */
    readonly launchTemplateId?: string;
    /**
    * The name of the launch template.
    *  You must specify the ``LaunchTemplateName`` or the ``LaunchTemplateID``, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template_name AutoscalingAutoScalingGroup#launch_template_name}
    */
    readonly launchTemplateName?: string;
    /**
    * The version number of the launch template.
    *  Specifying ``$Latest`` or ``$Default`` for the template version number is not supported. However, you can specify ``LatestVersionNumber`` or ``DefaultVersionNumber`` using the ``Fn::GetAtt`` intrinsic function. For more information, see [Fn::GetAtt](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/intrinsic-function-reference-getatt.html).
    *   For an example of using the ``Fn::GetAtt`` function, see the [Examples](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-autoscaling-autoscalinggroup.html#aws-resource-autoscaling-autoscalinggroup--examples) section of the ``AWS::AutoScaling::AutoScalingGroup`` resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#version AutoscalingAutoScalingGroup#version}
    */
    readonly version?: string;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification | cdktn.IResolvable | undefined);
    private _launchTemplateId?;
    get launchTemplateId(): string;
    set launchTemplateId(value: string);
    resetLaunchTemplateId(): void;
    get launchTemplateIdInput(): string | undefined;
    private _launchTemplateName?;
    get launchTemplateName(): string;
    set launchTemplateName(value: string);
    resetLaunchTemplateName(): void;
    get launchTemplateNameInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCount {
    /**
    * The maximum value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The minimum value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCountToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCount | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCountToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCount | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCount | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCount | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiB {
    /**
    * The memory maximum in MiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The memory minimum in MiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiBToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiB | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiBToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiB | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiBOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiB | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiB | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbps {
    /**
    * The maximum value in Mbps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The minimum value in Mbps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbpsToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbps | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbpsToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbps | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbps | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbps | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences {
    /**
    * The instance family to use as a baseline reference.
    *   Make sure that you specify the correct value for the instance family. The instance family is everything before the period (.) in the instance type name. For example, in the instance ``c6i.large``, the instance family is ``c6i``, not ``c6``. For more information, see [Amazon EC2 instance type naming conventions](https://docs.aws.amazon.com/ec2/latest/instancetypes/instance-type-names.html) in *Amazon EC2 Instance Types*.
    *   The following instance types are *not supported* for performance protection.
    *   +   ``c1``
    *   +   ``g3| g3s``
    *   +   ``hpc7g``
    *   +   ``m1| m2``
    *   +   ``mac1 | mac2 | mac2-m1ultra | mac2-m2 | mac2-m2pro``
    *   +   ``p3dn | p4d | p5``
    *   +   ``t1``
    *   +   ``u-12tb1 | u-18tb1 | u-24tb1 | u-3tb1 | u-6tb1 | u-9tb1 | u7i-12tb | u7in-16tb | u7in-24tb | u7in-32tb``
    *
    *  If you performance protection by specifying a supported instance family, the returned instance types will exclude the preceding unsupported instance families.
    *  If you specify an unsupported instance family as a value for baseline performance, the API returns an empty response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#instance_family AutoscalingAutoScalingGroup#instance_family}
    */
    readonly instanceFamily?: string;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferencesToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferencesToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences | cdktn.IResolvable | undefined);
    private _instanceFamily?;
    get instanceFamily(): string;
    set instanceFamily(value: string);
    resetInstanceFamily(): void;
    get instanceFamilyInput(): string | undefined;
}
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferencesList extends cdktn.ComplexList {
    internalValue?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferencesOutputReference;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpu {
    /**
    * Specify an instance family to use as the baseline reference for CPU performance. All instance types that match your specified attributes will be compared against the CPU performance of the referenced instance family, regardless of CPU manufacturer or architecture differences.
    *   Currently only one instance family can be specified in the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#references AutoscalingAutoScalingGroup#references}
    */
    readonly references?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences[] | cdktn.IResolvable;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpu | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpu | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpu | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpu | cdktn.IResolvable | undefined);
    private _references;
    get references(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferencesList;
    putReferences(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences[] | cdktn.IResolvable): void;
    resetReferences(): void;
    get referencesInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuReferences[] | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactors {
    /**
    * The CPU performance to consider, using an instance family as the baseline reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#cpu AutoscalingAutoScalingGroup#cpu}
    */
    readonly cpu?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpu;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactors | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactors | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactors | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactors | cdktn.IResolvable | undefined);
    private _cpu;
    get cpu(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpuOutputReference;
    putCpu(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpu): void;
    resetCpu(): void;
    get cpuInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsCpu | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpu {
    /**
    * The memory maximum in GiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The memory minimum in GiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpuToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpu | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpuToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpu | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpu | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpu | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiB {
    /**
    * The memory maximum in MiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The memory minimum in MiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiBToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiB | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiBToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiB | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiBOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiB | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiB | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbps {
    /**
    * The maximum amount of network bandwidth, in gigabits per second (Gbps).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The minimum amount of network bandwidth, in gigabits per second (Gbps).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbpsToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbps | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbpsToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbps | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbps | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbps | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCount {
    /**
    * The maximum number of network interfaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The minimum number of network interfaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCountToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCount | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCountToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCount | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCount | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCount | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGb {
    /**
    * The storage maximum in GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The storage minimum in GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGbToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGb | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGbToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGb | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGb | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGb | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCount {
    /**
    * The maximum number of vCPUs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max AutoscalingAutoScalingGroup#max}
    */
    readonly max?: number;
    /**
    * The minimum number of vCPUs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#min AutoscalingAutoScalingGroup#min}
    */
    readonly min?: number;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCountToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCount | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCountToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCount | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCount | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCount | cdktn.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    resetMax(): void;
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    resetMin(): void;
    get minInput(): number | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirements {
    /**
    * The minimum and maximum number of accelerators (GPUs, FPGAs, or AWS Inferentia chips) for an instance type.
    *  To exclude accelerator-enabled instance types, set ``Max`` to ``0``.
    *  Default: No minimum or maximum limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#accelerator_count AutoscalingAutoScalingGroup#accelerator_count}
    */
    readonly acceleratorCount?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCount;
    /**
    * Indicates whether instance types must have accelerators by specific manufacturers.
    *   +  For instance types with NVIDIA devices, specify ``nvidia``.
    *   +  For instance types with AMD devices, specify ``amd``.
    *   +  For instance types with AWS devices, specify ``amazon-web-services``.
    *   +  For instance types with Xilinx devices, specify ``xilinx``.
    *
    *  Default: Any manufacturer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#accelerator_manufacturers AutoscalingAutoScalingGroup#accelerator_manufacturers}
    */
    readonly acceleratorManufacturers?: string[];
    /**
    * Lists the accelerators that must be on an instance type.
    *   +  For instance types with NVIDIA A100 GPUs, specify ``a100``.
    *   +  For instance types with NVIDIA V100 GPUs, specify ``v100``.
    *   +  For instance types with NVIDIA K80 GPUs, specify ``k80``.
    *   +  For instance types with NVIDIA T4 GPUs, specify ``t4``.
    *   +  For instance types with NVIDIA M60 GPUs, specify ``m60``.
    *   +  For instance types with AMD Radeon Pro V520 GPUs, specify ``radeon-pro-v520``.
    *   +  For instance types with Xilinx VU9P FPGAs, specify ``vu9p``.
    *
    *  Default: Any accelerator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#accelerator_names AutoscalingAutoScalingGroup#accelerator_names}
    */
    readonly acceleratorNames?: string[];
    /**
    * The minimum and maximum total memory size for the accelerators on an instance type, in MiB.
    *  Default: No minimum or maximum limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#accelerator_total_memory_mi_b AutoscalingAutoScalingGroup#accelerator_total_memory_mi_b}
    */
    readonly acceleratorTotalMemoryMiB?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiB;
    /**
    * Lists the accelerator types that must be on an instance type.
    *   +  For instance types with GPU accelerators, specify ``gpu``.
    *   +  For instance types with FPGA accelerators, specify ``fpga``.
    *   +  For instance types with inference accelerators, specify ``inference``.
    *
    *  Default: Any accelerator type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#accelerator_types AutoscalingAutoScalingGroup#accelerator_types}
    */
    readonly acceleratorTypes?: string[];
    /**
    * The instance types to apply your specified attributes against. All other instance types are ignored, even if they match your specified attributes.
    *  You can use strings with one or more wild cards, represented by an asterisk (``*``), to allow an instance type, size, or generation. The following are examples: ``m5.8xlarge``, ``c5*.*``, ``m5a.*``, ``r*``, ``*3*``.
    *  For example, if you specify ``c5*``, Amazon EC2 Auto Scaling will allow the entire C5 instance family, which includes all C5a and C5n instance types. If you specify ``m5a.*``, Amazon EC2 Auto Scaling will allow all the M5a instance types, but not the M5n instance types.
    *   If you specify ``AllowedInstanceTypes``, you can't specify ``ExcludedInstanceTypes``.
    *   Default: All instance types
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#allowed_instance_types AutoscalingAutoScalingGroup#allowed_instance_types}
    */
    readonly allowedInstanceTypes?: string[];
    /**
    * Indicates whether bare metal instance types are included, excluded, or required.
    *  Default: ``excluded``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#bare_metal AutoscalingAutoScalingGroup#bare_metal}
    */
    readonly bareMetal?: string;
    /**
    * The minimum and maximum baseline bandwidth performance for an instance type, in Mbps. For more information, see [Amazon EBS–optimized instances](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ebs-optimized.html) in the *Amazon EC2 User Guide*.
    *  Default: No minimum or maximum limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#baseline_ebs_bandwidth_mbps AutoscalingAutoScalingGroup#baseline_ebs_bandwidth_mbps}
    */
    readonly baselineEbsBandwidthMbps?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbps;
    /**
    * The baseline performance factors for the instance requirements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#baseline_performance_factors AutoscalingAutoScalingGroup#baseline_performance_factors}
    */
    readonly baselinePerformanceFactors?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactors;
    /**
    * Indicates whether burstable performance instance types are included, excluded, or required. For more information, see [Burstable performance instances](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/burstable-performance-instances.html) in the *Amazon EC2 User Guide*.
    *  Default: ``excluded``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#burstable_performance AutoscalingAutoScalingGroup#burstable_performance}
    */
    readonly burstablePerformance?: string;
    /**
    * Lists which specific CPU manufacturers to include.
    *   +  For instance types with Intel CPUs, specify ``intel``.
    *   +  For instance types with AMD CPUs, specify ``amd``.
    *   +  For instance types with AWS CPUs, specify ``amazon-web-services``.
    *   +  For instance types with Apple CPUs, specify ``apple``.
    *
    *   Don't confuse the CPU hardware manufacturer with the CPU hardware architecture. Instances will be launched with a compatible CPU architecture based on the Amazon Machine Image (AMI) that you specify in your launch template.
    *   Default: Any manufacturer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#cpu_manufacturers AutoscalingAutoScalingGroup#cpu_manufacturers}
    */
    readonly cpuManufacturers?: string[];
    /**
    * The instance types to exclude. You can use strings with one or more wild cards, represented by an asterisk (``*``), to exclude an instance family, type, size, or generation. The following are examples: ``m5.8xlarge``, ``c5*.*``, ``m5a.*``, ``r*``, ``*3*``.
    *  For example, if you specify ``c5*``, you are excluding the entire C5 instance family, which includes all C5a and C5n instance types. If you specify ``m5a.*``, Amazon EC2 Auto Scaling will exclude all the M5a instance types, but not the M5n instance types.
    *   If you specify ``ExcludedInstanceTypes``, you can't specify ``AllowedInstanceTypes``.
    *   Default: No excluded instance types
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#excluded_instance_types AutoscalingAutoScalingGroup#excluded_instance_types}
    */
    readonly excludedInstanceTypes?: string[];
    /**
    * Indicates whether current or previous generation instance types are included.
    *   +  For current generation instance types, specify ``current``. The current generation includes EC2 instance types currently recommended for use. This typically includes the latest two to three generations in each instance family. For more information, see [Instance types](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-types.html) in the *Amazon EC2 User Guide*.
    *   +  For previous generation instance types, specify ``previous``.
    *
    *  Default: Any current or previous generation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#instance_generations AutoscalingAutoScalingGroup#instance_generations}
    */
    readonly instanceGenerations?: string[];
    /**
    * Indicates whether instance types with instance store volumes are included, excluded, or required. For more information, see [Amazon EC2 instance store](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/InstanceStorage.html) in the *Amazon EC2 User Guide*.
    *  Default: ``included``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#local_storage AutoscalingAutoScalingGroup#local_storage}
    */
    readonly localStorage?: string;
    /**
    * Indicates the type of local storage that is required.
    *   +  For instance types with hard disk drive (HDD) storage, specify ``hdd``.
    *   +  For instance types with solid state drive (SSD) storage, specify ``ssd``.
    *
    *  Default: Any local storage type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#local_storage_types AutoscalingAutoScalingGroup#local_storage_types}
    */
    readonly localStorageTypes?: string[];
    /**
    * [Price protection] The price protection threshold for Spot Instances, as a percentage of an identified On-Demand price. The identified On-Demand price is the price of the lowest priced current generation C, M, or R instance type with your specified attributes. If no current generation C, M, or R instance type matches your attributes, then the identified price is from either the lowest priced current generation instance types or, failing that, the lowest priced previous generation instance types that match your attributes. When Amazon EC2 Auto Scaling selects instance types with your attributes, we will exclude instance types whose price exceeds your specified threshold.
    *  The parameter accepts an integer, which Amazon EC2 Auto Scaling interprets as a percentage.
    *  If you set ``DesiredCapacityType`` to ``vcpu`` or ``memory-mib``, the price protection threshold is based on the per-vCPU or per-memory price instead of the per instance price.
    *   Only one of ``SpotMaxPricePercentageOverLowestPrice`` or ``MaxSpotPriceAsPercentageOfOptimalOnDemandPrice`` can be specified. If you don't specify either, Amazon EC2 Auto Scaling will automatically apply optimal price protection to consistently select from a wide range of instance types. To indicate no price protection threshold for Spot Instances, meaning you want to consider all instance types that match your attributes, include one of these parameters and specify a high value, such as ``999999``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#max_spot_price_as_percentage_of_optimal_on_demand_price AutoscalingAutoScalingGroup#max_spot_price_as_percentage_of_optimal_on_demand_price}
    */
    readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
    /**
    * The minimum and maximum amount of memory per vCPU for an instance type, in GiB.
    *  Default: No minimum or maximum limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#memory_gi_b_per_v_cpu AutoscalingAutoScalingGroup#memory_gi_b_per_v_cpu}
    */
    readonly memoryGiBPerVCpu?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpu;
    /**
    * The minimum and maximum instance memory size for an instance type, in MiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#memory_mi_b AutoscalingAutoScalingGroup#memory_mi_b}
    */
    readonly memoryMiB?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiB;
    /**
    * The minimum and maximum amount of network bandwidth, in gigabits per second (Gbps).
    *  Default: No minimum or maximum limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#network_bandwidth_gbps AutoscalingAutoScalingGroup#network_bandwidth_gbps}
    */
    readonly networkBandwidthGbps?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbps;
    /**
    * The minimum and maximum number of network interfaces for an instance type.
    *  Default: No minimum or maximum limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#network_interface_count AutoscalingAutoScalingGroup#network_interface_count}
    */
    readonly networkInterfaceCount?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCount;
    /**
    * [Price protection] The price protection threshold for On-Demand Instances, as a percentage higher than an identified On-Demand price. The identified On-Demand price is the price of the lowest priced current generation C, M, or R instance type with your specified attributes. If no current generation C, M, or R instance type matches your attributes, then the identified price is from either the lowest priced current generation instance types or, failing that, the lowest priced previous generation instance types that match your attributes. When Amazon EC2 Auto Scaling selects instance types with your attributes, we will exclude instance types whose price exceeds your specified threshold.
    *  The parameter accepts an integer, which Amazon EC2 Auto Scaling interprets as a percentage.
    *  To turn off price protection, specify a high value, such as ``999999``.
    *  If you set ``DesiredCapacityType`` to ``vcpu`` or ``memory-mib``, the price protection threshold is applied based on the per-vCPU or per-memory price instead of the per instance price.
    *  Default: ``20``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#on_demand_max_price_percentage_over_lowest_price AutoscalingAutoScalingGroup#on_demand_max_price_percentage_over_lowest_price}
    */
    readonly onDemandMaxPricePercentageOverLowestPrice?: number;
    /**
    * Indicates whether instance types must provide On-Demand Instance hibernation support.
    *  Default: ``false``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#require_hibernate_support AutoscalingAutoScalingGroup#require_hibernate_support}
    */
    readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
    /**
    * [Price protection] The price protection threshold for Spot Instances, as a percentage higher than an identified Spot price. The identified Spot price is the price of the lowest priced current generation C, M, or R instance type with your specified attributes. If no current generation C, M, or R instance type matches your attributes, then the identified price is from either the lowest priced current generation instance types or, failing that, the lowest priced previous generation instance types that match your attributes. When Amazon EC2 Auto Scaling selects instance types with your attributes, we will exclude instance types whose price exceeds your specified threshold.
    *  The parameter accepts an integer, which Amazon EC2 Auto Scaling interprets as a percentage.
    *  If you set ``DesiredCapacityType`` to ``vcpu`` or ``memory-mib``, the price protection threshold is based on the per-vCPU or per-memory price instead of the per instance price.
    *   Only one of ``SpotMaxPricePercentageOverLowestPrice`` or ``MaxSpotPriceAsPercentageOfOptimalOnDemandPrice`` can be specified. If you don't specify either, Amazon EC2 Auto Scaling will automatically apply optimal price protection to consistently select from a wide range of instance types. To indicate no price protection threshold for Spot Instances, meaning you want to consider all instance types that match your attributes, include one of these parameters and specify a high value, such as ``999999``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#spot_max_price_percentage_over_lowest_price AutoscalingAutoScalingGroup#spot_max_price_percentage_over_lowest_price}
    */
    readonly spotMaxPricePercentageOverLowestPrice?: number;
    /**
    * The minimum and maximum total local storage size for an instance type, in GB.
    *  Default: No minimum or maximum limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#total_local_storage_gb AutoscalingAutoScalingGroup#total_local_storage_gb}
    */
    readonly totalLocalStorageGb?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGb;
    /**
    * The minimum and maximum number of vCPUs for an instance type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#v_cpu_count AutoscalingAutoScalingGroup#v_cpu_count}
    */
    readonly vCpuCount?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCount;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirements | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirements | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirements | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirements | cdktn.IResolvable | undefined);
    private _acceleratorCount;
    get acceleratorCount(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCountOutputReference;
    putAcceleratorCount(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCount): void;
    resetAcceleratorCount(): void;
    get acceleratorCountInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorCount | undefined;
    private _acceleratorManufacturers?;
    get acceleratorManufacturers(): string[];
    set acceleratorManufacturers(value: string[]);
    resetAcceleratorManufacturers(): void;
    get acceleratorManufacturersInput(): string[] | undefined;
    private _acceleratorNames?;
    get acceleratorNames(): string[];
    set acceleratorNames(value: string[]);
    resetAcceleratorNames(): void;
    get acceleratorNamesInput(): string[] | undefined;
    private _acceleratorTotalMemoryMiB;
    get acceleratorTotalMemoryMiB(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiBOutputReference;
    putAcceleratorTotalMemoryMiB(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiB): void;
    resetAcceleratorTotalMemoryMiB(): void;
    get acceleratorTotalMemoryMiBInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsAcceleratorTotalMemoryMiB | undefined;
    private _acceleratorTypes?;
    get acceleratorTypes(): string[];
    set acceleratorTypes(value: string[]);
    resetAcceleratorTypes(): void;
    get acceleratorTypesInput(): string[] | undefined;
    private _allowedInstanceTypes?;
    get allowedInstanceTypes(): string[];
    set allowedInstanceTypes(value: string[]);
    resetAllowedInstanceTypes(): void;
    get allowedInstanceTypesInput(): string[] | undefined;
    private _bareMetal?;
    get bareMetal(): string;
    set bareMetal(value: string);
    resetBareMetal(): void;
    get bareMetalInput(): string | undefined;
    private _baselineEbsBandwidthMbps;
    get baselineEbsBandwidthMbps(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbpsOutputReference;
    putBaselineEbsBandwidthMbps(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbps): void;
    resetBaselineEbsBandwidthMbps(): void;
    get baselineEbsBandwidthMbpsInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselineEbsBandwidthMbps | undefined;
    private _baselinePerformanceFactors;
    get baselinePerformanceFactors(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactorsOutputReference;
    putBaselinePerformanceFactors(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactors): void;
    resetBaselinePerformanceFactors(): void;
    get baselinePerformanceFactorsInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsBaselinePerformanceFactors | undefined;
    private _burstablePerformance?;
    get burstablePerformance(): string;
    set burstablePerformance(value: string);
    resetBurstablePerformance(): void;
    get burstablePerformanceInput(): string | undefined;
    private _cpuManufacturers?;
    get cpuManufacturers(): string[];
    set cpuManufacturers(value: string[]);
    resetCpuManufacturers(): void;
    get cpuManufacturersInput(): string[] | undefined;
    private _excludedInstanceTypes?;
    get excludedInstanceTypes(): string[];
    set excludedInstanceTypes(value: string[]);
    resetExcludedInstanceTypes(): void;
    get excludedInstanceTypesInput(): string[] | undefined;
    private _instanceGenerations?;
    get instanceGenerations(): string[];
    set instanceGenerations(value: string[]);
    resetInstanceGenerations(): void;
    get instanceGenerationsInput(): string[] | undefined;
    private _localStorage?;
    get localStorage(): string;
    set localStorage(value: string);
    resetLocalStorage(): void;
    get localStorageInput(): string | undefined;
    private _localStorageTypes?;
    get localStorageTypes(): string[];
    set localStorageTypes(value: string[]);
    resetLocalStorageTypes(): void;
    get localStorageTypesInput(): string[] | undefined;
    private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
    get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
    set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
    resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
    get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
    private _memoryGiBPerVCpu;
    get memoryGiBPerVCpu(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpuOutputReference;
    putMemoryGiBPerVCpu(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpu): void;
    resetMemoryGiBPerVCpu(): void;
    get memoryGiBPerVCpuInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryGiBPerVCpu | undefined;
    private _memoryMiB;
    get memoryMiB(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiBOutputReference;
    putMemoryMiB(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiB): void;
    resetMemoryMiB(): void;
    get memoryMiBInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsMemoryMiB | undefined;
    private _networkBandwidthGbps;
    get networkBandwidthGbps(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbpsOutputReference;
    putNetworkBandwidthGbps(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbps): void;
    resetNetworkBandwidthGbps(): void;
    get networkBandwidthGbpsInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkBandwidthGbps | undefined;
    private _networkInterfaceCount;
    get networkInterfaceCount(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCountOutputReference;
    putNetworkInterfaceCount(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCount): void;
    resetNetworkInterfaceCount(): void;
    get networkInterfaceCountInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsNetworkInterfaceCount | undefined;
    private _onDemandMaxPricePercentageOverLowestPrice?;
    get onDemandMaxPricePercentageOverLowestPrice(): number;
    set onDemandMaxPricePercentageOverLowestPrice(value: number);
    resetOnDemandMaxPricePercentageOverLowestPrice(): void;
    get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
    private _requireHibernateSupport?;
    get requireHibernateSupport(): boolean | cdktn.IResolvable;
    set requireHibernateSupport(value: boolean | cdktn.IResolvable);
    resetRequireHibernateSupport(): void;
    get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
    private _spotMaxPricePercentageOverLowestPrice?;
    get spotMaxPricePercentageOverLowestPrice(): number;
    set spotMaxPricePercentageOverLowestPrice(value: number);
    resetSpotMaxPricePercentageOverLowestPrice(): void;
    get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
    private _totalLocalStorageGb;
    get totalLocalStorageGb(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGbOutputReference;
    putTotalLocalStorageGb(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGb): void;
    resetTotalLocalStorageGb(): void;
    get totalLocalStorageGbInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsTotalLocalStorageGb | undefined;
    private _vCpuCount;
    get vCpuCount(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCountOutputReference;
    putVCpuCount(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCount): void;
    resetVCpuCount(): void;
    get vCpuCountInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsVCpuCount | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecification {
    /**
    * The ID of the launch template.
    *  You must specify the ``LaunchTemplateID`` or the ``LaunchTemplateName``, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template_id AutoscalingAutoScalingGroup#launch_template_id}
    */
    readonly launchTemplateId?: string;
    /**
    * The name of the launch template.
    *  You must specify the ``LaunchTemplateName`` or the ``LaunchTemplateID``, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template_name AutoscalingAutoScalingGroup#launch_template_name}
    */
    readonly launchTemplateName?: string;
    /**
    * The version number of the launch template.
    *  Specifying ``$Latest`` or ``$Default`` for the template version number is not supported. However, you can specify ``LatestVersionNumber`` or ``DefaultVersionNumber`` using the ``Fn::GetAtt`` intrinsic function. For more information, see [Fn::GetAtt](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/intrinsic-function-reference-getatt.html).
    *   For an example of using the ``Fn::GetAtt`` function, see the [Examples](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-autoscaling-autoscalinggroup.html#aws-resource-autoscaling-autoscalinggroup--examples) section of the ``AWS::AutoScaling::AutoScalingGroup`` resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#version AutoscalingAutoScalingGroup#version}
    */
    readonly version?: string;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecificationToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecification | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecificationToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecification | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecification | cdktn.IResolvable | undefined);
    private _launchTemplateId?;
    get launchTemplateId(): string;
    set launchTemplateId(value: string);
    resetLaunchTemplateId(): void;
    get launchTemplateIdInput(): string | undefined;
    private _launchTemplateName?;
    get launchTemplateName(): string;
    set launchTemplateName(value: string);
    resetLaunchTemplateName(): void;
    get launchTemplateNameInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides {
    /**
    * The ID of the Amazon Machine Image (AMI) to use for instances launched with this override. When using Instance Refresh with ``ReplaceRootVolume`` strategy, this specifies the AMI for root volume replacement operations.
    *   For ``ReplaceRootVolume`` operations:
    *   +  All overrides in the ``MixedInstancesPolicy`` must specify an ImageId
    *   +  The AMI must contain only a single root volume
    *   +  Root volume replacement doesn't support multi-volume AMIs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#image_id AutoscalingAutoScalingGroup#image_id}
    */
    readonly imageId?: string;
    /**
    * The instance requirements. Amazon EC2 Auto Scaling uses your specified requirements to identify instance types. Then, it uses your On-Demand and Spot allocation strategies to launch instances from these instance types.
    *  You can specify up to four separate sets of instance requirements per Auto Scaling group. This is useful for provisioning instances from different Amazon Machine Images (AMIs) in the same Auto Scaling group. To do this, create the AMIs and create a new launch template for each AMI. Then, create a compatible set of instance requirements for each launch template.
    *   If you specify ``InstanceRequirements``, you can't specify ``InstanceType``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#instance_requirements AutoscalingAutoScalingGroup#instance_requirements}
    */
    readonly instanceRequirements?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirements;
    /**
    * The instance type, such as ``m3.xlarge``. You must specify an instance type that is supported in your requested Region and Availability Zones. For more information, see [Instance types](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-types.html) in the *Amazon EC2 User Guide*.
    *  You can specify up to 40 instance types per Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#instance_type AutoscalingAutoScalingGroup#instance_type}
    */
    readonly instanceType?: string;
    /**
    * Provides a launch template for the specified instance type or set of instance requirements. For example, some instance types might require a launch template with a different AMI. If not provided, Amazon EC2 Auto Scaling uses the launch template that's specified in the ``LaunchTemplate`` definition. For more information, see [Specifying a different launch template for an instance type](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-mixed-instances-groups-launch-template-overrides.html) in the *Amazon EC2 Auto Scaling User Guide*.
    *  You can specify up to 20 launch templates per Auto Scaling group. The launch templates specified in the overrides and in the ``LaunchTemplate`` definition count towards this limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template_specification AutoscalingAutoScalingGroup#launch_template_specification}
    */
    readonly launchTemplateSpecification?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecification;
    /**
    * If you provide a list of instance types to use, you can specify the number of capacity units provided by each instance type in terms of virtual CPUs, memory, storage, throughput, or other relative performance characteristic. When a Spot or On-Demand Instance is launched, the capacity units count toward the desired capacity. Amazon EC2 Auto Scaling launches instances until the desired capacity is totally fulfilled, even if this results in an overage. For example, if there are two units remaining to fulfill capacity, and Amazon EC2 Auto Scaling can only launch an instance with a ``WeightedCapacity`` of five units, the instance is launched, and the desired capacity is exceeded by three units. For more information, see [Configure instance weighting for Amazon EC2 Auto Scaling](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-mixed-instances-groups-instance-weighting.html) in the *Amazon EC2 Auto Scaling User Guide*. Value must be in the range of 1-999.
    *  If you specify a value for ``WeightedCapacity`` for one instance type, you must specify a value for ``WeightedCapacity`` for all of them.
    *   Every Auto Scaling group has three size parameters (``DesiredCapacity``, ``MaxSize``, and ``MinSize``). Usually, you set these sizes based on a specific number of instances. However, if you configure a mixed instances policy that defines weights for the instance types, you must specify these sizes with the same units that you use for weighting instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#weighted_capacity AutoscalingAutoScalingGroup#weighted_capacity}
    */
    readonly weightedCapacity?: string;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides | cdktn.IResolvable | undefined);
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _instanceRequirements;
    get instanceRequirements(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirementsOutputReference;
    putInstanceRequirements(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirements): void;
    resetInstanceRequirements(): void;
    get instanceRequirementsInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesInstanceRequirements | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _launchTemplateSpecification;
    get launchTemplateSpecification(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecificationOutputReference;
    putLaunchTemplateSpecification(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecification): void;
    resetLaunchTemplateSpecification(): void;
    get launchTemplateSpecificationInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesLaunchTemplateSpecification | undefined;
    private _weightedCapacity?;
    get weightedCapacity(): string;
    set weightedCapacity(value: string);
    resetWeightedCapacity(): void;
    get weightedCapacityInput(): string | undefined;
}
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesList extends cdktn.ComplexList {
    internalValue?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesOutputReference;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplate {
    /**
    * The launch template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template_specification AutoscalingAutoScalingGroup#launch_template_specification}
    */
    readonly launchTemplateSpecification?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification;
    /**
    * Any properties that you specify override the same properties in the launch template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#overrides AutoscalingAutoScalingGroup#overrides}
    */
    readonly overrides?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides[] | cdktn.IResolvable;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplate | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplate | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplate | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplate | cdktn.IResolvable | undefined);
    private _launchTemplateSpecification;
    get launchTemplateSpecification(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationOutputReference;
    putLaunchTemplateSpecification(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification): void;
    resetLaunchTemplateSpecification(): void;
    get launchTemplateSpecificationInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification | undefined;
    private _overrides;
    get overrides(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesList;
    putOverrides(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides[] | cdktn.IResolvable): void;
    resetOverrides(): void;
    get overridesInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverrides[] | undefined;
}
export interface AutoscalingAutoScalingGroupMixedInstancesPolicy {
    /**
    * The instances distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#instances_distribution AutoscalingAutoScalingGroup#instances_distribution}
    */
    readonly instancesDistribution?: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistribution;
    /**
    * One or more launch templates and the instance types (overrides) that are used to launch EC2 instances to fulfill the configured capacities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#launch_template AutoscalingAutoScalingGroup#launch_template}
    */
    readonly launchTemplate?: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplate;
}
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyToTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicy | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupMixedInstancesPolicyToHclTerraform(struct?: AutoscalingAutoScalingGroupMixedInstancesPolicy | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupMixedInstancesPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupMixedInstancesPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupMixedInstancesPolicy | cdktn.IResolvable | undefined);
    private _instancesDistribution;
    get instancesDistribution(): AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionOutputReference;
    putInstancesDistribution(value: AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistribution): void;
    resetInstancesDistribution(): void;
    get instancesDistributionInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyInstancesDistribution | undefined;
    private _launchTemplate;
    get launchTemplate(): AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOutputReference;
    putLaunchTemplate(value: AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplate): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicyLaunchTemplate | undefined;
}
export interface AutoscalingAutoScalingGroupNotificationConfiguration {
    /**
    * A list of event types that send a notification. Event types can include any of the following types.
    *  *Allowed values*:
    *   +   ``autoscaling:EC2_INSTANCE_LAUNCH``
    *   +   ``autoscaling:EC2_INSTANCE_LAUNCH_ERROR``
    *   +   ``autoscaling:EC2_INSTANCE_TERMINATE``
    *   +   ``autoscaling:EC2_INSTANCE_TERMINATE_ERROR``
    *   +   ``autoscaling:TEST_NOTIFICATION``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#notification_types AutoscalingAutoScalingGroup#notification_types}
    */
    readonly notificationTypes?: string[];
    /**
    * The Amazon Resource Name (ARN) of the Amazon SNS topic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#topic_arn AutoscalingAutoScalingGroup#topic_arn}
    */
    readonly topicArn?: string;
}
export declare function autoscalingAutoScalingGroupNotificationConfigurationToTerraform(struct?: AutoscalingAutoScalingGroupNotificationConfiguration | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupNotificationConfigurationToHclTerraform(struct?: AutoscalingAutoScalingGroupNotificationConfiguration | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupNotificationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingAutoScalingGroupNotificationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupNotificationConfiguration | cdktn.IResolvable | undefined);
    private _notificationTypes?;
    get notificationTypes(): string[];
    set notificationTypes(value: string[]);
    resetNotificationTypes(): void;
    get notificationTypesInput(): string[] | undefined;
    private _topicArn?;
    get topicArn(): string;
    set topicArn(value: string);
    resetTopicArn(): void;
    get topicArnInput(): string | undefined;
}
export interface AutoscalingAutoScalingGroupNotificationConfigurations {
    /**
    * A list of event types that send a notification. Event types can include any of the following types.
    *  *Allowed values*:
    *   +   ``autoscaling:EC2_INSTANCE_LAUNCH``
    *   +   ``autoscaling:EC2_INSTANCE_LAUNCH_ERROR``
    *   +   ``autoscaling:EC2_INSTANCE_TERMINATE``
    *   +   ``autoscaling:EC2_INSTANCE_TERMINATE_ERROR``
    *   +   ``autoscaling:TEST_NOTIFICATION``
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#notification_types AutoscalingAutoScalingGroup#notification_types}
    */
    readonly notificationTypes?: string[];
    /**
    * The Amazon Resource Name (ARN) of the Amazon SNS topic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#topic_arn AutoscalingAutoScalingGroup#topic_arn}
    */
    readonly topicArn?: string;
}
export declare function autoscalingAutoScalingGroupNotificationConfigurationsToTerraform(struct?: AutoscalingAutoScalingGroupNotificationConfigurations | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupNotificationConfigurationsToHclTerraform(struct?: AutoscalingAutoScalingGroupNotificationConfigurations | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupNotificationConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingAutoScalingGroupNotificationConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupNotificationConfigurations | cdktn.IResolvable | undefined);
    private _notificationTypes?;
    get notificationTypes(): string[];
    set notificationTypes(value: string[]);
    resetNotificationTypes(): void;
    get notificationTypesInput(): string[] | undefined;
    private _topicArn?;
    get topicArn(): string;
    set topicArn(value: string);
    resetTopicArn(): void;
    get topicArnInput(): string | undefined;
}
export declare class AutoscalingAutoScalingGroupNotificationConfigurationsList extends cdktn.ComplexList {
    internalValue?: AutoscalingAutoScalingGroupNotificationConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingAutoScalingGroupNotificationConfigurationsOutputReference;
}
export interface AutoscalingAutoScalingGroupTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#key AutoscalingAutoScalingGroup#key}
    */
    readonly key?: string;
    /**
    * Set to ``true`` if you want CloudFormation to copy the tag to EC2 instances that are launched as part of the Auto Scaling group. Set to ``false`` if you want the tag attached only to the Auto Scaling group and not copied to any instances launched as part of the Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#propagate_at_launch AutoscalingAutoScalingGroup#propagate_at_launch}
    */
    readonly propagateAtLaunch?: boolean | cdktn.IResolvable;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#value AutoscalingAutoScalingGroup#value}
    */
    readonly value?: string;
}
export declare function autoscalingAutoScalingGroupTagsToTerraform(struct?: AutoscalingAutoScalingGroupTags | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupTagsToHclTerraform(struct?: AutoscalingAutoScalingGroupTags | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingAutoScalingGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _propagateAtLaunch?;
    get propagateAtLaunch(): boolean | cdktn.IResolvable;
    set propagateAtLaunch(value: boolean | cdktn.IResolvable);
    resetPropagateAtLaunch(): void;
    get propagateAtLaunchInput(): boolean | cdktn.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AutoscalingAutoScalingGroupTagsList extends cdktn.ComplexList {
    internalValue?: AutoscalingAutoScalingGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingAutoScalingGroupTagsOutputReference;
}
export interface AutoscalingAutoScalingGroupTrafficSources {
    /**
    * Identifies the traffic source.
    *  For Application Load Balancers, Gateway Load Balancers, Network Load Balancers, and VPC Lattice, this will be the Amazon Resource Name (ARN) for a target group in this account and Region. For Classic Load Balancers, this will be the name of the Classic Load Balancer in this account and Region.
    *  For example:
    *   +  Application Load Balancer ARN: ``arn:aws:elasticloadbalancing:us-west-2:123456789012:targetgroup/my-targets/1234567890123456``
    *   +  Classic Load Balancer name: ``my-classic-load-balancer``
    *   +  VPC Lattice ARN: ``arn:aws:vpc-lattice:us-west-2:123456789012:targetgroup/tg-1234567890123456``
    *
    *  To get the ARN of a target group for a Application Load Balancer, Gateway Load Balancer, or Network Load Balancer, or the name of a Classic Load Balancer, use the Elastic Load Balancing [DescribeTargetGroups](https://docs.aws.amazon.com/elasticloadbalancing/latest/APIReference/API_DescribeTargetGroups.html) and [DescribeLoadBalancers](https://docs.aws.amazon.com/elasticloadbalancing/latest/APIReference/API_DescribeLoadBalancers.html) API operations.
    *  To get the ARN of a target group for VPC Lattice, use the VPC Lattice [GetTargetGroup](https://docs.aws.amazon.com/vpc-lattice/latest/APIReference/API_GetTargetGroup.html) API operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#identifier AutoscalingAutoScalingGroup#identifier}
    */
    readonly identifier?: string;
    /**
    * Provides additional context for the value of ``Identifier``.
    *  The following lists the valid values:
    *   +  ``elb`` if ``Identifier`` is the name of a Classic Load Balancer.
    *   +  ``elbv2`` if ``Identifier`` is the ARN of an Application Load Balancer, Gateway Load Balancer, or Network Load Balancer target group.
    *   +  ``vpc-lattice`` if ``Identifier`` is the ARN of a VPC Lattice target group.
    *
    *  Required if the identifier is the name of a Classic Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#type AutoscalingAutoScalingGroup#type}
    */
    readonly type?: string;
}
export declare function autoscalingAutoScalingGroupTrafficSourcesToTerraform(struct?: AutoscalingAutoScalingGroupTrafficSources | cdktn.IResolvable): any;
export declare function autoscalingAutoScalingGroupTrafficSourcesToHclTerraform(struct?: AutoscalingAutoScalingGroupTrafficSources | cdktn.IResolvable): any;
export declare class AutoscalingAutoScalingGroupTrafficSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingAutoScalingGroupTrafficSources | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingAutoScalingGroupTrafficSources | cdktn.IResolvable | undefined);
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    resetIdentifier(): void;
    get identifierInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class AutoscalingAutoScalingGroupTrafficSourcesList extends cdktn.ComplexList {
    internalValue?: AutoscalingAutoScalingGroupTrafficSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingAutoScalingGroupTrafficSourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group awscc_autoscaling_auto_scaling_group}
*/
export declare class AutoscalingAutoScalingGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_autoscaling_auto_scaling_group";
    /**
    * Generates CDKTN code for importing a AutoscalingAutoScalingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutoscalingAutoScalingGroup to import
    * @param importFromId The id of the existing AutoscalingAutoScalingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutoscalingAutoScalingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/autoscaling_auto_scaling_group awscc_autoscaling_auto_scaling_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutoscalingAutoScalingGroupConfig
    */
    constructor(scope: Construct, id: string, config: AutoscalingAutoScalingGroupConfig);
    get autoScalingGroupArn(): string;
    private _autoScalingGroupName?;
    get autoScalingGroupName(): string;
    set autoScalingGroupName(value: string);
    resetAutoScalingGroupName(): void;
    get autoScalingGroupNameInput(): string | undefined;
    private _availabilityZoneDistribution;
    get availabilityZoneDistribution(): AutoscalingAutoScalingGroupAvailabilityZoneDistributionOutputReference;
    putAvailabilityZoneDistribution(value: AutoscalingAutoScalingGroupAvailabilityZoneDistribution): void;
    resetAvailabilityZoneDistribution(): void;
    get availabilityZoneDistributionInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupAvailabilityZoneDistribution | undefined;
    private _availabilityZoneIds?;
    get availabilityZoneIds(): string[];
    set availabilityZoneIds(value: string[]);
    resetAvailabilityZoneIds(): void;
    get availabilityZoneIdsInput(): string[] | undefined;
    private _availabilityZoneImpairmentPolicy;
    get availabilityZoneImpairmentPolicy(): AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicyOutputReference;
    putAvailabilityZoneImpairmentPolicy(value: AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicy): void;
    resetAvailabilityZoneImpairmentPolicy(): void;
    get availabilityZoneImpairmentPolicyInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupAvailabilityZoneImpairmentPolicy | undefined;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    resetAvailabilityZones(): void;
    get availabilityZonesInput(): string[] | undefined;
    private _capacityRebalance?;
    get capacityRebalance(): boolean | cdktn.IResolvable;
    set capacityRebalance(value: boolean | cdktn.IResolvable);
    resetCapacityRebalance(): void;
    get capacityRebalanceInput(): boolean | cdktn.IResolvable | undefined;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): AutoscalingAutoScalingGroupCapacityReservationSpecificationOutputReference;
    putCapacityReservationSpecification(value: AutoscalingAutoScalingGroupCapacityReservationSpecification): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupCapacityReservationSpecification | undefined;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _cooldown?;
    get cooldown(): string;
    set cooldown(value: string);
    resetCooldown(): void;
    get cooldownInput(): string | undefined;
    private _defaultInstanceWarmup?;
    get defaultInstanceWarmup(): number;
    set defaultInstanceWarmup(value: number);
    resetDefaultInstanceWarmup(): void;
    get defaultInstanceWarmupInput(): number | undefined;
    private _deletionProtection?;
    get deletionProtection(): string;
    set deletionProtection(value: string);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): string | undefined;
    private _desiredCapacity?;
    get desiredCapacity(): string;
    set desiredCapacity(value: string);
    resetDesiredCapacity(): void;
    get desiredCapacityInput(): string | undefined;
    private _desiredCapacityType?;
    get desiredCapacityType(): string;
    set desiredCapacityType(value: string);
    resetDesiredCapacityType(): void;
    get desiredCapacityTypeInput(): string | undefined;
    private _healthCheckGracePeriod?;
    get healthCheckGracePeriod(): number;
    set healthCheckGracePeriod(value: number);
    resetHealthCheckGracePeriod(): void;
    get healthCheckGracePeriodInput(): number | undefined;
    private _healthCheckType?;
    get healthCheckType(): string;
    set healthCheckType(value: string);
    resetHealthCheckType(): void;
    get healthCheckTypeInput(): string | undefined;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _instanceLifecyclePolicy;
    get instanceLifecyclePolicy(): AutoscalingAutoScalingGroupInstanceLifecyclePolicyOutputReference;
    putInstanceLifecyclePolicy(value: AutoscalingAutoScalingGroupInstanceLifecyclePolicy): void;
    resetInstanceLifecyclePolicy(): void;
    get instanceLifecyclePolicyInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupInstanceLifecyclePolicy | undefined;
    private _instanceMaintenancePolicy;
    get instanceMaintenancePolicy(): AutoscalingAutoScalingGroupInstanceMaintenancePolicyOutputReference;
    putInstanceMaintenancePolicy(value: AutoscalingAutoScalingGroupInstanceMaintenancePolicy): void;
    resetInstanceMaintenancePolicy(): void;
    get instanceMaintenancePolicyInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupInstanceMaintenancePolicy | undefined;
    private _launchConfigurationName?;
    get launchConfigurationName(): string;
    set launchConfigurationName(value: string);
    resetLaunchConfigurationName(): void;
    get launchConfigurationNameInput(): string | undefined;
    private _launchTemplate;
    get launchTemplate(): AutoscalingAutoScalingGroupLaunchTemplateOutputReference;
    putLaunchTemplate(value: AutoscalingAutoScalingGroupLaunchTemplate): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupLaunchTemplate | undefined;
    private _lifecycleHookSpecificationList;
    get lifecycleHookSpecificationList(): AutoscalingAutoScalingGroupLifecycleHookSpecificationListStructList;
    putLifecycleHookSpecificationList(value: AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct[] | cdktn.IResolvable): void;
    resetLifecycleHookSpecificationList(): void;
    get lifecycleHookSpecificationListInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupLifecycleHookSpecificationListStruct[] | undefined;
    private _loadBalancerNames?;
    get loadBalancerNames(): string[];
    set loadBalancerNames(value: string[]);
    resetLoadBalancerNames(): void;
    get loadBalancerNamesInput(): string[] | undefined;
    private _maxInstanceLifetime?;
    get maxInstanceLifetime(): number;
    set maxInstanceLifetime(value: number);
    resetMaxInstanceLifetime(): void;
    get maxInstanceLifetimeInput(): number | undefined;
    private _maxSize?;
    get maxSize(): string;
    set maxSize(value: string);
    get maxSizeInput(): string | undefined;
    private _metricsCollection;
    get metricsCollection(): AutoscalingAutoScalingGroupMetricsCollectionList;
    putMetricsCollection(value: AutoscalingAutoScalingGroupMetricsCollection[] | cdktn.IResolvable): void;
    resetMetricsCollection(): void;
    get metricsCollectionInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMetricsCollection[] | undefined;
    private _minSize?;
    get minSize(): string;
    set minSize(value: string);
    get minSizeInput(): string | undefined;
    private _mixedInstancesPolicy;
    get mixedInstancesPolicy(): AutoscalingAutoScalingGroupMixedInstancesPolicyOutputReference;
    putMixedInstancesPolicy(value: AutoscalingAutoScalingGroupMixedInstancesPolicy): void;
    resetMixedInstancesPolicy(): void;
    get mixedInstancesPolicyInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupMixedInstancesPolicy | undefined;
    private _newInstancesProtectedFromScaleIn?;
    get newInstancesProtectedFromScaleIn(): boolean | cdktn.IResolvable;
    set newInstancesProtectedFromScaleIn(value: boolean | cdktn.IResolvable);
    resetNewInstancesProtectedFromScaleIn(): void;
    get newInstancesProtectedFromScaleInInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationConfiguration;
    get notificationConfiguration(): AutoscalingAutoScalingGroupNotificationConfigurationOutputReference;
    putNotificationConfiguration(value: AutoscalingAutoScalingGroupNotificationConfiguration): void;
    resetNotificationConfiguration(): void;
    get notificationConfigurationInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupNotificationConfiguration | undefined;
    private _notificationConfigurations;
    get notificationConfigurations(): AutoscalingAutoScalingGroupNotificationConfigurationsList;
    putNotificationConfigurations(value: AutoscalingAutoScalingGroupNotificationConfigurations[] | cdktn.IResolvable): void;
    resetNotificationConfigurations(): void;
    get notificationConfigurationsInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupNotificationConfigurations[] | undefined;
    private _placementGroup?;
    get placementGroup(): string;
    set placementGroup(value: string);
    resetPlacementGroup(): void;
    get placementGroupInput(): string | undefined;
    private _serviceLinkedRoleArn?;
    get serviceLinkedRoleArn(): string;
    set serviceLinkedRoleArn(value: string);
    resetServiceLinkedRoleArn(): void;
    get serviceLinkedRoleArnInput(): string | undefined;
    private _skipZonalShiftValidation?;
    get skipZonalShiftValidation(): boolean | cdktn.IResolvable;
    set skipZonalShiftValidation(value: boolean | cdktn.IResolvable);
    resetSkipZonalShiftValidation(): void;
    get skipZonalShiftValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _tags;
    get tags(): AutoscalingAutoScalingGroupTagsList;
    putTags(value: AutoscalingAutoScalingGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupTags[] | undefined;
    private _targetGroupArNs?;
    get targetGroupArNs(): string[];
    set targetGroupArNs(value: string[]);
    resetTargetGroupArNs(): void;
    get targetGroupArNsInput(): string[] | undefined;
    private _terminationPolicies?;
    get terminationPolicies(): string[];
    set terminationPolicies(value: string[]);
    resetTerminationPolicies(): void;
    get terminationPoliciesInput(): string[] | undefined;
    private _trafficSources;
    get trafficSources(): AutoscalingAutoScalingGroupTrafficSourcesList;
    putTrafficSources(value: AutoscalingAutoScalingGroupTrafficSources[] | cdktn.IResolvable): void;
    resetTrafficSources(): void;
    get trafficSourcesInput(): cdktn.IResolvable | AutoscalingAutoScalingGroupTrafficSources[] | undefined;
    private _vpcZoneIdentifier?;
    get vpcZoneIdentifier(): string[];
    set vpcZoneIdentifier(value: string[]);
    resetVpcZoneIdentifier(): void;
    get vpcZoneIdentifierInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
