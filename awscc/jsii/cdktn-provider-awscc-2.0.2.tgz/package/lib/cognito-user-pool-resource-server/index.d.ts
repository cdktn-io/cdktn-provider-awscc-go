/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoUserPoolResourceServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server#identifier CognitoUserPoolResourceServer#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server#name CognitoUserPoolResourceServer#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server#scopes CognitoUserPoolResourceServer#scopes}
    */
    readonly scopes?: CognitoUserPoolResourceServerScopes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server#user_pool_id CognitoUserPoolResourceServer#user_pool_id}
    */
    readonly userPoolId: string;
}
export interface CognitoUserPoolResourceServerScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server#scope_description CognitoUserPoolResourceServer#scope_description}
    */
    readonly scopeDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server#scope_name CognitoUserPoolResourceServer#scope_name}
    */
    readonly scopeName?: string;
}
export declare function cognitoUserPoolResourceServerScopesToTerraform(struct?: CognitoUserPoolResourceServerScopes | cdktn.IResolvable): any;
export declare function cognitoUserPoolResourceServerScopesToHclTerraform(struct?: CognitoUserPoolResourceServerScopes | cdktn.IResolvable): any;
export declare class CognitoUserPoolResourceServerScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoUserPoolResourceServerScopes | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolResourceServerScopes | cdktn.IResolvable | undefined);
    private _scopeDescription?;
    get scopeDescription(): string;
    set scopeDescription(value: string);
    resetScopeDescription(): void;
    get scopeDescriptionInput(): string | undefined;
    private _scopeName?;
    get scopeName(): string;
    set scopeName(value: string);
    resetScopeName(): void;
    get scopeNameInput(): string | undefined;
}
export declare class CognitoUserPoolResourceServerScopesList extends cdktn.ComplexList {
    internalValue?: CognitoUserPoolResourceServerScopes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoUserPoolResourceServerScopesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server awscc_cognito_user_pool_resource_server}
*/
export declare class CognitoUserPoolResourceServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_user_pool_resource_server";
    /**
    * Generates CDKTN code for importing a CognitoUserPoolResourceServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoUserPoolResourceServer to import
    * @param importFromId The id of the existing CognitoUserPoolResourceServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoUserPoolResourceServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_user_pool_resource_server awscc_cognito_user_pool_resource_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoUserPoolResourceServerConfig
    */
    constructor(scope: Construct, id: string, config: CognitoUserPoolResourceServerConfig);
    get id(): string;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _scopes;
    get scopes(): CognitoUserPoolResourceServerScopesList;
    putScopes(value: CognitoUserPoolResourceServerScopes[] | cdktn.IResolvable): void;
    resetScopes(): void;
    get scopesInput(): cdktn.IResolvable | CognitoUserPoolResourceServerScopes[] | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
