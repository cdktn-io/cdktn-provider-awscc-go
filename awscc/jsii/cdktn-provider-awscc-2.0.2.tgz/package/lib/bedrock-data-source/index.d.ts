/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockDataSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The deletion policy for the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#data_deletion_policy BedrockDataSource#data_deletion_policy}
    */
    readonly dataDeletionPolicy?: string;
    /**
    * Specifies a raw data source location to ingest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#data_source_configuration BedrockDataSource#data_source_configuration}
    */
    readonly dataSourceConfiguration: BedrockDataSourceDataSourceConfiguration;
    /**
    * Description of the Resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#description BedrockDataSource#description}
    */
    readonly description?: string;
    /**
    * The unique identifier of the knowledge base to which to add the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#knowledge_base_id BedrockDataSource#knowledge_base_id}
    */
    readonly knowledgeBaseId: string;
    /**
    * The name of the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#name BedrockDataSource#name}
    */
    readonly name: string;
    /**
    * Contains details about the server-side encryption for the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#server_side_encryption_configuration BedrockDataSource#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration?: BedrockDataSourceServerSideEncryptionConfiguration;
    /**
    * Details about how to chunk the documents in the data source. A chunk refers to an excerpt from a data source that is returned when the knowledge base that it belongs to is queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#vector_ingestion_configuration BedrockDataSource#vector_ingestion_configuration}
    */
    readonly vectorIngestionConfiguration?: BedrockDataSourceVectorIngestionConfiguration;
}
export interface BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters {
    /**
    * A set of regular expression filter patterns for a type of object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#exclusion_filters BedrockDataSource#exclusion_filters}
    */
    readonly exclusionFilters?: string[];
    /**
    * A set of regular expression filter patterns for a type of object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#inclusion_filters BedrockDataSource#inclusion_filters}
    */
    readonly inclusionFilters?: string[];
    /**
    * The supported object type or content type of the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#object_type BedrockDataSource#object_type}
    */
    readonly objectType?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersToTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable | undefined);
    private _exclusionFilters?;
    get exclusionFilters(): string[];
    set exclusionFilters(value: string[]);
    resetExclusionFilters(): void;
    get exclusionFiltersInput(): string[] | undefined;
    private _inclusionFilters?;
    get inclusionFilters(): string[];
    set inclusionFilters(value: string[]);
    resetInclusionFilters(): void;
    get inclusionFiltersInput(): string[] | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    resetObjectType(): void;
    get objectTypeInput(): string | undefined;
}
export declare class BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersList extends cdktn.ComplexList {
    internalValue?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersOutputReference;
}
export interface BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter {
    /**
    * Contains information
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#filters BedrockDataSource#filters}
    */
    readonly filters?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable;
}
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterToTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable | undefined);
    private _filters;
    get filters(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersList;
    putFilters(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfiguration {
    /**
    * The configuration of specific filters applied to your data source content. You can filter out or include certain content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#pattern_object_filter BedrockDataSource#pattern_object_filter}
    */
    readonly patternObjectFilter?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter;
    /**
    * The crawl filter type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#type BedrockDataSource#type}
    */
    readonly type?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable | undefined);
    private _patternObjectFilter;
    get patternObjectFilter(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterOutputReference;
    putPatternObjectFilter(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter): void;
    resetPatternObjectFilter(): void;
    get patternObjectFilterInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfiguration {
    /**
    * The type of filtering that you want to apply to certain objects or content of the data source. For example, the PATTERN type is regular expression patterns you can apply to filter your content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#filter_configuration BedrockDataSource#filter_configuration}
    */
    readonly filterConfiguration?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfiguration | cdktn.IResolvable | undefined);
    private _filterConfiguration;
    get filterConfiguration(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationOutputReference;
    putFilterConfiguration(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfiguration): void;
    resetFilterConfiguration(): void;
    get filterConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfiguration {
    /**
    * The supported authentication type to authenticate and connect to your Confluence instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#auth_type BedrockDataSource#auth_type}
    */
    readonly authType?: string;
    /**
    * The Amazon Resource Name of an AWS Secrets Manager secret that stores your authentication credentials for your Confluence instance URL. For more information on the key-value pairs that must be included in your secret, depending on your authentication type, see Confluence connection configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#credentials_secret_arn BedrockDataSource#credentials_secret_arn}
    */
    readonly credentialsSecretArn?: string;
    /**
    * The supported host type, whether online/cloud or server/on-premises.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#host_type BedrockDataSource#host_type}
    */
    readonly hostType?: string;
    /**
    * The Confluence host URL or instance URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#host_url BedrockDataSource#host_url}
    */
    readonly hostUrl?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfiguration | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _credentialsSecretArn?;
    get credentialsSecretArn(): string;
    set credentialsSecretArn(value: string);
    resetCredentialsSecretArn(): void;
    get credentialsSecretArnInput(): string | undefined;
    private _hostType?;
    get hostType(): string;
    set hostType(value: string);
    resetHostType(): void;
    get hostTypeInput(): string | undefined;
    private _hostUrl?;
    get hostUrl(): string;
    set hostUrl(value: string);
    resetHostUrl(): void;
    get hostUrlInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationConfluenceConfiguration {
    /**
    * The configuration of the Confluence content. For example, configuring specific types of Confluence content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#crawler_configuration BedrockDataSource#crawler_configuration}
    */
    readonly crawlerConfiguration?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfiguration;
    /**
    * The endpoint information to connect to your Confluence data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#source_configuration BedrockDataSource#source_configuration}
    */
    readonly sourceConfiguration?: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationConfluenceConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationConfluenceConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationConfluenceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationConfluenceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationConfluenceConfiguration | cdktn.IResolvable | undefined);
    private _crawlerConfiguration;
    get crawlerConfiguration(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationOutputReference;
    putCrawlerConfiguration(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfiguration): void;
    resetCrawlerConfiguration(): void;
    get crawlerConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfiguration | undefined;
    private _sourceConfiguration;
    get sourceConfiguration(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfigurationOutputReference;
    putSourceConfiguration(value: BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfiguration): void;
    resetSourceConfiguration(): void;
    get sourceConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfiguration {
    /**
    * Indicates whether a feature is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#deletion_protection_status BedrockDataSource#deletion_protection_status}
    */
    readonly deletionProtectionStatus?: string;
    /**
    * Threshold for deletion protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#deletion_protection_threshold BedrockDataSource#deletion_protection_threshold}
    */
    readonly deletionProtectionThreshold?: number;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfiguration | cdktn.IResolvable | undefined);
    private _deletionProtectionStatus?;
    get deletionProtectionStatus(): string;
    set deletionProtectionStatus(value: string);
    resetDeletionProtectionStatus(): void;
    get deletionProtectionStatusInput(): string | undefined;
    private _deletionProtectionThreshold?;
    get deletionProtectionThreshold(): number;
    set deletionProtectionThreshold(value: number);
    resetDeletionProtectionThreshold(): void;
    get deletionProtectionThresholdInput(): number | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfiguration {
    /**
    * Indicates whether a feature is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#audio_extraction_status BedrockDataSource#audio_extraction_status}
    */
    readonly audioExtractionStatus?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfiguration | cdktn.IResolvable | undefined);
    private _audioExtractionStatus?;
    get audioExtractionStatus(): string;
    set audioExtractionStatus(value: string);
    resetAudioExtractionStatus(): void;
    get audioExtractionStatusInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfiguration {
    /**
    * Indicates whether a feature is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#image_extraction_status BedrockDataSource#image_extraction_status}
    */
    readonly imageExtractionStatus?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfiguration | cdktn.IResolvable | undefined);
    private _imageExtractionStatus?;
    get imageExtractionStatus(): string;
    set imageExtractionStatus(value: string);
    resetImageExtractionStatus(): void;
    get imageExtractionStatusInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfiguration {
    /**
    * Indicates whether a feature is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#video_extraction_status BedrockDataSource#video_extraction_status}
    */
    readonly videoExtractionStatus?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfiguration | cdktn.IResolvable | undefined);
    private _videoExtractionStatus?;
    get videoExtractionStatus(): string;
    set videoExtractionStatus(value: string);
    resetVideoExtractionStatus(): void;
    get videoExtractionStatusInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfiguration {
    /**
    * Configuration for audio extraction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#audio_extraction_configuration BedrockDataSource#audio_extraction_configuration}
    */
    readonly audioExtractionConfiguration?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfiguration;
    /**
    * Configuration for image extraction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#image_extraction_configuration BedrockDataSource#image_extraction_configuration}
    */
    readonly imageExtractionConfiguration?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfiguration;
    /**
    * Configuration for video extraction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#video_extraction_configuration BedrockDataSource#video_extraction_configuration}
    */
    readonly videoExtractionConfiguration?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfiguration | cdktn.IResolvable | undefined);
    private _audioExtractionConfiguration;
    get audioExtractionConfiguration(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfigurationOutputReference;
    putAudioExtractionConfiguration(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfiguration): void;
    resetAudioExtractionConfiguration(): void;
    get audioExtractionConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationAudioExtractionConfiguration | undefined;
    private _imageExtractionConfiguration;
    get imageExtractionConfiguration(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfigurationOutputReference;
    putImageExtractionConfiguration(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfiguration): void;
    resetImageExtractionConfiguration(): void;
    get imageExtractionConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationImageExtractionConfiguration | undefined;
    private _videoExtractionConfiguration;
    get videoExtractionConfiguration(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfigurationOutputReference;
    putVideoExtractionConfiguration(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfiguration): void;
    resetVideoExtractionConfiguration(): void;
    get videoExtractionConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationVideoExtractionConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonth {
    /**
    * Specific day of the month, 1 through 28 (capped at 28 to avoid month-length ambiguity).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#day_number BedrockDataSource#day_number}
    */
    readonly dayNumber?: number;
    /**
    * Run on the last calendar day of each month.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#last_day_of_month BedrockDataSource#last_day_of_month}
    */
    readonly lastDayOfMonth?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonthToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonth | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonthToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonth | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonth | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonth | cdktn.IResolvable | undefined);
    private _dayNumber?;
    get dayNumber(): number;
    set dayNumber(value: number);
    resetDayNumber(): void;
    get dayNumberInput(): number | undefined;
    private _lastDayOfMonth?;
    get lastDayOfMonth(): string;
    set lastDayOfMonth(value: string);
    resetLastDayOfMonth(): void;
    get lastDayOfMonthInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthly {
    /**
    * Day of the month on which a monthly refresh runs. Exactly one variant is set: an explicit day number, or the last calendar day of the month.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#day_of_month BedrockDataSource#day_of_month}
    */
    readonly dayOfMonth?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonth;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthly | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthly | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthly | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthly | cdktn.IResolvable | undefined);
    private _dayOfMonth;
    get dayOfMonth(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonthOutputReference;
    putDayOfMonth(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonth): void;
    resetDayOfMonth(): void;
    get dayOfMonthInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyDayOfMonth | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeekly {
    /**
    * Day of the week.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#day_of_week BedrockDataSource#day_of_week}
    */
    readonly dayOfWeek?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeeklyToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeekly | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeeklyToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeekly | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeeklyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeekly | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeekly | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncSchedule {
    /**
    * A daily refresh. The run time is system-chosen (off-peak) and not customer-configurable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#daily BedrockDataSource#daily}
    */
    readonly daily?: string;
    /**
    * A monthly refresh on a specified day of the month.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#monthly BedrockDataSource#monthly}
    */
    readonly monthly?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthly;
    /**
    * A weekly refresh on a specified day of the week.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#weekly BedrockDataSource#weekly}
    */
    readonly weekly?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeekly;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncSchedule | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncSchedule | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncSchedule | cdktn.IResolvable | undefined);
    private _daily?;
    get daily(): string;
    set daily(value: string);
    resetDaily(): void;
    get dailyInput(): string | undefined;
    private _monthly;
    get monthly(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthlyOutputReference;
    putMonthly(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthly): void;
    resetMonthly(): void;
    get monthlyInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleMonthly | undefined;
    private _weekly;
    get weekly(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeeklyOutputReference;
    putWeekly(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeekly): void;
    resetWeekly(): void;
    get weeklyInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleWeekly | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfiguration {
    /**
    * Connector-specific parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#connector_parameters BedrockDataSource#connector_parameters}
    */
    readonly connectorParameters?: string;
    /**
    * Configuration for deletion protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#deletion_protection_configuration BedrockDataSource#deletion_protection_configuration}
    */
    readonly deletionProtectionConfiguration?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfiguration;
    /**
    * Configuration for media extraction settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#media_extraction_configuration BedrockDataSource#media_extraction_configuration}
    */
    readonly mediaExtractionConfiguration?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfiguration;
    /**
    * Recurring schedule on which the connector automatically refreshes ingested content. Exactly one frequency variant is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#sync_schedule BedrockDataSource#sync_schedule}
    */
    readonly syncSchedule?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncSchedule;
}
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfiguration | cdktn.IResolvable | undefined);
    private _connectorParameters?;
    get connectorParameters(): string;
    set connectorParameters(value: string);
    resetConnectorParameters(): void;
    get connectorParametersInput(): string | undefined;
    private _deletionProtectionConfiguration;
    get deletionProtectionConfiguration(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfigurationOutputReference;
    putDeletionProtectionConfiguration(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfiguration): void;
    resetDeletionProtectionConfiguration(): void;
    get deletionProtectionConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationDeletionProtectionConfiguration | undefined;
    private _mediaExtractionConfiguration;
    get mediaExtractionConfiguration(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfigurationOutputReference;
    putMediaExtractionConfiguration(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfiguration): void;
    resetMediaExtractionConfiguration(): void;
    get mediaExtractionConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationMediaExtractionConfiguration | undefined;
    private _syncSchedule;
    get syncSchedule(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncScheduleOutputReference;
    putSyncSchedule(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncSchedule): void;
    resetSyncSchedule(): void;
    get syncScheduleInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationSyncSchedule | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationS3Configuration {
    /**
    * The ARN of the bucket that contains the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#bucket_arn BedrockDataSource#bucket_arn}
    */
    readonly bucketArn?: string;
    /**
    * The account ID for the owner of the S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#bucket_owner_account_id BedrockDataSource#bucket_owner_account_id}
    */
    readonly bucketOwnerAccountId?: string;
    /**
    * A list of S3 prefixes that define the object containing the data sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#inclusion_prefixes BedrockDataSource#inclusion_prefixes}
    */
    readonly inclusionPrefixes?: string[];
}
export declare function bedrockDataSourceDataSourceConfigurationS3ConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationS3Configuration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationS3ConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationS3Configuration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationS3ConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationS3Configuration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationS3Configuration | cdktn.IResolvable | undefined);
    private _bucketArn?;
    get bucketArn(): string;
    set bucketArn(value: string);
    resetBucketArn(): void;
    get bucketArnInput(): string | undefined;
    private _bucketOwnerAccountId?;
    get bucketOwnerAccountId(): string;
    set bucketOwnerAccountId(value: string);
    resetBucketOwnerAccountId(): void;
    get bucketOwnerAccountIdInput(): string | undefined;
    private _inclusionPrefixes?;
    get inclusionPrefixes(): string[];
    set inclusionPrefixes(value: string[]);
    resetInclusionPrefixes(): void;
    get inclusionPrefixesInput(): string[] | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters {
    /**
    * A set of regular expression filter patterns for a type of object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#exclusion_filters BedrockDataSource#exclusion_filters}
    */
    readonly exclusionFilters?: string[];
    /**
    * A set of regular expression filter patterns for a type of object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#inclusion_filters BedrockDataSource#inclusion_filters}
    */
    readonly inclusionFilters?: string[];
    /**
    * The supported object type or content type of the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#object_type BedrockDataSource#object_type}
    */
    readonly objectType?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable | undefined);
    private _exclusionFilters?;
    get exclusionFilters(): string[];
    set exclusionFilters(value: string[]);
    resetExclusionFilters(): void;
    get exclusionFiltersInput(): string[] | undefined;
    private _inclusionFilters?;
    get inclusionFilters(): string[];
    set inclusionFilters(value: string[]);
    resetInclusionFilters(): void;
    get inclusionFiltersInput(): string[] | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    resetObjectType(): void;
    get objectTypeInput(): string | undefined;
}
export declare class BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersList extends cdktn.ComplexList {
    internalValue?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersOutputReference;
}
export interface BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter {
    /**
    * Contains information
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#filters BedrockDataSource#filters}
    */
    readonly filters?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable;
}
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable | undefined);
    private _filters;
    get filters(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersList;
    putFilters(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfiguration {
    /**
    * The configuration of specific filters applied to your data source content. You can filter out or include certain content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#pattern_object_filter BedrockDataSource#pattern_object_filter}
    */
    readonly patternObjectFilter?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter;
    /**
    * The crawl filter type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#type BedrockDataSource#type}
    */
    readonly type?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable | undefined);
    private _patternObjectFilter;
    get patternObjectFilter(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterOutputReference;
    putPatternObjectFilter(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter): void;
    resetPatternObjectFilter(): void;
    get patternObjectFilterInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfiguration {
    /**
    * The type of filtering that you want to apply to certain objects or content of the data source. For example, the PATTERN type is regular expression patterns you can apply to filter your content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#filter_configuration BedrockDataSource#filter_configuration}
    */
    readonly filterConfiguration?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfiguration | cdktn.IResolvable | undefined);
    private _filterConfiguration;
    get filterConfiguration(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationOutputReference;
    putFilterConfiguration(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfiguration): void;
    resetFilterConfiguration(): void;
    get filterConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfiguration {
    /**
    * The supported authentication type to authenticate and connect to your Salesforce instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#auth_type BedrockDataSource#auth_type}
    */
    readonly authType?: string;
    /**
    * The Amazon Resource Name of an AWS Secrets Manager secret that stores your authentication credentials for your Salesforce instance URL. For more information on the key-value pairs that must be included in your secret, depending on your authentication type, see Salesforce connection configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#credentials_secret_arn BedrockDataSource#credentials_secret_arn}
    */
    readonly credentialsSecretArn?: string;
    /**
    * The Salesforce host URL or instance URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#host_url BedrockDataSource#host_url}
    */
    readonly hostUrl?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfiguration | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _credentialsSecretArn?;
    get credentialsSecretArn(): string;
    set credentialsSecretArn(value: string);
    resetCredentialsSecretArn(): void;
    get credentialsSecretArnInput(): string | undefined;
    private _hostUrl?;
    get hostUrl(): string;
    set hostUrl(value: string);
    resetHostUrl(): void;
    get hostUrlInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSalesforceConfiguration {
    /**
    * The configuration of filtering the Salesforce content. For example, configuring regular expression patterns to include or exclude certain content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#crawler_configuration BedrockDataSource#crawler_configuration}
    */
    readonly crawlerConfiguration?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfiguration;
    /**
    * The endpoint information to connect to your Salesforce data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#source_configuration BedrockDataSource#source_configuration}
    */
    readonly sourceConfiguration?: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSalesforceConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSalesforceConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSalesforceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSalesforceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSalesforceConfiguration | cdktn.IResolvable | undefined);
    private _crawlerConfiguration;
    get crawlerConfiguration(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationOutputReference;
    putCrawlerConfiguration(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfiguration): void;
    resetCrawlerConfiguration(): void;
    get crawlerConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfiguration | undefined;
    private _sourceConfiguration;
    get sourceConfiguration(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfigurationOutputReference;
    putSourceConfiguration(value: BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfiguration): void;
    resetSourceConfiguration(): void;
    get sourceConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters {
    /**
    * A set of regular expression filter patterns for a type of object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#exclusion_filters BedrockDataSource#exclusion_filters}
    */
    readonly exclusionFilters?: string[];
    /**
    * A set of regular expression filter patterns for a type of object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#inclusion_filters BedrockDataSource#inclusion_filters}
    */
    readonly inclusionFilters?: string[];
    /**
    * The supported object type or content type of the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#object_type BedrockDataSource#object_type}
    */
    readonly objectType?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters | cdktn.IResolvable | undefined);
    private _exclusionFilters?;
    get exclusionFilters(): string[];
    set exclusionFilters(value: string[]);
    resetExclusionFilters(): void;
    get exclusionFiltersInput(): string[] | undefined;
    private _inclusionFilters?;
    get inclusionFilters(): string[];
    set inclusionFilters(value: string[]);
    resetInclusionFilters(): void;
    get inclusionFiltersInput(): string[] | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    resetObjectType(): void;
    get objectTypeInput(): string | undefined;
}
export declare class BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersList extends cdktn.ComplexList {
    internalValue?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersOutputReference;
}
export interface BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter {
    /**
    * Contains information
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#filters BedrockDataSource#filters}
    */
    readonly filters?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable;
}
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | cdktn.IResolvable | undefined);
    private _filters;
    get filters(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersList;
    putFilters(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFilters[] | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfiguration {
    /**
    * The configuration of specific filters applied to your data source content. You can filter out or include certain content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#pattern_object_filter BedrockDataSource#pattern_object_filter}
    */
    readonly patternObjectFilter?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter;
    /**
    * The crawl filter type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#type BedrockDataSource#type}
    */
    readonly type?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfiguration | cdktn.IResolvable | undefined);
    private _patternObjectFilter;
    get patternObjectFilter(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterOutputReference;
    putPatternObjectFilter(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter): void;
    resetPatternObjectFilter(): void;
    get patternObjectFilterInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilter | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfiguration {
    /**
    * The type of filtering that you want to apply to certain objects or content of the data source. For example, the PATTERN type is regular expression patterns you can apply to filter your content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#filter_configuration BedrockDataSource#filter_configuration}
    */
    readonly filterConfiguration?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfiguration | cdktn.IResolvable | undefined);
    private _filterConfiguration;
    get filterConfiguration(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationOutputReference;
    putFilterConfiguration(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfiguration): void;
    resetFilterConfiguration(): void;
    get filterConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfiguration {
    /**
    * The supported authentication type to authenticate and connect to your SharePoint site/sites.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#auth_type BedrockDataSource#auth_type}
    */
    readonly authType?: string;
    /**
    * The Amazon Resource Name of an AWS Secrets Manager secret that stores your authentication credentials for your SharePoint site/sites. For more information on the key-value pairs that must be included in your secret, depending on your authentication type, see SharePoint connection configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#credentials_secret_arn BedrockDataSource#credentials_secret_arn}
    */
    readonly credentialsSecretArn?: string;
    /**
    * The domain of your SharePoint instance or site URL/URLs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#domain BedrockDataSource#domain}
    */
    readonly domain?: string;
    /**
    * The supported host type, whether online/cloud or server/on-premises.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#host_type BedrockDataSource#host_type}
    */
    readonly hostType?: string;
    /**
    * A list of one or more SharePoint site URLs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#site_urls BedrockDataSource#site_urls}
    */
    readonly siteUrls?: string[];
    /**
    * The identifier of your Microsoft 365 tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#tenant_id BedrockDataSource#tenant_id}
    */
    readonly tenantId?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfiguration | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _credentialsSecretArn?;
    get credentialsSecretArn(): string;
    set credentialsSecretArn(value: string);
    resetCredentialsSecretArn(): void;
    get credentialsSecretArnInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _hostType?;
    get hostType(): string;
    set hostType(value: string);
    resetHostType(): void;
    get hostTypeInput(): string | undefined;
    private _siteUrls?;
    get siteUrls(): string[];
    set siteUrls(value: string[]);
    resetSiteUrls(): void;
    get siteUrlsInput(): string[] | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationSharePointConfiguration {
    /**
    * The configuration of the SharePoint content. For example, configuring specific types of SharePoint content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#crawler_configuration BedrockDataSource#crawler_configuration}
    */
    readonly crawlerConfiguration?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfiguration;
    /**
    * The endpoint information to connect to your SharePoint data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#source_configuration BedrockDataSource#source_configuration}
    */
    readonly sourceConfiguration?: BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationSharePointConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationSharePointConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationSharePointConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationSharePointConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationSharePointConfiguration | cdktn.IResolvable | undefined);
    private _crawlerConfiguration;
    get crawlerConfiguration(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationOutputReference;
    putCrawlerConfiguration(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfiguration): void;
    resetCrawlerConfiguration(): void;
    get crawlerConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfiguration | undefined;
    private _sourceConfiguration;
    get sourceConfiguration(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfigurationOutputReference;
    putSourceConfiguration(value: BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfiguration): void;
    resetSourceConfiguration(): void;
    get sourceConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSharePointConfigurationSourceConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimits {
    /**
    * Maximum number of pages the crawler can crawl.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#max_pages BedrockDataSource#max_pages}
    */
    readonly maxPages?: number;
    /**
    * Rate of web URLs retrieved per minute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#rate_limit BedrockDataSource#rate_limit}
    */
    readonly rateLimit?: number;
}
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimitsToTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimits | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimitsToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimits | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimits | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimits | cdktn.IResolvable | undefined);
    private _maxPages?;
    get maxPages(): number;
    set maxPages(value: number);
    resetMaxPages(): void;
    get maxPagesInput(): number | undefined;
    private _rateLimit?;
    get rateLimit(): number;
    set rateLimit(value: number);
    resetRateLimit(): void;
    get rateLimitInput(): number | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfiguration {
    /**
    * Limit settings for the web crawler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#crawler_limits BedrockDataSource#crawler_limits}
    */
    readonly crawlerLimits?: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimits;
    /**
    * A set of regular expression filter patterns for a type of object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#exclusion_filters BedrockDataSource#exclusion_filters}
    */
    readonly exclusionFilters?: string[];
    /**
    * A set of regular expression filter patterns for a type of object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#inclusion_filters BedrockDataSource#inclusion_filters}
    */
    readonly inclusionFilters?: string[];
    /**
    * The scope that a web crawl job will be restricted to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#scope BedrockDataSource#scope}
    */
    readonly scope?: string;
    /**
    * The suffix that will be included in the user agent header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#user_agent BedrockDataSource#user_agent}
    */
    readonly userAgent?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfiguration | cdktn.IResolvable | undefined);
    private _crawlerLimits;
    get crawlerLimits(): BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimitsOutputReference;
    putCrawlerLimits(value: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimits): void;
    resetCrawlerLimits(): void;
    get crawlerLimitsInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationCrawlerLimits | undefined;
    private _exclusionFilters?;
    get exclusionFilters(): string[];
    set exclusionFilters(value: string[]);
    resetExclusionFilters(): void;
    get exclusionFiltersInput(): string[] | undefined;
    private _inclusionFilters?;
    get inclusionFilters(): string[];
    set inclusionFilters(value: string[]);
    resetInclusionFilters(): void;
    get inclusionFiltersInput(): string[] | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _userAgent?;
    get userAgent(): string;
    set userAgent(value: string);
    resetUserAgent(): void;
    get userAgentInput(): string | undefined;
    get userAgentHeader(): string;
}
export interface BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls {
    /**
    * A web url.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#url BedrockDataSource#url}
    */
    readonly url?: string;
}
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrlsToTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrlsToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls | cdktn.IResolvable | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export declare class BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrlsList extends cdktn.ComplexList {
    internalValue?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrlsOutputReference;
}
export interface BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfiguration {
    /**
    * A list of web urls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#seed_urls BedrockDataSource#seed_urls}
    */
    readonly seedUrls?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls[] | cdktn.IResolvable;
}
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfiguration | cdktn.IResolvable | undefined);
    private _seedUrls;
    get seedUrls(): BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrlsList;
    putSeedUrls(value: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls[] | cdktn.IResolvable): void;
    resetSeedUrls(): void;
    get seedUrlsInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationSeedUrls[] | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfiguration {
    /**
    * A url configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#url_configuration BedrockDataSource#url_configuration}
    */
    readonly urlConfiguration?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfiguration | cdktn.IResolvable | undefined);
    private _urlConfiguration;
    get urlConfiguration(): BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfigurationOutputReference;
    putUrlConfiguration(value: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfiguration): void;
    resetUrlConfiguration(): void;
    get urlConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationUrlConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfigurationWebConfiguration {
    /**
    * Configuration for the web crawler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#crawler_configuration BedrockDataSource#crawler_configuration}
    */
    readonly crawlerConfiguration?: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfiguration;
    /**
    * A web source configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#source_configuration BedrockDataSource#source_configuration}
    */
    readonly sourceConfiguration?: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationWebConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfigurationWebConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationWebConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfigurationWebConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfigurationWebConfiguration | cdktn.IResolvable | undefined);
    private _crawlerConfiguration;
    get crawlerConfiguration(): BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationOutputReference;
    putCrawlerConfiguration(value: BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfiguration): void;
    resetCrawlerConfiguration(): void;
    get crawlerConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationWebConfigurationCrawlerConfiguration | undefined;
    private _sourceConfiguration;
    get sourceConfiguration(): BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationOutputReference;
    putSourceConfiguration(value: BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfiguration): void;
    resetSourceConfiguration(): void;
    get sourceConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationWebConfigurationSourceConfiguration | undefined;
}
export interface BedrockDataSourceDataSourceConfiguration {
    /**
    * The configuration information to connect to Confluence as your data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#confluence_configuration BedrockDataSource#confluence_configuration}
    */
    readonly confluenceConfiguration?: BedrockDataSourceDataSourceConfigurationConfluenceConfiguration;
    /**
    * Configuration for managed knowledge base connector data sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#managed_knowledge_base_connector_configuration BedrockDataSource#managed_knowledge_base_connector_configuration}
    */
    readonly managedKnowledgeBaseConnectorConfiguration?: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfiguration;
    /**
    * The configuration information to connect to Amazon S3 as your data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#s3_configuration BedrockDataSource#s3_configuration}
    */
    readonly s3Configuration?: BedrockDataSourceDataSourceConfigurationS3Configuration;
    /**
    * The configuration information to connect to Salesforce as your data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#salesforce_configuration BedrockDataSource#salesforce_configuration}
    */
    readonly salesforceConfiguration?: BedrockDataSourceDataSourceConfigurationSalesforceConfiguration;
    /**
    * The configuration information to connect to SharePoint as your data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#share_point_configuration BedrockDataSource#share_point_configuration}
    */
    readonly sharePointConfiguration?: BedrockDataSourceDataSourceConfigurationSharePointConfiguration;
    /**
    * The type of the data source location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#type BedrockDataSource#type}
    */
    readonly type: string;
    /**
    * Configures a web data source location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#web_configuration BedrockDataSource#web_configuration}
    */
    readonly webConfiguration?: BedrockDataSourceDataSourceConfigurationWebConfiguration;
}
export declare function bedrockDataSourceDataSourceConfigurationToTerraform(struct?: BedrockDataSourceDataSourceConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceDataSourceConfigurationToHclTerraform(struct?: BedrockDataSourceDataSourceConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceDataSourceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceDataSourceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceDataSourceConfiguration | cdktn.IResolvable | undefined);
    private _confluenceConfiguration;
    get confluenceConfiguration(): BedrockDataSourceDataSourceConfigurationConfluenceConfigurationOutputReference;
    putConfluenceConfiguration(value: BedrockDataSourceDataSourceConfigurationConfluenceConfiguration): void;
    resetConfluenceConfiguration(): void;
    get confluenceConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationConfluenceConfiguration | undefined;
    private _managedKnowledgeBaseConnectorConfiguration;
    get managedKnowledgeBaseConnectorConfiguration(): BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfigurationOutputReference;
    putManagedKnowledgeBaseConnectorConfiguration(value: BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfiguration): void;
    resetManagedKnowledgeBaseConnectorConfiguration(): void;
    get managedKnowledgeBaseConnectorConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationManagedKnowledgeBaseConnectorConfiguration | undefined;
    private _s3Configuration;
    get s3Configuration(): BedrockDataSourceDataSourceConfigurationS3ConfigurationOutputReference;
    putS3Configuration(value: BedrockDataSourceDataSourceConfigurationS3Configuration): void;
    resetS3Configuration(): void;
    get s3ConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationS3Configuration | undefined;
    private _salesforceConfiguration;
    get salesforceConfiguration(): BedrockDataSourceDataSourceConfigurationSalesforceConfigurationOutputReference;
    putSalesforceConfiguration(value: BedrockDataSourceDataSourceConfigurationSalesforceConfiguration): void;
    resetSalesforceConfiguration(): void;
    get salesforceConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSalesforceConfiguration | undefined;
    private _sharePointConfiguration;
    get sharePointConfiguration(): BedrockDataSourceDataSourceConfigurationSharePointConfigurationOutputReference;
    putSharePointConfiguration(value: BedrockDataSourceDataSourceConfigurationSharePointConfiguration): void;
    resetSharePointConfiguration(): void;
    get sharePointConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationSharePointConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _webConfiguration;
    get webConfiguration(): BedrockDataSourceDataSourceConfigurationWebConfigurationOutputReference;
    putWebConfiguration(value: BedrockDataSourceDataSourceConfigurationWebConfiguration): void;
    resetWebConfiguration(): void;
    get webConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfigurationWebConfiguration | undefined;
}
export interface BedrockDataSourceServerSideEncryptionConfiguration {
    /**
    * The ARN of the AWS KMS key used to encrypt the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#kms_key_arn BedrockDataSource#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
}
export declare function bedrockDataSourceServerSideEncryptionConfigurationToTerraform(struct?: BedrockDataSourceServerSideEncryptionConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceServerSideEncryptionConfigurationToHclTerraform(struct?: BedrockDataSourceServerSideEncryptionConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceServerSideEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceServerSideEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceServerSideEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfiguration {
    /**
    * The maximum number of tokens to include in a chunk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#max_tokens BedrockDataSource#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * The percentage of overlap between adjacent chunks of a data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#overlap_percentage BedrockDataSource#overlap_percentage}
    */
    readonly overlapPercentage?: number;
}
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfiguration | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _overlapPercentage?;
    get overlapPercentage(): number;
    set overlapPercentage(value: number);
    resetOverlapPercentage(): void;
    get overlapPercentageInput(): number | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations {
    /**
    * The maximum number of tokens that a chunk can contain in this layer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#max_tokens BedrockDataSource#max_tokens}
    */
    readonly maxTokens?: number;
}
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurationsToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurationsToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
}
export declare class BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurationsList extends cdktn.ComplexList {
    internalValue?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurationsOutputReference;
}
export interface BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfiguration {
    /**
    * Token settings for each layer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#level_configurations BedrockDataSource#level_configurations}
    */
    readonly levelConfigurations?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations[] | cdktn.IResolvable;
    /**
    * The number of tokens to repeat across chunks in the same layer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#overlap_tokens BedrockDataSource#overlap_tokens}
    */
    readonly overlapTokens?: number;
}
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfiguration | cdktn.IResolvable | undefined);
    private _levelConfigurations;
    get levelConfigurations(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurationsList;
    putLevelConfigurations(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations[] | cdktn.IResolvable): void;
    resetLevelConfigurations(): void;
    get levelConfigurationsInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationLevelConfigurations[] | undefined;
    private _overlapTokens?;
    get overlapTokens(): number;
    set overlapTokens(value: number);
    resetOverlapTokens(): void;
    get overlapTokensInput(): number | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfiguration {
    /**
    * The dissimilarity threshold for splitting chunks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#breakpoint_percentile_threshold BedrockDataSource#breakpoint_percentile_threshold}
    */
    readonly breakpointPercentileThreshold?: number;
    /**
    * The buffer size.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#buffer_size BedrockDataSource#buffer_size}
    */
    readonly bufferSize?: number;
    /**
    * The maximum number of tokens that a chunk can contain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#max_tokens BedrockDataSource#max_tokens}
    */
    readonly maxTokens?: number;
}
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfiguration | cdktn.IResolvable | undefined);
    private _breakpointPercentileThreshold?;
    get breakpointPercentileThreshold(): number;
    set breakpointPercentileThreshold(value: number);
    resetBreakpointPercentileThreshold(): void;
    get breakpointPercentileThresholdInput(): number | undefined;
    private _bufferSize?;
    get bufferSize(): number;
    set bufferSize(value: number);
    resetBufferSize(): void;
    get bufferSizeInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationChunkingConfiguration {
    /**
    * Knowledge base can split your source data into chunks. A chunk refers to an excerpt from a data source that is returned when the knowledge base that it belongs to is queried. You have the following options for chunking your data. If you opt for NONE, then you may want to pre-process your files by splitting them up such that each file corresponds to a chunk.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#chunking_strategy BedrockDataSource#chunking_strategy}
    */
    readonly chunkingStrategy?: string;
    /**
    * Configurations for when you choose fixed-size chunking. If you set the chunkingStrategy as NONE, exclude this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#fixed_size_chunking_configuration BedrockDataSource#fixed_size_chunking_configuration}
    */
    readonly fixedSizeChunkingConfiguration?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfiguration;
    /**
    * Configurations for when you choose hierarchical chunking. If you set the chunkingStrategy as NONE, exclude this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#hierarchical_chunking_configuration BedrockDataSource#hierarchical_chunking_configuration}
    */
    readonly hierarchicalChunkingConfiguration?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfiguration;
    /**
    * Configurations for when you choose semantic chunking. If you set the chunkingStrategy as NONE, exclude this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#semantic_chunking_configuration BedrockDataSource#semantic_chunking_configuration}
    */
    readonly semanticChunkingConfiguration?: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfiguration;
}
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationChunkingConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationChunkingConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationChunkingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfiguration | cdktn.IResolvable | undefined);
    private _chunkingStrategy?;
    get chunkingStrategy(): string;
    set chunkingStrategy(value: string);
    resetChunkingStrategy(): void;
    get chunkingStrategyInput(): string | undefined;
    private _fixedSizeChunkingConfiguration;
    get fixedSizeChunkingConfiguration(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfigurationOutputReference;
    putFixedSizeChunkingConfiguration(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfiguration): void;
    resetFixedSizeChunkingConfiguration(): void;
    get fixedSizeChunkingConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationFixedSizeChunkingConfiguration | undefined;
    private _hierarchicalChunkingConfiguration;
    get hierarchicalChunkingConfiguration(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfigurationOutputReference;
    putHierarchicalChunkingConfiguration(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfiguration): void;
    resetHierarchicalChunkingConfiguration(): void;
    get hierarchicalChunkingConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationHierarchicalChunkingConfiguration | undefined;
    private _semanticChunkingConfiguration;
    get semanticChunkingConfiguration(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfigurationOutputReference;
    putSemanticChunkingConfiguration(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfiguration): void;
    resetSemanticChunkingConfiguration(): void;
    get semanticChunkingConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationSemanticChunkingConfiguration | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfiguration {
    /**
    * Enrichment Strategy method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#method BedrockDataSource#method}
    */
    readonly method?: string;
}
export declare function bedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfiguration | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfiguration {
    /**
    * Strategy to be used when using Bedrock Foundation Model for Context Enrichment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#enrichment_strategy_configuration BedrockDataSource#enrichment_strategy_configuration}
    */
    readonly enrichmentStrategyConfiguration?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfiguration;
    /**
    * The model's ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#model_arn BedrockDataSource#model_arn}
    */
    readonly modelArn?: string;
}
export declare function bedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfiguration | cdktn.IResolvable | undefined);
    private _enrichmentStrategyConfiguration;
    get enrichmentStrategyConfiguration(): BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfigurationOutputReference;
    putEnrichmentStrategyConfiguration(value: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfiguration): void;
    resetEnrichmentStrategyConfiguration(): void;
    get enrichmentStrategyConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationEnrichmentStrategyConfiguration | undefined;
    private _modelArn?;
    get modelArn(): string;
    set modelArn(value: string);
    resetModelArn(): void;
    get modelArnInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfiguration {
    /**
    * Bedrock Foundation Model configuration to be used for Context Enrichment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#bedrock_foundation_model_configuration BedrockDataSource#bedrock_foundation_model_configuration}
    */
    readonly bedrockFoundationModelConfiguration?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfiguration;
    /**
    * Enrichment type to be used for the vector database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#type BedrockDataSource#type}
    */
    readonly type?: string;
}
export declare function bedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfiguration | cdktn.IResolvable | undefined);
    private _bedrockFoundationModelConfiguration;
    get bedrockFoundationModelConfiguration(): BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfigurationOutputReference;
    putBedrockFoundationModelConfiguration(value: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfiguration): void;
    resetBedrockFoundationModelConfiguration(): void;
    get bedrockFoundationModelConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationBedrockFoundationModelConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3Location {
    /**
    * The location's URI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#uri BedrockDataSource#uri}
    */
    readonly uri?: string;
}
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3LocationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3Location | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3LocationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3Location | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3Location | cdktn.IResolvable | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorage {
    /**
    * An Amazon S3 location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#s3_location BedrockDataSource#s3_location}
    */
    readonly s3Location?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3Location;
}
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorage | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorage | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorage | cdktn.IResolvable | undefined);
    private _s3Location;
    get s3Location(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3LocationOutputReference;
    putS3Location(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3Location): void;
    resetS3Location(): void;
    get s3LocationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageS3Location | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfiguration {
    /**
    * The function's ARN identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#lambda_arn BedrockDataSource#lambda_arn}
    */
    readonly lambdaArn?: string;
}
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfiguration | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    resetLambdaArn(): void;
    get lambdaArnInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunction {
    /**
    * A Lambda function that processes documents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#transformation_lambda_configuration BedrockDataSource#transformation_lambda_configuration}
    */
    readonly transformationLambdaConfiguration?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfiguration;
}
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunction | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunction | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunction | cdktn.IResolvable | undefined);
    private _transformationLambdaConfiguration;
    get transformationLambdaConfiguration(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfigurationOutputReference;
    putTransformationLambdaConfiguration(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfiguration): void;
    resetTransformationLambdaConfiguration(): void;
    get transformationLambdaConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionTransformationLambdaConfiguration | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations {
    /**
    * When the service applies the transformation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#step_to_apply BedrockDataSource#step_to_apply}
    */
    readonly stepToApply?: string;
    /**
    * A Lambda function that processes documents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#transformation_function BedrockDataSource#transformation_function}
    */
    readonly transformationFunction?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunction;
}
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations | cdktn.IResolvable | undefined);
    private _stepToApply?;
    get stepToApply(): string;
    set stepToApply(value: string);
    resetStepToApply(): void;
    get stepToApplyInput(): string | undefined;
    private _transformationFunction;
    get transformationFunction(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunctionOutputReference;
    putTransformationFunction(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunction): void;
    resetTransformationFunction(): void;
    get transformationFunctionInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsTransformationFunction | undefined;
}
export declare class BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsList extends cdktn.ComplexList {
    internalValue?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsOutputReference;
}
export interface BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfiguration {
    /**
    * A location for storing content from data sources temporarily as it is processed by custom components in the ingestion pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#intermediate_storage BedrockDataSource#intermediate_storage}
    */
    readonly intermediateStorage?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorage;
    /**
    * A list of Lambda functions that process documents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#transformations BedrockDataSource#transformations}
    */
    readonly transformations?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations[] | cdktn.IResolvable;
}
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfiguration | cdktn.IResolvable | undefined);
    private _intermediateStorage;
    get intermediateStorage(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorageOutputReference;
    putIntermediateStorage(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorage): void;
    resetIntermediateStorage(): void;
    get intermediateStorageInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationIntermediateStorage | undefined;
    private _transformations;
    get transformations(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformationsList;
    putTransformations(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations[] | cdktn.IResolvable): void;
    resetTransformations(): void;
    get transformationsInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationTransformations[] | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfiguration {
    /**
    * Determine how will parsed content be stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#parsing_modality BedrockDataSource#parsing_modality}
    */
    readonly parsingModality?: string;
}
export declare function bedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfiguration | cdktn.IResolvable | undefined);
    private _parsingModality?;
    get parsingModality(): string;
    set parsingModality(value: string);
    resetParsingModality(): void;
    get parsingModalityInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPrompt {
    /**
    * Instructions for interpreting the contents of a document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#parsing_prompt_text BedrockDataSource#parsing_prompt_text}
    */
    readonly parsingPromptText?: string;
}
export declare function bedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPromptToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPrompt | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPromptToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPrompt | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPromptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPrompt | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPrompt | cdktn.IResolvable | undefined);
    private _parsingPromptText?;
    get parsingPromptText(): string;
    set parsingPromptText(value: string);
    resetParsingPromptText(): void;
    get parsingPromptTextInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfiguration {
    /**
    * The model's ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#model_arn BedrockDataSource#model_arn}
    */
    readonly modelArn?: string;
    /**
    * Determine how will parsed content be stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#parsing_modality BedrockDataSource#parsing_modality}
    */
    readonly parsingModality?: string;
    /**
    * Instructions for interpreting the contents of a document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#parsing_prompt BedrockDataSource#parsing_prompt}
    */
    readonly parsingPrompt?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPrompt;
}
export declare function bedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfiguration | cdktn.IResolvable | undefined);
    private _modelArn?;
    get modelArn(): string;
    set modelArn(value: string);
    resetModelArn(): void;
    get modelArnInput(): string | undefined;
    private _parsingModality?;
    get parsingModality(): string;
    set parsingModality(value: string);
    resetParsingModality(): void;
    get parsingModalityInput(): string | undefined;
    private _parsingPrompt;
    get parsingPrompt(): BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPromptOutputReference;
    putParsingPrompt(value: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPrompt): void;
    resetParsingPrompt(): void;
    get parsingPromptInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationParsingPrompt | undefined;
}
export interface BedrockDataSourceVectorIngestionConfigurationParsingConfiguration {
    /**
    * Settings for a Bedrock Data Automation used to parse documents for a data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#bedrock_data_automation_configuration BedrockDataSource#bedrock_data_automation_configuration}
    */
    readonly bedrockDataAutomationConfiguration?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfiguration;
    /**
    * Settings for a foundation model used to parse documents for a data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#bedrock_foundation_model_configuration BedrockDataSource#bedrock_foundation_model_configuration}
    */
    readonly bedrockFoundationModelConfiguration?: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfiguration;
    /**
    * The parsing strategy for the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#parsing_strategy BedrockDataSource#parsing_strategy}
    */
    readonly parsingStrategy?: string;
}
export declare function bedrockDataSourceVectorIngestionConfigurationParsingConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationParsingConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationParsingConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfigurationParsingConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationParsingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfigurationParsingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfigurationParsingConfiguration | cdktn.IResolvable | undefined);
    private _bedrockDataAutomationConfiguration;
    get bedrockDataAutomationConfiguration(): BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfigurationOutputReference;
    putBedrockDataAutomationConfiguration(value: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfiguration): void;
    resetBedrockDataAutomationConfiguration(): void;
    get bedrockDataAutomationConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockDataAutomationConfiguration | undefined;
    private _bedrockFoundationModelConfiguration;
    get bedrockFoundationModelConfiguration(): BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfigurationOutputReference;
    putBedrockFoundationModelConfiguration(value: BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfiguration): void;
    resetBedrockFoundationModelConfiguration(): void;
    get bedrockFoundationModelConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationParsingConfigurationBedrockFoundationModelConfiguration | undefined;
    private _parsingStrategy?;
    get parsingStrategy(): string;
    set parsingStrategy(value: string);
    resetParsingStrategy(): void;
    get parsingStrategyInput(): string | undefined;
}
export interface BedrockDataSourceVectorIngestionConfiguration {
    /**
    * Details about how to chunk the documents in the data source. A chunk refers to an excerpt from a data source that is returned when the knowledge base that it belongs to is queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#chunking_configuration BedrockDataSource#chunking_configuration}
    */
    readonly chunkingConfiguration?: BedrockDataSourceVectorIngestionConfigurationChunkingConfiguration;
    /**
    * Additional Enrichment Configuration for example when using GraphRag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#context_enrichment_configuration BedrockDataSource#context_enrichment_configuration}
    */
    readonly contextEnrichmentConfiguration?: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfiguration;
    /**
    * Settings for customizing steps in the data source content ingestion pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#custom_transformation_configuration BedrockDataSource#custom_transformation_configuration}
    */
    readonly customTransformationConfiguration?: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfiguration;
    /**
    * Settings for parsing document contents
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#parsing_configuration BedrockDataSource#parsing_configuration}
    */
    readonly parsingConfiguration?: BedrockDataSourceVectorIngestionConfigurationParsingConfiguration;
}
export declare function bedrockDataSourceVectorIngestionConfigurationToTerraform(struct?: BedrockDataSourceVectorIngestionConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataSourceVectorIngestionConfigurationToHclTerraform(struct?: BedrockDataSourceVectorIngestionConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataSourceVectorIngestionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataSourceVectorIngestionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataSourceVectorIngestionConfiguration | cdktn.IResolvable | undefined);
    private _chunkingConfiguration;
    get chunkingConfiguration(): BedrockDataSourceVectorIngestionConfigurationChunkingConfigurationOutputReference;
    putChunkingConfiguration(value: BedrockDataSourceVectorIngestionConfigurationChunkingConfiguration): void;
    resetChunkingConfiguration(): void;
    get chunkingConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationChunkingConfiguration | undefined;
    private _contextEnrichmentConfiguration;
    get contextEnrichmentConfiguration(): BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfigurationOutputReference;
    putContextEnrichmentConfiguration(value: BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfiguration): void;
    resetContextEnrichmentConfiguration(): void;
    get contextEnrichmentConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationContextEnrichmentConfiguration | undefined;
    private _customTransformationConfiguration;
    get customTransformationConfiguration(): BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfigurationOutputReference;
    putCustomTransformationConfiguration(value: BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfiguration): void;
    resetCustomTransformationConfiguration(): void;
    get customTransformationConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationCustomTransformationConfiguration | undefined;
    private _parsingConfiguration;
    get parsingConfiguration(): BedrockDataSourceVectorIngestionConfigurationParsingConfigurationOutputReference;
    putParsingConfiguration(value: BedrockDataSourceVectorIngestionConfigurationParsingConfiguration): void;
    resetParsingConfiguration(): void;
    get parsingConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfigurationParsingConfiguration | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source awscc_bedrock_data_source}
*/
export declare class BedrockDataSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_data_source";
    /**
    * Generates CDKTN code for importing a BedrockDataSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockDataSource to import
    * @param importFromId The id of the existing BedrockDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/bedrock_data_source awscc_bedrock_data_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockDataSourceConfig
    */
    constructor(scope: Construct, id: string, config: BedrockDataSourceConfig);
    get createdAt(): string;
    private _dataDeletionPolicy?;
    get dataDeletionPolicy(): string;
    set dataDeletionPolicy(value: string);
    resetDataDeletionPolicy(): void;
    get dataDeletionPolicyInput(): string | undefined;
    private _dataSourceConfiguration;
    get dataSourceConfiguration(): BedrockDataSourceDataSourceConfigurationOutputReference;
    putDataSourceConfiguration(value: BedrockDataSourceDataSourceConfiguration): void;
    get dataSourceConfigurationInput(): cdktn.IResolvable | BedrockDataSourceDataSourceConfiguration | undefined;
    get dataSourceId(): string;
    get dataSourceStatus(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get failureReasons(): string[];
    get id(): string;
    private _knowledgeBaseId?;
    get knowledgeBaseId(): string;
    set knowledgeBaseId(value: string);
    get knowledgeBaseIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): BedrockDataSourceServerSideEncryptionConfigurationOutputReference;
    putServerSideEncryptionConfiguration(value: BedrockDataSourceServerSideEncryptionConfiguration): void;
    resetServerSideEncryptionConfiguration(): void;
    get serverSideEncryptionConfigurationInput(): cdktn.IResolvable | BedrockDataSourceServerSideEncryptionConfiguration | undefined;
    get updatedAt(): string;
    private _vectorIngestionConfiguration;
    get vectorIngestionConfiguration(): BedrockDataSourceVectorIngestionConfigurationOutputReference;
    putVectorIngestionConfiguration(value: BedrockDataSourceVectorIngestionConfiguration): void;
    resetVectorIngestionConfiguration(): void;
    get vectorIngestionConfigurationInput(): cdktn.IResolvable | BedrockDataSourceVectorIngestionConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
