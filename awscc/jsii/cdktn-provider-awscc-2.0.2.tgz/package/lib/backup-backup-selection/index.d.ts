/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupBackupSelectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#backup_plan_id BackupBackupSelection#backup_plan_id}
    */
    readonly backupPlanId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#backup_selection BackupBackupSelection#backup_selection}
    */
    readonly backupSelection: BackupBackupSelectionBackupSelection;
}
export interface BackupBackupSelectionBackupSelectionConditionsStringEquals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_key BackupBackupSelection#condition_key}
    */
    readonly conditionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_value BackupBackupSelection#condition_value}
    */
    readonly conditionValue?: string;
}
export declare function backupBackupSelectionBackupSelectionConditionsStringEqualsToTerraform(struct?: BackupBackupSelectionBackupSelectionConditionsStringEquals | cdktn.IResolvable): any;
export declare function backupBackupSelectionBackupSelectionConditionsStringEqualsToHclTerraform(struct?: BackupBackupSelectionBackupSelectionConditionsStringEquals | cdktn.IResolvable): any;
export declare class BackupBackupSelectionBackupSelectionConditionsStringEqualsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupSelectionBackupSelectionConditionsStringEquals | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupSelectionBackupSelectionConditionsStringEquals | cdktn.IResolvable | undefined);
    private _conditionKey?;
    get conditionKey(): string;
    set conditionKey(value: string);
    resetConditionKey(): void;
    get conditionKeyInput(): string | undefined;
    private _conditionValue?;
    get conditionValue(): string;
    set conditionValue(value: string);
    resetConditionValue(): void;
    get conditionValueInput(): string | undefined;
}
export declare class BackupBackupSelectionBackupSelectionConditionsStringEqualsList extends cdktn.ComplexList {
    internalValue?: BackupBackupSelectionBackupSelectionConditionsStringEquals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupSelectionBackupSelectionConditionsStringEqualsOutputReference;
}
export interface BackupBackupSelectionBackupSelectionConditionsStringLike {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_key BackupBackupSelection#condition_key}
    */
    readonly conditionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_value BackupBackupSelection#condition_value}
    */
    readonly conditionValue?: string;
}
export declare function backupBackupSelectionBackupSelectionConditionsStringLikeToTerraform(struct?: BackupBackupSelectionBackupSelectionConditionsStringLike | cdktn.IResolvable): any;
export declare function backupBackupSelectionBackupSelectionConditionsStringLikeToHclTerraform(struct?: BackupBackupSelectionBackupSelectionConditionsStringLike | cdktn.IResolvable): any;
export declare class BackupBackupSelectionBackupSelectionConditionsStringLikeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupSelectionBackupSelectionConditionsStringLike | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupSelectionBackupSelectionConditionsStringLike | cdktn.IResolvable | undefined);
    private _conditionKey?;
    get conditionKey(): string;
    set conditionKey(value: string);
    resetConditionKey(): void;
    get conditionKeyInput(): string | undefined;
    private _conditionValue?;
    get conditionValue(): string;
    set conditionValue(value: string);
    resetConditionValue(): void;
    get conditionValueInput(): string | undefined;
}
export declare class BackupBackupSelectionBackupSelectionConditionsStringLikeList extends cdktn.ComplexList {
    internalValue?: BackupBackupSelectionBackupSelectionConditionsStringLike[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupSelectionBackupSelectionConditionsStringLikeOutputReference;
}
export interface BackupBackupSelectionBackupSelectionConditionsStringNotEquals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_key BackupBackupSelection#condition_key}
    */
    readonly conditionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_value BackupBackupSelection#condition_value}
    */
    readonly conditionValue?: string;
}
export declare function backupBackupSelectionBackupSelectionConditionsStringNotEqualsToTerraform(struct?: BackupBackupSelectionBackupSelectionConditionsStringNotEquals | cdktn.IResolvable): any;
export declare function backupBackupSelectionBackupSelectionConditionsStringNotEqualsToHclTerraform(struct?: BackupBackupSelectionBackupSelectionConditionsStringNotEquals | cdktn.IResolvable): any;
export declare class BackupBackupSelectionBackupSelectionConditionsStringNotEqualsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupSelectionBackupSelectionConditionsStringNotEquals | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupSelectionBackupSelectionConditionsStringNotEquals | cdktn.IResolvable | undefined);
    private _conditionKey?;
    get conditionKey(): string;
    set conditionKey(value: string);
    resetConditionKey(): void;
    get conditionKeyInput(): string | undefined;
    private _conditionValue?;
    get conditionValue(): string;
    set conditionValue(value: string);
    resetConditionValue(): void;
    get conditionValueInput(): string | undefined;
}
export declare class BackupBackupSelectionBackupSelectionConditionsStringNotEqualsList extends cdktn.ComplexList {
    internalValue?: BackupBackupSelectionBackupSelectionConditionsStringNotEquals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupSelectionBackupSelectionConditionsStringNotEqualsOutputReference;
}
export interface BackupBackupSelectionBackupSelectionConditionsStringNotLike {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_key BackupBackupSelection#condition_key}
    */
    readonly conditionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_value BackupBackupSelection#condition_value}
    */
    readonly conditionValue?: string;
}
export declare function backupBackupSelectionBackupSelectionConditionsStringNotLikeToTerraform(struct?: BackupBackupSelectionBackupSelectionConditionsStringNotLike | cdktn.IResolvable): any;
export declare function backupBackupSelectionBackupSelectionConditionsStringNotLikeToHclTerraform(struct?: BackupBackupSelectionBackupSelectionConditionsStringNotLike | cdktn.IResolvable): any;
export declare class BackupBackupSelectionBackupSelectionConditionsStringNotLikeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupSelectionBackupSelectionConditionsStringNotLike | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupSelectionBackupSelectionConditionsStringNotLike | cdktn.IResolvable | undefined);
    private _conditionKey?;
    get conditionKey(): string;
    set conditionKey(value: string);
    resetConditionKey(): void;
    get conditionKeyInput(): string | undefined;
    private _conditionValue?;
    get conditionValue(): string;
    set conditionValue(value: string);
    resetConditionValue(): void;
    get conditionValueInput(): string | undefined;
}
export declare class BackupBackupSelectionBackupSelectionConditionsStringNotLikeList extends cdktn.ComplexList {
    internalValue?: BackupBackupSelectionBackupSelectionConditionsStringNotLike[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupSelectionBackupSelectionConditionsStringNotLikeOutputReference;
}
export interface BackupBackupSelectionBackupSelectionConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#string_equals BackupBackupSelection#string_equals}
    */
    readonly stringEquals?: BackupBackupSelectionBackupSelectionConditionsStringEquals[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#string_like BackupBackupSelection#string_like}
    */
    readonly stringLike?: BackupBackupSelectionBackupSelectionConditionsStringLike[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#string_not_equals BackupBackupSelection#string_not_equals}
    */
    readonly stringNotEquals?: BackupBackupSelectionBackupSelectionConditionsStringNotEquals[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#string_not_like BackupBackupSelection#string_not_like}
    */
    readonly stringNotLike?: BackupBackupSelectionBackupSelectionConditionsStringNotLike[] | cdktn.IResolvable;
}
export declare function backupBackupSelectionBackupSelectionConditionsToTerraform(struct?: BackupBackupSelectionBackupSelectionConditions | cdktn.IResolvable): any;
export declare function backupBackupSelectionBackupSelectionConditionsToHclTerraform(struct?: BackupBackupSelectionBackupSelectionConditions | cdktn.IResolvable): any;
export declare class BackupBackupSelectionBackupSelectionConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupBackupSelectionBackupSelectionConditions | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupSelectionBackupSelectionConditions | cdktn.IResolvable | undefined);
    private _stringEquals;
    get stringEquals(): BackupBackupSelectionBackupSelectionConditionsStringEqualsList;
    putStringEquals(value: BackupBackupSelectionBackupSelectionConditionsStringEquals[] | cdktn.IResolvable): void;
    resetStringEquals(): void;
    get stringEqualsInput(): cdktn.IResolvable | BackupBackupSelectionBackupSelectionConditionsStringEquals[] | undefined;
    private _stringLike;
    get stringLike(): BackupBackupSelectionBackupSelectionConditionsStringLikeList;
    putStringLike(value: BackupBackupSelectionBackupSelectionConditionsStringLike[] | cdktn.IResolvable): void;
    resetStringLike(): void;
    get stringLikeInput(): cdktn.IResolvable | BackupBackupSelectionBackupSelectionConditionsStringLike[] | undefined;
    private _stringNotEquals;
    get stringNotEquals(): BackupBackupSelectionBackupSelectionConditionsStringNotEqualsList;
    putStringNotEquals(value: BackupBackupSelectionBackupSelectionConditionsStringNotEquals[] | cdktn.IResolvable): void;
    resetStringNotEquals(): void;
    get stringNotEqualsInput(): cdktn.IResolvable | BackupBackupSelectionBackupSelectionConditionsStringNotEquals[] | undefined;
    private _stringNotLike;
    get stringNotLike(): BackupBackupSelectionBackupSelectionConditionsStringNotLikeList;
    putStringNotLike(value: BackupBackupSelectionBackupSelectionConditionsStringNotLike[] | cdktn.IResolvable): void;
    resetStringNotLike(): void;
    get stringNotLikeInput(): cdktn.IResolvable | BackupBackupSelectionBackupSelectionConditionsStringNotLike[] | undefined;
}
export interface BackupBackupSelectionBackupSelectionListOfTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_key BackupBackupSelection#condition_key}
    */
    readonly conditionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_type BackupBackupSelection#condition_type}
    */
    readonly conditionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#condition_value BackupBackupSelection#condition_value}
    */
    readonly conditionValue?: string;
}
export declare function backupBackupSelectionBackupSelectionListOfTagsToTerraform(struct?: BackupBackupSelectionBackupSelectionListOfTags | cdktn.IResolvable): any;
export declare function backupBackupSelectionBackupSelectionListOfTagsToHclTerraform(struct?: BackupBackupSelectionBackupSelectionListOfTags | cdktn.IResolvable): any;
export declare class BackupBackupSelectionBackupSelectionListOfTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupBackupSelectionBackupSelectionListOfTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupSelectionBackupSelectionListOfTags | cdktn.IResolvable | undefined);
    private _conditionKey?;
    get conditionKey(): string;
    set conditionKey(value: string);
    resetConditionKey(): void;
    get conditionKeyInput(): string | undefined;
    private _conditionType?;
    get conditionType(): string;
    set conditionType(value: string);
    resetConditionType(): void;
    get conditionTypeInput(): string | undefined;
    private _conditionValue?;
    get conditionValue(): string;
    set conditionValue(value: string);
    resetConditionValue(): void;
    get conditionValueInput(): string | undefined;
}
export declare class BackupBackupSelectionBackupSelectionListOfTagsList extends cdktn.ComplexList {
    internalValue?: BackupBackupSelectionBackupSelectionListOfTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupBackupSelectionBackupSelectionListOfTagsOutputReference;
}
export interface BackupBackupSelectionBackupSelection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#conditions BackupBackupSelection#conditions}
    */
    readonly conditions?: BackupBackupSelectionBackupSelectionConditions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#iam_role_arn BackupBackupSelection#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#list_of_tags BackupBackupSelection#list_of_tags}
    */
    readonly listOfTags?: BackupBackupSelectionBackupSelectionListOfTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#not_resources BackupBackupSelection#not_resources}
    */
    readonly notResources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#resources BackupBackupSelection#resources}
    */
    readonly resources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#selection_name BackupBackupSelection#selection_name}
    */
    readonly selectionName: string;
}
export declare function backupBackupSelectionBackupSelectionToTerraform(struct?: BackupBackupSelectionBackupSelection | cdktn.IResolvable): any;
export declare function backupBackupSelectionBackupSelectionToHclTerraform(struct?: BackupBackupSelectionBackupSelection | cdktn.IResolvable): any;
export declare class BackupBackupSelectionBackupSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupBackupSelectionBackupSelection | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupSelectionBackupSelection | cdktn.IResolvable | undefined);
    private _conditions;
    get conditions(): BackupBackupSelectionBackupSelectionConditionsOutputReference;
    putConditions(value: BackupBackupSelectionBackupSelectionConditions): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | BackupBackupSelectionBackupSelectionConditions | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    private _listOfTags;
    get listOfTags(): BackupBackupSelectionBackupSelectionListOfTagsList;
    putListOfTags(value: BackupBackupSelectionBackupSelectionListOfTags[] | cdktn.IResolvable): void;
    resetListOfTags(): void;
    get listOfTagsInput(): cdktn.IResolvable | BackupBackupSelectionBackupSelectionListOfTags[] | undefined;
    private _notResources?;
    get notResources(): string[];
    set notResources(value: string[]);
    resetNotResources(): void;
    get notResourcesInput(): string[] | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _selectionName?;
    get selectionName(): string;
    set selectionName(value: string);
    get selectionNameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection awscc_backup_backup_selection}
*/
export declare class BackupBackupSelection extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_backup_selection";
    /**
    * Generates CDKTN code for importing a BackupBackupSelection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupBackupSelection to import
    * @param importFromId The id of the existing BackupBackupSelection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupBackupSelection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/backup_backup_selection awscc_backup_backup_selection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupBackupSelectionConfig
    */
    constructor(scope: Construct, id: string, config: BackupBackupSelectionConfig);
    private _backupPlanId?;
    get backupPlanId(): string;
    set backupPlanId(value: string);
    get backupPlanIdInput(): string | undefined;
    private _backupSelection;
    get backupSelection(): BackupBackupSelectionBackupSelectionOutputReference;
    putBackupSelection(value: BackupBackupSelectionBackupSelection): void;
    get backupSelectionInput(): cdktn.IResolvable | BackupBackupSelectionBackupSelection | undefined;
    get backupSelectionId(): string;
    get id(): string;
    get selectionId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
