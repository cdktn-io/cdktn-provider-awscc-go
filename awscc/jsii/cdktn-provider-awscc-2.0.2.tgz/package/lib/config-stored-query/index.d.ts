/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigStoredQueryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query#query_description ConfigStoredQuery#query_description}
    */
    readonly queryDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query#query_expression ConfigStoredQuery#query_expression}
    */
    readonly queryExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query#query_name ConfigStoredQuery#query_name}
    */
    readonly queryName: string;
    /**
    * The tags for the stored query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query#tags ConfigStoredQuery#tags}
    */
    readonly tags?: ConfigStoredQueryTags[] | cdktn.IResolvable;
}
export interface ConfigStoredQueryTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query#key ConfigStoredQuery#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query#value ConfigStoredQuery#value}
    */
    readonly value?: string;
}
export declare function configStoredQueryTagsToTerraform(struct?: ConfigStoredQueryTags | cdktn.IResolvable): any;
export declare function configStoredQueryTagsToHclTerraform(struct?: ConfigStoredQueryTags | cdktn.IResolvable): any;
export declare class ConfigStoredQueryTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigStoredQueryTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigStoredQueryTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConfigStoredQueryTagsList extends cdktn.ComplexList {
    internalValue?: ConfigStoredQueryTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigStoredQueryTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query awscc_config_stored_query}
*/
export declare class ConfigStoredQuery extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_stored_query";
    /**
    * Generates CDKTN code for importing a ConfigStoredQuery resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigStoredQuery to import
    * @param importFromId The id of the existing ConfigStoredQuery that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigStoredQuery to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/config_stored_query awscc_config_stored_query} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigStoredQueryConfig
    */
    constructor(scope: Construct, id: string, config: ConfigStoredQueryConfig);
    get id(): string;
    get queryArn(): string;
    private _queryDescription?;
    get queryDescription(): string;
    set queryDescription(value: string);
    resetQueryDescription(): void;
    get queryDescriptionInput(): string | undefined;
    private _queryExpression?;
    get queryExpression(): string;
    set queryExpression(value: string);
    get queryExpressionInput(): string | undefined;
    get queryId(): string;
    private _queryName?;
    get queryName(): string;
    set queryName(value: string);
    get queryNameInput(): string | undefined;
    private _tags;
    get tags(): ConfigStoredQueryTagsList;
    putTags(value: ConfigStoredQueryTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConfigStoredQueryTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
