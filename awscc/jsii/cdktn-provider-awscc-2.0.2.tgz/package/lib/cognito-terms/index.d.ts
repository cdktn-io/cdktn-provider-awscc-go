/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoTermsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms#client_id CognitoTerms#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms#enforcement CognitoTerms#enforcement}
    */
    readonly enforcement: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms#links CognitoTerms#links}
    */
    readonly links: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms#terms_name CognitoTerms#terms_name}
    */
    readonly termsName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms#terms_source CognitoTerms#terms_source}
    */
    readonly termsSource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms#user_pool_id CognitoTerms#user_pool_id}
    */
    readonly userPoolId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms awscc_cognito_terms}
*/
export declare class CognitoTerms extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_terms";
    /**
    * Generates CDKTN code for importing a CognitoTerms resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoTerms to import
    * @param importFromId The id of the existing CognitoTerms that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoTerms to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.110.0/docs/resources/cognito_terms awscc_cognito_terms} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoTermsConfig
    */
    constructor(scope: Construct, id: string, config: CognitoTermsConfig);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _enforcement?;
    get enforcement(): string;
    set enforcement(value: string);
    get enforcementInput(): string | undefined;
    get id(): string;
    private _links?;
    get links(): {
        [key: string]: string;
    };
    set links(value: {
        [key: string]: string;
    });
    get linksInput(): {
        [key: string]: string;
    } | undefined;
    get termsId(): string;
    private _termsName?;
    get termsName(): string;
    set termsName(value: string);
    get termsNameInput(): string | undefined;
    private _termsSource?;
    get termsSource(): string;
    set termsSource(value: string);
    get termsSourceInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
