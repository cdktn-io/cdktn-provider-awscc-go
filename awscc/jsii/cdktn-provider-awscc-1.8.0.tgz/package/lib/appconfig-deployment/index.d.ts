/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#application_id AppconfigDeployment#application_id}
    */
    readonly applicationId: string;
    /**
    * The configuration profile ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#configuration_profile_id AppconfigDeployment#configuration_profile_id}
    */
    readonly configurationProfileId: string;
    /**
    * The configuration version to deploy. If deploying an AWS AppConfig hosted configuration version, you can specify either the version number or version label. For all other configurations, you must specify the version number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#configuration_version AppconfigDeployment#configuration_version}
    */
    readonly configurationVersion: string;
    /**
    * The deployment strategy ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#deployment_strategy_id AppconfigDeployment#deployment_strategy_id}
    */
    readonly deploymentStrategyId: string;
    /**
    * A description of the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#description AppconfigDeployment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#dynamic_extension_parameters AppconfigDeployment#dynamic_extension_parameters}
    */
    readonly dynamicExtensionParameters?: AppconfigDeploymentDynamicExtensionParameters[] | cdktn.IResolvable;
    /**
    * The environment ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#environment_id AppconfigDeployment#environment_id}
    */
    readonly environmentId: string;
    /**
    * The AWS Key Management Service key identifier (key ID, key alias, or key ARN) provided when the resource was created or updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#kms_key_identifier AppconfigDeployment#kms_key_identifier}
    */
    readonly kmsKeyIdentifier?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#tags AppconfigDeployment#tags}
    */
    readonly tags?: AppconfigDeploymentTags[] | cdktn.IResolvable;
}
export interface AppconfigDeploymentDynamicExtensionParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#extension_reference AppconfigDeployment#extension_reference}
    */
    readonly extensionReference?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#parameter_name AppconfigDeployment#parameter_name}
    */
    readonly parameterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#parameter_value AppconfigDeployment#parameter_value}
    */
    readonly parameterValue?: string;
}
export declare function appconfigDeploymentDynamicExtensionParametersToTerraform(struct?: AppconfigDeploymentDynamicExtensionParameters | cdktn.IResolvable): any;
export declare function appconfigDeploymentDynamicExtensionParametersToHclTerraform(struct?: AppconfigDeploymentDynamicExtensionParameters | cdktn.IResolvable): any;
export declare class AppconfigDeploymentDynamicExtensionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigDeploymentDynamicExtensionParameters | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigDeploymentDynamicExtensionParameters | cdktn.IResolvable | undefined);
    private _extensionReference?;
    get extensionReference(): string;
    set extensionReference(value: string);
    resetExtensionReference(): void;
    get extensionReferenceInput(): string | undefined;
    private _parameterName?;
    get parameterName(): string;
    set parameterName(value: string);
    resetParameterName(): void;
    get parameterNameInput(): string | undefined;
    private _parameterValue?;
    get parameterValue(): string;
    set parameterValue(value: string);
    resetParameterValue(): void;
    get parameterValueInput(): string | undefined;
}
export declare class AppconfigDeploymentDynamicExtensionParametersList extends cdktn.ComplexList {
    internalValue?: AppconfigDeploymentDynamicExtensionParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigDeploymentDynamicExtensionParametersOutputReference;
}
export interface AppconfigDeploymentTags {
    /**
    * The key-value string map. The valid character set is [a-zA-Z1-9+-=._:/]. The tag key can be up to 128 characters and must not start with aws:.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#key AppconfigDeployment#key}
    */
    readonly key?: string;
    /**
    * The tag value can be up to 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#value AppconfigDeployment#value}
    */
    readonly value?: string;
}
export declare function appconfigDeploymentTagsToTerraform(struct?: AppconfigDeploymentTags | cdktn.IResolvable): any;
export declare function appconfigDeploymentTagsToHclTerraform(struct?: AppconfigDeploymentTags | cdktn.IResolvable): any;
export declare class AppconfigDeploymentTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigDeploymentTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigDeploymentTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppconfigDeploymentTagsList extends cdktn.ComplexList {
    internalValue?: AppconfigDeploymentTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigDeploymentTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment awscc_appconfig_deployment}
*/
export declare class AppconfigDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appconfig_deployment";
    /**
    * Generates CDKTN code for importing a AppconfigDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigDeployment to import
    * @param importFromId The id of the existing AppconfigDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_deployment awscc_appconfig_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: AppconfigDeploymentConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _configurationProfileId?;
    get configurationProfileId(): string;
    set configurationProfileId(value: string);
    get configurationProfileIdInput(): string | undefined;
    private _configurationVersion?;
    get configurationVersion(): string;
    set configurationVersion(value: string);
    get configurationVersionInput(): string | undefined;
    get deploymentNumber(): string;
    private _deploymentStrategyId?;
    get deploymentStrategyId(): string;
    set deploymentStrategyId(value: string);
    get deploymentStrategyIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dynamicExtensionParameters;
    get dynamicExtensionParameters(): AppconfigDeploymentDynamicExtensionParametersList;
    putDynamicExtensionParameters(value: AppconfigDeploymentDynamicExtensionParameters[] | cdktn.IResolvable): void;
    resetDynamicExtensionParameters(): void;
    get dynamicExtensionParametersInput(): cdktn.IResolvable | AppconfigDeploymentDynamicExtensionParameters[] | undefined;
    private _environmentId?;
    get environmentId(): string;
    set environmentId(value: string);
    get environmentIdInput(): string | undefined;
    get id(): string;
    private _kmsKeyIdentifier?;
    get kmsKeyIdentifier(): string;
    set kmsKeyIdentifier(value: string);
    resetKmsKeyIdentifier(): void;
    get kmsKeyIdentifierInput(): string | undefined;
    get state(): string;
    private _tags;
    get tags(): AppconfigDeploymentTagsList;
    putTags(value: AppconfigDeploymentTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppconfigDeploymentTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
