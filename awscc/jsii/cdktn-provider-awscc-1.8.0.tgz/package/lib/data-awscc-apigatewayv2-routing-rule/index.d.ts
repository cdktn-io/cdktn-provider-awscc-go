/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2RoutingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_routing_rule#id DataAwsccApigatewayv2RoutingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2RoutingRuleActionsInvokeApi {
}
export declare function dataAwsccApigatewayv2RoutingRuleActionsInvokeApiToTerraform(struct?: DataAwsccApigatewayv2RoutingRuleActionsInvokeApi): any;
export declare function dataAwsccApigatewayv2RoutingRuleActionsInvokeApiToHclTerraform(struct?: DataAwsccApigatewayv2RoutingRuleActionsInvokeApi): any;
export declare class DataAwsccApigatewayv2RoutingRuleActionsInvokeApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2RoutingRuleActionsInvokeApi | undefined;
    set internalValue(value: DataAwsccApigatewayv2RoutingRuleActionsInvokeApi | undefined);
    get apiId(): string;
    get stage(): string;
    get stripBasePath(): cdktn.IResolvable;
}
export interface DataAwsccApigatewayv2RoutingRuleActions {
}
export declare function dataAwsccApigatewayv2RoutingRuleActionsToTerraform(struct?: DataAwsccApigatewayv2RoutingRuleActions): any;
export declare function dataAwsccApigatewayv2RoutingRuleActionsToHclTerraform(struct?: DataAwsccApigatewayv2RoutingRuleActions): any;
export declare class DataAwsccApigatewayv2RoutingRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayv2RoutingRuleActions | undefined;
    set internalValue(value: DataAwsccApigatewayv2RoutingRuleActions | undefined);
    private _invokeApi;
    get invokeApi(): DataAwsccApigatewayv2RoutingRuleActionsInvokeApiOutputReference;
}
export declare class DataAwsccApigatewayv2RoutingRuleActionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayv2RoutingRuleActionsOutputReference;
}
export interface DataAwsccApigatewayv2RoutingRuleConditionsMatchBasePaths {
}
export declare function dataAwsccApigatewayv2RoutingRuleConditionsMatchBasePathsToTerraform(struct?: DataAwsccApigatewayv2RoutingRuleConditionsMatchBasePaths): any;
export declare function dataAwsccApigatewayv2RoutingRuleConditionsMatchBasePathsToHclTerraform(struct?: DataAwsccApigatewayv2RoutingRuleConditionsMatchBasePaths): any;
export declare class DataAwsccApigatewayv2RoutingRuleConditionsMatchBasePathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2RoutingRuleConditionsMatchBasePaths | undefined;
    set internalValue(value: DataAwsccApigatewayv2RoutingRuleConditionsMatchBasePaths | undefined);
    get anyOf(): string[];
}
export interface DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOf {
}
export declare function dataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOfToTerraform(struct?: DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOf): any;
export declare function dataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOfToHclTerraform(struct?: DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOf): any;
export declare class DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOf | undefined;
    set internalValue(value: DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOf | undefined);
    get header(): string;
    get valueGlob(): string;
}
export declare class DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOfList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOfOutputReference;
}
export interface DataAwsccApigatewayv2RoutingRuleConditionsMatchHeaders {
}
export declare function dataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersToTerraform(struct?: DataAwsccApigatewayv2RoutingRuleConditionsMatchHeaders): any;
export declare function dataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersToHclTerraform(struct?: DataAwsccApigatewayv2RoutingRuleConditionsMatchHeaders): any;
export declare class DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2RoutingRuleConditionsMatchHeaders | undefined;
    set internalValue(value: DataAwsccApigatewayv2RoutingRuleConditionsMatchHeaders | undefined);
    private _anyOf;
    get anyOf(): DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersAnyOfList;
}
export interface DataAwsccApigatewayv2RoutingRuleConditions {
}
export declare function dataAwsccApigatewayv2RoutingRuleConditionsToTerraform(struct?: DataAwsccApigatewayv2RoutingRuleConditions): any;
export declare function dataAwsccApigatewayv2RoutingRuleConditionsToHclTerraform(struct?: DataAwsccApigatewayv2RoutingRuleConditions): any;
export declare class DataAwsccApigatewayv2RoutingRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayv2RoutingRuleConditions | undefined;
    set internalValue(value: DataAwsccApigatewayv2RoutingRuleConditions | undefined);
    private _matchBasePaths;
    get matchBasePaths(): DataAwsccApigatewayv2RoutingRuleConditionsMatchBasePathsOutputReference;
    private _matchHeaders;
    get matchHeaders(): DataAwsccApigatewayv2RoutingRuleConditionsMatchHeadersOutputReference;
}
export declare class DataAwsccApigatewayv2RoutingRuleConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayv2RoutingRuleConditionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_routing_rule awscc_apigatewayv2_routing_rule}
*/
export declare class DataAwsccApigatewayv2RoutingRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_routing_rule";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2RoutingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2RoutingRule to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2RoutingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_routing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2RoutingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_routing_rule awscc_apigatewayv2_routing_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2RoutingRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2RoutingRuleConfig);
    private _actions;
    get actions(): DataAwsccApigatewayv2RoutingRuleActionsList;
    private _conditions;
    get conditions(): DataAwsccApigatewayv2RoutingRuleConditionsList;
    get domainNameArn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get priority(): number;
    get routingRuleArn(): string;
    get routingRuleId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
