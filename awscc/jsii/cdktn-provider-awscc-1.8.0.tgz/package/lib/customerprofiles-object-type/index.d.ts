/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesObjectTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether a profile should be created when data is received.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#allow_profile_creation CustomerprofilesObjectType#allow_profile_creation}
    */
    readonly allowProfileCreation?: boolean | cdktn.IResolvable;
    /**
    * Description of the profile object type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#description CustomerprofilesObjectType#description}
    */
    readonly description: string;
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#domain_name CustomerprofilesObjectType#domain_name}
    */
    readonly domainName: string;
    /**
    * The default encryption key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#encryption_key CustomerprofilesObjectType#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * The default number of days until the data within the domain expires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#expiration_days CustomerprofilesObjectType#expiration_days}
    */
    readonly expirationDays?: number;
    /**
    * A list of the name and ObjectType field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#fields CustomerprofilesObjectType#fields}
    */
    readonly fields?: CustomerprofilesObjectTypeFields[] | cdktn.IResolvable;
    /**
    * A list of unique keys that can be used to map data to the profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#keys CustomerprofilesObjectType#keys}
    */
    readonly keys?: CustomerprofilesObjectTypeKeys[] | cdktn.IResolvable;
    /**
    * The maximum number of profile objects for this object type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#max_profile_object_count CustomerprofilesObjectType#max_profile_object_count}
    */
    readonly maxProfileObjectCount?: number;
    /**
    * The name of the profile object type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#object_type_name CustomerprofilesObjectType#object_type_name}
    */
    readonly objectTypeName: string;
    /**
    * The format of your sourceLastUpdatedTimestamp that was previously set up.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#source_last_updated_timestamp_format CustomerprofilesObjectType#source_last_updated_timestamp_format}
    */
    readonly sourceLastUpdatedTimestampFormat?: string;
    /**
    * Defines the priority order of object types. Lower value indicates higher priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#source_priority CustomerprofilesObjectType#source_priority}
    */
    readonly sourcePriority?: number;
    /**
    * The tags (keys and values) associated with the integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#tags CustomerprofilesObjectType#tags}
    */
    readonly tags?: CustomerprofilesObjectTypeTags[] | cdktn.IResolvable;
    /**
    * A unique identifier for the object template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#template_id CustomerprofilesObjectType#template_id}
    */
    readonly templateId?: string;
}
export interface CustomerprofilesObjectTypeFieldsObjectTypeField {
    /**
    * The content type of the field. Used for determining equality when searching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#content_type CustomerprofilesObjectType#content_type}
    */
    readonly contentType?: string;
    /**
    * A field of a ProfileObject. For example: _source.FirstName, where "_source" is a ProfileObjectType of a Zendesk user and "FirstName" is a field in that ObjectType.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#source CustomerprofilesObjectType#source}
    */
    readonly source?: string;
    /**
    * The location of the data in the standard ProfileObject model. For example: _profile.Address.PostalCode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#target CustomerprofilesObjectType#target}
    */
    readonly target?: string;
}
export declare function customerprofilesObjectTypeFieldsObjectTypeFieldToTerraform(struct?: CustomerprofilesObjectTypeFieldsObjectTypeField | cdktn.IResolvable): any;
export declare function customerprofilesObjectTypeFieldsObjectTypeFieldToHclTerraform(struct?: CustomerprofilesObjectTypeFieldsObjectTypeField | cdktn.IResolvable): any;
export declare class CustomerprofilesObjectTypeFieldsObjectTypeFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesObjectTypeFieldsObjectTypeField | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesObjectTypeFieldsObjectTypeField | cdktn.IResolvable | undefined);
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
}
export interface CustomerprofilesObjectTypeFields {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#name CustomerprofilesObjectType#name}
    */
    readonly name?: string;
    /**
    * Represents a field in a ProfileObjectType.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#object_type_field CustomerprofilesObjectType#object_type_field}
    */
    readonly objectTypeField?: CustomerprofilesObjectTypeFieldsObjectTypeField;
}
export declare function customerprofilesObjectTypeFieldsToTerraform(struct?: CustomerprofilesObjectTypeFields | cdktn.IResolvable): any;
export declare function customerprofilesObjectTypeFieldsToHclTerraform(struct?: CustomerprofilesObjectTypeFields | cdktn.IResolvable): any;
export declare class CustomerprofilesObjectTypeFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesObjectTypeFields | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesObjectTypeFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _objectTypeField;
    get objectTypeField(): CustomerprofilesObjectTypeFieldsObjectTypeFieldOutputReference;
    putObjectTypeField(value: CustomerprofilesObjectTypeFieldsObjectTypeField): void;
    resetObjectTypeField(): void;
    get objectTypeFieldInput(): cdktn.IResolvable | CustomerprofilesObjectTypeFieldsObjectTypeField | undefined;
}
export declare class CustomerprofilesObjectTypeFieldsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesObjectTypeFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesObjectTypeFieldsOutputReference;
}
export interface CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct {
    /**
    * The reference for the key name of the fields map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#field_names CustomerprofilesObjectType#field_names}
    */
    readonly fieldNames?: string[];
    /**
    * The types of keys that a ProfileObject can have. Each ProfileObject can have only 1 UNIQUE key but multiple PROFILE keys. PROFILE means that this key can be used to tie an object to a PROFILE. UNIQUE means that it can be used to uniquely identify an object. If a key a is marked as SECONDARY, it will be used to search for profiles after all other PROFILE keys have been searched. A LOOKUP_ONLY key is only used to match a profile but is not persisted to be used for searching of the profile. A NEW_ONLY key is only used if the profile does not already exist before the object is ingested, otherwise it is only used for matching objects to profiles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#standard_identifiers CustomerprofilesObjectType#standard_identifiers}
    */
    readonly standardIdentifiers?: string[];
}
export declare function customerprofilesObjectTypeKeysObjectTypeKeyListStructToTerraform(struct?: CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct | cdktn.IResolvable): any;
export declare function customerprofilesObjectTypeKeysObjectTypeKeyListStructToHclTerraform(struct?: CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct | cdktn.IResolvable): any;
export declare class CustomerprofilesObjectTypeKeysObjectTypeKeyListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct | cdktn.IResolvable | undefined);
    private _fieldNames?;
    get fieldNames(): string[];
    set fieldNames(value: string[]);
    resetFieldNames(): void;
    get fieldNamesInput(): string[] | undefined;
    private _standardIdentifiers?;
    get standardIdentifiers(): string[];
    set standardIdentifiers(value: string[]);
    resetStandardIdentifiers(): void;
    get standardIdentifiersInput(): string[] | undefined;
}
export declare class CustomerprofilesObjectTypeKeysObjectTypeKeyListStructList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesObjectTypeKeysObjectTypeKeyListStructOutputReference;
}
export interface CustomerprofilesObjectTypeKeys {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#name CustomerprofilesObjectType#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#object_type_key_list CustomerprofilesObjectType#object_type_key_list}
    */
    readonly objectTypeKeyList?: CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct[] | cdktn.IResolvable;
}
export declare function customerprofilesObjectTypeKeysToTerraform(struct?: CustomerprofilesObjectTypeKeys | cdktn.IResolvable): any;
export declare function customerprofilesObjectTypeKeysToHclTerraform(struct?: CustomerprofilesObjectTypeKeys | cdktn.IResolvable): any;
export declare class CustomerprofilesObjectTypeKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesObjectTypeKeys | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesObjectTypeKeys | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _objectTypeKeyList;
    get objectTypeKeyList(): CustomerprofilesObjectTypeKeysObjectTypeKeyListStructList;
    putObjectTypeKeyList(value: CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct[] | cdktn.IResolvable): void;
    resetObjectTypeKeyList(): void;
    get objectTypeKeyListInput(): cdktn.IResolvable | CustomerprofilesObjectTypeKeysObjectTypeKeyListStruct[] | undefined;
}
export declare class CustomerprofilesObjectTypeKeysList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesObjectTypeKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesObjectTypeKeysOutputReference;
}
export interface CustomerprofilesObjectTypeTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#key CustomerprofilesObjectType#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#value CustomerprofilesObjectType#value}
    */
    readonly value?: string;
}
export declare function customerprofilesObjectTypeTagsToTerraform(struct?: CustomerprofilesObjectTypeTags | cdktn.IResolvable): any;
export declare function customerprofilesObjectTypeTagsToHclTerraform(struct?: CustomerprofilesObjectTypeTags | cdktn.IResolvable): any;
export declare class CustomerprofilesObjectTypeTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesObjectTypeTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesObjectTypeTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesObjectTypeTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesObjectTypeTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesObjectTypeTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type awscc_customerprofiles_object_type}
*/
export declare class CustomerprofilesObjectType extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_object_type";
    /**
    * Generates CDKTN code for importing a CustomerprofilesObjectType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesObjectType to import
    * @param importFromId The id of the existing CustomerprofilesObjectType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesObjectType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/customerprofiles_object_type awscc_customerprofiles_object_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesObjectTypeConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesObjectTypeConfig);
    private _allowProfileCreation?;
    get allowProfileCreation(): boolean | cdktn.IResolvable;
    set allowProfileCreation(value: boolean | cdktn.IResolvable);
    resetAllowProfileCreation(): void;
    get allowProfileCreationInput(): boolean | cdktn.IResolvable | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _expirationDays?;
    get expirationDays(): number;
    set expirationDays(value: number);
    resetExpirationDays(): void;
    get expirationDaysInput(): number | undefined;
    private _fields;
    get fields(): CustomerprofilesObjectTypeFieldsList;
    putFields(value: CustomerprofilesObjectTypeFields[] | cdktn.IResolvable): void;
    resetFields(): void;
    get fieldsInput(): cdktn.IResolvable | CustomerprofilesObjectTypeFields[] | undefined;
    get id(): string;
    private _keys;
    get keys(): CustomerprofilesObjectTypeKeysList;
    putKeys(value: CustomerprofilesObjectTypeKeys[] | cdktn.IResolvable): void;
    resetKeys(): void;
    get keysInput(): cdktn.IResolvable | CustomerprofilesObjectTypeKeys[] | undefined;
    get lastUpdatedAt(): string;
    get maxAvailableProfileObjectCount(): number;
    private _maxProfileObjectCount?;
    get maxProfileObjectCount(): number;
    set maxProfileObjectCount(value: number);
    resetMaxProfileObjectCount(): void;
    get maxProfileObjectCountInput(): number | undefined;
    private _objectTypeName?;
    get objectTypeName(): string;
    set objectTypeName(value: string);
    get objectTypeNameInput(): string | undefined;
    private _sourceLastUpdatedTimestampFormat?;
    get sourceLastUpdatedTimestampFormat(): string;
    set sourceLastUpdatedTimestampFormat(value: string);
    resetSourceLastUpdatedTimestampFormat(): void;
    get sourceLastUpdatedTimestampFormatInput(): string | undefined;
    private _sourcePriority?;
    get sourcePriority(): number;
    set sourcePriority(value: number);
    resetSourcePriority(): void;
    get sourcePriorityInput(): number | undefined;
    private _tags;
    get tags(): CustomerprofilesObjectTypeTagsList;
    putTags(value: CustomerprofilesObjectTypeTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesObjectTypeTags[] | undefined;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    resetTemplateId(): void;
    get templateIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
