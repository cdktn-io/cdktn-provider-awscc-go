/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodepipelineCustomActionTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * The category of the custom action, such as a build action or a test action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#category CodepipelineCustomActionType#category}
    */
    readonly category: string;
    /**
    * The configuration properties for the custom action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#configuration_properties CodepipelineCustomActionType#configuration_properties}
    */
    readonly configurationProperties?: CodepipelineCustomActionTypeConfigurationProperties[] | cdktn.IResolvable;
    /**
    * The details of the input artifact for the action, such as its commit ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#input_artifact_details CodepipelineCustomActionType#input_artifact_details}
    */
    readonly inputArtifactDetails: CodepipelineCustomActionTypeInputArtifactDetails;
    /**
    * The details of the output artifact of the action, such as its commit ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#output_artifact_details CodepipelineCustomActionType#output_artifact_details}
    */
    readonly outputArtifactDetails: CodepipelineCustomActionTypeOutputArtifactDetails;
    /**
    * The provider of the service used in the custom action, such as AWS CodeDeploy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#provider_name CodepipelineCustomActionType#provider_name}
    */
    readonly providerName: string;
    /**
    * URLs that provide users information about this custom action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#settings CodepipelineCustomActionType#settings}
    */
    readonly settings?: CodepipelineCustomActionTypeSettings;
    /**
    * Any tags assigned to the custom action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#tags CodepipelineCustomActionType#tags}
    */
    readonly tags?: CodepipelineCustomActionTypeTags[] | cdktn.IResolvable;
    /**
    * The version identifier of the custom action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#version CodepipelineCustomActionType#version}
    */
    readonly version: string;
}
export interface CodepipelineCustomActionTypeConfigurationProperties {
    /**
    * The description of the action configuration property that is displayed to users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#description CodepipelineCustomActionType#description}
    */
    readonly description?: string;
    /**
    * Whether the configuration property is a key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#key CodepipelineCustomActionType#key}
    */
    readonly key?: boolean | cdktn.IResolvable;
    /**
    * The name of the action configuration property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#name CodepipelineCustomActionType#name}
    */
    readonly name?: string;
    /**
    * Indicates that the property is used with PollForJobs. When creating a custom action, an action can have up to one queryable property. If it has one, that property must be both required and not secret.If you create a pipeline with a custom action type, and that custom action contains a queryable property, the value for that configuration property is subject to other restrictions. The value must be less than or equal to twenty (20) characters. The value can contain only alphanumeric characters, underscores, and hyphens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#queryable CodepipelineCustomActionType#queryable}
    */
    readonly queryable?: boolean | cdktn.IResolvable;
    /**
    * Whether the configuration property is a required value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#required CodepipelineCustomActionType#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Whether the configuration property is secret. Secrets are hidden from all calls except for GetJobDetails, GetThirdPartyJobDetails, PollForJobs, and PollForThirdPartyJobs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#secret CodepipelineCustomActionType#secret}
    */
    readonly secret?: boolean | cdktn.IResolvable;
    /**
    * The type of the configuration property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#type CodepipelineCustomActionType#type}
    */
    readonly type?: string;
}
export declare function codepipelineCustomActionTypeConfigurationPropertiesToTerraform(struct?: CodepipelineCustomActionTypeConfigurationProperties | cdktn.IResolvable): any;
export declare function codepipelineCustomActionTypeConfigurationPropertiesToHclTerraform(struct?: CodepipelineCustomActionTypeConfigurationProperties | cdktn.IResolvable): any;
export declare class CodepipelineCustomActionTypeConfigurationPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelineCustomActionTypeConfigurationProperties | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelineCustomActionTypeConfigurationProperties | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _key?;
    get key(): boolean | cdktn.IResolvable;
    set key(value: boolean | cdktn.IResolvable);
    resetKey(): void;
    get keyInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _queryable?;
    get queryable(): boolean | cdktn.IResolvable;
    set queryable(value: boolean | cdktn.IResolvable);
    resetQueryable(): void;
    get queryableInput(): boolean | cdktn.IResolvable | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _secret?;
    get secret(): boolean | cdktn.IResolvable;
    set secret(value: boolean | cdktn.IResolvable);
    resetSecret(): void;
    get secretInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CodepipelineCustomActionTypeConfigurationPropertiesList extends cdktn.ComplexList {
    internalValue?: CodepipelineCustomActionTypeConfigurationProperties[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelineCustomActionTypeConfigurationPropertiesOutputReference;
}
export interface CodepipelineCustomActionTypeInputArtifactDetails {
    /**
    * The maximum number of artifacts allowed for the action type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#maximum_count CodepipelineCustomActionType#maximum_count}
    */
    readonly maximumCount: number;
    /**
    * The minimum number of artifacts allowed for the action type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#minimum_count CodepipelineCustomActionType#minimum_count}
    */
    readonly minimumCount: number;
}
export declare function codepipelineCustomActionTypeInputArtifactDetailsToTerraform(struct?: CodepipelineCustomActionTypeInputArtifactDetails | cdktn.IResolvable): any;
export declare function codepipelineCustomActionTypeInputArtifactDetailsToHclTerraform(struct?: CodepipelineCustomActionTypeInputArtifactDetails | cdktn.IResolvable): any;
export declare class CodepipelineCustomActionTypeInputArtifactDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelineCustomActionTypeInputArtifactDetails | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelineCustomActionTypeInputArtifactDetails | cdktn.IResolvable | undefined);
    private _maximumCount?;
    get maximumCount(): number;
    set maximumCount(value: number);
    get maximumCountInput(): number | undefined;
    private _minimumCount?;
    get minimumCount(): number;
    set minimumCount(value: number);
    get minimumCountInput(): number | undefined;
}
export interface CodepipelineCustomActionTypeOutputArtifactDetails {
    /**
    * The maximum number of artifacts allowed for the action type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#maximum_count CodepipelineCustomActionType#maximum_count}
    */
    readonly maximumCount: number;
    /**
    * The minimum number of artifacts allowed for the action type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#minimum_count CodepipelineCustomActionType#minimum_count}
    */
    readonly minimumCount: number;
}
export declare function codepipelineCustomActionTypeOutputArtifactDetailsToTerraform(struct?: CodepipelineCustomActionTypeOutputArtifactDetails | cdktn.IResolvable): any;
export declare function codepipelineCustomActionTypeOutputArtifactDetailsToHclTerraform(struct?: CodepipelineCustomActionTypeOutputArtifactDetails | cdktn.IResolvable): any;
export declare class CodepipelineCustomActionTypeOutputArtifactDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelineCustomActionTypeOutputArtifactDetails | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelineCustomActionTypeOutputArtifactDetails | cdktn.IResolvable | undefined);
    private _maximumCount?;
    get maximumCount(): number;
    set maximumCount(value: number);
    get maximumCountInput(): number | undefined;
    private _minimumCount?;
    get minimumCount(): number;
    set minimumCount(value: number);
    get minimumCountInput(): number | undefined;
}
export interface CodepipelineCustomActionTypeSettings {
    /**
    * The URL returned to the AWS CodePipeline console that provides a deep link to the resources of the external system, such as the configuration page for an AWS CodeDeploy deployment group. This link is provided as part of the action display in the pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#entity_url_template CodepipelineCustomActionType#entity_url_template}
    */
    readonly entityUrlTemplate?: string;
    /**
    * The URL returned to the AWS CodePipeline console that contains a link to the top-level landing page for the external system, such as the console page for AWS CodeDeploy. This link is shown on the pipeline view page in the AWS CodePipeline console and provides a link to the execution entity of the external action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#execution_url_template CodepipelineCustomActionType#execution_url_template}
    */
    readonly executionUrlTemplate?: string;
    /**
    * The URL returned to the AWS CodePipeline console that contains a link to the page where customers can update or change the configuration of the external action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#revision_url_template CodepipelineCustomActionType#revision_url_template}
    */
    readonly revisionUrlTemplate?: string;
    /**
    * The URL of a sign-up page where users can sign up for an external service and perform initial configuration of the action provided by that service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#third_party_configuration_url CodepipelineCustomActionType#third_party_configuration_url}
    */
    readonly thirdPartyConfigurationUrl?: string;
}
export declare function codepipelineCustomActionTypeSettingsToTerraform(struct?: CodepipelineCustomActionTypeSettings | cdktn.IResolvable): any;
export declare function codepipelineCustomActionTypeSettingsToHclTerraform(struct?: CodepipelineCustomActionTypeSettings | cdktn.IResolvable): any;
export declare class CodepipelineCustomActionTypeSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelineCustomActionTypeSettings | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelineCustomActionTypeSettings | cdktn.IResolvable | undefined);
    private _entityUrlTemplate?;
    get entityUrlTemplate(): string;
    set entityUrlTemplate(value: string);
    resetEntityUrlTemplate(): void;
    get entityUrlTemplateInput(): string | undefined;
    private _executionUrlTemplate?;
    get executionUrlTemplate(): string;
    set executionUrlTemplate(value: string);
    resetExecutionUrlTemplate(): void;
    get executionUrlTemplateInput(): string | undefined;
    private _revisionUrlTemplate?;
    get revisionUrlTemplate(): string;
    set revisionUrlTemplate(value: string);
    resetRevisionUrlTemplate(): void;
    get revisionUrlTemplateInput(): string | undefined;
    private _thirdPartyConfigurationUrl?;
    get thirdPartyConfigurationUrl(): string;
    set thirdPartyConfigurationUrl(value: string);
    resetThirdPartyConfigurationUrl(): void;
    get thirdPartyConfigurationUrlInput(): string | undefined;
}
export interface CodepipelineCustomActionTypeTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#key CodepipelineCustomActionType#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#value CodepipelineCustomActionType#value}
    */
    readonly value?: string;
}
export declare function codepipelineCustomActionTypeTagsToTerraform(struct?: CodepipelineCustomActionTypeTags | cdktn.IResolvable): any;
export declare function codepipelineCustomActionTypeTagsToHclTerraform(struct?: CodepipelineCustomActionTypeTags | cdktn.IResolvable): any;
export declare class CodepipelineCustomActionTypeTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelineCustomActionTypeTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelineCustomActionTypeTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodepipelineCustomActionTypeTagsList extends cdktn.ComplexList {
    internalValue?: CodepipelineCustomActionTypeTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelineCustomActionTypeTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type awscc_codepipeline_custom_action_type}
*/
export declare class CodepipelineCustomActionType extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codepipeline_custom_action_type";
    /**
    * Generates CDKTN code for importing a CodepipelineCustomActionType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodepipelineCustomActionType to import
    * @param importFromId The id of the existing CodepipelineCustomActionType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodepipelineCustomActionType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codepipeline_custom_action_type awscc_codepipeline_custom_action_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodepipelineCustomActionTypeConfig
    */
    constructor(scope: Construct, id: string, config: CodepipelineCustomActionTypeConfig);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _configurationProperties;
    get configurationProperties(): CodepipelineCustomActionTypeConfigurationPropertiesList;
    putConfigurationProperties(value: CodepipelineCustomActionTypeConfigurationProperties[] | cdktn.IResolvable): void;
    resetConfigurationProperties(): void;
    get configurationPropertiesInput(): cdktn.IResolvable | CodepipelineCustomActionTypeConfigurationProperties[] | undefined;
    get customActionTypeId(): string;
    get id(): string;
    private _inputArtifactDetails;
    get inputArtifactDetails(): CodepipelineCustomActionTypeInputArtifactDetailsOutputReference;
    putInputArtifactDetails(value: CodepipelineCustomActionTypeInputArtifactDetails): void;
    get inputArtifactDetailsInput(): cdktn.IResolvable | CodepipelineCustomActionTypeInputArtifactDetails | undefined;
    private _outputArtifactDetails;
    get outputArtifactDetails(): CodepipelineCustomActionTypeOutputArtifactDetailsOutputReference;
    putOutputArtifactDetails(value: CodepipelineCustomActionTypeOutputArtifactDetails): void;
    get outputArtifactDetailsInput(): cdktn.IResolvable | CodepipelineCustomActionTypeOutputArtifactDetails | undefined;
    private _providerName?;
    get providerName(): string;
    set providerName(value: string);
    get providerNameInput(): string | undefined;
    private _settings;
    get settings(): CodepipelineCustomActionTypeSettingsOutputReference;
    putSettings(value: CodepipelineCustomActionTypeSettings): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | CodepipelineCustomActionTypeSettings | undefined;
    private _tags;
    get tags(): CodepipelineCustomActionTypeTagsList;
    putTags(value: CodepipelineCustomActionTypeTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodepipelineCustomActionTypeTags[] | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
