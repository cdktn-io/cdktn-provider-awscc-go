/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayBasePathMappingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigateway_base_path_mapping_v2#id DataAwsccApigatewayBasePathMappingV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigateway_base_path_mapping_v2 awscc_apigateway_base_path_mapping_v2}
*/
export declare class DataAwsccApigatewayBasePathMappingV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_base_path_mapping_v2";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayBasePathMappingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayBasePathMappingV2 to import
    * @param importFromId The id of the existing DataAwsccApigatewayBasePathMappingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigateway_base_path_mapping_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayBasePathMappingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigateway_base_path_mapping_v2 awscc_apigateway_base_path_mapping_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayBasePathMappingV2Config
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayBasePathMappingV2Config);
    get basePath(): string;
    get basePathMappingArn(): string;
    get domainNameArn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get restApiId(): string;
    get stage(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
