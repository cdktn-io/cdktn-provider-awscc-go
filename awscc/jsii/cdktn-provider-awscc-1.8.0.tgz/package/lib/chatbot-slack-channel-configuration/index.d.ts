/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChatbotSlackChannelConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#configuration_name ChatbotSlackChannelConfiguration#configuration_name}
    */
    readonly configurationName: string;
    /**
    * ARNs of Custom Actions to associate with notifications in the provided chat channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#customization_resource_arns ChatbotSlackChannelConfiguration#customization_resource_arns}
    */
    readonly customizationResourceArns?: string[];
    /**
    * The list of IAM policy ARNs that are applied as channel guardrails. The AWS managed 'AdministratorAccess' policy is applied as a default if this is not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#guardrail_policies ChatbotSlackChannelConfiguration#guardrail_policies}
    */
    readonly guardrailPolicies?: string[];
    /**
    * The ARN of the IAM role that defines the permissions for AWS Chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#iam_role_arn ChatbotSlackChannelConfiguration#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Specifies the logging level for this configuration:ERROR,INFO or NONE. This property affects the log entries pushed to Amazon CloudWatch logs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#logging_level ChatbotSlackChannelConfiguration#logging_level}
    */
    readonly loggingLevel?: string;
    /**
    * The id of the Slack channel
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#slack_channel_id ChatbotSlackChannelConfiguration#slack_channel_id}
    */
    readonly slackChannelId: string;
    /**
    * The id of the Slack workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#slack_workspace_id ChatbotSlackChannelConfiguration#slack_workspace_id}
    */
    readonly slackWorkspaceId: string;
    /**
    * ARNs of SNS topics which delivers notifications to AWS Chatbot, for example CloudWatch alarm notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#sns_topic_arns ChatbotSlackChannelConfiguration#sns_topic_arns}
    */
    readonly snsTopicArns?: string[];
    /**
    * The tags to add to the configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#tags ChatbotSlackChannelConfiguration#tags}
    */
    readonly tags?: ChatbotSlackChannelConfigurationTags[] | cdktn.IResolvable;
    /**
    * Enables use of a user role requirement in your chat configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#user_role_required ChatbotSlackChannelConfiguration#user_role_required}
    */
    readonly userRoleRequired?: boolean | cdktn.IResolvable;
}
export interface ChatbotSlackChannelConfigurationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#key ChatbotSlackChannelConfiguration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#value ChatbotSlackChannelConfiguration#value}
    */
    readonly value?: string;
}
export declare function chatbotSlackChannelConfigurationTagsToTerraform(struct?: ChatbotSlackChannelConfigurationTags | cdktn.IResolvable): any;
export declare function chatbotSlackChannelConfigurationTagsToHclTerraform(struct?: ChatbotSlackChannelConfigurationTags | cdktn.IResolvable): any;
export declare class ChatbotSlackChannelConfigurationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChatbotSlackChannelConfigurationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChatbotSlackChannelConfigurationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChatbotSlackChannelConfigurationTagsList extends cdktn.ComplexList {
    internalValue?: ChatbotSlackChannelConfigurationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChatbotSlackChannelConfigurationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration awscc_chatbot_slack_channel_configuration}
*/
export declare class ChatbotSlackChannelConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chatbot_slack_channel_configuration";
    /**
    * Generates CDKTN code for importing a ChatbotSlackChannelConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChatbotSlackChannelConfiguration to import
    * @param importFromId The id of the existing ChatbotSlackChannelConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChatbotSlackChannelConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_slack_channel_configuration awscc_chatbot_slack_channel_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChatbotSlackChannelConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: ChatbotSlackChannelConfigurationConfig);
    get arn(): string;
    private _configurationName?;
    get configurationName(): string;
    set configurationName(value: string);
    get configurationNameInput(): string | undefined;
    private _customizationResourceArns?;
    get customizationResourceArns(): string[];
    set customizationResourceArns(value: string[]);
    resetCustomizationResourceArns(): void;
    get customizationResourceArnsInput(): string[] | undefined;
    private _guardrailPolicies?;
    get guardrailPolicies(): string[];
    set guardrailPolicies(value: string[]);
    resetGuardrailPolicies(): void;
    get guardrailPoliciesInput(): string[] | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    get id(): string;
    private _loggingLevel?;
    get loggingLevel(): string;
    set loggingLevel(value: string);
    resetLoggingLevel(): void;
    get loggingLevelInput(): string | undefined;
    private _slackChannelId?;
    get slackChannelId(): string;
    set slackChannelId(value: string);
    get slackChannelIdInput(): string | undefined;
    private _slackWorkspaceId?;
    get slackWorkspaceId(): string;
    set slackWorkspaceId(value: string);
    get slackWorkspaceIdInput(): string | undefined;
    private _snsTopicArns?;
    get snsTopicArns(): string[];
    set snsTopicArns(value: string[]);
    resetSnsTopicArns(): void;
    get snsTopicArnsInput(): string[] | undefined;
    private _tags;
    get tags(): ChatbotSlackChannelConfigurationTagsList;
    putTags(value: ChatbotSlackChannelConfigurationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChatbotSlackChannelConfigurationTags[] | undefined;
    private _userRoleRequired?;
    get userRoleRequired(): boolean | cdktn.IResolvable;
    set userRoleRequired(value: boolean | cdktn.IResolvable);
    resetUserRoleRequired(): void;
    get userRoleRequiredInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
