/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreConsentPortalConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#description BedrockagentcoreConsentPortal#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#execution_role_arn BedrockagentcoreConsentPortal#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#idp_config BedrockagentcoreConsentPortal#idp_config}
    */
    readonly idpConfig: BedrockagentcoreConsentPortalIdpConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#name BedrockagentcoreConsentPortal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#sources BedrockagentcoreConsentPortal#sources}
    */
    readonly sources: BedrockagentcoreConsentPortalSources[] | cdktn.IResolvable;
    /**
    * Tags to assign to the consent portal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#tags BedrockagentcoreConsentPortal#tags}
    */
    readonly tags?: BedrockagentcoreConsentPortalTags[] | cdktn.IResolvable;
}
export interface BedrockagentcoreConsentPortalIdpConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#audience BedrockagentcoreConsentPortal#audience}
    */
    readonly audience?: string;
    /**
    * The ARN of an AWS::BedrockAgentCore::OAuth2CredentialProvider resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#credential_provider_arn BedrockagentcoreConsentPortal#credential_provider_arn}
    */
    readonly credentialProviderArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#scopes BedrockagentcoreConsentPortal#scopes}
    */
    readonly scopes: string[];
}
export declare function bedrockagentcoreConsentPortalIdpConfigToTerraform(struct?: BedrockagentcoreConsentPortalIdpConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreConsentPortalIdpConfigToHclTerraform(struct?: BedrockagentcoreConsentPortalIdpConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreConsentPortalIdpConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreConsentPortalIdpConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreConsentPortalIdpConfig | cdktn.IResolvable | undefined);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _credentialProviderArn?;
    get credentialProviderArn(): string;
    set credentialProviderArn(value: string);
    get credentialProviderArnInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
}
export interface BedrockagentcoreConsentPortalSources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#identifier BedrockagentcoreConsentPortal#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#type BedrockagentcoreConsentPortal#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreConsentPortalSourcesToTerraform(struct?: BedrockagentcoreConsentPortalSources | cdktn.IResolvable): any;
export declare function bedrockagentcoreConsentPortalSourcesToHclTerraform(struct?: BedrockagentcoreConsentPortalSources | cdktn.IResolvable): any;
export declare class BedrockagentcoreConsentPortalSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreConsentPortalSources | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreConsentPortalSources | cdktn.IResolvable | undefined);
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreConsentPortalSourcesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreConsentPortalSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreConsentPortalSourcesOutputReference;
}
export interface BedrockagentcoreConsentPortalTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#key BedrockagentcoreConsentPortal#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#value BedrockagentcoreConsentPortal#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcoreConsentPortalTagsToTerraform(struct?: BedrockagentcoreConsentPortalTags | cdktn.IResolvable): any;
export declare function bedrockagentcoreConsentPortalTagsToHclTerraform(struct?: BedrockagentcoreConsentPortalTags | cdktn.IResolvable): any;
export declare class BedrockagentcoreConsentPortalTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreConsentPortalTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreConsentPortalTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcoreConsentPortalTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreConsentPortalTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreConsentPortalTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal awscc_bedrockagentcore_consent_portal}
*/
export declare class BedrockagentcoreConsentPortal extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_consent_portal";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreConsentPortal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreConsentPortal to import
    * @param importFromId The id of the existing BedrockagentcoreConsentPortal that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreConsentPortal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_consent_portal awscc_bedrockagentcore_consent_portal} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreConsentPortalConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreConsentPortalConfig);
    get consentPortalArn(): string;
    get consentPortalId(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    get id(): string;
    private _idpConfig;
    get idpConfig(): BedrockagentcoreConsentPortalIdpConfigOutputReference;
    putIdpConfig(value: BedrockagentcoreConsentPortalIdpConfig): void;
    get idpConfigInput(): cdktn.IResolvable | BedrockagentcoreConsentPortalIdpConfig | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get portalUrl(): string;
    private _sources;
    get sources(): BedrockagentcoreConsentPortalSourcesList;
    putSources(value: BedrockagentcoreConsentPortalSources[] | cdktn.IResolvable): void;
    get sourcesInput(): cdktn.IResolvable | BedrockagentcoreConsentPortalSources[] | undefined;
    get status(): string;
    private _tags;
    get tags(): BedrockagentcoreConsentPortalTagsList;
    putTags(value: BedrockagentcoreConsentPortalTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcoreConsentPortalTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
