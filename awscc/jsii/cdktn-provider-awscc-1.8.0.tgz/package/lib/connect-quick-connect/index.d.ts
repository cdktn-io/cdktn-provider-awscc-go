/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectQuickConnectConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the quick connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#description ConnectQuickConnect#description}
    */
    readonly description?: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#instance_arn ConnectQuickConnect#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the quick connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#name ConnectQuickConnect#name}
    */
    readonly name: string;
    /**
    * Configuration settings for the quick connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#quick_connect_config ConnectQuickConnect#quick_connect_config}
    */
    readonly quickConnectConfig: ConnectQuickConnectQuickConnectConfig;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#tags ConnectQuickConnect#tags}
    */
    readonly tags?: ConnectQuickConnectTags[] | cdktn.IResolvable;
}
export interface ConnectQuickConnectQuickConnectConfigFlowConfig {
    /**
    * The identifier of the contact flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#contact_flow_arn ConnectQuickConnect#contact_flow_arn}
    */
    readonly contactFlowArn?: string;
}
export declare function connectQuickConnectQuickConnectConfigFlowConfigToTerraform(struct?: ConnectQuickConnectQuickConnectConfigFlowConfig | cdktn.IResolvable): any;
export declare function connectQuickConnectQuickConnectConfigFlowConfigToHclTerraform(struct?: ConnectQuickConnectQuickConnectConfigFlowConfig | cdktn.IResolvable): any;
export declare class ConnectQuickConnectQuickConnectConfigFlowConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectQuickConnectQuickConnectConfigFlowConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQuickConnectQuickConnectConfigFlowConfig | cdktn.IResolvable | undefined);
    private _contactFlowArn?;
    get contactFlowArn(): string;
    set contactFlowArn(value: string);
    resetContactFlowArn(): void;
    get contactFlowArnInput(): string | undefined;
}
export interface ConnectQuickConnectQuickConnectConfigPhoneConfig {
    /**
    * The phone number in E.164 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#phone_number ConnectQuickConnect#phone_number}
    */
    readonly phoneNumber?: string;
}
export declare function connectQuickConnectQuickConnectConfigPhoneConfigToTerraform(struct?: ConnectQuickConnectQuickConnectConfigPhoneConfig | cdktn.IResolvable): any;
export declare function connectQuickConnectQuickConnectConfigPhoneConfigToHclTerraform(struct?: ConnectQuickConnectQuickConnectConfigPhoneConfig | cdktn.IResolvable): any;
export declare class ConnectQuickConnectQuickConnectConfigPhoneConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectQuickConnectQuickConnectConfigPhoneConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQuickConnectQuickConnectConfigPhoneConfig | cdktn.IResolvable | undefined);
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    resetPhoneNumber(): void;
    get phoneNumberInput(): string | undefined;
}
export interface ConnectQuickConnectQuickConnectConfigQueueConfig {
    /**
    * The identifier of the contact flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#contact_flow_arn ConnectQuickConnect#contact_flow_arn}
    */
    readonly contactFlowArn?: string;
    /**
    * The identifier for the queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#queue_arn ConnectQuickConnect#queue_arn}
    */
    readonly queueArn?: string;
}
export declare function connectQuickConnectQuickConnectConfigQueueConfigToTerraform(struct?: ConnectQuickConnectQuickConnectConfigQueueConfig | cdktn.IResolvable): any;
export declare function connectQuickConnectQuickConnectConfigQueueConfigToHclTerraform(struct?: ConnectQuickConnectQuickConnectConfigQueueConfig | cdktn.IResolvable): any;
export declare class ConnectQuickConnectQuickConnectConfigQueueConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectQuickConnectQuickConnectConfigQueueConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQuickConnectQuickConnectConfigQueueConfig | cdktn.IResolvable | undefined);
    private _contactFlowArn?;
    get contactFlowArn(): string;
    set contactFlowArn(value: string);
    resetContactFlowArn(): void;
    get contactFlowArnInput(): string | undefined;
    private _queueArn?;
    get queueArn(): string;
    set queueArn(value: string);
    resetQueueArn(): void;
    get queueArnInput(): string | undefined;
}
export interface ConnectQuickConnectQuickConnectConfigUserConfig {
    /**
    * The identifier of the contact flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#contact_flow_arn ConnectQuickConnect#contact_flow_arn}
    */
    readonly contactFlowArn?: string;
    /**
    * The identifier of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#user_arn ConnectQuickConnect#user_arn}
    */
    readonly userArn?: string;
}
export declare function connectQuickConnectQuickConnectConfigUserConfigToTerraform(struct?: ConnectQuickConnectQuickConnectConfigUserConfig | cdktn.IResolvable): any;
export declare function connectQuickConnectQuickConnectConfigUserConfigToHclTerraform(struct?: ConnectQuickConnectQuickConnectConfigUserConfig | cdktn.IResolvable): any;
export declare class ConnectQuickConnectQuickConnectConfigUserConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectQuickConnectQuickConnectConfigUserConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQuickConnectQuickConnectConfigUserConfig | cdktn.IResolvable | undefined);
    private _contactFlowArn?;
    get contactFlowArn(): string;
    set contactFlowArn(value: string);
    resetContactFlowArn(): void;
    get contactFlowArnInput(): string | undefined;
    private _userArn?;
    get userArn(): string;
    set userArn(value: string);
    resetUserArn(): void;
    get userArnInput(): string | undefined;
}
export interface ConnectQuickConnectQuickConnectConfig {
    /**
    * The flow configuration. This is required only if QuickConnectType is FLOW.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#flow_config ConnectQuickConnect#flow_config}
    */
    readonly flowConfig?: ConnectQuickConnectQuickConnectConfigFlowConfig;
    /**
    * The phone configuration. This is required only if QuickConnectType is PHONE_NUMBER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#phone_config ConnectQuickConnect#phone_config}
    */
    readonly phoneConfig?: ConnectQuickConnectQuickConnectConfigPhoneConfig;
    /**
    * The queue configuration. This is required only if QuickConnectType is QUEUE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#queue_config ConnectQuickConnect#queue_config}
    */
    readonly queueConfig?: ConnectQuickConnectQuickConnectConfigQueueConfig;
    /**
    * The type of quick connect. In the Amazon Connect console, when you create a quick connect, you are prompted to assign one of the following types: Agent (USER), External (PHONE_NUMBER), or Queue (QUEUE).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#quick_connect_type ConnectQuickConnect#quick_connect_type}
    */
    readonly quickConnectType: string;
    /**
    * The user configuration. This is required only if QuickConnectType is USER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#user_config ConnectQuickConnect#user_config}
    */
    readonly userConfig?: ConnectQuickConnectQuickConnectConfigUserConfig;
}
export declare function connectQuickConnectQuickConnectConfigToTerraform(struct?: ConnectQuickConnectQuickConnectConfig | cdktn.IResolvable): any;
export declare function connectQuickConnectQuickConnectConfigToHclTerraform(struct?: ConnectQuickConnectQuickConnectConfig | cdktn.IResolvable): any;
export declare class ConnectQuickConnectQuickConnectConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectQuickConnectQuickConnectConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQuickConnectQuickConnectConfig | cdktn.IResolvable | undefined);
    private _flowConfig;
    get flowConfig(): ConnectQuickConnectQuickConnectConfigFlowConfigOutputReference;
    putFlowConfig(value: ConnectQuickConnectQuickConnectConfigFlowConfig): void;
    resetFlowConfig(): void;
    get flowConfigInput(): cdktn.IResolvable | ConnectQuickConnectQuickConnectConfigFlowConfig | undefined;
    private _phoneConfig;
    get phoneConfig(): ConnectQuickConnectQuickConnectConfigPhoneConfigOutputReference;
    putPhoneConfig(value: ConnectQuickConnectQuickConnectConfigPhoneConfig): void;
    resetPhoneConfig(): void;
    get phoneConfigInput(): cdktn.IResolvable | ConnectQuickConnectQuickConnectConfigPhoneConfig | undefined;
    private _queueConfig;
    get queueConfig(): ConnectQuickConnectQuickConnectConfigQueueConfigOutputReference;
    putQueueConfig(value: ConnectQuickConnectQuickConnectConfigQueueConfig): void;
    resetQueueConfig(): void;
    get queueConfigInput(): cdktn.IResolvable | ConnectQuickConnectQuickConnectConfigQueueConfig | undefined;
    private _quickConnectType?;
    get quickConnectType(): string;
    set quickConnectType(value: string);
    get quickConnectTypeInput(): string | undefined;
    private _userConfig;
    get userConfig(): ConnectQuickConnectQuickConnectConfigUserConfigOutputReference;
    putUserConfig(value: ConnectQuickConnectQuickConnectConfigUserConfig): void;
    resetUserConfig(): void;
    get userConfigInput(): cdktn.IResolvable | ConnectQuickConnectQuickConnectConfigUserConfig | undefined;
}
export interface ConnectQuickConnectTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#key ConnectQuickConnect#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#value ConnectQuickConnect#value}
    */
    readonly value?: string;
}
export declare function connectQuickConnectTagsToTerraform(struct?: ConnectQuickConnectTags | cdktn.IResolvable): any;
export declare function connectQuickConnectTagsToHclTerraform(struct?: ConnectQuickConnectTags | cdktn.IResolvable): any;
export declare class ConnectQuickConnectTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectQuickConnectTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectQuickConnectTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectQuickConnectTagsList extends cdktn.ComplexList {
    internalValue?: ConnectQuickConnectTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectQuickConnectTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect awscc_connect_quick_connect}
*/
export declare class ConnectQuickConnect extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_quick_connect";
    /**
    * Generates CDKTN code for importing a ConnectQuickConnect resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectQuickConnect to import
    * @param importFromId The id of the existing ConnectQuickConnect that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectQuickConnect to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_quick_connect awscc_connect_quick_connect} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectQuickConnectConfig
    */
    constructor(scope: Construct, id: string, config: ConnectQuickConnectConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get quickConnectArn(): string;
    private _quickConnectConfig;
    get quickConnectConfig(): ConnectQuickConnectQuickConnectConfigOutputReference;
    putQuickConnectConfig(value: ConnectQuickConnectQuickConnectConfig): void;
    get quickConnectConfigInput(): cdktn.IResolvable | ConnectQuickConnectQuickConnectConfig | undefined;
    get quickConnectType(): string;
    private _tags;
    get tags(): ConnectQuickConnectTagsList;
    putTags(value: ConnectQuickConnectTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectQuickConnectTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
