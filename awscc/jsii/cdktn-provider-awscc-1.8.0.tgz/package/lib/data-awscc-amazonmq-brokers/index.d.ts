/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAmazonmqBrokersConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/amazonmq_brokers awscc_amazonmq_brokers}
*/
export declare class DataAwsccAmazonmqBrokers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_amazonmq_brokers";
    /**
    * Generates CDKTN code for importing a DataAwsccAmazonmqBrokers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAmazonmqBrokers to import
    * @param importFromId The id of the existing DataAwsccAmazonmqBrokers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/amazonmq_brokers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAmazonmqBrokers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/amazonmq_brokers awscc_amazonmq_brokers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAmazonmqBrokersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsccAmazonmqBrokersConfig);
    get id(): string;
    get ids(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
