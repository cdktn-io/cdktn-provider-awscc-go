/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_application#description AppconfigApplication#description}
    */
    readonly description?: string;
    /**
    * A name for the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_application#name AppconfigApplication#name}
    */
    readonly name: string;
    /**
    * Metadata to assign to the application. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_application#tags AppconfigApplication#tags}
    */
    readonly tags?: AppconfigApplicationTags[] | cdktn.IResolvable;
}
export interface AppconfigApplicationTags {
    /**
    * The key-value string map. The valid character set is [a-zA-Z1-9 +-=._:/-]. The tag key can be up to 128 characters and must not start with aws:.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_application#key AppconfigApplication#key}
    */
    readonly key?: string;
    /**
    * The tag value can be up to 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_application#value AppconfigApplication#value}
    */
    readonly value?: string;
}
export declare function appconfigApplicationTagsToTerraform(struct?: AppconfigApplicationTags | cdktn.IResolvable): any;
export declare function appconfigApplicationTagsToHclTerraform(struct?: AppconfigApplicationTags | cdktn.IResolvable): any;
export declare class AppconfigApplicationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigApplicationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigApplicationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppconfigApplicationTagsList extends cdktn.ComplexList {
    internalValue?: AppconfigApplicationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigApplicationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_application awscc_appconfig_application}
*/
export declare class AppconfigApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appconfig_application";
    /**
    * Generates CDKTN code for importing a AppconfigApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigApplication to import
    * @param importFromId The id of the existing AppconfigApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_application awscc_appconfig_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AppconfigApplicationConfig);
    get applicationId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): AppconfigApplicationTagsList;
    putTags(value: AppconfigApplicationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppconfigApplicationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
