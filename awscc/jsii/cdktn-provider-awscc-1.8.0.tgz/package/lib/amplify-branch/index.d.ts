/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AmplifyBranchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#app_id AmplifyBranch#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#backend AmplifyBranch#backend}
    */
    readonly backend?: AmplifyBranchBackend;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#basic_auth_config AmplifyBranch#basic_auth_config}
    */
    readonly basicAuthConfig?: AmplifyBranchBasicAuthConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#branch_name AmplifyBranch#branch_name}
    */
    readonly branchName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#build_spec AmplifyBranch#build_spec}
    */
    readonly buildSpec?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#compute_role_arn AmplifyBranch#compute_role_arn}
    */
    readonly computeRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#description AmplifyBranch#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#enable_auto_build AmplifyBranch#enable_auto_build}
    */
    readonly enableAutoBuild?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#enable_performance_mode AmplifyBranch#enable_performance_mode}
    */
    readonly enablePerformanceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#enable_pull_request_preview AmplifyBranch#enable_pull_request_preview}
    */
    readonly enablePullRequestPreview?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#enable_skew_protection AmplifyBranch#enable_skew_protection}
    */
    readonly enableSkewProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#environment_variables AmplifyBranch#environment_variables}
    */
    readonly environmentVariables?: AmplifyBranchEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#framework AmplifyBranch#framework}
    */
    readonly framework?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#pull_request_environment_name AmplifyBranch#pull_request_environment_name}
    */
    readonly pullRequestEnvironmentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#stage AmplifyBranch#stage}
    */
    readonly stage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#tags AmplifyBranch#tags}
    */
    readonly tags?: AmplifyBranchTags[] | cdktn.IResolvable;
}
export interface AmplifyBranchBackend {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#stack_arn AmplifyBranch#stack_arn}
    */
    readonly stackArn?: string;
}
export declare function amplifyBranchBackendToTerraform(struct?: AmplifyBranchBackend | cdktn.IResolvable): any;
export declare function amplifyBranchBackendToHclTerraform(struct?: AmplifyBranchBackend | cdktn.IResolvable): any;
export declare class AmplifyBranchBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyBranchBackend | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyBranchBackend | cdktn.IResolvable | undefined);
    private _stackArn?;
    get stackArn(): string;
    set stackArn(value: string);
    resetStackArn(): void;
    get stackArnInput(): string | undefined;
}
export interface AmplifyBranchBasicAuthConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#enable_basic_auth AmplifyBranch#enable_basic_auth}
    */
    readonly enableBasicAuth?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#password AmplifyBranch#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#username AmplifyBranch#username}
    */
    readonly username?: string;
}
export declare function amplifyBranchBasicAuthConfigToTerraform(struct?: AmplifyBranchBasicAuthConfig | cdktn.IResolvable): any;
export declare function amplifyBranchBasicAuthConfigToHclTerraform(struct?: AmplifyBranchBasicAuthConfig | cdktn.IResolvable): any;
export declare class AmplifyBranchBasicAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyBranchBasicAuthConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyBranchBasicAuthConfig | cdktn.IResolvable | undefined);
    private _enableBasicAuth?;
    get enableBasicAuth(): boolean | cdktn.IResolvable;
    set enableBasicAuth(value: boolean | cdktn.IResolvable);
    resetEnableBasicAuth(): void;
    get enableBasicAuthInput(): boolean | cdktn.IResolvable | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AmplifyBranchEnvironmentVariables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#name AmplifyBranch#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#value AmplifyBranch#value}
    */
    readonly value?: string;
}
export declare function amplifyBranchEnvironmentVariablesToTerraform(struct?: AmplifyBranchEnvironmentVariables | cdktn.IResolvable): any;
export declare function amplifyBranchEnvironmentVariablesToHclTerraform(struct?: AmplifyBranchEnvironmentVariables | cdktn.IResolvable): any;
export declare class AmplifyBranchEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmplifyBranchEnvironmentVariables | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyBranchEnvironmentVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AmplifyBranchEnvironmentVariablesList extends cdktn.ComplexList {
    internalValue?: AmplifyBranchEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmplifyBranchEnvironmentVariablesOutputReference;
}
export interface AmplifyBranchTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#key AmplifyBranch#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#value AmplifyBranch#value}
    */
    readonly value?: string;
}
export declare function amplifyBranchTagsToTerraform(struct?: AmplifyBranchTags | cdktn.IResolvable): any;
export declare function amplifyBranchTagsToHclTerraform(struct?: AmplifyBranchTags | cdktn.IResolvable): any;
export declare class AmplifyBranchTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmplifyBranchTags | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyBranchTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AmplifyBranchTagsList extends cdktn.ComplexList {
    internalValue?: AmplifyBranchTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmplifyBranchTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch awscc_amplify_branch}
*/
export declare class AmplifyBranch extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_amplify_branch";
    /**
    * Generates CDKTN code for importing a AmplifyBranch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AmplifyBranch to import
    * @param importFromId The id of the existing AmplifyBranch that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AmplifyBranch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amplify_branch awscc_amplify_branch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AmplifyBranchConfig
    */
    constructor(scope: Construct, id: string, config: AmplifyBranchConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    get arn(): string;
    private _backend;
    get backend(): AmplifyBranchBackendOutputReference;
    putBackend(value: AmplifyBranchBackend): void;
    resetBackend(): void;
    get backendInput(): cdktn.IResolvable | AmplifyBranchBackend | undefined;
    private _basicAuthConfig;
    get basicAuthConfig(): AmplifyBranchBasicAuthConfigOutputReference;
    putBasicAuthConfig(value: AmplifyBranchBasicAuthConfig): void;
    resetBasicAuthConfig(): void;
    get basicAuthConfigInput(): cdktn.IResolvable | AmplifyBranchBasicAuthConfig | undefined;
    private _branchName?;
    get branchName(): string;
    set branchName(value: string);
    get branchNameInput(): string | undefined;
    private _buildSpec?;
    get buildSpec(): string;
    set buildSpec(value: string);
    resetBuildSpec(): void;
    get buildSpecInput(): string | undefined;
    private _computeRoleArn?;
    get computeRoleArn(): string;
    set computeRoleArn(value: string);
    resetComputeRoleArn(): void;
    get computeRoleArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableAutoBuild?;
    get enableAutoBuild(): boolean | cdktn.IResolvable;
    set enableAutoBuild(value: boolean | cdktn.IResolvable);
    resetEnableAutoBuild(): void;
    get enableAutoBuildInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePerformanceMode?;
    get enablePerformanceMode(): boolean | cdktn.IResolvable;
    set enablePerformanceMode(value: boolean | cdktn.IResolvable);
    resetEnablePerformanceMode(): void;
    get enablePerformanceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePullRequestPreview?;
    get enablePullRequestPreview(): boolean | cdktn.IResolvable;
    set enablePullRequestPreview(value: boolean | cdktn.IResolvable);
    resetEnablePullRequestPreview(): void;
    get enablePullRequestPreviewInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSkewProtection?;
    get enableSkewProtection(): boolean | cdktn.IResolvable;
    set enableSkewProtection(value: boolean | cdktn.IResolvable);
    resetEnableSkewProtection(): void;
    get enableSkewProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentVariables;
    get environmentVariables(): AmplifyBranchEnvironmentVariablesList;
    putEnvironmentVariables(value: AmplifyBranchEnvironmentVariables[] | cdktn.IResolvable): void;
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): cdktn.IResolvable | AmplifyBranchEnvironmentVariables[] | undefined;
    private _framework?;
    get framework(): string;
    set framework(value: string);
    resetFramework(): void;
    get frameworkInput(): string | undefined;
    get id(): string;
    private _pullRequestEnvironmentName?;
    get pullRequestEnvironmentName(): string;
    set pullRequestEnvironmentName(value: string);
    resetPullRequestEnvironmentName(): void;
    get pullRequestEnvironmentNameInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    resetStage(): void;
    get stageInput(): string | undefined;
    private _tags;
    get tags(): AmplifyBranchTagsList;
    putTags(value: AmplifyBranchTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AmplifyBranchTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
