/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface B2BiProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#business_name B2BiProfile#business_name}
    */
    readonly businessName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#email B2BiProfile#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#logging B2BiProfile#logging}
    */
    readonly logging: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#name B2BiProfile#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#phone B2BiProfile#phone}
    */
    readonly phone: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#tags B2BiProfile#tags}
    */
    readonly tags?: B2BiProfileTags[] | cdktn.IResolvable;
}
export interface B2BiProfileTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#key B2BiProfile#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#value B2BiProfile#value}
    */
    readonly value?: string;
}
export declare function b2BiProfileTagsToTerraform(struct?: B2BiProfileTags | cdktn.IResolvable): any;
export declare function b2BiProfileTagsToHclTerraform(struct?: B2BiProfileTags | cdktn.IResolvable): any;
export declare class B2BiProfileTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): B2BiProfileTags | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiProfileTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class B2BiProfileTagsList extends cdktn.ComplexList {
    internalValue?: B2BiProfileTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): B2BiProfileTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile awscc_b2bi_profile}
*/
export declare class B2BiProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_b2bi_profile";
    /**
    * Generates CDKTN code for importing a B2BiProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the B2BiProfile to import
    * @param importFromId The id of the existing B2BiProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the B2BiProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_profile awscc_b2bi_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options B2BiProfileConfig
    */
    constructor(scope: Construct, id: string, config: B2BiProfileConfig);
    private _businessName?;
    get businessName(): string;
    set businessName(value: string);
    get businessNameInput(): string | undefined;
    get createdAt(): string;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    get id(): string;
    get logGroupName(): string;
    private _logging?;
    get logging(): string;
    set logging(value: string);
    get loggingInput(): string | undefined;
    get modifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _phone?;
    get phone(): string;
    set phone(value: string);
    get phoneInput(): string | undefined;
    get profileArn(): string;
    get profileId(): string;
    private _tags;
    get tags(): B2BiProfileTagsList;
    putTags(value: B2BiProfileTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | B2BiProfileTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
