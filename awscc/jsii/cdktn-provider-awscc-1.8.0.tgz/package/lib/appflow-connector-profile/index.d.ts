/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppflowConnectorProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Mode in which data transfer should be enabled. Private connection mode is currently enabled for Salesforce, Snowflake, Trendmicro and Singular
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connection_mode AppflowConnectorProfile#connection_mode}
    */
    readonly connectionMode: string;
    /**
    * The label of the connector. The label is unique for each ConnectorRegistration in your AWS account. Only needed if calling for CUSTOMCONNECTOR connector type/.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_label AppflowConnectorProfile#connector_label}
    */
    readonly connectorLabel?: string;
    /**
    * Connector specific configurations needed to create connector profile
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_profile_config AppflowConnectorProfile#connector_profile_config}
    */
    readonly connectorProfileConfig?: AppflowConnectorProfileConnectorProfileConfig;
    /**
    * The maximum number of items to retrieve in a single batch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_profile_name AppflowConnectorProfile#connector_profile_name}
    */
    readonly connectorProfileName: string;
    /**
    * List of Saas providers that need connector profile to be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_type AppflowConnectorProfile#connector_type}
    */
    readonly connectorType: string;
    /**
    * The ARN of the AWS Key Management Service (AWS KMS) key that's used to encrypt your function's environment variables. If it's not provided, AWS Lambda uses a default service key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#kms_arn AppflowConnectorProfile#kms_arn}
    */
    readonly kmsArn?: string;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitude {
    /**
    * A unique alphanumeric identi?er used to authenticate a user, developer, or calling program to your API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#api_key AppflowConnectorProfile#api_key}
    */
    readonly apiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#secret_key AppflowConnectorProfile#secret_key}
    */
    readonly secretKey?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitudeToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitude | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitudeToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitude | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitudeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitude | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitude | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#api_key AppflowConnectorProfile#api_key}
    */
    readonly apiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#api_secret_key AppflowConnectorProfile#api_secret_key}
    */
    readonly apiSecretKey?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKeyToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKey | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKeyToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKey | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKey | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _apiSecretKey?;
    get apiSecretKey(): string;
    set apiSecretKey(value: string);
    resetApiSecretKey(): void;
    get apiSecretKeyInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#password AppflowConnectorProfile#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#username AppflowConnectorProfile#username}
    */
    readonly username?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasicToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasic | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasicToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasic | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasic | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasic | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustom {
    /**
    * A map for properties for custom authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#credentials_map AppflowConnectorProfile#credentials_map}
    */
    readonly credentialsMap?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#custom_authentication_type AppflowConnectorProfile#custom_authentication_type}
    */
    readonly customAuthenticationType?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustomToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustom | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustomToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustom | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustom | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustom | cdktn.IResolvable | undefined);
    private _credentialsMap?;
    get credentialsMap(): {
        [key: string]: string;
    };
    set credentialsMap(value: {
        [key: string]: string;
    });
    resetCredentialsMap(): void;
    get credentialsMapInput(): {
        [key: string]: string;
    } | undefined;
    private _customAuthenticationType?;
    get customAuthenticationType(): string;
    set customAuthenticationType(value: string);
    resetCustomAuthenticationType(): void;
    get customAuthenticationTypeInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequest {
    /**
    * The code provided by the connector when it has been authenticated via the connected app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code AppflowConnectorProfile#auth_code}
    */
    readonly authCode?: string;
    /**
    * The URL to which the authentication server redirects the browser after authorization has been
    * granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redirect_uri AppflowConnectorProfile#redirect_uri}
    */
    readonly redirectUri?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequestToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequest | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequestToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequest | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequest | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequest | cdktn.IResolvable | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _redirectUri?;
    get redirectUri(): string;
    set redirectUri(value: string);
    resetRedirectUri(): void;
    get redirectUriInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_token AppflowConnectorProfile#access_token}
    */
    readonly accessToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_id AppflowConnectorProfile#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_secret AppflowConnectorProfile#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#o_auth_request AppflowConnectorProfile#o_auth_request}
    */
    readonly oAuthRequest?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequest;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#refresh_token AppflowConnectorProfile#refresh_token}
    */
    readonly refreshToken?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2ToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2 | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2ToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2 | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2 | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2 | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _oAuthRequest;
    get oAuthRequest(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequestOutputReference;
    putOAuthRequest(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequest): void;
    resetOAuthRequest(): void;
    get oAuthRequestInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OAuthRequest | undefined;
    private _refreshToken?;
    get refreshToken(): string;
    set refreshToken(value: string);
    resetRefreshToken(): void;
    get refreshTokenInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnector {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#api_key AppflowConnectorProfile#api_key}
    */
    readonly apiKey?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#authentication_type AppflowConnectorProfile#authentication_type}
    */
    readonly authenticationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#basic AppflowConnectorProfile#basic}
    */
    readonly basic?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasic;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#custom AppflowConnectorProfile#custom}
    */
    readonly custom?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#oauth_2 AppflowConnectorProfile#oauth_2}
    */
    readonly oauth2?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnector | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnector | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnector | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnector | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKeyOutputReference;
    putApiKey(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorApiKey | undefined;
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    resetAuthenticationType(): void;
    get authenticationTypeInput(): string | undefined;
    private _basic;
    get basic(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasicOutputReference;
    putBasic(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasic): void;
    resetBasic(): void;
    get basicInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorBasic | undefined;
    private _custom;
    get custom(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustomOutputReference;
    putCustom(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorCustom | undefined;
    private _oauth2;
    get oauth2(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2OutputReference;
    putOauth2(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2): void;
    resetOauth2(): void;
    get oauth2Input(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOauth2 | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadog {
    /**
    * A unique alphanumeric identi?er used to authenticate a user, developer, or calling program to your API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#api_key AppflowConnectorProfile#api_key}
    */
    readonly apiKey?: string;
    /**
    * Application keys, in conjunction with your API key, give you full access to Datadog?s programmatic API. Application keys are associated with the user account that created them. The application key is used to log all requests made to the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#application_key AppflowConnectorProfile#application_key}
    */
    readonly applicationKey?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadogToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadog | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadogToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadog | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadog | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _applicationKey?;
    get applicationKey(): string;
    set applicationKey(value: string);
    resetApplicationKey(): void;
    get applicationKeyInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatrace {
    /**
    * The API tokens used by Dynatrace API to authenticate various API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#api_token AppflowConnectorProfile#api_token}
    */
    readonly apiToken?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatraceToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatrace | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatraceToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatrace | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatraceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatrace | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatrace | cdktn.IResolvable | undefined);
    private _apiToken?;
    get apiToken(): string;
    set apiToken(value: string);
    resetApiToken(): void;
    get apiTokenInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequest {
    /**
    * The code provided by the connector when it has been authenticated via the connected app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code AppflowConnectorProfile#auth_code}
    */
    readonly authCode?: string;
    /**
    * The URL to which the authentication server redirects the browser after authorization has been
    * granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redirect_uri AppflowConnectorProfile#redirect_uri}
    */
    readonly redirectUri?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequestToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequest | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequestToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequest | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequest | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequest | cdktn.IResolvable | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _redirectUri?;
    get redirectUri(): string;
    set redirectUri(value: string);
    resetRedirectUri(): void;
    get redirectUriInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalytics {
    /**
    * The credentials used to access protected resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_token AppflowConnectorProfile#access_token}
    */
    readonly accessToken?: string;
    /**
    * The identi?er for the desired client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_id AppflowConnectorProfile#client_id}
    */
    readonly clientId?: string;
    /**
    * The client secret used by the oauth client to authenticate to the authorization server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_secret AppflowConnectorProfile#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * The oauth needed to request security tokens from the connector endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_o_auth_request AppflowConnectorProfile#connector_o_auth_request}
    */
    readonly connectorOAuthRequest?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequest;
    /**
    * The credentials used to acquire new access tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#refresh_token AppflowConnectorProfile#refresh_token}
    */
    readonly refreshToken?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalytics | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalytics | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalytics | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalytics | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _connectorOAuthRequest;
    get connectorOAuthRequest(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequestOutputReference;
    putConnectorOAuthRequest(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequest): void;
    resetConnectorOAuthRequest(): void;
    get connectorOAuthRequestInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsConnectorOAuthRequest | undefined;
    private _refreshToken?;
    get refreshToken(): string;
    set refreshToken(value: string);
    resetRefreshToken(): void;
    get refreshTokenInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexus {
    /**
    * The Access Key portion of the credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_key_id AppflowConnectorProfile#access_key_id}
    */
    readonly accessKeyId?: string;
    /**
    * The encryption keys used to encrypt data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#datakey AppflowConnectorProfile#datakey}
    */
    readonly datakey?: string;
    /**
    * The secret key used to sign requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#secret_access_key AppflowConnectorProfile#secret_access_key}
    */
    readonly secretAccessKey?: string;
    /**
    * The identi?er for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#user_id AppflowConnectorProfile#user_id}
    */
    readonly userId?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexusToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexus | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexusToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexus | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexus | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexus | cdktn.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    resetAccessKeyId(): void;
    get accessKeyIdInput(): string | undefined;
    private _datakey?;
    get datakey(): string;
    set datakey(value: string);
    resetDatakey(): void;
    get datakeyInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    resetSecretAccessKey(): void;
    get secretAccessKeyInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequest {
    /**
    * The code provided by the connector when it has been authenticated via the connected app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code AppflowConnectorProfile#auth_code}
    */
    readonly authCode?: string;
    /**
    * The URL to which the authentication server redirects the browser after authorization has been
    * granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redirect_uri AppflowConnectorProfile#redirect_uri}
    */
    readonly redirectUri?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequestToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequest | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequestToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequest | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequest | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequest | cdktn.IResolvable | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _redirectUri?;
    get redirectUri(): string;
    set redirectUri(value: string);
    resetRedirectUri(): void;
    get redirectUriInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketo {
    /**
    * The credentials used to access protected resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_token AppflowConnectorProfile#access_token}
    */
    readonly accessToken?: string;
    /**
    * The identi?er for the desired client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_id AppflowConnectorProfile#client_id}
    */
    readonly clientId?: string;
    /**
    * The client secret used by the oauth client to authenticate to the authorization server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_secret AppflowConnectorProfile#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * The oauth needed to request security tokens from the connector endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_o_auth_request AppflowConnectorProfile#connector_o_auth_request}
    */
    readonly connectorOAuthRequest?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequest;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketo | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketo | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketo | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketo | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _connectorOAuthRequest;
    get connectorOAuthRequest(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequestOutputReference;
    putConnectorOAuthRequest(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequest): void;
    resetConnectorOAuthRequest(): void;
    get connectorOAuthRequestInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoConnectorOAuthRequest | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequest {
    /**
    * The code provided by the connector when it has been authenticated via the connected app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code AppflowConnectorProfile#auth_code}
    */
    readonly authCode?: string;
    /**
    * The URL to which the authentication server redirects the browser after authorization has been
    * granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redirect_uri AppflowConnectorProfile#redirect_uri}
    */
    readonly redirectUri?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequestToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequest | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequestToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequest | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequest | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequest | cdktn.IResolvable | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _redirectUri?;
    get redirectUri(): string;
    set redirectUri(value: string);
    resetRedirectUri(): void;
    get redirectUriInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardot {
    /**
    * The credentials used to access protected resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_token AppflowConnectorProfile#access_token}
    */
    readonly accessToken?: string;
    /**
    * The client credentials to fetch access token and refresh token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_credentials_arn AppflowConnectorProfile#client_credentials_arn}
    */
    readonly clientCredentialsArn?: string;
    /**
    * The oauth needed to request security tokens from the connector endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_o_auth_request AppflowConnectorProfile#connector_o_auth_request}
    */
    readonly connectorOAuthRequest?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequest;
    /**
    * The credentials used to acquire new access tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#refresh_token AppflowConnectorProfile#refresh_token}
    */
    readonly refreshToken?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardot | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardot | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardot | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardot | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _clientCredentialsArn?;
    get clientCredentialsArn(): string;
    set clientCredentialsArn(value: string);
    resetClientCredentialsArn(): void;
    get clientCredentialsArnInput(): string | undefined;
    private _connectorOAuthRequest;
    get connectorOAuthRequest(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequestOutputReference;
    putConnectorOAuthRequest(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequest): void;
    resetConnectorOAuthRequest(): void;
    get connectorOAuthRequestInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotConnectorOAuthRequest | undefined;
    private _refreshToken?;
    get refreshToken(): string;
    set refreshToken(value: string);
    resetRefreshToken(): void;
    get refreshTokenInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshift {
    /**
    * The password that corresponds to the username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#password AppflowConnectorProfile#password}
    */
    readonly password?: string;
    /**
    * The name of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#username AppflowConnectorProfile#username}
    */
    readonly username?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshiftToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshift | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshiftToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshift | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshift | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequest {
    /**
    * The code provided by the connector when it has been authenticated via the connected app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code AppflowConnectorProfile#auth_code}
    */
    readonly authCode?: string;
    /**
    * The URL to which the authentication server redirects the browser after authorization has been
    * granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redirect_uri AppflowConnectorProfile#redirect_uri}
    */
    readonly redirectUri?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequestToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequest | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequestToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequest | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequest | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequest | cdktn.IResolvable | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _redirectUri?;
    get redirectUri(): string;
    set redirectUri(value: string);
    resetRedirectUri(): void;
    get redirectUriInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforce {
    /**
    * The credentials used to access protected resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_token AppflowConnectorProfile#access_token}
    */
    readonly accessToken?: string;
    /**
    * The client credentials to fetch access token and refresh token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_credentials_arn AppflowConnectorProfile#client_credentials_arn}
    */
    readonly clientCredentialsArn?: string;
    /**
    * The oauth needed to request security tokens from the connector endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_o_auth_request AppflowConnectorProfile#connector_o_auth_request}
    */
    readonly connectorOAuthRequest?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequest;
    /**
    * The credentials used to acquire new access tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#refresh_token AppflowConnectorProfile#refresh_token}
    */
    readonly refreshToken?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforce | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforce | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforce | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforce | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _clientCredentialsArn?;
    get clientCredentialsArn(): string;
    set clientCredentialsArn(value: string);
    resetClientCredentialsArn(): void;
    get clientCredentialsArnInput(): string | undefined;
    private _connectorOAuthRequest;
    get connectorOAuthRequest(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequestOutputReference;
    putConnectorOAuthRequest(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequest): void;
    resetConnectorOAuthRequest(): void;
    get connectorOAuthRequestInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceConnectorOAuthRequest | undefined;
    private _refreshToken?;
    get refreshToken(): string;
    set refreshToken(value: string);
    resetRefreshToken(): void;
    get refreshTokenInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#password AppflowConnectorProfile#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#username AppflowConnectorProfile#username}
    */
    readonly username?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentialsToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentials | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentialsToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentials | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentials | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequest {
    /**
    * The code provided by the connector when it has been authenticated via the connected app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code AppflowConnectorProfile#auth_code}
    */
    readonly authCode?: string;
    /**
    * The URL to which the authentication server redirects the browser after authorization has been
    * granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redirect_uri AppflowConnectorProfile#redirect_uri}
    */
    readonly redirectUri?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequestToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequest | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequestToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequest | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequest | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequest | cdktn.IResolvable | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _redirectUri?;
    get redirectUri(): string;
    set redirectUri(value: string);
    resetRedirectUri(): void;
    get redirectUriInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_token AppflowConnectorProfile#access_token}
    */
    readonly accessToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_id AppflowConnectorProfile#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_secret AppflowConnectorProfile#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_o_auth_request AppflowConnectorProfile#connector_o_auth_request}
    */
    readonly connectorOAuthRequest?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequest;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#refresh_token AppflowConnectorProfile#refresh_token}
    */
    readonly refreshToken?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentials | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentials | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentials | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _connectorOAuthRequest;
    get connectorOAuthRequest(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequestOutputReference;
    putConnectorOAuthRequest(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequest): void;
    resetConnectorOAuthRequest(): void;
    get connectorOAuthRequestInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsConnectorOAuthRequest | undefined;
    private _refreshToken?;
    get refreshToken(): string;
    set refreshToken(value: string);
    resetRefreshToken(): void;
    get refreshTokenInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoData {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#basic_auth_credentials AppflowConnectorProfile#basic_auth_credentials}
    */
    readonly basicAuthCredentials?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentials;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#o_auth_credentials AppflowConnectorProfile#o_auth_credentials}
    */
    readonly oAuthCredentials?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentials;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoData | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoData | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoData | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoData | cdktn.IResolvable | undefined);
    private _basicAuthCredentials;
    get basicAuthCredentials(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentialsOutputReference;
    putBasicAuthCredentials(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentials): void;
    resetBasicAuthCredentials(): void;
    get basicAuthCredentialsInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataBasicAuthCredentials | undefined;
    private _oAuthCredentials;
    get oAuthCredentials(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentialsOutputReference;
    putOAuthCredentials(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentials): void;
    resetOAuthCredentials(): void;
    get oAuthCredentialsInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOAuthCredentials | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNow {
    /**
    * The password that corresponds to the username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#password AppflowConnectorProfile#password}
    */
    readonly password?: string;
    /**
    * The name of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#username AppflowConnectorProfile#username}
    */
    readonly username?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNowToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNow | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNowToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNow | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNow | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNow | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingular {
    /**
    * A unique alphanumeric identi?er used to authenticate a user, developer, or calling program to your API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#api_key AppflowConnectorProfile#api_key}
    */
    readonly apiKey?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingularToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingular | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingularToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingular | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingularOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingular | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingular | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequest {
    /**
    * The code provided by the connector when it has been authenticated via the connected app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code AppflowConnectorProfile#auth_code}
    */
    readonly authCode?: string;
    /**
    * The URL to which the authentication server redirects the browser after authorization has been
    * granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redirect_uri AppflowConnectorProfile#redirect_uri}
    */
    readonly redirectUri?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequestToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequest | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequestToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequest | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequest | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequest | cdktn.IResolvable | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _redirectUri?;
    get redirectUri(): string;
    set redirectUri(value: string);
    resetRedirectUri(): void;
    get redirectUriInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlack {
    /**
    * The credentials used to access protected resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_token AppflowConnectorProfile#access_token}
    */
    readonly accessToken?: string;
    /**
    * The identi?er for the desired client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_id AppflowConnectorProfile#client_id}
    */
    readonly clientId?: string;
    /**
    * The client secret used by the oauth client to authenticate to the authorization server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_secret AppflowConnectorProfile#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * The oauth needed to request security tokens from the connector endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_o_auth_request AppflowConnectorProfile#connector_o_auth_request}
    */
    readonly connectorOAuthRequest?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequest;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlack | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlack | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlack | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlack | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _connectorOAuthRequest;
    get connectorOAuthRequest(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequestOutputReference;
    putConnectorOAuthRequest(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequest): void;
    resetConnectorOAuthRequest(): void;
    get connectorOAuthRequestInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackConnectorOAuthRequest | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflake {
    /**
    * The password that corresponds to the username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#password AppflowConnectorProfile#password}
    */
    readonly password?: string;
    /**
    * The name of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#username AppflowConnectorProfile#username}
    */
    readonly username?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflakeToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflake | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflakeToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflake | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflakeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflake | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflake | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicro {
    /**
    * The Secret Access Key portion of the credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#api_secret_key AppflowConnectorProfile#api_secret_key}
    */
    readonly apiSecretKey?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicroToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicro | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicroToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicro | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicro | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicro | cdktn.IResolvable | undefined);
    private _apiSecretKey?;
    get apiSecretKey(): string;
    set apiSecretKey(value: string);
    resetApiSecretKey(): void;
    get apiSecretKeyInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeeva {
    /**
    * The password that corresponds to the username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#password AppflowConnectorProfile#password}
    */
    readonly password?: string;
    /**
    * The name of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#username AppflowConnectorProfile#username}
    */
    readonly username?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeevaToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeeva | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeevaToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeeva | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeevaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeeva | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeeva | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequest {
    /**
    * The code provided by the connector when it has been authenticated via the connected app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code AppflowConnectorProfile#auth_code}
    */
    readonly authCode?: string;
    /**
    * The URL to which the authentication server redirects the browser after authorization has been
    * granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redirect_uri AppflowConnectorProfile#redirect_uri}
    */
    readonly redirectUri?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequestToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequest | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequestToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequest | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequest | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequest | cdktn.IResolvable | undefined);
    private _authCode?;
    get authCode(): string;
    set authCode(value: string);
    resetAuthCode(): void;
    get authCodeInput(): string | undefined;
    private _redirectUri?;
    get redirectUri(): string;
    set redirectUri(value: string);
    resetRedirectUri(): void;
    get redirectUriInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendesk {
    /**
    * The credentials used to access protected resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#access_token AppflowConnectorProfile#access_token}
    */
    readonly accessToken?: string;
    /**
    * The identi?er for the desired client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_id AppflowConnectorProfile#client_id}
    */
    readonly clientId?: string;
    /**
    * The client secret used by the oauth client to authenticate to the authorization server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_secret AppflowConnectorProfile#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * The oauth needed to request security tokens from the connector endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_o_auth_request AppflowConnectorProfile#connector_o_auth_request}
    */
    readonly connectorOAuthRequest?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequest;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendesk | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendesk | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendesk | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendesk | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _connectorOAuthRequest;
    get connectorOAuthRequest(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequestOutputReference;
    putConnectorOAuthRequest(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequest): void;
    resetConnectorOAuthRequest(): void;
    get connectorOAuthRequestInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskConnectorOAuthRequest | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#amplitude AppflowConnectorProfile#amplitude}
    */
    readonly amplitude?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitude;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#custom_connector AppflowConnectorProfile#custom_connector}
    */
    readonly customConnector?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnector;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#datadog AppflowConnectorProfile#datadog}
    */
    readonly datadog?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadog;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#dynatrace AppflowConnectorProfile#dynatrace}
    */
    readonly dynatrace?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatrace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#google_analytics AppflowConnectorProfile#google_analytics}
    */
    readonly googleAnalytics?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalytics;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#infor_nexus AppflowConnectorProfile#infor_nexus}
    */
    readonly inforNexus?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#marketo AppflowConnectorProfile#marketo}
    */
    readonly marketo?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketo;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#pardot AppflowConnectorProfile#pardot}
    */
    readonly pardot?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardot;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redshift AppflowConnectorProfile#redshift}
    */
    readonly redshift?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshift;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#salesforce AppflowConnectorProfile#salesforce}
    */
    readonly salesforce?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforce;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#sapo_data AppflowConnectorProfile#sapo_data}
    */
    readonly sapoData?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoData;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#service_now AppflowConnectorProfile#service_now}
    */
    readonly serviceNow?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#singular AppflowConnectorProfile#singular}
    */
    readonly singular?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingular;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#slack AppflowConnectorProfile#slack}
    */
    readonly slack?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlack;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#snowflake AppflowConnectorProfile#snowflake}
    */
    readonly snowflake?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflake;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#trendmicro AppflowConnectorProfile#trendmicro}
    */
    readonly trendmicro?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicro;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#veeva AppflowConnectorProfile#veeva}
    */
    readonly veeva?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeeva;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#zendesk AppflowConnectorProfile#zendesk}
    */
    readonly zendesk?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendesk;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentials | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentials | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentials | cdktn.IResolvable | undefined);
    private _amplitude;
    get amplitude(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitudeOutputReference;
    putAmplitude(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitude): void;
    resetAmplitude(): void;
    get amplitudeInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsAmplitude | undefined;
    private _customConnector;
    get customConnector(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnectorOutputReference;
    putCustomConnector(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnector): void;
    resetCustomConnector(): void;
    get customConnectorInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsCustomConnector | undefined;
    private _datadog;
    get datadog(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadogOutputReference;
    putDatadog(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadog): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDatadog | undefined;
    private _dynatrace;
    get dynatrace(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatraceOutputReference;
    putDynatrace(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatrace): void;
    resetDynatrace(): void;
    get dynatraceInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsDynatrace | undefined;
    private _googleAnalytics;
    get googleAnalytics(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalyticsOutputReference;
    putGoogleAnalytics(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalytics): void;
    resetGoogleAnalytics(): void;
    get googleAnalyticsInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsGoogleAnalytics | undefined;
    private _inforNexus;
    get inforNexus(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexusOutputReference;
    putInforNexus(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexus): void;
    resetInforNexus(): void;
    get inforNexusInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsInforNexus | undefined;
    private _marketo;
    get marketo(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketoOutputReference;
    putMarketo(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketo): void;
    resetMarketo(): void;
    get marketoInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsMarketo | undefined;
    private _pardot;
    get pardot(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardotOutputReference;
    putPardot(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardot): void;
    resetPardot(): void;
    get pardotInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsPardot | undefined;
    private _redshift;
    get redshift(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshiftOutputReference;
    putRedshift(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshift): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsRedshift | undefined;
    private _salesforce;
    get salesforce(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforceOutputReference;
    putSalesforce(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforce): void;
    resetSalesforce(): void;
    get salesforceInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSalesforce | undefined;
    private _sapoData;
    get sapoData(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoDataOutputReference;
    putSapoData(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoData): void;
    resetSapoData(): void;
    get sapoDataInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSapoData | undefined;
    private _serviceNow;
    get serviceNow(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNowOutputReference;
    putServiceNow(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNow): void;
    resetServiceNow(): void;
    get serviceNowInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsServiceNow | undefined;
    private _singular;
    get singular(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingularOutputReference;
    putSingular(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingular): void;
    resetSingular(): void;
    get singularInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSingular | undefined;
    private _slack;
    get slack(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlackOutputReference;
    putSlack(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlack): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSlack | undefined;
    private _snowflake;
    get snowflake(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflakeOutputReference;
    putSnowflake(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflake): void;
    resetSnowflake(): void;
    get snowflakeInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsSnowflake | undefined;
    private _trendmicro;
    get trendmicro(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicroOutputReference;
    putTrendmicro(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicro): void;
    resetTrendmicro(): void;
    get trendmicroInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsTrendmicro | undefined;
    private _veeva;
    get veeva(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeevaOutputReference;
    putVeeva(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeeva): void;
    resetVeeva(): void;
    get veevaInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsVeeva | undefined;
    private _zendesk;
    get zendesk(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendeskOutputReference;
    putZendesk(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendesk): void;
    resetZendesk(): void;
    get zendeskInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsZendesk | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2Properties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#o_auth_2_grant_type AppflowConnectorProfile#o_auth_2_grant_type}
    */
    readonly oAuth2GrantType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#token_url AppflowConnectorProfile#token_url}
    */
    readonly tokenUrl?: string;
    /**
    * A map for properties for custom connector Token Url.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#token_url_custom_properties AppflowConnectorProfile#token_url_custom_properties}
    */
    readonly tokenUrlCustomProperties?: {
        [key: string]: string;
    };
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2PropertiesToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2Properties | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2PropertiesToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2Properties | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2PropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2Properties | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2Properties | cdktn.IResolvable | undefined);
    private _oAuth2GrantType?;
    get oAuth2GrantType(): string;
    set oAuth2GrantType(value: string);
    resetOAuth2GrantType(): void;
    get oAuth2GrantTypeInput(): string | undefined;
    private _tokenUrl?;
    get tokenUrl(): string;
    set tokenUrl(value: string);
    resetTokenUrl(): void;
    get tokenUrlInput(): string | undefined;
    private _tokenUrlCustomProperties?;
    get tokenUrlCustomProperties(): {
        [key: string]: string;
    };
    set tokenUrlCustomProperties(value: {
        [key: string]: string;
    });
    resetTokenUrlCustomProperties(): void;
    get tokenUrlCustomPropertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnector {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#o_auth_2_properties AppflowConnectorProfile#o_auth_2_properties}
    */
    readonly oAuth2Properties?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2Properties;
    /**
    * A map for properties for custom connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#profile_properties AppflowConnectorProfile#profile_properties}
    */
    readonly profileProperties?: {
        [key: string]: string;
    };
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnector | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnector | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnector | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnector | cdktn.IResolvable | undefined);
    private _oAuth2Properties;
    get oAuth2Properties(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2PropertiesOutputReference;
    putOAuth2Properties(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2Properties): void;
    resetOAuth2Properties(): void;
    get oAuth2PropertiesInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOAuth2Properties | undefined;
    private _profileProperties?;
    get profileProperties(): {
        [key: string]: string;
    };
    set profileProperties(value: {
        [key: string]: string;
    });
    resetProfileProperties(): void;
    get profilePropertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadog {
    /**
    * The location of the Datadog resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadogToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadog | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadogToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadog | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadog | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatrace {
    /**
    * The location of the Dynatrace resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatraceToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatrace | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatraceToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatrace | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatraceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatrace | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatrace | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexus {
    /**
    * The location of the InforNexus resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexusToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexus | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexusToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexus | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexus | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexus | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketo {
    /**
    * The location of the Marketo resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketoToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketo | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketoToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketo | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketo | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketo | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardot {
    /**
    * The Business unit id of Salesforce Pardot instance to be connected
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#business_unit_id AppflowConnectorProfile#business_unit_id}
    */
    readonly businessUnitId?: string;
    /**
    * The location of the Salesforce Pardot resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
    /**
    * Indicates whether the connector profile applies to a demo or production environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#is_sandbox_environment AppflowConnectorProfile#is_sandbox_environment}
    */
    readonly isSandboxEnvironment?: boolean | cdktn.IResolvable;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardotToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardot | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardotToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardot | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardot | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardot | cdktn.IResolvable | undefined);
    private _businessUnitId?;
    get businessUnitId(): string;
    set businessUnitId(value: string);
    resetBusinessUnitId(): void;
    get businessUnitIdInput(): string | undefined;
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
    private _isSandboxEnvironment?;
    get isSandboxEnvironment(): boolean | cdktn.IResolvable;
    set isSandboxEnvironment(value: boolean | cdktn.IResolvable);
    resetIsSandboxEnvironment(): void;
    get isSandboxEnvironmentInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshift {
    /**
    * The name of the Amazon S3 bucket associated with Redshift.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#bucket_name AppflowConnectorProfile#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The object key for the destination bucket in which Amazon AppFlow will place the ?les.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#bucket_prefix AppflowConnectorProfile#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * The unique identifier of the Amazon Redshift cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#cluster_identifier AppflowConnectorProfile#cluster_identifier}
    */
    readonly clusterIdentifier?: string;
    /**
    * The Amazon Resource Name (ARN) of the IAM role that grants Amazon AppFlow access to the data through the Amazon Redshift Data API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#data_api_role_arn AppflowConnectorProfile#data_api_role_arn}
    */
    readonly dataApiRoleArn?: string;
    /**
    * The name of the Amazon Redshift database that will store the transferred data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#database_name AppflowConnectorProfile#database_name}
    */
    readonly databaseName?: string;
    /**
    * The JDBC URL of the Amazon Redshift cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#database_url AppflowConnectorProfile#database_url}
    */
    readonly databaseUrl?: string;
    /**
    * If Amazon AppFlow will connect to Amazon Redshift Serverless or Amazon Redshift cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#is_redshift_serverless AppflowConnectorProfile#is_redshift_serverless}
    */
    readonly isRedshiftServerless?: boolean | cdktn.IResolvable;
    /**
    * The Amazon Resource Name (ARN) of the IAM role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#role_arn AppflowConnectorProfile#role_arn}
    */
    readonly roleArn?: string;
    /**
    * The name of the Amazon Redshift serverless workgroup
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#workgroup_name AppflowConnectorProfile#workgroup_name}
    */
    readonly workgroupName?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshiftToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshift | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshiftToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshift | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshift | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _clusterIdentifier?;
    get clusterIdentifier(): string;
    set clusterIdentifier(value: string);
    resetClusterIdentifier(): void;
    get clusterIdentifierInput(): string | undefined;
    private _dataApiRoleArn?;
    get dataApiRoleArn(): string;
    set dataApiRoleArn(value: string);
    resetDataApiRoleArn(): void;
    get dataApiRoleArnInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _databaseUrl?;
    get databaseUrl(): string;
    set databaseUrl(value: string);
    resetDatabaseUrl(): void;
    get databaseUrlInput(): string | undefined;
    private _isRedshiftServerless?;
    get isRedshiftServerless(): boolean | cdktn.IResolvable;
    set isRedshiftServerless(value: boolean | cdktn.IResolvable);
    resetIsRedshiftServerless(): void;
    get isRedshiftServerlessInput(): boolean | cdktn.IResolvable | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _workgroupName?;
    get workgroupName(): string;
    set workgroupName(value: string);
    resetWorkgroupName(): void;
    get workgroupNameInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforce {
    /**
    * The location of the Salesforce resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
    /**
    * Indicates whether the connector profile applies to a sandbox or production environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#is_sandbox_environment AppflowConnectorProfile#is_sandbox_environment}
    */
    readonly isSandboxEnvironment?: boolean | cdktn.IResolvable;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforceToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforce | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforceToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforce | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforce | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforce | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
    private _isSandboxEnvironment?;
    get isSandboxEnvironment(): boolean | cdktn.IResolvable;
    set isSandboxEnvironment(value: boolean | cdktn.IResolvable);
    resetIsSandboxEnvironment(): void;
    get isSandboxEnvironmentInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#auth_code_url AppflowConnectorProfile#auth_code_url}
    */
    readonly authCodeUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#o_auth_scopes AppflowConnectorProfile#o_auth_scopes}
    */
    readonly oAuthScopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#token_url AppflowConnectorProfile#token_url}
    */
    readonly tokenUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthPropertiesToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthProperties | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthPropertiesToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthProperties | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthProperties | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthProperties | cdktn.IResolvable | undefined);
    private _authCodeUrl?;
    get authCodeUrl(): string;
    set authCodeUrl(value: string);
    resetAuthCodeUrl(): void;
    get authCodeUrlInput(): string | undefined;
    private _oAuthScopes?;
    get oAuthScopes(): string[];
    set oAuthScopes(value: string[]);
    resetOAuthScopes(): void;
    get oAuthScopesInput(): string[] | undefined;
    private _tokenUrl?;
    get tokenUrl(): string;
    set tokenUrl(value: string);
    resetTokenUrl(): void;
    get tokenUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoData {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#application_host_url AppflowConnectorProfile#application_host_url}
    */
    readonly applicationHostUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#application_service_path AppflowConnectorProfile#application_service_path}
    */
    readonly applicationServicePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#client_number AppflowConnectorProfile#client_number}
    */
    readonly clientNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#logon_language AppflowConnectorProfile#logon_language}
    */
    readonly logonLanguage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#o_auth_properties AppflowConnectorProfile#o_auth_properties}
    */
    readonly oAuthProperties?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#port_number AppflowConnectorProfile#port_number}
    */
    readonly portNumber?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#private_link_service_name AppflowConnectorProfile#private_link_service_name}
    */
    readonly privateLinkServiceName?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoData | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoData | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoData | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoData | cdktn.IResolvable | undefined);
    private _applicationHostUrl?;
    get applicationHostUrl(): string;
    set applicationHostUrl(value: string);
    resetApplicationHostUrl(): void;
    get applicationHostUrlInput(): string | undefined;
    private _applicationServicePath?;
    get applicationServicePath(): string;
    set applicationServicePath(value: string);
    resetApplicationServicePath(): void;
    get applicationServicePathInput(): string | undefined;
    private _clientNumber?;
    get clientNumber(): string;
    set clientNumber(value: string);
    resetClientNumber(): void;
    get clientNumberInput(): string | undefined;
    private _logonLanguage?;
    get logonLanguage(): string;
    set logonLanguage(value: string);
    resetLogonLanguage(): void;
    get logonLanguageInput(): string | undefined;
    private _oAuthProperties;
    get oAuthProperties(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthPropertiesOutputReference;
    putOAuthProperties(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthProperties): void;
    resetOAuthProperties(): void;
    get oAuthPropertiesInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOAuthProperties | undefined;
    private _portNumber?;
    get portNumber(): number;
    set portNumber(value: number);
    resetPortNumber(): void;
    get portNumberInput(): number | undefined;
    private _privateLinkServiceName?;
    get privateLinkServiceName(): string;
    set privateLinkServiceName(value: string);
    resetPrivateLinkServiceName(): void;
    get privateLinkServiceNameInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNow {
    /**
    * The location of the ServiceNow resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNowToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNow | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNowToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNow | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNow | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNow | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlack {
    /**
    * The location of the Slack resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlackToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlack | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlackToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlack | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlack | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlack | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflake {
    /**
    * The name of the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#account_name AppflowConnectorProfile#account_name}
    */
    readonly accountName?: string;
    /**
    * The name of the Amazon S3 bucket associated with Snow?ake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#bucket_name AppflowConnectorProfile#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The bucket prefix that refers to the Amazon S3 bucket associated with Snow?ake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#bucket_prefix AppflowConnectorProfile#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * The Snow?ake Private Link service name to be used for private data transfers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#private_link_service_name AppflowConnectorProfile#private_link_service_name}
    */
    readonly privateLinkServiceName?: string;
    /**
    * The region of the Snow?ake account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#region AppflowConnectorProfile#region}
    */
    readonly region?: string;
    /**
    * The name of the Amazon S3 stage that was created while setting up an Amazon S3 stage in the
    * Snow?ake account. This is written in the following format: < Database>< Schema><Stage Name>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#stage AppflowConnectorProfile#stage}
    */
    readonly stage?: string;
    /**
    * The name of the Snow?ake warehouse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#warehouse AppflowConnectorProfile#warehouse}
    */
    readonly warehouse?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflakeToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflake | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflakeToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflake | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflakeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflake | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflake | cdktn.IResolvable | undefined);
    private _accountName?;
    get accountName(): string;
    set accountName(value: string);
    resetAccountName(): void;
    get accountNameInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _privateLinkServiceName?;
    get privateLinkServiceName(): string;
    set privateLinkServiceName(value: string);
    resetPrivateLinkServiceName(): void;
    get privateLinkServiceNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    resetStage(): void;
    get stageInput(): string | undefined;
    private _warehouse?;
    get warehouse(): string;
    set warehouse(value: string);
    resetWarehouse(): void;
    get warehouseInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeeva {
    /**
    * The location of the Veeva resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeevaToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeeva | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeevaToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeeva | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeevaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeeva | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeeva | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendesk {
    /**
    * The location of the Zendesk resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#instance_url AppflowConnectorProfile#instance_url}
    */
    readonly instanceUrl?: string;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendeskToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendesk | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendeskToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendesk | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendeskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendesk | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendesk | cdktn.IResolvable | undefined);
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    resetInstanceUrl(): void;
    get instanceUrlInput(): string | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfigConnectorProfileProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#custom_connector AppflowConnectorProfile#custom_connector}
    */
    readonly customConnector?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnector;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#datadog AppflowConnectorProfile#datadog}
    */
    readonly datadog?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadog;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#dynatrace AppflowConnectorProfile#dynatrace}
    */
    readonly dynatrace?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatrace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#infor_nexus AppflowConnectorProfile#infor_nexus}
    */
    readonly inforNexus?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#marketo AppflowConnectorProfile#marketo}
    */
    readonly marketo?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketo;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#pardot AppflowConnectorProfile#pardot}
    */
    readonly pardot?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardot;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#redshift AppflowConnectorProfile#redshift}
    */
    readonly redshift?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshift;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#salesforce AppflowConnectorProfile#salesforce}
    */
    readonly salesforce?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforce;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#sapo_data AppflowConnectorProfile#sapo_data}
    */
    readonly sapoData?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoData;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#service_now AppflowConnectorProfile#service_now}
    */
    readonly serviceNow?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#slack AppflowConnectorProfile#slack}
    */
    readonly slack?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlack;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#snowflake AppflowConnectorProfile#snowflake}
    */
    readonly snowflake?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflake;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#veeva AppflowConnectorProfile#veeva}
    */
    readonly veeva?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeeva;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#zendesk AppflowConnectorProfile#zendesk}
    */
    readonly zendesk?: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendesk;
}
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileProperties | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileProperties | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileProperties | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileProperties | cdktn.IResolvable | undefined);
    private _customConnector;
    get customConnector(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnectorOutputReference;
    putCustomConnector(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnector): void;
    resetCustomConnector(): void;
    get customConnectorInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesCustomConnector | undefined;
    private _datadog;
    get datadog(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadogOutputReference;
    putDatadog(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadog): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDatadog | undefined;
    private _dynatrace;
    get dynatrace(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatraceOutputReference;
    putDynatrace(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatrace): void;
    resetDynatrace(): void;
    get dynatraceInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesDynatrace | undefined;
    private _inforNexus;
    get inforNexus(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexusOutputReference;
    putInforNexus(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexus): void;
    resetInforNexus(): void;
    get inforNexusInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesInforNexus | undefined;
    private _marketo;
    get marketo(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketoOutputReference;
    putMarketo(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketo): void;
    resetMarketo(): void;
    get marketoInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesMarketo | undefined;
    private _pardot;
    get pardot(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardotOutputReference;
    putPardot(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardot): void;
    resetPardot(): void;
    get pardotInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesPardot | undefined;
    private _redshift;
    get redshift(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshiftOutputReference;
    putRedshift(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshift): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesRedshift | undefined;
    private _salesforce;
    get salesforce(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforceOutputReference;
    putSalesforce(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforce): void;
    resetSalesforce(): void;
    get salesforceInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSalesforce | undefined;
    private _sapoData;
    get sapoData(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoDataOutputReference;
    putSapoData(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoData): void;
    resetSapoData(): void;
    get sapoDataInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSapoData | undefined;
    private _serviceNow;
    get serviceNow(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNowOutputReference;
    putServiceNow(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNow): void;
    resetServiceNow(): void;
    get serviceNowInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesServiceNow | undefined;
    private _slack;
    get slack(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlackOutputReference;
    putSlack(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlack): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSlack | undefined;
    private _snowflake;
    get snowflake(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflakeOutputReference;
    putSnowflake(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflake): void;
    resetSnowflake(): void;
    get snowflakeInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesSnowflake | undefined;
    private _veeva;
    get veeva(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeevaOutputReference;
    putVeeva(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeeva): void;
    resetVeeva(): void;
    get veevaInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesVeeva | undefined;
    private _zendesk;
    get zendesk(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendeskOutputReference;
    putZendesk(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendesk): void;
    resetZendesk(): void;
    get zendeskInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesZendesk | undefined;
}
export interface AppflowConnectorProfileConnectorProfileConfig {
    /**
    * Connector specific configuration needed to create connector profile based on Authentication mechanism
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_profile_credentials AppflowConnectorProfile#connector_profile_credentials}
    */
    readonly connectorProfileCredentials?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentials;
    /**
    * Connector specific properties needed to create connector profile - currently not needed for Amplitude, Trendmicro, Googleanalytics and Singular
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#connector_profile_properties AppflowConnectorProfile#connector_profile_properties}
    */
    readonly connectorProfileProperties?: AppflowConnectorProfileConnectorProfileConfigConnectorProfileProperties;
}
export declare function appflowConnectorProfileConnectorProfileConfigToTerraform(struct?: AppflowConnectorProfileConnectorProfileConfig | cdktn.IResolvable): any;
export declare function appflowConnectorProfileConnectorProfileConfigToHclTerraform(struct?: AppflowConnectorProfileConnectorProfileConfig | cdktn.IResolvable): any;
export declare class AppflowConnectorProfileConnectorProfileConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowConnectorProfileConnectorProfileConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowConnectorProfileConnectorProfileConfig | cdktn.IResolvable | undefined);
    private _connectorProfileCredentials;
    get connectorProfileCredentials(): AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentialsOutputReference;
    putConnectorProfileCredentials(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentials): void;
    resetConnectorProfileCredentials(): void;
    get connectorProfileCredentialsInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileCredentials | undefined;
    private _connectorProfileProperties;
    get connectorProfileProperties(): AppflowConnectorProfileConnectorProfileConfigConnectorProfilePropertiesOutputReference;
    putConnectorProfileProperties(value: AppflowConnectorProfileConnectorProfileConfigConnectorProfileProperties): void;
    resetConnectorProfileProperties(): void;
    get connectorProfilePropertiesInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfigConnectorProfileProperties | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile awscc_appflow_connector_profile}
*/
export declare class AppflowConnectorProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appflow_connector_profile";
    /**
    * Generates CDKTN code for importing a AppflowConnectorProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppflowConnectorProfile to import
    * @param importFromId The id of the existing AppflowConnectorProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppflowConnectorProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_connector_profile awscc_appflow_connector_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppflowConnectorProfileConfig
    */
    constructor(scope: Construct, id: string, config: AppflowConnectorProfileConfig);
    private _connectionMode?;
    get connectionMode(): string;
    set connectionMode(value: string);
    get connectionModeInput(): string | undefined;
    private _connectorLabel?;
    get connectorLabel(): string;
    set connectorLabel(value: string);
    resetConnectorLabel(): void;
    get connectorLabelInput(): string | undefined;
    get connectorProfileArn(): string;
    private _connectorProfileConfig;
    get connectorProfileConfig(): AppflowConnectorProfileConnectorProfileConfigOutputReference;
    putConnectorProfileConfig(value: AppflowConnectorProfileConnectorProfileConfig): void;
    resetConnectorProfileConfig(): void;
    get connectorProfileConfigInput(): cdktn.IResolvable | AppflowConnectorProfileConnectorProfileConfig | undefined;
    private _connectorProfileName?;
    get connectorProfileName(): string;
    set connectorProfileName(value: string);
    get connectorProfileNameInput(): string | undefined;
    private _connectorType?;
    get connectorType(): string;
    set connectorType(value: string);
    get connectorTypeInput(): string | undefined;
    get credentialsArn(): string;
    get id(): string;
    private _kmsArn?;
    get kmsArn(): string;
    set kmsArn(value: string);
    resetKmsArn(): void;
    get kmsArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
