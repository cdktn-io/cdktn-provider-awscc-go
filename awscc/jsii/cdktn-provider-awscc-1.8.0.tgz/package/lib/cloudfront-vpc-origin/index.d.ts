/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontVpcOriginConfig extends cdktn.TerraformMetaArguments {
    /**
    * A complex type that contains zero or more ``Tag`` elements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#tags CloudfrontVpcOrigin#tags}
    */
    readonly tags?: CloudfrontVpcOriginTags[] | cdktn.IResolvable;
    /**
    * The VPC origin endpoint configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#vpc_origin_endpoint_config CloudfrontVpcOrigin#vpc_origin_endpoint_config}
    */
    readonly vpcOriginEndpointConfig: CloudfrontVpcOriginVpcOriginEndpointConfig;
}
export interface CloudfrontVpcOriginTags {
    /**
    * A string that contains ``Tag`` key.
    *  The string length should be between 1 and 128 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#key CloudfrontVpcOrigin#key}
    */
    readonly key?: string;
    /**
    * A string that contains an optional ``Tag`` value.
    *  The string length should be between 0 and 256 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#value CloudfrontVpcOrigin#value}
    */
    readonly value?: string;
}
export declare function cloudfrontVpcOriginTagsToTerraform(struct?: CloudfrontVpcOriginTags | cdktn.IResolvable): any;
export declare function cloudfrontVpcOriginTagsToHclTerraform(struct?: CloudfrontVpcOriginTags | cdktn.IResolvable): any;
export declare class CloudfrontVpcOriginTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontVpcOriginTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontVpcOriginTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontVpcOriginTagsList extends cdktn.ComplexList {
    internalValue?: CloudfrontVpcOriginTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontVpcOriginTagsOutputReference;
}
export interface CloudfrontVpcOriginVpcOriginEndpointConfig {
    /**
    * The ARN of the CloudFront VPC origin endpoint configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#arn CloudfrontVpcOrigin#arn}
    */
    readonly arn: string;
    /**
    * The HTTP port for the CloudFront VPC origin endpoint configuration. The default value is ``80``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#http_port CloudfrontVpcOrigin#http_port}
    */
    readonly httpPort?: number;
    /**
    * The HTTPS port of the CloudFront VPC origin endpoint configuration. The default value is ``443``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#https_port CloudfrontVpcOrigin#https_port}
    */
    readonly httpsPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#ip_address_type CloudfrontVpcOrigin#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * The name of the CloudFront VPC origin endpoint configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#name CloudfrontVpcOrigin#name}
    */
    readonly name: string;
    /**
    * The origin protocol policy for the CloudFront VPC origin endpoint configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#origin_protocol_policy CloudfrontVpcOrigin#origin_protocol_policy}
    */
    readonly originProtocolPolicy?: string;
    /**
    * Specifies the minimum SSL/TLS protocol that CloudFront uses when connecting to your origin over HTTPS. Valid values include ``SSLv3``, ``TLSv1``, ``TLSv1.1``, and ``TLSv1.2``.
    *  For more information, see [Minimum Origin SSL Protocol](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/DownloadDistValuesOrigin.html#DownloadDistValuesOriginSSLProtocols) in the *Amazon CloudFront Developer Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#origin_ssl_protocols CloudfrontVpcOrigin#origin_ssl_protocols}
    */
    readonly originSslProtocols?: string[];
}
export declare function cloudfrontVpcOriginVpcOriginEndpointConfigToTerraform(struct?: CloudfrontVpcOriginVpcOriginEndpointConfig | cdktn.IResolvable): any;
export declare function cloudfrontVpcOriginVpcOriginEndpointConfigToHclTerraform(struct?: CloudfrontVpcOriginVpcOriginEndpointConfig | cdktn.IResolvable): any;
export declare class CloudfrontVpcOriginVpcOriginEndpointConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontVpcOriginVpcOriginEndpointConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontVpcOriginVpcOriginEndpointConfig | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _httpPort?;
    get httpPort(): number;
    set httpPort(value: number);
    resetHttpPort(): void;
    get httpPortInput(): number | undefined;
    private _httpsPort?;
    get httpsPort(): number;
    set httpsPort(value: number);
    resetHttpsPort(): void;
    get httpsPortInput(): number | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _originProtocolPolicy?;
    get originProtocolPolicy(): string;
    set originProtocolPolicy(value: string);
    resetOriginProtocolPolicy(): void;
    get originProtocolPolicyInput(): string | undefined;
    private _originSslProtocols?;
    get originSslProtocols(): string[];
    set originSslProtocols(value: string[]);
    resetOriginSslProtocols(): void;
    get originSslProtocolsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin awscc_cloudfront_vpc_origin}
*/
export declare class CloudfrontVpcOrigin extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_vpc_origin";
    /**
    * Generates CDKTN code for importing a CloudfrontVpcOrigin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontVpcOrigin to import
    * @param importFromId The id of the existing CloudfrontVpcOrigin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontVpcOrigin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_vpc_origin awscc_cloudfront_vpc_origin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontVpcOriginConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontVpcOriginConfig);
    get accountId(): string;
    get arn(): string;
    get createdTime(): string;
    get id(): string;
    get lastModifiedTime(): string;
    get status(): string;
    private _tags;
    get tags(): CloudfrontVpcOriginTagsList;
    putTags(value: CloudfrontVpcOriginTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudfrontVpcOriginTags[] | undefined;
    private _vpcOriginEndpointConfig;
    get vpcOriginEndpointConfig(): CloudfrontVpcOriginVpcOriginEndpointConfigOutputReference;
    putVpcOriginEndpointConfig(value: CloudfrontVpcOriginVpcOriginEndpointConfig): void;
    get vpcOriginEndpointConfigInput(): cdktn.IResolvable | CloudfrontVpcOriginVpcOriginEndpointConfig | undefined;
    get vpcOriginId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
