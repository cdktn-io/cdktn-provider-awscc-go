/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAppconfigExperimentRunConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_experiment_run#id DataAwsccAppconfigExperimentRun#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAppconfigExperimentRunTags {
}
export declare function dataAwsccAppconfigExperimentRunTagsToTerraform(struct?: DataAwsccAppconfigExperimentRunTags): any;
export declare function dataAwsccAppconfigExperimentRunTagsToHclTerraform(struct?: DataAwsccAppconfigExperimentRunTags): any;
export declare class DataAwsccAppconfigExperimentRunTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigExperimentRunTags | undefined;
    set internalValue(value: DataAwsccAppconfigExperimentRunTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAppconfigExperimentRunTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigExperimentRunTagsOutputReference;
}
export interface DataAwsccAppconfigExperimentRunTreatmentOverrides {
}
export declare function dataAwsccAppconfigExperimentRunTreatmentOverridesToTerraform(struct?: DataAwsccAppconfigExperimentRunTreatmentOverrides): any;
export declare function dataAwsccAppconfigExperimentRunTreatmentOverridesToHclTerraform(struct?: DataAwsccAppconfigExperimentRunTreatmentOverrides): any;
export declare class DataAwsccAppconfigExperimentRunTreatmentOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAppconfigExperimentRunTreatmentOverrides | undefined;
    set internalValue(value: DataAwsccAppconfigExperimentRunTreatmentOverrides | undefined);
    private _inline;
    get inline(): cdktn.StringMap;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_experiment_run awscc_appconfig_experiment_run}
*/
export declare class DataAwsccAppconfigExperimentRun extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_appconfig_experiment_run";
    /**
    * Generates CDKTN code for importing a DataAwsccAppconfigExperimentRun resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAppconfigExperimentRun to import
    * @param importFromId The id of the existing DataAwsccAppconfigExperimentRun that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_experiment_run#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAppconfigExperimentRun to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_experiment_run awscc_appconfig_experiment_run} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAppconfigExperimentRunConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAppconfigExperimentRunConfig);
    get applicationId(): string;
    get applicationIdentifier(): string;
    get description(): string;
    get experimentDefinitionId(): string;
    get experimentDefinitionIdentifier(): string;
    get exposurePercentage(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get run(): string;
    get startedAt(): string;
    get status(): string;
    private _tags;
    get tags(): DataAwsccAppconfigExperimentRunTagsList;
    private _treatmentOverrides;
    get treatmentOverrides(): DataAwsccAppconfigExperimentRunTreatmentOverridesOutputReference;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
