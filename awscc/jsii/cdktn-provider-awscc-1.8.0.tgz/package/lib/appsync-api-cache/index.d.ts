/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncApiCacheConfig extends cdktn.TerraformMetaArguments {
    /**
    * Caching behavior, such as FULL_REQUEST_CACHING, PER_RESOLVER_CACHING, or OPERATION_LEVEL_CACHING
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache#api_caching_behavior AppsyncApiCache#api_caching_behavior}
    */
    readonly apiCachingBehavior: string;
    /**
    * Unique AWS AppSync GraphQL API identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache#api_id AppsyncApiCache#api_id}
    */
    readonly apiId: string;
    /**
    * At-rest encryption flag for cache. You cannot update this setting after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache#at_rest_encryption_enabled AppsyncApiCache#at_rest_encryption_enabled}
    */
    readonly atRestEncryptionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Controls how cache health metrics will be emitted to CloudWatch. Cache health metrics include NetworkBandwidthOutAllowanceExceeded and EngineCPUUtilization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache#health_metrics_config AppsyncApiCache#health_metrics_config}
    */
    readonly healthMetricsConfig?: string;
    /**
    * Transit encryption flag when connecting to cache. You cannot update this setting after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache#transit_encryption_enabled AppsyncApiCache#transit_encryption_enabled}
    */
    readonly transitEncryptionEnabled?: boolean | cdktn.IResolvable;
    /**
    * TTL in seconds for cache entries. Valid values are 1-3600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache#ttl AppsyncApiCache#ttl}
    */
    readonly ttl: number;
    /**
    * The cache instance type, such as SMALL, LARGE and LARGE_4X
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache#type AppsyncApiCache#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache awscc_appsync_api_cache}
*/
export declare class AppsyncApiCache extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_api_cache";
    /**
    * Generates CDKTN code for importing a AppsyncApiCache resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncApiCache to import
    * @param importFromId The id of the existing AppsyncApiCache that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncApiCache to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api_cache awscc_appsync_api_cache} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncApiCacheConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncApiCacheConfig);
    get apiCacheId(): string;
    private _apiCachingBehavior?;
    get apiCachingBehavior(): string;
    set apiCachingBehavior(value: string);
    get apiCachingBehaviorInput(): string | undefined;
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _atRestEncryptionEnabled?;
    get atRestEncryptionEnabled(): boolean | cdktn.IResolvable;
    set atRestEncryptionEnabled(value: boolean | cdktn.IResolvable);
    resetAtRestEncryptionEnabled(): void;
    get atRestEncryptionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _healthMetricsConfig?;
    get healthMetricsConfig(): string;
    set healthMetricsConfig(value: string);
    resetHealthMetricsConfig(): void;
    get healthMetricsConfigInput(): string | undefined;
    get id(): string;
    private _transitEncryptionEnabled?;
    get transitEncryptionEnabled(): boolean | cdktn.IResolvable;
    set transitEncryptionEnabled(value: boolean | cdktn.IResolvable);
    resetTransitEncryptionEnabled(): void;
    get transitEncryptionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    get ttlInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
