/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * The configuration for an Event Api
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#event_config AppsyncApi#event_config}
    */
    readonly eventConfig?: AppsyncApiEventConfig;
    /**
    * The name of the AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#name AppsyncApi#name}
    */
    readonly name: string;
    /**
    * The owner contact information for an API resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#owner_contact AppsyncApi#owner_contact}
    */
    readonly ownerContact?: string;
    /**
    * An arbitrary set of tags (key-value pairs) for this AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#tags AppsyncApi#tags}
    */
    readonly tags?: AppsyncApiTags[] | cdktn.IResolvable;
}
export interface AppsyncApiDns {
}
export declare function appsyncApiDnsToTerraform(struct?: AppsyncApiDns): any;
export declare function appsyncApiDnsToHclTerraform(struct?: AppsyncApiDns): any;
export declare class AppsyncApiDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncApiDns | undefined;
    set internalValue(value: AppsyncApiDns | undefined);
    get http(): string;
    get realtime(): string;
}
export interface AppsyncApiEventConfigAuthProvidersCognitoConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#app_id_client_regex AppsyncApi#app_id_client_regex}
    */
    readonly appIdClientRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#aws_region AppsyncApi#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#user_pool_id AppsyncApi#user_pool_id}
    */
    readonly userPoolId?: string;
}
export declare function appsyncApiEventConfigAuthProvidersCognitoConfigToTerraform(struct?: AppsyncApiEventConfigAuthProvidersCognitoConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigAuthProvidersCognitoConfigToHclTerraform(struct?: AppsyncApiEventConfigAuthProvidersCognitoConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigAuthProvidersCognitoConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncApiEventConfigAuthProvidersCognitoConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigAuthProvidersCognitoConfig | cdktn.IResolvable | undefined);
    private _appIdClientRegex?;
    get appIdClientRegex(): string;
    set appIdClientRegex(value: string);
    resetAppIdClientRegex(): void;
    get appIdClientRegexInput(): string | undefined;
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    resetUserPoolId(): void;
    get userPoolIdInput(): string | undefined;
}
export interface AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#authorizer_result_ttl_in_seconds AppsyncApi#authorizer_result_ttl_in_seconds}
    */
    readonly authorizerResultTtlInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#authorizer_uri AppsyncApi#authorizer_uri}
    */
    readonly authorizerUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#identity_validation_expression AppsyncApi#identity_validation_expression}
    */
    readonly identityValidationExpression?: string;
}
export declare function appsyncApiEventConfigAuthProvidersLambdaAuthorizerConfigToTerraform(struct?: AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigAuthProvidersLambdaAuthorizerConfigToHclTerraform(struct?: AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfig | cdktn.IResolvable | undefined);
    private _authorizerResultTtlInSeconds?;
    get authorizerResultTtlInSeconds(): number;
    set authorizerResultTtlInSeconds(value: number);
    resetAuthorizerResultTtlInSeconds(): void;
    get authorizerResultTtlInSecondsInput(): number | undefined;
    private _authorizerUri?;
    get authorizerUri(): string;
    set authorizerUri(value: string);
    resetAuthorizerUri(): void;
    get authorizerUriInput(): string | undefined;
    private _identityValidationExpression?;
    get identityValidationExpression(): string;
    set identityValidationExpression(value: string);
    resetIdentityValidationExpression(): void;
    get identityValidationExpressionInput(): string | undefined;
}
export interface AppsyncApiEventConfigAuthProvidersOpenIdConnectConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#auth_ttl AppsyncApi#auth_ttl}
    */
    readonly authTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#client_id AppsyncApi#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#iat_ttl AppsyncApi#iat_ttl}
    */
    readonly iatTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#issuer AppsyncApi#issuer}
    */
    readonly issuer?: string;
}
export declare function appsyncApiEventConfigAuthProvidersOpenIdConnectConfigToTerraform(struct?: AppsyncApiEventConfigAuthProvidersOpenIdConnectConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigAuthProvidersOpenIdConnectConfigToHclTerraform(struct?: AppsyncApiEventConfigAuthProvidersOpenIdConnectConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigAuthProvidersOpenIdConnectConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncApiEventConfigAuthProvidersOpenIdConnectConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigAuthProvidersOpenIdConnectConfig | cdktn.IResolvable | undefined);
    private _authTtl?;
    get authTtl(): number;
    set authTtl(value: number);
    resetAuthTtl(): void;
    get authTtlInput(): number | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _iatTtl?;
    get iatTtl(): number;
    set iatTtl(value: number);
    resetIatTtl(): void;
    get iatTtlInput(): number | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    resetIssuer(): void;
    get issuerInput(): string | undefined;
}
export interface AppsyncApiEventConfigAuthProviders {
    /**
    * Security configuration for your AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#auth_type AppsyncApi#auth_type}
    */
    readonly authType?: string;
    /**
    * Optional authorization configuration for using Amazon Cognito user pools with your API endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#cognito_config AppsyncApi#cognito_config}
    */
    readonly cognitoConfig?: AppsyncApiEventConfigAuthProvidersCognitoConfig;
    /**
    * A LambdaAuthorizerConfig holds configuration on how to authorize AWS AppSync API access when using the AWS_LAMBDA authorizer mode. Be aware that an AWS AppSync API may have only one Lambda authorizer configured at a time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#lambda_authorizer_config AppsyncApi#lambda_authorizer_config}
    */
    readonly lambdaAuthorizerConfig?: AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfig;
    /**
    * The OpenID Connect configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#open_id_connect_config AppsyncApi#open_id_connect_config}
    */
    readonly openIdConnectConfig?: AppsyncApiEventConfigAuthProvidersOpenIdConnectConfig;
}
export declare function appsyncApiEventConfigAuthProvidersToTerraform(struct?: AppsyncApiEventConfigAuthProviders | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigAuthProvidersToHclTerraform(struct?: AppsyncApiEventConfigAuthProviders | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigAuthProvidersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigAuthProviders | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigAuthProviders | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _cognitoConfig;
    get cognitoConfig(): AppsyncApiEventConfigAuthProvidersCognitoConfigOutputReference;
    putCognitoConfig(value: AppsyncApiEventConfigAuthProvidersCognitoConfig): void;
    resetCognitoConfig(): void;
    get cognitoConfigInput(): cdktn.IResolvable | AppsyncApiEventConfigAuthProvidersCognitoConfig | undefined;
    private _lambdaAuthorizerConfig;
    get lambdaAuthorizerConfig(): AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfigOutputReference;
    putLambdaAuthorizerConfig(value: AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfig): void;
    resetLambdaAuthorizerConfig(): void;
    get lambdaAuthorizerConfigInput(): cdktn.IResolvable | AppsyncApiEventConfigAuthProvidersLambdaAuthorizerConfig | undefined;
    private _openIdConnectConfig;
    get openIdConnectConfig(): AppsyncApiEventConfigAuthProvidersOpenIdConnectConfigOutputReference;
    putOpenIdConnectConfig(value: AppsyncApiEventConfigAuthProvidersOpenIdConnectConfig): void;
    resetOpenIdConnectConfig(): void;
    get openIdConnectConfigInput(): cdktn.IResolvable | AppsyncApiEventConfigAuthProvidersOpenIdConnectConfig | undefined;
}
export declare class AppsyncApiEventConfigAuthProvidersList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigAuthProviders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigAuthProvidersOutputReference;
}
export interface AppsyncApiEventConfigConnectionAuthModes {
    /**
    * Security configuration for your AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#auth_type AppsyncApi#auth_type}
    */
    readonly authType?: string;
}
export declare function appsyncApiEventConfigConnectionAuthModesToTerraform(struct?: AppsyncApiEventConfigConnectionAuthModes | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigConnectionAuthModesToHclTerraform(struct?: AppsyncApiEventConfigConnectionAuthModes | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigConnectionAuthModesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigConnectionAuthModes | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigConnectionAuthModes | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
}
export declare class AppsyncApiEventConfigConnectionAuthModesList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigConnectionAuthModes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigConnectionAuthModesOutputReference;
}
export interface AppsyncApiEventConfigDefaultPublishAuthModes {
    /**
    * Security configuration for your AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#auth_type AppsyncApi#auth_type}
    */
    readonly authType?: string;
}
export declare function appsyncApiEventConfigDefaultPublishAuthModesToTerraform(struct?: AppsyncApiEventConfigDefaultPublishAuthModes | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigDefaultPublishAuthModesToHclTerraform(struct?: AppsyncApiEventConfigDefaultPublishAuthModes | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigDefaultPublishAuthModesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigDefaultPublishAuthModes | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigDefaultPublishAuthModes | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
}
export declare class AppsyncApiEventConfigDefaultPublishAuthModesList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigDefaultPublishAuthModes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigDefaultPublishAuthModesOutputReference;
}
export interface AppsyncApiEventConfigDefaultSubscribeAuthModes {
    /**
    * Security configuration for your AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#auth_type AppsyncApi#auth_type}
    */
    readonly authType?: string;
}
export declare function appsyncApiEventConfigDefaultSubscribeAuthModesToTerraform(struct?: AppsyncApiEventConfigDefaultSubscribeAuthModes | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigDefaultSubscribeAuthModesToHclTerraform(struct?: AppsyncApiEventConfigDefaultSubscribeAuthModes | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigDefaultSubscribeAuthModesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigDefaultSubscribeAuthModes | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigDefaultSubscribeAuthModes | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
}
export declare class AppsyncApiEventConfigDefaultSubscribeAuthModesList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigDefaultSubscribeAuthModes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigDefaultSubscribeAuthModesOutputReference;
}
export interface AppsyncApiEventConfigLogConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#cloudwatch_logs_role_arn AppsyncApi#cloudwatch_logs_role_arn}
    */
    readonly cloudwatchLogsRoleArn?: string;
    /**
    * Logging level for the AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#log_level AppsyncApi#log_level}
    */
    readonly logLevel?: string;
}
export declare function appsyncApiEventConfigLogConfigToTerraform(struct?: AppsyncApiEventConfigLogConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigLogConfigToHclTerraform(struct?: AppsyncApiEventConfigLogConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncApiEventConfigLogConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigLogConfig | cdktn.IResolvable | undefined);
    private _cloudwatchLogsRoleArn?;
    get cloudwatchLogsRoleArn(): string;
    set cloudwatchLogsRoleArn(value: string);
    resetCloudwatchLogsRoleArn(): void;
    get cloudwatchLogsRoleArnInput(): string | undefined;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    resetLogLevel(): void;
    get logLevelInput(): string | undefined;
}
export interface AppsyncApiEventConfig {
    /**
    * A list of auth providers for the AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#auth_providers AppsyncApi#auth_providers}
    */
    readonly authProviders?: AppsyncApiEventConfigAuthProviders[] | cdktn.IResolvable;
    /**
    * A list of auth modes for the AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#connection_auth_modes AppsyncApi#connection_auth_modes}
    */
    readonly connectionAuthModes?: AppsyncApiEventConfigConnectionAuthModes[] | cdktn.IResolvable;
    /**
    * A list of auth modes for the AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#default_publish_auth_modes AppsyncApi#default_publish_auth_modes}
    */
    readonly defaultPublishAuthModes?: AppsyncApiEventConfigDefaultPublishAuthModes[] | cdktn.IResolvable;
    /**
    * A list of auth modes for the AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#default_subscribe_auth_modes AppsyncApi#default_subscribe_auth_modes}
    */
    readonly defaultSubscribeAuthModes?: AppsyncApiEventConfigDefaultSubscribeAuthModes[] | cdktn.IResolvable;
    /**
    * The log config for the AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#log_config AppsyncApi#log_config}
    */
    readonly logConfig?: AppsyncApiEventConfigLogConfig;
}
export declare function appsyncApiEventConfigToTerraform(struct?: AppsyncApiEventConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigToHclTerraform(struct?: AppsyncApiEventConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncApiEventConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfig | cdktn.IResolvable | undefined);
    private _authProviders;
    get authProviders(): AppsyncApiEventConfigAuthProvidersList;
    putAuthProviders(value: AppsyncApiEventConfigAuthProviders[] | cdktn.IResolvable): void;
    resetAuthProviders(): void;
    get authProvidersInput(): cdktn.IResolvable | AppsyncApiEventConfigAuthProviders[] | undefined;
    private _connectionAuthModes;
    get connectionAuthModes(): AppsyncApiEventConfigConnectionAuthModesList;
    putConnectionAuthModes(value: AppsyncApiEventConfigConnectionAuthModes[] | cdktn.IResolvable): void;
    resetConnectionAuthModes(): void;
    get connectionAuthModesInput(): cdktn.IResolvable | AppsyncApiEventConfigConnectionAuthModes[] | undefined;
    private _defaultPublishAuthModes;
    get defaultPublishAuthModes(): AppsyncApiEventConfigDefaultPublishAuthModesList;
    putDefaultPublishAuthModes(value: AppsyncApiEventConfigDefaultPublishAuthModes[] | cdktn.IResolvable): void;
    resetDefaultPublishAuthModes(): void;
    get defaultPublishAuthModesInput(): cdktn.IResolvable | AppsyncApiEventConfigDefaultPublishAuthModes[] | undefined;
    private _defaultSubscribeAuthModes;
    get defaultSubscribeAuthModes(): AppsyncApiEventConfigDefaultSubscribeAuthModesList;
    putDefaultSubscribeAuthModes(value: AppsyncApiEventConfigDefaultSubscribeAuthModes[] | cdktn.IResolvable): void;
    resetDefaultSubscribeAuthModes(): void;
    get defaultSubscribeAuthModesInput(): cdktn.IResolvable | AppsyncApiEventConfigDefaultSubscribeAuthModes[] | undefined;
    private _logConfig;
    get logConfig(): AppsyncApiEventConfigLogConfigOutputReference;
    putLogConfig(value: AppsyncApiEventConfigLogConfig): void;
    resetLogConfig(): void;
    get logConfigInput(): cdktn.IResolvable | AppsyncApiEventConfigLogConfig | undefined;
}
export interface AppsyncApiTags {
    /**
    * A string used to identify this tag. You can specify a maximum of 128 characters for a tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#key AppsyncApi#key}
    */
    readonly key?: string;
    /**
    * A string containing the value for this tag. You can specify a maximum of 256 characters for a tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#value AppsyncApi#value}
    */
    readonly value?: string;
}
export declare function appsyncApiTagsToTerraform(struct?: AppsyncApiTags | cdktn.IResolvable): any;
export declare function appsyncApiTagsToHclTerraform(struct?: AppsyncApiTags | cdktn.IResolvable): any;
export declare class AppsyncApiTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppsyncApiTagsList extends cdktn.ComplexList {
    internalValue?: AppsyncApiTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api awscc_appsync_api}
*/
export declare class AppsyncApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_api";
    /**
    * Generates CDKTN code for importing a AppsyncApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncApi to import
    * @param importFromId The id of the existing AppsyncApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_api awscc_appsync_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncApiConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncApiConfig);
    get apiArn(): string;
    get apiId(): string;
    private _dns;
    get dns(): AppsyncApiDnsOutputReference;
    private _eventConfig;
    get eventConfig(): AppsyncApiEventConfigOutputReference;
    putEventConfig(value: AppsyncApiEventConfig): void;
    resetEventConfig(): void;
    get eventConfigInput(): cdktn.IResolvable | AppsyncApiEventConfig | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ownerContact?;
    get ownerContact(): string;
    set ownerContact(value: string);
    resetOwnerContact(): void;
    get ownerContactInput(): string | undefined;
    private _tags;
    get tags(): AppsyncApiTagsList;
    putTags(value: AppsyncApiTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppsyncApiTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
