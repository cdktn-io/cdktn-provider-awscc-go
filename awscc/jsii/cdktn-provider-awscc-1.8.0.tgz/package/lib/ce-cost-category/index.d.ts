/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CeCostCategoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * The default value for the cost category
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#default_value CeCostCategory#default_value}
    */
    readonly defaultValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#name CeCostCategory#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#rule_version CeCostCategory#rule_version}
    */
    readonly ruleVersion: string;
    /**
    * JSON array format of Expression in Billing and Cost Management API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#rules CeCostCategory#rules}
    */
    readonly rules: string;
    /**
    * Json array format of CostCategorySplitChargeRule in Billing and Cost Management API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#split_charge_rules CeCostCategory#split_charge_rules}
    */
    readonly splitChargeRules?: string;
    /**
    * Tags to assign to the cost category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#tags CeCostCategory#tags}
    */
    readonly tags?: CeCostCategoryTags[] | cdktn.IResolvable;
}
export interface CeCostCategoryTags {
    /**
    * The key name for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#key CeCostCategory#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#value CeCostCategory#value}
    */
    readonly value?: string;
}
export declare function ceCostCategoryTagsToTerraform(struct?: CeCostCategoryTags | cdktn.IResolvable): any;
export declare function ceCostCategoryTagsToHclTerraform(struct?: CeCostCategoryTags | cdktn.IResolvable): any;
export declare class CeCostCategoryTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CeCostCategoryTags | cdktn.IResolvable | undefined;
    set internalValue(value: CeCostCategoryTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CeCostCategoryTagsList extends cdktn.ComplexList {
    internalValue?: CeCostCategoryTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CeCostCategoryTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category awscc_ce_cost_category}
*/
export declare class CeCostCategory extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_ce_cost_category";
    /**
    * Generates CDKTN code for importing a CeCostCategory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CeCostCategory to import
    * @param importFromId The id of the existing CeCostCategory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CeCostCategory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/ce_cost_category awscc_ce_cost_category} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CeCostCategoryConfig
    */
    constructor(scope: Construct, id: string, config: CeCostCategoryConfig);
    get arn(): string;
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    get effectiveStart(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ruleVersion?;
    get ruleVersion(): string;
    set ruleVersion(value: string);
    get ruleVersionInput(): string | undefined;
    private _rules?;
    get rules(): string;
    set rules(value: string);
    get rulesInput(): string | undefined;
    private _splitChargeRules?;
    get splitChargeRules(): string;
    set splitChargeRules(value: string);
    resetSplitChargeRules(): void;
    get splitChargeRulesInput(): string | undefined;
    private _tags;
    get tags(): CeCostCategoryTagsList;
    putTags(value: CeCostCategoryTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CeCostCategoryTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
