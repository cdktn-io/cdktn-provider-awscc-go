/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamStackFleetAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the fleet. To associate a fleet with a stack, you must specify a dependency on the fleet resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appstream_stack_fleet_association#fleet_name AppstreamStackFleetAssociation#fleet_name}
    */
    readonly fleetName: string;
    /**
    * The name of the stack. To associate a fleet with a stack, you must specify a dependency on the stack resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appstream_stack_fleet_association#stack_name AppstreamStackFleetAssociation#stack_name}
    */
    readonly stackName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appstream_stack_fleet_association awscc_appstream_stack_fleet_association}
*/
export declare class AppstreamStackFleetAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_stack_fleet_association";
    /**
    * Generates CDKTN code for importing a AppstreamStackFleetAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamStackFleetAssociation to import
    * @param importFromId The id of the existing AppstreamStackFleetAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appstream_stack_fleet_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamStackFleetAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appstream_stack_fleet_association awscc_appstream_stack_fleet_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamStackFleetAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamStackFleetAssociationConfig);
    private _fleetName?;
    get fleetName(): string;
    set fleetName(value: string);
    get fleetNameInput(): string | undefined;
    get id(): string;
    private _stackName?;
    get stackName(): string;
    set stackName(value: string);
    get stackNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
