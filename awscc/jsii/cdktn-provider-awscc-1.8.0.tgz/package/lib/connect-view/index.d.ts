/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * The actions of the view in an array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#actions ConnectView#actions}
    */
    readonly actions: string[];
    /**
    * The description of the view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#description ConnectView#description}
    */
    readonly description?: string;
    /**
    * The Amazon Resource Name (ARN) of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#instance_arn ConnectView#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#name ConnectView#name}
    */
    readonly name: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#tags ConnectView#tags}
    */
    readonly tags?: ConnectViewTags[] | cdktn.IResolvable;
    /**
    * The template of the view as JSON.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#template ConnectView#template}
    */
    readonly template: string;
}
export interface ConnectViewTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#key ConnectView#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. . You can specify a value that is maximum of 256 Unicode characters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#value ConnectView#value}
    */
    readonly value?: string;
}
export declare function connectViewTagsToTerraform(struct?: ConnectViewTags | cdktn.IResolvable): any;
export declare function connectViewTagsToHclTerraform(struct?: ConnectViewTags | cdktn.IResolvable): any;
export declare class ConnectViewTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectViewTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectViewTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectViewTagsList extends cdktn.ComplexList {
    internalValue?: ConnectViewTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectViewTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view awscc_connect_view}
*/
export declare class ConnectView extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_view";
    /**
    * Generates CDKTN code for importing a ConnectView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectView to import
    * @param importFromId The id of the existing ConnectView that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_view awscc_connect_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectViewConfig
    */
    constructor(scope: Construct, id: string, config: ConnectViewConfig);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    get actionsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): ConnectViewTagsList;
    putTags(value: ConnectViewTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectViewTags[] | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    get templateInput(): string | undefined;
    get viewArn(): string;
    get viewContentSha256(): string;
    get viewId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
