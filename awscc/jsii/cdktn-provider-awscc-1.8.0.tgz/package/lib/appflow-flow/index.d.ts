/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppflowFlowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#description AppflowFlow#description}
    */
    readonly description?: string;
    /**
    * List of Destination connectors of the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#destination_flow_config_list AppflowFlow#destination_flow_config_list}
    */
    readonly destinationFlowConfigList: AppflowFlowDestinationFlowConfigListStruct[] | cdktn.IResolvable;
    /**
    * Name of the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#flow_name AppflowFlow#flow_name}
    */
    readonly flowName: string;
    /**
    * Flow activation status for Scheduled- and Event-triggered flows
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#flow_status AppflowFlow#flow_status}
    */
    readonly flowStatus?: string;
    /**
    * The ARN of the AWS Key Management Service (AWS KMS) key that's used to encrypt your function's environment variables. If it's not provided, AWS Lambda uses a default service key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#kms_arn AppflowFlow#kms_arn}
    */
    readonly kmsArn?: string;
    /**
    * Configurations of metadata catalog of the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#metadata_catalog_config AppflowFlow#metadata_catalog_config}
    */
    readonly metadataCatalogConfig?: AppflowFlowMetadataCatalogConfig;
    /**
    * Configurations of Source connector of the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#source_flow_config AppflowFlow#source_flow_config}
    */
    readonly sourceFlowConfig: AppflowFlowSourceFlowConfig;
    /**
    * List of Tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#tags AppflowFlow#tags}
    */
    readonly tags?: AppflowFlowTags[] | cdktn.IResolvable;
    /**
    * List of tasks for the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#tasks AppflowFlow#tasks}
    */
    readonly tasks: AppflowFlowTasks[] | cdktn.IResolvable;
    /**
    * Trigger settings of the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#trigger_config AppflowFlow#trigger_config}
    */
    readonly triggerConfig: AppflowFlowTriggerConfig;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#fail_on_first_error AppflowFlow#fail_on_first_error}
    */
    readonly failOnFirstError?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _failOnFirstError?;
    get failOnFirstError(): boolean | cdktn.IResolvable;
    set failOnFirstError(value: boolean | cdktn.IResolvable);
    resetFailOnFirstError(): void;
    get failOnFirstErrorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnector {
    /**
    * A map for properties for custom connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#custom_properties AppflowFlow#custom_properties}
    */
    readonly customProperties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#entity_name AppflowFlow#entity_name}
    */
    readonly entityName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#error_handling_config AppflowFlow#error_handling_config}
    */
    readonly errorHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfig;
    /**
    * List of fields used as ID when performing a write operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#id_field_names AppflowFlow#id_field_names}
    */
    readonly idFieldNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#write_operation_type AppflowFlow#write_operation_type}
    */
    readonly writeOperationType?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnector | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnector | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnector | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnector | cdktn.IResolvable | undefined);
    private _customProperties?;
    get customProperties(): {
        [key: string]: string;
    };
    set customProperties(value: {
        [key: string]: string;
    });
    resetCustomProperties(): void;
    get customPropertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    resetEntityName(): void;
    get entityNameInput(): string | undefined;
    private _errorHandlingConfig;
    get errorHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigOutputReference;
    putErrorHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfig): void;
    resetErrorHandlingConfig(): void;
    get errorHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorErrorHandlingConfig | undefined;
    private _idFieldNames?;
    get idFieldNames(): string[];
    set idFieldNames(value: string[]);
    resetIdFieldNames(): void;
    get idFieldNamesInput(): string[] | undefined;
    private _writeOperationType?;
    get writeOperationType(): string;
    set writeOperationType(value: string);
    resetWriteOperationType(): void;
    get writeOperationTypeInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#fail_on_first_error AppflowFlow#fail_on_first_error}
    */
    readonly failOnFirstError?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _failOnFirstError?;
    get failOnFirstError(): boolean | cdktn.IResolvable;
    set failOnFirstError(value: boolean | cdktn.IResolvable);
    resetFailOnFirstError(): void;
    get failOnFirstErrorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridge {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#error_handling_config AppflowFlow#error_handling_config}
    */
    readonly errorHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridge | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridge | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridge | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridge | cdktn.IResolvable | undefined);
    private _errorHandlingConfig;
    get errorHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfigOutputReference;
    putErrorHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfig): void;
    resetErrorHandlingConfig(): void;
    get errorHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeErrorHandlingConfig | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetrics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetricsToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetrics | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetricsToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetrics | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetrics | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#fail_on_first_error AppflowFlow#fail_on_first_error}
    */
    readonly failOnFirstError?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _failOnFirstError?;
    get failOnFirstError(): boolean | cdktn.IResolvable;
    set failOnFirstError(value: boolean | cdktn.IResolvable);
    resetFailOnFirstError(): void;
    get failOnFirstErrorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#error_handling_config AppflowFlow#error_handling_config}
    */
    readonly errorHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketo | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketo | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketo | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketo | cdktn.IResolvable | undefined);
    private _errorHandlingConfig;
    get errorHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfigOutputReference;
    putErrorHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfig): void;
    resetErrorHandlingConfig(): void;
    get errorHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoErrorHandlingConfig | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#fail_on_first_error AppflowFlow#fail_on_first_error}
    */
    readonly failOnFirstError?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _failOnFirstError?;
    get failOnFirstError(): boolean | cdktn.IResolvable;
    set failOnFirstError(value: boolean | cdktn.IResolvable);
    resetFailOnFirstError(): void;
    get failOnFirstErrorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshift {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#error_handling_config AppflowFlow#error_handling_config}
    */
    readonly errorHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#intermediate_bucket_name AppflowFlow#intermediate_bucket_name}
    */
    readonly intermediateBucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshift | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshift | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshift | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshift | cdktn.IResolvable | undefined);
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _errorHandlingConfig;
    get errorHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfigOutputReference;
    putErrorHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfig): void;
    resetErrorHandlingConfig(): void;
    get errorHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftErrorHandlingConfig | undefined;
    private _intermediateBucketName?;
    get intermediateBucketName(): string;
    set intermediateBucketName(value: string);
    resetIntermediateBucketName(): void;
    get intermediateBucketNameInput(): string | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#aggregation_type AppflowFlow#aggregation_type}
    */
    readonly aggregationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#target_file_size AppflowFlow#target_file_size}
    */
    readonly targetFileSize?: number;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfig | cdktn.IResolvable | undefined);
    private _aggregationType?;
    get aggregationType(): string;
    set aggregationType(value: string);
    resetAggregationType(): void;
    get aggregationTypeInput(): string | undefined;
    private _targetFileSize?;
    get targetFileSize(): number;
    set targetFileSize(value: number);
    resetTargetFileSize(): void;
    get targetFileSizeInput(): number | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#path_prefix_hierarchy AppflowFlow#path_prefix_hierarchy}
    */
    readonly pathPrefixHierarchy?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#prefix_format AppflowFlow#prefix_format}
    */
    readonly prefixFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#prefix_type AppflowFlow#prefix_type}
    */
    readonly prefixType?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfig | cdktn.IResolvable | undefined);
    private _pathPrefixHierarchy?;
    get pathPrefixHierarchy(): string[];
    set pathPrefixHierarchy(value: string[]);
    resetPathPrefixHierarchy(): void;
    get pathPrefixHierarchyInput(): string[] | undefined;
    private _prefixFormat?;
    get prefixFormat(): string;
    set prefixFormat(value: string);
    resetPrefixFormat(): void;
    get prefixFormatInput(): string | undefined;
    private _prefixType?;
    get prefixType(): string;
    set prefixType(value: string);
    resetPrefixType(): void;
    get prefixTypeInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#aggregation_config AppflowFlow#aggregation_config}
    */
    readonly aggregationConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#file_type AppflowFlow#file_type}
    */
    readonly fileType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#prefix_config AppflowFlow#prefix_config}
    */
    readonly prefixConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#preserve_source_data_typing AppflowFlow#preserve_source_data_typing}
    */
    readonly preserveSourceDataTyping?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfig | cdktn.IResolvable | undefined);
    private _aggregationConfig;
    get aggregationConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigOutputReference;
    putAggregationConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfig): void;
    resetAggregationConfig(): void;
    get aggregationConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfig | undefined;
    private _fileType?;
    get fileType(): string;
    set fileType(value: string);
    resetFileType(): void;
    get fileTypeInput(): string | undefined;
    private _prefixConfig;
    get prefixConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigOutputReference;
    putPrefixConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfig): void;
    resetPrefixConfig(): void;
    get prefixConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfig | undefined;
    private _preserveSourceDataTyping?;
    get preserveSourceDataTyping(): boolean | cdktn.IResolvable;
    set preserveSourceDataTyping(value: boolean | cdktn.IResolvable);
    resetPreserveSourceDataTyping(): void;
    get preserveSourceDataTypingInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#s3_output_format_config AppflowFlow#s3_output_format_config}
    */
    readonly s3OutputFormatConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfig;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3ToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3 | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3ToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3 | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3 | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3 | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _s3OutputFormatConfig;
    get s3OutputFormatConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfigOutputReference;
    putS3OutputFormatConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfig): void;
    resetS3OutputFormatConfig(): void;
    get s3OutputFormatConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3S3OutputFormatConfig | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#fail_on_first_error AppflowFlow#fail_on_first_error}
    */
    readonly failOnFirstError?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _failOnFirstError?;
    get failOnFirstError(): boolean | cdktn.IResolvable;
    set failOnFirstError(value: boolean | cdktn.IResolvable);
    resetFailOnFirstError(): void;
    get failOnFirstErrorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforce {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#data_transfer_api AppflowFlow#data_transfer_api}
    */
    readonly dataTransferApi?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#error_handling_config AppflowFlow#error_handling_config}
    */
    readonly errorHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfig;
    /**
    * List of fields used as ID when performing a write operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#id_field_names AppflowFlow#id_field_names}
    */
    readonly idFieldNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#write_operation_type AppflowFlow#write_operation_type}
    */
    readonly writeOperationType?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforce | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforce | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforce | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforce | cdktn.IResolvable | undefined);
    private _dataTransferApi?;
    get dataTransferApi(): string;
    set dataTransferApi(value: string);
    resetDataTransferApi(): void;
    get dataTransferApiInput(): string | undefined;
    private _errorHandlingConfig;
    get errorHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfigOutputReference;
    putErrorHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfig): void;
    resetErrorHandlingConfig(): void;
    get errorHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceErrorHandlingConfig | undefined;
    private _idFieldNames?;
    get idFieldNames(): string[];
    set idFieldNames(value: string[]);
    resetIdFieldNames(): void;
    get idFieldNamesInput(): string[] | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
    private _writeOperationType?;
    get writeOperationType(): string;
    set writeOperationType(value: string);
    resetWriteOperationType(): void;
    get writeOperationTypeInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#fail_on_first_error AppflowFlow#fail_on_first_error}
    */
    readonly failOnFirstError?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _failOnFirstError?;
    get failOnFirstError(): boolean | cdktn.IResolvable;
    set failOnFirstError(value: boolean | cdktn.IResolvable);
    resetFailOnFirstError(): void;
    get failOnFirstErrorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoData {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#error_handling_config AppflowFlow#error_handling_config}
    */
    readonly errorHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfig;
    /**
    * List of fields used as ID when performing a write operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#id_field_names AppflowFlow#id_field_names}
    */
    readonly idFieldNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object_path AppflowFlow#object_path}
    */
    readonly objectPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#success_response_handling_config AppflowFlow#success_response_handling_config}
    */
    readonly successResponseHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#write_operation_type AppflowFlow#write_operation_type}
    */
    readonly writeOperationType?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoData | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoData | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoData | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoData | cdktn.IResolvable | undefined);
    private _errorHandlingConfig;
    get errorHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfigOutputReference;
    putErrorHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfig): void;
    resetErrorHandlingConfig(): void;
    get errorHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataErrorHandlingConfig | undefined;
    private _idFieldNames?;
    get idFieldNames(): string[];
    set idFieldNames(value: string[]);
    resetIdFieldNames(): void;
    get idFieldNamesInput(): string[] | undefined;
    private _objectPath?;
    get objectPath(): string;
    set objectPath(value: string);
    resetObjectPath(): void;
    get objectPathInput(): string | undefined;
    private _successResponseHandlingConfig;
    get successResponseHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfigOutputReference;
    putSuccessResponseHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfig): void;
    resetSuccessResponseHandlingConfig(): void;
    get successResponseHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataSuccessResponseHandlingConfig | undefined;
    private _writeOperationType?;
    get writeOperationType(): string;
    set writeOperationType(value: string);
    resetWriteOperationType(): void;
    get writeOperationTypeInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#fail_on_first_error AppflowFlow#fail_on_first_error}
    */
    readonly failOnFirstError?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _failOnFirstError?;
    get failOnFirstError(): boolean | cdktn.IResolvable;
    set failOnFirstError(value: boolean | cdktn.IResolvable);
    resetFailOnFirstError(): void;
    get failOnFirstErrorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflake {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#error_handling_config AppflowFlow#error_handling_config}
    */
    readonly errorHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#intermediate_bucket_name AppflowFlow#intermediate_bucket_name}
    */
    readonly intermediateBucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflake | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflake | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflake | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflake | cdktn.IResolvable | undefined);
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _errorHandlingConfig;
    get errorHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfigOutputReference;
    putErrorHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfig): void;
    resetErrorHandlingConfig(): void;
    get errorHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeErrorHandlingConfig | undefined;
    private _intermediateBucketName?;
    get intermediateBucketName(): string;
    set intermediateBucketName(value: string);
    resetIntermediateBucketName(): void;
    get intermediateBucketNameInput(): string | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#aggregation_type AppflowFlow#aggregation_type}
    */
    readonly aggregationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#target_file_size AppflowFlow#target_file_size}
    */
    readonly targetFileSize?: number;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfig | cdktn.IResolvable | undefined);
    private _aggregationType?;
    get aggregationType(): string;
    set aggregationType(value: string);
    resetAggregationType(): void;
    get aggregationTypeInput(): string | undefined;
    private _targetFileSize?;
    get targetFileSize(): number;
    set targetFileSize(value: number);
    resetTargetFileSize(): void;
    get targetFileSizeInput(): number | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#path_prefix_hierarchy AppflowFlow#path_prefix_hierarchy}
    */
    readonly pathPrefixHierarchy?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#prefix_format AppflowFlow#prefix_format}
    */
    readonly prefixFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#prefix_type AppflowFlow#prefix_type}
    */
    readonly prefixType?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfig | cdktn.IResolvable | undefined);
    private _pathPrefixHierarchy?;
    get pathPrefixHierarchy(): string[];
    set pathPrefixHierarchy(value: string[]);
    resetPathPrefixHierarchy(): void;
    get pathPrefixHierarchyInput(): string[] | undefined;
    private _prefixFormat?;
    get prefixFormat(): string;
    set prefixFormat(value: string);
    resetPrefixFormat(): void;
    get prefixFormatInput(): string | undefined;
    private _prefixType?;
    get prefixType(): string;
    set prefixType(value: string);
    resetPrefixType(): void;
    get prefixTypeInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#aggregation_config AppflowFlow#aggregation_config}
    */
    readonly aggregationConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#file_type AppflowFlow#file_type}
    */
    readonly fileType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#prefix_config AppflowFlow#prefix_config}
    */
    readonly prefixConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfig;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfig | cdktn.IResolvable | undefined);
    private _aggregationConfig;
    get aggregationConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigOutputReference;
    putAggregationConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfig): void;
    resetAggregationConfig(): void;
    get aggregationConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfig | undefined;
    private _fileType?;
    get fileType(): string;
    set fileType(value: string);
    resetFileType(): void;
    get fileTypeInput(): string | undefined;
    private _prefixConfig;
    get prefixConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigOutputReference;
    putPrefixConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfig): void;
    resetPrefixConfig(): void;
    get prefixConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfig | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolver {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#s3_output_format_config AppflowFlow#s3_output_format_config}
    */
    readonly s3OutputFormatConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfig;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolver | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolver | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolver | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolver | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _s3OutputFormatConfig;
    get s3OutputFormatConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfigOutputReference;
    putS3OutputFormatConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfig): void;
    resetS3OutputFormatConfig(): void;
    get s3OutputFormatConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverS3OutputFormatConfig | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#fail_on_first_error AppflowFlow#fail_on_first_error}
    */
    readonly failOnFirstError?: boolean | cdktn.IResolvable;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfigToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfig | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfigToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfig | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfig | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _failOnFirstError?;
    get failOnFirstError(): boolean | cdktn.IResolvable;
    set failOnFirstError(value: boolean | cdktn.IResolvable);
    resetFailOnFirstError(): void;
    get failOnFirstErrorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendesk {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#error_handling_config AppflowFlow#error_handling_config}
    */
    readonly errorHandlingConfig?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfig;
    /**
    * List of fields used as ID when performing a write operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#id_field_names AppflowFlow#id_field_names}
    */
    readonly idFieldNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#write_operation_type AppflowFlow#write_operation_type}
    */
    readonly writeOperationType?: string;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendesk | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendesk | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendesk | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendesk | cdktn.IResolvable | undefined);
    private _errorHandlingConfig;
    get errorHandlingConfig(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfigOutputReference;
    putErrorHandlingConfig(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfig): void;
    resetErrorHandlingConfig(): void;
    get errorHandlingConfigInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskErrorHandlingConfig | undefined;
    private _idFieldNames?;
    get idFieldNames(): string[];
    set idFieldNames(value: string[]);
    resetIdFieldNames(): void;
    get idFieldNamesInput(): string[] | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
    private _writeOperationType?;
    get writeOperationType(): string;
    set writeOperationType(value: string);
    resetWriteOperationType(): void;
    get writeOperationTypeInput(): string | undefined;
}
export interface AppflowFlowDestinationFlowConfigListDestinationConnectorProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#custom_connector AppflowFlow#custom_connector}
    */
    readonly customConnector?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnector;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#event_bridge AppflowFlow#event_bridge}
    */
    readonly eventBridge?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridge;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#lookout_metrics AppflowFlow#lookout_metrics}
    */
    readonly lookoutMetrics?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetrics;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#marketo AppflowFlow#marketo}
    */
    readonly marketo?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketo;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#redshift AppflowFlow#redshift}
    */
    readonly redshift?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshift;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#s3 AppflowFlow#s3}
    */
    readonly s3?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#salesforce AppflowFlow#salesforce}
    */
    readonly salesforce?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforce;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#sapo_data AppflowFlow#sapo_data}
    */
    readonly sapoData?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoData;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#snowflake AppflowFlow#snowflake}
    */
    readonly snowflake?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflake;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#upsolver AppflowFlow#upsolver}
    */
    readonly upsolver?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolver;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#zendesk AppflowFlow#zendesk}
    */
    readonly zendesk?: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendesk;
}
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesToTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorProperties | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListDestinationConnectorPropertiesToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListDestinationConnectorProperties | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowDestinationFlowConfigListDestinationConnectorProperties | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListDestinationConnectorProperties | cdktn.IResolvable | undefined);
    private _customConnector;
    get customConnector(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnectorOutputReference;
    putCustomConnector(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnector): void;
    resetCustomConnector(): void;
    get customConnectorInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesCustomConnector | undefined;
    private _eventBridge;
    get eventBridge(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridgeOutputReference;
    putEventBridge(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridge): void;
    resetEventBridge(): void;
    get eventBridgeInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesEventBridge | undefined;
    private _lookoutMetrics;
    get lookoutMetrics(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetricsOutputReference;
    putLookoutMetrics(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetrics): void;
    resetLookoutMetrics(): void;
    get lookoutMetricsInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesLookoutMetrics | undefined;
    private _marketo;
    get marketo(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketoOutputReference;
    putMarketo(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketo): void;
    resetMarketo(): void;
    get marketoInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesMarketo | undefined;
    private _redshift;
    get redshift(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshiftOutputReference;
    putRedshift(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshift): void;
    resetRedshift(): void;
    get redshiftInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesRedshift | undefined;
    private _s3;
    get s3(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3OutputReference;
    putS3(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesS3 | undefined;
    private _salesforce;
    get salesforce(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforceOutputReference;
    putSalesforce(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforce): void;
    resetSalesforce(): void;
    get salesforceInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSalesforce | undefined;
    private _sapoData;
    get sapoData(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoDataOutputReference;
    putSapoData(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoData): void;
    resetSapoData(): void;
    get sapoDataInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSapoData | undefined;
    private _snowflake;
    get snowflake(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflakeOutputReference;
    putSnowflake(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflake): void;
    resetSnowflake(): void;
    get snowflakeInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesSnowflake | undefined;
    private _upsolver;
    get upsolver(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolverOutputReference;
    putUpsolver(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolver): void;
    resetUpsolver(): void;
    get upsolverInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesUpsolver | undefined;
    private _zendesk;
    get zendesk(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendeskOutputReference;
    putZendesk(value: AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendesk): void;
    resetZendesk(): void;
    get zendeskInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesZendesk | undefined;
}
export interface AppflowFlowDestinationFlowConfigListStruct {
    /**
    * The API version that the destination connector uses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#api_version AppflowFlow#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Name of destination connector profile
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#connector_profile_name AppflowFlow#connector_profile_name}
    */
    readonly connectorProfileName?: string;
    /**
    * Destination connector type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#connector_type AppflowFlow#connector_type}
    */
    readonly connectorType: string;
    /**
    * Destination connector details
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#destination_connector_properties AppflowFlow#destination_connector_properties}
    */
    readonly destinationConnectorProperties: AppflowFlowDestinationFlowConfigListDestinationConnectorProperties;
}
export declare function appflowFlowDestinationFlowConfigListStructToTerraform(struct?: AppflowFlowDestinationFlowConfigListStruct | cdktn.IResolvable): any;
export declare function appflowFlowDestinationFlowConfigListStructToHclTerraform(struct?: AppflowFlowDestinationFlowConfigListStruct | cdktn.IResolvable): any;
export declare class AppflowFlowDestinationFlowConfigListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppflowFlowDestinationFlowConfigListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowDestinationFlowConfigListStruct | cdktn.IResolvable | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _connectorProfileName?;
    get connectorProfileName(): string;
    set connectorProfileName(value: string);
    resetConnectorProfileName(): void;
    get connectorProfileNameInput(): string | undefined;
    private _connectorType?;
    get connectorType(): string;
    set connectorType(value: string);
    get connectorTypeInput(): string | undefined;
    private _destinationConnectorProperties;
    get destinationConnectorProperties(): AppflowFlowDestinationFlowConfigListDestinationConnectorPropertiesOutputReference;
    putDestinationConnectorProperties(value: AppflowFlowDestinationFlowConfigListDestinationConnectorProperties): void;
    get destinationConnectorPropertiesInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListDestinationConnectorProperties | undefined;
}
export declare class AppflowFlowDestinationFlowConfigListStructList extends cdktn.ComplexList {
    internalValue?: AppflowFlowDestinationFlowConfigListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppflowFlowDestinationFlowConfigListStructOutputReference;
}
export interface AppflowFlowMetadataCatalogConfigGlueDataCatalog {
    /**
    * A string containing the value for the tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#database_name AppflowFlow#database_name}
    */
    readonly databaseName?: string;
    /**
    * A string containing the value for the tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#role_arn AppflowFlow#role_arn}
    */
    readonly roleArn?: string;
    /**
    * A string containing the value for the tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#table_prefix AppflowFlow#table_prefix}
    */
    readonly tablePrefix?: string;
}
export declare function appflowFlowMetadataCatalogConfigGlueDataCatalogToTerraform(struct?: AppflowFlowMetadataCatalogConfigGlueDataCatalog | cdktn.IResolvable): any;
export declare function appflowFlowMetadataCatalogConfigGlueDataCatalogToHclTerraform(struct?: AppflowFlowMetadataCatalogConfigGlueDataCatalog | cdktn.IResolvable): any;
export declare class AppflowFlowMetadataCatalogConfigGlueDataCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowMetadataCatalogConfigGlueDataCatalog | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowMetadataCatalogConfigGlueDataCatalog | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _tablePrefix?;
    get tablePrefix(): string;
    set tablePrefix(value: string);
    resetTablePrefix(): void;
    get tablePrefixInput(): string | undefined;
}
export interface AppflowFlowMetadataCatalogConfig {
    /**
    * Configurations of glue data catalog of the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#glue_data_catalog AppflowFlow#glue_data_catalog}
    */
    readonly glueDataCatalog?: AppflowFlowMetadataCatalogConfigGlueDataCatalog;
}
export declare function appflowFlowMetadataCatalogConfigToTerraform(struct?: AppflowFlowMetadataCatalogConfig | cdktn.IResolvable): any;
export declare function appflowFlowMetadataCatalogConfigToHclTerraform(struct?: AppflowFlowMetadataCatalogConfig | cdktn.IResolvable): any;
export declare class AppflowFlowMetadataCatalogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowMetadataCatalogConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowMetadataCatalogConfig | cdktn.IResolvable | undefined);
    private _glueDataCatalog;
    get glueDataCatalog(): AppflowFlowMetadataCatalogConfigGlueDataCatalogOutputReference;
    putGlueDataCatalog(value: AppflowFlowMetadataCatalogConfigGlueDataCatalog): void;
    resetGlueDataCatalog(): void;
    get glueDataCatalogInput(): cdktn.IResolvable | AppflowFlowMetadataCatalogConfigGlueDataCatalog | undefined;
}
export interface AppflowFlowSourceFlowConfigIncrementalPullConfig {
    /**
    * Name of the datetime/timestamp data type field to be used for importing incremental records from the source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#datetime_type_field_name AppflowFlow#datetime_type_field_name}
    */
    readonly datetimeTypeFieldName?: string;
}
export declare function appflowFlowSourceFlowConfigIncrementalPullConfigToTerraform(struct?: AppflowFlowSourceFlowConfigIncrementalPullConfig | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigIncrementalPullConfigToHclTerraform(struct?: AppflowFlowSourceFlowConfigIncrementalPullConfig | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigIncrementalPullConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigIncrementalPullConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigIncrementalPullConfig | cdktn.IResolvable | undefined);
    private _datetimeTypeFieldName?;
    get datetimeTypeFieldName(): string;
    set datetimeTypeFieldName(value: string);
    resetDatetimeTypeFieldName(): void;
    get datetimeTypeFieldNameInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitude {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitudeToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitude | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitudeToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitude | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitudeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitude | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitude | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#name AppflowFlow#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#type AppflowFlow#type}
    */
    readonly type?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApiToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApi | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApiToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApi | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApi | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApi | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnector {
    /**
    * A map for properties for custom connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#custom_properties AppflowFlow#custom_properties}
    */
    readonly customProperties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#data_transfer_api AppflowFlow#data_transfer_api}
    */
    readonly dataTransferApi?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#entity_name AppflowFlow#entity_name}
    */
    readonly entityName?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnector | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnector | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnector | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnector | cdktn.IResolvable | undefined);
    private _customProperties?;
    get customProperties(): {
        [key: string]: string;
    };
    set customProperties(value: {
        [key: string]: string;
    });
    resetCustomProperties(): void;
    get customPropertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _dataTransferApi;
    get dataTransferApi(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApiOutputReference;
    putDataTransferApi(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApi): void;
    resetDataTransferApi(): void;
    get dataTransferApiInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorDataTransferApi | undefined;
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    resetEntityName(): void;
    get entityNameInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesDatadogToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadog | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesDatadogToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadog | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadog | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadog | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatrace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesDynatraceToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatrace | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesDynatraceToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatrace | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatraceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatrace | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatrace | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalytics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalyticsToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalytics | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalyticsToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalytics | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalyticsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalytics | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalytics | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexusToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexus | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexusToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexus | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexus | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexus | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesMarketoToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketo | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesMarketoToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketo | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketo | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketo | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardot {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesPardotToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardot | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesPardotToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardot | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardot | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardot | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#s3_input_file_type AppflowFlow#s3_input_file_type}
    */
    readonly s3InputFileType?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfigToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfig | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfigToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfig | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfig | cdktn.IResolvable | undefined);
    private _s3InputFileType?;
    get s3InputFileType(): string;
    set s3InputFileType(value: string);
    resetS3InputFileType(): void;
    get s3InputFileTypeInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_name AppflowFlow#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#bucket_prefix AppflowFlow#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#s3_input_format_config AppflowFlow#s3_input_format_config}
    */
    readonly s3InputFormatConfig?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfig;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesS3ToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3 | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesS3ToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3 | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3 | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3 | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _s3InputFormatConfig;
    get s3InputFormatConfig(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfigOutputReference;
    putS3InputFormatConfig(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfig): void;
    resetS3InputFormatConfig(): void;
    get s3InputFormatConfigInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3S3InputFormatConfig | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforce {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#data_transfer_api AppflowFlow#data_transfer_api}
    */
    readonly dataTransferApi?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#enable_dynamic_field_update AppflowFlow#enable_dynamic_field_update}
    */
    readonly enableDynamicFieldUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#include_deleted_records AppflowFlow#include_deleted_records}
    */
    readonly includeDeletedRecords?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforceToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforce | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforceToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforce | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforce | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforce | cdktn.IResolvable | undefined);
    private _dataTransferApi?;
    get dataTransferApi(): string;
    set dataTransferApi(value: string);
    resetDataTransferApi(): void;
    get dataTransferApiInput(): string | undefined;
    private _enableDynamicFieldUpdate?;
    get enableDynamicFieldUpdate(): boolean | cdktn.IResolvable;
    set enableDynamicFieldUpdate(value: boolean | cdktn.IResolvable);
    resetEnableDynamicFieldUpdate(): void;
    get enableDynamicFieldUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _includeDeletedRecords?;
    get includeDeletedRecords(): boolean | cdktn.IResolvable;
    set includeDeletedRecords(value: boolean | cdktn.IResolvable);
    resetIncludeDeletedRecords(): void;
    get includeDeletedRecordsInput(): boolean | cdktn.IResolvable | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#max_page_size AppflowFlow#max_page_size}
    */
    readonly maxPageSize?: number;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfigToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfig | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfigToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfig | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfig | cdktn.IResolvable | undefined);
    private _maxPageSize?;
    get maxPageSize(): number;
    set maxPageSize(value: number);
    resetMaxPageSize(): void;
    get maxPageSizeInput(): number | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#max_parallelism AppflowFlow#max_parallelism}
    */
    readonly maxParallelism?: number;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfigToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfig | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfigToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfig | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfig | cdktn.IResolvable | undefined);
    private _maxParallelism?;
    get maxParallelism(): number;
    set maxParallelism(value: number);
    resetMaxParallelism(): void;
    get maxParallelismInput(): number | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoData {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object_path AppflowFlow#object_path}
    */
    readonly objectPath?: string;
    /**
    * SAP Source connector page size
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#pagination_config AppflowFlow#pagination_config}
    */
    readonly paginationConfig?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfig;
    /**
    * SAP Source connector parallelism factor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#parallelism_config AppflowFlow#parallelism_config}
    */
    readonly parallelismConfig?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfig;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoData | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoData | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoData | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoData | cdktn.IResolvable | undefined);
    private _objectPath?;
    get objectPath(): string;
    set objectPath(value: string);
    resetObjectPath(): void;
    get objectPathInput(): string | undefined;
    private _paginationConfig;
    get paginationConfig(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfigOutputReference;
    putPaginationConfig(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfig): void;
    resetPaginationConfig(): void;
    get paginationConfigInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPaginationConfig | undefined;
    private _parallelismConfig;
    get parallelismConfig(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfigOutputReference;
    putParallelismConfig(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfig): void;
    resetParallelismConfig(): void;
    get parallelismConfigInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataParallelismConfig | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNowToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNow | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNowToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNow | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNow | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNow | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingular {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSingularToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingular | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSingularToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingular | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingularOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingular | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingular | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlack {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSlackToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlack | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesSlackToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlack | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlack | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlack | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicro {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicroToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicro | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicroToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicro | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicro | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicro | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeeva {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#document_type AppflowFlow#document_type}
    */
    readonly documentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#include_all_versions AppflowFlow#include_all_versions}
    */
    readonly includeAllVersions?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#include_renditions AppflowFlow#include_renditions}
    */
    readonly includeRenditions?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#include_source_files AppflowFlow#include_source_files}
    */
    readonly includeSourceFiles?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesVeevaToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeeva | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesVeevaToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeeva | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeevaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeeva | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeeva | cdktn.IResolvable | undefined);
    private _documentType?;
    get documentType(): string;
    set documentType(value: string);
    resetDocumentType(): void;
    get documentTypeInput(): string | undefined;
    private _includeAllVersions?;
    get includeAllVersions(): boolean | cdktn.IResolvable;
    set includeAllVersions(value: boolean | cdktn.IResolvable);
    resetIncludeAllVersions(): void;
    get includeAllVersionsInput(): boolean | cdktn.IResolvable | undefined;
    private _includeRenditions?;
    get includeRenditions(): boolean | cdktn.IResolvable;
    set includeRenditions(value: boolean | cdktn.IResolvable);
    resetIncludeRenditions(): void;
    get includeRenditionsInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSourceFiles?;
    get includeSourceFiles(): boolean | cdktn.IResolvable;
    set includeSourceFiles(value: boolean | cdktn.IResolvable);
    resetIncludeSourceFiles(): void;
    get includeSourceFilesInput(): boolean | cdktn.IResolvable | undefined;
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendesk {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#object AppflowFlow#object}
    */
    readonly object?: string;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesZendeskToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendesk | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesZendeskToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendesk | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendeskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendesk | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendesk | cdktn.IResolvable | undefined);
    private _object?;
    get object(): string;
    set object(value: string);
    resetObject(): void;
    get objectInput(): string | undefined;
}
export interface AppflowFlowSourceFlowConfigSourceConnectorProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#amplitude AppflowFlow#amplitude}
    */
    readonly amplitude?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitude;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#custom_connector AppflowFlow#custom_connector}
    */
    readonly customConnector?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnector;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#datadog AppflowFlow#datadog}
    */
    readonly datadog?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadog;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#dynatrace AppflowFlow#dynatrace}
    */
    readonly dynatrace?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatrace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#google_analytics AppflowFlow#google_analytics}
    */
    readonly googleAnalytics?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalytics;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#infor_nexus AppflowFlow#infor_nexus}
    */
    readonly inforNexus?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#marketo AppflowFlow#marketo}
    */
    readonly marketo?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketo;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#pardot AppflowFlow#pardot}
    */
    readonly pardot?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardot;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#s3 AppflowFlow#s3}
    */
    readonly s3?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#salesforce AppflowFlow#salesforce}
    */
    readonly salesforce?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforce;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#sapo_data AppflowFlow#sapo_data}
    */
    readonly sapoData?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoData;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#service_now AppflowFlow#service_now}
    */
    readonly serviceNow?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#singular AppflowFlow#singular}
    */
    readonly singular?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingular;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#slack AppflowFlow#slack}
    */
    readonly slack?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlack;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#trendmicro AppflowFlow#trendmicro}
    */
    readonly trendmicro?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicro;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#veeva AppflowFlow#veeva}
    */
    readonly veeva?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeeva;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#zendesk AppflowFlow#zendesk}
    */
    readonly zendesk?: AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendesk;
}
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesToTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorProperties | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigSourceConnectorPropertiesToHclTerraform(struct?: AppflowFlowSourceFlowConfigSourceConnectorProperties | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigSourceConnectorPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfigSourceConnectorProperties | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfigSourceConnectorProperties | cdktn.IResolvable | undefined);
    private _amplitude;
    get amplitude(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitudeOutputReference;
    putAmplitude(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitude): void;
    resetAmplitude(): void;
    get amplitudeInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesAmplitude | undefined;
    private _customConnector;
    get customConnector(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorOutputReference;
    putCustomConnector(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnector): void;
    resetCustomConnector(): void;
    get customConnectorInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnector | undefined;
    private _datadog;
    get datadog(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadogOutputReference;
    putDatadog(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadog): void;
    resetDatadog(): void;
    get datadogInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesDatadog | undefined;
    private _dynatrace;
    get dynatrace(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatraceOutputReference;
    putDynatrace(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatrace): void;
    resetDynatrace(): void;
    get dynatraceInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesDynatrace | undefined;
    private _googleAnalytics;
    get googleAnalytics(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalyticsOutputReference;
    putGoogleAnalytics(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalytics): void;
    resetGoogleAnalytics(): void;
    get googleAnalyticsInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesGoogleAnalytics | undefined;
    private _inforNexus;
    get inforNexus(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexusOutputReference;
    putInforNexus(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexus): void;
    resetInforNexus(): void;
    get inforNexusInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesInforNexus | undefined;
    private _marketo;
    get marketo(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketoOutputReference;
    putMarketo(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketo): void;
    resetMarketo(): void;
    get marketoInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketo | undefined;
    private _pardot;
    get pardot(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardotOutputReference;
    putPardot(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardot): void;
    resetPardot(): void;
    get pardotInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesPardot | undefined;
    private _s3;
    get s3(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3OutputReference;
    putS3(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesS3 | undefined;
    private _salesforce;
    get salesforce(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforceOutputReference;
    putSalesforce(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforce): void;
    resetSalesforce(): void;
    get salesforceInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforce | undefined;
    private _sapoData;
    get sapoData(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataOutputReference;
    putSapoData(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoData): void;
    resetSapoData(): void;
    get sapoDataInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoData | undefined;
    private _serviceNow;
    get serviceNow(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNowOutputReference;
    putServiceNow(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNow): void;
    resetServiceNow(): void;
    get serviceNowInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesServiceNow | undefined;
    private _singular;
    get singular(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingularOutputReference;
    putSingular(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingular): void;
    resetSingular(): void;
    get singularInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesSingular | undefined;
    private _slack;
    get slack(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlackOutputReference;
    putSlack(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlack): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesSlack | undefined;
    private _trendmicro;
    get trendmicro(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicroOutputReference;
    putTrendmicro(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicro): void;
    resetTrendmicro(): void;
    get trendmicroInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesTrendmicro | undefined;
    private _veeva;
    get veeva(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeevaOutputReference;
    putVeeva(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeeva): void;
    resetVeeva(): void;
    get veevaInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesVeeva | undefined;
    private _zendesk;
    get zendesk(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendeskOutputReference;
    putZendesk(value: AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendesk): void;
    resetZendesk(): void;
    get zendeskInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorPropertiesZendesk | undefined;
}
export interface AppflowFlowSourceFlowConfig {
    /**
    * The API version that the destination connector uses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#api_version AppflowFlow#api_version}
    */
    readonly apiVersion?: string;
    /**
    * Name of source connector profile
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#connector_profile_name AppflowFlow#connector_profile_name}
    */
    readonly connectorProfileName?: string;
    /**
    * Type of source connector
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#connector_type AppflowFlow#connector_type}
    */
    readonly connectorType: string;
    /**
    * Configuration for scheduled incremental data pull
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#incremental_pull_config AppflowFlow#incremental_pull_config}
    */
    readonly incrementalPullConfig?: AppflowFlowSourceFlowConfigIncrementalPullConfig;
    /**
    * Source connector details required to query a connector
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#source_connector_properties AppflowFlow#source_connector_properties}
    */
    readonly sourceConnectorProperties: AppflowFlowSourceFlowConfigSourceConnectorProperties;
}
export declare function appflowFlowSourceFlowConfigToTerraform(struct?: AppflowFlowSourceFlowConfig | cdktn.IResolvable): any;
export declare function appflowFlowSourceFlowConfigToHclTerraform(struct?: AppflowFlowSourceFlowConfig | cdktn.IResolvable): any;
export declare class AppflowFlowSourceFlowConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowSourceFlowConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowSourceFlowConfig | cdktn.IResolvable | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _connectorProfileName?;
    get connectorProfileName(): string;
    set connectorProfileName(value: string);
    resetConnectorProfileName(): void;
    get connectorProfileNameInput(): string | undefined;
    private _connectorType?;
    get connectorType(): string;
    set connectorType(value: string);
    get connectorTypeInput(): string | undefined;
    private _incrementalPullConfig;
    get incrementalPullConfig(): AppflowFlowSourceFlowConfigIncrementalPullConfigOutputReference;
    putIncrementalPullConfig(value: AppflowFlowSourceFlowConfigIncrementalPullConfig): void;
    resetIncrementalPullConfig(): void;
    get incrementalPullConfigInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigIncrementalPullConfig | undefined;
    private _sourceConnectorProperties;
    get sourceConnectorProperties(): AppflowFlowSourceFlowConfigSourceConnectorPropertiesOutputReference;
    putSourceConnectorProperties(value: AppflowFlowSourceFlowConfigSourceConnectorProperties): void;
    get sourceConnectorPropertiesInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfigSourceConnectorProperties | undefined;
}
export interface AppflowFlowTags {
    /**
    * A string used to identify this tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#key AppflowFlow#key}
    */
    readonly key?: string;
    /**
    * A string containing the value for the tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#value AppflowFlow#value}
    */
    readonly value?: string;
}
export declare function appflowFlowTagsToTerraform(struct?: AppflowFlowTags | cdktn.IResolvable): any;
export declare function appflowFlowTagsToHclTerraform(struct?: AppflowFlowTags | cdktn.IResolvable): any;
export declare class AppflowFlowTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppflowFlowTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppflowFlowTagsList extends cdktn.ComplexList {
    internalValue?: AppflowFlowTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppflowFlowTagsOutputReference;
}
export interface AppflowFlowTasksConnectorOperator {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#amplitude AppflowFlow#amplitude}
    */
    readonly amplitude?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#custom_connector AppflowFlow#custom_connector}
    */
    readonly customConnector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#datadog AppflowFlow#datadog}
    */
    readonly datadog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#dynatrace AppflowFlow#dynatrace}
    */
    readonly dynatrace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#google_analytics AppflowFlow#google_analytics}
    */
    readonly googleAnalytics?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#infor_nexus AppflowFlow#infor_nexus}
    */
    readonly inforNexus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#marketo AppflowFlow#marketo}
    */
    readonly marketo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#pardot AppflowFlow#pardot}
    */
    readonly pardot?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#s3 AppflowFlow#s3}
    */
    readonly s3?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#salesforce AppflowFlow#salesforce}
    */
    readonly salesforce?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#sapo_data AppflowFlow#sapo_data}
    */
    readonly sapoData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#service_now AppflowFlow#service_now}
    */
    readonly serviceNow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#singular AppflowFlow#singular}
    */
    readonly singular?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#slack AppflowFlow#slack}
    */
    readonly slack?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#trendmicro AppflowFlow#trendmicro}
    */
    readonly trendmicro?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#veeva AppflowFlow#veeva}
    */
    readonly veeva?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#zendesk AppflowFlow#zendesk}
    */
    readonly zendesk?: string;
}
export declare function appflowFlowTasksConnectorOperatorToTerraform(struct?: AppflowFlowTasksConnectorOperator | cdktn.IResolvable): any;
export declare function appflowFlowTasksConnectorOperatorToHclTerraform(struct?: AppflowFlowTasksConnectorOperator | cdktn.IResolvable): any;
export declare class AppflowFlowTasksConnectorOperatorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowTasksConnectorOperator | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowTasksConnectorOperator | cdktn.IResolvable | undefined);
    private _amplitude?;
    get amplitude(): string;
    set amplitude(value: string);
    resetAmplitude(): void;
    get amplitudeInput(): string | undefined;
    private _customConnector?;
    get customConnector(): string;
    set customConnector(value: string);
    resetCustomConnector(): void;
    get customConnectorInput(): string | undefined;
    private _datadog?;
    get datadog(): string;
    set datadog(value: string);
    resetDatadog(): void;
    get datadogInput(): string | undefined;
    private _dynatrace?;
    get dynatrace(): string;
    set dynatrace(value: string);
    resetDynatrace(): void;
    get dynatraceInput(): string | undefined;
    private _googleAnalytics?;
    get googleAnalytics(): string;
    set googleAnalytics(value: string);
    resetGoogleAnalytics(): void;
    get googleAnalyticsInput(): string | undefined;
    private _inforNexus?;
    get inforNexus(): string;
    set inforNexus(value: string);
    resetInforNexus(): void;
    get inforNexusInput(): string | undefined;
    private _marketo?;
    get marketo(): string;
    set marketo(value: string);
    resetMarketo(): void;
    get marketoInput(): string | undefined;
    private _pardot?;
    get pardot(): string;
    set pardot(value: string);
    resetPardot(): void;
    get pardotInput(): string | undefined;
    private _s3?;
    get s3(): string;
    set s3(value: string);
    resetS3(): void;
    get s3Input(): string | undefined;
    private _salesforce?;
    get salesforce(): string;
    set salesforce(value: string);
    resetSalesforce(): void;
    get salesforceInput(): string | undefined;
    private _sapoData?;
    get sapoData(): string;
    set sapoData(value: string);
    resetSapoData(): void;
    get sapoDataInput(): string | undefined;
    private _serviceNow?;
    get serviceNow(): string;
    set serviceNow(value: string);
    resetServiceNow(): void;
    get serviceNowInput(): string | undefined;
    private _singular?;
    get singular(): string;
    set singular(value: string);
    resetSingular(): void;
    get singularInput(): string | undefined;
    private _slack?;
    get slack(): string;
    set slack(value: string);
    resetSlack(): void;
    get slackInput(): string | undefined;
    private _trendmicro?;
    get trendmicro(): string;
    set trendmicro(value: string);
    resetTrendmicro(): void;
    get trendmicroInput(): string | undefined;
    private _veeva?;
    get veeva(): string;
    set veeva(value: string);
    resetVeeva(): void;
    get veevaInput(): string | undefined;
    private _zendesk?;
    get zendesk(): string;
    set zendesk(value: string);
    resetZendesk(): void;
    get zendeskInput(): string | undefined;
}
export interface AppflowFlowTasksTaskProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#key AppflowFlow#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#value AppflowFlow#value}
    */
    readonly value?: string;
}
export declare function appflowFlowTasksTaskPropertiesToTerraform(struct?: AppflowFlowTasksTaskProperties | cdktn.IResolvable): any;
export declare function appflowFlowTasksTaskPropertiesToHclTerraform(struct?: AppflowFlowTasksTaskProperties | cdktn.IResolvable): any;
export declare class AppflowFlowTasksTaskPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppflowFlowTasksTaskProperties | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowTasksTaskProperties | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppflowFlowTasksTaskPropertiesList extends cdktn.ComplexList {
    internalValue?: AppflowFlowTasksTaskProperties[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppflowFlowTasksTaskPropertiesOutputReference;
}
export interface AppflowFlowTasks {
    /**
    * Operation to be performed on provided source fields
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#connector_operator AppflowFlow#connector_operator}
    */
    readonly connectorOperator?: AppflowFlowTasksConnectorOperator;
    /**
    * A field value on which source field should be validated
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#destination_field AppflowFlow#destination_field}
    */
    readonly destinationField?: string;
    /**
    * Source fields on which particular task will be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#source_fields AppflowFlow#source_fields}
    */
    readonly sourceFields: string[];
    /**
    * A Map used to store task related info
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#task_properties AppflowFlow#task_properties}
    */
    readonly taskProperties?: AppflowFlowTasksTaskProperties[] | cdktn.IResolvable;
    /**
    * Type of task
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#task_type AppflowFlow#task_type}
    */
    readonly taskType: string;
}
export declare function appflowFlowTasksToTerraform(struct?: AppflowFlowTasks | cdktn.IResolvable): any;
export declare function appflowFlowTasksToHclTerraform(struct?: AppflowFlowTasks | cdktn.IResolvable): any;
export declare class AppflowFlowTasksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppflowFlowTasks | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowTasks | cdktn.IResolvable | undefined);
    private _connectorOperator;
    get connectorOperator(): AppflowFlowTasksConnectorOperatorOutputReference;
    putConnectorOperator(value: AppflowFlowTasksConnectorOperator): void;
    resetConnectorOperator(): void;
    get connectorOperatorInput(): cdktn.IResolvable | AppflowFlowTasksConnectorOperator | undefined;
    private _destinationField?;
    get destinationField(): string;
    set destinationField(value: string);
    resetDestinationField(): void;
    get destinationFieldInput(): string | undefined;
    private _sourceFields?;
    get sourceFields(): string[];
    set sourceFields(value: string[]);
    get sourceFieldsInput(): string[] | undefined;
    private _taskProperties;
    get taskProperties(): AppflowFlowTasksTaskPropertiesList;
    putTaskProperties(value: AppflowFlowTasksTaskProperties[] | cdktn.IResolvable): void;
    resetTaskProperties(): void;
    get taskPropertiesInput(): cdktn.IResolvable | AppflowFlowTasksTaskProperties[] | undefined;
    private _taskType?;
    get taskType(): string;
    set taskType(value: string);
    get taskTypeInput(): string | undefined;
}
export declare class AppflowFlowTasksList extends cdktn.ComplexList {
    internalValue?: AppflowFlowTasks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppflowFlowTasksOutputReference;
}
export interface AppflowFlowTriggerConfigTriggerProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#data_pull_mode AppflowFlow#data_pull_mode}
    */
    readonly dataPullMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#first_execution_from AppflowFlow#first_execution_from}
    */
    readonly firstExecutionFrom?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#flow_error_deactivation_threshold AppflowFlow#flow_error_deactivation_threshold}
    */
    readonly flowErrorDeactivationThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#schedule_end_time AppflowFlow#schedule_end_time}
    */
    readonly scheduleEndTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#schedule_expression AppflowFlow#schedule_expression}
    */
    readonly scheduleExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#schedule_offset AppflowFlow#schedule_offset}
    */
    readonly scheduleOffset?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#schedule_start_time AppflowFlow#schedule_start_time}
    */
    readonly scheduleStartTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#time_zone AppflowFlow#time_zone}
    */
    readonly timeZone?: string;
}
export declare function appflowFlowTriggerConfigTriggerPropertiesToTerraform(struct?: AppflowFlowTriggerConfigTriggerProperties | cdktn.IResolvable): any;
export declare function appflowFlowTriggerConfigTriggerPropertiesToHclTerraform(struct?: AppflowFlowTriggerConfigTriggerProperties | cdktn.IResolvable): any;
export declare class AppflowFlowTriggerConfigTriggerPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowTriggerConfigTriggerProperties | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowTriggerConfigTriggerProperties | cdktn.IResolvable | undefined);
    private _dataPullMode?;
    get dataPullMode(): string;
    set dataPullMode(value: string);
    resetDataPullMode(): void;
    get dataPullModeInput(): string | undefined;
    private _firstExecutionFrom?;
    get firstExecutionFrom(): number;
    set firstExecutionFrom(value: number);
    resetFirstExecutionFrom(): void;
    get firstExecutionFromInput(): number | undefined;
    private _flowErrorDeactivationThreshold?;
    get flowErrorDeactivationThreshold(): number;
    set flowErrorDeactivationThreshold(value: number);
    resetFlowErrorDeactivationThreshold(): void;
    get flowErrorDeactivationThresholdInput(): number | undefined;
    private _scheduleEndTime?;
    get scheduleEndTime(): number;
    set scheduleEndTime(value: number);
    resetScheduleEndTime(): void;
    get scheduleEndTimeInput(): number | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    resetScheduleExpression(): void;
    get scheduleExpressionInput(): string | undefined;
    private _scheduleOffset?;
    get scheduleOffset(): number;
    set scheduleOffset(value: number);
    resetScheduleOffset(): void;
    get scheduleOffsetInput(): number | undefined;
    private _scheduleStartTime?;
    get scheduleStartTime(): number;
    set scheduleStartTime(value: number);
    resetScheduleStartTime(): void;
    get scheduleStartTimeInput(): number | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
}
export interface AppflowFlowTriggerConfig {
    /**
    * Details required based on the type of trigger
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#trigger_properties AppflowFlow#trigger_properties}
    */
    readonly triggerProperties?: AppflowFlowTriggerConfigTriggerProperties;
    /**
    * Trigger type of the flow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#trigger_type AppflowFlow#trigger_type}
    */
    readonly triggerType: string;
}
export declare function appflowFlowTriggerConfigToTerraform(struct?: AppflowFlowTriggerConfig | cdktn.IResolvable): any;
export declare function appflowFlowTriggerConfigToHclTerraform(struct?: AppflowFlowTriggerConfig | cdktn.IResolvable): any;
export declare class AppflowFlowTriggerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppflowFlowTriggerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppflowFlowTriggerConfig | cdktn.IResolvable | undefined);
    private _triggerProperties;
    get triggerProperties(): AppflowFlowTriggerConfigTriggerPropertiesOutputReference;
    putTriggerProperties(value: AppflowFlowTriggerConfigTriggerProperties): void;
    resetTriggerProperties(): void;
    get triggerPropertiesInput(): cdktn.IResolvable | AppflowFlowTriggerConfigTriggerProperties | undefined;
    private _triggerType?;
    get triggerType(): string;
    set triggerType(value: string);
    get triggerTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow awscc_appflow_flow}
*/
export declare class AppflowFlow extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appflow_flow";
    /**
    * Generates CDKTN code for importing a AppflowFlow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppflowFlow to import
    * @param importFromId The id of the existing AppflowFlow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppflowFlow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appflow_flow awscc_appflow_flow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppflowFlowConfig
    */
    constructor(scope: Construct, id: string, config: AppflowFlowConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destinationFlowConfigList;
    get destinationFlowConfigList(): AppflowFlowDestinationFlowConfigListStructList;
    putDestinationFlowConfigList(value: AppflowFlowDestinationFlowConfigListStruct[] | cdktn.IResolvable): void;
    get destinationFlowConfigListInput(): cdktn.IResolvable | AppflowFlowDestinationFlowConfigListStruct[] | undefined;
    get flowArn(): string;
    private _flowName?;
    get flowName(): string;
    set flowName(value: string);
    get flowNameInput(): string | undefined;
    private _flowStatus?;
    get flowStatus(): string;
    set flowStatus(value: string);
    resetFlowStatus(): void;
    get flowStatusInput(): string | undefined;
    get id(): string;
    private _kmsArn?;
    get kmsArn(): string;
    set kmsArn(value: string);
    resetKmsArn(): void;
    get kmsArnInput(): string | undefined;
    private _metadataCatalogConfig;
    get metadataCatalogConfig(): AppflowFlowMetadataCatalogConfigOutputReference;
    putMetadataCatalogConfig(value: AppflowFlowMetadataCatalogConfig): void;
    resetMetadataCatalogConfig(): void;
    get metadataCatalogConfigInput(): cdktn.IResolvable | AppflowFlowMetadataCatalogConfig | undefined;
    private _sourceFlowConfig;
    get sourceFlowConfig(): AppflowFlowSourceFlowConfigOutputReference;
    putSourceFlowConfig(value: AppflowFlowSourceFlowConfig): void;
    get sourceFlowConfigInput(): cdktn.IResolvable | AppflowFlowSourceFlowConfig | undefined;
    private _tags;
    get tags(): AppflowFlowTagsList;
    putTags(value: AppflowFlowTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppflowFlowTags[] | undefined;
    private _tasks;
    get tasks(): AppflowFlowTasksList;
    putTasks(value: AppflowFlowTasks[] | cdktn.IResolvable): void;
    get tasksInput(): cdktn.IResolvable | AppflowFlowTasks[] | undefined;
    private _triggerConfig;
    get triggerConfig(): AppflowFlowTriggerConfigOutputReference;
    putTriggerConfig(value: AppflowFlowTriggerConfig): void;
    get triggerConfigInput(): cdktn.IResolvable | AppflowFlowTriggerConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
