/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApsResourcePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The JSON to use as the Resource-based Policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_resource_policy#policy_document ApsResourcePolicy#policy_document}
    */
    readonly policyDocument: string;
    /**
    * The Arn of an APS Workspace that the PolicyDocument will be attached to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_resource_policy#workspace_arn ApsResourcePolicy#workspace_arn}
    */
    readonly workspaceArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_resource_policy awscc_aps_resource_policy}
*/
export declare class ApsResourcePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_aps_resource_policy";
    /**
    * Generates CDKTN code for importing a ApsResourcePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApsResourcePolicy to import
    * @param importFromId The id of the existing ApsResourcePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_resource_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApsResourcePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_resource_policy awscc_aps_resource_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApsResourcePolicyConfig
    */
    constructor(scope: Construct, id: string, config: ApsResourcePolicyConfig);
    get id(): string;
    private _policyDocument?;
    get policyDocument(): string;
    set policyDocument(value: string);
    get policyDocumentInput(): string | undefined;
    private _workspaceArn?;
    get workspaceArn(): string;
    set workspaceArn(value: string);
    get workspaceArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
