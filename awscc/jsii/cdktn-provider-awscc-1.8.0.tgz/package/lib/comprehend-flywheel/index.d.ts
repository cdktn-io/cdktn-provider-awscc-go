/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComprehendFlywheelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#active_model_arn ComprehendFlywheel#active_model_arn}
    */
    readonly activeModelArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#data_access_role_arn ComprehendFlywheel#data_access_role_arn}
    */
    readonly dataAccessRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#data_lake_s3_uri ComprehendFlywheel#data_lake_s3_uri}
    */
    readonly dataLakeS3Uri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#data_security_config ComprehendFlywheel#data_security_config}
    */
    readonly dataSecurityConfig?: ComprehendFlywheelDataSecurityConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#flywheel_name ComprehendFlywheel#flywheel_name}
    */
    readonly flywheelName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#model_type ComprehendFlywheel#model_type}
    */
    readonly modelType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#tags ComprehendFlywheel#tags}
    */
    readonly tags?: ComprehendFlywheelTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#task_config ComprehendFlywheel#task_config}
    */
    readonly taskConfig?: ComprehendFlywheelTaskConfig;
}
export interface ComprehendFlywheelDataSecurityConfigVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#security_group_ids ComprehendFlywheel#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#subnets ComprehendFlywheel#subnets}
    */
    readonly subnets?: string[];
}
export declare function comprehendFlywheelDataSecurityConfigVpcConfigToTerraform(struct?: ComprehendFlywheelDataSecurityConfigVpcConfig | cdktn.IResolvable): any;
export declare function comprehendFlywheelDataSecurityConfigVpcConfigToHclTerraform(struct?: ComprehendFlywheelDataSecurityConfigVpcConfig | cdktn.IResolvable): any;
export declare class ComprehendFlywheelDataSecurityConfigVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendFlywheelDataSecurityConfigVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendFlywheelDataSecurityConfigVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
export interface ComprehendFlywheelDataSecurityConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#data_lake_kms_key_id ComprehendFlywheel#data_lake_kms_key_id}
    */
    readonly dataLakeKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#model_kms_key_id ComprehendFlywheel#model_kms_key_id}
    */
    readonly modelKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#volume_kms_key_id ComprehendFlywheel#volume_kms_key_id}
    */
    readonly volumeKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#vpc_config ComprehendFlywheel#vpc_config}
    */
    readonly vpcConfig?: ComprehendFlywheelDataSecurityConfigVpcConfig;
}
export declare function comprehendFlywheelDataSecurityConfigToTerraform(struct?: ComprehendFlywheelDataSecurityConfig | cdktn.IResolvable): any;
export declare function comprehendFlywheelDataSecurityConfigToHclTerraform(struct?: ComprehendFlywheelDataSecurityConfig | cdktn.IResolvable): any;
export declare class ComprehendFlywheelDataSecurityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendFlywheelDataSecurityConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendFlywheelDataSecurityConfig | cdktn.IResolvable | undefined);
    private _dataLakeKmsKeyId?;
    get dataLakeKmsKeyId(): string;
    set dataLakeKmsKeyId(value: string);
    resetDataLakeKmsKeyId(): void;
    get dataLakeKmsKeyIdInput(): string | undefined;
    private _modelKmsKeyId?;
    get modelKmsKeyId(): string;
    set modelKmsKeyId(value: string);
    resetModelKmsKeyId(): void;
    get modelKmsKeyIdInput(): string | undefined;
    private _volumeKmsKeyId?;
    get volumeKmsKeyId(): string;
    set volumeKmsKeyId(value: string);
    resetVolumeKmsKeyId(): void;
    get volumeKmsKeyIdInput(): string | undefined;
    private _vpcConfig;
    get vpcConfig(): ComprehendFlywheelDataSecurityConfigVpcConfigOutputReference;
    putVpcConfig(value: ComprehendFlywheelDataSecurityConfigVpcConfig): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | ComprehendFlywheelDataSecurityConfigVpcConfig | undefined;
}
export interface ComprehendFlywheelTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#key ComprehendFlywheel#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#value ComprehendFlywheel#value}
    */
    readonly value?: string;
}
export declare function comprehendFlywheelTagsToTerraform(struct?: ComprehendFlywheelTags | cdktn.IResolvable): any;
export declare function comprehendFlywheelTagsToHclTerraform(struct?: ComprehendFlywheelTags | cdktn.IResolvable): any;
export declare class ComprehendFlywheelTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendFlywheelTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendFlywheelTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComprehendFlywheelTagsList extends cdktn.ComplexList {
    internalValue?: ComprehendFlywheelTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendFlywheelTagsOutputReference;
}
export interface ComprehendFlywheelTaskConfigDocumentClassificationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#labels ComprehendFlywheel#labels}
    */
    readonly labels?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#mode ComprehendFlywheel#mode}
    */
    readonly mode?: string;
}
export declare function comprehendFlywheelTaskConfigDocumentClassificationConfigToTerraform(struct?: ComprehendFlywheelTaskConfigDocumentClassificationConfig | cdktn.IResolvable): any;
export declare function comprehendFlywheelTaskConfigDocumentClassificationConfigToHclTerraform(struct?: ComprehendFlywheelTaskConfigDocumentClassificationConfig | cdktn.IResolvable): any;
export declare class ComprehendFlywheelTaskConfigDocumentClassificationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendFlywheelTaskConfigDocumentClassificationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendFlywheelTaskConfigDocumentClassificationConfig | cdktn.IResolvable | undefined);
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    resetLabels(): void;
    get labelsInput(): string[] | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#type ComprehendFlywheel#type}
    */
    readonly type?: string;
}
export declare function comprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypesToTerraform(struct?: ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes | cdktn.IResolvable): any;
export declare function comprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypesToHclTerraform(struct?: ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes | cdktn.IResolvable): any;
export declare class ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypesList extends cdktn.ComplexList {
    internalValue?: ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypesOutputReference;
}
export interface ComprehendFlywheelTaskConfigEntityRecognitionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#entity_types ComprehendFlywheel#entity_types}
    */
    readonly entityTypes?: ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes[] | cdktn.IResolvable;
}
export declare function comprehendFlywheelTaskConfigEntityRecognitionConfigToTerraform(struct?: ComprehendFlywheelTaskConfigEntityRecognitionConfig | cdktn.IResolvable): any;
export declare function comprehendFlywheelTaskConfigEntityRecognitionConfigToHclTerraform(struct?: ComprehendFlywheelTaskConfigEntityRecognitionConfig | cdktn.IResolvable): any;
export declare class ComprehendFlywheelTaskConfigEntityRecognitionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendFlywheelTaskConfigEntityRecognitionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendFlywheelTaskConfigEntityRecognitionConfig | cdktn.IResolvable | undefined);
    private _entityTypes;
    get entityTypes(): ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypesList;
    putEntityTypes(value: ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes[] | cdktn.IResolvable): void;
    resetEntityTypes(): void;
    get entityTypesInput(): cdktn.IResolvable | ComprehendFlywheelTaskConfigEntityRecognitionConfigEntityTypes[] | undefined;
}
export interface ComprehendFlywheelTaskConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#document_classification_config ComprehendFlywheel#document_classification_config}
    */
    readonly documentClassificationConfig?: ComprehendFlywheelTaskConfigDocumentClassificationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#entity_recognition_config ComprehendFlywheel#entity_recognition_config}
    */
    readonly entityRecognitionConfig?: ComprehendFlywheelTaskConfigEntityRecognitionConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#language_code ComprehendFlywheel#language_code}
    */
    readonly languageCode?: string;
}
export declare function comprehendFlywheelTaskConfigToTerraform(struct?: ComprehendFlywheelTaskConfig | cdktn.IResolvable): any;
export declare function comprehendFlywheelTaskConfigToHclTerraform(struct?: ComprehendFlywheelTaskConfig | cdktn.IResolvable): any;
export declare class ComprehendFlywheelTaskConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendFlywheelTaskConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendFlywheelTaskConfig | cdktn.IResolvable | undefined);
    private _documentClassificationConfig;
    get documentClassificationConfig(): ComprehendFlywheelTaskConfigDocumentClassificationConfigOutputReference;
    putDocumentClassificationConfig(value: ComprehendFlywheelTaskConfigDocumentClassificationConfig): void;
    resetDocumentClassificationConfig(): void;
    get documentClassificationConfigInput(): cdktn.IResolvable | ComprehendFlywheelTaskConfigDocumentClassificationConfig | undefined;
    private _entityRecognitionConfig;
    get entityRecognitionConfig(): ComprehendFlywheelTaskConfigEntityRecognitionConfigOutputReference;
    putEntityRecognitionConfig(value: ComprehendFlywheelTaskConfigEntityRecognitionConfig): void;
    resetEntityRecognitionConfig(): void;
    get entityRecognitionConfigInput(): cdktn.IResolvable | ComprehendFlywheelTaskConfigEntityRecognitionConfig | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    resetLanguageCode(): void;
    get languageCodeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel awscc_comprehend_flywheel}
*/
export declare class ComprehendFlywheel extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_comprehend_flywheel";
    /**
    * Generates CDKTN code for importing a ComprehendFlywheel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComprehendFlywheel to import
    * @param importFromId The id of the existing ComprehendFlywheel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComprehendFlywheel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/comprehend_flywheel awscc_comprehend_flywheel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComprehendFlywheelConfig
    */
    constructor(scope: Construct, id: string, config: ComprehendFlywheelConfig);
    private _activeModelArn?;
    get activeModelArn(): string;
    set activeModelArn(value: string);
    resetActiveModelArn(): void;
    get activeModelArnInput(): string | undefined;
    get arn(): string;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    get dataAccessRoleArnInput(): string | undefined;
    private _dataLakeS3Uri?;
    get dataLakeS3Uri(): string;
    set dataLakeS3Uri(value: string);
    get dataLakeS3UriInput(): string | undefined;
    private _dataSecurityConfig;
    get dataSecurityConfig(): ComprehendFlywheelDataSecurityConfigOutputReference;
    putDataSecurityConfig(value: ComprehendFlywheelDataSecurityConfig): void;
    resetDataSecurityConfig(): void;
    get dataSecurityConfigInput(): cdktn.IResolvable | ComprehendFlywheelDataSecurityConfig | undefined;
    private _flywheelName?;
    get flywheelName(): string;
    set flywheelName(value: string);
    get flywheelNameInput(): string | undefined;
    get id(): string;
    private _modelType?;
    get modelType(): string;
    set modelType(value: string);
    resetModelType(): void;
    get modelTypeInput(): string | undefined;
    private _tags;
    get tags(): ComprehendFlywheelTagsList;
    putTags(value: ComprehendFlywheelTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ComprehendFlywheelTags[] | undefined;
    private _taskConfig;
    get taskConfig(): ComprehendFlywheelTaskConfigOutputReference;
    putTaskConfig(value: ComprehendFlywheelTaskConfig): void;
    resetTaskConfig(): void;
    get taskConfigInput(): cdktn.IResolvable | ComprehendFlywheelTaskConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
