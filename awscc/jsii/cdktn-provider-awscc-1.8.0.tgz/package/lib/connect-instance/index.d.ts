/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The attributes for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#attributes ConnectInstance#attributes}
    */
    readonly attributes: ConnectInstanceAttributes;
    /**
    * Existing directoryId user wants to map to the new Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#directory_id ConnectInstance#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Specifies the type of directory integration for new instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#identity_management_type ConnectInstance#identity_management_type}
    */
    readonly identityManagementType: string;
    /**
    * Alias of the new directory created as part of new instance creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#instance_alias ConnectInstance#instance_alias}
    */
    readonly instanceAlias?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#tags ConnectInstance#tags}
    */
    readonly tags?: ConnectInstanceTags[] | cdktn.IResolvable;
}
export interface ConnectInstanceAttributes {
    /**
    * Boolean flag which enables AUTO_RESOLVE_BEST_VOICES on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#auto_resolve_best_voices ConnectInstance#auto_resolve_best_voices}
    */
    readonly autoResolveBestVoices?: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables CONTACT_LENS on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#contact_lens ConnectInstance#contact_lens}
    */
    readonly contactLens?: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables CONTACTFLOW_LOGS on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#contactflow_logs ConnectInstance#contactflow_logs}
    */
    readonly contactflowLogs?: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables EARLY_MEDIA on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#early_media ConnectInstance#early_media}
    */
    readonly earlyMedia?: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables ENHANCED_CHAT_MONITORING on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#enhanced_chat_monitoring ConnectInstance#enhanced_chat_monitoring}
    */
    readonly enhancedChatMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables ENHANCED_CONTACT_MONITORING on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#enhanced_contact_monitoring ConnectInstance#enhanced_contact_monitoring}
    */
    readonly enhancedContactMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables HIGH_VOLUME_OUTBOUND on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#high_volume_out_bound ConnectInstance#high_volume_out_bound}
    */
    readonly highVolumeOutBound?: boolean | cdktn.IResolvable;
    /**
    * Mandatory element which enables inbound calls on new instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#inbound_calls ConnectInstance#inbound_calls}
    */
    readonly inboundCalls: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables MESSAGE_STREAMING on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#message_streaming ConnectInstance#message_streaming}
    */
    readonly messageStreaming?: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables MULTI_PARTY_CHAT_CONFERENCE on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#multi_party_chat_conference ConnectInstance#multi_party_chat_conference}
    */
    readonly multiPartyChatConference?: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables MULTI_PARTY_CONFERENCE on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#multi_party_conference ConnectInstance#multi_party_conference}
    */
    readonly multiPartyConference?: boolean | cdktn.IResolvable;
    /**
    * Mandatory element which enables outbound calls on new instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#outbound_calls ConnectInstance#outbound_calls}
    */
    readonly outboundCalls: boolean | cdktn.IResolvable;
    /**
    * Boolean flag which enables USE_CUSTOM_TTS_VOICES on an instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#use_custom_tts_voices ConnectInstance#use_custom_tts_voices}
    */
    readonly useCustomTtsVoices?: boolean | cdktn.IResolvable;
}
export declare function connectInstanceAttributesToTerraform(struct?: ConnectInstanceAttributes | cdktn.IResolvable): any;
export declare function connectInstanceAttributesToHclTerraform(struct?: ConnectInstanceAttributes | cdktn.IResolvable): any;
export declare class ConnectInstanceAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectInstanceAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectInstanceAttributes | cdktn.IResolvable | undefined);
    private _autoResolveBestVoices?;
    get autoResolveBestVoices(): boolean | cdktn.IResolvable;
    set autoResolveBestVoices(value: boolean | cdktn.IResolvable);
    resetAutoResolveBestVoices(): void;
    get autoResolveBestVoicesInput(): boolean | cdktn.IResolvable | undefined;
    private _contactLens?;
    get contactLens(): boolean | cdktn.IResolvable;
    set contactLens(value: boolean | cdktn.IResolvable);
    resetContactLens(): void;
    get contactLensInput(): boolean | cdktn.IResolvable | undefined;
    private _contactflowLogs?;
    get contactflowLogs(): boolean | cdktn.IResolvable;
    set contactflowLogs(value: boolean | cdktn.IResolvable);
    resetContactflowLogs(): void;
    get contactflowLogsInput(): boolean | cdktn.IResolvable | undefined;
    private _earlyMedia?;
    get earlyMedia(): boolean | cdktn.IResolvable;
    set earlyMedia(value: boolean | cdktn.IResolvable);
    resetEarlyMedia(): void;
    get earlyMediaInput(): boolean | cdktn.IResolvable | undefined;
    private _enhancedChatMonitoring?;
    get enhancedChatMonitoring(): boolean | cdktn.IResolvable;
    set enhancedChatMonitoring(value: boolean | cdktn.IResolvable);
    resetEnhancedChatMonitoring(): void;
    get enhancedChatMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _enhancedContactMonitoring?;
    get enhancedContactMonitoring(): boolean | cdktn.IResolvable;
    set enhancedContactMonitoring(value: boolean | cdktn.IResolvable);
    resetEnhancedContactMonitoring(): void;
    get enhancedContactMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _highVolumeOutBound?;
    get highVolumeOutBound(): boolean | cdktn.IResolvable;
    set highVolumeOutBound(value: boolean | cdktn.IResolvable);
    resetHighVolumeOutBound(): void;
    get highVolumeOutBoundInput(): boolean | cdktn.IResolvable | undefined;
    private _inboundCalls?;
    get inboundCalls(): boolean | cdktn.IResolvable;
    set inboundCalls(value: boolean | cdktn.IResolvable);
    get inboundCallsInput(): boolean | cdktn.IResolvable | undefined;
    private _messageStreaming?;
    get messageStreaming(): boolean | cdktn.IResolvable;
    set messageStreaming(value: boolean | cdktn.IResolvable);
    resetMessageStreaming(): void;
    get messageStreamingInput(): boolean | cdktn.IResolvable | undefined;
    private _multiPartyChatConference?;
    get multiPartyChatConference(): boolean | cdktn.IResolvable;
    set multiPartyChatConference(value: boolean | cdktn.IResolvable);
    resetMultiPartyChatConference(): void;
    get multiPartyChatConferenceInput(): boolean | cdktn.IResolvable | undefined;
    private _multiPartyConference?;
    get multiPartyConference(): boolean | cdktn.IResolvable;
    set multiPartyConference(value: boolean | cdktn.IResolvable);
    resetMultiPartyConference(): void;
    get multiPartyConferenceInput(): boolean | cdktn.IResolvable | undefined;
    private _outboundCalls?;
    get outboundCalls(): boolean | cdktn.IResolvable;
    set outboundCalls(value: boolean | cdktn.IResolvable);
    get outboundCallsInput(): boolean | cdktn.IResolvable | undefined;
    private _useCustomTtsVoices?;
    get useCustomTtsVoices(): boolean | cdktn.IResolvable;
    set useCustomTtsVoices(value: boolean | cdktn.IResolvable);
    resetUseCustomTtsVoices(): void;
    get useCustomTtsVoicesInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ConnectInstanceTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#key ConnectInstance#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#value ConnectInstance#value}
    */
    readonly value?: string;
}
export declare function connectInstanceTagsToTerraform(struct?: ConnectInstanceTags | cdktn.IResolvable): any;
export declare function connectInstanceTagsToHclTerraform(struct?: ConnectInstanceTags | cdktn.IResolvable): any;
export declare class ConnectInstanceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectInstanceTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectInstanceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectInstanceTagsList extends cdktn.ComplexList {
    internalValue?: ConnectInstanceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectInstanceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance awscc_connect_instance}
*/
export declare class ConnectInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_instance";
    /**
    * Generates CDKTN code for importing a ConnectInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectInstance to import
    * @param importFromId The id of the existing ConnectInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_instance awscc_connect_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectInstanceConfig
    */
    constructor(scope: Construct, id: string, config: ConnectInstanceConfig);
    get arn(): string;
    private _attributes;
    get attributes(): ConnectInstanceAttributesOutputReference;
    putAttributes(value: ConnectInstanceAttributes): void;
    get attributesInput(): cdktn.IResolvable | ConnectInstanceAttributes | undefined;
    get createdTime(): string;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    get id(): string;
    private _identityManagementType?;
    get identityManagementType(): string;
    set identityManagementType(value: string);
    get identityManagementTypeInput(): string | undefined;
    private _instanceAlias?;
    get instanceAlias(): string;
    set instanceAlias(value: string);
    resetInstanceAlias(): void;
    get instanceAliasInput(): string | undefined;
    get instanceId(): string;
    get instanceStatus(): string;
    get serviceRole(): string;
    private _tags;
    get tags(): ConnectInstanceTagsList;
    putTags(value: ConnectInstanceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectInstanceTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
