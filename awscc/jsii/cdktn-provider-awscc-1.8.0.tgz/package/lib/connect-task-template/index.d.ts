/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectTaskTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * the client token string in uuid format
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#client_token ConnectTaskTemplate#client_token}
    */
    readonly clientToken?: string;
    /**
    * The constraints for the task template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#constraints ConnectTaskTemplate#constraints}
    */
    readonly constraints?: ConnectTaskTemplateConstraints;
    /**
    * The identifier of the contact flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#contact_flow_arn ConnectTaskTemplate#contact_flow_arn}
    */
    readonly contactFlowArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#defaults ConnectTaskTemplate#defaults}
    */
    readonly defaults?: ConnectTaskTemplateDefaults[] | cdktn.IResolvable;
    /**
    * The description of the task template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#description ConnectTaskTemplate#description}
    */
    readonly description?: string;
    /**
    * The list of task template's fields
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#fields ConnectTaskTemplate#fields}
    */
    readonly fields?: ConnectTaskTemplateFields[] | cdktn.IResolvable;
    /**
    * The identifier (arn) of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#instance_arn ConnectTaskTemplate#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the task template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#name ConnectTaskTemplate#name}
    */
    readonly name?: string;
    /**
    * The identifier of the contact flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#self_assign_contact_flow_arn ConnectTaskTemplate#self_assign_contact_flow_arn}
    */
    readonly selfAssignContactFlowArn?: string;
    /**
    * The status of the task template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#status ConnectTaskTemplate#status}
    */
    readonly status?: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#tags ConnectTaskTemplate#tags}
    */
    readonly tags?: ConnectTaskTemplateTags[] | cdktn.IResolvable;
}
export interface ConnectTaskTemplateConstraintsInvisibleFieldsId {
    /**
    * The name of the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#name ConnectTaskTemplate#name}
    */
    readonly name?: string;
}
export declare function connectTaskTemplateConstraintsInvisibleFieldsIdToTerraform(struct?: ConnectTaskTemplateConstraintsInvisibleFieldsId | cdktn.IResolvable): any;
export declare function connectTaskTemplateConstraintsInvisibleFieldsIdToHclTerraform(struct?: ConnectTaskTemplateConstraintsInvisibleFieldsId | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateConstraintsInvisibleFieldsIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTaskTemplateConstraintsInvisibleFieldsId | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateConstraintsInvisibleFieldsId | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectTaskTemplateConstraintsInvisibleFields {
    /**
    * the identifier (name) for the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#id ConnectTaskTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: ConnectTaskTemplateConstraintsInvisibleFieldsId;
}
export declare function connectTaskTemplateConstraintsInvisibleFieldsToTerraform(struct?: ConnectTaskTemplateConstraintsInvisibleFields | cdktn.IResolvable): any;
export declare function connectTaskTemplateConstraintsInvisibleFieldsToHclTerraform(struct?: ConnectTaskTemplateConstraintsInvisibleFields | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateConstraintsInvisibleFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectTaskTemplateConstraintsInvisibleFields | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateConstraintsInvisibleFields | cdktn.IResolvable | undefined);
    private _id;
    get id(): ConnectTaskTemplateConstraintsInvisibleFieldsIdOutputReference;
    putId(value: ConnectTaskTemplateConstraintsInvisibleFieldsId): void;
    resetId(): void;
    get idInput(): cdktn.IResolvable | ConnectTaskTemplateConstraintsInvisibleFieldsId | undefined;
}
export declare class ConnectTaskTemplateConstraintsInvisibleFieldsList extends cdktn.ComplexList {
    internalValue?: ConnectTaskTemplateConstraintsInvisibleFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectTaskTemplateConstraintsInvisibleFieldsOutputReference;
}
export interface ConnectTaskTemplateConstraintsReadOnlyFieldsId {
    /**
    * The name of the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#name ConnectTaskTemplate#name}
    */
    readonly name?: string;
}
export declare function connectTaskTemplateConstraintsReadOnlyFieldsIdToTerraform(struct?: ConnectTaskTemplateConstraintsReadOnlyFieldsId | cdktn.IResolvable): any;
export declare function connectTaskTemplateConstraintsReadOnlyFieldsIdToHclTerraform(struct?: ConnectTaskTemplateConstraintsReadOnlyFieldsId | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateConstraintsReadOnlyFieldsIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTaskTemplateConstraintsReadOnlyFieldsId | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateConstraintsReadOnlyFieldsId | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectTaskTemplateConstraintsReadOnlyFields {
    /**
    * the identifier (name) for the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#id ConnectTaskTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: ConnectTaskTemplateConstraintsReadOnlyFieldsId;
}
export declare function connectTaskTemplateConstraintsReadOnlyFieldsToTerraform(struct?: ConnectTaskTemplateConstraintsReadOnlyFields | cdktn.IResolvable): any;
export declare function connectTaskTemplateConstraintsReadOnlyFieldsToHclTerraform(struct?: ConnectTaskTemplateConstraintsReadOnlyFields | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateConstraintsReadOnlyFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectTaskTemplateConstraintsReadOnlyFields | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateConstraintsReadOnlyFields | cdktn.IResolvable | undefined);
    private _id;
    get id(): ConnectTaskTemplateConstraintsReadOnlyFieldsIdOutputReference;
    putId(value: ConnectTaskTemplateConstraintsReadOnlyFieldsId): void;
    resetId(): void;
    get idInput(): cdktn.IResolvable | ConnectTaskTemplateConstraintsReadOnlyFieldsId | undefined;
}
export declare class ConnectTaskTemplateConstraintsReadOnlyFieldsList extends cdktn.ComplexList {
    internalValue?: ConnectTaskTemplateConstraintsReadOnlyFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectTaskTemplateConstraintsReadOnlyFieldsOutputReference;
}
export interface ConnectTaskTemplateConstraintsRequiredFieldsId {
    /**
    * The name of the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#name ConnectTaskTemplate#name}
    */
    readonly name?: string;
}
export declare function connectTaskTemplateConstraintsRequiredFieldsIdToTerraform(struct?: ConnectTaskTemplateConstraintsRequiredFieldsId | cdktn.IResolvable): any;
export declare function connectTaskTemplateConstraintsRequiredFieldsIdToHclTerraform(struct?: ConnectTaskTemplateConstraintsRequiredFieldsId | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateConstraintsRequiredFieldsIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTaskTemplateConstraintsRequiredFieldsId | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateConstraintsRequiredFieldsId | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectTaskTemplateConstraintsRequiredFields {
    /**
    * the identifier (name) for the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#id ConnectTaskTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: ConnectTaskTemplateConstraintsRequiredFieldsId;
}
export declare function connectTaskTemplateConstraintsRequiredFieldsToTerraform(struct?: ConnectTaskTemplateConstraintsRequiredFields | cdktn.IResolvable): any;
export declare function connectTaskTemplateConstraintsRequiredFieldsToHclTerraform(struct?: ConnectTaskTemplateConstraintsRequiredFields | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateConstraintsRequiredFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectTaskTemplateConstraintsRequiredFields | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateConstraintsRequiredFields | cdktn.IResolvable | undefined);
    private _id;
    get id(): ConnectTaskTemplateConstraintsRequiredFieldsIdOutputReference;
    putId(value: ConnectTaskTemplateConstraintsRequiredFieldsId): void;
    resetId(): void;
    get idInput(): cdktn.IResolvable | ConnectTaskTemplateConstraintsRequiredFieldsId | undefined;
}
export declare class ConnectTaskTemplateConstraintsRequiredFieldsList extends cdktn.ComplexList {
    internalValue?: ConnectTaskTemplateConstraintsRequiredFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectTaskTemplateConstraintsRequiredFieldsOutputReference;
}
export interface ConnectTaskTemplateConstraints {
    /**
    * The list of the task template's invisible fields
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#invisible_fields ConnectTaskTemplate#invisible_fields}
    */
    readonly invisibleFields?: ConnectTaskTemplateConstraintsInvisibleFields[] | cdktn.IResolvable;
    /**
    * The list of the task template's read only fields
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#read_only_fields ConnectTaskTemplate#read_only_fields}
    */
    readonly readOnlyFields?: ConnectTaskTemplateConstraintsReadOnlyFields[] | cdktn.IResolvable;
    /**
    * The list of the task template's required fields
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#required_fields ConnectTaskTemplate#required_fields}
    */
    readonly requiredFields?: ConnectTaskTemplateConstraintsRequiredFields[] | cdktn.IResolvable;
}
export declare function connectTaskTemplateConstraintsToTerraform(struct?: ConnectTaskTemplateConstraints | cdktn.IResolvable): any;
export declare function connectTaskTemplateConstraintsToHclTerraform(struct?: ConnectTaskTemplateConstraints | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTaskTemplateConstraints | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateConstraints | cdktn.IResolvable | undefined);
    private _invisibleFields;
    get invisibleFields(): ConnectTaskTemplateConstraintsInvisibleFieldsList;
    putInvisibleFields(value: ConnectTaskTemplateConstraintsInvisibleFields[] | cdktn.IResolvable): void;
    resetInvisibleFields(): void;
    get invisibleFieldsInput(): cdktn.IResolvable | ConnectTaskTemplateConstraintsInvisibleFields[] | undefined;
    private _readOnlyFields;
    get readOnlyFields(): ConnectTaskTemplateConstraintsReadOnlyFieldsList;
    putReadOnlyFields(value: ConnectTaskTemplateConstraintsReadOnlyFields[] | cdktn.IResolvable): void;
    resetReadOnlyFields(): void;
    get readOnlyFieldsInput(): cdktn.IResolvable | ConnectTaskTemplateConstraintsReadOnlyFields[] | undefined;
    private _requiredFields;
    get requiredFields(): ConnectTaskTemplateConstraintsRequiredFieldsList;
    putRequiredFields(value: ConnectTaskTemplateConstraintsRequiredFields[] | cdktn.IResolvable): void;
    resetRequiredFields(): void;
    get requiredFieldsInput(): cdktn.IResolvable | ConnectTaskTemplateConstraintsRequiredFields[] | undefined;
}
export interface ConnectTaskTemplateDefaultsId {
    /**
    * The name of the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#name ConnectTaskTemplate#name}
    */
    readonly name?: string;
}
export declare function connectTaskTemplateDefaultsIdToTerraform(struct?: ConnectTaskTemplateDefaultsId | cdktn.IResolvable): any;
export declare function connectTaskTemplateDefaultsIdToHclTerraform(struct?: ConnectTaskTemplateDefaultsId | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateDefaultsIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTaskTemplateDefaultsId | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateDefaultsId | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectTaskTemplateDefaults {
    /**
    * the default value for the task template's field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#default_value ConnectTaskTemplate#default_value}
    */
    readonly defaultValue?: string;
    /**
    * the identifier (name) for the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#id ConnectTaskTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: ConnectTaskTemplateDefaultsId;
}
export declare function connectTaskTemplateDefaultsToTerraform(struct?: ConnectTaskTemplateDefaults | cdktn.IResolvable): any;
export declare function connectTaskTemplateDefaultsToHclTerraform(struct?: ConnectTaskTemplateDefaults | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateDefaultsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectTaskTemplateDefaults | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateDefaults | cdktn.IResolvable | undefined);
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _id;
    get id(): ConnectTaskTemplateDefaultsIdOutputReference;
    putId(value: ConnectTaskTemplateDefaultsId): void;
    resetId(): void;
    get idInput(): cdktn.IResolvable | ConnectTaskTemplateDefaultsId | undefined;
}
export declare class ConnectTaskTemplateDefaultsList extends cdktn.ComplexList {
    internalValue?: ConnectTaskTemplateDefaults[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectTaskTemplateDefaultsOutputReference;
}
export interface ConnectTaskTemplateFieldsId {
    /**
    * The name of the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#name ConnectTaskTemplate#name}
    */
    readonly name?: string;
}
export declare function connectTaskTemplateFieldsIdToTerraform(struct?: ConnectTaskTemplateFieldsId | cdktn.IResolvable): any;
export declare function connectTaskTemplateFieldsIdToHclTerraform(struct?: ConnectTaskTemplateFieldsId | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateFieldsIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectTaskTemplateFieldsId | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateFieldsId | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectTaskTemplateFields {
    /**
    * The description of the task template's field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#description ConnectTaskTemplate#description}
    */
    readonly description?: string;
    /**
    * the identifier (name) for the task template field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#id ConnectTaskTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: ConnectTaskTemplateFieldsId;
    /**
    * list of field options to be used with single select
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#single_select_options ConnectTaskTemplate#single_select_options}
    */
    readonly singleSelectOptions?: string[];
    /**
    * The type of the task template's field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#type ConnectTaskTemplate#type}
    */
    readonly type?: string;
}
export declare function connectTaskTemplateFieldsToTerraform(struct?: ConnectTaskTemplateFields | cdktn.IResolvable): any;
export declare function connectTaskTemplateFieldsToHclTerraform(struct?: ConnectTaskTemplateFields | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectTaskTemplateFields | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateFields | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id;
    get id(): ConnectTaskTemplateFieldsIdOutputReference;
    putId(value: ConnectTaskTemplateFieldsId): void;
    resetId(): void;
    get idInput(): cdktn.IResolvable | ConnectTaskTemplateFieldsId | undefined;
    private _singleSelectOptions?;
    get singleSelectOptions(): string[];
    set singleSelectOptions(value: string[]);
    resetSingleSelectOptions(): void;
    get singleSelectOptionsInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ConnectTaskTemplateFieldsList extends cdktn.ComplexList {
    internalValue?: ConnectTaskTemplateFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectTaskTemplateFieldsOutputReference;
}
export interface ConnectTaskTemplateTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#key ConnectTaskTemplate#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. . You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#value ConnectTaskTemplate#value}
    */
    readonly value?: string;
}
export declare function connectTaskTemplateTagsToTerraform(struct?: ConnectTaskTemplateTags | cdktn.IResolvable): any;
export declare function connectTaskTemplateTagsToHclTerraform(struct?: ConnectTaskTemplateTags | cdktn.IResolvable): any;
export declare class ConnectTaskTemplateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectTaskTemplateTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTaskTemplateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectTaskTemplateTagsList extends cdktn.ComplexList {
    internalValue?: ConnectTaskTemplateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectTaskTemplateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template awscc_connect_task_template}
*/
export declare class ConnectTaskTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_task_template";
    /**
    * Generates CDKTN code for importing a ConnectTaskTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectTaskTemplate to import
    * @param importFromId The id of the existing ConnectTaskTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectTaskTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_task_template awscc_connect_task_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectTaskTemplateConfig
    */
    constructor(scope: Construct, id: string, config: ConnectTaskTemplateConfig);
    get arn(): string;
    private _clientToken?;
    get clientToken(): string;
    set clientToken(value: string);
    resetClientToken(): void;
    get clientTokenInput(): string | undefined;
    private _constraints;
    get constraints(): ConnectTaskTemplateConstraintsOutputReference;
    putConstraints(value: ConnectTaskTemplateConstraints): void;
    resetConstraints(): void;
    get constraintsInput(): cdktn.IResolvable | ConnectTaskTemplateConstraints | undefined;
    private _contactFlowArn?;
    get contactFlowArn(): string;
    set contactFlowArn(value: string);
    resetContactFlowArn(): void;
    get contactFlowArnInput(): string | undefined;
    private _defaults;
    get defaults(): ConnectTaskTemplateDefaultsList;
    putDefaults(value: ConnectTaskTemplateDefaults[] | cdktn.IResolvable): void;
    resetDefaults(): void;
    get defaultsInput(): cdktn.IResolvable | ConnectTaskTemplateDefaults[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _fields;
    get fields(): ConnectTaskTemplateFieldsList;
    putFields(value: ConnectTaskTemplateFields[] | cdktn.IResolvable): void;
    resetFields(): void;
    get fieldsInput(): cdktn.IResolvable | ConnectTaskTemplateFields[] | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _selfAssignContactFlowArn?;
    get selfAssignContactFlowArn(): string;
    set selfAssignContactFlowArn(value: string);
    resetSelfAssignContactFlowArn(): void;
    get selfAssignContactFlowArnInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags;
    get tags(): ConnectTaskTemplateTagsList;
    putTags(value: ConnectTaskTemplateTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectTaskTemplateTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
