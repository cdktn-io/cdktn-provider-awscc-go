/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigConfigurationAggregatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#account_aggregation_sources ConfigConfigurationAggregator#account_aggregation_sources}
    */
    readonly accountAggregationSources?: ConfigConfigurationAggregatorAccountAggregationSources[] | cdktn.IResolvable;
    /**
    * The name of the aggregator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#configuration_aggregator_name ConfigConfigurationAggregator#configuration_aggregator_name}
    */
    readonly configurationAggregatorName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#organization_aggregation_source ConfigConfigurationAggregator#organization_aggregation_source}
    */
    readonly organizationAggregationSource?: ConfigConfigurationAggregatorOrganizationAggregationSource;
    /**
    * The tags for the configuration aggregator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#tags ConfigConfigurationAggregator#tags}
    */
    readonly tags?: ConfigConfigurationAggregatorTags[] | cdktn.IResolvable;
}
export interface ConfigConfigurationAggregatorAccountAggregationSources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#account_ids ConfigConfigurationAggregator#account_ids}
    */
    readonly accountIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#all_aws_regions ConfigConfigurationAggregator#all_aws_regions}
    */
    readonly allAwsRegions?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#aws_regions ConfigConfigurationAggregator#aws_regions}
    */
    readonly awsRegions?: string[];
}
export declare function configConfigurationAggregatorAccountAggregationSourcesToTerraform(struct?: ConfigConfigurationAggregatorAccountAggregationSources | cdktn.IResolvable): any;
export declare function configConfigurationAggregatorAccountAggregationSourcesToHclTerraform(struct?: ConfigConfigurationAggregatorAccountAggregationSources | cdktn.IResolvable): any;
export declare class ConfigConfigurationAggregatorAccountAggregationSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigConfigurationAggregatorAccountAggregationSources | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigurationAggregatorAccountAggregationSources | cdktn.IResolvable | undefined);
    private _accountIds?;
    get accountIds(): string[];
    set accountIds(value: string[]);
    resetAccountIds(): void;
    get accountIdsInput(): string[] | undefined;
    private _allAwsRegions?;
    get allAwsRegions(): boolean | cdktn.IResolvable;
    set allAwsRegions(value: boolean | cdktn.IResolvable);
    resetAllAwsRegions(): void;
    get allAwsRegionsInput(): boolean | cdktn.IResolvable | undefined;
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
}
export declare class ConfigConfigurationAggregatorAccountAggregationSourcesList extends cdktn.ComplexList {
    internalValue?: ConfigConfigurationAggregatorAccountAggregationSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigConfigurationAggregatorAccountAggregationSourcesOutputReference;
}
export interface ConfigConfigurationAggregatorOrganizationAggregationSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#all_aws_regions ConfigConfigurationAggregator#all_aws_regions}
    */
    readonly allAwsRegions?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#aws_regions ConfigConfigurationAggregator#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#role_arn ConfigConfigurationAggregator#role_arn}
    */
    readonly roleArn?: string;
}
export declare function configConfigurationAggregatorOrganizationAggregationSourceToTerraform(struct?: ConfigConfigurationAggregatorOrganizationAggregationSource | cdktn.IResolvable): any;
export declare function configConfigurationAggregatorOrganizationAggregationSourceToHclTerraform(struct?: ConfigConfigurationAggregatorOrganizationAggregationSource | cdktn.IResolvable): any;
export declare class ConfigConfigurationAggregatorOrganizationAggregationSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConfigurationAggregatorOrganizationAggregationSource | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigurationAggregatorOrganizationAggregationSource | cdktn.IResolvable | undefined);
    private _allAwsRegions?;
    get allAwsRegions(): boolean | cdktn.IResolvable;
    set allAwsRegions(value: boolean | cdktn.IResolvable);
    resetAllAwsRegions(): void;
    get allAwsRegionsInput(): boolean | cdktn.IResolvable | undefined;
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
}
export interface ConfigConfigurationAggregatorTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#key ConfigConfigurationAggregator#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#value ConfigConfigurationAggregator#value}
    */
    readonly value?: string;
}
export declare function configConfigurationAggregatorTagsToTerraform(struct?: ConfigConfigurationAggregatorTags | cdktn.IResolvable): any;
export declare function configConfigurationAggregatorTagsToHclTerraform(struct?: ConfigConfigurationAggregatorTags | cdktn.IResolvable): any;
export declare class ConfigConfigurationAggregatorTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigConfigurationAggregatorTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConfigurationAggregatorTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConfigConfigurationAggregatorTagsList extends cdktn.ComplexList {
    internalValue?: ConfigConfigurationAggregatorTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigConfigurationAggregatorTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator awscc_config_configuration_aggregator}
*/
export declare class ConfigConfigurationAggregator extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_configuration_aggregator";
    /**
    * Generates CDKTN code for importing a ConfigConfigurationAggregator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigConfigurationAggregator to import
    * @param importFromId The id of the existing ConfigConfigurationAggregator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigConfigurationAggregator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_configuration_aggregator awscc_config_configuration_aggregator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigConfigurationAggregatorConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ConfigConfigurationAggregatorConfig);
    private _accountAggregationSources;
    get accountAggregationSources(): ConfigConfigurationAggregatorAccountAggregationSourcesList;
    putAccountAggregationSources(value: ConfigConfigurationAggregatorAccountAggregationSources[] | cdktn.IResolvable): void;
    resetAccountAggregationSources(): void;
    get accountAggregationSourcesInput(): cdktn.IResolvable | ConfigConfigurationAggregatorAccountAggregationSources[] | undefined;
    get configurationAggregatorArn(): string;
    private _configurationAggregatorName?;
    get configurationAggregatorName(): string;
    set configurationAggregatorName(value: string);
    resetConfigurationAggregatorName(): void;
    get configurationAggregatorNameInput(): string | undefined;
    get id(): string;
    private _organizationAggregationSource;
    get organizationAggregationSource(): ConfigConfigurationAggregatorOrganizationAggregationSourceOutputReference;
    putOrganizationAggregationSource(value: ConfigConfigurationAggregatorOrganizationAggregationSource): void;
    resetOrganizationAggregationSource(): void;
    get organizationAggregationSourceInput(): cdktn.IResolvable | ConfigConfigurationAggregatorOrganizationAggregationSource | undefined;
    private _tags;
    get tags(): ConfigConfigurationAggregatorTagsList;
    putTags(value: ConfigConfigurationAggregatorTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConfigConfigurationAggregatorTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
