/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CasesTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description explaining the purpose and use case for this template. Should indicate what types of cases this template is designed for and any specific workflow it supports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#description CasesTemplate#description}
    */
    readonly description?: string;
    /**
    * The unique identifier of the Cases domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#domain_id CasesTemplate#domain_id}
    */
    readonly domainId?: string;
    /**
    * Specifies the default layout to use when displaying cases created from this template. The layout determines which fields are visible and their arrangement in the agent interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#layout_configuration CasesTemplate#layout_configuration}
    */
    readonly layoutConfiguration?: CasesTemplateLayoutConfiguration;
    /**
    * A name for the template. It must be unique per domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#name CasesTemplate#name}
    */
    readonly name: string;
    /**
    * A list of fields that must contain a value for a case to be successfully created with this template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#required_fields CasesTemplate#required_fields}
    */
    readonly requiredFields?: CasesTemplateRequiredFields[] | cdktn.IResolvable;
    /**
    * A list of case rules (also known as case field conditions) on a template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#rules CasesTemplate#rules}
    */
    readonly rules?: CasesTemplateRules[] | cdktn.IResolvable;
    /**
    * The current status of the template. Active templates can be used to create new cases, while Inactive templates are disabled but preserved for existing cases.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#status CasesTemplate#status}
    */
    readonly status?: string;
    /**
    * The tags that you attach to this template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#tags CasesTemplate#tags}
    */
    readonly tags?: CasesTemplateTags[] | cdktn.IResolvable;
}
export interface CasesTemplateLayoutConfiguration {
    /**
    * The unique identifier of a layout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#default_layout CasesTemplate#default_layout}
    */
    readonly defaultLayout?: string;
}
export declare function casesTemplateLayoutConfigurationToTerraform(struct?: CasesTemplateLayoutConfiguration | cdktn.IResolvable): any;
export declare function casesTemplateLayoutConfigurationToHclTerraform(struct?: CasesTemplateLayoutConfiguration | cdktn.IResolvable): any;
export declare class CasesTemplateLayoutConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesTemplateLayoutConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CasesTemplateLayoutConfiguration | cdktn.IResolvable | undefined);
    private _defaultLayout?;
    get defaultLayout(): string;
    set defaultLayout(value: string);
    resetDefaultLayout(): void;
    get defaultLayoutInput(): string | undefined;
}
export interface CasesTemplateRequiredFields {
    /**
    * The unique identifier of a field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#field_id CasesTemplate#field_id}
    */
    readonly fieldId?: string;
}
export declare function casesTemplateRequiredFieldsToTerraform(struct?: CasesTemplateRequiredFields | cdktn.IResolvable): any;
export declare function casesTemplateRequiredFieldsToHclTerraform(struct?: CasesTemplateRequiredFields | cdktn.IResolvable): any;
export declare class CasesTemplateRequiredFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesTemplateRequiredFields | cdktn.IResolvable | undefined;
    set internalValue(value: CasesTemplateRequiredFields | cdktn.IResolvable | undefined);
    private _fieldId?;
    get fieldId(): string;
    set fieldId(value: string);
    resetFieldId(): void;
    get fieldIdInput(): string | undefined;
}
export declare class CasesTemplateRequiredFieldsList extends cdktn.ComplexList {
    internalValue?: CasesTemplateRequiredFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesTemplateRequiredFieldsOutputReference;
}
export interface CasesTemplateRules {
    /**
    * The unique identifier of a case rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#case_rule_id CasesTemplate#case_rule_id}
    */
    readonly caseRuleId?: string;
    /**
    * The ID of the field that this rule applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#field_id CasesTemplate#field_id}
    */
    readonly fieldId?: string;
}
export declare function casesTemplateRulesToTerraform(struct?: CasesTemplateRules | cdktn.IResolvable): any;
export declare function casesTemplateRulesToHclTerraform(struct?: CasesTemplateRules | cdktn.IResolvable): any;
export declare class CasesTemplateRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesTemplateRules | cdktn.IResolvable | undefined;
    set internalValue(value: CasesTemplateRules | cdktn.IResolvable | undefined);
    private _caseRuleId?;
    get caseRuleId(): string;
    set caseRuleId(value: string);
    resetCaseRuleId(): void;
    get caseRuleIdInput(): string | undefined;
    private _fieldId?;
    get fieldId(): string;
    set fieldId(value: string);
    resetFieldId(): void;
    get fieldIdInput(): string | undefined;
}
export declare class CasesTemplateRulesList extends cdktn.ComplexList {
    internalValue?: CasesTemplateRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesTemplateRulesOutputReference;
}
export interface CasesTemplateTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#key CasesTemplate#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#value CasesTemplate#value}
    */
    readonly value?: string;
}
export declare function casesTemplateTagsToTerraform(struct?: CasesTemplateTags | cdktn.IResolvable): any;
export declare function casesTemplateTagsToHclTerraform(struct?: CasesTemplateTags | cdktn.IResolvable): any;
export declare class CasesTemplateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesTemplateTags | cdktn.IResolvable | undefined;
    set internalValue(value: CasesTemplateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CasesTemplateTagsList extends cdktn.ComplexList {
    internalValue?: CasesTemplateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesTemplateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template awscc_cases_template}
*/
export declare class CasesTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cases_template";
    /**
    * Generates CDKTN code for importing a CasesTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CasesTemplate to import
    * @param importFromId The id of the existing CasesTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CasesTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_template awscc_cases_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CasesTemplateConfig
    */
    constructor(scope: Construct, id: string, config: CasesTemplateConfig);
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    resetDomainId(): void;
    get domainIdInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): string;
    private _layoutConfiguration;
    get layoutConfiguration(): CasesTemplateLayoutConfigurationOutputReference;
    putLayoutConfiguration(value: CasesTemplateLayoutConfiguration): void;
    resetLayoutConfiguration(): void;
    get layoutConfigurationInput(): cdktn.IResolvable | CasesTemplateLayoutConfiguration | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _requiredFields;
    get requiredFields(): CasesTemplateRequiredFieldsList;
    putRequiredFields(value: CasesTemplateRequiredFields[] | cdktn.IResolvable): void;
    resetRequiredFields(): void;
    get requiredFieldsInput(): cdktn.IResolvable | CasesTemplateRequiredFields[] | undefined;
    private _rules;
    get rules(): CasesTemplateRulesList;
    putRules(value: CasesTemplateRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | CasesTemplateRules[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags;
    get tags(): CasesTemplateTagsList;
    putTags(value: CasesTemplateTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CasesTemplateTags[] | undefined;
    get templateArn(): string;
    get templateId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
