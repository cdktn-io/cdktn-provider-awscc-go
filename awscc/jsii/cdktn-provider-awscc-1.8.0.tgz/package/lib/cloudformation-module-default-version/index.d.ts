/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationModuleDefaultVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the module version to set as the default version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_module_default_version#arn CloudformationModuleDefaultVersion#arn}
    */
    readonly arn?: string;
    /**
    * The name of a module existing in the registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_module_default_version#module_name CloudformationModuleDefaultVersion#module_name}
    */
    readonly moduleName?: string;
    /**
    * The ID of an existing version of the named module to set as the default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_module_default_version#version_id CloudformationModuleDefaultVersion#version_id}
    */
    readonly versionId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_module_default_version awscc_cloudformation_module_default_version}
*/
export declare class CloudformationModuleDefaultVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_module_default_version";
    /**
    * Generates CDKTN code for importing a CloudformationModuleDefaultVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationModuleDefaultVersion to import
    * @param importFromId The id of the existing CloudformationModuleDefaultVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_module_default_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationModuleDefaultVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_module_default_version awscc_cloudformation_module_default_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationModuleDefaultVersionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudformationModuleDefaultVersionConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get id(): string;
    private _moduleName?;
    get moduleName(): string;
    set moduleName(value: string);
    resetModuleName(): void;
    get moduleNameInput(): string | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
