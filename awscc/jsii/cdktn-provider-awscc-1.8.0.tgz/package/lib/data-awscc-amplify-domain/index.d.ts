/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAmplifyDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/amplify_domain#id DataAwsccAmplifyDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAmplifyDomainCertificate {
}
export declare function dataAwsccAmplifyDomainCertificateToTerraform(struct?: DataAwsccAmplifyDomainCertificate): any;
export declare function dataAwsccAmplifyDomainCertificateToHclTerraform(struct?: DataAwsccAmplifyDomainCertificate): any;
export declare class DataAwsccAmplifyDomainCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyDomainCertificate | undefined;
    set internalValue(value: DataAwsccAmplifyDomainCertificate | undefined);
    get certificateArn(): string;
    get certificateType(): string;
    get certificateVerificationDnsRecord(): string;
}
export interface DataAwsccAmplifyDomainCertificateSettings {
}
export declare function dataAwsccAmplifyDomainCertificateSettingsToTerraform(struct?: DataAwsccAmplifyDomainCertificateSettings): any;
export declare function dataAwsccAmplifyDomainCertificateSettingsToHclTerraform(struct?: DataAwsccAmplifyDomainCertificateSettings): any;
export declare class DataAwsccAmplifyDomainCertificateSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyDomainCertificateSettings | undefined;
    set internalValue(value: DataAwsccAmplifyDomainCertificateSettings | undefined);
    get certificateType(): string;
    get customCertificateArn(): string;
}
export interface DataAwsccAmplifyDomainSubDomainSettings {
}
export declare function dataAwsccAmplifyDomainSubDomainSettingsToTerraform(struct?: DataAwsccAmplifyDomainSubDomainSettings): any;
export declare function dataAwsccAmplifyDomainSubDomainSettingsToHclTerraform(struct?: DataAwsccAmplifyDomainSubDomainSettings): any;
export declare class DataAwsccAmplifyDomainSubDomainSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAmplifyDomainSubDomainSettings | undefined;
    set internalValue(value: DataAwsccAmplifyDomainSubDomainSettings | undefined);
    get branchName(): string;
    get prefix(): string;
}
export declare class DataAwsccAmplifyDomainSubDomainSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAmplifyDomainSubDomainSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/amplify_domain awscc_amplify_domain}
*/
export declare class DataAwsccAmplifyDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_amplify_domain";
    /**
    * Generates CDKTN code for importing a DataAwsccAmplifyDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAmplifyDomain to import
    * @param importFromId The id of the existing DataAwsccAmplifyDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/amplify_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAmplifyDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/amplify_domain awscc_amplify_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAmplifyDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAmplifyDomainConfig);
    get appId(): string;
    get arn(): string;
    get autoSubDomainCreationPatterns(): string[];
    get autoSubDomainIamRole(): string;
    private _certificate;
    get certificate(): DataAwsccAmplifyDomainCertificateOutputReference;
    get certificateRecord(): string;
    private _certificateSettings;
    get certificateSettings(): DataAwsccAmplifyDomainCertificateSettingsOutputReference;
    get domainName(): string;
    get domainStatus(): string;
    get enableAutoSubDomain(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get statusReason(): string;
    private _subDomainSettings;
    get subDomainSettings(): DataAwsccAmplifyDomainSubDomainSettingsList;
    get updateStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
