/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontFieldLevelEncryptionProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * The configuration of a field-level encryption profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#field_level_encryption_profile_config CloudfrontFieldLevelEncryptionProfile#field_level_encryption_profile_config}
    */
    readonly fieldLevelEncryptionProfileConfig: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfig;
}
export interface CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities {
    /**
    * The request-body field names to encrypt. A pattern is either a full field name or leading characters followed by a wildcard (*). Patterns are case-sensitive and must not overlap.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#field_patterns CloudfrontFieldLevelEncryptionProfile#field_patterns}
    */
    readonly fieldPatterns: string[];
    /**
    * The provider associated with the public key. The same value must be supplied with the private key for an application to decrypt the data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#provider_id CloudfrontFieldLevelEncryptionProfile#provider_id}
    */
    readonly providerId: string;
    /**
    * The identifier of the CloudFront public key used to encrypt the fields that match the patterns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#public_key_id CloudfrontFieldLevelEncryptionProfile#public_key_id}
    */
    readonly publicKeyId: string;
}
export declare function cloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntitiesToTerraform(struct?: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities | cdktn.IResolvable): any;
export declare function cloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntitiesToHclTerraform(struct?: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities | cdktn.IResolvable): any;
export declare class CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities | cdktn.IResolvable | undefined);
    private _fieldPatterns?;
    get fieldPatterns(): string[];
    set fieldPatterns(value: string[]);
    get fieldPatternsInput(): string[] | undefined;
    private _providerId?;
    get providerId(): string;
    set providerId(value: string);
    get providerIdInput(): string | undefined;
    private _publicKeyId?;
    get publicKeyId(): string;
    set publicKeyId(value: string);
    get publicKeyIdInput(): string | undefined;
}
export declare class CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntitiesList extends cdktn.ComplexList {
    internalValue?: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntitiesOutputReference;
}
export interface CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfig {
    /**
    * A unique value that identifies the creation request. Caller references are unique within an AWS account and cannot be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#caller_reference CloudfrontFieldLevelEncryptionProfile#caller_reference}
    */
    readonly callerReference: string;
    /**
    * An optional comment describing the field-level encryption profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#comment CloudfrontFieldLevelEncryptionProfile#comment}
    */
    readonly comment?: string;
    /**
    * The encryption entities of the field-level encryption profile. At least one entity is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#encryption_entities CloudfrontFieldLevelEncryptionProfile#encryption_entities}
    */
    readonly encryptionEntities: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities[] | cdktn.IResolvable;
    /**
    * The name of the field-level encryption profile. Names are unique within an AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#name CloudfrontFieldLevelEncryptionProfile#name}
    */
    readonly name: string;
}
export declare function cloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigToTerraform(struct?: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfig | cdktn.IResolvable): any;
export declare function cloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigToHclTerraform(struct?: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfig | cdktn.IResolvable): any;
export declare class CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfig | cdktn.IResolvable | undefined);
    private _callerReference?;
    get callerReference(): string;
    set callerReference(value: string);
    get callerReferenceInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _encryptionEntities;
    get encryptionEntities(): CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntitiesList;
    putEncryptionEntities(value: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities[] | cdktn.IResolvable): void;
    get encryptionEntitiesInput(): cdktn.IResolvable | CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigEncryptionEntities[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile awscc_cloudfront_field_level_encryption_profile}
*/
export declare class CloudfrontFieldLevelEncryptionProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_field_level_encryption_profile";
    /**
    * Generates CDKTN code for importing a CloudfrontFieldLevelEncryptionProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontFieldLevelEncryptionProfile to import
    * @param importFromId The id of the existing CloudfrontFieldLevelEncryptionProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontFieldLevelEncryptionProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_field_level_encryption_profile awscc_cloudfront_field_level_encryption_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontFieldLevelEncryptionProfileConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontFieldLevelEncryptionProfileConfig);
    get arn(): string;
    private _fieldLevelEncryptionProfileConfig;
    get fieldLevelEncryptionProfileConfig(): CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfigOutputReference;
    putFieldLevelEncryptionProfileConfig(value: CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfig): void;
    get fieldLevelEncryptionProfileConfigInput(): cdktn.IResolvable | CloudfrontFieldLevelEncryptionProfileFieldLevelEncryptionProfileConfig | undefined;
    get fieldLevelEncryptionProfileId(): string;
    get id(): string;
    get lastModifiedTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
