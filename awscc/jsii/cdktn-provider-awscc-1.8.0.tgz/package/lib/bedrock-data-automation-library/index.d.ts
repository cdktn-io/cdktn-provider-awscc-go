/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockDataAutomationLibraryConfig extends cdktn.TerraformMetaArguments {
    /**
    * KMS Encryption Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#encryption_configuration BedrockDataAutomationLibrary#encryption_configuration}
    */
    readonly encryptionConfiguration?: BedrockDataAutomationLibraryEncryptionConfiguration;
    /**
    * Description of the DataAutomationLibrary
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#library_description BedrockDataAutomationLibrary#library_description}
    */
    readonly libraryDescription?: string;
    /**
    * Name of the DataAutomationLibrary
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#library_name BedrockDataAutomationLibrary#library_name}
    */
    readonly libraryName: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#tags BedrockDataAutomationLibrary#tags}
    */
    readonly tags?: BedrockDataAutomationLibraryTags[] | cdktn.IResolvable;
}
export interface BedrockDataAutomationLibraryEncryptionConfiguration {
    /**
    * KMS Encryption Context
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#kms_encryption_context BedrockDataAutomationLibrary#kms_encryption_context}
    */
    readonly kmsEncryptionContext?: {
        [key: string]: string;
    };
    /**
    * KMS Key Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#kms_key_id BedrockDataAutomationLibrary#kms_key_id}
    */
    readonly kmsKeyId?: string;
}
export declare function bedrockDataAutomationLibraryEncryptionConfigurationToTerraform(struct?: BedrockDataAutomationLibraryEncryptionConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationLibraryEncryptionConfigurationToHclTerraform(struct?: BedrockDataAutomationLibraryEncryptionConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationLibraryEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationLibraryEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationLibraryEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsEncryptionContext?;
    get kmsEncryptionContext(): {
        [key: string]: string;
    };
    set kmsEncryptionContext(value: {
        [key: string]: string;
    });
    resetKmsEncryptionContext(): void;
    get kmsEncryptionContextInput(): {
        [key: string]: string;
    } | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
}
export interface BedrockDataAutomationLibraryEntityTypes {
}
export declare function bedrockDataAutomationLibraryEntityTypesToTerraform(struct?: BedrockDataAutomationLibraryEntityTypes): any;
export declare function bedrockDataAutomationLibraryEntityTypesToHclTerraform(struct?: BedrockDataAutomationLibraryEntityTypes): any;
export declare class BedrockDataAutomationLibraryEntityTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataAutomationLibraryEntityTypes | undefined;
    set internalValue(value: BedrockDataAutomationLibraryEntityTypes | undefined);
    get entityMetadata(): string;
    get entityType(): string;
}
export declare class BedrockDataAutomationLibraryEntityTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataAutomationLibraryEntityTypesOutputReference;
}
export interface BedrockDataAutomationLibraryTags {
    /**
    * Tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#key BedrockDataAutomationLibrary#key}
    */
    readonly key?: string;
    /**
    * Tag value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#value BedrockDataAutomationLibrary#value}
    */
    readonly value?: string;
}
export declare function bedrockDataAutomationLibraryTagsToTerraform(struct?: BedrockDataAutomationLibraryTags | cdktn.IResolvable): any;
export declare function bedrockDataAutomationLibraryTagsToHclTerraform(struct?: BedrockDataAutomationLibraryTags | cdktn.IResolvable): any;
export declare class BedrockDataAutomationLibraryTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataAutomationLibraryTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationLibraryTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockDataAutomationLibraryTagsList extends cdktn.ComplexList {
    internalValue?: BedrockDataAutomationLibraryTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataAutomationLibraryTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library awscc_bedrock_data_automation_library}
*/
export declare class BedrockDataAutomationLibrary extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_data_automation_library";
    /**
    * Generates CDKTN code for importing a BedrockDataAutomationLibrary resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockDataAutomationLibrary to import
    * @param importFromId The id of the existing BedrockDataAutomationLibrary that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockDataAutomationLibrary to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_data_automation_library awscc_bedrock_data_automation_library} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockDataAutomationLibraryConfig
    */
    constructor(scope: Construct, id: string, config: BedrockDataAutomationLibraryConfig);
    get creationTime(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): BedrockDataAutomationLibraryEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: BedrockDataAutomationLibraryEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationLibraryEncryptionConfiguration | undefined;
    private _entityTypes;
    get entityTypes(): BedrockDataAutomationLibraryEntityTypesList;
    get id(): string;
    get libraryArn(): string;
    private _libraryDescription?;
    get libraryDescription(): string;
    set libraryDescription(value: string);
    resetLibraryDescription(): void;
    get libraryDescriptionInput(): string | undefined;
    private _libraryName?;
    get libraryName(): string;
    set libraryName(value: string);
    get libraryNameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): BedrockDataAutomationLibraryTagsList;
    putTags(value: BedrockDataAutomationLibraryTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockDataAutomationLibraryTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
