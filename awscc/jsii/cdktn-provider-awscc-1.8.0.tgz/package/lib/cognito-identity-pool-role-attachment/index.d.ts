/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoIdentityPoolRoleAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#identity_pool_id CognitoIdentityPoolRoleAttachment#identity_pool_id}
    */
    readonly identityPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#role_mappings CognitoIdentityPoolRoleAttachment#role_mappings}
    */
    readonly roleMappings?: {
        [key: string]: CognitoIdentityPoolRoleAttachmentRoleMappings;
    } | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#roles CognitoIdentityPoolRoleAttachment#roles}
    */
    readonly roles?: {
        [key: string]: string;
    };
}
export interface CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#claim CognitoIdentityPoolRoleAttachment#claim}
    */
    readonly claim?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#match_type CognitoIdentityPoolRoleAttachment#match_type}
    */
    readonly matchType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#role_arn CognitoIdentityPoolRoleAttachment#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#value CognitoIdentityPoolRoleAttachment#value}
    */
    readonly value?: string;
}
export declare function cognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRulesToTerraform(struct?: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules | cdktn.IResolvable): any;
export declare function cognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRulesToHclTerraform(struct?: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules | cdktn.IResolvable): any;
export declare class CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules | cdktn.IResolvable | undefined);
    private _claim?;
    get claim(): string;
    set claim(value: string);
    resetClaim(): void;
    get claimInput(): string | undefined;
    private _matchType?;
    get matchType(): string;
    set matchType(value: string);
    resetMatchType(): void;
    get matchTypeInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRulesList extends cdktn.ComplexList {
    internalValue?: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRulesOutputReference;
}
export interface CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#rules CognitoIdentityPoolRoleAttachment#rules}
    */
    readonly rules?: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules[] | cdktn.IResolvable;
}
export declare function cognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationToTerraform(struct?: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfiguration | cdktn.IResolvable): any;
export declare function cognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationToHclTerraform(struct?: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfiguration | cdktn.IResolvable): any;
export declare class CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfiguration | cdktn.IResolvable | undefined);
    private _rules;
    get rules(): CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRulesList;
    putRules(value: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationRules[] | undefined;
}
export interface CognitoIdentityPoolRoleAttachmentRoleMappings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#ambiguous_role_resolution CognitoIdentityPoolRoleAttachment#ambiguous_role_resolution}
    */
    readonly ambiguousRoleResolution?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#identity_provider CognitoIdentityPoolRoleAttachment#identity_provider}
    */
    readonly identityProvider?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#rules_configuration CognitoIdentityPoolRoleAttachment#rules_configuration}
    */
    readonly rulesConfiguration?: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#type CognitoIdentityPoolRoleAttachment#type}
    */
    readonly type?: string;
}
export declare function cognitoIdentityPoolRoleAttachmentRoleMappingsToTerraform(struct?: CognitoIdentityPoolRoleAttachmentRoleMappings | cdktn.IResolvable): any;
export declare function cognitoIdentityPoolRoleAttachmentRoleMappingsToHclTerraform(struct?: CognitoIdentityPoolRoleAttachmentRoleMappings | cdktn.IResolvable): any;
export declare class CognitoIdentityPoolRoleAttachmentRoleMappingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): CognitoIdentityPoolRoleAttachmentRoleMappings | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoIdentityPoolRoleAttachmentRoleMappings | cdktn.IResolvable | undefined);
    private _ambiguousRoleResolution?;
    get ambiguousRoleResolution(): string;
    set ambiguousRoleResolution(value: string);
    resetAmbiguousRoleResolution(): void;
    get ambiguousRoleResolutionInput(): string | undefined;
    private _identityProvider?;
    get identityProvider(): string;
    set identityProvider(value: string);
    resetIdentityProvider(): void;
    get identityProviderInput(): string | undefined;
    private _rulesConfiguration;
    get rulesConfiguration(): CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfigurationOutputReference;
    putRulesConfiguration(value: CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfiguration): void;
    resetRulesConfiguration(): void;
    get rulesConfigurationInput(): cdktn.IResolvable | CognitoIdentityPoolRoleAttachmentRoleMappingsRulesConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CognitoIdentityPoolRoleAttachmentRoleMappingsMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: CognitoIdentityPoolRoleAttachmentRoleMappings;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): CognitoIdentityPoolRoleAttachmentRoleMappingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment awscc_cognito_identity_pool_role_attachment}
*/
export declare class CognitoIdentityPoolRoleAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_identity_pool_role_attachment";
    /**
    * Generates CDKTN code for importing a CognitoIdentityPoolRoleAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoIdentityPoolRoleAttachment to import
    * @param importFromId The id of the existing CognitoIdentityPoolRoleAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoIdentityPoolRoleAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cognito_identity_pool_role_attachment awscc_cognito_identity_pool_role_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoIdentityPoolRoleAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: CognitoIdentityPoolRoleAttachmentConfig);
    get id(): string;
    private _identityPoolId?;
    get identityPoolId(): string;
    set identityPoolId(value: string);
    get identityPoolIdInput(): string | undefined;
    get identityPoolRoleAttachmentId(): string;
    private _roleMappings;
    get roleMappings(): CognitoIdentityPoolRoleAttachmentRoleMappingsMap;
    putRoleMappings(value: {
        [key: string]: CognitoIdentityPoolRoleAttachmentRoleMappings;
    } | cdktn.IResolvable): void;
    resetRoleMappings(): void;
    get roleMappingsInput(): cdktn.IResolvable | {
        [key: string]: CognitoIdentityPoolRoleAttachmentRoleMappings;
    } | undefined;
    private _roles?;
    get roles(): {
        [key: string]: string;
    };
    set roles(value: {
        [key: string]: string;
    });
    resetRoles(): void;
    get rolesInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
