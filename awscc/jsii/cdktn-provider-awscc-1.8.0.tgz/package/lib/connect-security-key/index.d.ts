/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectSecurityKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Amazon Connect instance identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_security_key#instance_id ConnectSecurityKey#instance_id}
    */
    readonly instanceId: string;
    /**
    * A valid security key in PEM format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_security_key#key ConnectSecurityKey#key}
    */
    readonly key: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_security_key awscc_connect_security_key}
*/
export declare class ConnectSecurityKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_security_key";
    /**
    * Generates CDKTN code for importing a ConnectSecurityKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectSecurityKey to import
    * @param importFromId The id of the existing ConnectSecurityKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_security_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectSecurityKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_security_key awscc_connect_security_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectSecurityKeyConfig
    */
    constructor(scope: Construct, id: string, config: ConnectSecurityKeyConfig);
    get associationId(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
