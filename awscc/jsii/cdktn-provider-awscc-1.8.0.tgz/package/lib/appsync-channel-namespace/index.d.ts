/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncChannelNamespaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * AppSync Api Id that this Channel Namespace belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#api_id AppsyncChannelNamespace#api_id}
    */
    readonly apiId: string;
    /**
    * String of APPSYNC_JS code to be used by the handlers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#code_handlers AppsyncChannelNamespace#code_handlers}
    */
    readonly codeHandlers?: string;
    /**
    * The Amazon S3 endpoint where the code is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#code_s3_location AppsyncChannelNamespace#code_s3_location}
    */
    readonly codeS3Location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#handler_configs AppsyncChannelNamespace#handler_configs}
    */
    readonly handlerConfigs?: AppsyncChannelNamespaceHandlerConfigs;
    /**
    * Namespace indentifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#name AppsyncChannelNamespace#name}
    */
    readonly name: string;
    /**
    * List of AuthModes supported for Publish operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#publish_auth_modes AppsyncChannelNamespace#publish_auth_modes}
    */
    readonly publishAuthModes?: AppsyncChannelNamespacePublishAuthModes[] | cdktn.IResolvable;
    /**
    * List of AuthModes supported for Subscribe operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#subscribe_auth_modes AppsyncChannelNamespace#subscribe_auth_modes}
    */
    readonly subscribeAuthModes?: AppsyncChannelNamespaceSubscribeAuthModes[] | cdktn.IResolvable;
    /**
    * An arbitrary set of tags (key-value pairs) for this AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#tags AppsyncChannelNamespace#tags}
    */
    readonly tags?: AppsyncChannelNamespaceTags[] | cdktn.IResolvable;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig {
    /**
    * Invocation type for direct lambda integrations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#invoke_type AppsyncChannelNamespace#invoke_type}
    */
    readonly invokeType?: string;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | cdktn.IResolvable | undefined);
    private _invokeType?;
    get invokeType(): string;
    set invokeType(value: string);
    resetInvokeType(): void;
    get invokeTypeInput(): string | undefined;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration {
    /**
    * Data source to invoke for this integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#data_source_name AppsyncChannelNamespace#data_source_name}
    */
    readonly dataSourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#lambda_config AppsyncChannelNamespace#lambda_config}
    */
    readonly lambdaConfig?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishIntegrationToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishIntegrationToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | cdktn.IResolvable | undefined);
    private _dataSourceName?;
    get dataSourceName(): string;
    set dataSourceName(value: string);
    resetDataSourceName(): void;
    get dataSourceNameInput(): string | undefined;
    private _lambdaConfig;
    get lambdaConfig(): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigOutputReference;
    putLambdaConfig(value: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | undefined;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnPublish {
    /**
    * Integration behavior for a handler configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#behavior AppsyncChannelNamespace#behavior}
    */
    readonly behavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#integration AppsyncChannelNamespace#integration}
    */
    readonly integration?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublish | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublish | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnPublish | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnPublish | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    resetBehavior(): void;
    get behaviorInput(): string | undefined;
    private _integration;
    get integration(): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationOutputReference;
    putIntegration(value: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration): void;
    resetIntegration(): void;
    get integrationInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | undefined;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig {
    /**
    * Invocation type for direct lambda integrations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#invoke_type AppsyncChannelNamespace#invoke_type}
    */
    readonly invokeType?: string;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | cdktn.IResolvable | undefined);
    private _invokeType?;
    get invokeType(): string;
    set invokeType(value: string);
    resetInvokeType(): void;
    get invokeTypeInput(): string | undefined;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration {
    /**
    * Data source to invoke for this integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#data_source_name AppsyncChannelNamespace#data_source_name}
    */
    readonly dataSourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#lambda_config AppsyncChannelNamespace#lambda_config}
    */
    readonly lambdaConfig?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | cdktn.IResolvable | undefined);
    private _dataSourceName?;
    get dataSourceName(): string;
    set dataSourceName(value: string);
    resetDataSourceName(): void;
    get dataSourceNameInput(): string | undefined;
    private _lambdaConfig;
    get lambdaConfig(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigOutputReference;
    putLambdaConfig(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | undefined;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnSubscribe {
    /**
    * Integration behavior for a handler configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#behavior AppsyncChannelNamespace#behavior}
    */
    readonly behavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#integration AppsyncChannelNamespace#integration}
    */
    readonly integration?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribe | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribe | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnSubscribe | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribe | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    resetBehavior(): void;
    get behaviorInput(): string | undefined;
    private _integration;
    get integration(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationOutputReference;
    putIntegration(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration): void;
    resetIntegration(): void;
    get integrationInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | undefined;
}
export interface AppsyncChannelNamespaceHandlerConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#on_publish AppsyncChannelNamespace#on_publish}
    */
    readonly onPublish?: AppsyncChannelNamespaceHandlerConfigsOnPublish;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#on_subscribe AppsyncChannelNamespace#on_subscribe}
    */
    readonly onSubscribe?: AppsyncChannelNamespaceHandlerConfigsOnSubscribe;
}
export declare function appsyncChannelNamespaceHandlerConfigsToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigs | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigs | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigs | cdktn.IResolvable | undefined);
    private _onPublish;
    get onPublish(): AppsyncChannelNamespaceHandlerConfigsOnPublishOutputReference;
    putOnPublish(value: AppsyncChannelNamespaceHandlerConfigsOnPublish): void;
    resetOnPublish(): void;
    get onPublishInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnPublish | undefined;
    private _onSubscribe;
    get onSubscribe(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeOutputReference;
    putOnSubscribe(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribe): void;
    resetOnSubscribe(): void;
    get onSubscribeInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnSubscribe | undefined;
}
export interface AppsyncChannelNamespacePublishAuthModes {
    /**
    * Security configuration for your AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#auth_type AppsyncChannelNamespace#auth_type}
    */
    readonly authType?: string;
}
export declare function appsyncChannelNamespacePublishAuthModesToTerraform(struct?: AppsyncChannelNamespacePublishAuthModes | cdktn.IResolvable): any;
export declare function appsyncChannelNamespacePublishAuthModesToHclTerraform(struct?: AppsyncChannelNamespacePublishAuthModes | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespacePublishAuthModesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespacePublishAuthModes | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespacePublishAuthModes | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
}
export declare class AppsyncChannelNamespacePublishAuthModesList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespacePublishAuthModes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespacePublishAuthModesOutputReference;
}
export interface AppsyncChannelNamespaceSubscribeAuthModes {
    /**
    * Security configuration for your AppSync API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#auth_type AppsyncChannelNamespace#auth_type}
    */
    readonly authType?: string;
}
export declare function appsyncChannelNamespaceSubscribeAuthModesToTerraform(struct?: AppsyncChannelNamespaceSubscribeAuthModes | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceSubscribeAuthModesToHclTerraform(struct?: AppsyncChannelNamespaceSubscribeAuthModes | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceSubscribeAuthModesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceSubscribeAuthModes | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceSubscribeAuthModes | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
}
export declare class AppsyncChannelNamespaceSubscribeAuthModesList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceSubscribeAuthModes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceSubscribeAuthModesOutputReference;
}
export interface AppsyncChannelNamespaceTags {
    /**
    * A string used to identify this tag. You can specify a maximum of 128 characters for a tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#key AppsyncChannelNamespace#key}
    */
    readonly key?: string;
    /**
    * A string containing the value for this tag. You can specify a maximum of 256 characters for a tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#value AppsyncChannelNamespace#value}
    */
    readonly value?: string;
}
export declare function appsyncChannelNamespaceTagsToTerraform(struct?: AppsyncChannelNamespaceTags | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceTagsToHclTerraform(struct?: AppsyncChannelNamespaceTags | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppsyncChannelNamespaceTagsList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace awscc_appsync_channel_namespace}
*/
export declare class AppsyncChannelNamespace extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_channel_namespace";
    /**
    * Generates CDKTN code for importing a AppsyncChannelNamespace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncChannelNamespace to import
    * @param importFromId The id of the existing AppsyncChannelNamespace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncChannelNamespace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_channel_namespace awscc_appsync_channel_namespace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncChannelNamespaceConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncChannelNamespaceConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get channelNamespaceArn(): string;
    private _codeHandlers?;
    get codeHandlers(): string;
    set codeHandlers(value: string);
    resetCodeHandlers(): void;
    get codeHandlersInput(): string | undefined;
    private _codeS3Location?;
    get codeS3Location(): string;
    set codeS3Location(value: string);
    resetCodeS3Location(): void;
    get codeS3LocationInput(): string | undefined;
    private _handlerConfigs;
    get handlerConfigs(): AppsyncChannelNamespaceHandlerConfigsOutputReference;
    putHandlerConfigs(value: AppsyncChannelNamespaceHandlerConfigs): void;
    resetHandlerConfigs(): void;
    get handlerConfigsInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigs | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publishAuthModes;
    get publishAuthModes(): AppsyncChannelNamespacePublishAuthModesList;
    putPublishAuthModes(value: AppsyncChannelNamespacePublishAuthModes[] | cdktn.IResolvable): void;
    resetPublishAuthModes(): void;
    get publishAuthModesInput(): cdktn.IResolvable | AppsyncChannelNamespacePublishAuthModes[] | undefined;
    private _subscribeAuthModes;
    get subscribeAuthModes(): AppsyncChannelNamespaceSubscribeAuthModesList;
    putSubscribeAuthModes(value: AppsyncChannelNamespaceSubscribeAuthModes[] | cdktn.IResolvable): void;
    resetSubscribeAuthModes(): void;
    get subscribeAuthModesInput(): cdktn.IResolvable | AppsyncChannelNamespaceSubscribeAuthModes[] | undefined;
    private _tags;
    get tags(): AppsyncChannelNamespaceTagsList;
    putTags(value: AppsyncChannelNamespaceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppsyncChannelNamespaceTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
