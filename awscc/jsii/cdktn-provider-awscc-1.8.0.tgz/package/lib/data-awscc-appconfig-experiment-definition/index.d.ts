/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAppconfigExperimentDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_experiment_definition#id DataAwsccAppconfigExperimentDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAppconfigExperimentDefinitionControlAttributeValues {
}
export declare function dataAwsccAppconfigExperimentDefinitionControlAttributeValuesToTerraform(struct?: DataAwsccAppconfigExperimentDefinitionControlAttributeValues): any;
export declare function dataAwsccAppconfigExperimentDefinitionControlAttributeValuesToHclTerraform(struct?: DataAwsccAppconfigExperimentDefinitionControlAttributeValues): any;
export declare class DataAwsccAppconfigExperimentDefinitionControlAttributeValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataAwsccAppconfigExperimentDefinitionControlAttributeValues | undefined;
    set internalValue(value: DataAwsccAppconfigExperimentDefinitionControlAttributeValues | undefined);
    get booleanValue(): cdktn.IResolvable;
    get numberArray(): number[];
    get numberValue(): number;
    get stringArray(): string[];
    get stringValue(): string;
}
export declare class DataAwsccAppconfigExperimentDefinitionControlAttributeValuesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataAwsccAppconfigExperimentDefinitionControlAttributeValuesOutputReference;
}
export interface DataAwsccAppconfigExperimentDefinitionControl {
}
export declare function dataAwsccAppconfigExperimentDefinitionControlToTerraform(struct?: DataAwsccAppconfigExperimentDefinitionControl): any;
export declare function dataAwsccAppconfigExperimentDefinitionControlToHclTerraform(struct?: DataAwsccAppconfigExperimentDefinitionControl): any;
export declare class DataAwsccAppconfigExperimentDefinitionControlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAppconfigExperimentDefinitionControl | undefined;
    set internalValue(value: DataAwsccAppconfigExperimentDefinitionControl | undefined);
    private _attributeValues;
    get attributeValues(): DataAwsccAppconfigExperimentDefinitionControlAttributeValuesMap;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get key(): string;
    get weight(): number;
}
export interface DataAwsccAppconfigExperimentDefinitionTags {
}
export declare function dataAwsccAppconfigExperimentDefinitionTagsToTerraform(struct?: DataAwsccAppconfigExperimentDefinitionTags): any;
export declare function dataAwsccAppconfigExperimentDefinitionTagsToHclTerraform(struct?: DataAwsccAppconfigExperimentDefinitionTags): any;
export declare class DataAwsccAppconfigExperimentDefinitionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigExperimentDefinitionTags | undefined;
    set internalValue(value: DataAwsccAppconfigExperimentDefinitionTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAppconfigExperimentDefinitionTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigExperimentDefinitionTagsOutputReference;
}
export interface DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValues {
}
export declare function dataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValuesToTerraform(struct?: DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValues): any;
export declare function dataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValuesToHclTerraform(struct?: DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValues): any;
export declare class DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValues | undefined;
    set internalValue(value: DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValues | undefined);
    get booleanValue(): cdktn.IResolvable;
    get numberArray(): number[];
    get numberValue(): number;
    get stringArray(): string[];
    get stringValue(): string;
}
export declare class DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValuesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValuesOutputReference;
}
export interface DataAwsccAppconfigExperimentDefinitionTreatments {
}
export declare function dataAwsccAppconfigExperimentDefinitionTreatmentsToTerraform(struct?: DataAwsccAppconfigExperimentDefinitionTreatments): any;
export declare function dataAwsccAppconfigExperimentDefinitionTreatmentsToHclTerraform(struct?: DataAwsccAppconfigExperimentDefinitionTreatments): any;
export declare class DataAwsccAppconfigExperimentDefinitionTreatmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigExperimentDefinitionTreatments | undefined;
    set internalValue(value: DataAwsccAppconfigExperimentDefinitionTreatments | undefined);
    private _attributeValues;
    get attributeValues(): DataAwsccAppconfigExperimentDefinitionTreatmentsAttributeValuesMap;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get key(): string;
    get weight(): number;
}
export declare class DataAwsccAppconfigExperimentDefinitionTreatmentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigExperimentDefinitionTreatmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_experiment_definition awscc_appconfig_experiment_definition}
*/
export declare class DataAwsccAppconfigExperimentDefinition extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_appconfig_experiment_definition";
    /**
    * Generates CDKTN code for importing a DataAwsccAppconfigExperimentDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAppconfigExperimentDefinition to import
    * @param importFromId The id of the existing DataAwsccAppconfigExperimentDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_experiment_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAppconfigExperimentDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_experiment_definition awscc_appconfig_experiment_definition} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAppconfigExperimentDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAppconfigExperimentDefinitionConfig);
    get applicationId(): string;
    get applicationIdentifier(): string;
    get audienceDescription(): string;
    get audienceRule(): string;
    get configurationProfileIdentifier(): string;
    private _control;
    get control(): DataAwsccAppconfigExperimentDefinitionControlOutputReference;
    get createdAt(): string;
    get environmentIdentifier(): string;
    get experimentDefinitionId(): string;
    get flagKey(): string;
    get hypothesis(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get launchCriteria(): string;
    get name(): string;
    get status(): string;
    private _tags;
    get tags(): DataAwsccAppconfigExperimentDefinitionTagsList;
    private _treatments;
    get treatments(): DataAwsccAppconfigExperimentDefinitionTreatmentsList;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
