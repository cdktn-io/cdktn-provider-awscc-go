/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockIntelligentPromptRouterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the Prompt Router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#description BedrockIntelligentPromptRouter#description}
    */
    readonly description?: string;
    /**
    * Model configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#fallback_model BedrockIntelligentPromptRouter#fallback_model}
    */
    readonly fallbackModel: BedrockIntelligentPromptRouterFallbackModel;
    /**
    * List of model configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#models BedrockIntelligentPromptRouter#models}
    */
    readonly models: BedrockIntelligentPromptRouterModels[] | cdktn.IResolvable;
    /**
    * Name of the Prompt Router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#prompt_router_name BedrockIntelligentPromptRouter#prompt_router_name}
    */
    readonly promptRouterName: string;
    /**
    * Represents the criteria used for routing requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#routing_criteria BedrockIntelligentPromptRouter#routing_criteria}
    */
    readonly routingCriteria: BedrockIntelligentPromptRouterRoutingCriteria;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#tags BedrockIntelligentPromptRouter#tags}
    */
    readonly tags?: BedrockIntelligentPromptRouterTags[] | cdktn.IResolvable;
}
export interface BedrockIntelligentPromptRouterFallbackModel {
    /**
    * Arn of underlying model which are added in the Prompt Router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#model_arn BedrockIntelligentPromptRouter#model_arn}
    */
    readonly modelArn: string;
}
export declare function bedrockIntelligentPromptRouterFallbackModelToTerraform(struct?: BedrockIntelligentPromptRouterFallbackModel | cdktn.IResolvable): any;
export declare function bedrockIntelligentPromptRouterFallbackModelToHclTerraform(struct?: BedrockIntelligentPromptRouterFallbackModel | cdktn.IResolvable): any;
export declare class BedrockIntelligentPromptRouterFallbackModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockIntelligentPromptRouterFallbackModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockIntelligentPromptRouterFallbackModel | cdktn.IResolvable | undefined);
    private _modelArn?;
    get modelArn(): string;
    set modelArn(value: string);
    get modelArnInput(): string | undefined;
}
export interface BedrockIntelligentPromptRouterModels {
    /**
    * Arn of underlying model which are added in the Prompt Router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#model_arn BedrockIntelligentPromptRouter#model_arn}
    */
    readonly modelArn: string;
}
export declare function bedrockIntelligentPromptRouterModelsToTerraform(struct?: BedrockIntelligentPromptRouterModels | cdktn.IResolvable): any;
export declare function bedrockIntelligentPromptRouterModelsToHclTerraform(struct?: BedrockIntelligentPromptRouterModels | cdktn.IResolvable): any;
export declare class BedrockIntelligentPromptRouterModelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockIntelligentPromptRouterModels | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockIntelligentPromptRouterModels | cdktn.IResolvable | undefined);
    private _modelArn?;
    get modelArn(): string;
    set modelArn(value: string);
    get modelArnInput(): string | undefined;
}
export declare class BedrockIntelligentPromptRouterModelsList extends cdktn.ComplexList {
    internalValue?: BedrockIntelligentPromptRouterModels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockIntelligentPromptRouterModelsOutputReference;
}
export interface BedrockIntelligentPromptRouterRoutingCriteria {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#response_quality_difference BedrockIntelligentPromptRouter#response_quality_difference}
    */
    readonly responseQualityDifference: number;
}
export declare function bedrockIntelligentPromptRouterRoutingCriteriaToTerraform(struct?: BedrockIntelligentPromptRouterRoutingCriteria | cdktn.IResolvable): any;
export declare function bedrockIntelligentPromptRouterRoutingCriteriaToHclTerraform(struct?: BedrockIntelligentPromptRouterRoutingCriteria | cdktn.IResolvable): any;
export declare class BedrockIntelligentPromptRouterRoutingCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockIntelligentPromptRouterRoutingCriteria | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockIntelligentPromptRouterRoutingCriteria | cdktn.IResolvable | undefined);
    private _responseQualityDifference?;
    get responseQualityDifference(): number;
    set responseQualityDifference(value: number);
    get responseQualityDifferenceInput(): number | undefined;
}
export interface BedrockIntelligentPromptRouterTags {
    /**
    * Tag Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#key BedrockIntelligentPromptRouter#key}
    */
    readonly key?: string;
    /**
    * Tag Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#value BedrockIntelligentPromptRouter#value}
    */
    readonly value?: string;
}
export declare function bedrockIntelligentPromptRouterTagsToTerraform(struct?: BedrockIntelligentPromptRouterTags | cdktn.IResolvable): any;
export declare function bedrockIntelligentPromptRouterTagsToHclTerraform(struct?: BedrockIntelligentPromptRouterTags | cdktn.IResolvable): any;
export declare class BedrockIntelligentPromptRouterTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockIntelligentPromptRouterTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockIntelligentPromptRouterTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockIntelligentPromptRouterTagsList extends cdktn.ComplexList {
    internalValue?: BedrockIntelligentPromptRouterTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockIntelligentPromptRouterTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router awscc_bedrock_intelligent_prompt_router}
*/
export declare class BedrockIntelligentPromptRouter extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_intelligent_prompt_router";
    /**
    * Generates CDKTN code for importing a BedrockIntelligentPromptRouter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockIntelligentPromptRouter to import
    * @param importFromId The id of the existing BedrockIntelligentPromptRouter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockIntelligentPromptRouter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_intelligent_prompt_router awscc_bedrock_intelligent_prompt_router} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockIntelligentPromptRouterConfig
    */
    constructor(scope: Construct, id: string, config: BedrockIntelligentPromptRouterConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _fallbackModel;
    get fallbackModel(): BedrockIntelligentPromptRouterFallbackModelOutputReference;
    putFallbackModel(value: BedrockIntelligentPromptRouterFallbackModel): void;
    get fallbackModelInput(): cdktn.IResolvable | BedrockIntelligentPromptRouterFallbackModel | undefined;
    get id(): string;
    private _models;
    get models(): BedrockIntelligentPromptRouterModelsList;
    putModels(value: BedrockIntelligentPromptRouterModels[] | cdktn.IResolvable): void;
    get modelsInput(): cdktn.IResolvable | BedrockIntelligentPromptRouterModels[] | undefined;
    get promptRouterArn(): string;
    private _promptRouterName?;
    get promptRouterName(): string;
    set promptRouterName(value: string);
    get promptRouterNameInput(): string | undefined;
    private _routingCriteria;
    get routingCriteria(): BedrockIntelligentPromptRouterRoutingCriteriaOutputReference;
    putRoutingCriteria(value: BedrockIntelligentPromptRouterRoutingCriteria): void;
    get routingCriteriaInput(): cdktn.IResolvable | BedrockIntelligentPromptRouterRoutingCriteria | undefined;
    get status(): string;
    private _tags;
    get tags(): BedrockIntelligentPromptRouterTagsList;
    putTags(value: BedrockIntelligentPromptRouterTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockIntelligentPromptRouterTags[] | undefined;
    get type(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
