/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectDataLakeAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the analytics data set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_data_lake_association#data_set_id ConnectDataLakeAssociation#data_set_id}
    */
    readonly dataSetId: string;
    /**
    * The identifier of the Amazon Connect instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_data_lake_association#instance_id ConnectDataLakeAssociation#instance_id}
    */
    readonly instanceId: string;
    /**
    * The identifier of the target account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_data_lake_association#target_account_id ConnectDataLakeAssociation#target_account_id}
    */
    readonly targetAccountId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_data_lake_association awscc_connect_data_lake_association}
*/
export declare class ConnectDataLakeAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_data_lake_association";
    /**
    * Generates CDKTN code for importing a ConnectDataLakeAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectDataLakeAssociation to import
    * @param importFromId The id of the existing ConnectDataLakeAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_data_lake_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectDataLakeAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_data_lake_association awscc_connect_data_lake_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectDataLakeAssociationConfig
    */
    constructor(scope: Construct, id: string, config: ConnectDataLakeAssociationConfig);
    private _dataSetId?;
    get dataSetId(): string;
    set dataSetId(value: string);
    get dataSetIdInput(): string | undefined;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get resourceShareArn(): string;
    get resourceShareId(): string;
    private _targetAccountId?;
    get targetAccountId(): string;
    set targetAccountId(value: string);
    resetTargetAccountId(): void;
    get targetAccountIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
