/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChatbotCustomActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#action_name ChatbotCustomAction#action_name}
    */
    readonly actionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#alias_name ChatbotCustomAction#alias_name}
    */
    readonly aliasName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#attachments ChatbotCustomAction#attachments}
    */
    readonly attachments?: ChatbotCustomActionAttachments[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#definition ChatbotCustomAction#definition}
    */
    readonly definition: ChatbotCustomActionDefinition;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#tags ChatbotCustomAction#tags}
    */
    readonly tags?: ChatbotCustomActionTags[] | cdktn.IResolvable;
}
export interface ChatbotCustomActionAttachmentsCriteria {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#operator ChatbotCustomAction#operator}
    */
    readonly operator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#value ChatbotCustomAction#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#variable_name ChatbotCustomAction#variable_name}
    */
    readonly variableName?: string;
}
export declare function chatbotCustomActionAttachmentsCriteriaToTerraform(struct?: ChatbotCustomActionAttachmentsCriteria | cdktn.IResolvable): any;
export declare function chatbotCustomActionAttachmentsCriteriaToHclTerraform(struct?: ChatbotCustomActionAttachmentsCriteria | cdktn.IResolvable): any;
export declare class ChatbotCustomActionAttachmentsCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChatbotCustomActionAttachmentsCriteria | cdktn.IResolvable | undefined;
    set internalValue(value: ChatbotCustomActionAttachmentsCriteria | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _variableName?;
    get variableName(): string;
    set variableName(value: string);
    resetVariableName(): void;
    get variableNameInput(): string | undefined;
}
export declare class ChatbotCustomActionAttachmentsCriteriaList extends cdktn.ComplexList {
    internalValue?: ChatbotCustomActionAttachmentsCriteria[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChatbotCustomActionAttachmentsCriteriaOutputReference;
}
export interface ChatbotCustomActionAttachments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#button_text ChatbotCustomAction#button_text}
    */
    readonly buttonText?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#criteria ChatbotCustomAction#criteria}
    */
    readonly criteria?: ChatbotCustomActionAttachmentsCriteria[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#notification_type ChatbotCustomAction#notification_type}
    */
    readonly notificationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#variables ChatbotCustomAction#variables}
    */
    readonly variables?: {
        [key: string]: string;
    };
}
export declare function chatbotCustomActionAttachmentsToTerraform(struct?: ChatbotCustomActionAttachments | cdktn.IResolvable): any;
export declare function chatbotCustomActionAttachmentsToHclTerraform(struct?: ChatbotCustomActionAttachments | cdktn.IResolvable): any;
export declare class ChatbotCustomActionAttachmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChatbotCustomActionAttachments | cdktn.IResolvable | undefined;
    set internalValue(value: ChatbotCustomActionAttachments | cdktn.IResolvable | undefined);
    private _buttonText?;
    get buttonText(): string;
    set buttonText(value: string);
    resetButtonText(): void;
    get buttonTextInput(): string | undefined;
    private _criteria;
    get criteria(): ChatbotCustomActionAttachmentsCriteriaList;
    putCriteria(value: ChatbotCustomActionAttachmentsCriteria[] | cdktn.IResolvable): void;
    resetCriteria(): void;
    get criteriaInput(): cdktn.IResolvable | ChatbotCustomActionAttachmentsCriteria[] | undefined;
    private _notificationType?;
    get notificationType(): string;
    set notificationType(value: string);
    resetNotificationType(): void;
    get notificationTypeInput(): string | undefined;
    private _variables?;
    get variables(): {
        [key: string]: string;
    };
    set variables(value: {
        [key: string]: string;
    });
    resetVariables(): void;
    get variablesInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class ChatbotCustomActionAttachmentsList extends cdktn.ComplexList {
    internalValue?: ChatbotCustomActionAttachments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChatbotCustomActionAttachmentsOutputReference;
}
export interface ChatbotCustomActionDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#command_text ChatbotCustomAction#command_text}
    */
    readonly commandText: string;
}
export declare function chatbotCustomActionDefinitionToTerraform(struct?: ChatbotCustomActionDefinition | cdktn.IResolvable): any;
export declare function chatbotCustomActionDefinitionToHclTerraform(struct?: ChatbotCustomActionDefinition | cdktn.IResolvable): any;
export declare class ChatbotCustomActionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChatbotCustomActionDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: ChatbotCustomActionDefinition | cdktn.IResolvable | undefined);
    private _commandText?;
    get commandText(): string;
    set commandText(value: string);
    get commandTextInput(): string | undefined;
}
export interface ChatbotCustomActionTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#key ChatbotCustomAction#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#value ChatbotCustomAction#value}
    */
    readonly value?: string;
}
export declare function chatbotCustomActionTagsToTerraform(struct?: ChatbotCustomActionTags | cdktn.IResolvable): any;
export declare function chatbotCustomActionTagsToHclTerraform(struct?: ChatbotCustomActionTags | cdktn.IResolvable): any;
export declare class ChatbotCustomActionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChatbotCustomActionTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChatbotCustomActionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChatbotCustomActionTagsList extends cdktn.ComplexList {
    internalValue?: ChatbotCustomActionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChatbotCustomActionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action awscc_chatbot_custom_action}
*/
export declare class ChatbotCustomAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chatbot_custom_action";
    /**
    * Generates CDKTN code for importing a ChatbotCustomAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChatbotCustomAction to import
    * @param importFromId The id of the existing ChatbotCustomAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChatbotCustomAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chatbot_custom_action awscc_chatbot_custom_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChatbotCustomActionConfig
    */
    constructor(scope: Construct, id: string, config: ChatbotCustomActionConfig);
    private _actionName?;
    get actionName(): string;
    set actionName(value: string);
    get actionNameInput(): string | undefined;
    private _aliasName?;
    get aliasName(): string;
    set aliasName(value: string);
    resetAliasName(): void;
    get aliasNameInput(): string | undefined;
    private _attachments;
    get attachments(): ChatbotCustomActionAttachmentsList;
    putAttachments(value: ChatbotCustomActionAttachments[] | cdktn.IResolvable): void;
    resetAttachments(): void;
    get attachmentsInput(): cdktn.IResolvable | ChatbotCustomActionAttachments[] | undefined;
    get customActionArn(): string;
    private _definition;
    get definition(): ChatbotCustomActionDefinitionOutputReference;
    putDefinition(value: ChatbotCustomActionDefinition): void;
    get definitionInput(): cdktn.IResolvable | ChatbotCustomActionDefinition | undefined;
    get id(): string;
    private _tags;
    get tags(): ChatbotCustomActionTagsList;
    putTags(value: ChatbotCustomActionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChatbotCustomActionTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
