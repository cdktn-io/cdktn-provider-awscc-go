/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodeartifactRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * A text description of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#description CodeartifactRepository#description}
    */
    readonly description?: string;
    /**
    * The name of the domain that contains the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#domain_name CodeartifactRepository#domain_name}
    */
    readonly domainName: string;
    /**
    * A list of external connections associated with the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#external_connections CodeartifactRepository#external_connections}
    */
    readonly externalConnections?: string[];
    /**
    * The access control resource policy on the provided repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#permissions_policy_document CodeartifactRepository#permissions_policy_document}
    */
    readonly permissionsPolicyDocument?: string;
    /**
    * The name of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#repository_name CodeartifactRepository#repository_name}
    */
    readonly repositoryName: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#tags CodeartifactRepository#tags}
    */
    readonly tags?: CodeartifactRepositoryTags[] | cdktn.IResolvable;
    /**
    * A list of upstream repositories associated with the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#upstreams CodeartifactRepository#upstreams}
    */
    readonly upstreams?: string[];
}
export interface CodeartifactRepositoryTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#key CodeartifactRepository#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#value CodeartifactRepository#value}
    */
    readonly value?: string;
}
export declare function codeartifactRepositoryTagsToTerraform(struct?: CodeartifactRepositoryTags | cdktn.IResolvable): any;
export declare function codeartifactRepositoryTagsToHclTerraform(struct?: CodeartifactRepositoryTags | cdktn.IResolvable): any;
export declare class CodeartifactRepositoryTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodeartifactRepositoryTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodeartifactRepositoryTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodeartifactRepositoryTagsList extends cdktn.ComplexList {
    internalValue?: CodeartifactRepositoryTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodeartifactRepositoryTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository awscc_codeartifact_repository}
*/
export declare class CodeartifactRepository extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codeartifact_repository";
    /**
    * Generates CDKTN code for importing a CodeartifactRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodeartifactRepository to import
    * @param importFromId The id of the existing CodeartifactRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodeartifactRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codeartifact_repository awscc_codeartifact_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodeartifactRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: CodeartifactRepositoryConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get domainOwner(): string;
    private _externalConnections?;
    get externalConnections(): string[];
    set externalConnections(value: string[]);
    resetExternalConnections(): void;
    get externalConnectionsInput(): string[] | undefined;
    get id(): string;
    get name(): string;
    private _permissionsPolicyDocument?;
    get permissionsPolicyDocument(): string;
    set permissionsPolicyDocument(value: string);
    resetPermissionsPolicyDocument(): void;
    get permissionsPolicyDocumentInput(): string | undefined;
    private _repositoryName?;
    get repositoryName(): string;
    set repositoryName(value: string);
    get repositoryNameInput(): string | undefined;
    private _tags;
    get tags(): CodeartifactRepositoryTagsList;
    putTags(value: CodeartifactRepositoryTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodeartifactRepositoryTags[] | undefined;
    private _upstreams?;
    get upstreams(): string[];
    set upstreams(value: string[]);
    resetUpstreams(): void;
    get upstreamsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
