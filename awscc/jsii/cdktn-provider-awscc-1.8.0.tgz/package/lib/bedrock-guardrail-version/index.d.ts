/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockGuardrailVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the Guardrail version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_guardrail_version#description BedrockGuardrailVersion#description}
    */
    readonly description?: string;
    /**
    * Identifier (GuardrailId or GuardrailArn) for the guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_guardrail_version#guardrail_identifier BedrockGuardrailVersion#guardrail_identifier}
    */
    readonly guardrailIdentifier: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_guardrail_version awscc_bedrock_guardrail_version}
*/
export declare class BedrockGuardrailVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_guardrail_version";
    /**
    * Generates CDKTN code for importing a BedrockGuardrailVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockGuardrailVersion to import
    * @param importFromId The id of the existing BedrockGuardrailVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_guardrail_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockGuardrailVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_guardrail_version awscc_bedrock_guardrail_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockGuardrailVersionConfig
    */
    constructor(scope: Construct, id: string, config: BedrockGuardrailVersionConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get guardrailArn(): string;
    get guardrailId(): string;
    private _guardrailIdentifier?;
    get guardrailIdentifier(): string;
    set guardrailIdentifier(value: string);
    get guardrailIdentifierInput(): string | undefined;
    get id(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
