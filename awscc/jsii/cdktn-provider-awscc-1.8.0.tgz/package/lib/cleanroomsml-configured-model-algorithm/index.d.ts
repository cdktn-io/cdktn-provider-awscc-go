/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsmlConfiguredModelAlgorithmConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#description CleanroomsmlConfiguredModelAlgorithm#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#inference_container_config CleanroomsmlConfiguredModelAlgorithm#inference_container_config}
    */
    readonly inferenceContainerConfig?: CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#kms_key_arn CleanroomsmlConfiguredModelAlgorithm#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#name CleanroomsmlConfiguredModelAlgorithm#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#role_arn CleanroomsmlConfiguredModelAlgorithm#role_arn}
    */
    readonly roleArn: string;
    /**
    * An arbitrary set of tags (key-value pairs) for this cleanrooms-ml configured model algorithm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#tags CleanroomsmlConfiguredModelAlgorithm#tags}
    */
    readonly tags?: CleanroomsmlConfiguredModelAlgorithmTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#training_container_config CleanroomsmlConfiguredModelAlgorithm#training_container_config}
    */
    readonly trainingContainerConfig?: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfig;
}
export interface CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#image_uri CleanroomsmlConfiguredModelAlgorithm#image_uri}
    */
    readonly imageUri?: string;
}
export declare function cleanroomsmlConfiguredModelAlgorithmInferenceContainerConfigToTerraform(struct?: CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfig | cdktn.IResolvable): any;
export declare function cleanroomsmlConfiguredModelAlgorithmInferenceContainerConfigToHclTerraform(struct?: CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfig | cdktn.IResolvable): any;
export declare class CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfig | cdktn.IResolvable | undefined);
    private _imageUri?;
    get imageUri(): string;
    set imageUri(value: string);
    resetImageUri(): void;
    get imageUriInput(): string | undefined;
}
export interface CleanroomsmlConfiguredModelAlgorithmTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#key CleanroomsmlConfiguredModelAlgorithm#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#value CleanroomsmlConfiguredModelAlgorithm#value}
    */
    readonly value?: string;
}
export declare function cleanroomsmlConfiguredModelAlgorithmTagsToTerraform(struct?: CleanroomsmlConfiguredModelAlgorithmTags | cdktn.IResolvable): any;
export declare function cleanroomsmlConfiguredModelAlgorithmTagsToHclTerraform(struct?: CleanroomsmlConfiguredModelAlgorithmTags | cdktn.IResolvable): any;
export declare class CleanroomsmlConfiguredModelAlgorithmTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsmlConfiguredModelAlgorithmTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlConfiguredModelAlgorithmTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsmlConfiguredModelAlgorithmTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsmlConfiguredModelAlgorithmTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsmlConfiguredModelAlgorithmTagsOutputReference;
}
export interface CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#name CleanroomsmlConfiguredModelAlgorithm#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#regex CleanroomsmlConfiguredModelAlgorithm#regex}
    */
    readonly regex?: string;
}
export declare function cleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitionsToTerraform(struct?: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions | cdktn.IResolvable): any;
export declare function cleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitionsToHclTerraform(struct?: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions | cdktn.IResolvable): any;
export declare class CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
}
export declare class CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitionsList extends cdktn.ComplexList {
    internalValue?: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitionsOutputReference;
}
export interface CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#arguments CleanroomsmlConfiguredModelAlgorithm#arguments}
    */
    readonly arguments?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#entrypoint CleanroomsmlConfiguredModelAlgorithm#entrypoint}
    */
    readonly entrypoint?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#image_uri CleanroomsmlConfiguredModelAlgorithm#image_uri}
    */
    readonly imageUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#metric_definitions CleanroomsmlConfiguredModelAlgorithm#metric_definitions}
    */
    readonly metricDefinitions?: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions[] | cdktn.IResolvable;
}
export declare function cleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigToTerraform(struct?: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfig | cdktn.IResolvable): any;
export declare function cleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigToHclTerraform(struct?: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfig | cdktn.IResolvable): any;
export declare class CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfig | cdktn.IResolvable | undefined);
    private _arguments?;
    get arguments(): string[];
    set arguments(value: string[]);
    resetArguments(): void;
    get argumentsInput(): string[] | undefined;
    private _entrypoint?;
    get entrypoint(): string[];
    set entrypoint(value: string[]);
    resetEntrypoint(): void;
    get entrypointInput(): string[] | undefined;
    private _imageUri?;
    get imageUri(): string;
    set imageUri(value: string);
    resetImageUri(): void;
    get imageUriInput(): string | undefined;
    private _metricDefinitions;
    get metricDefinitions(): CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitionsList;
    putMetricDefinitions(value: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions[] | cdktn.IResolvable): void;
    resetMetricDefinitions(): void;
    get metricDefinitionsInput(): cdktn.IResolvable | CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigMetricDefinitions[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm awscc_cleanroomsml_configured_model_algorithm}
*/
export declare class CleanroomsmlConfiguredModelAlgorithm extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanroomsml_configured_model_algorithm";
    /**
    * Generates CDKTN code for importing a CleanroomsmlConfiguredModelAlgorithm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsmlConfiguredModelAlgorithm to import
    * @param importFromId The id of the existing CleanroomsmlConfiguredModelAlgorithm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsmlConfiguredModelAlgorithm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cleanroomsml_configured_model_algorithm awscc_cleanroomsml_configured_model_algorithm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsmlConfiguredModelAlgorithmConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsmlConfiguredModelAlgorithmConfig);
    get configuredModelAlgorithmArn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _inferenceContainerConfig;
    get inferenceContainerConfig(): CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfigOutputReference;
    putInferenceContainerConfig(value: CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfig): void;
    resetInferenceContainerConfig(): void;
    get inferenceContainerConfigInput(): cdktn.IResolvable | CleanroomsmlConfiguredModelAlgorithmInferenceContainerConfig | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags;
    get tags(): CleanroomsmlConfiguredModelAlgorithmTagsList;
    putTags(value: CleanroomsmlConfiguredModelAlgorithmTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsmlConfiguredModelAlgorithmTags[] | undefined;
    private _trainingContainerConfig;
    get trainingContainerConfig(): CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfigOutputReference;
    putTrainingContainerConfig(value: CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfig): void;
    resetTrainingContainerConfig(): void;
    get trainingContainerConfigInput(): cdktn.IResolvable | CleanroomsmlConfiguredModelAlgorithmTrainingContainerConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
