/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2ApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_api#id DataAwsccApigatewayv2Api#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2ApiBodyS3Location {
}
export declare function dataAwsccApigatewayv2ApiBodyS3LocationToTerraform(struct?: DataAwsccApigatewayv2ApiBodyS3Location): any;
export declare function dataAwsccApigatewayv2ApiBodyS3LocationToHclTerraform(struct?: DataAwsccApigatewayv2ApiBodyS3Location): any;
export declare class DataAwsccApigatewayv2ApiBodyS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2ApiBodyS3Location | undefined;
    set internalValue(value: DataAwsccApigatewayv2ApiBodyS3Location | undefined);
    get bucket(): string;
    get etag(): string;
    get key(): string;
    get version(): string;
}
export interface DataAwsccApigatewayv2ApiCorsConfiguration {
}
export declare function dataAwsccApigatewayv2ApiCorsConfigurationToTerraform(struct?: DataAwsccApigatewayv2ApiCorsConfiguration): any;
export declare function dataAwsccApigatewayv2ApiCorsConfigurationToHclTerraform(struct?: DataAwsccApigatewayv2ApiCorsConfiguration): any;
export declare class DataAwsccApigatewayv2ApiCorsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2ApiCorsConfiguration | undefined;
    set internalValue(value: DataAwsccApigatewayv2ApiCorsConfiguration | undefined);
    get allowCredentials(): cdktn.IResolvable;
    get allowHeaders(): string[];
    get allowMethods(): string[];
    get allowOrigins(): string[];
    get exposeHeaders(): string[];
    get maxAge(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_api awscc_apigatewayv2_api}
*/
export declare class DataAwsccApigatewayv2Api extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_api";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2Api resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2Api to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2Api that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2Api to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_api awscc_apigatewayv2_api} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2ApiConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2ApiConfig);
    get apiEndpoint(): string;
    get apiId(): string;
    get apiKeySelectionExpression(): string;
    get basePath(): string;
    get body(): string;
    private _bodyS3Location;
    get bodyS3Location(): DataAwsccApigatewayv2ApiBodyS3LocationOutputReference;
    private _corsConfiguration;
    get corsConfiguration(): DataAwsccApigatewayv2ApiCorsConfigurationOutputReference;
    get credentialsArn(): string;
    get description(): string;
    get disableExecuteApiEndpoint(): cdktn.IResolvable;
    get disableSchemaValidation(): cdktn.IResolvable;
    get executeApiArn(): string;
    get failOnWarnings(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get ipAddressType(): string;
    get name(): string;
    get protocolType(): string;
    get routeKey(): string;
    get routeSelectionExpression(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get target(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
