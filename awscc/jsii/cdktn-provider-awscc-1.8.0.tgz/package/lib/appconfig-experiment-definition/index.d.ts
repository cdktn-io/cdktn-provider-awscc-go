/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigExperimentDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The application ID, name, or ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#application_identifier AppconfigExperimentDefinition#application_identifier}
    */
    readonly applicationIdentifier: string;
    /**
    * Human-readable description of the audience.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#audience_description AppconfigExperimentDefinition#audience_description}
    */
    readonly audienceDescription?: string;
    /**
    * Rule expression defining the experiment audience.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#audience_rule AppconfigExperimentDefinition#audience_rule}
    */
    readonly audienceRule: string;
    /**
    * The configuration profile ID, name, or ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#configuration_profile_identifier AppconfigExperimentDefinition#configuration_profile_identifier}
    */
    readonly configurationProfileIdentifier: string;
    /**
    * The control (baseline) variant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#control AppconfigExperimentDefinition#control}
    */
    readonly control: AppconfigExperimentDefinitionControl;
    /**
    * The environment ID, name, or ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#environment_identifier AppconfigExperimentDefinition#environment_identifier}
    */
    readonly environmentIdentifier: string;
    /**
    * The key of the existing flag in the configuration profile to experiment on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#flag_key AppconfigExperimentDefinition#flag_key}
    */
    readonly flagKey: string;
    /**
    * The hypothesis of the experiment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#hypothesis AppconfigExperimentDefinition#hypothesis}
    */
    readonly hypothesis?: string;
    /**
    * Criteria for launching the experiment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#launch_criteria AppconfigExperimentDefinition#launch_criteria}
    */
    readonly launchCriteria?: string;
    /**
    * A name for the experiment definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#name AppconfigExperimentDefinition#name}
    */
    readonly name: string;
    /**
    * Tags to associate with the experiment definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#tags AppconfigExperimentDefinition#tags}
    */
    readonly tags?: AppconfigExperimentDefinitionTags[] | cdktn.IResolvable;
    /**
    * Treatment variants (1-5).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#treatments AppconfigExperimentDefinition#treatments}
    */
    readonly treatments: AppconfigExperimentDefinitionTreatments[] | cdktn.IResolvable;
}
export interface AppconfigExperimentDefinitionControlAttributeValues {
    /**
    * A boolean value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#boolean_value AppconfigExperimentDefinition#boolean_value}
    */
    readonly booleanValue?: boolean | cdktn.IResolvable;
    /**
    * An array of numeric values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#number_array AppconfigExperimentDefinition#number_array}
    */
    readonly numberArray?: number[];
    /**
    * A numeric value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#number_value AppconfigExperimentDefinition#number_value}
    */
    readonly numberValue?: number;
    /**
    * An array of string values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#string_array AppconfigExperimentDefinition#string_array}
    */
    readonly stringArray?: string[];
    /**
    * A string value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#string_value AppconfigExperimentDefinition#string_value}
    */
    readonly stringValue?: string;
}
export declare function appconfigExperimentDefinitionControlAttributeValuesToTerraform(struct?: AppconfigExperimentDefinitionControlAttributeValues | cdktn.IResolvable): any;
export declare function appconfigExperimentDefinitionControlAttributeValuesToHclTerraform(struct?: AppconfigExperimentDefinitionControlAttributeValues | cdktn.IResolvable): any;
export declare class AppconfigExperimentDefinitionControlAttributeValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AppconfigExperimentDefinitionControlAttributeValues | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExperimentDefinitionControlAttributeValues | cdktn.IResolvable | undefined);
    private _booleanValue?;
    get booleanValue(): boolean | cdktn.IResolvable;
    set booleanValue(value: boolean | cdktn.IResolvable);
    resetBooleanValue(): void;
    get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
    private _numberArray?;
    get numberArray(): number[];
    set numberArray(value: number[]);
    resetNumberArray(): void;
    get numberArrayInput(): number[] | undefined;
    private _numberValue?;
    get numberValue(): number;
    set numberValue(value: number);
    resetNumberValue(): void;
    get numberValueInput(): number | undefined;
    private _stringArray?;
    get stringArray(): string[];
    set stringArray(value: string[]);
    resetStringArray(): void;
    get stringArrayInput(): string[] | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export declare class AppconfigExperimentDefinitionControlAttributeValuesMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: AppconfigExperimentDefinitionControlAttributeValues;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AppconfigExperimentDefinitionControlAttributeValuesOutputReference;
}
export interface AppconfigExperimentDefinitionControl {
    /**
    * Map of attribute name to attribute value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#attribute_values AppconfigExperimentDefinition#attribute_values}
    */
    readonly attributeValues?: {
        [key: string]: AppconfigExperimentDefinitionControlAttributeValues;
    } | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#description AppconfigExperimentDefinition#description}
    */
    readonly description?: string;
    /**
    * Whether the flag is enabled for this variant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#enabled AppconfigExperimentDefinition#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Traffic weight percentage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#weight AppconfigExperimentDefinition#weight}
    */
    readonly weight: number;
}
export declare function appconfigExperimentDefinitionControlToTerraform(struct?: AppconfigExperimentDefinitionControl | cdktn.IResolvable): any;
export declare function appconfigExperimentDefinitionControlToHclTerraform(struct?: AppconfigExperimentDefinitionControl | cdktn.IResolvable): any;
export declare class AppconfigExperimentDefinitionControlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppconfigExperimentDefinitionControl | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExperimentDefinitionControl | cdktn.IResolvable | undefined);
    private _attributeValues;
    get attributeValues(): AppconfigExperimentDefinitionControlAttributeValuesMap;
    putAttributeValues(value: {
        [key: string]: AppconfigExperimentDefinitionControlAttributeValues;
    } | cdktn.IResolvable): void;
    resetAttributeValues(): void;
    get attributeValuesInput(): cdktn.IResolvable | {
        [key: string]: AppconfigExperimentDefinitionControlAttributeValues;
    } | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get key(): string;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
}
export interface AppconfigExperimentDefinitionTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#key AppconfigExperimentDefinition#key}
    */
    readonly key?: string;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#value AppconfigExperimentDefinition#value}
    */
    readonly value?: string;
}
export declare function appconfigExperimentDefinitionTagsToTerraform(struct?: AppconfigExperimentDefinitionTags | cdktn.IResolvable): any;
export declare function appconfigExperimentDefinitionTagsToHclTerraform(struct?: AppconfigExperimentDefinitionTags | cdktn.IResolvable): any;
export declare class AppconfigExperimentDefinitionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigExperimentDefinitionTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExperimentDefinitionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppconfigExperimentDefinitionTagsList extends cdktn.ComplexList {
    internalValue?: AppconfigExperimentDefinitionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigExperimentDefinitionTagsOutputReference;
}
export interface AppconfigExperimentDefinitionTreatmentsAttributeValues {
    /**
    * A boolean value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#boolean_value AppconfigExperimentDefinition#boolean_value}
    */
    readonly booleanValue?: boolean | cdktn.IResolvable;
    /**
    * An array of numeric values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#number_array AppconfigExperimentDefinition#number_array}
    */
    readonly numberArray?: number[];
    /**
    * A numeric value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#number_value AppconfigExperimentDefinition#number_value}
    */
    readonly numberValue?: number;
    /**
    * An array of string values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#string_array AppconfigExperimentDefinition#string_array}
    */
    readonly stringArray?: string[];
    /**
    * A string value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#string_value AppconfigExperimentDefinition#string_value}
    */
    readonly stringValue?: string;
}
export declare function appconfigExperimentDefinitionTreatmentsAttributeValuesToTerraform(struct?: AppconfigExperimentDefinitionTreatmentsAttributeValues | cdktn.IResolvable): any;
export declare function appconfigExperimentDefinitionTreatmentsAttributeValuesToHclTerraform(struct?: AppconfigExperimentDefinitionTreatmentsAttributeValues | cdktn.IResolvable): any;
export declare class AppconfigExperimentDefinitionTreatmentsAttributeValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AppconfigExperimentDefinitionTreatmentsAttributeValues | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExperimentDefinitionTreatmentsAttributeValues | cdktn.IResolvable | undefined);
    private _booleanValue?;
    get booleanValue(): boolean | cdktn.IResolvable;
    set booleanValue(value: boolean | cdktn.IResolvable);
    resetBooleanValue(): void;
    get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
    private _numberArray?;
    get numberArray(): number[];
    set numberArray(value: number[]);
    resetNumberArray(): void;
    get numberArrayInput(): number[] | undefined;
    private _numberValue?;
    get numberValue(): number;
    set numberValue(value: number);
    resetNumberValue(): void;
    get numberValueInput(): number | undefined;
    private _stringArray?;
    get stringArray(): string[];
    set stringArray(value: string[]);
    resetStringArray(): void;
    get stringArrayInput(): string[] | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export declare class AppconfigExperimentDefinitionTreatmentsAttributeValuesMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: AppconfigExperimentDefinitionTreatmentsAttributeValues;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AppconfigExperimentDefinitionTreatmentsAttributeValuesOutputReference;
}
export interface AppconfigExperimentDefinitionTreatments {
    /**
    * Map of attribute name to attribute value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#attribute_values AppconfigExperimentDefinition#attribute_values}
    */
    readonly attributeValues?: {
        [key: string]: AppconfigExperimentDefinitionTreatmentsAttributeValues;
    } | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#description AppconfigExperimentDefinition#description}
    */
    readonly description?: string;
    /**
    * Whether the flag is enabled for this variant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#enabled AppconfigExperimentDefinition#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The treatment key (read-only, auto-generated by service).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#key AppconfigExperimentDefinition#key}
    */
    readonly key?: string;
    /**
    * Traffic weight percentage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#weight AppconfigExperimentDefinition#weight}
    */
    readonly weight: number;
}
export declare function appconfigExperimentDefinitionTreatmentsToTerraform(struct?: AppconfigExperimentDefinitionTreatments | cdktn.IResolvable): any;
export declare function appconfigExperimentDefinitionTreatmentsToHclTerraform(struct?: AppconfigExperimentDefinitionTreatments | cdktn.IResolvable): any;
export declare class AppconfigExperimentDefinitionTreatmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigExperimentDefinitionTreatments | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExperimentDefinitionTreatments | cdktn.IResolvable | undefined);
    private _attributeValues;
    get attributeValues(): AppconfigExperimentDefinitionTreatmentsAttributeValuesMap;
    putAttributeValues(value: {
        [key: string]: AppconfigExperimentDefinitionTreatmentsAttributeValues;
    } | cdktn.IResolvable): void;
    resetAttributeValues(): void;
    get attributeValuesInput(): cdktn.IResolvable | {
        [key: string]: AppconfigExperimentDefinitionTreatmentsAttributeValues;
    } | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
}
export declare class AppconfigExperimentDefinitionTreatmentsList extends cdktn.ComplexList {
    internalValue?: AppconfigExperimentDefinitionTreatments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigExperimentDefinitionTreatmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition awscc_appconfig_experiment_definition}
*/
export declare class AppconfigExperimentDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appconfig_experiment_definition";
    /**
    * Generates CDKTN code for importing a AppconfigExperimentDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigExperimentDefinition to import
    * @param importFromId The id of the existing AppconfigExperimentDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigExperimentDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_experiment_definition awscc_appconfig_experiment_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigExperimentDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: AppconfigExperimentDefinitionConfig);
    get applicationId(): string;
    private _applicationIdentifier?;
    get applicationIdentifier(): string;
    set applicationIdentifier(value: string);
    get applicationIdentifierInput(): string | undefined;
    private _audienceDescription?;
    get audienceDescription(): string;
    set audienceDescription(value: string);
    resetAudienceDescription(): void;
    get audienceDescriptionInput(): string | undefined;
    private _audienceRule?;
    get audienceRule(): string;
    set audienceRule(value: string);
    get audienceRuleInput(): string | undefined;
    private _configurationProfileIdentifier?;
    get configurationProfileIdentifier(): string;
    set configurationProfileIdentifier(value: string);
    get configurationProfileIdentifierInput(): string | undefined;
    private _control;
    get control(): AppconfigExperimentDefinitionControlOutputReference;
    putControl(value: AppconfigExperimentDefinitionControl): void;
    get controlInput(): cdktn.IResolvable | AppconfigExperimentDefinitionControl | undefined;
    get createdAt(): string;
    private _environmentIdentifier?;
    get environmentIdentifier(): string;
    set environmentIdentifier(value: string);
    get environmentIdentifierInput(): string | undefined;
    get experimentDefinitionId(): string;
    private _flagKey?;
    get flagKey(): string;
    set flagKey(value: string);
    get flagKeyInput(): string | undefined;
    private _hypothesis?;
    get hypothesis(): string;
    set hypothesis(value: string);
    resetHypothesis(): void;
    get hypothesisInput(): string | undefined;
    get id(): string;
    private _launchCriteria?;
    get launchCriteria(): string;
    set launchCriteria(value: string);
    resetLaunchCriteria(): void;
    get launchCriteriaInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): AppconfigExperimentDefinitionTagsList;
    putTags(value: AppconfigExperimentDefinitionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppconfigExperimentDefinitionTags[] | undefined;
    private _treatments;
    get treatments(): AppconfigExperimentDefinitionTreatmentsList;
    putTreatments(value: AppconfigExperimentDefinitionTreatments[] | cdktn.IResolvable): void;
    get treatmentsInput(): cdktn.IResolvable | AppconfigExperimentDefinitionTreatments[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
