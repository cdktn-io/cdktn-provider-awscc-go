/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectTrafficDistributionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description for the traffic distribution group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group#description ConnectTrafficDistributionGroup#description}
    */
    readonly description?: string;
    /**
    * The identifier of the Amazon Connect instance that has been replicated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group#instance_arn ConnectTrafficDistributionGroup#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name for the traffic distribution group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group#name ConnectTrafficDistributionGroup#name}
    */
    readonly name: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group#tags ConnectTrafficDistributionGroup#tags}
    */
    readonly tags?: ConnectTrafficDistributionGroupTags[] | cdktn.IResolvable;
}
export interface ConnectTrafficDistributionGroupTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group#key ConnectTrafficDistributionGroup#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group#value ConnectTrafficDistributionGroup#value}
    */
    readonly value?: string;
}
export declare function connectTrafficDistributionGroupTagsToTerraform(struct?: ConnectTrafficDistributionGroupTags | cdktn.IResolvable): any;
export declare function connectTrafficDistributionGroupTagsToHclTerraform(struct?: ConnectTrafficDistributionGroupTags | cdktn.IResolvable): any;
export declare class ConnectTrafficDistributionGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectTrafficDistributionGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectTrafficDistributionGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectTrafficDistributionGroupTagsList extends cdktn.ComplexList {
    internalValue?: ConnectTrafficDistributionGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectTrafficDistributionGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group awscc_connect_traffic_distribution_group}
*/
export declare class ConnectTrafficDistributionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_traffic_distribution_group";
    /**
    * Generates CDKTN code for importing a ConnectTrafficDistributionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectTrafficDistributionGroup to import
    * @param importFromId The id of the existing ConnectTrafficDistributionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectTrafficDistributionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_traffic_distribution_group awscc_connect_traffic_distribution_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectTrafficDistributionGroupConfig
    */
    constructor(scope: Construct, id: string, config: ConnectTrafficDistributionGroupConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get isDefault(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): ConnectTrafficDistributionGroupTagsList;
    putTags(value: ConnectTrafficDistributionGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectTrafficDistributionGroupTags[] | undefined;
    get trafficDistributionGroupArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
