/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockApplicationInferenceProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the inference profile
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile#description BedrockApplicationInferenceProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile#inference_profile_name BedrockApplicationInferenceProfile#inference_profile_name}
    */
    readonly inferenceProfileName: string;
    /**
    * Various ways to encode a list of models in a CreateInferenceProfile request
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile#model_source BedrockApplicationInferenceProfile#model_source}
    */
    readonly modelSource?: BedrockApplicationInferenceProfileModelSource;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile#tags BedrockApplicationInferenceProfile#tags}
    */
    readonly tags?: BedrockApplicationInferenceProfileTags[] | cdktn.IResolvable;
}
export interface BedrockApplicationInferenceProfileModelSource {
    /**
    * Source arns for a custom inference profile to copy its regional load balancing config from. This
    * can either be a foundation model or predefined inference profile ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile#copy_from BedrockApplicationInferenceProfile#copy_from}
    */
    readonly copyFrom?: string;
}
export declare function bedrockApplicationInferenceProfileModelSourceToTerraform(struct?: BedrockApplicationInferenceProfileModelSource | cdktn.IResolvable): any;
export declare function bedrockApplicationInferenceProfileModelSourceToHclTerraform(struct?: BedrockApplicationInferenceProfileModelSource | cdktn.IResolvable): any;
export declare class BedrockApplicationInferenceProfileModelSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockApplicationInferenceProfileModelSource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockApplicationInferenceProfileModelSource | cdktn.IResolvable | undefined);
    private _copyFrom?;
    get copyFrom(): string;
    set copyFrom(value: string);
    resetCopyFrom(): void;
    get copyFromInput(): string | undefined;
}
export interface BedrockApplicationInferenceProfileModels {
}
export declare function bedrockApplicationInferenceProfileModelsToTerraform(struct?: BedrockApplicationInferenceProfileModels): any;
export declare function bedrockApplicationInferenceProfileModelsToHclTerraform(struct?: BedrockApplicationInferenceProfileModels): any;
export declare class BedrockApplicationInferenceProfileModelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockApplicationInferenceProfileModels | undefined;
    set internalValue(value: BedrockApplicationInferenceProfileModels | undefined);
    get modelArn(): string;
}
export declare class BedrockApplicationInferenceProfileModelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockApplicationInferenceProfileModelsOutputReference;
}
export interface BedrockApplicationInferenceProfileTags {
    /**
    * Tag Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile#key BedrockApplicationInferenceProfile#key}
    */
    readonly key?: string;
    /**
    * Tag Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile#value BedrockApplicationInferenceProfile#value}
    */
    readonly value?: string;
}
export declare function bedrockApplicationInferenceProfileTagsToTerraform(struct?: BedrockApplicationInferenceProfileTags | cdktn.IResolvable): any;
export declare function bedrockApplicationInferenceProfileTagsToHclTerraform(struct?: BedrockApplicationInferenceProfileTags | cdktn.IResolvable): any;
export declare class BedrockApplicationInferenceProfileTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockApplicationInferenceProfileTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockApplicationInferenceProfileTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockApplicationInferenceProfileTagsList extends cdktn.ComplexList {
    internalValue?: BedrockApplicationInferenceProfileTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockApplicationInferenceProfileTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile awscc_bedrock_application_inference_profile}
*/
export declare class BedrockApplicationInferenceProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_application_inference_profile";
    /**
    * Generates CDKTN code for importing a BedrockApplicationInferenceProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockApplicationInferenceProfile to import
    * @param importFromId The id of the existing BedrockApplicationInferenceProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockApplicationInferenceProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_application_inference_profile awscc_bedrock_application_inference_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockApplicationInferenceProfileConfig
    */
    constructor(scope: Construct, id: string, config: BedrockApplicationInferenceProfileConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get inferenceProfileArn(): string;
    get inferenceProfileId(): string;
    get inferenceProfileIdentifier(): string;
    private _inferenceProfileName?;
    get inferenceProfileName(): string;
    set inferenceProfileName(value: string);
    get inferenceProfileNameInput(): string | undefined;
    private _modelSource;
    get modelSource(): BedrockApplicationInferenceProfileModelSourceOutputReference;
    putModelSource(value: BedrockApplicationInferenceProfileModelSource): void;
    resetModelSource(): void;
    get modelSourceInput(): cdktn.IResolvable | BedrockApplicationInferenceProfileModelSource | undefined;
    private _models;
    get models(): BedrockApplicationInferenceProfileModelsList;
    get status(): string;
    private _tags;
    get tags(): BedrockApplicationInferenceProfileTagsList;
    putTags(value: BedrockApplicationInferenceProfileTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockApplicationInferenceProfileTags[] | undefined;
    get type(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
