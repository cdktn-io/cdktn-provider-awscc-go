/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2IntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_integration#id DataAwsccApigatewayv2Integration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2IntegrationResponseParametersResponseParameters {
}
export declare function dataAwsccApigatewayv2IntegrationResponseParametersResponseParametersToTerraform(struct?: DataAwsccApigatewayv2IntegrationResponseParametersResponseParameters): any;
export declare function dataAwsccApigatewayv2IntegrationResponseParametersResponseParametersToHclTerraform(struct?: DataAwsccApigatewayv2IntegrationResponseParametersResponseParameters): any;
export declare class DataAwsccApigatewayv2IntegrationResponseParametersResponseParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayv2IntegrationResponseParametersResponseParameters | undefined;
    set internalValue(value: DataAwsccApigatewayv2IntegrationResponseParametersResponseParameters | undefined);
    get destination(): string;
    get source(): string;
}
export declare class DataAwsccApigatewayv2IntegrationResponseParametersResponseParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayv2IntegrationResponseParametersResponseParametersOutputReference;
}
export interface DataAwsccApigatewayv2IntegrationResponseParameters {
}
export declare function dataAwsccApigatewayv2IntegrationResponseParametersToTerraform(struct?: DataAwsccApigatewayv2IntegrationResponseParameters): any;
export declare function dataAwsccApigatewayv2IntegrationResponseParametersToHclTerraform(struct?: DataAwsccApigatewayv2IntegrationResponseParameters): any;
export declare class DataAwsccApigatewayv2IntegrationResponseParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataAwsccApigatewayv2IntegrationResponseParameters | undefined;
    set internalValue(value: DataAwsccApigatewayv2IntegrationResponseParameters | undefined);
    private _responseParameters;
    get responseParameters(): DataAwsccApigatewayv2IntegrationResponseParametersResponseParametersList;
}
export declare class DataAwsccApigatewayv2IntegrationResponseParametersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataAwsccApigatewayv2IntegrationResponseParametersOutputReference;
}
export interface DataAwsccApigatewayv2IntegrationTlsConfig {
}
export declare function dataAwsccApigatewayv2IntegrationTlsConfigToTerraform(struct?: DataAwsccApigatewayv2IntegrationTlsConfig): any;
export declare function dataAwsccApigatewayv2IntegrationTlsConfigToHclTerraform(struct?: DataAwsccApigatewayv2IntegrationTlsConfig): any;
export declare class DataAwsccApigatewayv2IntegrationTlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2IntegrationTlsConfig | undefined;
    set internalValue(value: DataAwsccApigatewayv2IntegrationTlsConfig | undefined);
    get serverNameToVerify(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_integration awscc_apigatewayv2_integration}
*/
export declare class DataAwsccApigatewayv2Integration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_integration";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2Integration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2Integration to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2Integration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2Integration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_integration awscc_apigatewayv2_integration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2IntegrationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2IntegrationConfig);
    get apiId(): string;
    get connectionId(): string;
    get connectionType(): string;
    get contentHandlingStrategy(): string;
    get credentialsArn(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get integrationId(): string;
    get integrationMethod(): string;
    get integrationSubtype(): string;
    get integrationType(): string;
    get integrationUri(): string;
    get passthroughBehavior(): string;
    get payloadFormatVersion(): string;
    private _requestParameters;
    get requestParameters(): cdktn.StringMap;
    private _requestTemplates;
    get requestTemplates(): cdktn.StringMap;
    private _responseParameters;
    get responseParameters(): DataAwsccApigatewayv2IntegrationResponseParametersMap;
    get templateSelectionExpression(): string;
    get timeoutInMillis(): number;
    private _tlsConfig;
    get tlsConfig(): DataAwsccApigatewayv2IntegrationTlsConfigOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
