/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CasesFieldConfig extends cdktn.TerraformMetaArguments {
    /**
    * Field-type specific attributes that control rendering and validation behavior
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#attributes CasesField#attributes}
    */
    readonly attributes?: CasesFieldAttributes;
    /**
    * A description explaining the purpose and usage of this field in cases. Helps agents and administrators understand what information should be captured in this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#description CasesField#description}
    */
    readonly description?: string;
    /**
    * The unique identifier of the Cases domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#domain_id CasesField#domain_id}
    */
    readonly domainId?: string;
    /**
    * The display name of the field as it appears to agents in the case interface. Should be descriptive and user-friendly (e.g., 'Customer Priority Level', 'Issue Category').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#name CasesField#name}
    */
    readonly name: string;
    /**
    * The tags that you attach to this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#tags CasesField#tags}
    */
    readonly tags?: CasesFieldTags[] | cdktn.IResolvable;
    /**
    * The data type of the field, which determines validation rules, input constraints, and display format. Each type has specific constraints: Text (string input), Number (numeric values), Boolean (true/false), DateTime (date/time picker), SingleSelect (dropdown options), Url (URL validation), User (Amazon Connect user selection).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#type CasesField#type}
    */
    readonly type: string;
}
export interface CasesFieldAttributesText {
    /**
    * Attribute that defines rendering component and validation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#is_multiline CasesField#is_multiline}
    */
    readonly isMultiline?: boolean | cdktn.IResolvable;
}
export declare function casesFieldAttributesTextToTerraform(struct?: CasesFieldAttributesText | cdktn.IResolvable): any;
export declare function casesFieldAttributesTextToHclTerraform(struct?: CasesFieldAttributesText | cdktn.IResolvable): any;
export declare class CasesFieldAttributesTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesFieldAttributesText | cdktn.IResolvable | undefined;
    set internalValue(value: CasesFieldAttributesText | cdktn.IResolvable | undefined);
    private _isMultiline?;
    get isMultiline(): boolean | cdktn.IResolvable;
    set isMultiline(value: boolean | cdktn.IResolvable);
    resetIsMultiline(): void;
    get isMultilineInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CasesFieldAttributes {
    /**
    * Field attributes for Text field type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#text CasesField#text}
    */
    readonly text?: CasesFieldAttributesText;
}
export declare function casesFieldAttributesToTerraform(struct?: CasesFieldAttributes | cdktn.IResolvable): any;
export declare function casesFieldAttributesToHclTerraform(struct?: CasesFieldAttributes | cdktn.IResolvable): any;
export declare class CasesFieldAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesFieldAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CasesFieldAttributes | cdktn.IResolvable | undefined);
    private _text;
    get text(): CasesFieldAttributesTextOutputReference;
    putText(value: CasesFieldAttributesText): void;
    resetText(): void;
    get textInput(): cdktn.IResolvable | CasesFieldAttributesText | undefined;
}
export interface CasesFieldTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#key CasesField#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#value CasesField#value}
    */
    readonly value?: string;
}
export declare function casesFieldTagsToTerraform(struct?: CasesFieldTags | cdktn.IResolvable): any;
export declare function casesFieldTagsToHclTerraform(struct?: CasesFieldTags | cdktn.IResolvable): any;
export declare class CasesFieldTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesFieldTags | cdktn.IResolvable | undefined;
    set internalValue(value: CasesFieldTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CasesFieldTagsList extends cdktn.ComplexList {
    internalValue?: CasesFieldTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesFieldTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field awscc_cases_field}
*/
export declare class CasesField extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cases_field";
    /**
    * Generates CDKTN code for importing a CasesField resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CasesField to import
    * @param importFromId The id of the existing CasesField that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CasesField to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_field awscc_cases_field} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CasesFieldConfig
    */
    constructor(scope: Construct, id: string, config: CasesFieldConfig);
    private _attributes;
    get attributes(): CasesFieldAttributesOutputReference;
    putAttributes(value: CasesFieldAttributes): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | CasesFieldAttributes | undefined;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    resetDomainId(): void;
    get domainIdInput(): string | undefined;
    get fieldArn(): string;
    get fieldId(): string;
    get id(): string;
    get lastModifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get namespace(): string;
    private _tags;
    get tags(): CasesFieldTagsList;
    putTags(value: CasesFieldTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CasesFieldTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
