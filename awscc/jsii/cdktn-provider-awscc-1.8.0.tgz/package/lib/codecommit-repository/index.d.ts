/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodecommitRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Information about code to be committed to a repository after it is created in an AWS CloudFormation stack. Information about code is only used in resource creation. Updates to a stack will not reflect changes made to code properties after initial resource creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#code CodecommitRepository#code}
    */
    readonly code?: CodecommitRepositoryCode;
    /**
    * The ID of the AWS Key Management Service encryption key used to encrypt and decrypt the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#kms_key_id CodecommitRepository#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * A comment or description about the new repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#repository_description CodecommitRepository#repository_description}
    */
    readonly repositoryDescription?: string;
    /**
    * The name of the new repository to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#repository_name CodecommitRepository#repository_name}
    */
    readonly repositoryName: string;
    /**
    * One or more tag key-value pairs to use when tagging this repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#tags CodecommitRepository#tags}
    */
    readonly tags?: CodecommitRepositoryTags[] | cdktn.IResolvable;
    /**
    * Information about a trigger for a repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#triggers CodecommitRepository#triggers}
    */
    readonly triggers?: CodecommitRepositoryTriggers[] | cdktn.IResolvable;
}
export interface CodecommitRepositoryCodeS3 {
    /**
    * The name of the Amazon S3 bucket that contains the ZIP file with the content that will be committed to the new repository. This can be specified using the name of the bucket in the AWS account. Changes to this property are ignored after initial resource creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#bucket CodecommitRepository#bucket}
    */
    readonly bucket?: string;
    /**
    * The key to use for accessing the Amazon S3 bucket. Changes to this property are ignored after initial resource creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#key CodecommitRepository#key}
    */
    readonly key?: string;
    /**
    * The object version of the ZIP file, if versioning is enabled for the Amazon S3 bucket. Changes to this property are ignored after initial resource creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#object_version CodecommitRepository#object_version}
    */
    readonly objectVersion?: string;
}
export declare function codecommitRepositoryCodeS3ToTerraform(struct?: CodecommitRepositoryCodeS3 | cdktn.IResolvable): any;
export declare function codecommitRepositoryCodeS3ToHclTerraform(struct?: CodecommitRepositoryCodeS3 | cdktn.IResolvable): any;
export declare class CodecommitRepositoryCodeS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodecommitRepositoryCodeS3 | cdktn.IResolvable | undefined;
    set internalValue(value: CodecommitRepositoryCodeS3 | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _objectVersion?;
    get objectVersion(): string;
    set objectVersion(value: string);
    resetObjectVersion(): void;
    get objectVersionInput(): string | undefined;
}
export interface CodecommitRepositoryCode {
    /**
    * Optional. Specifies a branch name to be used as the default branch when importing code into a repository on initial creation. If this property is not set, the name main will be used for the default branch for the repository. Changes to this property are ignored after initial resource creation. We recommend using this parameter to set the name to main to align with the default behavior of CodeCommit unless another name is needed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#branch_name CodecommitRepository#branch_name}
    */
    readonly branchName?: string;
    /**
    * Information about the Amazon S3 bucket that contains a ZIP file of code to be committed to the repository. Changes to this property are ignored after initial resource creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#s3 CodecommitRepository#s3}
    */
    readonly s3?: CodecommitRepositoryCodeS3;
}
export declare function codecommitRepositoryCodeToTerraform(struct?: CodecommitRepositoryCode | cdktn.IResolvable): any;
export declare function codecommitRepositoryCodeToHclTerraform(struct?: CodecommitRepositoryCode | cdktn.IResolvable): any;
export declare class CodecommitRepositoryCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodecommitRepositoryCode | cdktn.IResolvable | undefined;
    set internalValue(value: CodecommitRepositoryCode | cdktn.IResolvable | undefined);
    private _branchName?;
    get branchName(): string;
    set branchName(value: string);
    resetBranchName(): void;
    get branchNameInput(): string | undefined;
    private _s3;
    get s3(): CodecommitRepositoryCodeS3OutputReference;
    putS3(value: CodecommitRepositoryCodeS3): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | CodecommitRepositoryCodeS3 | undefined;
}
export interface CodecommitRepositoryTags {
    /**
    * The tag's key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#key CodecommitRepository#key}
    */
    readonly key?: string;
    /**
    * The tag's value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#value CodecommitRepository#value}
    */
    readonly value?: string;
}
export declare function codecommitRepositoryTagsToTerraform(struct?: CodecommitRepositoryTags | cdktn.IResolvable): any;
export declare function codecommitRepositoryTagsToHclTerraform(struct?: CodecommitRepositoryTags | cdktn.IResolvable): any;
export declare class CodecommitRepositoryTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodecommitRepositoryTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodecommitRepositoryTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodecommitRepositoryTagsList extends cdktn.ComplexList {
    internalValue?: CodecommitRepositoryTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodecommitRepositoryTagsOutputReference;
}
export interface CodecommitRepositoryTriggers {
    /**
    * The branches to be included in the trigger configuration. If you specify an empty array, the trigger applies to all branches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#branches CodecommitRepository#branches}
    */
    readonly branches?: string[];
    /**
    * Any custom data associated with the trigger to be included in the information sent to the target of the trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#custom_data CodecommitRepository#custom_data}
    */
    readonly customData?: string;
    /**
    * The ARN of the resource that is the target for a trigger (for example, the ARN of a topic in Amazon SNS).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#destination_arn CodecommitRepository#destination_arn}
    */
    readonly destinationArn?: string;
    /**
    * The repository events that cause the trigger to run actions in another service, such as sending a notification through Amazon SNS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#events CodecommitRepository#events}
    */
    readonly events?: string[];
    /**
    * The name of the trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#name CodecommitRepository#name}
    */
    readonly name?: string;
}
export declare function codecommitRepositoryTriggersToTerraform(struct?: CodecommitRepositoryTriggers | cdktn.IResolvable): any;
export declare function codecommitRepositoryTriggersToHclTerraform(struct?: CodecommitRepositoryTriggers | cdktn.IResolvable): any;
export declare class CodecommitRepositoryTriggersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodecommitRepositoryTriggers | cdktn.IResolvable | undefined;
    set internalValue(value: CodecommitRepositoryTriggers | cdktn.IResolvable | undefined);
    private _branches?;
    get branches(): string[];
    set branches(value: string[]);
    resetBranches(): void;
    get branchesInput(): string[] | undefined;
    private _customData?;
    get customData(): string;
    set customData(value: string);
    resetCustomData(): void;
    get customDataInput(): string | undefined;
    private _destinationArn?;
    get destinationArn(): string;
    set destinationArn(value: string);
    resetDestinationArn(): void;
    get destinationArnInput(): string | undefined;
    private _events?;
    get events(): string[];
    set events(value: string[]);
    resetEvents(): void;
    get eventsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CodecommitRepositoryTriggersList extends cdktn.ComplexList {
    internalValue?: CodecommitRepositoryTriggers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodecommitRepositoryTriggersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository awscc_codecommit_repository}
*/
export declare class CodecommitRepository extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codecommit_repository";
    /**
    * Generates CDKTN code for importing a CodecommitRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodecommitRepository to import
    * @param importFromId The id of the existing CodecommitRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodecommitRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/codecommit_repository awscc_codecommit_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodecommitRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: CodecommitRepositoryConfig);
    get arn(): string;
    get cloneUrlHttp(): string;
    get cloneUrlSsh(): string;
    private _code;
    get code(): CodecommitRepositoryCodeOutputReference;
    putCode(value: CodecommitRepositoryCode): void;
    resetCode(): void;
    get codeInput(): cdktn.IResolvable | CodecommitRepositoryCode | undefined;
    get id(): string;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get name(): string;
    private _repositoryDescription?;
    get repositoryDescription(): string;
    set repositoryDescription(value: string);
    resetRepositoryDescription(): void;
    get repositoryDescriptionInput(): string | undefined;
    get repositoryId(): string;
    private _repositoryName?;
    get repositoryName(): string;
    set repositoryName(value: string);
    get repositoryNameInput(): string | undefined;
    private _tags;
    get tags(): CodecommitRepositoryTagsList;
    putTags(value: CodecommitRepositoryTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodecommitRepositoryTags[] | undefined;
    private _triggers;
    get triggers(): CodecommitRepositoryTriggersList;
    putTriggers(value: CodecommitRepositoryTriggers[] | cdktn.IResolvable): void;
    resetTriggers(): void;
    get triggersInput(): cdktn.IResolvable | CodecommitRepositoryTriggers[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
