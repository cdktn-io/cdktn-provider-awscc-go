/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationPublicTypeVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Number (ARN) of the extension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_public_type_version#arn CloudformationPublicTypeVersion#arn}
    */
    readonly arn?: string;
    /**
    * A url to the S3 bucket where logs for the testType run will be available
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_public_type_version#log_delivery_bucket CloudformationPublicTypeVersion#log_delivery_bucket}
    */
    readonly logDeliveryBucket?: string;
    /**
    * The version number of a public third-party extension
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_public_type_version#public_version_number CloudformationPublicTypeVersion#public_version_number}
    */
    readonly publicVersionNumber?: string;
    /**
    * The kind of extension
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_public_type_version#type CloudformationPublicTypeVersion#type}
    */
    readonly type?: string;
    /**
    * The name of the type being registered.
    *
    * We recommend that type names adhere to the following pattern: company_or_organization::service::type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_public_type_version#type_name CloudformationPublicTypeVersion#type_name}
    */
    readonly typeName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_public_type_version awscc_cloudformation_public_type_version}
*/
export declare class CloudformationPublicTypeVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_public_type_version";
    /**
    * Generates CDKTN code for importing a CloudformationPublicTypeVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationPublicTypeVersion to import
    * @param importFromId The id of the existing CloudformationPublicTypeVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_public_type_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationPublicTypeVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudformation_public_type_version awscc_cloudformation_public_type_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationPublicTypeVersionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudformationPublicTypeVersionConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get id(): string;
    private _logDeliveryBucket?;
    get logDeliveryBucket(): string;
    set logDeliveryBucket(value: string);
    resetLogDeliveryBucket(): void;
    get logDeliveryBucketInput(): string | undefined;
    get publicTypeArn(): string;
    private _publicVersionNumber?;
    get publicVersionNumber(): string;
    set publicVersionNumber(value: string);
    resetPublicVersionNumber(): void;
    get publicVersionNumberInput(): string | undefined;
    get publisherId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    resetTypeName(): void;
    get typeNameInput(): string | undefined;
    get typeVersionArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
