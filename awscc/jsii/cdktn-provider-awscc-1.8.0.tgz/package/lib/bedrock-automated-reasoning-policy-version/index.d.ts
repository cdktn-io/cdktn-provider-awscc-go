/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockAutomatedReasoningPolicyVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The hash for this version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_automated_reasoning_policy_version#last_updated_definition_hash BedrockAutomatedReasoningPolicyVersion#last_updated_definition_hash}
    */
    readonly lastUpdatedDefinitionHash?: string;
    /**
    * Arn of the policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_automated_reasoning_policy_version#policy_arn BedrockAutomatedReasoningPolicyVersion#policy_arn}
    */
    readonly policyArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_automated_reasoning_policy_version#tags BedrockAutomatedReasoningPolicyVersion#tags}
    */
    readonly tags?: BedrockAutomatedReasoningPolicyVersionTags[] | cdktn.IResolvable;
}
export interface BedrockAutomatedReasoningPolicyVersionTags {
    /**
    * Tag Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_automated_reasoning_policy_version#key BedrockAutomatedReasoningPolicyVersion#key}
    */
    readonly key?: string;
    /**
    * Tag Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_automated_reasoning_policy_version#value BedrockAutomatedReasoningPolicyVersion#value}
    */
    readonly value?: string;
}
export declare function bedrockAutomatedReasoningPolicyVersionTagsToTerraform(struct?: BedrockAutomatedReasoningPolicyVersionTags | cdktn.IResolvable): any;
export declare function bedrockAutomatedReasoningPolicyVersionTagsToHclTerraform(struct?: BedrockAutomatedReasoningPolicyVersionTags | cdktn.IResolvable): any;
export declare class BedrockAutomatedReasoningPolicyVersionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAutomatedReasoningPolicyVersionTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAutomatedReasoningPolicyVersionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockAutomatedReasoningPolicyVersionTagsList extends cdktn.ComplexList {
    internalValue?: BedrockAutomatedReasoningPolicyVersionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAutomatedReasoningPolicyVersionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_automated_reasoning_policy_version awscc_bedrock_automated_reasoning_policy_version}
*/
export declare class BedrockAutomatedReasoningPolicyVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_automated_reasoning_policy_version";
    /**
    * Generates CDKTN code for importing a BedrockAutomatedReasoningPolicyVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockAutomatedReasoningPolicyVersion to import
    * @param importFromId The id of the existing BedrockAutomatedReasoningPolicyVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_automated_reasoning_policy_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockAutomatedReasoningPolicyVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrock_automated_reasoning_policy_version awscc_bedrock_automated_reasoning_policy_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockAutomatedReasoningPolicyVersionConfig
    */
    constructor(scope: Construct, id: string, config: BedrockAutomatedReasoningPolicyVersionConfig);
    get createdAt(): string;
    get definitionHash(): string;
    get description(): string;
    get id(): string;
    private _lastUpdatedDefinitionHash?;
    get lastUpdatedDefinitionHash(): string;
    set lastUpdatedDefinitionHash(value: string);
    resetLastUpdatedDefinitionHash(): void;
    get lastUpdatedDefinitionHashInput(): string | undefined;
    get name(): string;
    private _policyArn?;
    get policyArn(): string;
    set policyArn(value: string);
    get policyArnInput(): string | undefined;
    get policyId(): string;
    private _tags;
    get tags(): BedrockAutomatedReasoningPolicyVersionTagsList;
    putTags(value: BedrockAutomatedReasoningPolicyVersionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockAutomatedReasoningPolicyVersionTags[] | undefined;
    get updatedAt(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
