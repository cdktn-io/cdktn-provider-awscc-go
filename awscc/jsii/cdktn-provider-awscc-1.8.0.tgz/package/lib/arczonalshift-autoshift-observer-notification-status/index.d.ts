/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArczonalshiftAutoshiftObserverNotificationStatusConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_autoshift_observer_notification_status#status ArczonalshiftAutoshiftObserverNotificationStatus#status}
    */
    readonly status: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_autoshift_observer_notification_status awscc_arczonalshift_autoshift_observer_notification_status}
*/
export declare class ArczonalshiftAutoshiftObserverNotificationStatus extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_arczonalshift_autoshift_observer_notification_status";
    /**
    * Generates CDKTN code for importing a ArczonalshiftAutoshiftObserverNotificationStatus resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArczonalshiftAutoshiftObserverNotificationStatus to import
    * @param importFromId The id of the existing ArczonalshiftAutoshiftObserverNotificationStatus that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_autoshift_observer_notification_status#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArczonalshiftAutoshiftObserverNotificationStatus to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_autoshift_observer_notification_status awscc_arczonalshift_autoshift_observer_notification_status} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArczonalshiftAutoshiftObserverNotificationStatusConfig
    */
    constructor(scope: Construct, id: string, config: ArczonalshiftAutoshiftObserverNotificationStatusConfig);
    get accountId(): string;
    get id(): string;
    get region(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
