/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2RouteResponseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_route_response#id DataAwsccApigatewayv2RouteResponse#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2RouteResponseResponseParameters {
}
export declare function dataAwsccApigatewayv2RouteResponseResponseParametersToTerraform(struct?: DataAwsccApigatewayv2RouteResponseResponseParameters): any;
export declare function dataAwsccApigatewayv2RouteResponseResponseParametersToHclTerraform(struct?: DataAwsccApigatewayv2RouteResponseResponseParameters): any;
export declare class DataAwsccApigatewayv2RouteResponseResponseParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataAwsccApigatewayv2RouteResponseResponseParameters | undefined;
    set internalValue(value: DataAwsccApigatewayv2RouteResponseResponseParameters | undefined);
    get required(): cdktn.IResolvable;
}
export declare class DataAwsccApigatewayv2RouteResponseResponseParametersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataAwsccApigatewayv2RouteResponseResponseParametersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_route_response awscc_apigatewayv2_route_response}
*/
export declare class DataAwsccApigatewayv2RouteResponse extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_route_response";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2RouteResponse resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2RouteResponse to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2RouteResponse that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_route_response#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2RouteResponse to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/apigatewayv2_route_response awscc_apigatewayv2_route_response} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2RouteResponseConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2RouteResponseConfig);
    get apiId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get modelSelectionExpression(): string;
    get responseModels(): string;
    private _responseParameters;
    get responseParameters(): DataAwsccApigatewayv2RouteResponseResponseParametersMap;
    get routeId(): string;
    get routeResponseId(): string;
    get routeResponseKey(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
