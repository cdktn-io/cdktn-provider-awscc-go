/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BatchJobDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#consumable_resource_properties BatchJobDefinition#consumable_resource_properties}
    */
    readonly consumableResourceProperties?: BatchJobDefinitionConsumableResourceProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_properties BatchJobDefinition#container_properties}
    */
    readonly containerProperties?: BatchJobDefinitionContainerProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ecs_properties BatchJobDefinition#ecs_properties}
    */
    readonly ecsProperties?: BatchJobDefinitionEcsProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#eks_properties BatchJobDefinition#eks_properties}
    */
    readonly eksProperties?: BatchJobDefinitionEksProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#job_definition_name BatchJobDefinition#job_definition_name}
    */
    readonly jobDefinitionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#node_properties BatchJobDefinition#node_properties}
    */
    readonly nodeProperties?: BatchJobDefinitionNodeProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#parameters BatchJobDefinition#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#platform_capabilities BatchJobDefinition#platform_capabilities}
    */
    readonly platformCapabilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#propagate_tags BatchJobDefinition#propagate_tags}
    */
    readonly propagateTags?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resource_retention_policy BatchJobDefinition#resource_retention_policy}
    */
    readonly resourceRetentionPolicy?: BatchJobDefinitionResourceRetentionPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#retry_strategy BatchJobDefinition#retry_strategy}
    */
    readonly retryStrategy?: BatchJobDefinitionRetryStrategy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#scheduling_priority BatchJobDefinition#scheduling_priority}
    */
    readonly schedulingPriority?: number;
    /**
    * A key-value pair to associate with a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#tags BatchJobDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#timeout BatchJobDefinition#timeout}
    */
    readonly timeout?: BatchJobDefinitionTimeout;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#type BatchJobDefinition#type}
    */
    readonly type: string;
}
export interface BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct {
    /**
    * The ARN of the consumable resource the job definition should consume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#consumable_resource BatchJobDefinition#consumable_resource}
    */
    readonly consumableResource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#quantity BatchJobDefinition#quantity}
    */
    readonly quantity?: number;
}
export declare function batchJobDefinitionConsumableResourcePropertiesConsumableResourceListStructToTerraform(struct?: BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct | cdktn.IResolvable): any;
export declare function batchJobDefinitionConsumableResourcePropertiesConsumableResourceListStructToHclTerraform(struct?: BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct | cdktn.IResolvable): any;
export declare class BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct | cdktn.IResolvable | undefined);
    private _consumableResource?;
    get consumableResource(): string;
    set consumableResource(value: string);
    resetConsumableResource(): void;
    get consumableResourceInput(): string | undefined;
    private _quantity?;
    get quantity(): number;
    set quantity(value: number);
    resetQuantity(): void;
    get quantityInput(): number | undefined;
}
export declare class BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStructList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStructOutputReference;
}
export interface BatchJobDefinitionConsumableResourceProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#consumable_resource_list BatchJobDefinition#consumable_resource_list}
    */
    readonly consumableResourceList?: BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionConsumableResourcePropertiesToTerraform(struct?: BatchJobDefinitionConsumableResourceProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionConsumableResourcePropertiesToHclTerraform(struct?: BatchJobDefinitionConsumableResourceProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionConsumableResourcePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionConsumableResourceProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionConsumableResourceProperties | cdktn.IResolvable | undefined);
    private _consumableResourceList;
    get consumableResourceList(): BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStructList;
    putConsumableResourceList(value: BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct[] | cdktn.IResolvable): void;
    resetConsumableResourceList(): void;
    get consumableResourceListInput(): cdktn.IResolvable | BatchJobDefinitionConsumableResourcePropertiesConsumableResourceListStruct[] | undefined;
}
export interface BatchJobDefinitionContainerPropertiesEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionContainerPropertiesEnvironmentToTerraform(struct?: BatchJobDefinitionContainerPropertiesEnvironment | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesEnvironmentToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesEnvironment | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesEnvironment | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesEnvironmentList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesEnvironmentOutputReference;
}
export interface BatchJobDefinitionContainerPropertiesEphemeralStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size_in_gi_b BatchJobDefinition#size_in_gi_b}
    */
    readonly sizeInGiB?: number;
}
export declare function batchJobDefinitionContainerPropertiesEphemeralStorageToTerraform(struct?: BatchJobDefinitionContainerPropertiesEphemeralStorage | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesEphemeralStorageToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesEphemeralStorage | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesEphemeralStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesEphemeralStorage | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesEphemeralStorage | cdktn.IResolvable | undefined);
    private _sizeInGiB?;
    get sizeInGiB(): number;
    set sizeInGiB(value: number);
    resetSizeInGiB(): void;
    get sizeInGiBInput(): number | undefined;
}
export interface BatchJobDefinitionContainerPropertiesFargatePlatformConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#platform_version BatchJobDefinition#platform_version}
    */
    readonly platformVersion?: string;
}
export declare function batchJobDefinitionContainerPropertiesFargatePlatformConfigurationToTerraform(struct?: BatchJobDefinitionContainerPropertiesFargatePlatformConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesFargatePlatformConfigurationToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesFargatePlatformConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesFargatePlatformConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesFargatePlatformConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesFargatePlatformConfiguration | cdktn.IResolvable | undefined);
    private _platformVersion?;
    get platformVersion(): string;
    set platformVersion(value: string);
    resetPlatformVersion(): void;
    get platformVersionInput(): string | undefined;
}
export interface BatchJobDefinitionContainerPropertiesLinuxParametersDevices {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host_path BatchJobDefinition#host_path}
    */
    readonly hostPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#permissions BatchJobDefinition#permissions}
    */
    readonly permissions?: string[];
}
export declare function batchJobDefinitionContainerPropertiesLinuxParametersDevicesToTerraform(struct?: BatchJobDefinitionContainerPropertiesLinuxParametersDevices | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesLinuxParametersDevicesToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesLinuxParametersDevices | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesLinuxParametersDevicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesLinuxParametersDevices | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesLinuxParametersDevices | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _hostPath?;
    get hostPath(): string;
    set hostPath(value: string);
    resetHostPath(): void;
    get hostPathInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    resetPermissions(): void;
    get permissionsInput(): string[] | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesLinuxParametersDevicesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesLinuxParametersDevices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesLinuxParametersDevicesOutputReference;
}
export interface BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_options BatchJobDefinition#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size BatchJobDefinition#size}
    */
    readonly size?: number;
}
export declare function batchJobDefinitionContainerPropertiesLinuxParametersTmpfsToTerraform(struct?: BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesLinuxParametersTmpfsToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesLinuxParametersTmpfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesLinuxParametersTmpfsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesLinuxParametersTmpfsOutputReference;
}
export interface BatchJobDefinitionContainerPropertiesLinuxParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#devices BatchJobDefinition#devices}
    */
    readonly devices?: BatchJobDefinitionContainerPropertiesLinuxParametersDevices[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#init_process_enabled BatchJobDefinition#init_process_enabled}
    */
    readonly initProcessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#max_swap BatchJobDefinition#max_swap}
    */
    readonly maxSwap?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#shared_memory_size BatchJobDefinition#shared_memory_size}
    */
    readonly sharedMemorySize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#swappiness BatchJobDefinition#swappiness}
    */
    readonly swappiness?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#tmpfs BatchJobDefinition#tmpfs}
    */
    readonly tmpfs?: BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionContainerPropertiesLinuxParametersToTerraform(struct?: BatchJobDefinitionContainerPropertiesLinuxParameters | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesLinuxParametersToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesLinuxParameters | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesLinuxParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesLinuxParameters | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesLinuxParameters | cdktn.IResolvable | undefined);
    private _devices;
    get devices(): BatchJobDefinitionContainerPropertiesLinuxParametersDevicesList;
    putDevices(value: BatchJobDefinitionContainerPropertiesLinuxParametersDevices[] | cdktn.IResolvable): void;
    resetDevices(): void;
    get devicesInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesLinuxParametersDevices[] | undefined;
    private _initProcessEnabled?;
    get initProcessEnabled(): boolean | cdktn.IResolvable;
    set initProcessEnabled(value: boolean | cdktn.IResolvable);
    resetInitProcessEnabled(): void;
    get initProcessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _maxSwap?;
    get maxSwap(): number;
    set maxSwap(value: number);
    resetMaxSwap(): void;
    get maxSwapInput(): number | undefined;
    private _sharedMemorySize?;
    get sharedMemorySize(): number;
    set sharedMemorySize(value: number);
    resetSharedMemorySize(): void;
    get sharedMemorySizeInput(): number | undefined;
    private _swappiness?;
    get swappiness(): number;
    set swappiness(value: number);
    resetSwappiness(): void;
    get swappinessInput(): number | undefined;
    private _tmpfs;
    get tmpfs(): BatchJobDefinitionContainerPropertiesLinuxParametersTmpfsList;
    putTmpfs(value: BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs[] | cdktn.IResolvable): void;
    resetTmpfs(): void;
    get tmpfsInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesLinuxParametersTmpfs[] | undefined;
}
export interface BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value_from BatchJobDefinition#value_from}
    */
    readonly valueFrom?: string;
}
export declare function batchJobDefinitionContainerPropertiesLogConfigurationSecretOptionsToTerraform(struct?: BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesLogConfigurationSecretOptionsToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptionsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptionsOutputReference;
}
export interface BatchJobDefinitionContainerPropertiesLogConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#log_driver BatchJobDefinition#log_driver}
    */
    readonly logDriver?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#options BatchJobDefinition#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secret_options BatchJobDefinition#secret_options}
    */
    readonly secretOptions?: BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionContainerPropertiesLogConfigurationToTerraform(struct?: BatchJobDefinitionContainerPropertiesLogConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesLogConfigurationToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesLogConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesLogConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesLogConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesLogConfiguration | cdktn.IResolvable | undefined);
    private _logDriver?;
    get logDriver(): string;
    set logDriver(value: string);
    resetLogDriver(): void;
    get logDriverInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _secretOptions;
    get secretOptions(): BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptionsList;
    putSecretOptions(value: BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions[] | cdktn.IResolvable): void;
    resetSecretOptions(): void;
    get secretOptionsInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesLogConfigurationSecretOptions[] | undefined;
}
export interface BatchJobDefinitionContainerPropertiesMountPoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#source_volume BatchJobDefinition#source_volume}
    */
    readonly sourceVolume?: string;
}
export declare function batchJobDefinitionContainerPropertiesMountPointsToTerraform(struct?: BatchJobDefinitionContainerPropertiesMountPoints | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesMountPointsToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesMountPoints | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesMountPointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesMountPoints | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesMountPoints | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceVolume?;
    get sourceVolume(): string;
    set sourceVolume(value: string);
    resetSourceVolume(): void;
    get sourceVolumeInput(): string | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesMountPointsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesMountPoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesMountPointsOutputReference;
}
export interface BatchJobDefinitionContainerPropertiesNetworkConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#assign_public_ip BatchJobDefinition#assign_public_ip}
    */
    readonly assignPublicIp?: string;
}
export declare function batchJobDefinitionContainerPropertiesNetworkConfigurationToTerraform(struct?: BatchJobDefinitionContainerPropertiesNetworkConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesNetworkConfigurationToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesNetworkConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesNetworkConfiguration | cdktn.IResolvable | undefined);
    private _assignPublicIp?;
    get assignPublicIp(): string;
    set assignPublicIp(value: string);
    resetAssignPublicIp(): void;
    get assignPublicIpInput(): string | undefined;
}
export interface BatchJobDefinitionContainerPropertiesRepositoryCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#credentials_parameter BatchJobDefinition#credentials_parameter}
    */
    readonly credentialsParameter?: string;
}
export declare function batchJobDefinitionContainerPropertiesRepositoryCredentialsToTerraform(struct?: BatchJobDefinitionContainerPropertiesRepositoryCredentials | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesRepositoryCredentialsToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesRepositoryCredentials | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesRepositoryCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesRepositoryCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesRepositoryCredentials | cdktn.IResolvable | undefined);
    private _credentialsParameter?;
    get credentialsParameter(): string;
    set credentialsParameter(value: string);
    resetCredentialsParameter(): void;
    get credentialsParameterInput(): string | undefined;
}
export interface BatchJobDefinitionContainerPropertiesResourceRequirements {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#type BatchJobDefinition#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionContainerPropertiesResourceRequirementsToTerraform(struct?: BatchJobDefinitionContainerPropertiesResourceRequirements | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesResourceRequirementsToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesResourceRequirements | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesResourceRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesResourceRequirements | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesResourceRequirements | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesResourceRequirementsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesResourceRequirements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesResourceRequirementsOutputReference;
}
export interface BatchJobDefinitionContainerPropertiesRuntimePlatform {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#cpu_architecture BatchJobDefinition#cpu_architecture}
    */
    readonly cpuArchitecture?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#operating_system_family BatchJobDefinition#operating_system_family}
    */
    readonly operatingSystemFamily?: string;
}
export declare function batchJobDefinitionContainerPropertiesRuntimePlatformToTerraform(struct?: BatchJobDefinitionContainerPropertiesRuntimePlatform | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesRuntimePlatformToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesRuntimePlatform | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesRuntimePlatformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesRuntimePlatform | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesRuntimePlatform | cdktn.IResolvable | undefined);
    private _cpuArchitecture?;
    get cpuArchitecture(): string;
    set cpuArchitecture(value: string);
    resetCpuArchitecture(): void;
    get cpuArchitectureInput(): string | undefined;
    private _operatingSystemFamily?;
    get operatingSystemFamily(): string;
    set operatingSystemFamily(value: string);
    resetOperatingSystemFamily(): void;
    get operatingSystemFamilyInput(): string | undefined;
}
export interface BatchJobDefinitionContainerPropertiesSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value_from BatchJobDefinition#value_from}
    */
    readonly valueFrom?: string;
}
export declare function batchJobDefinitionContainerPropertiesSecretsToTerraform(struct?: BatchJobDefinitionContainerPropertiesSecrets | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesSecretsToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesSecrets | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesSecrets | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesSecrets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesSecretsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesSecretsOutputReference;
}
export interface BatchJobDefinitionContainerPropertiesUlimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#hard_limit BatchJobDefinition#hard_limit}
    */
    readonly hardLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#soft_limit BatchJobDefinition#soft_limit}
    */
    readonly softLimit?: number;
}
export declare function batchJobDefinitionContainerPropertiesUlimitsToTerraform(struct?: BatchJobDefinitionContainerPropertiesUlimits | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesUlimitsToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesUlimits | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesUlimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesUlimits | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesUlimits | cdktn.IResolvable | undefined);
    private _hardLimit?;
    get hardLimit(): number;
    set hardLimit(value: number);
    resetHardLimit(): void;
    get hardLimitInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _softLimit?;
    get softLimit(): number;
    set softLimit(value: number);
    resetSoftLimit(): void;
    get softLimitInput(): number | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesUlimitsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesUlimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesUlimitsOutputReference;
}
export interface BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#access_point_id BatchJobDefinition#access_point_id}
    */
    readonly accessPointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#iam BatchJobDefinition#iam}
    */
    readonly iam?: string;
}
export declare function batchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigToTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable | undefined);
    private _accessPointId?;
    get accessPointId(): string;
    set accessPointId(value: string);
    resetAccessPointId(): void;
    get accessPointIdInput(): string | undefined;
    private _iam?;
    get iam(): string;
    set iam(value: string);
    resetIam(): void;
    get iamInput(): string | undefined;
}
export interface BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#authorization_config BatchJobDefinition#authorization_config}
    */
    readonly authorizationConfig?: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#file_system_id BatchJobDefinition#file_system_id}
    */
    readonly fileSystemId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#root_directory BatchJobDefinition#root_directory}
    */
    readonly rootDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption BatchJobDefinition#transit_encryption}
    */
    readonly transitEncryption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption_port BatchJobDefinition#transit_encryption_port}
    */
    readonly transitEncryptionPort?: number;
}
export declare function batchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationToTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable | undefined);
    private _authorizationConfig;
    get authorizationConfig(): BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigOutputReference;
    putAuthorizationConfig(value: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig): void;
    resetAuthorizationConfig(): void;
    get authorizationConfigInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | undefined;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    resetFileSystemId(): void;
    get fileSystemIdInput(): string | undefined;
    private _rootDirectory?;
    get rootDirectory(): string;
    set rootDirectory(value: string);
    resetRootDirectory(): void;
    get rootDirectoryInput(): string | undefined;
    private _transitEncryption?;
    get transitEncryption(): string;
    set transitEncryption(value: string);
    resetTransitEncryption(): void;
    get transitEncryptionInput(): string | undefined;
    private _transitEncryptionPort?;
    get transitEncryptionPort(): number;
    set transitEncryptionPort(value: number);
    resetTransitEncryptionPort(): void;
    get transitEncryptionPortInput(): number | undefined;
}
export interface BatchJobDefinitionContainerPropertiesVolumesHost {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#source_path BatchJobDefinition#source_path}
    */
    readonly sourcePath?: string;
}
export declare function batchJobDefinitionContainerPropertiesVolumesHostToTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumesHost | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesVolumesHostToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumesHost | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesVolumesHostOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesVolumesHost | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesVolumesHost | cdktn.IResolvable | undefined);
    private _sourcePath?;
    get sourcePath(): string;
    set sourcePath(value: string);
    resetSourcePath(): void;
    get sourcePathInput(): string | undefined;
}
export interface BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#access_point_arn BatchJobDefinition#access_point_arn}
    */
    readonly accessPointArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#file_system_arn BatchJobDefinition#file_system_arn}
    */
    readonly fileSystemArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#root_directory BatchJobDefinition#root_directory}
    */
    readonly rootDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption_port BatchJobDefinition#transit_encryption_port}
    */
    readonly transitEncryptionPort?: number;
}
export declare function batchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfigurationToTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfigurationToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable | undefined);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    resetAccessPointArn(): void;
    get accessPointArnInput(): string | undefined;
    private _fileSystemArn?;
    get fileSystemArn(): string;
    set fileSystemArn(value: string);
    resetFileSystemArn(): void;
    get fileSystemArnInput(): string | undefined;
    private _rootDirectory?;
    get rootDirectory(): string;
    set rootDirectory(value: string);
    resetRootDirectory(): void;
    get rootDirectoryInput(): string | undefined;
    private _transitEncryptionPort?;
    get transitEncryptionPort(): number;
    set transitEncryptionPort(value: number);
    resetTransitEncryptionPort(): void;
    get transitEncryptionPortInput(): number | undefined;
}
export interface BatchJobDefinitionContainerPropertiesVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#efs_volume_configuration BatchJobDefinition#efs_volume_configuration}
    */
    readonly efsVolumeConfiguration?: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host BatchJobDefinition#host}
    */
    readonly host?: BatchJobDefinitionContainerPropertiesVolumesHost;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#s3_files_volume_configuration BatchJobDefinition#s3_files_volume_configuration}
    */
    readonly s3FilesVolumeConfiguration?: BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfiguration;
}
export declare function batchJobDefinitionContainerPropertiesVolumesToTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumes | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesVolumesToHclTerraform(struct?: BatchJobDefinitionContainerPropertiesVolumes | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionContainerPropertiesVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerPropertiesVolumes | cdktn.IResolvable | undefined);
    private _efsVolumeConfiguration;
    get efsVolumeConfiguration(): BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfigurationOutputReference;
    putEfsVolumeConfiguration(value: BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfiguration): void;
    resetEfsVolumeConfiguration(): void;
    get efsVolumeConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesVolumesEfsVolumeConfiguration | undefined;
    private _host;
    get host(): BatchJobDefinitionContainerPropertiesVolumesHostOutputReference;
    putHost(value: BatchJobDefinitionContainerPropertiesVolumesHost): void;
    resetHost(): void;
    get hostInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesVolumesHost | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _s3FilesVolumeConfiguration;
    get s3FilesVolumeConfiguration(): BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfigurationOutputReference;
    putS3FilesVolumeConfiguration(value: BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfiguration): void;
    resetS3FilesVolumeConfiguration(): void;
    get s3FilesVolumeConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesVolumesS3FilesVolumeConfiguration | undefined;
}
export declare class BatchJobDefinitionContainerPropertiesVolumesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionContainerPropertiesVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionContainerPropertiesVolumesOutputReference;
}
export interface BatchJobDefinitionContainerProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#command BatchJobDefinition#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#enable_execute_command BatchJobDefinition#enable_execute_command}
    */
    readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#environment BatchJobDefinition#environment}
    */
    readonly environment?: BatchJobDefinitionContainerPropertiesEnvironment[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ephemeral_storage BatchJobDefinition#ephemeral_storage}
    */
    readonly ephemeralStorage?: BatchJobDefinitionContainerPropertiesEphemeralStorage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#execution_role_arn BatchJobDefinition#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#fargate_platform_configuration BatchJobDefinition#fargate_platform_configuration}
    */
    readonly fargatePlatformConfiguration?: BatchJobDefinitionContainerPropertiesFargatePlatformConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image BatchJobDefinition#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#job_role_arn BatchJobDefinition#job_role_arn}
    */
    readonly jobRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#linux_parameters BatchJobDefinition#linux_parameters}
    */
    readonly linuxParameters?: BatchJobDefinitionContainerPropertiesLinuxParameters;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#log_configuration BatchJobDefinition#log_configuration}
    */
    readonly logConfiguration?: BatchJobDefinitionContainerPropertiesLogConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#memory BatchJobDefinition#memory}
    */
    readonly memory?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_points BatchJobDefinition#mount_points}
    */
    readonly mountPoints?: BatchJobDefinitionContainerPropertiesMountPoints[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#network_configuration BatchJobDefinition#network_configuration}
    */
    readonly networkConfiguration?: BatchJobDefinitionContainerPropertiesNetworkConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#privileged BatchJobDefinition#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#readonly_root_filesystem BatchJobDefinition#readonly_root_filesystem}
    */
    readonly readonlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#repository_credentials BatchJobDefinition#repository_credentials}
    */
    readonly repositoryCredentials?: BatchJobDefinitionContainerPropertiesRepositoryCredentials;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resource_requirements BatchJobDefinition#resource_requirements}
    */
    readonly resourceRequirements?: BatchJobDefinitionContainerPropertiesResourceRequirements[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#runtime_platform BatchJobDefinition#runtime_platform}
    */
    readonly runtimePlatform?: BatchJobDefinitionContainerPropertiesRuntimePlatform;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secrets BatchJobDefinition#secrets}
    */
    readonly secrets?: BatchJobDefinitionContainerPropertiesSecrets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ulimits BatchJobDefinition#ulimits}
    */
    readonly ulimits?: BatchJobDefinitionContainerPropertiesUlimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#user BatchJobDefinition#user}
    */
    readonly user?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#vcpus BatchJobDefinition#vcpus}
    */
    readonly vcpus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volumes BatchJobDefinition#volumes}
    */
    readonly volumes?: BatchJobDefinitionContainerPropertiesVolumes[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionContainerPropertiesToTerraform(struct?: BatchJobDefinitionContainerProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionContainerPropertiesToHclTerraform(struct?: BatchJobDefinitionContainerProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionContainerPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionContainerProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionContainerProperties | cdktn.IResolvable | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _enableExecuteCommand?;
    get enableExecuteCommand(): boolean | cdktn.IResolvable;
    set enableExecuteCommand(value: boolean | cdktn.IResolvable);
    resetEnableExecuteCommand(): void;
    get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
    private _environment;
    get environment(): BatchJobDefinitionContainerPropertiesEnvironmentList;
    putEnvironment(value: BatchJobDefinitionContainerPropertiesEnvironment[] | cdktn.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesEnvironment[] | undefined;
    private _ephemeralStorage;
    get ephemeralStorage(): BatchJobDefinitionContainerPropertiesEphemeralStorageOutputReference;
    putEphemeralStorage(value: BatchJobDefinitionContainerPropertiesEphemeralStorage): void;
    resetEphemeralStorage(): void;
    get ephemeralStorageInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesEphemeralStorage | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _fargatePlatformConfiguration;
    get fargatePlatformConfiguration(): BatchJobDefinitionContainerPropertiesFargatePlatformConfigurationOutputReference;
    putFargatePlatformConfiguration(value: BatchJobDefinitionContainerPropertiesFargatePlatformConfiguration): void;
    resetFargatePlatformConfiguration(): void;
    get fargatePlatformConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesFargatePlatformConfiguration | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _jobRoleArn?;
    get jobRoleArn(): string;
    set jobRoleArn(value: string);
    resetJobRoleArn(): void;
    get jobRoleArnInput(): string | undefined;
    private _linuxParameters;
    get linuxParameters(): BatchJobDefinitionContainerPropertiesLinuxParametersOutputReference;
    putLinuxParameters(value: BatchJobDefinitionContainerPropertiesLinuxParameters): void;
    resetLinuxParameters(): void;
    get linuxParametersInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesLinuxParameters | undefined;
    private _logConfiguration;
    get logConfiguration(): BatchJobDefinitionContainerPropertiesLogConfigurationOutputReference;
    putLogConfiguration(value: BatchJobDefinitionContainerPropertiesLogConfiguration): void;
    resetLogConfiguration(): void;
    get logConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesLogConfiguration | undefined;
    private _memory?;
    get memory(): number;
    set memory(value: number);
    resetMemory(): void;
    get memoryInput(): number | undefined;
    private _mountPoints;
    get mountPoints(): BatchJobDefinitionContainerPropertiesMountPointsList;
    putMountPoints(value: BatchJobDefinitionContainerPropertiesMountPoints[] | cdktn.IResolvable): void;
    resetMountPoints(): void;
    get mountPointsInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesMountPoints[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BatchJobDefinitionContainerPropertiesNetworkConfigurationOutputReference;
    putNetworkConfiguration(value: BatchJobDefinitionContainerPropertiesNetworkConfiguration): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesNetworkConfiguration | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readonlyRootFilesystem?;
    get readonlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readonlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadonlyRootFilesystem(): void;
    get readonlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _repositoryCredentials;
    get repositoryCredentials(): BatchJobDefinitionContainerPropertiesRepositoryCredentialsOutputReference;
    putRepositoryCredentials(value: BatchJobDefinitionContainerPropertiesRepositoryCredentials): void;
    resetRepositoryCredentials(): void;
    get repositoryCredentialsInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesRepositoryCredentials | undefined;
    private _resourceRequirements;
    get resourceRequirements(): BatchJobDefinitionContainerPropertiesResourceRequirementsList;
    putResourceRequirements(value: BatchJobDefinitionContainerPropertiesResourceRequirements[] | cdktn.IResolvable): void;
    resetResourceRequirements(): void;
    get resourceRequirementsInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesResourceRequirements[] | undefined;
    private _runtimePlatform;
    get runtimePlatform(): BatchJobDefinitionContainerPropertiesRuntimePlatformOutputReference;
    putRuntimePlatform(value: BatchJobDefinitionContainerPropertiesRuntimePlatform): void;
    resetRuntimePlatform(): void;
    get runtimePlatformInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesRuntimePlatform | undefined;
    private _secrets;
    get secrets(): BatchJobDefinitionContainerPropertiesSecretsList;
    putSecrets(value: BatchJobDefinitionContainerPropertiesSecrets[] | cdktn.IResolvable): void;
    resetSecrets(): void;
    get secretsInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesSecrets[] | undefined;
    private _ulimits;
    get ulimits(): BatchJobDefinitionContainerPropertiesUlimitsList;
    putUlimits(value: BatchJobDefinitionContainerPropertiesUlimits[] | cdktn.IResolvable): void;
    resetUlimits(): void;
    get ulimitsInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesUlimits[] | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _vcpus?;
    get vcpus(): number;
    set vcpus(value: number);
    resetVcpus(): void;
    get vcpusInput(): number | undefined;
    private _volumes;
    get volumes(): BatchJobDefinitionContainerPropertiesVolumesList;
    putVolumes(value: BatchJobDefinitionContainerPropertiesVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | BatchJobDefinitionContainerPropertiesVolumes[] | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#condition BatchJobDefinition#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_name BatchJobDefinition#container_name}
    */
    readonly containerName?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOnToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOnToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _containerName?;
    get containerName(): string;
    set containerName(value: string);
    resetContainerName(): void;
    get containerNameInput(): string | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOnList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOnOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironmentToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironmentToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironmentList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironmentOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#options BatchJobDefinition#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#type BatchJobDefinition#type}
    */
    readonly type?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfigurationToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfigurationToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfiguration | cdktn.IResolvable | undefined);
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host_path BatchJobDefinition#host_path}
    */
    readonly hostPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#permissions BatchJobDefinition#permissions}
    */
    readonly permissions?: string[];
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _hostPath?;
    get hostPath(): string;
    set hostPath(value: string);
    resetHostPath(): void;
    get hostPathInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    resetPermissions(): void;
    get permissionsInput(): string[] | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_options BatchJobDefinition#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size BatchJobDefinition#size}
    */
    readonly size?: number;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#devices BatchJobDefinition#devices}
    */
    readonly devices?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#init_process_enabled BatchJobDefinition#init_process_enabled}
    */
    readonly initProcessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#max_swap BatchJobDefinition#max_swap}
    */
    readonly maxSwap?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#shared_memory_size BatchJobDefinition#shared_memory_size}
    */
    readonly sharedMemorySize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#swappiness BatchJobDefinition#swappiness}
    */
    readonly swappiness?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#tmpfs BatchJobDefinition#tmpfs}
    */
    readonly tmpfs?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParameters | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParameters | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParameters | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParameters | cdktn.IResolvable | undefined);
    private _devices;
    get devices(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesList;
    putDevices(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices[] | cdktn.IResolvable): void;
    resetDevices(): void;
    get devicesInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersDevices[] | undefined;
    private _initProcessEnabled?;
    get initProcessEnabled(): boolean | cdktn.IResolvable;
    set initProcessEnabled(value: boolean | cdktn.IResolvable);
    resetInitProcessEnabled(): void;
    get initProcessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _maxSwap?;
    get maxSwap(): number;
    set maxSwap(value: number);
    resetMaxSwap(): void;
    get maxSwapInput(): number | undefined;
    private _sharedMemorySize?;
    get sharedMemorySize(): number;
    set sharedMemorySize(value: number);
    resetSharedMemorySize(): void;
    get sharedMemorySizeInput(): number | undefined;
    private _swappiness?;
    get swappiness(): number;
    set swappiness(value: number);
    resetSwappiness(): void;
    get swappinessInput(): number | undefined;
    private _tmpfs;
    get tmpfs(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsList;
    putTmpfs(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs[] | cdktn.IResolvable): void;
    resetTmpfs(): void;
    get tmpfsInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs[] | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value_from BatchJobDefinition#value_from}
    */
    readonly valueFrom?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#log_driver BatchJobDefinition#log_driver}
    */
    readonly logDriver?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#options BatchJobDefinition#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secret_options BatchJobDefinition#secret_options}
    */
    readonly secretOptions?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfiguration | cdktn.IResolvable | undefined);
    private _logDriver?;
    get logDriver(): string;
    set logDriver(value: string);
    resetLogDriver(): void;
    get logDriverInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _secretOptions;
    get secretOptions(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsList;
    putSecretOptions(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions[] | cdktn.IResolvable): void;
    resetSecretOptions(): void;
    get secretOptionsInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions[] | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#source_volume BatchJobDefinition#source_volume}
    */
    readonly sourceVolume?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPointsToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPointsToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceVolume?;
    get sourceVolume(): string;
    set sourceVolume(value: string);
    resetSourceVolume(): void;
    get sourceVolumeInput(): string | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPointsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPointsOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#credentials_parameter BatchJobDefinition#credentials_parameter}
    */
    readonly credentialsParameter?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentialsToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentials | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentialsToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentials | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentials | cdktn.IResolvable | undefined);
    private _credentialsParameter?;
    get credentialsParameter(): string;
    set credentialsParameter(value: string);
    resetCredentialsParameter(): void;
    get credentialsParameterInput(): string | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#type BatchJobDefinition#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirementsToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirementsToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirementsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirementsOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value_from BatchJobDefinition#value_from}
    */
    readonly valueFrom?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersSecretsToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersSecretsToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecretsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecretsOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#hard_limit BatchJobDefinition#hard_limit}
    */
    readonly hardLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#soft_limit BatchJobDefinition#soft_limit}
    */
    readonly softLimit?: number;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimitsToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimitsToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits | cdktn.IResolvable | undefined);
    private _hardLimit?;
    get hardLimit(): number;
    set hardLimit(value: number);
    resetHardLimit(): void;
    get hardLimitInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _softLimit?;
    get softLimit(): number;
    set softLimit(value: number);
    resetSoftLimit(): void;
    get softLimitInput(): number | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimitsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimitsOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesContainers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#command BatchJobDefinition#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#depends_on BatchJobDefinition#depends_on}
    */
    readonly dependsOn?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#environment BatchJobDefinition#environment}
    */
    readonly environment?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#essential BatchJobDefinition#essential}
    */
    readonly essential?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#firelens_configuration BatchJobDefinition#firelens_configuration}
    */
    readonly firelensConfiguration?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image BatchJobDefinition#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#linux_parameters BatchJobDefinition#linux_parameters}
    */
    readonly linuxParameters?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParameters;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#log_configuration BatchJobDefinition#log_configuration}
    */
    readonly logConfiguration?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_points BatchJobDefinition#mount_points}
    */
    readonly mountPoints?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#privileged BatchJobDefinition#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#readonly_root_filesystem BatchJobDefinition#readonly_root_filesystem}
    */
    readonly readonlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#repository_credentials BatchJobDefinition#repository_credentials}
    */
    readonly repositoryCredentials?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentials;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resource_requirements BatchJobDefinition#resource_requirements}
    */
    readonly resourceRequirements?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secrets BatchJobDefinition#secrets}
    */
    readonly secrets?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#start_timeout BatchJobDefinition#start_timeout}
    */
    readonly startTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#stop_timeout BatchJobDefinition#stop_timeout}
    */
    readonly stopTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ulimits BatchJobDefinition#ulimits}
    */
    readonly ulimits?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#user BatchJobDefinition#user}
    */
    readonly user?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainers | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesContainersToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainers | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainers | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainers | cdktn.IResolvable | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _dependsOn;
    get dependsOn(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOnList;
    putDependsOn(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn[] | cdktn.IResolvable): void;
    resetDependsOn(): void;
    get dependsOnInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersDependsOn[] | undefined;
    private _environment;
    get environment(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironmentList;
    putEnvironment(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment[] | cdktn.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersEnvironment[] | undefined;
    private _essential?;
    get essential(): boolean | cdktn.IResolvable;
    set essential(value: boolean | cdktn.IResolvable);
    resetEssential(): void;
    get essentialInput(): boolean | cdktn.IResolvable | undefined;
    private _firelensConfiguration;
    get firelensConfiguration(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfigurationOutputReference;
    putFirelensConfiguration(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfiguration): void;
    resetFirelensConfiguration(): void;
    get firelensConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersFirelensConfiguration | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _linuxParameters;
    get linuxParameters(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParametersOutputReference;
    putLinuxParameters(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParameters): void;
    resetLinuxParameters(): void;
    get linuxParametersInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLinuxParameters | undefined;
    private _logConfiguration;
    get logConfiguration(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfigurationOutputReference;
    putLogConfiguration(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfiguration): void;
    resetLogConfiguration(): void;
    get logConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersLogConfiguration | undefined;
    private _mountPoints;
    get mountPoints(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPointsList;
    putMountPoints(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints[] | cdktn.IResolvable): void;
    resetMountPoints(): void;
    get mountPointsInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersMountPoints[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readonlyRootFilesystem?;
    get readonlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readonlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadonlyRootFilesystem(): void;
    get readonlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _repositoryCredentials;
    get repositoryCredentials(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentialsOutputReference;
    putRepositoryCredentials(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentials): void;
    resetRepositoryCredentials(): void;
    get repositoryCredentialsInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersRepositoryCredentials | undefined;
    private _resourceRequirements;
    get resourceRequirements(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirementsList;
    putResourceRequirements(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements[] | cdktn.IResolvable): void;
    resetResourceRequirements(): void;
    get resourceRequirementsInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersResourceRequirements[] | undefined;
    private _secrets;
    get secrets(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecretsList;
    putSecrets(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets[] | cdktn.IResolvable): void;
    resetSecrets(): void;
    get secretsInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersSecrets[] | undefined;
    private _startTimeout?;
    get startTimeout(): number;
    set startTimeout(value: number);
    resetStartTimeout(): void;
    get startTimeoutInput(): number | undefined;
    private _stopTimeout?;
    get stopTimeout(): number;
    set stopTimeout(value: number);
    resetStopTimeout(): void;
    get stopTimeoutInput(): number | undefined;
    private _ulimits;
    get ulimits(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimitsList;
    putUlimits(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits[] | cdktn.IResolvable): void;
    resetUlimits(): void;
    get ulimitsInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainersUlimits[] | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesContainersList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size_in_gi_b BatchJobDefinition#size_in_gi_b}
    */
    readonly sizeInGiB?: number;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorageToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorage | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorageToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorage | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorage | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorage | cdktn.IResolvable | undefined);
    private _sizeInGiB?;
    get sizeInGiB(): number;
    set sizeInGiB(value: number);
    resetSizeInGiB(): void;
    get sizeInGiBInput(): number | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#assign_public_ip BatchJobDefinition#assign_public_ip}
    */
    readonly assignPublicIp?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfigurationToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfigurationToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfiguration | cdktn.IResolvable | undefined);
    private _assignPublicIp?;
    get assignPublicIp(): string;
    set assignPublicIp(value: string);
    resetAssignPublicIp(): void;
    get assignPublicIpInput(): string | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatform {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#cpu_architecture BatchJobDefinition#cpu_architecture}
    */
    readonly cpuArchitecture?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#operating_system_family BatchJobDefinition#operating_system_family}
    */
    readonly operatingSystemFamily?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatformToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatform | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatformToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatform | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatform | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatform | cdktn.IResolvable | undefined);
    private _cpuArchitecture?;
    get cpuArchitecture(): string;
    set cpuArchitecture(value: string);
    resetCpuArchitecture(): void;
    get cpuArchitectureInput(): string | undefined;
    private _operatingSystemFamily?;
    get operatingSystemFamily(): string;
    set operatingSystemFamily(value: string);
    resetOperatingSystemFamily(): void;
    get operatingSystemFamilyInput(): string | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#access_point_id BatchJobDefinition#access_point_id}
    */
    readonly accessPointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#iam BatchJobDefinition#iam}
    */
    readonly iam?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable | undefined);
    private _accessPointId?;
    get accessPointId(): string;
    set accessPointId(value: string);
    resetAccessPointId(): void;
    get accessPointIdInput(): string | undefined;
    private _iam?;
    get iam(): string;
    set iam(value: string);
    resetIam(): void;
    get iamInput(): string | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#authorization_config BatchJobDefinition#authorization_config}
    */
    readonly authorizationConfig?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#file_system_id BatchJobDefinition#file_system_id}
    */
    readonly fileSystemId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#root_directory BatchJobDefinition#root_directory}
    */
    readonly rootDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption BatchJobDefinition#transit_encryption}
    */
    readonly transitEncryption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption_port BatchJobDefinition#transit_encryption_port}
    */
    readonly transitEncryptionPort?: number;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable | undefined);
    private _authorizationConfig;
    get authorizationConfig(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigOutputReference;
    putAuthorizationConfig(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig): void;
    resetAuthorizationConfig(): void;
    get authorizationConfigInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | undefined;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    resetFileSystemId(): void;
    get fileSystemIdInput(): string | undefined;
    private _rootDirectory?;
    get rootDirectory(): string;
    set rootDirectory(value: string);
    resetRootDirectory(): void;
    get rootDirectoryInput(): string | undefined;
    private _transitEncryption?;
    get transitEncryption(): string;
    set transitEncryption(value: string);
    resetTransitEncryption(): void;
    get transitEncryptionInput(): string | undefined;
    private _transitEncryptionPort?;
    get transitEncryptionPort(): number;
    set transitEncryptionPort(value: number);
    resetTransitEncryptionPort(): void;
    get transitEncryptionPortInput(): number | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHost {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#source_path BatchJobDefinition#source_path}
    */
    readonly sourcePath?: string;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesHostToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHost | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesHostToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHost | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHostOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHost | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHost | cdktn.IResolvable | undefined);
    private _sourcePath?;
    get sourcePath(): string;
    set sourcePath(value: string);
    resetSourcePath(): void;
    get sourcePathInput(): string | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#access_point_arn BatchJobDefinition#access_point_arn}
    */
    readonly accessPointArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#file_system_arn BatchJobDefinition#file_system_arn}
    */
    readonly fileSystemArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#root_directory BatchJobDefinition#root_directory}
    */
    readonly rootDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption_port BatchJobDefinition#transit_encryption_port}
    */
    readonly transitEncryptionPort?: number;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfigurationToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfigurationToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable | undefined);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    resetAccessPointArn(): void;
    get accessPointArnInput(): string | undefined;
    private _fileSystemArn?;
    get fileSystemArn(): string;
    set fileSystemArn(value: string);
    resetFileSystemArn(): void;
    get fileSystemArnInput(): string | undefined;
    private _rootDirectory?;
    get rootDirectory(): string;
    set rootDirectory(value: string);
    resetRootDirectory(): void;
    get rootDirectoryInput(): string | undefined;
    private _transitEncryptionPort?;
    get transitEncryptionPort(): number;
    set transitEncryptionPort(value: number);
    resetTransitEncryptionPort(): void;
    get transitEncryptionPortInput(): number | undefined;
}
export interface BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#efs_volume_configuration BatchJobDefinition#efs_volume_configuration}
    */
    readonly efsVolumeConfiguration?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host BatchJobDefinition#host}
    */
    readonly host?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHost;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#s3_files_volume_configuration BatchJobDefinition#s3_files_volume_configuration}
    */
    readonly s3FilesVolumeConfiguration?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesVolumesToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes | cdktn.IResolvable | undefined);
    private _efsVolumeConfiguration;
    get efsVolumeConfiguration(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationOutputReference;
    putEfsVolumeConfiguration(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration): void;
    resetEfsVolumeConfiguration(): void;
    get efsVolumeConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | undefined;
    private _host;
    get host(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHostOutputReference;
    putHost(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHost): void;
    resetHost(): void;
    get hostInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesHost | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _s3FilesVolumeConfiguration;
    get s3FilesVolumeConfiguration(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfigurationOutputReference;
    putS3FilesVolumeConfiguration(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration): void;
    resetS3FilesVolumeConfiguration(): void;
    get s3FilesVolumeConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesOutputReference;
}
export interface BatchJobDefinitionEcsPropertiesTaskProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#containers BatchJobDefinition#containers}
    */
    readonly containers?: BatchJobDefinitionEcsPropertiesTaskPropertiesContainers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#enable_execute_command BatchJobDefinition#enable_execute_command}
    */
    readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ephemeral_storage BatchJobDefinition#ephemeral_storage}
    */
    readonly ephemeralStorage?: BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#execution_role_arn BatchJobDefinition#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ipc_mode BatchJobDefinition#ipc_mode}
    */
    readonly ipcMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#network_configuration BatchJobDefinition#network_configuration}
    */
    readonly networkConfiguration?: BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#network_mode BatchJobDefinition#network_mode}
    */
    readonly networkMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#pid_mode BatchJobDefinition#pid_mode}
    */
    readonly pidMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#platform_version BatchJobDefinition#platform_version}
    */
    readonly platformVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#runtime_platform BatchJobDefinition#runtime_platform}
    */
    readonly runtimePlatform?: BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatform;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#task_role_arn BatchJobDefinition#task_role_arn}
    */
    readonly taskRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volumes BatchJobDefinition#volumes}
    */
    readonly volumes?: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesToTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesTaskPropertiesToHclTerraform(struct?: BatchJobDefinitionEcsPropertiesTaskProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEcsPropertiesTaskProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsPropertiesTaskProperties | cdktn.IResolvable | undefined);
    private _containers;
    get containers(): BatchJobDefinitionEcsPropertiesTaskPropertiesContainersList;
    putContainers(value: BatchJobDefinitionEcsPropertiesTaskPropertiesContainers[] | cdktn.IResolvable): void;
    resetContainers(): void;
    get containersInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesContainers[] | undefined;
    private _enableExecuteCommand?;
    get enableExecuteCommand(): boolean | cdktn.IResolvable;
    set enableExecuteCommand(value: boolean | cdktn.IResolvable);
    resetEnableExecuteCommand(): void;
    get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
    private _ephemeralStorage;
    get ephemeralStorage(): BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorageOutputReference;
    putEphemeralStorage(value: BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorage): void;
    resetEphemeralStorage(): void;
    get ephemeralStorageInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesEphemeralStorage | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _ipcMode?;
    get ipcMode(): string;
    set ipcMode(value: string);
    resetIpcMode(): void;
    get ipcModeInput(): string | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfigurationOutputReference;
    putNetworkConfiguration(value: BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfiguration): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesNetworkConfiguration | undefined;
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    resetNetworkMode(): void;
    get networkModeInput(): string | undefined;
    private _pidMode?;
    get pidMode(): string;
    set pidMode(value: string);
    resetPidMode(): void;
    get pidModeInput(): string | undefined;
    private _platformVersion?;
    get platformVersion(): string;
    set platformVersion(value: string);
    resetPlatformVersion(): void;
    get platformVersionInput(): string | undefined;
    private _runtimePlatform;
    get runtimePlatform(): BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatformOutputReference;
    putRuntimePlatform(value: BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatform): void;
    resetRuntimePlatform(): void;
    get runtimePlatformInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesRuntimePlatform | undefined;
    private _taskRoleArn?;
    get taskRoleArn(): string;
    set taskRoleArn(value: string);
    resetTaskRoleArn(): void;
    get taskRoleArnInput(): string | undefined;
    private _volumes;
    get volumes(): BatchJobDefinitionEcsPropertiesTaskPropertiesVolumesList;
    putVolumes(value: BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskPropertiesVolumes[] | undefined;
}
export declare class BatchJobDefinitionEcsPropertiesTaskPropertiesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEcsPropertiesTaskProperties[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEcsPropertiesTaskPropertiesOutputReference;
}
export interface BatchJobDefinitionEcsProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#task_properties BatchJobDefinition#task_properties}
    */
    readonly taskProperties?: BatchJobDefinitionEcsPropertiesTaskProperties[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionEcsPropertiesToTerraform(struct?: BatchJobDefinitionEcsProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionEcsPropertiesToHclTerraform(struct?: BatchJobDefinitionEcsProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEcsPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEcsProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEcsProperties | cdktn.IResolvable | undefined);
    private _taskProperties;
    get taskProperties(): BatchJobDefinitionEcsPropertiesTaskPropertiesList;
    putTaskProperties(value: BatchJobDefinitionEcsPropertiesTaskProperties[] | cdktn.IResolvable): void;
    resetTaskProperties(): void;
    get taskPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionEcsPropertiesTaskProperties[] | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersEnvToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersEnvToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesContainersEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionEksPropertiesPodPropertiesContainersEnvList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEksPropertiesPodPropertiesContainersEnvOutputReference;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesContainersResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#limits BatchJobDefinition#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#requests BatchJobDefinition#requests}
    */
    readonly requests?: {
        [key: string]: string;
    };
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersResourcesToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainersResources | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersResourcesToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainersResources | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesContainersResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesContainersResources | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesContainersResources | cdktn.IResolvable | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests?;
    get requests(): {
        [key: string]: string;
    };
    set requests(value: {
        [key: string]: string;
    });
    resetRequests(): void;
    get requestsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#allow_privilege_escalation BatchJobDefinition#allow_privilege_escalation}
    */
    readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#privileged BatchJobDefinition#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only_root_filesystem BatchJobDefinition#read_only_root_filesystem}
    */
    readonly readOnlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_group BatchJobDefinition#run_as_group}
    */
    readonly runAsGroup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_non_root BatchJobDefinition#run_as_non_root}
    */
    readonly runAsNonRoot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_user BatchJobDefinition#run_as_user}
    */
    readonly runAsUser?: number;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContext | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContext | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContext | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContext | cdktn.IResolvable | undefined);
    private _allowPrivilegeEscalation?;
    get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
    set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
    resetAllowPrivilegeEscalation(): void;
    get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readOnlyRootFilesystem?;
    get readOnlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readOnlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadOnlyRootFilesystem(): void;
    get readOnlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsGroup?;
    get runAsGroup(): number;
    set runAsGroup(value: number);
    resetRunAsGroup(): void;
    get runAsGroupInput(): number | undefined;
    private _runAsNonRoot?;
    get runAsNonRoot(): boolean | cdktn.IResolvable;
    set runAsNonRoot(value: boolean | cdktn.IResolvable);
    resetRunAsNonRoot(): void;
    get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUser?;
    get runAsUser(): number;
    set runAsUser(value: number);
    resetRunAsUser(): void;
    get runAsUserInput(): number | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_path BatchJobDefinition#mount_path}
    */
    readonly mountPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#sub_path BatchJobDefinition#sub_path}
    */
    readonly subPath?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsOutputReference;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesContainers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#args BatchJobDefinition#args}
    */
    readonly args?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#command BatchJobDefinition#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#env BatchJobDefinition#env}
    */
    readonly env?: BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image BatchJobDefinition#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image_pull_policy BatchJobDefinition#image_pull_policy}
    */
    readonly imagePullPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resources BatchJobDefinition#resources}
    */
    readonly resources?: BatchJobDefinitionEksPropertiesPodPropertiesContainersResources;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#security_context BatchJobDefinition#security_context}
    */
    readonly securityContext?: BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volume_mounts BatchJobDefinition#volume_mounts}
    */
    readonly volumeMounts?: BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainers | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesContainersToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesContainers | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesContainers | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesContainers | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _env;
    get env(): BatchJobDefinitionEksPropertiesPodPropertiesContainersEnvList;
    putEnv(value: BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesContainersEnv[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _imagePullPolicy?;
    get imagePullPolicy(): string;
    set imagePullPolicy(value: string);
    resetImagePullPolicy(): void;
    get imagePullPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _resources;
    get resources(): BatchJobDefinitionEksPropertiesPodPropertiesContainersResourcesOutputReference;
    putResources(value: BatchJobDefinitionEksPropertiesPodPropertiesContainersResources): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesContainersResources | undefined;
    private _securityContext;
    get securityContext(): BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextOutputReference;
    putSecurityContext(value: BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContext): void;
    resetSecurityContext(): void;
    get securityContextInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContext | undefined;
    private _volumeMounts;
    get volumeMounts(): BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsList;
    putVolumeMounts(value: BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMounts[] | undefined;
}
export declare class BatchJobDefinitionEksPropertiesPodPropertiesContainersList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEksPropertiesPodPropertiesContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEksPropertiesPodPropertiesContainersOutputReference;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesImagePullSecretsToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesImagePullSecretsToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecretsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecretsOutputReference;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersEnvToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersEnvToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnvList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnvOutputReference;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#limits BatchJobDefinition#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#requests BatchJobDefinition#requests}
    */
    readonly requests?: {
        [key: string]: string;
    };
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResources | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResources | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResources | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResources | cdktn.IResolvable | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests?;
    get requests(): {
        [key: string]: string;
    };
    set requests(value: {
        [key: string]: string;
    });
    resetRequests(): void;
    get requestsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#allow_privilege_escalation BatchJobDefinition#allow_privilege_escalation}
    */
    readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#privileged BatchJobDefinition#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only_root_filesystem BatchJobDefinition#read_only_root_filesystem}
    */
    readonly readOnlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_group BatchJobDefinition#run_as_group}
    */
    readonly runAsGroup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_non_root BatchJobDefinition#run_as_non_root}
    */
    readonly runAsNonRoot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_user BatchJobDefinition#run_as_user}
    */
    readonly runAsUser?: number;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContext | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContext | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContext | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContext | cdktn.IResolvable | undefined);
    private _allowPrivilegeEscalation?;
    get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
    set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
    resetAllowPrivilegeEscalation(): void;
    get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readOnlyRootFilesystem?;
    get readOnlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readOnlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadOnlyRootFilesystem(): void;
    get readOnlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsGroup?;
    get runAsGroup(): number;
    set runAsGroup(value: number);
    resetRunAsGroup(): void;
    get runAsGroupInput(): number | undefined;
    private _runAsNonRoot?;
    get runAsNonRoot(): boolean | cdktn.IResolvable;
    set runAsNonRoot(value: boolean | cdktn.IResolvable);
    resetRunAsNonRoot(): void;
    get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUser?;
    get runAsUser(): number;
    set runAsUser(value: number);
    resetRunAsUser(): void;
    get runAsUserInput(): number | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_path BatchJobDefinition#mount_path}
    */
    readonly mountPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#sub_path BatchJobDefinition#sub_path}
    */
    readonly subPath?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsOutputReference;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesInitContainers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#args BatchJobDefinition#args}
    */
    readonly args?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#command BatchJobDefinition#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#env BatchJobDefinition#env}
    */
    readonly env?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image BatchJobDefinition#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image_pull_policy BatchJobDefinition#image_pull_policy}
    */
    readonly imagePullPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resources BatchJobDefinition#resources}
    */
    readonly resources?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResources;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#security_context BatchJobDefinition#security_context}
    */
    readonly securityContext?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volume_mounts BatchJobDefinition#volume_mounts}
    */
    readonly volumeMounts?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainers | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesInitContainersToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainers | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesInitContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainers | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainers | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _env;
    get env(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnvList;
    putEnv(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnv[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _imagePullPolicy?;
    get imagePullPolicy(): string;
    set imagePullPolicy(value: string);
    resetImagePullPolicy(): void;
    get imagePullPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _resources;
    get resources(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesOutputReference;
    putResources(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResources): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesInitContainersResources | undefined;
    private _securityContext;
    get securityContext(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextOutputReference;
    putSecurityContext(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContext): void;
    resetSecurityContext(): void;
    get securityContextInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContext | undefined;
    private _volumeMounts;
    get volumeMounts(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsList;
    putVolumeMounts(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMounts[] | undefined;
}
export declare class BatchJobDefinitionEksPropertiesPodPropertiesInitContainersList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersOutputReference;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#annotations BatchJobDefinition#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#labels BatchJobDefinition#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#namespace BatchJobDefinition#namespace}
    */
    readonly namespace?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesMetadataToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesMetadata | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesMetadataToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesMetadata | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesMetadata | cdktn.IResolvable | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDir {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#medium BatchJobDefinition#medium}
    */
    readonly medium?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size_limit BatchJobDefinition#size_limit}
    */
    readonly sizeLimit?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDirToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDir | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDirToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDir | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDir | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDir | cdktn.IResolvable | undefined);
    private _medium?;
    get medium(): string;
    set medium(value: string);
    resetMedium(): void;
    get mediumInput(): string | undefined;
    private _sizeLimit?;
    get sizeLimit(): string;
    set sizeLimit(value: string);
    resetSizeLimit(): void;
    get sizeLimitInput(): string | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPath {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#path BatchJobDefinition#path}
    */
    readonly path?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesHostPathToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPath | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesHostPathToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPath | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPath | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPath | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaim {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#claim_name BatchJobDefinition#claim_name}
    */
    readonly claimName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaimToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaimToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaimOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | cdktn.IResolvable | undefined);
    private _claimName?;
    get claimName(): string;
    set claimName(value: string);
    resetClaimName(): void;
    get claimNameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#optional BatchJobDefinition#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secret_name BatchJobDefinition#secret_name}
    */
    readonly secretName?: string;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesSecretToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecret | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesSecretToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecret | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecret | cdktn.IResolvable | undefined);
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    resetSecretName(): void;
    get secretNameInput(): string | undefined;
}
export interface BatchJobDefinitionEksPropertiesPodPropertiesVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#empty_dir BatchJobDefinition#empty_dir}
    */
    readonly emptyDir?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDir;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host_path BatchJobDefinition#host_path}
    */
    readonly hostPath?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPath;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#persistent_volume_claim BatchJobDefinition#persistent_volume_claim}
    */
    readonly persistentVolumeClaim?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaim;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secret BatchJobDefinition#secret}
    */
    readonly secret?: BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecret;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesToTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumes | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesVolumesToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodPropertiesVolumes | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionEksPropertiesPodPropertiesVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumes | cdktn.IResolvable | undefined);
    private _emptyDir;
    get emptyDir(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDirOutputReference;
    putEmptyDir(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDir): void;
    resetEmptyDir(): void;
    get emptyDirInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesVolumesEmptyDir | undefined;
    private _hostPath;
    get hostPath(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPathOutputReference;
    putHostPath(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPath): void;
    resetHostPath(): void;
    get hostPathInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesVolumesHostPath | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _persistentVolumeClaim;
    get persistentVolumeClaim(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaimOutputReference;
    putPersistentVolumeClaim(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaim): void;
    resetPersistentVolumeClaim(): void;
    get persistentVolumeClaimInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | undefined;
    private _secret;
    get secret(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecretOutputReference;
    putSecret(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesVolumesSecret | undefined;
}
export declare class BatchJobDefinitionEksPropertiesPodPropertiesVolumesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionEksPropertiesPodPropertiesVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionEksPropertiesPodPropertiesVolumesOutputReference;
}
export interface BatchJobDefinitionEksPropertiesPodProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#containers BatchJobDefinition#containers}
    */
    readonly containers?: BatchJobDefinitionEksPropertiesPodPropertiesContainers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#dns_policy BatchJobDefinition#dns_policy}
    */
    readonly dnsPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host_network BatchJobDefinition#host_network}
    */
    readonly hostNetwork?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image_pull_secrets BatchJobDefinition#image_pull_secrets}
    */
    readonly imagePullSecrets?: BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#init_containers BatchJobDefinition#init_containers}
    */
    readonly initContainers?: BatchJobDefinitionEksPropertiesPodPropertiesInitContainers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#metadata BatchJobDefinition#metadata}
    */
    readonly metadata?: BatchJobDefinitionEksPropertiesPodPropertiesMetadata;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#service_account_name BatchJobDefinition#service_account_name}
    */
    readonly serviceAccountName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#share_process_namespace BatchJobDefinition#share_process_namespace}
    */
    readonly shareProcessNamespace?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volumes BatchJobDefinition#volumes}
    */
    readonly volumes?: BatchJobDefinitionEksPropertiesPodPropertiesVolumes[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionEksPropertiesPodPropertiesToTerraform(struct?: BatchJobDefinitionEksPropertiesPodProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesPodPropertiesToHclTerraform(struct?: BatchJobDefinitionEksPropertiesPodProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesPodPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksPropertiesPodProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksPropertiesPodProperties | cdktn.IResolvable | undefined);
    private _containers;
    get containers(): BatchJobDefinitionEksPropertiesPodPropertiesContainersList;
    putContainers(value: BatchJobDefinitionEksPropertiesPodPropertiesContainers[] | cdktn.IResolvable): void;
    resetContainers(): void;
    get containersInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesContainers[] | undefined;
    private _dnsPolicy?;
    get dnsPolicy(): string;
    set dnsPolicy(value: string);
    resetDnsPolicy(): void;
    get dnsPolicyInput(): string | undefined;
    private _hostNetwork?;
    get hostNetwork(): boolean | cdktn.IResolvable;
    set hostNetwork(value: boolean | cdktn.IResolvable);
    resetHostNetwork(): void;
    get hostNetworkInput(): boolean | cdktn.IResolvable | undefined;
    private _imagePullSecrets;
    get imagePullSecrets(): BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecretsList;
    putImagePullSecrets(value: BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets[] | cdktn.IResolvable): void;
    resetImagePullSecrets(): void;
    get imagePullSecretsInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesImagePullSecrets[] | undefined;
    private _initContainers;
    get initContainers(): BatchJobDefinitionEksPropertiesPodPropertiesInitContainersList;
    putInitContainers(value: BatchJobDefinitionEksPropertiesPodPropertiesInitContainers[] | cdktn.IResolvable): void;
    resetInitContainers(): void;
    get initContainersInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesInitContainers[] | undefined;
    private _metadata;
    get metadata(): BatchJobDefinitionEksPropertiesPodPropertiesMetadataOutputReference;
    putMetadata(value: BatchJobDefinitionEksPropertiesPodPropertiesMetadata): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesMetadata | undefined;
    private _serviceAccountName?;
    get serviceAccountName(): string;
    set serviceAccountName(value: string);
    resetServiceAccountName(): void;
    get serviceAccountNameInput(): string | undefined;
    private _shareProcessNamespace?;
    get shareProcessNamespace(): boolean | cdktn.IResolvable;
    set shareProcessNamespace(value: boolean | cdktn.IResolvable);
    resetShareProcessNamespace(): void;
    get shareProcessNamespaceInput(): boolean | cdktn.IResolvable | undefined;
    private _volumes;
    get volumes(): BatchJobDefinitionEksPropertiesPodPropertiesVolumesList;
    putVolumes(value: BatchJobDefinitionEksPropertiesPodPropertiesVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodPropertiesVolumes[] | undefined;
}
export interface BatchJobDefinitionEksProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#pod_properties BatchJobDefinition#pod_properties}
    */
    readonly podProperties?: BatchJobDefinitionEksPropertiesPodProperties;
}
export declare function batchJobDefinitionEksPropertiesToTerraform(struct?: BatchJobDefinitionEksProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionEksPropertiesToHclTerraform(struct?: BatchJobDefinitionEksProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionEksPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionEksProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionEksProperties | cdktn.IResolvable | undefined);
    private _podProperties;
    get podProperties(): BatchJobDefinitionEksPropertiesPodPropertiesOutputReference;
    putPodProperties(value: BatchJobDefinitionEksPropertiesPodProperties): void;
    resetPodProperties(): void;
    get podPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionEksPropertiesPodProperties | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct {
    /**
    * The ARN of the consumable resource the job definition should consume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#consumable_resource BatchJobDefinition#consumable_resource}
    */
    readonly consumableResource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#quantity BatchJobDefinition#quantity}
    */
    readonly quantity?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStructToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStructToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct | cdktn.IResolvable | undefined);
    private _consumableResource?;
    get consumableResource(): string;
    set consumableResource(value: string);
    resetConsumableResource(): void;
    get consumableResourceInput(): string | undefined;
    private _quantity?;
    get quantity(): number;
    set quantity(value: number);
    resetQuantity(): void;
    get quantityInput(): number | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStructList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStructOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourceProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#consumable_resource_list BatchJobDefinition#consumable_resource_list}
    */
    readonly consumableResourceList?: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourceProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourceProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourceProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourceProperties | cdktn.IResolvable | undefined);
    private _consumableResourceList;
    get consumableResourceList(): BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStructList;
    putConsumableResourceList(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct[] | cdktn.IResolvable): void;
    resetConsumableResourceList(): void;
    get consumableResourceListInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesConsumableResourceListStruct[] | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironmentToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironmentToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironmentList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironmentOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size_in_gi_b BatchJobDefinition#size_in_gi_b}
    */
    readonly sizeInGiB?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorageToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorage | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorageToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorage | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorage | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorage | cdktn.IResolvable | undefined);
    private _sizeInGiB?;
    get sizeInGiB(): number;
    set sizeInGiB(value: number);
    resetSizeInGiB(): void;
    get sizeInGiBInput(): number | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host_path BatchJobDefinition#host_path}
    */
    readonly hostPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#permissions BatchJobDefinition#permissions}
    */
    readonly permissions?: string[];
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevicesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevicesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _hostPath?;
    get hostPath(): string;
    set hostPath(value: string);
    resetHostPath(): void;
    get hostPathInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    resetPermissions(): void;
    get permissionsInput(): string[] | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevicesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevicesOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_options BatchJobDefinition#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size BatchJobDefinition#size}
    */
    readonly size?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#devices BatchJobDefinition#devices}
    */
    readonly devices?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#init_process_enabled BatchJobDefinition#init_process_enabled}
    */
    readonly initProcessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#max_swap BatchJobDefinition#max_swap}
    */
    readonly maxSwap?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#shared_memory_size BatchJobDefinition#shared_memory_size}
    */
    readonly sharedMemorySize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#swappiness BatchJobDefinition#swappiness}
    */
    readonly swappiness?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#tmpfs BatchJobDefinition#tmpfs}
    */
    readonly tmpfs?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParameters | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParameters | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParameters | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParameters | cdktn.IResolvable | undefined);
    private _devices;
    get devices(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevicesList;
    putDevices(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices[] | cdktn.IResolvable): void;
    resetDevices(): void;
    get devicesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersDevices[] | undefined;
    private _initProcessEnabled?;
    get initProcessEnabled(): boolean | cdktn.IResolvable;
    set initProcessEnabled(value: boolean | cdktn.IResolvable);
    resetInitProcessEnabled(): void;
    get initProcessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _maxSwap?;
    get maxSwap(): number;
    set maxSwap(value: number);
    resetMaxSwap(): void;
    get maxSwapInput(): number | undefined;
    private _sharedMemorySize?;
    get sharedMemorySize(): number;
    set sharedMemorySize(value: number);
    resetSharedMemorySize(): void;
    get sharedMemorySizeInput(): number | undefined;
    private _swappiness?;
    get swappiness(): number;
    set swappiness(value: number);
    resetSwappiness(): void;
    get swappinessInput(): number | undefined;
    private _tmpfs;
    get tmpfs(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfsList;
    putTmpfs(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs[] | cdktn.IResolvable): void;
    resetTmpfs(): void;
    get tmpfsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersTmpfs[] | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value_from BatchJobDefinition#value_from}
    */
    readonly valueFrom?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptionsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptionsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptionsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptionsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#log_driver BatchJobDefinition#log_driver}
    */
    readonly logDriver?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#options BatchJobDefinition#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secret_options BatchJobDefinition#secret_options}
    */
    readonly secretOptions?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfiguration | cdktn.IResolvable | undefined);
    private _logDriver?;
    get logDriver(): string;
    set logDriver(value: string);
    resetLogDriver(): void;
    get logDriverInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _secretOptions;
    get secretOptions(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptionsList;
    putSecretOptions(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions[] | cdktn.IResolvable): void;
    resetSecretOptions(): void;
    get secretOptionsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationSecretOptions[] | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#source_volume BatchJobDefinition#source_volume}
    */
    readonly sourceVolume?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPointsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPointsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceVolume?;
    get sourceVolume(): string;
    set sourceVolume(value: string);
    resetSourceVolume(): void;
    get sourceVolumeInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPointsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPointsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#credentials_parameter BatchJobDefinition#credentials_parameter}
    */
    readonly credentialsParameter?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentialsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentials | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentialsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentials | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentials | cdktn.IResolvable | undefined);
    private _credentialsParameter?;
    get credentialsParameter(): string;
    set credentialsParameter(value: string);
    resetCredentialsParameter(): void;
    get credentialsParameterInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#type BatchJobDefinition#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirementsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirementsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirementsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirementsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatform {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#cpu_architecture BatchJobDefinition#cpu_architecture}
    */
    readonly cpuArchitecture?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#operating_system_family BatchJobDefinition#operating_system_family}
    */
    readonly operatingSystemFamily?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatformToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatform | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatformToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatform | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatform | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatform | cdktn.IResolvable | undefined);
    private _cpuArchitecture?;
    get cpuArchitecture(): string;
    set cpuArchitecture(value: string);
    resetCpuArchitecture(): void;
    get cpuArchitectureInput(): string | undefined;
    private _operatingSystemFamily?;
    get operatingSystemFamily(): string;
    set operatingSystemFamily(value: string);
    resetOperatingSystemFamily(): void;
    get operatingSystemFamilyInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value_from BatchJobDefinition#value_from}
    */
    readonly valueFrom?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecretsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecretsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecretsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecretsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#hard_limit BatchJobDefinition#hard_limit}
    */
    readonly hardLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#soft_limit BatchJobDefinition#soft_limit}
    */
    readonly softLimit?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimitsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimitsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits | cdktn.IResolvable | undefined);
    private _hardLimit?;
    get hardLimit(): number;
    set hardLimit(value: number);
    resetHardLimit(): void;
    get hardLimitInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _softLimit?;
    get softLimit(): number;
    set softLimit(value: number);
    resetSoftLimit(): void;
    get softLimitInput(): number | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimitsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimitsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#access_point_id BatchJobDefinition#access_point_id}
    */
    readonly accessPointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#iam BatchJobDefinition#iam}
    */
    readonly iam?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfigToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfigToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable | undefined);
    private _accessPointId?;
    get accessPointId(): string;
    set accessPointId(value: string);
    resetAccessPointId(): void;
    get accessPointIdInput(): string | undefined;
    private _iam?;
    get iam(): string;
    set iam(value: string);
    resetIam(): void;
    get iamInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#authorization_config BatchJobDefinition#authorization_config}
    */
    readonly authorizationConfig?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#file_system_id BatchJobDefinition#file_system_id}
    */
    readonly fileSystemId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#root_directory BatchJobDefinition#root_directory}
    */
    readonly rootDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption BatchJobDefinition#transit_encryption}
    */
    readonly transitEncryption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption_port BatchJobDefinition#transit_encryption_port}
    */
    readonly transitEncryptionPort?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfiguration | cdktn.IResolvable | undefined);
    private _authorizationConfig;
    get authorizationConfig(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfigOutputReference;
    putAuthorizationConfig(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfig): void;
    resetAuthorizationConfig(): void;
    get authorizationConfigInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationAuthorizationConfig | undefined;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    resetFileSystemId(): void;
    get fileSystemIdInput(): string | undefined;
    private _rootDirectory?;
    get rootDirectory(): string;
    set rootDirectory(value: string);
    resetRootDirectory(): void;
    get rootDirectoryInput(): string | undefined;
    private _transitEncryption?;
    get transitEncryption(): string;
    set transitEncryption(value: string);
    resetTransitEncryption(): void;
    get transitEncryptionInput(): string | undefined;
    private _transitEncryptionPort?;
    get transitEncryptionPort(): number;
    set transitEncryptionPort(value: number);
    resetTransitEncryptionPort(): void;
    get transitEncryptionPortInput(): number | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHost {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#source_path BatchJobDefinition#source_path}
    */
    readonly sourcePath?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHostToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHost | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHostToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHost | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHostOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHost | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHost | cdktn.IResolvable | undefined);
    private _sourcePath?;
    get sourcePath(): string;
    set sourcePath(value: string);
    resetSourcePath(): void;
    get sourcePathInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#access_point_arn BatchJobDefinition#access_point_arn}
    */
    readonly accessPointArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#file_system_arn BatchJobDefinition#file_system_arn}
    */
    readonly fileSystemArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#root_directory BatchJobDefinition#root_directory}
    */
    readonly rootDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption_port BatchJobDefinition#transit_encryption_port}
    */
    readonly transitEncryptionPort?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfigurationToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfigurationToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfiguration | cdktn.IResolvable | undefined);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    resetAccessPointArn(): void;
    get accessPointArnInput(): string | undefined;
    private _fileSystemArn?;
    get fileSystemArn(): string;
    set fileSystemArn(value: string);
    resetFileSystemArn(): void;
    get fileSystemArnInput(): string | undefined;
    private _rootDirectory?;
    get rootDirectory(): string;
    set rootDirectory(value: string);
    resetRootDirectory(): void;
    get rootDirectoryInput(): string | undefined;
    private _transitEncryptionPort?;
    get transitEncryptionPort(): number;
    set transitEncryptionPort(value: number);
    resetTransitEncryptionPort(): void;
    get transitEncryptionPortInput(): number | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#efs_volume_configuration BatchJobDefinition#efs_volume_configuration}
    */
    readonly efsVolumeConfiguration?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host BatchJobDefinition#host}
    */
    readonly host?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHost;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#s3_files_volume_configuration BatchJobDefinition#s3_files_volume_configuration}
    */
    readonly s3FilesVolumeConfiguration?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfiguration;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes | cdktn.IResolvable | undefined);
    private _efsVolumeConfiguration;
    get efsVolumeConfiguration(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfigurationOutputReference;
    putEfsVolumeConfiguration(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfiguration): void;
    resetEfsVolumeConfiguration(): void;
    get efsVolumeConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesEfsVolumeConfiguration | undefined;
    private _host;
    get host(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHostOutputReference;
    putHost(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHost): void;
    resetHost(): void;
    get hostInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesHost | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _s3FilesVolumeConfiguration;
    get s3FilesVolumeConfiguration(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfigurationOutputReference;
    putS3FilesVolumeConfiguration(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfiguration): void;
    resetS3FilesVolumeConfiguration(): void;
    get s3FilesVolumeConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesS3FilesVolumeConfiguration | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesContainer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#command BatchJobDefinition#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#enable_execute_command BatchJobDefinition#enable_execute_command}
    */
    readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#environment BatchJobDefinition#environment}
    */
    readonly environment?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ephemeral_storage BatchJobDefinition#ephemeral_storage}
    */
    readonly ephemeralStorage?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#execution_role_arn BatchJobDefinition#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image BatchJobDefinition#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#instance_type BatchJobDefinition#instance_type}
    */
    readonly instanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#job_role_arn BatchJobDefinition#job_role_arn}
    */
    readonly jobRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#linux_parameters BatchJobDefinition#linux_parameters}
    */
    readonly linuxParameters?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParameters;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#log_configuration BatchJobDefinition#log_configuration}
    */
    readonly logConfiguration?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#memory BatchJobDefinition#memory}
    */
    readonly memory?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_points BatchJobDefinition#mount_points}
    */
    readonly mountPoints?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#privileged BatchJobDefinition#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#readonly_root_filesystem BatchJobDefinition#readonly_root_filesystem}
    */
    readonly readonlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#repository_credentials BatchJobDefinition#repository_credentials}
    */
    readonly repositoryCredentials?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentials;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resource_requirements BatchJobDefinition#resource_requirements}
    */
    readonly resourceRequirements?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#runtime_platform BatchJobDefinition#runtime_platform}
    */
    readonly runtimePlatform?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatform;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secrets BatchJobDefinition#secrets}
    */
    readonly secrets?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ulimits BatchJobDefinition#ulimits}
    */
    readonly ulimits?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#user BatchJobDefinition#user}
    */
    readonly user?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#vcpus BatchJobDefinition#vcpus}
    */
    readonly vcpus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volumes BatchJobDefinition#volumes}
    */
    readonly volumes?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainer | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesContainerToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainer | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainer | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainer | cdktn.IResolvable | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _enableExecuteCommand?;
    get enableExecuteCommand(): boolean | cdktn.IResolvable;
    set enableExecuteCommand(value: boolean | cdktn.IResolvable);
    resetEnableExecuteCommand(): void;
    get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
    private _environment;
    get environment(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironmentList;
    putEnvironment(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment[] | cdktn.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEnvironment[] | undefined;
    private _ephemeralStorage;
    get ephemeralStorage(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorageOutputReference;
    putEphemeralStorage(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorage): void;
    resetEphemeralStorage(): void;
    get ephemeralStorageInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerEphemeralStorage | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _jobRoleArn?;
    get jobRoleArn(): string;
    set jobRoleArn(value: string);
    resetJobRoleArn(): void;
    get jobRoleArnInput(): string | undefined;
    private _linuxParameters;
    get linuxParameters(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParametersOutputReference;
    putLinuxParameters(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParameters): void;
    resetLinuxParameters(): void;
    get linuxParametersInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLinuxParameters | undefined;
    private _logConfiguration;
    get logConfiguration(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfigurationOutputReference;
    putLogConfiguration(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfiguration): void;
    resetLogConfiguration(): void;
    get logConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerLogConfiguration | undefined;
    private _memory?;
    get memory(): number;
    set memory(value: number);
    resetMemory(): void;
    get memoryInput(): number | undefined;
    private _mountPoints;
    get mountPoints(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPointsList;
    putMountPoints(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints[] | cdktn.IResolvable): void;
    resetMountPoints(): void;
    get mountPointsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerMountPoints[] | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readonlyRootFilesystem?;
    get readonlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readonlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadonlyRootFilesystem(): void;
    get readonlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _repositoryCredentials;
    get repositoryCredentials(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentialsOutputReference;
    putRepositoryCredentials(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentials): void;
    resetRepositoryCredentials(): void;
    get repositoryCredentialsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRepositoryCredentials | undefined;
    private _resourceRequirements;
    get resourceRequirements(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirementsList;
    putResourceRequirements(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements[] | cdktn.IResolvable): void;
    resetResourceRequirements(): void;
    get resourceRequirementsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerResourceRequirements[] | undefined;
    private _runtimePlatform;
    get runtimePlatform(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatformOutputReference;
    putRuntimePlatform(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatform): void;
    resetRuntimePlatform(): void;
    get runtimePlatformInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerRuntimePlatform | undefined;
    private _secrets;
    get secrets(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecretsList;
    putSecrets(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets[] | cdktn.IResolvable): void;
    resetSecrets(): void;
    get secretsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerSecrets[] | undefined;
    private _ulimits;
    get ulimits(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimitsList;
    putUlimits(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits[] | cdktn.IResolvable): void;
    resetUlimits(): void;
    get ulimitsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerUlimits[] | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    private _vcpus?;
    get vcpus(): number;
    set vcpus(value: number);
    resetVcpus(): void;
    get vcpusInput(): number | undefined;
    private _volumes;
    get volumes(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesList;
    putVolumes(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumes[] | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#condition BatchJobDefinition#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_name BatchJobDefinition#container_name}
    */
    readonly containerName?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOnToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOnToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _containerName?;
    get containerName(): string;
    set containerName(value: string);
    resetContainerName(): void;
    get containerNameInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOnList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOnOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironmentToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironmentToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironmentList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironmentOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#options BatchJobDefinition#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#type BatchJobDefinition#type}
    */
    readonly type?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfigurationToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfigurationToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfiguration | cdktn.IResolvable | undefined);
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host_path BatchJobDefinition#host_path}
    */
    readonly hostPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#permissions BatchJobDefinition#permissions}
    */
    readonly permissions?: string[];
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _hostPath?;
    get hostPath(): string;
    set hostPath(value: string);
    resetHostPath(): void;
    get hostPathInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    resetPermissions(): void;
    get permissionsInput(): string[] | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_options BatchJobDefinition#mount_options}
    */
    readonly mountOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size BatchJobDefinition#size}
    */
    readonly size?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _mountOptions?;
    get mountOptions(): string[];
    set mountOptions(value: string[]);
    resetMountOptions(): void;
    get mountOptionsInput(): string[] | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#devices BatchJobDefinition#devices}
    */
    readonly devices?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#init_process_enabled BatchJobDefinition#init_process_enabled}
    */
    readonly initProcessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#max_swap BatchJobDefinition#max_swap}
    */
    readonly maxSwap?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#shared_memory_size BatchJobDefinition#shared_memory_size}
    */
    readonly sharedMemorySize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#swappiness BatchJobDefinition#swappiness}
    */
    readonly swappiness?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#tmpfs BatchJobDefinition#tmpfs}
    */
    readonly tmpfs?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParameters | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParameters | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParameters | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParameters | cdktn.IResolvable | undefined);
    private _devices;
    get devices(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevicesList;
    putDevices(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices[] | cdktn.IResolvable): void;
    resetDevices(): void;
    get devicesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersDevices[] | undefined;
    private _initProcessEnabled?;
    get initProcessEnabled(): boolean | cdktn.IResolvable;
    set initProcessEnabled(value: boolean | cdktn.IResolvable);
    resetInitProcessEnabled(): void;
    get initProcessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _maxSwap?;
    get maxSwap(): number;
    set maxSwap(value: number);
    resetMaxSwap(): void;
    get maxSwapInput(): number | undefined;
    private _sharedMemorySize?;
    get sharedMemorySize(): number;
    set sharedMemorySize(value: number);
    resetSharedMemorySize(): void;
    get sharedMemorySizeInput(): number | undefined;
    private _swappiness?;
    get swappiness(): number;
    set swappiness(value: number);
    resetSwappiness(): void;
    get swappinessInput(): number | undefined;
    private _tmpfs;
    get tmpfs(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfsList;
    putTmpfs(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs[] | cdktn.IResolvable): void;
    resetTmpfs(): void;
    get tmpfsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersTmpfs[] | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value_from BatchJobDefinition#value_from}
    */
    readonly valueFrom?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#log_driver BatchJobDefinition#log_driver}
    */
    readonly logDriver?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#options BatchJobDefinition#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secret_options BatchJobDefinition#secret_options}
    */
    readonly secretOptions?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfiguration | cdktn.IResolvable | undefined);
    private _logDriver?;
    get logDriver(): string;
    set logDriver(value: string);
    resetLogDriver(): void;
    get logDriverInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _secretOptions;
    get secretOptions(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptionsList;
    putSecretOptions(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions[] | cdktn.IResolvable): void;
    resetSecretOptions(): void;
    get secretOptionsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationSecretOptions[] | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container_path BatchJobDefinition#container_path}
    */
    readonly containerPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#source_volume BatchJobDefinition#source_volume}
    */
    readonly sourceVolume?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPointsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPointsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints | cdktn.IResolvable | undefined);
    private _containerPath?;
    get containerPath(): string;
    set containerPath(value: string);
    resetContainerPath(): void;
    get containerPathInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceVolume?;
    get sourceVolume(): string;
    set sourceVolume(value: string);
    resetSourceVolume(): void;
    get sourceVolumeInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPointsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPointsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#credentials_parameter BatchJobDefinition#credentials_parameter}
    */
    readonly credentialsParameter?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentialsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentials | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentialsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentials | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentials | cdktn.IResolvable | undefined);
    private _credentialsParameter?;
    get credentialsParameter(): string;
    set credentialsParameter(value: string);
    resetCredentialsParameter(): void;
    get credentialsParameterInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#type BatchJobDefinition#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirementsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirementsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirementsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirementsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value_from BatchJobDefinition#value_from}
    */
    readonly valueFrom?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecretsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecretsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecretsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecretsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#hard_limit BatchJobDefinition#hard_limit}
    */
    readonly hardLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#soft_limit BatchJobDefinition#soft_limit}
    */
    readonly softLimit?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimitsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimitsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits | cdktn.IResolvable | undefined);
    private _hardLimit?;
    get hardLimit(): number;
    set hardLimit(value: number);
    resetHardLimit(): void;
    get hardLimitInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _softLimit?;
    get softLimit(): number;
    set softLimit(value: number);
    resetSoftLimit(): void;
    get softLimitInput(): number | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimitsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimitsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#command BatchJobDefinition#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#depends_on BatchJobDefinition#depends_on}
    */
    readonly dependsOn?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#environment BatchJobDefinition#environment}
    */
    readonly environment?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#essential BatchJobDefinition#essential}
    */
    readonly essential?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#firelens_configuration BatchJobDefinition#firelens_configuration}
    */
    readonly firelensConfiguration?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image BatchJobDefinition#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#linux_parameters BatchJobDefinition#linux_parameters}
    */
    readonly linuxParameters?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParameters;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#log_configuration BatchJobDefinition#log_configuration}
    */
    readonly logConfiguration?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_points BatchJobDefinition#mount_points}
    */
    readonly mountPoints?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#privileged BatchJobDefinition#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#readonly_root_filesystem BatchJobDefinition#readonly_root_filesystem}
    */
    readonly readonlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#repository_credentials BatchJobDefinition#repository_credentials}
    */
    readonly repositoryCredentials?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentials;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resource_requirements BatchJobDefinition#resource_requirements}
    */
    readonly resourceRequirements?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secrets BatchJobDefinition#secrets}
    */
    readonly secrets?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#start_timeout BatchJobDefinition#start_timeout}
    */
    readonly startTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#stop_timeout BatchJobDefinition#stop_timeout}
    */
    readonly stopTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ulimits BatchJobDefinition#ulimits}
    */
    readonly ulimits?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#user BatchJobDefinition#user}
    */
    readonly user?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers | cdktn.IResolvable | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _dependsOn;
    get dependsOn(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOnList;
    putDependsOn(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn[] | cdktn.IResolvable): void;
    resetDependsOn(): void;
    get dependsOnInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersDependsOn[] | undefined;
    private _environment;
    get environment(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironmentList;
    putEnvironment(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment[] | cdktn.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersEnvironment[] | undefined;
    private _essential?;
    get essential(): boolean | cdktn.IResolvable;
    set essential(value: boolean | cdktn.IResolvable);
    resetEssential(): void;
    get essentialInput(): boolean | cdktn.IResolvable | undefined;
    private _firelensConfiguration;
    get firelensConfiguration(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfigurationOutputReference;
    putFirelensConfiguration(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfiguration): void;
    resetFirelensConfiguration(): void;
    get firelensConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersFirelensConfiguration | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _linuxParameters;
    get linuxParameters(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParametersOutputReference;
    putLinuxParameters(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParameters): void;
    resetLinuxParameters(): void;
    get linuxParametersInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLinuxParameters | undefined;
    private _logConfiguration;
    get logConfiguration(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfigurationOutputReference;
    putLogConfiguration(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfiguration): void;
    resetLogConfiguration(): void;
    get logConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersLogConfiguration | undefined;
    private _mountPoints;
    get mountPoints(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPointsList;
    putMountPoints(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints[] | cdktn.IResolvable): void;
    resetMountPoints(): void;
    get mountPointsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersMountPoints[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readonlyRootFilesystem?;
    get readonlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readonlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadonlyRootFilesystem(): void;
    get readonlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _repositoryCredentials;
    get repositoryCredentials(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentialsOutputReference;
    putRepositoryCredentials(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentials): void;
    resetRepositoryCredentials(): void;
    get repositoryCredentialsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersRepositoryCredentials | undefined;
    private _resourceRequirements;
    get resourceRequirements(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirementsList;
    putResourceRequirements(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements[] | cdktn.IResolvable): void;
    resetResourceRequirements(): void;
    get resourceRequirementsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersResourceRequirements[] | undefined;
    private _secrets;
    get secrets(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecretsList;
    putSecrets(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets[] | cdktn.IResolvable): void;
    resetSecrets(): void;
    get secretsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersSecrets[] | undefined;
    private _startTimeout?;
    get startTimeout(): number;
    set startTimeout(value: number);
    resetStartTimeout(): void;
    get startTimeoutInput(): number | undefined;
    private _stopTimeout?;
    get stopTimeout(): number;
    set stopTimeout(value: number);
    resetStopTimeout(): void;
    get stopTimeoutInput(): number | undefined;
    private _ulimits;
    get ulimits(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimitsList;
    putUlimits(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits[] | cdktn.IResolvable): void;
    resetUlimits(): void;
    get ulimitsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersUlimits[] | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#access_point_id BatchJobDefinition#access_point_id}
    */
    readonly accessPointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#iam BatchJobDefinition#iam}
    */
    readonly iam?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | cdktn.IResolvable | undefined);
    private _accessPointId?;
    get accessPointId(): string;
    set accessPointId(value: string);
    resetAccessPointId(): void;
    get accessPointIdInput(): string | undefined;
    private _iam?;
    get iam(): string;
    set iam(value: string);
    resetIam(): void;
    get iamInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#authorization_config BatchJobDefinition#authorization_config}
    */
    readonly authorizationConfig?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#file_system_id BatchJobDefinition#file_system_id}
    */
    readonly fileSystemId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#root_directory BatchJobDefinition#root_directory}
    */
    readonly rootDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption BatchJobDefinition#transit_encryption}
    */
    readonly transitEncryption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption_port BatchJobDefinition#transit_encryption_port}
    */
    readonly transitEncryptionPort?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | cdktn.IResolvable | undefined);
    private _authorizationConfig;
    get authorizationConfig(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfigOutputReference;
    putAuthorizationConfig(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig): void;
    resetAuthorizationConfig(): void;
    get authorizationConfigInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationAuthorizationConfig | undefined;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    resetFileSystemId(): void;
    get fileSystemIdInput(): string | undefined;
    private _rootDirectory?;
    get rootDirectory(): string;
    set rootDirectory(value: string);
    resetRootDirectory(): void;
    get rootDirectoryInput(): string | undefined;
    private _transitEncryption?;
    get transitEncryption(): string;
    set transitEncryption(value: string);
    resetTransitEncryption(): void;
    get transitEncryptionInput(): string | undefined;
    private _transitEncryptionPort?;
    get transitEncryptionPort(): number;
    set transitEncryptionPort(value: number);
    resetTransitEncryptionPort(): void;
    get transitEncryptionPortInput(): number | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHost {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#source_path BatchJobDefinition#source_path}
    */
    readonly sourcePath?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHostToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHost | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHostToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHost | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHostOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHost | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHost | cdktn.IResolvable | undefined);
    private _sourcePath?;
    get sourcePath(): string;
    set sourcePath(value: string);
    resetSourcePath(): void;
    get sourcePathInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#access_point_arn BatchJobDefinition#access_point_arn}
    */
    readonly accessPointArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#file_system_arn BatchJobDefinition#file_system_arn}
    */
    readonly fileSystemArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#root_directory BatchJobDefinition#root_directory}
    */
    readonly rootDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#transit_encryption_port BatchJobDefinition#transit_encryption_port}
    */
    readonly transitEncryptionPort?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfigurationToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfigurationToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | cdktn.IResolvable | undefined);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    resetAccessPointArn(): void;
    get accessPointArnInput(): string | undefined;
    private _fileSystemArn?;
    get fileSystemArn(): string;
    set fileSystemArn(value: string);
    resetFileSystemArn(): void;
    get fileSystemArnInput(): string | undefined;
    private _rootDirectory?;
    get rootDirectory(): string;
    set rootDirectory(value: string);
    resetRootDirectory(): void;
    get rootDirectoryInput(): string | undefined;
    private _transitEncryptionPort?;
    get transitEncryptionPort(): number;
    set transitEncryptionPort(value: number);
    resetTransitEncryptionPort(): void;
    get transitEncryptionPortInput(): number | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#efs_volume_configuration BatchJobDefinition#efs_volume_configuration}
    */
    readonly efsVolumeConfiguration?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host BatchJobDefinition#host}
    */
    readonly host?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHost;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#s3_files_volume_configuration BatchJobDefinition#s3_files_volume_configuration}
    */
    readonly s3FilesVolumeConfiguration?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes | cdktn.IResolvable | undefined);
    private _efsVolumeConfiguration;
    get efsVolumeConfiguration(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfigurationOutputReference;
    putEfsVolumeConfiguration(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration): void;
    resetEfsVolumeConfiguration(): void;
    get efsVolumeConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesEfsVolumeConfiguration | undefined;
    private _host;
    get host(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHostOutputReference;
    putHost(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHost): void;
    resetHost(): void;
    get hostInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesHost | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _s3FilesVolumeConfiguration;
    get s3FilesVolumeConfiguration(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfigurationOutputReference;
    putS3FilesVolumeConfiguration(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration): void;
    resetS3FilesVolumeConfiguration(): void;
    get s3FilesVolumeConfigurationInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesS3FilesVolumeConfiguration | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#containers BatchJobDefinition#containers}
    */
    readonly containers?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#enable_execute_command BatchJobDefinition#enable_execute_command}
    */
    readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#execution_role_arn BatchJobDefinition#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ipc_mode BatchJobDefinition#ipc_mode}
    */
    readonly ipcMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#pid_mode BatchJobDefinition#pid_mode}
    */
    readonly pidMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#task_role_arn BatchJobDefinition#task_role_arn}
    */
    readonly taskRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volumes BatchJobDefinition#volumes}
    */
    readonly volumes?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties | cdktn.IResolvable | undefined);
    private _containers;
    get containers(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainersList;
    putContainers(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers[] | cdktn.IResolvable): void;
    resetContainers(): void;
    get containersInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesContainers[] | undefined;
    private _enableExecuteCommand?;
    get enableExecuteCommand(): boolean | cdktn.IResolvable;
    set enableExecuteCommand(value: boolean | cdktn.IResolvable);
    resetEnableExecuteCommand(): void;
    get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _ipcMode?;
    get ipcMode(): string;
    set ipcMode(value: string);
    resetIpcMode(): void;
    get ipcModeInput(): string | undefined;
    private _pidMode?;
    get pidMode(): string;
    set pidMode(value: string);
    resetPidMode(): void;
    get pidModeInput(): string | undefined;
    private _taskRoleArn?;
    get taskRoleArn(): string;
    set taskRoleArn(value: string);
    resetTaskRoleArn(): void;
    get taskRoleArnInput(): string | undefined;
    private _volumes;
    get volumes(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumesList;
    putVolumes(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesVolumes[] | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#task_properties BatchJobDefinition#task_properties}
    */
    readonly taskProperties?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsProperties | cdktn.IResolvable | undefined);
    private _taskProperties;
    get taskProperties(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskPropertiesList;
    putTaskProperties(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties[] | cdktn.IResolvable): void;
    resetTaskProperties(): void;
    get taskPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesTaskProperties[] | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnvToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnvToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnvList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnvOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#limits BatchJobDefinition#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#requests BatchJobDefinition#requests}
    */
    readonly requests?: {
        [key: string]: string;
    };
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResourcesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResources | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResourcesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResources | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResources | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResources | cdktn.IResolvable | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests?;
    get requests(): {
        [key: string]: string;
    };
    set requests(value: {
        [key: string]: string;
    });
    resetRequests(): void;
    get requestsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#allow_privilege_escalation BatchJobDefinition#allow_privilege_escalation}
    */
    readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#privileged BatchJobDefinition#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only_root_filesystem BatchJobDefinition#read_only_root_filesystem}
    */
    readonly readOnlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_group BatchJobDefinition#run_as_group}
    */
    readonly runAsGroup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_non_root BatchJobDefinition#run_as_non_root}
    */
    readonly runAsNonRoot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_user BatchJobDefinition#run_as_user}
    */
    readonly runAsUser?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContextToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContext | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContextToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContext | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContext | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContext | cdktn.IResolvable | undefined);
    private _allowPrivilegeEscalation?;
    get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
    set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
    resetAllowPrivilegeEscalation(): void;
    get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readOnlyRootFilesystem?;
    get readOnlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readOnlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadOnlyRootFilesystem(): void;
    get readOnlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsGroup?;
    get runAsGroup(): number;
    set runAsGroup(value: number);
    resetRunAsGroup(): void;
    get runAsGroupInput(): number | undefined;
    private _runAsNonRoot?;
    get runAsNonRoot(): boolean | cdktn.IResolvable;
    set runAsNonRoot(value: boolean | cdktn.IResolvable);
    resetRunAsNonRoot(): void;
    get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUser?;
    get runAsUser(): number;
    set runAsUser(value: number);
    resetRunAsUser(): void;
    get runAsUserInput(): number | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_path BatchJobDefinition#mount_path}
    */
    readonly mountPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#sub_path BatchJobDefinition#sub_path}
    */
    readonly subPath?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMountsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMountsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMountsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMountsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#args BatchJobDefinition#args}
    */
    readonly args?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#command BatchJobDefinition#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#env BatchJobDefinition#env}
    */
    readonly env?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image BatchJobDefinition#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image_pull_policy BatchJobDefinition#image_pull_policy}
    */
    readonly imagePullPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resources BatchJobDefinition#resources}
    */
    readonly resources?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResources;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#security_context BatchJobDefinition#security_context}
    */
    readonly securityContext?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volume_mounts BatchJobDefinition#volume_mounts}
    */
    readonly volumeMounts?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _env;
    get env(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnvList;
    putEnv(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersEnv[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _imagePullPolicy?;
    get imagePullPolicy(): string;
    set imagePullPolicy(value: string);
    resetImagePullPolicy(): void;
    get imagePullPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _resources;
    get resources(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResourcesOutputReference;
    putResources(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResources): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersResources | undefined;
    private _securityContext;
    get securityContext(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContextOutputReference;
    putSecurityContext(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContext): void;
    resetSecurityContext(): void;
    get securityContextInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersSecurityContext | undefined;
    private _volumeMounts;
    get volumeMounts(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMountsList;
    putVolumeMounts(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersVolumeMounts[] | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecretsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecretsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecretsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecretsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#value BatchJobDefinition#value}
    */
    readonly value?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnvToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnvToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnvList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnvOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#limits BatchJobDefinition#limits}
    */
    readonly limits?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#requests BatchJobDefinition#requests}
    */
    readonly requests?: {
        [key: string]: string;
    };
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResourcesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResources | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResourcesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResources | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResources | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResources | cdktn.IResolvable | undefined);
    private _limits?;
    get limits(): {
        [key: string]: string;
    };
    set limits(value: {
        [key: string]: string;
    });
    resetLimits(): void;
    get limitsInput(): {
        [key: string]: string;
    } | undefined;
    private _requests?;
    get requests(): {
        [key: string]: string;
    };
    set requests(value: {
        [key: string]: string;
    });
    resetRequests(): void;
    get requestsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#allow_privilege_escalation BatchJobDefinition#allow_privilege_escalation}
    */
    readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#privileged BatchJobDefinition#privileged}
    */
    readonly privileged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only_root_filesystem BatchJobDefinition#read_only_root_filesystem}
    */
    readonly readOnlyRootFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_group BatchJobDefinition#run_as_group}
    */
    readonly runAsGroup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_non_root BatchJobDefinition#run_as_non_root}
    */
    readonly runAsNonRoot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#run_as_user BatchJobDefinition#run_as_user}
    */
    readonly runAsUser?: number;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContextToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContext | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContextToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContext | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContext | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContext | cdktn.IResolvable | undefined);
    private _allowPrivilegeEscalation?;
    get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
    set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
    resetAllowPrivilegeEscalation(): void;
    get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
    private _privileged?;
    get privileged(): boolean | cdktn.IResolvable;
    set privileged(value: boolean | cdktn.IResolvable);
    resetPrivileged(): void;
    get privilegedInput(): boolean | cdktn.IResolvable | undefined;
    private _readOnlyRootFilesystem?;
    get readOnlyRootFilesystem(): boolean | cdktn.IResolvable;
    set readOnlyRootFilesystem(value: boolean | cdktn.IResolvable);
    resetReadOnlyRootFilesystem(): void;
    get readOnlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsGroup?;
    get runAsGroup(): number;
    set runAsGroup(value: number);
    resetRunAsGroup(): void;
    get runAsGroupInput(): number | undefined;
    private _runAsNonRoot?;
    get runAsNonRoot(): boolean | cdktn.IResolvable;
    set runAsNonRoot(value: boolean | cdktn.IResolvable);
    resetRunAsNonRoot(): void;
    get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
    private _runAsUser?;
    get runAsUser(): number;
    set runAsUser(value: number);
    resetRunAsUser(): void;
    get runAsUserInput(): number | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#mount_path BatchJobDefinition#mount_path}
    */
    readonly mountPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#sub_path BatchJobDefinition#sub_path}
    */
    readonly subPath?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMountsToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMountsToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMountsList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMountsOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#args BatchJobDefinition#args}
    */
    readonly args?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#command BatchJobDefinition#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#env BatchJobDefinition#env}
    */
    readonly env?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image BatchJobDefinition#image}
    */
    readonly image?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image_pull_policy BatchJobDefinition#image_pull_policy}
    */
    readonly imagePullPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#resources BatchJobDefinition#resources}
    */
    readonly resources?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResources;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#security_context BatchJobDefinition#security_context}
    */
    readonly securityContext?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volume_mounts BatchJobDefinition#volume_mounts}
    */
    readonly volumeMounts?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _env;
    get env(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnvList;
    putEnv(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersEnv[] | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _imagePullPolicy?;
    get imagePullPolicy(): string;
    set imagePullPolicy(value: string);
    resetImagePullPolicy(): void;
    get imagePullPolicyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _resources;
    get resources(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResourcesOutputReference;
    putResources(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResources): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersResources | undefined;
    private _securityContext;
    get securityContext(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContextOutputReference;
    putSecurityContext(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContext): void;
    resetSecurityContext(): void;
    get securityContextInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersSecurityContext | undefined;
    private _volumeMounts;
    get volumeMounts(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMountsList;
    putVolumeMounts(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersVolumeMounts[] | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#annotations BatchJobDefinition#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#labels BatchJobDefinition#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#namespace BatchJobDefinition#namespace}
    */
    readonly namespace?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadataToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadata | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadataToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadata | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadata | cdktn.IResolvable | undefined);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDir {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#medium BatchJobDefinition#medium}
    */
    readonly medium?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#size_limit BatchJobDefinition#size_limit}
    */
    readonly sizeLimit?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDirToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDir | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDirToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDir | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDir | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDir | cdktn.IResolvable | undefined);
    private _medium?;
    get medium(): string;
    set medium(value: string);
    resetMedium(): void;
    get mediumInput(): string | undefined;
    private _sizeLimit?;
    get sizeLimit(): string;
    set sizeLimit(value: string);
    resetSizeLimit(): void;
    get sizeLimitInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPath {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#path BatchJobDefinition#path}
    */
    readonly path?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPathToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPath | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPathToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPath | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPath | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPath | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaim {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#claim_name BatchJobDefinition#claim_name}
    */
    readonly claimName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#read_only BatchJobDefinition#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaimToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaimToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaimOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | cdktn.IResolvable | undefined);
    private _claimName?;
    get claimName(): string;
    set claimName(value: string);
    resetClaimName(): void;
    get claimNameInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#optional BatchJobDefinition#optional}
    */
    readonly optional?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secret_name BatchJobDefinition#secret_name}
    */
    readonly secretName?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecretToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecret | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecretToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecret | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecret | cdktn.IResolvable | undefined);
    private _optional?;
    get optional(): boolean | cdktn.IResolvable;
    set optional(value: boolean | cdktn.IResolvable);
    resetOptional(): void;
    get optionalInput(): boolean | cdktn.IResolvable | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    resetSecretName(): void;
    get secretNameInput(): string | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#empty_dir BatchJobDefinition#empty_dir}
    */
    readonly emptyDir?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDir;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host_path BatchJobDefinition#host_path}
    */
    readonly hostPath?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPath;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#name BatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#persistent_volume_claim BatchJobDefinition#persistent_volume_claim}
    */
    readonly persistentVolumeClaim?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaim;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#secret BatchJobDefinition#secret}
    */
    readonly secret?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecret;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes | cdktn.IResolvable | undefined);
    private _emptyDir;
    get emptyDir(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDirOutputReference;
    putEmptyDir(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDir): void;
    resetEmptyDir(): void;
    get emptyDirInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesEmptyDir | undefined;
    private _hostPath;
    get hostPath(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPathOutputReference;
    putHostPath(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPath): void;
    resetHostPath(): void;
    get hostPathInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesHostPath | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _persistentVolumeClaim;
    get persistentVolumeClaim(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaimOutputReference;
    putPersistentVolumeClaim(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaim): void;
    resetPersistentVolumeClaim(): void;
    get persistentVolumeClaimInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesPersistentVolumeClaim | undefined;
    private _secret;
    get secret(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecretOutputReference;
    putSecret(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesSecret | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesOutputReference;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#containers BatchJobDefinition#containers}
    */
    readonly containers?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#dns_policy BatchJobDefinition#dns_policy}
    */
    readonly dnsPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#host_network BatchJobDefinition#host_network}
    */
    readonly hostNetwork?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#image_pull_secrets BatchJobDefinition#image_pull_secrets}
    */
    readonly imagePullSecrets?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#init_containers BatchJobDefinition#init_containers}
    */
    readonly initContainers?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#metadata BatchJobDefinition#metadata}
    */
    readonly metadata?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadata;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#service_account_name BatchJobDefinition#service_account_name}
    */
    readonly serviceAccountName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#share_process_namespace BatchJobDefinition#share_process_namespace}
    */
    readonly shareProcessNamespace?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#volumes BatchJobDefinition#volumes}
    */
    readonly volumes?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodProperties | cdktn.IResolvable | undefined);
    private _containers;
    get containers(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainersList;
    putContainers(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers[] | cdktn.IResolvable): void;
    resetContainers(): void;
    get containersInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesContainers[] | undefined;
    private _dnsPolicy?;
    get dnsPolicy(): string;
    set dnsPolicy(value: string);
    resetDnsPolicy(): void;
    get dnsPolicyInput(): string | undefined;
    private _hostNetwork?;
    get hostNetwork(): boolean | cdktn.IResolvable;
    set hostNetwork(value: boolean | cdktn.IResolvable);
    resetHostNetwork(): void;
    get hostNetworkInput(): boolean | cdktn.IResolvable | undefined;
    private _imagePullSecrets;
    get imagePullSecrets(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecretsList;
    putImagePullSecrets(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets[] | cdktn.IResolvable): void;
    resetImagePullSecrets(): void;
    get imagePullSecretsInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesImagePullSecrets[] | undefined;
    private _initContainers;
    get initContainers(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainersList;
    putInitContainers(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers[] | cdktn.IResolvable): void;
    resetInitContainers(): void;
    get initContainersInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesInitContainers[] | undefined;
    private _metadata;
    get metadata(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadataOutputReference;
    putMetadata(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadata): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesMetadata | undefined;
    private _serviceAccountName?;
    get serviceAccountName(): string;
    set serviceAccountName(value: string);
    resetServiceAccountName(): void;
    get serviceAccountNameInput(): string | undefined;
    private _shareProcessNamespace?;
    get shareProcessNamespace(): boolean | cdktn.IResolvable;
    set shareProcessNamespace(value: boolean | cdktn.IResolvable);
    resetShareProcessNamespace(): void;
    get shareProcessNamespaceInput(): boolean | cdktn.IResolvable | undefined;
    private _volumes;
    get volumes(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumesList;
    putVolumes(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesVolumes[] | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangePropertiesEksProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#pod_properties BatchJobDefinition#pod_properties}
    */
    readonly podProperties?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodProperties;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksProperties | cdktn.IResolvable | undefined);
    private _podProperties;
    get podProperties(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodPropertiesOutputReference;
    putPodProperties(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodProperties): void;
    resetPodProperties(): void;
    get podPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesPodProperties | undefined;
}
export interface BatchJobDefinitionNodePropertiesNodeRangeProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#consumable_resource_properties BatchJobDefinition#consumable_resource_properties}
    */
    readonly consumableResourceProperties?: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourceProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#container BatchJobDefinition#container}
    */
    readonly container?: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainer;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#ecs_properties BatchJobDefinition#ecs_properties}
    */
    readonly ecsProperties?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#eks_properties BatchJobDefinition#eks_properties}
    */
    readonly eksProperties?: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#instance_types BatchJobDefinition#instance_types}
    */
    readonly instanceTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#target_nodes BatchJobDefinition#target_nodes}
    */
    readonly targetNodes?: string;
}
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesToTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangeProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesNodeRangePropertiesToHclTerraform(struct?: BatchJobDefinitionNodePropertiesNodeRangeProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionNodePropertiesNodeRangeProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodePropertiesNodeRangeProperties | cdktn.IResolvable | undefined);
    private _consumableResourceProperties;
    get consumableResourceProperties(): BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourcePropertiesOutputReference;
    putConsumableResourceProperties(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourceProperties): void;
    resetConsumableResourceProperties(): void;
    get consumableResourcePropertiesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesConsumableResourceProperties | undefined;
    private _container;
    get container(): BatchJobDefinitionNodePropertiesNodeRangePropertiesContainerOutputReference;
    putContainer(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesContainer): void;
    resetContainer(): void;
    get containerInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesContainer | undefined;
    private _ecsProperties;
    get ecsProperties(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsPropertiesOutputReference;
    putEcsProperties(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsProperties): void;
    resetEcsProperties(): void;
    get ecsPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEcsProperties | undefined;
    private _eksProperties;
    get eksProperties(): BatchJobDefinitionNodePropertiesNodeRangePropertiesEksPropertiesOutputReference;
    putEksProperties(value: BatchJobDefinitionNodePropertiesNodeRangePropertiesEksProperties): void;
    resetEksProperties(): void;
    get eksPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangePropertiesEksProperties | undefined;
    private _instanceTypes?;
    get instanceTypes(): string[];
    set instanceTypes(value: string[]);
    resetInstanceTypes(): void;
    get instanceTypesInput(): string[] | undefined;
    private _targetNodes?;
    get targetNodes(): string;
    set targetNodes(value: string);
    resetTargetNodes(): void;
    get targetNodesInput(): string | undefined;
}
export declare class BatchJobDefinitionNodePropertiesNodeRangePropertiesList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionNodePropertiesNodeRangeProperties[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionNodePropertiesNodeRangePropertiesOutputReference;
}
export interface BatchJobDefinitionNodeProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#main_node BatchJobDefinition#main_node}
    */
    readonly mainNode?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#node_range_properties BatchJobDefinition#node_range_properties}
    */
    readonly nodeRangeProperties?: BatchJobDefinitionNodePropertiesNodeRangeProperties[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#num_nodes BatchJobDefinition#num_nodes}
    */
    readonly numNodes?: number;
}
export declare function batchJobDefinitionNodePropertiesToTerraform(struct?: BatchJobDefinitionNodeProperties | cdktn.IResolvable): any;
export declare function batchJobDefinitionNodePropertiesToHclTerraform(struct?: BatchJobDefinitionNodeProperties | cdktn.IResolvable): any;
export declare class BatchJobDefinitionNodePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionNodeProperties | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionNodeProperties | cdktn.IResolvable | undefined);
    private _mainNode?;
    get mainNode(): number;
    set mainNode(value: number);
    resetMainNode(): void;
    get mainNodeInput(): number | undefined;
    private _nodeRangeProperties;
    get nodeRangeProperties(): BatchJobDefinitionNodePropertiesNodeRangePropertiesList;
    putNodeRangeProperties(value: BatchJobDefinitionNodePropertiesNodeRangeProperties[] | cdktn.IResolvable): void;
    resetNodeRangeProperties(): void;
    get nodeRangePropertiesInput(): cdktn.IResolvable | BatchJobDefinitionNodePropertiesNodeRangeProperties[] | undefined;
    private _numNodes?;
    get numNodes(): number;
    set numNodes(value: number);
    resetNumNodes(): void;
    get numNodesInput(): number | undefined;
}
export interface BatchJobDefinitionResourceRetentionPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#skip_deregister_on_update BatchJobDefinition#skip_deregister_on_update}
    */
    readonly skipDeregisterOnUpdate?: boolean | cdktn.IResolvable;
}
export declare function batchJobDefinitionResourceRetentionPolicyToTerraform(struct?: BatchJobDefinitionResourceRetentionPolicy | cdktn.IResolvable): any;
export declare function batchJobDefinitionResourceRetentionPolicyToHclTerraform(struct?: BatchJobDefinitionResourceRetentionPolicy | cdktn.IResolvable): any;
export declare class BatchJobDefinitionResourceRetentionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionResourceRetentionPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionResourceRetentionPolicy | cdktn.IResolvable | undefined);
    private _skipDeregisterOnUpdate?;
    get skipDeregisterOnUpdate(): boolean | cdktn.IResolvable;
    set skipDeregisterOnUpdate(value: boolean | cdktn.IResolvable);
    resetSkipDeregisterOnUpdate(): void;
    get skipDeregisterOnUpdateInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BatchJobDefinitionRetryStrategyEvaluateOnExit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#action BatchJobDefinition#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#on_exit_code BatchJobDefinition#on_exit_code}
    */
    readonly onExitCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#on_reason BatchJobDefinition#on_reason}
    */
    readonly onReason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#on_status_reason BatchJobDefinition#on_status_reason}
    */
    readonly onStatusReason?: string;
}
export declare function batchJobDefinitionRetryStrategyEvaluateOnExitToTerraform(struct?: BatchJobDefinitionRetryStrategyEvaluateOnExit | cdktn.IResolvable): any;
export declare function batchJobDefinitionRetryStrategyEvaluateOnExitToHclTerraform(struct?: BatchJobDefinitionRetryStrategyEvaluateOnExit | cdktn.IResolvable): any;
export declare class BatchJobDefinitionRetryStrategyEvaluateOnExitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobDefinitionRetryStrategyEvaluateOnExit | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionRetryStrategyEvaluateOnExit | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _onExitCode?;
    get onExitCode(): string;
    set onExitCode(value: string);
    resetOnExitCode(): void;
    get onExitCodeInput(): string | undefined;
    private _onReason?;
    get onReason(): string;
    set onReason(value: string);
    resetOnReason(): void;
    get onReasonInput(): string | undefined;
    private _onStatusReason?;
    get onStatusReason(): string;
    set onStatusReason(value: string);
    resetOnStatusReason(): void;
    get onStatusReasonInput(): string | undefined;
}
export declare class BatchJobDefinitionRetryStrategyEvaluateOnExitList extends cdktn.ComplexList {
    internalValue?: BatchJobDefinitionRetryStrategyEvaluateOnExit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobDefinitionRetryStrategyEvaluateOnExitOutputReference;
}
export interface BatchJobDefinitionRetryStrategy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#attempts BatchJobDefinition#attempts}
    */
    readonly attempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#evaluate_on_exit BatchJobDefinition#evaluate_on_exit}
    */
    readonly evaluateOnExit?: BatchJobDefinitionRetryStrategyEvaluateOnExit[] | cdktn.IResolvable;
}
export declare function batchJobDefinitionRetryStrategyToTerraform(struct?: BatchJobDefinitionRetryStrategy | cdktn.IResolvable): any;
export declare function batchJobDefinitionRetryStrategyToHclTerraform(struct?: BatchJobDefinitionRetryStrategy | cdktn.IResolvable): any;
export declare class BatchJobDefinitionRetryStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionRetryStrategy | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionRetryStrategy | cdktn.IResolvable | undefined);
    private _attempts?;
    get attempts(): number;
    set attempts(value: number);
    resetAttempts(): void;
    get attemptsInput(): number | undefined;
    private _evaluateOnExit;
    get evaluateOnExit(): BatchJobDefinitionRetryStrategyEvaluateOnExitList;
    putEvaluateOnExit(value: BatchJobDefinitionRetryStrategyEvaluateOnExit[] | cdktn.IResolvable): void;
    resetEvaluateOnExit(): void;
    get evaluateOnExitInput(): cdktn.IResolvable | BatchJobDefinitionRetryStrategyEvaluateOnExit[] | undefined;
}
export interface BatchJobDefinitionTimeout {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#attempt_duration_seconds BatchJobDefinition#attempt_duration_seconds}
    */
    readonly attemptDurationSeconds?: number;
}
export declare function batchJobDefinitionTimeoutToTerraform(struct?: BatchJobDefinitionTimeout | cdktn.IResolvable): any;
export declare function batchJobDefinitionTimeoutToHclTerraform(struct?: BatchJobDefinitionTimeout | cdktn.IResolvable): any;
export declare class BatchJobDefinitionTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchJobDefinitionTimeout | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobDefinitionTimeout | cdktn.IResolvable | undefined);
    private _attemptDurationSeconds?;
    get attemptDurationSeconds(): number;
    set attemptDurationSeconds(value: number);
    resetAttemptDurationSeconds(): void;
    get attemptDurationSecondsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition awscc_batch_job_definition}
*/
export declare class BatchJobDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_batch_job_definition";
    /**
    * Generates CDKTN code for importing a BatchJobDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BatchJobDefinition to import
    * @param importFromId The id of the existing BatchJobDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BatchJobDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_definition awscc_batch_job_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BatchJobDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: BatchJobDefinitionConfig);
    private _consumableResourceProperties;
    get consumableResourceProperties(): BatchJobDefinitionConsumableResourcePropertiesOutputReference;
    putConsumableResourceProperties(value: BatchJobDefinitionConsumableResourceProperties): void;
    resetConsumableResourceProperties(): void;
    get consumableResourcePropertiesInput(): cdktn.IResolvable | BatchJobDefinitionConsumableResourceProperties | undefined;
    private _containerProperties;
    get containerProperties(): BatchJobDefinitionContainerPropertiesOutputReference;
    putContainerProperties(value: BatchJobDefinitionContainerProperties): void;
    resetContainerProperties(): void;
    get containerPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionContainerProperties | undefined;
    private _ecsProperties;
    get ecsProperties(): BatchJobDefinitionEcsPropertiesOutputReference;
    putEcsProperties(value: BatchJobDefinitionEcsProperties): void;
    resetEcsProperties(): void;
    get ecsPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionEcsProperties | undefined;
    private _eksProperties;
    get eksProperties(): BatchJobDefinitionEksPropertiesOutputReference;
    putEksProperties(value: BatchJobDefinitionEksProperties): void;
    resetEksProperties(): void;
    get eksPropertiesInput(): cdktn.IResolvable | BatchJobDefinitionEksProperties | undefined;
    get id(): string;
    get jobDefinitionArn(): string;
    private _jobDefinitionName?;
    get jobDefinitionName(): string;
    set jobDefinitionName(value: string);
    resetJobDefinitionName(): void;
    get jobDefinitionNameInput(): string | undefined;
    private _nodeProperties;
    get nodeProperties(): BatchJobDefinitionNodePropertiesOutputReference;
    putNodeProperties(value: BatchJobDefinitionNodeProperties): void;
    resetNodeProperties(): void;
    get nodePropertiesInput(): cdktn.IResolvable | BatchJobDefinitionNodeProperties | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _platformCapabilities?;
    get platformCapabilities(): string[];
    set platformCapabilities(value: string[]);
    resetPlatformCapabilities(): void;
    get platformCapabilitiesInput(): string[] | undefined;
    private _propagateTags?;
    get propagateTags(): boolean | cdktn.IResolvable;
    set propagateTags(value: boolean | cdktn.IResolvable);
    resetPropagateTags(): void;
    get propagateTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _resourceRetentionPolicy;
    get resourceRetentionPolicy(): BatchJobDefinitionResourceRetentionPolicyOutputReference;
    putResourceRetentionPolicy(value: BatchJobDefinitionResourceRetentionPolicy): void;
    resetResourceRetentionPolicy(): void;
    get resourceRetentionPolicyInput(): cdktn.IResolvable | BatchJobDefinitionResourceRetentionPolicy | undefined;
    private _retryStrategy;
    get retryStrategy(): BatchJobDefinitionRetryStrategyOutputReference;
    putRetryStrategy(value: BatchJobDefinitionRetryStrategy): void;
    resetRetryStrategy(): void;
    get retryStrategyInput(): cdktn.IResolvable | BatchJobDefinitionRetryStrategy | undefined;
    private _schedulingPriority?;
    get schedulingPriority(): number;
    set schedulingPriority(value: number);
    resetSchedulingPriority(): void;
    get schedulingPriorityInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeout;
    get timeout(): BatchJobDefinitionTimeoutOutputReference;
    putTimeout(value: BatchJobDefinitionTimeout): void;
    resetTimeout(): void;
    get timeoutInput(): cdktn.IResolvable | BatchJobDefinitionTimeout | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
