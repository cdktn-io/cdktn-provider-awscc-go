/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchLogAlarmConfig extends cdktn.TerraformMetaArguments {
    /**
    * The number of log lines to include in alarm notifications. Valid values are 0 to 50.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#action_log_line_count CloudwatchLogAlarm#action_log_line_count}
    */
    readonly actionLogLineCount?: number;
    /**
    * The ARN of the IAM role that grants CloudWatch permissions to fetch log lines for alarm notifications. Required when ActionLogLineCount is greater than 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#action_log_line_role_arn CloudwatchLogAlarm#action_log_line_role_arn}
    */
    readonly actionLogLineRoleArn?: string;
    /**
    * Indicates whether actions should be executed during any changes to the alarm state. The default is TRUE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#actions_enabled CloudwatchLogAlarm#actions_enabled}
    */
    readonly actionsEnabled?: boolean | cdktn.IResolvable;
    /**
    * The list of actions to execute when this alarm transitions into an ALARM state from any other state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#alarm_actions CloudwatchLogAlarm#alarm_actions}
    */
    readonly alarmActions?: string[];
    /**
    * The description of the log alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#alarm_description CloudwatchLogAlarm#alarm_description}
    */
    readonly alarmDescription?: string;
    /**
    * The name of the log alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#alarm_name CloudwatchLogAlarm#alarm_name}
    */
    readonly alarmName?: string;
    /**
    * The arithmetic operation to use when comparing the specified threshold and the query results. Valid values are GreaterThanOrEqualToThreshold, GreaterThanThreshold, LessThanThreshold, and LessThanOrEqualToThreshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#comparison_operator CloudwatchLogAlarm#comparison_operator}
    */
    readonly comparisonOperator: string;
    /**
    * The actions to execute when this alarm transitions to the INSUFFICIENT_DATA state from any other state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#insufficient_data_actions CloudwatchLogAlarm#insufficient_data_actions}
    */
    readonly insufficientDataActions?: string[];
    /**
    * The actions to execute when this alarm transitions to the OK state from any other state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#ok_actions CloudwatchLogAlarm#ok_actions}
    */
    readonly okActions?: string[];
    /**
    * The number of query results that must be breaching to trigger the alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#query_results_to_alarm CloudwatchLogAlarm#query_results_to_alarm}
    */
    readonly queryResultsToAlarm: number;
    /**
    * The number of query results over which data is compared to the specified threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#query_results_to_evaluate CloudwatchLogAlarm#query_results_to_evaluate}
    */
    readonly queryResultsToEvaluate: number;
    /**
    * The scheduled query configuration for the log alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#scheduled_query_configuration CloudwatchLogAlarm#scheduled_query_configuration}
    */
    readonly scheduledQueryConfiguration: CloudwatchLogAlarmScheduledQueryConfiguration;
    /**
    * A list of key-value pairs to associate with the log alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#tags CloudwatchLogAlarm#tags}
    */
    readonly tags?: CloudwatchLogAlarmTags[] | cdktn.IResolvable;
    /**
    * The value to compare against the results of the scheduled query evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#threshold CloudwatchLogAlarm#threshold}
    */
    readonly threshold: number;
    /**
    * Sets how this alarm is to handle missing data points. Valid values are breaching, notBreaching, ignore, and missing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#treat_missing_data CloudwatchLogAlarm#treat_missing_data}
    */
    readonly treatMissingData?: string;
    /**
    * The warm-up configuration for the alarm. During the warm-up period, the alarm stays in INSUFFICIENT_DATA and doesn't perform alarm actions. For more information, see Alarm warm-up periods in the Amazon CloudWatch User Guide.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#warm_up_configuration CloudwatchLogAlarm#warm_up_configuration}
    */
    readonly warmUpConfiguration?: CloudwatchLogAlarmWarmUpConfiguration;
}
export interface CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfiguration {
    /**
    * The number of seconds into the past to end the query window. Must be a non-negative value and cannot exceed 2592000 seconds (30 days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#end_time_offset CloudwatchLogAlarm#end_time_offset}
    */
    readonly endTimeOffset?: number;
    /**
    * The expression that defines when the scheduled query runs, e.g. rate(1 minute).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#schedule_expression CloudwatchLogAlarm#schedule_expression}
    */
    readonly scheduleExpression: string;
    /**
    * The number of seconds into the past to start the query window. Must be a positive value and cannot exceed 2592000 seconds (30 days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#start_time_offset CloudwatchLogAlarm#start_time_offset}
    */
    readonly startTimeOffset: number;
}
export declare function cloudwatchLogAlarmScheduledQueryConfigurationScheduleConfigurationToTerraform(struct?: CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchLogAlarmScheduledQueryConfigurationScheduleConfigurationToHclTerraform(struct?: CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfiguration | cdktn.IResolvable | undefined);
    private _endTimeOffset?;
    get endTimeOffset(): number;
    set endTimeOffset(value: number);
    resetEndTimeOffset(): void;
    get endTimeOffsetInput(): number | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    get scheduleExpressionInput(): string | undefined;
    private _startTimeOffset?;
    get startTimeOffset(): number;
    set startTimeOffset(value: number);
    get startTimeOffsetInput(): number | undefined;
}
export interface CloudwatchLogAlarmScheduledQueryConfigurationTags {
    /**
    * A unique identifier for the tag. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#key CloudwatchLogAlarm#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#value CloudwatchLogAlarm#value}
    */
    readonly value?: string;
}
export declare function cloudwatchLogAlarmScheduledQueryConfigurationTagsToTerraform(struct?: CloudwatchLogAlarmScheduledQueryConfigurationTags | cdktn.IResolvable): any;
export declare function cloudwatchLogAlarmScheduledQueryConfigurationTagsToHclTerraform(struct?: CloudwatchLogAlarmScheduledQueryConfigurationTags | cdktn.IResolvable): any;
export declare class CloudwatchLogAlarmScheduledQueryConfigurationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogAlarmScheduledQueryConfigurationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogAlarmScheduledQueryConfigurationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchLogAlarmScheduledQueryConfigurationTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogAlarmScheduledQueryConfigurationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogAlarmScheduledQueryConfigurationTagsOutputReference;
}
export interface CloudwatchLogAlarmScheduledQueryConfiguration {
    /**
    * The aggregation expression for the scheduled query, e.g. count(*) or avg(latency) by host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#aggregation_expression CloudwatchLogAlarm#aggregation_expression}
    */
    readonly aggregationExpression: string;
    /**
    * The log groups to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#log_group_identifiers CloudwatchLogAlarm#log_group_identifiers}
    */
    readonly logGroupIdentifiers?: string[];
    /**
    * The query string to execute against the specified log groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#query_string CloudwatchLogAlarm#query_string}
    */
    readonly queryString: string;
    /**
    * The schedule configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#schedule_configuration CloudwatchLogAlarm#schedule_configuration}
    */
    readonly scheduleConfiguration: CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfiguration;
    /**
    * The ARN of the IAM role that grants permissions to execute the scheduled query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#scheduled_query_role_arn CloudwatchLogAlarm#scheduled_query_role_arn}
    */
    readonly scheduledQueryRoleArn: string;
    /**
    * A list of key-value pairs to associate with the scheduled query that backs the log alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#tags CloudwatchLogAlarm#tags}
    */
    readonly tags?: CloudwatchLogAlarmScheduledQueryConfigurationTags[] | cdktn.IResolvable;
}
export declare function cloudwatchLogAlarmScheduledQueryConfigurationToTerraform(struct?: CloudwatchLogAlarmScheduledQueryConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchLogAlarmScheduledQueryConfigurationToHclTerraform(struct?: CloudwatchLogAlarmScheduledQueryConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchLogAlarmScheduledQueryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchLogAlarmScheduledQueryConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogAlarmScheduledQueryConfiguration | cdktn.IResolvable | undefined);
    private _aggregationExpression?;
    get aggregationExpression(): string;
    set aggregationExpression(value: string);
    get aggregationExpressionInput(): string | undefined;
    private _logGroupIdentifiers?;
    get logGroupIdentifiers(): string[];
    set logGroupIdentifiers(value: string[]);
    resetLogGroupIdentifiers(): void;
    get logGroupIdentifiersInput(): string[] | undefined;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    get queryStringInput(): string | undefined;
    private _scheduleConfiguration;
    get scheduleConfiguration(): CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfigurationOutputReference;
    putScheduleConfiguration(value: CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfiguration): void;
    get scheduleConfigurationInput(): cdktn.IResolvable | CloudwatchLogAlarmScheduledQueryConfigurationScheduleConfiguration | undefined;
    private _scheduledQueryRoleArn?;
    get scheduledQueryRoleArn(): string;
    set scheduledQueryRoleArn(value: string);
    get scheduledQueryRoleArnInput(): string | undefined;
    private _tags;
    get tags(): CloudwatchLogAlarmScheduledQueryConfigurationTagsList;
    putTags(value: CloudwatchLogAlarmScheduledQueryConfigurationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchLogAlarmScheduledQueryConfigurationTags[] | undefined;
}
export interface CloudwatchLogAlarmTags {
    /**
    * A unique identifier for the tag. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#key CloudwatchLogAlarm#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#value CloudwatchLogAlarm#value}
    */
    readonly value?: string;
}
export declare function cloudwatchLogAlarmTagsToTerraform(struct?: CloudwatchLogAlarmTags | cdktn.IResolvable): any;
export declare function cloudwatchLogAlarmTagsToHclTerraform(struct?: CloudwatchLogAlarmTags | cdktn.IResolvable): any;
export declare class CloudwatchLogAlarmTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogAlarmTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogAlarmTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchLogAlarmTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogAlarmTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogAlarmTagsOutputReference;
}
export interface CloudwatchLogAlarmWarmUpConfiguration {
    /**
    * Specifies whether the alarm waits for the full warm-up period before it starts evaluating. If true, the alarm waits the entire WarmUpPeriodDurationInMinutes before it starts evaluating, even if metric data arrives earlier. If false, the alarm ends the warm-up period early and starts evaluating as soon as it has enough metric data to fill its evaluation window. This is the default behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#only_start_evaluating_after_warm_up_period_ends CloudwatchLogAlarm#only_start_evaluating_after_warm_up_period_ends}
    */
    readonly onlyStartEvaluatingAfterWarmUpPeriodEnds?: boolean | cdktn.IResolvable;
    /**
    * The length of the warm-up period, in minutes. For this duration after you create or update the alarm, the alarm stays in INSUFFICIENT_DATA and doesn't perform alarm actions. Valid values range from 1 to 2,880 minutes (2 days). You can change this value while the alarm is still in its warm-up period. Changes have no effect after the warm-up period ends.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#warm_up_period_duration_in_minutes CloudwatchLogAlarm#warm_up_period_duration_in_minutes}
    */
    readonly warmUpPeriodDurationInMinutes?: number;
}
export declare function cloudwatchLogAlarmWarmUpConfigurationToTerraform(struct?: CloudwatchLogAlarmWarmUpConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchLogAlarmWarmUpConfigurationToHclTerraform(struct?: CloudwatchLogAlarmWarmUpConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchLogAlarmWarmUpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchLogAlarmWarmUpConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogAlarmWarmUpConfiguration | cdktn.IResolvable | undefined);
    private _onlyStartEvaluatingAfterWarmUpPeriodEnds?;
    get onlyStartEvaluatingAfterWarmUpPeriodEnds(): boolean | cdktn.IResolvable;
    set onlyStartEvaluatingAfterWarmUpPeriodEnds(value: boolean | cdktn.IResolvable);
    resetOnlyStartEvaluatingAfterWarmUpPeriodEnds(): void;
    get onlyStartEvaluatingAfterWarmUpPeriodEndsInput(): boolean | cdktn.IResolvable | undefined;
    private _warmUpPeriodDurationInMinutes?;
    get warmUpPeriodDurationInMinutes(): number;
    set warmUpPeriodDurationInMinutes(value: number);
    resetWarmUpPeriodDurationInMinutes(): void;
    get warmUpPeriodDurationInMinutesInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm awscc_cloudwatch_log_alarm}
*/
export declare class CloudwatchLogAlarm extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_log_alarm";
    /**
    * Generates CDKTN code for importing a CloudwatchLogAlarm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchLogAlarm to import
    * @param importFromId The id of the existing CloudwatchLogAlarm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchLogAlarm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_log_alarm awscc_cloudwatch_log_alarm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchLogAlarmConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchLogAlarmConfig);
    private _actionLogLineCount?;
    get actionLogLineCount(): number;
    set actionLogLineCount(value: number);
    resetActionLogLineCount(): void;
    get actionLogLineCountInput(): number | undefined;
    private _actionLogLineRoleArn?;
    get actionLogLineRoleArn(): string;
    set actionLogLineRoleArn(value: string);
    resetActionLogLineRoleArn(): void;
    get actionLogLineRoleArnInput(): string | undefined;
    private _actionsEnabled?;
    get actionsEnabled(): boolean | cdktn.IResolvable;
    set actionsEnabled(value: boolean | cdktn.IResolvable);
    resetActionsEnabled(): void;
    get actionsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _alarmActions?;
    get alarmActions(): string[];
    set alarmActions(value: string[]);
    resetAlarmActions(): void;
    get alarmActionsInput(): string[] | undefined;
    private _alarmDescription?;
    get alarmDescription(): string;
    set alarmDescription(value: string);
    resetAlarmDescription(): void;
    get alarmDescriptionInput(): string | undefined;
    private _alarmName?;
    get alarmName(): string;
    set alarmName(value: string);
    resetAlarmName(): void;
    get alarmNameInput(): string | undefined;
    get arn(): string;
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    get comparisonOperatorInput(): string | undefined;
    get id(): string;
    private _insufficientDataActions?;
    get insufficientDataActions(): string[];
    set insufficientDataActions(value: string[]);
    resetInsufficientDataActions(): void;
    get insufficientDataActionsInput(): string[] | undefined;
    private _okActions?;
    get okActions(): string[];
    set okActions(value: string[]);
    resetOkActions(): void;
    get okActionsInput(): string[] | undefined;
    private _queryResultsToAlarm?;
    get queryResultsToAlarm(): number;
    set queryResultsToAlarm(value: number);
    get queryResultsToAlarmInput(): number | undefined;
    private _queryResultsToEvaluate?;
    get queryResultsToEvaluate(): number;
    set queryResultsToEvaluate(value: number);
    get queryResultsToEvaluateInput(): number | undefined;
    private _scheduledQueryConfiguration;
    get scheduledQueryConfiguration(): CloudwatchLogAlarmScheduledQueryConfigurationOutputReference;
    putScheduledQueryConfiguration(value: CloudwatchLogAlarmScheduledQueryConfiguration): void;
    get scheduledQueryConfigurationInput(): cdktn.IResolvable | CloudwatchLogAlarmScheduledQueryConfiguration | undefined;
    private _tags;
    get tags(): CloudwatchLogAlarmTagsList;
    putTags(value: CloudwatchLogAlarmTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchLogAlarmTags[] | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _treatMissingData?;
    get treatMissingData(): string;
    set treatMissingData(value: string);
    resetTreatMissingData(): void;
    get treatMissingDataInput(): string | undefined;
    private _warmUpConfiguration;
    get warmUpConfiguration(): CloudwatchLogAlarmWarmUpConfigurationOutputReference;
    putWarmUpConfiguration(value: CloudwatchLogAlarmWarmUpConfiguration): void;
    resetWarmUpConfiguration(): void;
    get warmUpConfigurationInput(): cdktn.IResolvable | CloudwatchLogAlarmWarmUpConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
