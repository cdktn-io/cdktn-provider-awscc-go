/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAccountaccessApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/accountaccess_application#id DataAwsccAccountaccessApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAccountaccessApplicationIdentitySourceIdentityCenter {
}
export declare function dataAwsccAccountaccessApplicationIdentitySourceIdentityCenterToTerraform(struct?: DataAwsccAccountaccessApplicationIdentitySourceIdentityCenter): any;
export declare function dataAwsccAccountaccessApplicationIdentitySourceIdentityCenterToHclTerraform(struct?: DataAwsccAccountaccessApplicationIdentitySourceIdentityCenter): any;
export declare class DataAwsccAccountaccessApplicationIdentitySourceIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccountaccessApplicationIdentitySourceIdentityCenter | undefined;
    set internalValue(value: DataAwsccAccountaccessApplicationIdentitySourceIdentityCenter | undefined);
    get applicationArn(): string;
    get instanceArn(): string;
}
export interface DataAwsccAccountaccessApplicationIdentitySource {
}
export declare function dataAwsccAccountaccessApplicationIdentitySourceToTerraform(struct?: DataAwsccAccountaccessApplicationIdentitySource): any;
export declare function dataAwsccAccountaccessApplicationIdentitySourceToHclTerraform(struct?: DataAwsccAccountaccessApplicationIdentitySource): any;
export declare class DataAwsccAccountaccessApplicationIdentitySourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAccountaccessApplicationIdentitySource | undefined;
    set internalValue(value: DataAwsccAccountaccessApplicationIdentitySource | undefined);
    private _identityCenter;
    get identityCenter(): DataAwsccAccountaccessApplicationIdentitySourceIdentityCenterOutputReference;
}
export interface DataAwsccAccountaccessApplicationTags {
}
export declare function dataAwsccAccountaccessApplicationTagsToTerraform(struct?: DataAwsccAccountaccessApplicationTags): any;
export declare function dataAwsccAccountaccessApplicationTagsToHclTerraform(struct?: DataAwsccAccountaccessApplicationTags): any;
export declare class DataAwsccAccountaccessApplicationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAccountaccessApplicationTags | undefined;
    set internalValue(value: DataAwsccAccountaccessApplicationTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAccountaccessApplicationTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAccountaccessApplicationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/accountaccess_application awscc_accountaccess_application}
*/
export declare class DataAwsccAccountaccessApplication extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_accountaccess_application";
    /**
    * Generates CDKTN code for importing a DataAwsccAccountaccessApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAccountaccessApplication to import
    * @param importFromId The id of the existing DataAwsccAccountaccessApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/accountaccess_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAccountaccessApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/accountaccess_application awscc_accountaccess_application} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAccountaccessApplicationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAccountaccessApplicationConfig);
    get applicationArn(): string;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _identitySource;
    get identitySource(): DataAwsccAccountaccessApplicationIdentitySourceOutputReference;
    get status(): string;
    private _tags;
    get tags(): DataAwsccAccountaccessApplicationTagsList;
    get tenantId(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
