/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#customer_id ApigatewayApiKey#customer_id}
    */
    readonly customerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#description ApigatewayApiKey#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#enabled ApigatewayApiKey#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#generate_distinct_id ApigatewayApiKey#generate_distinct_id}
    */
    readonly generateDistinctId?: boolean | cdktn.IResolvable;
    /**
    * A name for the API key. If you don't specify a name, CFN generates a unique physical ID and uses that ID for the API key name. For more information, see [Name Type](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-name.html).
    *   If you specify a name, you cannot perform updates that require replacement of this resource. You can perform updates that require no or some interruption. If you must replace the resource, specify a new name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#name ApigatewayApiKey#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#stage_keys ApigatewayApiKey#stage_keys}
    */
    readonly stageKeys?: ApigatewayApiKeyStageKeys[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#tags ApigatewayApiKey#tags}
    */
    readonly tags?: ApigatewayApiKeyTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#value ApigatewayApiKey#value}
    */
    readonly value?: string;
}
export interface ApigatewayApiKeyStageKeys {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#rest_api_id ApigatewayApiKey#rest_api_id}
    */
    readonly restApiId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#stage_name ApigatewayApiKey#stage_name}
    */
    readonly stageName?: string;
}
export declare function apigatewayApiKeyStageKeysToTerraform(struct?: ApigatewayApiKeyStageKeys | cdktn.IResolvable): any;
export declare function apigatewayApiKeyStageKeysToHclTerraform(struct?: ApigatewayApiKeyStageKeys | cdktn.IResolvable): any;
export declare class ApigatewayApiKeyStageKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayApiKeyStageKeys | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayApiKeyStageKeys | cdktn.IResolvable | undefined);
    private _restApiId?;
    get restApiId(): string;
    set restApiId(value: string);
    resetRestApiId(): void;
    get restApiIdInput(): string | undefined;
    private _stageName?;
    get stageName(): string;
    set stageName(value: string);
    resetStageName(): void;
    get stageNameInput(): string | undefined;
}
export declare class ApigatewayApiKeyStageKeysList extends cdktn.ComplexList {
    internalValue?: ApigatewayApiKeyStageKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayApiKeyStageKeysOutputReference;
}
export interface ApigatewayApiKeyTags {
    /**
    * A string you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#key ApigatewayApiKey#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#value ApigatewayApiKey#value}
    */
    readonly value?: string;
}
export declare function apigatewayApiKeyTagsToTerraform(struct?: ApigatewayApiKeyTags | cdktn.IResolvable): any;
export declare function apigatewayApiKeyTagsToHclTerraform(struct?: ApigatewayApiKeyTags | cdktn.IResolvable): any;
export declare class ApigatewayApiKeyTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayApiKeyTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayApiKeyTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigatewayApiKeyTagsList extends cdktn.ComplexList {
    internalValue?: ApigatewayApiKeyTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayApiKeyTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key awscc_apigateway_api_key}
*/
export declare class ApigatewayApiKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_api_key";
    /**
    * Generates CDKTN code for importing a ApigatewayApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayApiKey to import
    * @param importFromId The id of the existing ApigatewayApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_api_key awscc_apigateway_api_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayApiKeyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApigatewayApiKeyConfig);
    get apiKeyId(): string;
    private _customerId?;
    get customerId(): string;
    set customerId(value: string);
    resetCustomerId(): void;
    get customerIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _generateDistinctId?;
    get generateDistinctId(): boolean | cdktn.IResolvable;
    set generateDistinctId(value: boolean | cdktn.IResolvable);
    resetGenerateDistinctId(): void;
    get generateDistinctIdInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _stageKeys;
    get stageKeys(): ApigatewayApiKeyStageKeysList;
    putStageKeys(value: ApigatewayApiKeyStageKeys[] | cdktn.IResolvable): void;
    resetStageKeys(): void;
    get stageKeysInput(): cdktn.IResolvable | ApigatewayApiKeyStageKeys[] | undefined;
    private _tags;
    get tags(): ApigatewayApiKeyTagsList;
    putTags(value: ApigatewayApiKeyTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApigatewayApiKeyTags[] | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
