/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectPredefinedAttributeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Custom metadata associated to a Predefined attribute that controls how the attribute behaves when used by upstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#attribute_configuration ConnectPredefinedAttribute#attribute_configuration}
    */
    readonly attributeConfiguration?: ConnectPredefinedAttributeAttributeConfiguration;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#instance_arn ConnectPredefinedAttribute#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the predefined attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#name ConnectPredefinedAttribute#name}
    */
    readonly name: string;
    /**
    * The assigned purposes of the predefined attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#purposes ConnectPredefinedAttribute#purposes}
    */
    readonly purposes?: string[];
    /**
    * The values of a predefined attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#values ConnectPredefinedAttribute#values}
    */
    readonly values?: ConnectPredefinedAttributeValues;
}
export interface ConnectPredefinedAttributeAttributeConfiguration {
    /**
    * Enables customers to enforce strict validation on the specific values that this predefined attribute can hold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#enable_value_validation_on_association ConnectPredefinedAttribute#enable_value_validation_on_association}
    */
    readonly enableValueValidationOnAssociation?: boolean | cdktn.IResolvable;
    /**
    * Allows the predefined attribute to show up and be managed in the Amazon Connect UI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#is_read_only ConnectPredefinedAttribute#is_read_only}
    */
    readonly isReadOnly?: boolean | cdktn.IResolvable;
}
export declare function connectPredefinedAttributeAttributeConfigurationToTerraform(struct?: ConnectPredefinedAttributeAttributeConfiguration | cdktn.IResolvable): any;
export declare function connectPredefinedAttributeAttributeConfigurationToHclTerraform(struct?: ConnectPredefinedAttributeAttributeConfiguration | cdktn.IResolvable): any;
export declare class ConnectPredefinedAttributeAttributeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectPredefinedAttributeAttributeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectPredefinedAttributeAttributeConfiguration | cdktn.IResolvable | undefined);
    private _enableValueValidationOnAssociation?;
    get enableValueValidationOnAssociation(): boolean | cdktn.IResolvable;
    set enableValueValidationOnAssociation(value: boolean | cdktn.IResolvable);
    resetEnableValueValidationOnAssociation(): void;
    get enableValueValidationOnAssociationInput(): boolean | cdktn.IResolvable | undefined;
    private _isReadOnly?;
    get isReadOnly(): boolean | cdktn.IResolvable;
    set isReadOnly(value: boolean | cdktn.IResolvable);
    resetIsReadOnly(): void;
    get isReadOnlyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ConnectPredefinedAttributeValues {
    /**
    * Predefined attribute values of type string list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#string_list ConnectPredefinedAttribute#string_list}
    */
    readonly stringList?: string[];
}
export declare function connectPredefinedAttributeValuesToTerraform(struct?: ConnectPredefinedAttributeValues | cdktn.IResolvable): any;
export declare function connectPredefinedAttributeValuesToHclTerraform(struct?: ConnectPredefinedAttributeValues | cdktn.IResolvable): any;
export declare class ConnectPredefinedAttributeValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectPredefinedAttributeValues | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectPredefinedAttributeValues | cdktn.IResolvable | undefined);
    private _stringList?;
    get stringList(): string[];
    set stringList(value: string[]);
    resetStringList(): void;
    get stringListInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute awscc_connect_predefined_attribute}
*/
export declare class ConnectPredefinedAttribute extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_predefined_attribute";
    /**
    * Generates CDKTN code for importing a ConnectPredefinedAttribute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectPredefinedAttribute to import
    * @param importFromId The id of the existing ConnectPredefinedAttribute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectPredefinedAttribute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_predefined_attribute awscc_connect_predefined_attribute} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectPredefinedAttributeConfig
    */
    constructor(scope: Construct, id: string, config: ConnectPredefinedAttributeConfig);
    private _attributeConfiguration;
    get attributeConfiguration(): ConnectPredefinedAttributeAttributeConfigurationOutputReference;
    putAttributeConfiguration(value: ConnectPredefinedAttributeAttributeConfiguration): void;
    resetAttributeConfiguration(): void;
    get attributeConfigurationInput(): cdktn.IResolvable | ConnectPredefinedAttributeAttributeConfiguration | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get lastModifiedRegion(): string;
    get lastModifiedTime(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _purposes?;
    get purposes(): string[];
    set purposes(value: string[]);
    resetPurposes(): void;
    get purposesInput(): string[] | undefined;
    private _values;
    get values(): ConnectPredefinedAttributeValuesOutputReference;
    putValues(value: ConnectPredefinedAttributeValues): void;
    resetValues(): void;
    get valuesInput(): cdktn.IResolvable | ConnectPredefinedAttributeValues | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
