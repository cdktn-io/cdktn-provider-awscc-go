/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuditmanagerAssessmentFrameworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * The compliance type that the framework supports, such as CIS or HIPAA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#compliance_type AuditmanagerAssessmentFramework#compliance_type}
    */
    readonly complianceType?: string;
    /**
    * The control sets that are associated with the framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#control_sets AuditmanagerAssessmentFramework#control_sets}
    */
    readonly controlSets: AuditmanagerAssessmentFrameworkControlSets[] | cdktn.IResolvable;
    /**
    * The description of the framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#description AuditmanagerAssessmentFramework#description}
    */
    readonly description?: string;
    /**
    * The name of the framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#name AuditmanagerAssessmentFramework#name}
    */
    readonly name: string;
    /**
    * The tags associated with the framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#tags AuditmanagerAssessmentFramework#tags}
    */
    readonly tags?: AuditmanagerAssessmentFrameworkTags[] | cdktn.IResolvable;
}
export interface AuditmanagerAssessmentFrameworkControlSetsControls {
    /**
    * The unique identifier of the control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#id AuditmanagerAssessmentFramework#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function auditmanagerAssessmentFrameworkControlSetsControlsToTerraform(struct?: AuditmanagerAssessmentFrameworkControlSetsControls | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentFrameworkControlSetsControlsToHclTerraform(struct?: AuditmanagerAssessmentFrameworkControlSetsControls | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentFrameworkControlSetsControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuditmanagerAssessmentFrameworkControlSetsControls | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentFrameworkControlSetsControls | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class AuditmanagerAssessmentFrameworkControlSetsControlsList extends cdktn.ComplexList {
    internalValue?: AuditmanagerAssessmentFrameworkControlSetsControls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuditmanagerAssessmentFrameworkControlSetsControlsOutputReference;
}
export interface AuditmanagerAssessmentFrameworkControlSets {
    /**
    * The list of controls within the control set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#controls AuditmanagerAssessmentFramework#controls}
    */
    readonly controls: AuditmanagerAssessmentFrameworkControlSetsControls[] | cdktn.IResolvable;
    /**
    * The name of the control set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#name AuditmanagerAssessmentFramework#name}
    */
    readonly name: string;
}
export declare function auditmanagerAssessmentFrameworkControlSetsToTerraform(struct?: AuditmanagerAssessmentFrameworkControlSets | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentFrameworkControlSetsToHclTerraform(struct?: AuditmanagerAssessmentFrameworkControlSets | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentFrameworkControlSetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuditmanagerAssessmentFrameworkControlSets | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentFrameworkControlSets | cdktn.IResolvable | undefined);
    private _controls;
    get controls(): AuditmanagerAssessmentFrameworkControlSetsControlsList;
    putControls(value: AuditmanagerAssessmentFrameworkControlSetsControls[] | cdktn.IResolvable): void;
    get controlsInput(): cdktn.IResolvable | AuditmanagerAssessmentFrameworkControlSetsControls[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class AuditmanagerAssessmentFrameworkControlSetsList extends cdktn.ComplexList {
    internalValue?: AuditmanagerAssessmentFrameworkControlSets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuditmanagerAssessmentFrameworkControlSetsOutputReference;
}
export interface AuditmanagerAssessmentFrameworkTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#key AuditmanagerAssessmentFramework#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#value AuditmanagerAssessmentFramework#value}
    */
    readonly value?: string;
}
export declare function auditmanagerAssessmentFrameworkTagsToTerraform(struct?: AuditmanagerAssessmentFrameworkTags | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentFrameworkTagsToHclTerraform(struct?: AuditmanagerAssessmentFrameworkTags | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentFrameworkTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuditmanagerAssessmentFrameworkTags | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentFrameworkTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AuditmanagerAssessmentFrameworkTagsList extends cdktn.ComplexList {
    internalValue?: AuditmanagerAssessmentFrameworkTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuditmanagerAssessmentFrameworkTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework awscc_auditmanager_assessment_framework}
*/
export declare class AuditmanagerAssessmentFramework extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_auditmanager_assessment_framework";
    /**
    * Generates CDKTN code for importing a AuditmanagerAssessmentFramework resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuditmanagerAssessmentFramework to import
    * @param importFromId The id of the existing AuditmanagerAssessmentFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuditmanagerAssessmentFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/auditmanager_assessment_framework awscc_auditmanager_assessment_framework} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuditmanagerAssessmentFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: AuditmanagerAssessmentFrameworkConfig);
    get arn(): string;
    private _complianceType?;
    get complianceType(): string;
    set complianceType(value: string);
    resetComplianceType(): void;
    get complianceTypeInput(): string | undefined;
    private _controlSets;
    get controlSets(): AuditmanagerAssessmentFrameworkControlSetsList;
    putControlSets(value: AuditmanagerAssessmentFrameworkControlSets[] | cdktn.IResolvable): void;
    get controlSetsInput(): cdktn.IResolvable | AuditmanagerAssessmentFrameworkControlSets[] | undefined;
    get createdAt(): string;
    get createdBy(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get frameworkId(): string;
    get id(): string;
    get lastUpdatedAt(): string;
    get lastUpdatedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): AuditmanagerAssessmentFrameworkTagsList;
    putTags(value: AuditmanagerAssessmentFrameworkTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AuditmanagerAssessmentFrameworkTags[] | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
