/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigOrganizationConformancePackConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of ConformancePackInputParameter objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#conformance_pack_input_parameters ConfigOrganizationConformancePack#conformance_pack_input_parameters}
    */
    readonly conformancePackInputParameters?: ConfigOrganizationConformancePackConformancePackInputParameters[] | cdktn.IResolvable;
    /**
    * AWS Config stores intermediate files while processing conformance pack template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#delivery_s3_bucket ConfigOrganizationConformancePack#delivery_s3_bucket}
    */
    readonly deliveryS3Bucket?: string;
    /**
    * The prefix for the delivery S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#delivery_s3_key_prefix ConfigOrganizationConformancePack#delivery_s3_key_prefix}
    */
    readonly deliveryS3KeyPrefix?: string;
    /**
    * A list of AWS accounts to be excluded from an organization conformance pack while deploying a conformance pack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#excluded_accounts ConfigOrganizationConformancePack#excluded_accounts}
    */
    readonly excludedAccounts?: string[];
    /**
    * The name of the organization conformance pack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#organization_conformance_pack_name ConfigOrganizationConformancePack#organization_conformance_pack_name}
    */
    readonly organizationConformancePackName: string;
    /**
    * The tags for the organization conformance pack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#tags ConfigOrganizationConformancePack#tags}
    */
    readonly tags?: ConfigOrganizationConformancePackTags[] | cdktn.IResolvable;
    /**
    * A string containing full conformance pack template body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#template_body ConfigOrganizationConformancePack#template_body}
    */
    readonly templateBody?: string;
    /**
    * Location of file containing the template body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#template_s3_uri ConfigOrganizationConformancePack#template_s3_uri}
    */
    readonly templateS3Uri?: string;
}
export interface ConfigOrganizationConformancePackConformancePackInputParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#parameter_name ConfigOrganizationConformancePack#parameter_name}
    */
    readonly parameterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#parameter_value ConfigOrganizationConformancePack#parameter_value}
    */
    readonly parameterValue?: string;
}
export declare function configOrganizationConformancePackConformancePackInputParametersToTerraform(struct?: ConfigOrganizationConformancePackConformancePackInputParameters | cdktn.IResolvable): any;
export declare function configOrganizationConformancePackConformancePackInputParametersToHclTerraform(struct?: ConfigOrganizationConformancePackConformancePackInputParameters | cdktn.IResolvable): any;
export declare class ConfigOrganizationConformancePackConformancePackInputParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigOrganizationConformancePackConformancePackInputParameters | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigOrganizationConformancePackConformancePackInputParameters | cdktn.IResolvable | undefined);
    private _parameterName?;
    get parameterName(): string;
    set parameterName(value: string);
    resetParameterName(): void;
    get parameterNameInput(): string | undefined;
    private _parameterValue?;
    get parameterValue(): string;
    set parameterValue(value: string);
    resetParameterValue(): void;
    get parameterValueInput(): string | undefined;
}
export declare class ConfigOrganizationConformancePackConformancePackInputParametersList extends cdktn.ComplexList {
    internalValue?: ConfigOrganizationConformancePackConformancePackInputParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigOrganizationConformancePackConformancePackInputParametersOutputReference;
}
export interface ConfigOrganizationConformancePackTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#key ConfigOrganizationConformancePack#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#value ConfigOrganizationConformancePack#value}
    */
    readonly value?: string;
}
export declare function configOrganizationConformancePackTagsToTerraform(struct?: ConfigOrganizationConformancePackTags | cdktn.IResolvable): any;
export declare function configOrganizationConformancePackTagsToHclTerraform(struct?: ConfigOrganizationConformancePackTags | cdktn.IResolvable): any;
export declare class ConfigOrganizationConformancePackTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigOrganizationConformancePackTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigOrganizationConformancePackTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConfigOrganizationConformancePackTagsList extends cdktn.ComplexList {
    internalValue?: ConfigOrganizationConformancePackTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigOrganizationConformancePackTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack awscc_config_organization_conformance_pack}
*/
export declare class ConfigOrganizationConformancePack extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_organization_conformance_pack";
    /**
    * Generates CDKTN code for importing a ConfigOrganizationConformancePack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigOrganizationConformancePack to import
    * @param importFromId The id of the existing ConfigOrganizationConformancePack that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigOrganizationConformancePack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_conformance_pack awscc_config_organization_conformance_pack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigOrganizationConformancePackConfig
    */
    constructor(scope: Construct, id: string, config: ConfigOrganizationConformancePackConfig);
    private _conformancePackInputParameters;
    get conformancePackInputParameters(): ConfigOrganizationConformancePackConformancePackInputParametersList;
    putConformancePackInputParameters(value: ConfigOrganizationConformancePackConformancePackInputParameters[] | cdktn.IResolvable): void;
    resetConformancePackInputParameters(): void;
    get conformancePackInputParametersInput(): cdktn.IResolvable | ConfigOrganizationConformancePackConformancePackInputParameters[] | undefined;
    private _deliveryS3Bucket?;
    get deliveryS3Bucket(): string;
    set deliveryS3Bucket(value: string);
    resetDeliveryS3Bucket(): void;
    get deliveryS3BucketInput(): string | undefined;
    private _deliveryS3KeyPrefix?;
    get deliveryS3KeyPrefix(): string;
    set deliveryS3KeyPrefix(value: string);
    resetDeliveryS3KeyPrefix(): void;
    get deliveryS3KeyPrefixInput(): string | undefined;
    private _excludedAccounts?;
    get excludedAccounts(): string[];
    set excludedAccounts(value: string[]);
    resetExcludedAccounts(): void;
    get excludedAccountsInput(): string[] | undefined;
    get id(): string;
    get organizationConformancePackArn(): string;
    private _organizationConformancePackName?;
    get organizationConformancePackName(): string;
    set organizationConformancePackName(value: string);
    get organizationConformancePackNameInput(): string | undefined;
    private _tags;
    get tags(): ConfigOrganizationConformancePackTagsList;
    putTags(value: ConfigOrganizationConformancePackTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConfigOrganizationConformancePackTags[] | undefined;
    private _templateBody?;
    get templateBody(): string;
    set templateBody(value: string);
    resetTemplateBody(): void;
    get templateBodyInput(): string | undefined;
    private _templateS3Uri?;
    get templateS3Uri(): string;
    set templateS3Uri(value: string);
    resetTemplateS3Uri(): void;
    get templateS3UriInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
