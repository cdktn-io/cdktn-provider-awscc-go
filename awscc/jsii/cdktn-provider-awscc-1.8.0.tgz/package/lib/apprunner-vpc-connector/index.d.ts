/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApprunnerVpcConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of IDs of security groups that App Runner should use for access to AWS resources under the specified subnets. If not specified, App Runner uses the default security group of the Amazon VPC. The default security group allows all outbound traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector#security_groups ApprunnerVpcConnector#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * A list of IDs of subnets that App Runner should use when it associates your service with a custom Amazon VPC. Specify IDs of subnets of a single Amazon VPC. App Runner determines the Amazon VPC from the subnets you specify.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector#subnets ApprunnerVpcConnector#subnets}
    */
    readonly subnets: string[];
    /**
    * A list of metadata items that you can associate with your VPC connector resource. A tag is a key-value pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector#tags ApprunnerVpcConnector#tags}
    */
    readonly tags?: ApprunnerVpcConnectorTags[] | cdktn.IResolvable;
    /**
    * A name for the VPC connector. If you don't specify a name, AWS CloudFormation generates a name for your VPC connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector#vpc_connector_name ApprunnerVpcConnector#vpc_connector_name}
    */
    readonly vpcConnectorName?: string;
}
export interface ApprunnerVpcConnectorTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector#key ApprunnerVpcConnector#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector#value ApprunnerVpcConnector#value}
    */
    readonly value?: string;
}
export declare function apprunnerVpcConnectorTagsToTerraform(struct?: ApprunnerVpcConnectorTags | cdktn.IResolvable): any;
export declare function apprunnerVpcConnectorTagsToHclTerraform(struct?: ApprunnerVpcConnectorTags | cdktn.IResolvable): any;
export declare class ApprunnerVpcConnectorTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApprunnerVpcConnectorTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerVpcConnectorTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApprunnerVpcConnectorTagsList extends cdktn.ComplexList {
    internalValue?: ApprunnerVpcConnectorTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApprunnerVpcConnectorTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector awscc_apprunner_vpc_connector}
*/
export declare class ApprunnerVpcConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apprunner_vpc_connector";
    /**
    * Generates CDKTN code for importing a ApprunnerVpcConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApprunnerVpcConnector to import
    * @param importFromId The id of the existing ApprunnerVpcConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApprunnerVpcConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apprunner_vpc_connector awscc_apprunner_vpc_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApprunnerVpcConnectorConfig
    */
    constructor(scope: Construct, id: string, config: ApprunnerVpcConnectorConfig);
    get id(): string;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    get subnetsInput(): string[] | undefined;
    private _tags;
    get tags(): ApprunnerVpcConnectorTagsList;
    putTags(value: ApprunnerVpcConnectorTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApprunnerVpcConnectorTags[] | undefined;
    get vpcConnectorArn(): string;
    private _vpcConnectorName?;
    get vpcConnectorName(): string;
    set vpcConnectorName(value: string);
    resetVpcConnectorName(): void;
    get vpcConnectorNameInput(): string | undefined;
    get vpcConnectorRevision(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
