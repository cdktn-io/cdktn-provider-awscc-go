/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayDocumentationPartConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ``Location`` property specifies the location of the Amazon API Gateway API entity that the documentation applies to. ``Location`` is a property of the [AWS::ApiGateway::DocumentationPart](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-documentationpart.html) resource.
    *   For more information about each property, including constraints and valid values, see [DocumentationPart](https://docs.aws.amazon.com/apigateway/latest/api/API_DocumentationPartLocation.html) in the *Amazon API Gateway REST API Reference*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#location ApigatewayDocumentationPart#location}
    */
    readonly location: ApigatewayDocumentationPartLocation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#properties ApigatewayDocumentationPart#properties}
    */
    readonly properties: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#rest_api_id ApigatewayDocumentationPart#rest_api_id}
    */
    readonly restApiId: string;
}
export interface ApigatewayDocumentationPartLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#method ApigatewayDocumentationPart#method}
    */
    readonly method?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#name ApigatewayDocumentationPart#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#path ApigatewayDocumentationPart#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#status_code ApigatewayDocumentationPart#status_code}
    */
    readonly statusCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#type ApigatewayDocumentationPart#type}
    */
    readonly type?: string;
}
export declare function apigatewayDocumentationPartLocationToTerraform(struct?: ApigatewayDocumentationPartLocation | cdktn.IResolvable): any;
export declare function apigatewayDocumentationPartLocationToHclTerraform(struct?: ApigatewayDocumentationPartLocation | cdktn.IResolvable): any;
export declare class ApigatewayDocumentationPartLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayDocumentationPartLocation | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDocumentationPartLocation | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _statusCode?;
    get statusCode(): string;
    set statusCode(value: string);
    resetStatusCode(): void;
    get statusCodeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part awscc_apigateway_documentation_part}
*/
export declare class ApigatewayDocumentationPart extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_documentation_part";
    /**
    * Generates CDKTN code for importing a ApigatewayDocumentationPart resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayDocumentationPart to import
    * @param importFromId The id of the existing ApigatewayDocumentationPart that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayDocumentationPart to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_documentation_part awscc_apigateway_documentation_part} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayDocumentationPartConfig
    */
    constructor(scope: Construct, id: string, config: ApigatewayDocumentationPartConfig);
    get documentationPartId(): string;
    get id(): string;
    private _location;
    get location(): ApigatewayDocumentationPartLocationOutputReference;
    putLocation(value: ApigatewayDocumentationPartLocation): void;
    get locationInput(): cdktn.IResolvable | ApigatewayDocumentationPartLocation | undefined;
    private _properties?;
    get properties(): string;
    set properties(value: string);
    get propertiesInput(): string | undefined;
    private _restApiId?;
    get restApiId(): string;
    set restApiId(value: string);
    get restApiIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
