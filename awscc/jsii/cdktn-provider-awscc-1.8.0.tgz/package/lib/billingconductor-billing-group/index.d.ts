/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BillingconductorBillingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#account_grouping BillingconductorBillingGroup#account_grouping}
    */
    readonly accountGrouping: BillingconductorBillingGroupAccountGrouping;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#computation_preference BillingconductorBillingGroup#computation_preference}
    */
    readonly computationPreference: BillingconductorBillingGroupComputationPreference;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#description BillingconductorBillingGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#name BillingconductorBillingGroup#name}
    */
    readonly name: string;
    /**
    * This account will act as a virtual payer account of the billing group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#primary_account_id BillingconductorBillingGroup#primary_account_id}
    */
    readonly primaryAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#tags BillingconductorBillingGroup#tags}
    */
    readonly tags?: BillingconductorBillingGroupTags[] | cdktn.IResolvable;
}
export interface BillingconductorBillingGroupAccountGrouping {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#auto_associate BillingconductorBillingGroup#auto_associate}
    */
    readonly autoAssociate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#linked_account_ids BillingconductorBillingGroup#linked_account_ids}
    */
    readonly linkedAccountIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#responsibility_transfer_arn BillingconductorBillingGroup#responsibility_transfer_arn}
    */
    readonly responsibilityTransferArn?: string;
}
export declare function billingconductorBillingGroupAccountGroupingToTerraform(struct?: BillingconductorBillingGroupAccountGrouping | cdktn.IResolvable): any;
export declare function billingconductorBillingGroupAccountGroupingToHclTerraform(struct?: BillingconductorBillingGroupAccountGrouping | cdktn.IResolvable): any;
export declare class BillingconductorBillingGroupAccountGroupingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorBillingGroupAccountGrouping | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorBillingGroupAccountGrouping | cdktn.IResolvable | undefined);
    private _autoAssociate?;
    get autoAssociate(): boolean | cdktn.IResolvable;
    set autoAssociate(value: boolean | cdktn.IResolvable);
    resetAutoAssociate(): void;
    get autoAssociateInput(): boolean | cdktn.IResolvable | undefined;
    private _linkedAccountIds?;
    get linkedAccountIds(): string[];
    set linkedAccountIds(value: string[]);
    resetLinkedAccountIds(): void;
    get linkedAccountIdsInput(): string[] | undefined;
    private _responsibilityTransferArn?;
    get responsibilityTransferArn(): string;
    set responsibilityTransferArn(value: string);
    resetResponsibilityTransferArn(): void;
    get responsibilityTransferArnInput(): string | undefined;
}
export interface BillingconductorBillingGroupComputationPreference {
    /**
    * ARN of the attached pricing plan
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#pricing_plan_arn BillingconductorBillingGroup#pricing_plan_arn}
    */
    readonly pricingPlanArn: string;
}
export declare function billingconductorBillingGroupComputationPreferenceToTerraform(struct?: BillingconductorBillingGroupComputationPreference | cdktn.IResolvable): any;
export declare function billingconductorBillingGroupComputationPreferenceToHclTerraform(struct?: BillingconductorBillingGroupComputationPreference | cdktn.IResolvable): any;
export declare class BillingconductorBillingGroupComputationPreferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorBillingGroupComputationPreference | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorBillingGroupComputationPreference | cdktn.IResolvable | undefined);
    private _pricingPlanArn?;
    get pricingPlanArn(): string;
    set pricingPlanArn(value: string);
    get pricingPlanArnInput(): string | undefined;
}
export interface BillingconductorBillingGroupTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#key BillingconductorBillingGroup#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#value BillingconductorBillingGroup#value}
    */
    readonly value?: string;
}
export declare function billingconductorBillingGroupTagsToTerraform(struct?: BillingconductorBillingGroupTags | cdktn.IResolvable): any;
export declare function billingconductorBillingGroupTagsToHclTerraform(struct?: BillingconductorBillingGroupTags | cdktn.IResolvable): any;
export declare class BillingconductorBillingGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingconductorBillingGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorBillingGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BillingconductorBillingGroupTagsList extends cdktn.ComplexList {
    internalValue?: BillingconductorBillingGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingconductorBillingGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group awscc_billingconductor_billing_group}
*/
export declare class BillingconductorBillingGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_billingconductor_billing_group";
    /**
    * Generates CDKTN code for importing a BillingconductorBillingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BillingconductorBillingGroup to import
    * @param importFromId The id of the existing BillingconductorBillingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BillingconductorBillingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/billingconductor_billing_group awscc_billingconductor_billing_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BillingconductorBillingGroupConfig
    */
    constructor(scope: Construct, id: string, config: BillingconductorBillingGroupConfig);
    private _accountGrouping;
    get accountGrouping(): BillingconductorBillingGroupAccountGroupingOutputReference;
    putAccountGrouping(value: BillingconductorBillingGroupAccountGrouping): void;
    get accountGroupingInput(): cdktn.IResolvable | BillingconductorBillingGroupAccountGrouping | undefined;
    get arn(): string;
    private _computationPreference;
    get computationPreference(): BillingconductorBillingGroupComputationPreferenceOutputReference;
    putComputationPreference(value: BillingconductorBillingGroupComputationPreference): void;
    get computationPreferenceInput(): cdktn.IResolvable | BillingconductorBillingGroupComputationPreference | undefined;
    get creationTime(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryAccountId?;
    get primaryAccountId(): string;
    set primaryAccountId(value: string);
    resetPrimaryAccountId(): void;
    get primaryAccountIdInput(): string | undefined;
    get size(): number;
    get status(): string;
    get statusReason(): string;
    private _tags;
    get tags(): BillingconductorBillingGroupTagsList;
    putTags(value: BillingconductorBillingGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BillingconductorBillingGroupTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
