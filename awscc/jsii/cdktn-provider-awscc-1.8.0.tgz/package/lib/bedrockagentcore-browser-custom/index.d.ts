/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreBrowserCustomConfig extends cdktn.TerraformMetaArguments {
    /**
    * Browser signing configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#browser_signing BedrockagentcoreBrowserCustom#browser_signing}
    */
    readonly browserSigning?: BedrockagentcoreBrowserCustomBrowserSigning;
    /**
    * List of root CA certificates in PEM format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#certificates BedrockagentcoreBrowserCustom#certificates}
    */
    readonly certificates?: BedrockagentcoreBrowserCustomCertificates[] | cdktn.IResolvable;
    /**
    * The description of the browser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#description BedrockagentcoreBrowserCustom#description}
    */
    readonly description?: string;
    /**
    * A list of enterprise policy files for the browser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#enterprise_policies BedrockagentcoreBrowserCustom#enterprise_policies}
    */
    readonly enterprisePolicies?: BedrockagentcoreBrowserCustomEnterprisePolicies[] | cdktn.IResolvable;
    /**
    * The Amazon Resource Name (ARN) of the IAM role that the browser uses to access resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#execution_role_arn BedrockagentcoreBrowserCustom#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * The name of the browser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#name BedrockagentcoreBrowserCustom#name}
    */
    readonly name: string;
    /**
    * Network configuration for browser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#network_configuration BedrockagentcoreBrowserCustom#network_configuration}
    */
    readonly networkConfiguration: BedrockagentcoreBrowserCustomNetworkConfiguration;
    /**
    * Recording configuration for browser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#recording_config BedrockagentcoreBrowserCustom#recording_config}
    */
    readonly recordingConfig?: BedrockagentcoreBrowserCustomRecordingConfig;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#tags BedrockagentcoreBrowserCustom#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BedrockagentcoreBrowserCustomBrowserSigning {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#enabled BedrockagentcoreBrowserCustom#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function bedrockagentcoreBrowserCustomBrowserSigningToTerraform(struct?: BedrockagentcoreBrowserCustomBrowserSigning | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomBrowserSigningToHclTerraform(struct?: BedrockagentcoreBrowserCustomBrowserSigning | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomBrowserSigningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreBrowserCustomBrowserSigning | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomBrowserSigning | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BedrockagentcoreBrowserCustomCertificatesCertificateLocation {
    /**
    * Secrets Manager secret ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#secret_arn BedrockagentcoreBrowserCustom#secret_arn}
    */
    readonly secretArn?: string;
}
export declare function bedrockagentcoreBrowserCustomCertificatesCertificateLocationToTerraform(struct?: BedrockagentcoreBrowserCustomCertificatesCertificateLocation | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomCertificatesCertificateLocationToHclTerraform(struct?: BedrockagentcoreBrowserCustomCertificatesCertificateLocation | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomCertificatesCertificateLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreBrowserCustomCertificatesCertificateLocation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomCertificatesCertificateLocation | cdktn.IResolvable | undefined);
    private _secretArn?;
    get secretArn(): string;
    set secretArn(value: string);
    resetSecretArn(): void;
    get secretArnInput(): string | undefined;
}
export interface BedrockagentcoreBrowserCustomCertificates {
    /**
    * Certificate location in Secrets Manager.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#certificate_location BedrockagentcoreBrowserCustom#certificate_location}
    */
    readonly certificateLocation?: BedrockagentcoreBrowserCustomCertificatesCertificateLocation;
}
export declare function bedrockagentcoreBrowserCustomCertificatesToTerraform(struct?: BedrockagentcoreBrowserCustomCertificates | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomCertificatesToHclTerraform(struct?: BedrockagentcoreBrowserCustomCertificates | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserCustomCertificates | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomCertificates | cdktn.IResolvable | undefined);
    private _certificateLocation;
    get certificateLocation(): BedrockagentcoreBrowserCustomCertificatesCertificateLocationOutputReference;
    putCertificateLocation(value: BedrockagentcoreBrowserCustomCertificatesCertificateLocation): void;
    resetCertificateLocation(): void;
    get certificateLocationInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomCertificatesCertificateLocation | undefined;
}
export declare class BedrockagentcoreBrowserCustomCertificatesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserCustomCertificates[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserCustomCertificatesOutputReference;
}
export interface BedrockagentcoreBrowserCustomEnterprisePoliciesLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#bucket BedrockagentcoreBrowserCustom#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#prefix BedrockagentcoreBrowserCustom#prefix}
    */
    readonly prefix?: string;
}
export declare function bedrockagentcoreBrowserCustomEnterprisePoliciesLocationToTerraform(struct?: BedrockagentcoreBrowserCustomEnterprisePoliciesLocation | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomEnterprisePoliciesLocationToHclTerraform(struct?: BedrockagentcoreBrowserCustomEnterprisePoliciesLocation | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomEnterprisePoliciesLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreBrowserCustomEnterprisePoliciesLocation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomEnterprisePoliciesLocation | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
export interface BedrockagentcoreBrowserCustomEnterprisePolicies {
    /**
    * The S3 location of the enterprise policy file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#location BedrockagentcoreBrowserCustom#location}
    */
    readonly location?: BedrockagentcoreBrowserCustomEnterprisePoliciesLocation;
    /**
    * The type of browser enterprise policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#type BedrockagentcoreBrowserCustom#type}
    */
    readonly type?: string;
}
export declare function bedrockagentcoreBrowserCustomEnterprisePoliciesToTerraform(struct?: BedrockagentcoreBrowserCustomEnterprisePolicies | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomEnterprisePoliciesToHclTerraform(struct?: BedrockagentcoreBrowserCustomEnterprisePolicies | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomEnterprisePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserCustomEnterprisePolicies | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomEnterprisePolicies | cdktn.IResolvable | undefined);
    private _location;
    get location(): BedrockagentcoreBrowserCustomEnterprisePoliciesLocationOutputReference;
    putLocation(value: BedrockagentcoreBrowserCustomEnterprisePoliciesLocation): void;
    resetLocation(): void;
    get locationInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomEnterprisePoliciesLocation | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreBrowserCustomEnterprisePoliciesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserCustomEnterprisePolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserCustomEnterprisePoliciesOutputReference;
}
export interface BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfig {
    /**
    * Security groups for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#security_groups BedrockagentcoreBrowserCustom#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Subnets for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#subnets BedrockagentcoreBrowserCustom#subnets}
    */
    readonly subnets?: string[];
}
export declare function bedrockagentcoreBrowserCustomNetworkConfigurationVpcConfigToTerraform(struct?: BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomNetworkConfigurationVpcConfigToHclTerraform(struct?: BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
export interface BedrockagentcoreBrowserCustomNetworkConfiguration {
    /**
    * Network modes supported by browser
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#network_mode BedrockagentcoreBrowserCustom#network_mode}
    */
    readonly networkMode?: string;
    /**
    * Network mode configuration for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#vpc_config BedrockagentcoreBrowserCustom#vpc_config}
    */
    readonly vpcConfig?: BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfig;
}
export declare function bedrockagentcoreBrowserCustomNetworkConfigurationToTerraform(struct?: BedrockagentcoreBrowserCustomNetworkConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomNetworkConfigurationToHclTerraform(struct?: BedrockagentcoreBrowserCustomNetworkConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreBrowserCustomNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomNetworkConfiguration | cdktn.IResolvable | undefined);
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    resetNetworkMode(): void;
    get networkModeInput(): string | undefined;
    private _vpcConfig;
    get vpcConfig(): BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfigOutputReference;
    putVpcConfig(value: BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfig): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomNetworkConfigurationVpcConfig | undefined;
}
export interface BedrockagentcoreBrowserCustomRecordingConfigS3Location {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#bucket BedrockagentcoreBrowserCustom#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#prefix BedrockagentcoreBrowserCustom#prefix}
    */
    readonly prefix?: string;
}
export declare function bedrockagentcoreBrowserCustomRecordingConfigS3LocationToTerraform(struct?: BedrockagentcoreBrowserCustomRecordingConfigS3Location | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomRecordingConfigS3LocationToHclTerraform(struct?: BedrockagentcoreBrowserCustomRecordingConfigS3Location | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomRecordingConfigS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreBrowserCustomRecordingConfigS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomRecordingConfigS3Location | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
export interface BedrockagentcoreBrowserCustomRecordingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#enabled BedrockagentcoreBrowserCustom#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * S3 Location Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#s3_location BedrockagentcoreBrowserCustom#s3_location}
    */
    readonly s3Location?: BedrockagentcoreBrowserCustomRecordingConfigS3Location;
}
export declare function bedrockagentcoreBrowserCustomRecordingConfigToTerraform(struct?: BedrockagentcoreBrowserCustomRecordingConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCustomRecordingConfigToHclTerraform(struct?: BedrockagentcoreBrowserCustomRecordingConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCustomRecordingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreBrowserCustomRecordingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCustomRecordingConfig | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _s3Location;
    get s3Location(): BedrockagentcoreBrowserCustomRecordingConfigS3LocationOutputReference;
    putS3Location(value: BedrockagentcoreBrowserCustomRecordingConfigS3Location): void;
    resetS3Location(): void;
    get s3LocationInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomRecordingConfigS3Location | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom awscc_bedrockagentcore_browser_custom}
*/
export declare class BedrockagentcoreBrowserCustom extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_browser_custom";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreBrowserCustom resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreBrowserCustom to import
    * @param importFromId The id of the existing BedrockagentcoreBrowserCustom that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreBrowserCustom to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_browser_custom awscc_bedrockagentcore_browser_custom} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreBrowserCustomConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreBrowserCustomConfig);
    get browserArn(): string;
    get browserId(): string;
    private _browserSigning;
    get browserSigning(): BedrockagentcoreBrowserCustomBrowserSigningOutputReference;
    putBrowserSigning(value: BedrockagentcoreBrowserCustomBrowserSigning): void;
    resetBrowserSigning(): void;
    get browserSigningInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomBrowserSigning | undefined;
    private _certificates;
    get certificates(): BedrockagentcoreBrowserCustomCertificatesList;
    putCertificates(value: BedrockagentcoreBrowserCustomCertificates[] | cdktn.IResolvable): void;
    resetCertificates(): void;
    get certificatesInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomCertificates[] | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enterprisePolicies;
    get enterprisePolicies(): BedrockagentcoreBrowserCustomEnterprisePoliciesList;
    putEnterprisePolicies(value: BedrockagentcoreBrowserCustomEnterprisePolicies[] | cdktn.IResolvable): void;
    resetEnterprisePolicies(): void;
    get enterprisePoliciesInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomEnterprisePolicies[] | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    get failureReason(): string;
    get id(): string;
    get lastUpdatedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BedrockagentcoreBrowserCustomNetworkConfigurationOutputReference;
    putNetworkConfiguration(value: BedrockagentcoreBrowserCustomNetworkConfiguration): void;
    get networkConfigurationInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomNetworkConfiguration | undefined;
    private _recordingConfig;
    get recordingConfig(): BedrockagentcoreBrowserCustomRecordingConfigOutputReference;
    putRecordingConfig(value: BedrockagentcoreBrowserCustomRecordingConfig): void;
    resetRecordingConfig(): void;
    get recordingConfigInput(): cdktn.IResolvable | BedrockagentcoreBrowserCustomRecordingConfig | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
