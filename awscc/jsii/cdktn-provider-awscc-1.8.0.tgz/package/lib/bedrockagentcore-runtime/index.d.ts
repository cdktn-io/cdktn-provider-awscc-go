/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreRuntimeConfig extends cdktn.TerraformMetaArguments {
    /**
    * The artifact of the agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#agent_runtime_artifact BedrockagentcoreRuntime#agent_runtime_artifact}
    */
    readonly agentRuntimeArtifact: BedrockagentcoreRuntimeAgentRuntimeArtifact;
    /**
    * Name for a resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#agent_runtime_name BedrockagentcoreRuntime#agent_runtime_name}
    */
    readonly agentRuntimeName: string;
    /**
    * Authorizer configuration for the agent runtime
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#authorizer_configuration BedrockagentcoreRuntime#authorizer_configuration}
    */
    readonly authorizerConfiguration?: BedrockagentcoreRuntimeAuthorizerConfiguration;
    /**
    * Capacity provider configuration for the agent runtime
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#capacity_provider_configuration BedrockagentcoreRuntime#capacity_provider_configuration}
    */
    readonly capacityProviderConfiguration?: BedrockagentcoreRuntimeCapacityProviderConfiguration;
    /**
    * Description of the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#description BedrockagentcoreRuntime#description}
    */
    readonly description?: string;
    /**
    * Environment variables for the agent runtime
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#environment_variables BedrockagentcoreRuntime#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Filesystem configurations for the agent runtime
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#filesystem_configurations BedrockagentcoreRuntime#filesystem_configurations}
    */
    readonly filesystemConfigurations?: BedrockagentcoreRuntimeFilesystemConfigurations[] | cdktn.IResolvable;
    /**
    * Lifecycle configuration for managing runtime sessions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#lifecycle_configuration BedrockagentcoreRuntime#lifecycle_configuration}
    */
    readonly lifecycleConfiguration?: BedrockagentcoreRuntimeLifecycleConfiguration;
    /**
    * Network access configuration for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#network_configuration BedrockagentcoreRuntime#network_configuration}
    */
    readonly networkConfiguration?: BedrockagentcoreRuntimeNetworkConfiguration;
    /**
    * The version of the runtime platform
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#platform_version BedrockagentcoreRuntime#platform_version}
    */
    readonly platformVersion?: string;
    /**
    * Protocol configuration for the agent runtime
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#protocol_configuration BedrockagentcoreRuntime#protocol_configuration}
    */
    readonly protocolConfiguration?: string;
    /**
    * Configuration for HTTP request headers
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#request_header_configuration BedrockagentcoreRuntime#request_header_configuration}
    */
    readonly requestHeaderConfiguration?: BedrockagentcoreRuntimeRequestHeaderConfiguration;
    /**
    * Amazon Resource Name (ARN) of an IAM role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#role_arn BedrockagentcoreRuntime#role_arn}
    */
    readonly roleArn: string;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#tags BedrockagentcoreRuntime#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3 {
    /**
    * S3 bucket name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#bucket BedrockagentcoreRuntime#bucket}
    */
    readonly bucket?: string;
    /**
    * S3 object key prefix
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#prefix BedrockagentcoreRuntime#prefix}
    */
    readonly prefix?: string;
    /**
    * S3 object version ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#version_id BedrockagentcoreRuntime#version_id}
    */
    readonly versionId?: string;
}
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3ToTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3ToHclTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3 | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCode {
    /**
    * S3 Location Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#s3 BedrockagentcoreRuntime#s3}
    */
    readonly s3?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3;
}
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeToTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCode | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeToHclTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCode | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCode | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCode | cdktn.IResolvable | undefined);
    private _s3;
    get s3(): BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3OutputReference;
    putS3(value: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeS3 | undefined;
}
export interface BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfiguration {
    /**
    * Object represents source code from zip file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#code BedrockagentcoreRuntime#code}
    */
    readonly code?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCode;
    /**
    * List of entry points
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#entry_point BedrockagentcoreRuntime#entry_point}
    */
    readonly entryPoint?: string[];
    /**
    * Managed runtime types
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#runtime BedrockagentcoreRuntime#runtime}
    */
    readonly runtime?: string;
}
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationToTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationToHclTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfiguration | cdktn.IResolvable | undefined);
    private _code;
    get code(): BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCodeOutputReference;
    putCode(value: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCode): void;
    resetCode(): void;
    get codeInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationCode | undefined;
    private _entryPoint?;
    get entryPoint(): string[];
    set entryPoint(value: string[]);
    resetEntryPoint(): void;
    get entryPointInput(): string[] | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    resetRuntime(): void;
    get runtimeInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfiguration {
    /**
    * The ECR URI of the container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#container_uri BedrockagentcoreRuntime#container_uri}
    */
    readonly containerUri?: string;
}
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfigurationToTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfigurationToHclTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfiguration | cdktn.IResolvable | undefined);
    private _containerUri?;
    get containerUri(): string;
    set containerUri(value: string);
    resetContainerUri(): void;
    get containerUriInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeAgentRuntimeArtifact {
    /**
    * Representation of a code configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#code_configuration BedrockagentcoreRuntime#code_configuration}
    */
    readonly codeConfiguration?: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#container_configuration BedrockagentcoreRuntime#container_configuration}
    */
    readonly containerConfiguration?: BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfiguration;
}
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactToTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifact | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAgentRuntimeArtifactToHclTerraform(struct?: BedrockagentcoreRuntimeAgentRuntimeArtifact | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAgentRuntimeArtifactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAgentRuntimeArtifact | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAgentRuntimeArtifact | cdktn.IResolvable | undefined);
    private _codeConfiguration;
    get codeConfiguration(): BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfigurationOutputReference;
    putCodeConfiguration(value: BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfiguration): void;
    resetCodeConfiguration(): void;
    get codeConfigurationInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAgentRuntimeArtifactCodeConfiguration | undefined;
    private _containerConfiguration;
    get containerConfiguration(): BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfigurationOutputReference;
    putContainerConfiguration(value: BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfiguration): void;
    resetContainerConfiguration(): void;
    get containerConfigurationInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAgentRuntimeArtifactContainerConfiguration | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments {
    /**
    * The ARN of the bedrock-agentcore hosting environment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#arn BedrockagentcoreRuntime#arn}
    */
    readonly arn?: string;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentsToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentsToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
}
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentsOutputReference;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration {
    /**
    * List of allow-listed hosting environments
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#hosting_environments BedrockagentcoreRuntime#hosting_environments}
    */
    readonly hostingEnvironments?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments[] | cdktn.IResolvable;
    /**
    * List of allow-listed workload identity names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#workload_identities BedrockagentcoreRuntime#workload_identities}
    */
    readonly workloadIdentities?: string[];
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | cdktn.IResolvable | undefined);
    private _hostingEnvironments;
    get hostingEnvironments(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentsList;
    putHostingEnvironments(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments[] | cdktn.IResolvable): void;
    resetHostingEnvironments(): void;
    get hostingEnvironmentsInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironments[] | undefined;
    private _workloadIdentities?;
    get workloadIdentities(): string[];
    set workloadIdentities(value: string[]);
    resetWorkloadIdentities(): void;
    get workloadIdentitiesInput(): string[] | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue {
    /**
    * The string value to match for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#match_value_string BedrockagentcoreRuntime#match_value_string}
    */
    readonly matchValueString?: string;
    /**
    * The list of strings to check for a match
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#match_value_string_list BedrockagentcoreRuntime#match_value_string_list}
    */
    readonly matchValueStringList?: string[];
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined);
    private _matchValueString?;
    get matchValueString(): string;
    set matchValueString(value: string);
    resetMatchValueString(): void;
    get matchValueStringInput(): string | undefined;
    private _matchValueStringList?;
    get matchValueStringList(): string[];
    set matchValueStringList(value: string[]);
    resetMatchValueStringList(): void;
    get matchValueStringListInput(): string[] | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue {
    /**
    * The relationship between the claim field value and the value or values being matched
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#claim_match_operator BedrockagentcoreRuntime#claim_match_operator}
    */
    readonly claimMatchOperator?: string;
    /**
    * The value or values in the custom claim to match for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#claim_match_value BedrockagentcoreRuntime#claim_match_value}
    */
    readonly claimMatchValue?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined);
    private _claimMatchOperator?;
    get claimMatchOperator(): string;
    set claimMatchOperator(value: string);
    resetClaimMatchOperator(): void;
    get claimMatchOperatorInput(): string | undefined;
    private _claimMatchValue;
    get claimMatchValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference;
    putClaimMatchValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue): void;
    resetClaimMatchValue(): void;
    get claimMatchValueInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims {
    /**
    * The value or values in the custom claim to match and relationship of match
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#authorizing_claim_match_value BedrockagentcoreRuntime#authorizing_claim_match_value}
    */
    readonly authorizingClaimMatchValue?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue;
    /**
    * The name of the custom claim to validate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#inbound_token_claim_name BedrockagentcoreRuntime#inbound_token_claim_name}
    */
    readonly inboundTokenClaimName?: string;
    /**
    * Token claim data type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#inbound_token_claim_value_type BedrockagentcoreRuntime#inbound_token_claim_value_type}
    */
    readonly inboundTokenClaimValueType?: string;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined);
    private _authorizingClaimMatchValue;
    get authorizingClaimMatchValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference;
    putAuthorizingClaimMatchValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue): void;
    resetAuthorizingClaimMatchValue(): void;
    get authorizingClaimMatchValueInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | undefined;
    private _inboundTokenClaimName?;
    get inboundTokenClaimName(): string;
    set inboundTokenClaimName(value: string);
    resetInboundTokenClaimName(): void;
    get inboundTokenClaimNameInput(): string | undefined;
    private _inboundTokenClaimValueType?;
    get inboundTokenClaimValueType(): string;
    set inboundTokenClaimValueType(value: string);
    resetInboundTokenClaimValueType(): void;
    get inboundTokenClaimValueTypeInput(): string | undefined;
}
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource {
    /**
    * The IP address type for the endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#endpoint_ip_address_type BedrockagentcoreRuntime#endpoint_ip_address_type}
    */
    readonly endpointIpAddressType?: string;
    /**
    * An intermediate domain to use as the resource configuration endpoint instead of the actual target domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#routing_domain BedrockagentcoreRuntime#routing_domain}
    */
    readonly routingDomain?: string;
    /**
    * The security group IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#security_group_ids BedrockagentcoreRuntime#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * The subnet IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#subnet_ids BedrockagentcoreRuntime#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Tags to apply to the managed VPC Lattice resource gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#tags BedrockagentcoreRuntime#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * The VPC identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#vpc_identifier BedrockagentcoreRuntime#vpc_identifier}
    */
    readonly vpcIdentifier?: string;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined);
    private _endpointIpAddressType?;
    get endpointIpAddressType(): string;
    set endpointIpAddressType(value: string);
    resetEndpointIpAddressType(): void;
    get endpointIpAddressTypeInput(): string | undefined;
    private _routingDomain?;
    get routingDomain(): string;
    set routingDomain(value: string);
    resetRoutingDomain(): void;
    get routingDomainInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdentifier?;
    get vpcIdentifier(): string;
    set vpcIdentifier(value: string);
    resetVpcIdentifier(): void;
    get vpcIdentifierInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource {
    /**
    * The identifier of the VPC Lattice resource configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#resource_configuration_identifier BedrockagentcoreRuntime#resource_configuration_identifier}
    */
    readonly resourceConfigurationIdentifier?: string;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined);
    private _resourceConfigurationIdentifier?;
    get resourceConfigurationIdentifier(): string;
    set resourceConfigurationIdentifier(value: string);
    resetResourceConfigurationIdentifier(): void;
    get resourceConfigurationIdentifierInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint {
    /**
    * Managed VPC resource configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#managed_vpc_resource BedrockagentcoreRuntime#managed_vpc_resource}
    */
    readonly managedVpcResource?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource;
    /**
    * Self-managed VPC Lattice resource configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#self_managed_lattice_resource BedrockagentcoreRuntime#self_managed_lattice_resource}
    */
    readonly selfManagedLatticeResource?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable | undefined);
    private _managedVpcResource;
    get managedVpcResource(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceOutputReference;
    putManagedVpcResource(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource): void;
    resetManagedVpcResource(): void;
    get managedVpcResourceInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | undefined;
    private _selfManagedLatticeResource;
    get selfManagedLatticeResource(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceOutputReference;
    putSelfManagedLatticeResource(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource): void;
    resetSelfManagedLatticeResource(): void;
    get selfManagedLatticeResourceInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource {
    /**
    * The IP address type for the endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#endpoint_ip_address_type BedrockagentcoreRuntime#endpoint_ip_address_type}
    */
    readonly endpointIpAddressType?: string;
    /**
    * An intermediate domain to use as the resource configuration endpoint instead of the actual target domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#routing_domain BedrockagentcoreRuntime#routing_domain}
    */
    readonly routingDomain?: string;
    /**
    * The security group IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#security_group_ids BedrockagentcoreRuntime#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * The subnet IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#subnet_ids BedrockagentcoreRuntime#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Tags to apply to the managed VPC Lattice resource gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#tags BedrockagentcoreRuntime#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * The VPC identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#vpc_identifier BedrockagentcoreRuntime#vpc_identifier}
    */
    readonly vpcIdentifier?: string;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined);
    private _endpointIpAddressType?;
    get endpointIpAddressType(): string;
    set endpointIpAddressType(value: string);
    resetEndpointIpAddressType(): void;
    get endpointIpAddressTypeInput(): string | undefined;
    private _routingDomain?;
    get routingDomain(): string;
    set routingDomain(value: string);
    resetRoutingDomain(): void;
    get routingDomainInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdentifier?;
    get vpcIdentifier(): string;
    set vpcIdentifier(value: string);
    resetVpcIdentifier(): void;
    get vpcIdentifierInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource {
    /**
    * The identifier of the VPC Lattice resource configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#resource_configuration_identifier BedrockagentcoreRuntime#resource_configuration_identifier}
    */
    readonly resourceConfigurationIdentifier?: string;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined);
    private _resourceConfigurationIdentifier?;
    get resourceConfigurationIdentifier(): string;
    set resourceConfigurationIdentifier(value: string);
    resetResourceConfigurationIdentifier(): void;
    get resourceConfigurationIdentifierInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint {
    /**
    * Managed VPC resource configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#managed_vpc_resource BedrockagentcoreRuntime#managed_vpc_resource}
    */
    readonly managedVpcResource?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource;
    /**
    * Self-managed VPC Lattice resource configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#self_managed_lattice_resource BedrockagentcoreRuntime#self_managed_lattice_resource}
    */
    readonly selfManagedLatticeResource?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | cdktn.IResolvable | undefined);
    private _managedVpcResource;
    get managedVpcResource(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceOutputReference;
    putManagedVpcResource(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource): void;
    resetManagedVpcResource(): void;
    get managedVpcResourceInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | undefined;
    private _selfManagedLatticeResource;
    get selfManagedLatticeResource(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceOutputReference;
    putSelfManagedLatticeResource(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource): void;
    resetSelfManagedLatticeResource(): void;
    get selfManagedLatticeResourceInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides {
    /**
    * The domain to override
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#domain BedrockagentcoreRuntime#domain}
    */
    readonly domain?: string;
    /**
    * Private endpoint configuration. Exactly one of SelfManagedLatticeResource or ManagedVpcResource must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#private_endpoint BedrockagentcoreRuntime#private_endpoint}
    */
    readonly privateEndpoint?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides | cdktn.IResolvable | undefined);
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _privateEndpoint;
    get privateEndpoint(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointOutputReference;
    putPrivateEndpoint(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint): void;
    resetPrivateEndpoint(): void;
    get privateEndpointInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | undefined;
}
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesOutputReference;
}
export interface BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizer {
    /**
    * List of allowed audiences
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#allowed_audience BedrockagentcoreRuntime#allowed_audience}
    */
    readonly allowedAudience?: string[];
    /**
    * List of allowed clients
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#allowed_clients BedrockagentcoreRuntime#allowed_clients}
    */
    readonly allowedClients?: string[];
    /**
    * List of allowed scopes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#allowed_scopes BedrockagentcoreRuntime#allowed_scopes}
    */
    readonly allowedScopes?: string[];
    /**
    * Allow-list of upstream workloads permitted to reach this resource via the workload identity chain. When set, the data plane enforces that the introspected workload chain's caller matches one of the configured hosting environments or workload identities; absent means no chain enforcement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#allowed_workload_configuration BedrockagentcoreRuntime#allowed_workload_configuration}
    */
    readonly allowedWorkloadConfiguration?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration;
    /**
    * List of required custom claims
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#custom_claims BedrockagentcoreRuntime#custom_claims}
    */
    readonly customClaims?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * OpenID Connect discovery URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#discovery_url BedrockagentcoreRuntime#discovery_url}
    */
    readonly discoveryUrl?: string;
    /**
    * Private endpoint configuration. Exactly one of SelfManagedLatticeResource or ManagedVpcResource must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#private_endpoint BedrockagentcoreRuntime#private_endpoint}
    */
    readonly privateEndpoint?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint;
    /**
    * List of private endpoint overrides
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#private_endpoint_overrides BedrockagentcoreRuntime#private_endpoint_overrides}
    */
    readonly privateEndpointOverrides?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined);
    private _allowedAudience?;
    get allowedAudience(): string[];
    set allowedAudience(value: string[]);
    resetAllowedAudience(): void;
    get allowedAudienceInput(): string[] | undefined;
    private _allowedClients?;
    get allowedClients(): string[];
    set allowedClients(value: string[]);
    resetAllowedClients(): void;
    get allowedClientsInput(): string[] | undefined;
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
    private _allowedWorkloadConfiguration;
    get allowedWorkloadConfiguration(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationOutputReference;
    putAllowedWorkloadConfiguration(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration): void;
    resetAllowedWorkloadConfiguration(): void;
    get allowedWorkloadConfigurationInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | undefined;
    private _customClaims;
    get customClaims(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList;
    putCustomClaims(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable): void;
    resetCustomClaims(): void;
    get customClaimsInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | undefined;
    private _discoveryUrl?;
    get discoveryUrl(): string;
    set discoveryUrl(value: string);
    resetDiscoveryUrl(): void;
    get discoveryUrlInput(): string | undefined;
    private _privateEndpoint;
    get privateEndpoint(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOutputReference;
    putPrivateEndpoint(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint): void;
    resetPrivateEndpoint(): void;
    get privateEndpointInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | undefined;
    private _privateEndpointOverrides;
    get privateEndpointOverrides(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesList;
    putPrivateEndpointOverrides(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides[] | cdktn.IResolvable): void;
    resetPrivateEndpointOverrides(): void;
    get privateEndpointOverridesInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides[] | undefined;
}
export interface BedrockagentcoreRuntimeAuthorizerConfiguration {
    /**
    * Configuration for custom JWT authorizer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#custom_jwt_authorizer BedrockagentcoreRuntime#custom_jwt_authorizer}
    */
    readonly customJwtAuthorizer?: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizer;
}
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationToTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeAuthorizerConfigurationToHclTerraform(struct?: BedrockagentcoreRuntimeAuthorizerConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeAuthorizerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeAuthorizerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeAuthorizerConfiguration | cdktn.IResolvable | undefined);
    private _customJwtAuthorizer;
    get customJwtAuthorizer(): BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizerOutputReference;
    putCustomJwtAuthorizer(value: BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizer): void;
    resetCustomJwtAuthorizer(): void;
    get customJwtAuthorizerInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfigurationCustomJwtAuthorizer | undefined;
}
export interface BedrockagentcoreRuntimeCapacityProviderConfiguration {
    /**
    * ARN of the capacity provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#capacity_provider_arn BedrockagentcoreRuntime#capacity_provider_arn}
    */
    readonly capacityProviderArn?: string;
}
export declare function bedrockagentcoreRuntimeCapacityProviderConfigurationToTerraform(struct?: BedrockagentcoreRuntimeCapacityProviderConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeCapacityProviderConfigurationToHclTerraform(struct?: BedrockagentcoreRuntimeCapacityProviderConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeCapacityProviderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeCapacityProviderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeCapacityProviderConfiguration | cdktn.IResolvable | undefined);
    private _capacityProviderArn?;
    get capacityProviderArn(): string;
    set capacityProviderArn(value: string);
    resetCapacityProviderArn(): void;
    get capacityProviderArnInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolume {
    /**
    * Mount path for filesystem configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#mount_path BedrockagentcoreRuntime#mount_path}
    */
    readonly mountPath?: string;
    /**
    * Name of the capacity provider volume
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#volume_name BedrockagentcoreRuntime#volume_name}
    */
    readonly volumeName?: string;
}
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolumeToTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolume | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolumeToHclTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolume | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolume | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolume | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
    private _volumeName?;
    get volumeName(): string;
    set volumeName(value: string);
    resetVolumeName(): void;
    get volumeNameInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPoint {
    /**
    * ARN of the EFS access point
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#access_point_arn BedrockagentcoreRuntime#access_point_arn}
    */
    readonly accessPointArn?: string;
    /**
    * Mount path for filesystem configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#mount_path BedrockagentcoreRuntime#mount_path}
    */
    readonly mountPath?: string;
}
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPointToTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPointToHclTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPoint | cdktn.IResolvable | undefined);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    resetAccessPointArn(): void;
    get accessPointArnInput(): string | undefined;
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPoint {
    /**
    * ARN of the S3 Files access point
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#access_point_arn BedrockagentcoreRuntime#access_point_arn}
    */
    readonly accessPointArn?: string;
    /**
    * Mount path for filesystem configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#mount_path BedrockagentcoreRuntime#mount_path}
    */
    readonly mountPath?: string;
}
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPointToTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPointToHclTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPoint | cdktn.IResolvable | undefined);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    resetAccessPointArn(): void;
    get accessPointArnInput(): string | undefined;
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorage {
    /**
    * Mount path for filesystem configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#mount_path BedrockagentcoreRuntime#mount_path}
    */
    readonly mountPath?: string;
}
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsSessionStorageToTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorage | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsSessionStorageToHclTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorage | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorage | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    resetMountPath(): void;
    get mountPathInput(): string | undefined;
}
export interface BedrockagentcoreRuntimeFilesystemConfigurations {
    /**
    * Configuration for a CapacityProvider-managed volume to mount into the agent runtime
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#capacity_provider_volume BedrockagentcoreRuntime#capacity_provider_volume}
    */
    readonly capacityProviderVolume?: BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolume;
    /**
    * Configuration for EFS access point filesystem
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#efs_access_point BedrockagentcoreRuntime#efs_access_point}
    */
    readonly efsAccessPoint?: BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPoint;
    /**
    * Configuration for S3 Files access point filesystem
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#s3_files_access_point BedrockagentcoreRuntime#s3_files_access_point}
    */
    readonly s3FilesAccessPoint?: BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPoint;
    /**
    * Configuration for session storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#session_storage BedrockagentcoreRuntime#session_storage}
    */
    readonly sessionStorage?: BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorage;
}
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsToTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurations | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeFilesystemConfigurationsToHclTerraform(struct?: BedrockagentcoreRuntimeFilesystemConfigurations | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeFilesystemConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreRuntimeFilesystemConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeFilesystemConfigurations | cdktn.IResolvable | undefined);
    private _capacityProviderVolume;
    get capacityProviderVolume(): BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolumeOutputReference;
    putCapacityProviderVolume(value: BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolume): void;
    resetCapacityProviderVolume(): void;
    get capacityProviderVolumeInput(): cdktn.IResolvable | BedrockagentcoreRuntimeFilesystemConfigurationsCapacityProviderVolume | undefined;
    private _efsAccessPoint;
    get efsAccessPoint(): BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPointOutputReference;
    putEfsAccessPoint(value: BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPoint): void;
    resetEfsAccessPoint(): void;
    get efsAccessPointInput(): cdktn.IResolvable | BedrockagentcoreRuntimeFilesystemConfigurationsEfsAccessPoint | undefined;
    private _s3FilesAccessPoint;
    get s3FilesAccessPoint(): BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPointOutputReference;
    putS3FilesAccessPoint(value: BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPoint): void;
    resetS3FilesAccessPoint(): void;
    get s3FilesAccessPointInput(): cdktn.IResolvable | BedrockagentcoreRuntimeFilesystemConfigurationsS3FilesAccessPoint | undefined;
    private _sessionStorage;
    get sessionStorage(): BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorageOutputReference;
    putSessionStorage(value: BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorage): void;
    resetSessionStorage(): void;
    get sessionStorageInput(): cdktn.IResolvable | BedrockagentcoreRuntimeFilesystemConfigurationsSessionStorage | undefined;
}
export declare class BedrockagentcoreRuntimeFilesystemConfigurationsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreRuntimeFilesystemConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreRuntimeFilesystemConfigurationsOutputReference;
}
export interface BedrockagentcoreRuntimeLifecycleConfiguration {
    /**
    * Timeout in seconds for idle runtime sessions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#idle_runtime_session_timeout BedrockagentcoreRuntime#idle_runtime_session_timeout}
    */
    readonly idleRuntimeSessionTimeout?: number;
    /**
    * Maximum lifetime in seconds for runtime sessions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#max_lifetime BedrockagentcoreRuntime#max_lifetime}
    */
    readonly maxLifetime?: number;
}
export declare function bedrockagentcoreRuntimeLifecycleConfigurationToTerraform(struct?: BedrockagentcoreRuntimeLifecycleConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeLifecycleConfigurationToHclTerraform(struct?: BedrockagentcoreRuntimeLifecycleConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeLifecycleConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeLifecycleConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeLifecycleConfiguration | cdktn.IResolvable | undefined);
    private _idleRuntimeSessionTimeout?;
    get idleRuntimeSessionTimeout(): number;
    set idleRuntimeSessionTimeout(value: number);
    resetIdleRuntimeSessionTimeout(): void;
    get idleRuntimeSessionTimeoutInput(): number | undefined;
    private _maxLifetime?;
    get maxLifetime(): number;
    set maxLifetime(value: number);
    resetMaxLifetime(): void;
    get maxLifetimeInput(): number | undefined;
}
export interface BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfig {
    /**
    * Security groups for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#security_groups BedrockagentcoreRuntime#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Subnets for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#subnets BedrockagentcoreRuntime#subnets}
    */
    readonly subnets?: string[];
}
export declare function bedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfigToTerraform(struct?: BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfigToHclTerraform(struct?: BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfig | cdktn.IResolvable | undefined);
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
export interface BedrockagentcoreRuntimeNetworkConfiguration {
    /**
    * Network mode configuration type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#network_mode BedrockagentcoreRuntime#network_mode}
    */
    readonly networkMode?: string;
    /**
    * Network mode configuration for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#network_mode_config BedrockagentcoreRuntime#network_mode_config}
    */
    readonly networkModeConfig?: BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfig;
}
export declare function bedrockagentcoreRuntimeNetworkConfigurationToTerraform(struct?: BedrockagentcoreRuntimeNetworkConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeNetworkConfigurationToHclTerraform(struct?: BedrockagentcoreRuntimeNetworkConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeNetworkConfiguration | cdktn.IResolvable | undefined);
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    resetNetworkMode(): void;
    get networkModeInput(): string | undefined;
    private _networkModeConfig;
    get networkModeConfig(): BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfigOutputReference;
    putNetworkModeConfig(value: BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfig): void;
    resetNetworkModeConfig(): void;
    get networkModeConfigInput(): cdktn.IResolvable | BedrockagentcoreRuntimeNetworkConfigurationNetworkModeConfig | undefined;
}
export interface BedrockagentcoreRuntimeRequestHeaderConfiguration {
    /**
    * List of allowed HTTP headers for agent runtime requests
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#request_header_allowlist BedrockagentcoreRuntime#request_header_allowlist}
    */
    readonly requestHeaderAllowlist?: string[];
}
export declare function bedrockagentcoreRuntimeRequestHeaderConfigurationToTerraform(struct?: BedrockagentcoreRuntimeRequestHeaderConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreRuntimeRequestHeaderConfigurationToHclTerraform(struct?: BedrockagentcoreRuntimeRequestHeaderConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreRuntimeRequestHeaderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeRequestHeaderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreRuntimeRequestHeaderConfiguration | cdktn.IResolvable | undefined);
    private _requestHeaderAllowlist?;
    get requestHeaderAllowlist(): string[];
    set requestHeaderAllowlist(value: string[]);
    resetRequestHeaderAllowlist(): void;
    get requestHeaderAllowlistInput(): string[] | undefined;
}
export interface BedrockagentcoreRuntimeWorkloadIdentityDetails {
}
export declare function bedrockagentcoreRuntimeWorkloadIdentityDetailsToTerraform(struct?: BedrockagentcoreRuntimeWorkloadIdentityDetails): any;
export declare function bedrockagentcoreRuntimeWorkloadIdentityDetailsToHclTerraform(struct?: BedrockagentcoreRuntimeWorkloadIdentityDetails): any;
export declare class BedrockagentcoreRuntimeWorkloadIdentityDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreRuntimeWorkloadIdentityDetails | undefined;
    set internalValue(value: BedrockagentcoreRuntimeWorkloadIdentityDetails | undefined);
    get workloadIdentityArn(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime awscc_bedrockagentcore_runtime}
*/
export declare class BedrockagentcoreRuntime extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_runtime";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreRuntime resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreRuntime to import
    * @param importFromId The id of the existing BedrockagentcoreRuntime that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreRuntime to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_runtime awscc_bedrockagentcore_runtime} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreRuntimeConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreRuntimeConfig);
    get agentRuntimeArn(): string;
    private _agentRuntimeArtifact;
    get agentRuntimeArtifact(): BedrockagentcoreRuntimeAgentRuntimeArtifactOutputReference;
    putAgentRuntimeArtifact(value: BedrockagentcoreRuntimeAgentRuntimeArtifact): void;
    get agentRuntimeArtifactInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAgentRuntimeArtifact | undefined;
    get agentRuntimeId(): string;
    private _agentRuntimeName?;
    get agentRuntimeName(): string;
    set agentRuntimeName(value: string);
    get agentRuntimeNameInput(): string | undefined;
    get agentRuntimeVersion(): string;
    private _authorizerConfiguration;
    get authorizerConfiguration(): BedrockagentcoreRuntimeAuthorizerConfigurationOutputReference;
    putAuthorizerConfiguration(value: BedrockagentcoreRuntimeAuthorizerConfiguration): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | BedrockagentcoreRuntimeAuthorizerConfiguration | undefined;
    private _capacityProviderConfiguration;
    get capacityProviderConfiguration(): BedrockagentcoreRuntimeCapacityProviderConfigurationOutputReference;
    putCapacityProviderConfiguration(value: BedrockagentcoreRuntimeCapacityProviderConfiguration): void;
    resetCapacityProviderConfiguration(): void;
    get capacityProviderConfigurationInput(): cdktn.IResolvable | BedrockagentcoreRuntimeCapacityProviderConfiguration | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    get failureReason(): string;
    private _filesystemConfigurations;
    get filesystemConfigurations(): BedrockagentcoreRuntimeFilesystemConfigurationsList;
    putFilesystemConfigurations(value: BedrockagentcoreRuntimeFilesystemConfigurations[] | cdktn.IResolvable): void;
    resetFilesystemConfigurations(): void;
    get filesystemConfigurationsInput(): cdktn.IResolvable | BedrockagentcoreRuntimeFilesystemConfigurations[] | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    private _lifecycleConfiguration;
    get lifecycleConfiguration(): BedrockagentcoreRuntimeLifecycleConfigurationOutputReference;
    putLifecycleConfiguration(value: BedrockagentcoreRuntimeLifecycleConfiguration): void;
    resetLifecycleConfiguration(): void;
    get lifecycleConfigurationInput(): cdktn.IResolvable | BedrockagentcoreRuntimeLifecycleConfiguration | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BedrockagentcoreRuntimeNetworkConfigurationOutputReference;
    putNetworkConfiguration(value: BedrockagentcoreRuntimeNetworkConfiguration): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | BedrockagentcoreRuntimeNetworkConfiguration | undefined;
    private _platformVersion?;
    get platformVersion(): string;
    set platformVersion(value: string);
    resetPlatformVersion(): void;
    get platformVersionInput(): string | undefined;
    private _protocolConfiguration?;
    get protocolConfiguration(): string;
    set protocolConfiguration(value: string);
    resetProtocolConfiguration(): void;
    get protocolConfigurationInput(): string | undefined;
    private _requestHeaderConfiguration;
    get requestHeaderConfiguration(): BedrockagentcoreRuntimeRequestHeaderConfigurationOutputReference;
    putRequestHeaderConfiguration(value: BedrockagentcoreRuntimeRequestHeaderConfiguration): void;
    resetRequestHeaderConfiguration(): void;
    get requestHeaderConfigurationInput(): cdktn.IResolvable | BedrockagentcoreRuntimeRequestHeaderConfiguration | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _workloadIdentityDetails;
    get workloadIdentityDetails(): BedrockagentcoreRuntimeWorkloadIdentityDetailsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
