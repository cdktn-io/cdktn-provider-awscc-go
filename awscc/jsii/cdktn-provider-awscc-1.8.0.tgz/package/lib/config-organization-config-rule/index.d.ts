/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigOrganizationConfigRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * A comma-separated list of accounts that you want to exclude from an organization AWS Config rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#excluded_accounts ConfigOrganizationConfigRule#excluded_accounts}
    */
    readonly excludedAccounts?: string[];
    /**
    * The name that you assign to an organization AWS Config rule. Required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#organization_config_rule_name ConfigOrganizationConfigRule#organization_config_rule_name}
    */
    readonly organizationConfigRuleName: string;
    /**
    * This object specifies metadata for your organization's AWS Config Custom Policy rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#organization_custom_policy_rule_metadata ConfigOrganizationConfigRule#organization_custom_policy_rule_metadata}
    */
    readonly organizationCustomPolicyRuleMetadata?: ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadata;
    /**
    * This object specifies organization custom rule metadata such as resource type, resource ID of AWS resource, Lambda function ARN, and organization trigger types that trigger AWS Config to evaluate your AWS resources against a rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#organization_custom_rule_metadata ConfigOrganizationConfigRule#organization_custom_rule_metadata}
    */
    readonly organizationCustomRuleMetadata?: ConfigOrganizationConfigRuleOrganizationCustomRuleMetadata;
    /**
    * This object specifies organization managed rule metadata such as resource type and ID of AWS resource along with the rule identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#organization_managed_rule_metadata ConfigOrganizationConfigRule#organization_managed_rule_metadata}
    */
    readonly organizationManagedRuleMetadata?: ConfigOrganizationConfigRuleOrganizationManagedRuleMetadata;
}
export interface ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadata {
    /**
    * A list of accounts that you can enable debug logging for your organization AWS Config Custom Policy rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#debug_log_delivery_accounts ConfigOrganizationConfigRule#debug_log_delivery_accounts}
    */
    readonly debugLogDeliveryAccounts?: string[];
    /**
    * The description that you provide for your organization AWS Config rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#description ConfigOrganizationConfigRule#description}
    */
    readonly description?: string;
    /**
    * A string, in JSON format, that is passed to your organization AWS Config Custom Policy rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#input_parameters ConfigOrganizationConfigRule#input_parameters}
    */
    readonly inputParameters?: string;
    /**
    * The type of notification that initiates AWS Config to run an evaluation for a rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#organization_config_rule_trigger_types ConfigOrganizationConfigRule#organization_config_rule_trigger_types}
    */
    readonly organizationConfigRuleTriggerTypes?: string[];
    /**
    * The policy definition containing the logic for your organization AWS Config Custom Policy rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#policy_text ConfigOrganizationConfigRule#policy_text}
    */
    readonly policyText?: string;
    /**
    * The ID of the AWS resource that was evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#resource_id_scope ConfigOrganizationConfigRule#resource_id_scope}
    */
    readonly resourceIdScope?: string;
    /**
    * The type of the AWS resource that was evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#resource_types_scope ConfigOrganizationConfigRule#resource_types_scope}
    */
    readonly resourceTypesScope?: string[];
    /**
    * The runtime system for your organization AWS Config Custom Policy rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#runtime ConfigOrganizationConfigRule#runtime}
    */
    readonly runtime?: string;
    /**
    * One part of a key-value pair that make up a tag. A key is a general label that acts like a category for more specific tag values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#tag_key_scope ConfigOrganizationConfigRule#tag_key_scope}
    */
    readonly tagKeyScope?: string;
    /**
    * The optional part of a key-value pair that make up a tag. A value acts as a descriptor within a tag category (key).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#tag_value_scope ConfigOrganizationConfigRule#tag_value_scope}
    */
    readonly tagValueScope?: string;
}
export declare function configOrganizationConfigRuleOrganizationCustomPolicyRuleMetadataToTerraform(struct?: ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadata | cdktn.IResolvable): any;
export declare function configOrganizationConfigRuleOrganizationCustomPolicyRuleMetadataToHclTerraform(struct?: ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadata | cdktn.IResolvable): any;
export declare class ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadata | cdktn.IResolvable | undefined);
    private _debugLogDeliveryAccounts?;
    get debugLogDeliveryAccounts(): string[];
    set debugLogDeliveryAccounts(value: string[]);
    resetDebugLogDeliveryAccounts(): void;
    get debugLogDeliveryAccountsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inputParameters?;
    get inputParameters(): string;
    set inputParameters(value: string);
    resetInputParameters(): void;
    get inputParametersInput(): string | undefined;
    private _organizationConfigRuleTriggerTypes?;
    get organizationConfigRuleTriggerTypes(): string[];
    set organizationConfigRuleTriggerTypes(value: string[]);
    resetOrganizationConfigRuleTriggerTypes(): void;
    get organizationConfigRuleTriggerTypesInput(): string[] | undefined;
    private _policyText?;
    get policyText(): string;
    set policyText(value: string);
    resetPolicyText(): void;
    get policyTextInput(): string | undefined;
    private _resourceIdScope?;
    get resourceIdScope(): string;
    set resourceIdScope(value: string);
    resetResourceIdScope(): void;
    get resourceIdScopeInput(): string | undefined;
    private _resourceTypesScope?;
    get resourceTypesScope(): string[];
    set resourceTypesScope(value: string[]);
    resetResourceTypesScope(): void;
    get resourceTypesScopeInput(): string[] | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    resetRuntime(): void;
    get runtimeInput(): string | undefined;
    private _tagKeyScope?;
    get tagKeyScope(): string;
    set tagKeyScope(value: string);
    resetTagKeyScope(): void;
    get tagKeyScopeInput(): string | undefined;
    private _tagValueScope?;
    get tagValueScope(): string;
    set tagValueScope(value: string);
    resetTagValueScope(): void;
    get tagValueScopeInput(): string | undefined;
}
export interface ConfigOrganizationConfigRuleOrganizationCustomRuleMetadata {
    /**
    * The description that you provide for your organization AWS Config rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#description ConfigOrganizationConfigRule#description}
    */
    readonly description?: string;
    /**
    * A string, in JSON format, that is passed to your organization AWS Config rule Lambda function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#input_parameters ConfigOrganizationConfigRule#input_parameters}
    */
    readonly inputParameters?: string;
    /**
    * The lambda function ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#lambda_function_arn ConfigOrganizationConfigRule#lambda_function_arn}
    */
    readonly lambdaFunctionArn?: string;
    /**
    * The maximum frequency with which AWS Config runs evaluations for a rule.Allowed values: One_Hour | Three_Hours | Six_Hours | Twelve_Hours | TwentyFour_Hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#maximum_execution_frequency ConfigOrganizationConfigRule#maximum_execution_frequency}
    */
    readonly maximumExecutionFrequency?: string;
    /**
    * The type of notification that triggers AWS Config to run an evaluation for a rule. You can specify the following notification types:
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#organization_config_rule_trigger_types ConfigOrganizationConfigRule#organization_config_rule_trigger_types}
    */
    readonly organizationConfigRuleTriggerTypes?: string[];
    /**
    * The ID of the AWS resource that was evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#resource_id_scope ConfigOrganizationConfigRule#resource_id_scope}
    */
    readonly resourceIdScope?: string;
    /**
    * The type of the AWS resource that was evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#resource_types_scope ConfigOrganizationConfigRule#resource_types_scope}
    */
    readonly resourceTypesScope?: string[];
    /**
    * One part of a key-value pair that make up a tag. A key is a general label that acts like a category for more specific tag values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#tag_key_scope ConfigOrganizationConfigRule#tag_key_scope}
    */
    readonly tagKeyScope?: string;
    /**
    * The optional part of a key-value pair that make up a tag. A value acts as a descriptor within a tag category (key).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#tag_value_scope ConfigOrganizationConfigRule#tag_value_scope}
    */
    readonly tagValueScope?: string;
}
export declare function configOrganizationConfigRuleOrganizationCustomRuleMetadataToTerraform(struct?: ConfigOrganizationConfigRuleOrganizationCustomRuleMetadata | cdktn.IResolvable): any;
export declare function configOrganizationConfigRuleOrganizationCustomRuleMetadataToHclTerraform(struct?: ConfigOrganizationConfigRuleOrganizationCustomRuleMetadata | cdktn.IResolvable): any;
export declare class ConfigOrganizationConfigRuleOrganizationCustomRuleMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigOrganizationConfigRuleOrganizationCustomRuleMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigOrganizationConfigRuleOrganizationCustomRuleMetadata | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inputParameters?;
    get inputParameters(): string;
    set inputParameters(value: string);
    resetInputParameters(): void;
    get inputParametersInput(): string | undefined;
    private _lambdaFunctionArn?;
    get lambdaFunctionArn(): string;
    set lambdaFunctionArn(value: string);
    resetLambdaFunctionArn(): void;
    get lambdaFunctionArnInput(): string | undefined;
    private _maximumExecutionFrequency?;
    get maximumExecutionFrequency(): string;
    set maximumExecutionFrequency(value: string);
    resetMaximumExecutionFrequency(): void;
    get maximumExecutionFrequencyInput(): string | undefined;
    private _organizationConfigRuleTriggerTypes?;
    get organizationConfigRuleTriggerTypes(): string[];
    set organizationConfigRuleTriggerTypes(value: string[]);
    resetOrganizationConfigRuleTriggerTypes(): void;
    get organizationConfigRuleTriggerTypesInput(): string[] | undefined;
    private _resourceIdScope?;
    get resourceIdScope(): string;
    set resourceIdScope(value: string);
    resetResourceIdScope(): void;
    get resourceIdScopeInput(): string | undefined;
    private _resourceTypesScope?;
    get resourceTypesScope(): string[];
    set resourceTypesScope(value: string[]);
    resetResourceTypesScope(): void;
    get resourceTypesScopeInput(): string[] | undefined;
    private _tagKeyScope?;
    get tagKeyScope(): string;
    set tagKeyScope(value: string);
    resetTagKeyScope(): void;
    get tagKeyScopeInput(): string | undefined;
    private _tagValueScope?;
    get tagValueScope(): string;
    set tagValueScope(value: string);
    resetTagValueScope(): void;
    get tagValueScopeInput(): string | undefined;
}
export interface ConfigOrganizationConfigRuleOrganizationManagedRuleMetadata {
    /**
    * The description that you provide for your organization AWS Config rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#description ConfigOrganizationConfigRule#description}
    */
    readonly description?: string;
    /**
    * A string, in JSON format, that is passed to your organization AWS Config rule Lambda function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#input_parameters ConfigOrganizationConfigRule#input_parameters}
    */
    readonly inputParameters?: string;
    /**
    * The maximum frequency with which AWS Config runs evaluations for a rule. Valid Values: One_Hour | Three_Hours | Six_Hours | Twelve_Hours | TwentyFour_Hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#maximum_execution_frequency ConfigOrganizationConfigRule#maximum_execution_frequency}
    */
    readonly maximumExecutionFrequency?: string;
    /**
    * The ID of the AWS resource that was evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#resource_id_scope ConfigOrganizationConfigRule#resource_id_scope}
    */
    readonly resourceIdScope?: string;
    /**
    * The type of the AWS resource that was evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#resource_types_scope ConfigOrganizationConfigRule#resource_types_scope}
    */
    readonly resourceTypesScope?: string[];
    /**
    * Required. For organization config managed rules, a predefined identifier from a list. For example, IAM_PASSWORD_POLICY is a managed rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#rule_identifier ConfigOrganizationConfigRule#rule_identifier}
    */
    readonly ruleIdentifier?: string;
    /**
    * One part of a key-value pair that make up a tag. A key is a general label that acts like a category for more specific tag values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#tag_key_scope ConfigOrganizationConfigRule#tag_key_scope}
    */
    readonly tagKeyScope?: string;
    /**
    * The optional part of a key-value pair that make up a tag. A value acts as a descriptor within a tag category (key).
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#tag_value_scope ConfigOrganizationConfigRule#tag_value_scope}
    */
    readonly tagValueScope?: string;
}
export declare function configOrganizationConfigRuleOrganizationManagedRuleMetadataToTerraform(struct?: ConfigOrganizationConfigRuleOrganizationManagedRuleMetadata | cdktn.IResolvable): any;
export declare function configOrganizationConfigRuleOrganizationManagedRuleMetadataToHclTerraform(struct?: ConfigOrganizationConfigRuleOrganizationManagedRuleMetadata | cdktn.IResolvable): any;
export declare class ConfigOrganizationConfigRuleOrganizationManagedRuleMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigOrganizationConfigRuleOrganizationManagedRuleMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigOrganizationConfigRuleOrganizationManagedRuleMetadata | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inputParameters?;
    get inputParameters(): string;
    set inputParameters(value: string);
    resetInputParameters(): void;
    get inputParametersInput(): string | undefined;
    private _maximumExecutionFrequency?;
    get maximumExecutionFrequency(): string;
    set maximumExecutionFrequency(value: string);
    resetMaximumExecutionFrequency(): void;
    get maximumExecutionFrequencyInput(): string | undefined;
    private _resourceIdScope?;
    get resourceIdScope(): string;
    set resourceIdScope(value: string);
    resetResourceIdScope(): void;
    get resourceIdScopeInput(): string | undefined;
    private _resourceTypesScope?;
    get resourceTypesScope(): string[];
    set resourceTypesScope(value: string[]);
    resetResourceTypesScope(): void;
    get resourceTypesScopeInput(): string[] | undefined;
    private _ruleIdentifier?;
    get ruleIdentifier(): string;
    set ruleIdentifier(value: string);
    resetRuleIdentifier(): void;
    get ruleIdentifierInput(): string | undefined;
    private _tagKeyScope?;
    get tagKeyScope(): string;
    set tagKeyScope(value: string);
    resetTagKeyScope(): void;
    get tagKeyScopeInput(): string | undefined;
    private _tagValueScope?;
    get tagValueScope(): string;
    set tagValueScope(value: string);
    resetTagValueScope(): void;
    get tagValueScopeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule awscc_config_organization_config_rule}
*/
export declare class ConfigOrganizationConfigRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_organization_config_rule";
    /**
    * Generates CDKTN code for importing a ConfigOrganizationConfigRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigOrganizationConfigRule to import
    * @param importFromId The id of the existing ConfigOrganizationConfigRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigOrganizationConfigRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_organization_config_rule awscc_config_organization_config_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigOrganizationConfigRuleConfig
    */
    constructor(scope: Construct, id: string, config: ConfigOrganizationConfigRuleConfig);
    private _excludedAccounts?;
    get excludedAccounts(): string[];
    set excludedAccounts(value: string[]);
    resetExcludedAccounts(): void;
    get excludedAccountsInput(): string[] | undefined;
    get id(): string;
    get organizationConfigRuleArn(): string;
    private _organizationConfigRuleName?;
    get organizationConfigRuleName(): string;
    set organizationConfigRuleName(value: string);
    get organizationConfigRuleNameInput(): string | undefined;
    private _organizationCustomPolicyRuleMetadata;
    get organizationCustomPolicyRuleMetadata(): ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadataOutputReference;
    putOrganizationCustomPolicyRuleMetadata(value: ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadata): void;
    resetOrganizationCustomPolicyRuleMetadata(): void;
    get organizationCustomPolicyRuleMetadataInput(): cdktn.IResolvable | ConfigOrganizationConfigRuleOrganizationCustomPolicyRuleMetadata | undefined;
    private _organizationCustomRuleMetadata;
    get organizationCustomRuleMetadata(): ConfigOrganizationConfigRuleOrganizationCustomRuleMetadataOutputReference;
    putOrganizationCustomRuleMetadata(value: ConfigOrganizationConfigRuleOrganizationCustomRuleMetadata): void;
    resetOrganizationCustomRuleMetadata(): void;
    get organizationCustomRuleMetadataInput(): cdktn.IResolvable | ConfigOrganizationConfigRuleOrganizationCustomRuleMetadata | undefined;
    private _organizationManagedRuleMetadata;
    get organizationManagedRuleMetadata(): ConfigOrganizationConfigRuleOrganizationManagedRuleMetadataOutputReference;
    putOrganizationManagedRuleMetadata(value: ConfigOrganizationConfigRuleOrganizationManagedRuleMetadata): void;
    resetOrganizationManagedRuleMetadata(): void;
    get organizationManagedRuleMetadataInput(): cdktn.IResolvable | ConfigOrganizationConfigRuleOrganizationManagedRuleMetadata | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
