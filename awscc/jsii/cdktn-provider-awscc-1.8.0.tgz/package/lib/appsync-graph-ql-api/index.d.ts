/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncGraphQlApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of additional authentication providers for the GraphqlApi API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#additional_authentication_providers AppsyncGraphQlApi#additional_authentication_providers}
    */
    readonly additionalAuthenticationProviders?: AppsyncGraphQlApiAdditionalAuthenticationProviders[] | cdktn.IResolvable;
    /**
    * The value that indicates whether the GraphQL API is a standard API (GRAPHQL) or merged API (MERGED).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#api_type AppsyncGraphQlApi#api_type}
    */
    readonly apiType?: string;
    /**
    * Security configuration for your GraphQL API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#authentication_type AppsyncGraphQlApi#authentication_type}
    */
    readonly authenticationType: string;
    /**
    * Enables and controls the enhanced metrics feature. Enhanced metrics emit granular data on API usage and performance such as AppSync request and error counts, latency, and cache hits/misses. All enhanced metric data is sent to your CloudWatch account, and you can configure the types of data that will be sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#enhanced_metrics_config AppsyncGraphQlApi#enhanced_metrics_config}
    */
    readonly enhancedMetricsConfig?: AppsyncGraphQlApiEnhancedMetricsConfig;
    /**
    * A map containing the list of resources with their properties and environment variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#environment_variables AppsyncGraphQlApi#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Sets the value of the GraphQL API to enable (ENABLED) or disable (DISABLED) introspection. If no value is provided, the introspection configuration will be set to ENABLED by default. This field will produce an error if the operation attempts to use the introspection feature while this field is disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#introspection_config AppsyncGraphQlApi#introspection_config}
    */
    readonly introspectionConfig?: string;
    /**
    * A LambdaAuthorizerConfig holds configuration on how to authorize AWS AppSync API access when using the AWS_LAMBDA authorizer mode. Be aware that an AWS AppSync API may have only one Lambda authorizer configured at a time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#lambda_authorizer_config AppsyncGraphQlApi#lambda_authorizer_config}
    */
    readonly lambdaAuthorizerConfig?: AppsyncGraphQlApiLambdaAuthorizerConfig;
    /**
    * The Amazon CloudWatch Logs configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#log_config AppsyncGraphQlApi#log_config}
    */
    readonly logConfig?: AppsyncGraphQlApiLogConfig;
    /**
    * The AWS Identity and Access Management service role ARN for a merged API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#merged_api_execution_role_arn AppsyncGraphQlApi#merged_api_execution_role_arn}
    */
    readonly mergedApiExecutionRoleArn?: string;
    /**
    * The API name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#name AppsyncGraphQlApi#name}
    */
    readonly name: string;
    /**
    * The OpenID Connect configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#open_id_connect_config AppsyncGraphQlApi#open_id_connect_config}
    */
    readonly openIdConnectConfig?: AppsyncGraphQlApiOpenIdConnectConfig;
    /**
    * The owner contact information for an API resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#owner_contact AppsyncGraphQlApi#owner_contact}
    */
    readonly ownerContact?: string;
    /**
    * The maximum depth a query can have in a single request. Depth refers to the amount of nested levels allowed in the body of query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#query_depth_limit AppsyncGraphQlApi#query_depth_limit}
    */
    readonly queryDepthLimit?: number;
    /**
    * The maximum number of resolvers that can be invoked in a single request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#resolver_count_limit AppsyncGraphQlApi#resolver_count_limit}
    */
    readonly resolverCountLimit?: number;
    /**
    * An arbitrary set of tags (key-value pairs) for this GraphQL API.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#tags AppsyncGraphQlApi#tags}
    */
    readonly tags?: AppsyncGraphQlApiTags[] | cdktn.IResolvable;
    /**
    * Optional authorization configuration for using Amazon Cognito user pools with your GraphQL endpoint.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#user_pool_config AppsyncGraphQlApi#user_pool_config}
    */
    readonly userPoolConfig?: AppsyncGraphQlApiUserPoolConfig;
    /**
    * Sets the scope of the GraphQL API to public (GLOBAL) or private (PRIVATE). By default, the scope is set to Global if no value is provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#visibility AppsyncGraphQlApi#visibility}
    */
    readonly visibility?: string;
    /**
    * A flag indicating whether to use AWS X-Ray tracing for this GraphqlApi.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#xray_enabled AppsyncGraphQlApi#xray_enabled}
    */
    readonly xrayEnabled?: boolean | cdktn.IResolvable;
}
export interface AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfig {
    /**
    * The number of seconds a response should be cached for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#authorizer_result_ttl_in_seconds AppsyncGraphQlApi#authorizer_result_ttl_in_seconds}
    */
    readonly authorizerResultTtlInSeconds?: number;
    /**
    * The ARN of the Lambda function to be called for authorization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#authorizer_uri AppsyncGraphQlApi#authorizer_uri}
    */
    readonly authorizerUri?: string;
    /**
    * A regular expression for validation of tokens before the Lambda function is called.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#identity_validation_expression AppsyncGraphQlApi#identity_validation_expression}
    */
    readonly identityValidationExpression?: string;
}
export declare function appsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfigToTerraform(struct?: AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfig | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfigToHclTerraform(struct?: AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfig | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfig | cdktn.IResolvable | undefined);
    private _authorizerResultTtlInSeconds?;
    get authorizerResultTtlInSeconds(): number;
    set authorizerResultTtlInSeconds(value: number);
    resetAuthorizerResultTtlInSeconds(): void;
    get authorizerResultTtlInSecondsInput(): number | undefined;
    private _authorizerUri?;
    get authorizerUri(): string;
    set authorizerUri(value: string);
    resetAuthorizerUri(): void;
    get authorizerUriInput(): string | undefined;
    private _identityValidationExpression?;
    get identityValidationExpression(): string;
    set identityValidationExpression(value: string);
    resetIdentityValidationExpression(): void;
    get identityValidationExpressionInput(): string | undefined;
}
export interface AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfig {
    /**
    * The number of milliseconds that a token is valid after being authenticated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#auth_ttl AppsyncGraphQlApi#auth_ttl}
    */
    readonly authTtl?: number;
    /**
    * The client identifier of the Relying party at the OpenID identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#client_id AppsyncGraphQlApi#client_id}
    */
    readonly clientId?: string;
    /**
    * The number of milliseconds that a token is valid after it's issued to a user.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#iat_ttl AppsyncGraphQlApi#iat_ttl}
    */
    readonly iatTtl?: number;
    /**
    * The issuer for the OIDC configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#issuer AppsyncGraphQlApi#issuer}
    */
    readonly issuer?: string;
}
export declare function appsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfigToTerraform(struct?: AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfig | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfigToHclTerraform(struct?: AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfig | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfig | cdktn.IResolvable | undefined);
    private _authTtl?;
    get authTtl(): number;
    set authTtl(value: number);
    resetAuthTtl(): void;
    get authTtlInput(): number | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _iatTtl?;
    get iatTtl(): number;
    set iatTtl(value: number);
    resetIatTtl(): void;
    get iatTtlInput(): number | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    resetIssuer(): void;
    get issuerInput(): string | undefined;
}
export interface AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfig {
    /**
    * A regular expression for validating the incoming Amazon Cognito user pool app client ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#app_id_client_regex AppsyncGraphQlApi#app_id_client_regex}
    */
    readonly appIdClientRegex?: string;
    /**
    * The AWS Region in which the user pool was created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#aws_region AppsyncGraphQlApi#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * The user pool ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#user_pool_id AppsyncGraphQlApi#user_pool_id}
    */
    readonly userPoolId?: string;
}
export declare function appsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfigToTerraform(struct?: AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfig | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfigToHclTerraform(struct?: AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfig | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfig | cdktn.IResolvable | undefined);
    private _appIdClientRegex?;
    get appIdClientRegex(): string;
    set appIdClientRegex(value: string);
    resetAppIdClientRegex(): void;
    get appIdClientRegexInput(): string | undefined;
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    resetUserPoolId(): void;
    get userPoolIdInput(): string | undefined;
}
export interface AppsyncGraphQlApiAdditionalAuthenticationProviders {
    /**
    * The authentication type for API key, AWS Identity and Access Management, OIDC, Amazon Cognito user pools, or AWS Lambda.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#authentication_type AppsyncGraphQlApi#authentication_type}
    */
    readonly authenticationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#lambda_authorizer_config AppsyncGraphQlApi#lambda_authorizer_config}
    */
    readonly lambdaAuthorizerConfig?: AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#open_id_connect_config AppsyncGraphQlApi#open_id_connect_config}
    */
    readonly openIdConnectConfig?: AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#user_pool_config AppsyncGraphQlApi#user_pool_config}
    */
    readonly userPoolConfig?: AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfig;
}
export declare function appsyncGraphQlApiAdditionalAuthenticationProvidersToTerraform(struct?: AppsyncGraphQlApiAdditionalAuthenticationProviders | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiAdditionalAuthenticationProvidersToHclTerraform(struct?: AppsyncGraphQlApiAdditionalAuthenticationProviders | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiAdditionalAuthenticationProvidersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncGraphQlApiAdditionalAuthenticationProviders | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiAdditionalAuthenticationProviders | cdktn.IResolvable | undefined);
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    resetAuthenticationType(): void;
    get authenticationTypeInput(): string | undefined;
    private _lambdaAuthorizerConfig;
    get lambdaAuthorizerConfig(): AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfigOutputReference;
    putLambdaAuthorizerConfig(value: AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfig): void;
    resetLambdaAuthorizerConfig(): void;
    get lambdaAuthorizerConfigInput(): cdktn.IResolvable | AppsyncGraphQlApiAdditionalAuthenticationProvidersLambdaAuthorizerConfig | undefined;
    private _openIdConnectConfig;
    get openIdConnectConfig(): AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfigOutputReference;
    putOpenIdConnectConfig(value: AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfig): void;
    resetOpenIdConnectConfig(): void;
    get openIdConnectConfigInput(): cdktn.IResolvable | AppsyncGraphQlApiAdditionalAuthenticationProvidersOpenIdConnectConfig | undefined;
    private _userPoolConfig;
    get userPoolConfig(): AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfigOutputReference;
    putUserPoolConfig(value: AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfig): void;
    resetUserPoolConfig(): void;
    get userPoolConfigInput(): cdktn.IResolvable | AppsyncGraphQlApiAdditionalAuthenticationProvidersUserPoolConfig | undefined;
}
export declare class AppsyncGraphQlApiAdditionalAuthenticationProvidersList extends cdktn.ComplexList {
    internalValue?: AppsyncGraphQlApiAdditionalAuthenticationProviders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncGraphQlApiAdditionalAuthenticationProvidersOutputReference;
}
export interface AppsyncGraphQlApiEnhancedMetricsConfig {
    /**
    * Controls how data source metrics will be emitted to CloudWatch. Data source metrics include:
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#data_source_level_metrics_behavior AppsyncGraphQlApi#data_source_level_metrics_behavior}
    */
    readonly dataSourceLevelMetricsBehavior?: string;
    /**
    * Controls how operation metrics will be emitted to CloudWatch. Operation metrics include:
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#operation_level_metrics_config AppsyncGraphQlApi#operation_level_metrics_config}
    */
    readonly operationLevelMetricsConfig?: string;
    /**
    * Controls how resolver metrics will be emitted to CloudWatch. Resolver metrics include:
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#resolver_level_metrics_behavior AppsyncGraphQlApi#resolver_level_metrics_behavior}
    */
    readonly resolverLevelMetricsBehavior?: string;
}
export declare function appsyncGraphQlApiEnhancedMetricsConfigToTerraform(struct?: AppsyncGraphQlApiEnhancedMetricsConfig | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiEnhancedMetricsConfigToHclTerraform(struct?: AppsyncGraphQlApiEnhancedMetricsConfig | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiEnhancedMetricsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncGraphQlApiEnhancedMetricsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiEnhancedMetricsConfig | cdktn.IResolvable | undefined);
    private _dataSourceLevelMetricsBehavior?;
    get dataSourceLevelMetricsBehavior(): string;
    set dataSourceLevelMetricsBehavior(value: string);
    resetDataSourceLevelMetricsBehavior(): void;
    get dataSourceLevelMetricsBehaviorInput(): string | undefined;
    private _operationLevelMetricsConfig?;
    get operationLevelMetricsConfig(): string;
    set operationLevelMetricsConfig(value: string);
    resetOperationLevelMetricsConfig(): void;
    get operationLevelMetricsConfigInput(): string | undefined;
    private _resolverLevelMetricsBehavior?;
    get resolverLevelMetricsBehavior(): string;
    set resolverLevelMetricsBehavior(value: string);
    resetResolverLevelMetricsBehavior(): void;
    get resolverLevelMetricsBehaviorInput(): string | undefined;
}
export interface AppsyncGraphQlApiLambdaAuthorizerConfig {
    /**
    * The number of seconds a response should be cached for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#authorizer_result_ttl_in_seconds AppsyncGraphQlApi#authorizer_result_ttl_in_seconds}
    */
    readonly authorizerResultTtlInSeconds?: number;
    /**
    * The ARN of the Lambda function to be called for authorization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#authorizer_uri AppsyncGraphQlApi#authorizer_uri}
    */
    readonly authorizerUri?: string;
    /**
    * A regular expression for validation of tokens before the Lambda function is called.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#identity_validation_expression AppsyncGraphQlApi#identity_validation_expression}
    */
    readonly identityValidationExpression?: string;
}
export declare function appsyncGraphQlApiLambdaAuthorizerConfigToTerraform(struct?: AppsyncGraphQlApiLambdaAuthorizerConfig | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiLambdaAuthorizerConfigToHclTerraform(struct?: AppsyncGraphQlApiLambdaAuthorizerConfig | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiLambdaAuthorizerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncGraphQlApiLambdaAuthorizerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiLambdaAuthorizerConfig | cdktn.IResolvable | undefined);
    private _authorizerResultTtlInSeconds?;
    get authorizerResultTtlInSeconds(): number;
    set authorizerResultTtlInSeconds(value: number);
    resetAuthorizerResultTtlInSeconds(): void;
    get authorizerResultTtlInSecondsInput(): number | undefined;
    private _authorizerUri?;
    get authorizerUri(): string;
    set authorizerUri(value: string);
    resetAuthorizerUri(): void;
    get authorizerUriInput(): string | undefined;
    private _identityValidationExpression?;
    get identityValidationExpression(): string;
    set identityValidationExpression(value: string);
    resetIdentityValidationExpression(): void;
    get identityValidationExpressionInput(): string | undefined;
}
export interface AppsyncGraphQlApiLogConfig {
    /**
    * The service role that AWS AppSync will assume to publish to Amazon CloudWatch Logs in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#cloudwatch_logs_role_arn AppsyncGraphQlApi#cloudwatch_logs_role_arn}
    */
    readonly cloudwatchLogsRoleArn?: string;
    /**
    * Set to TRUE to exclude sections that contain information such as headers, context, and evaluated mapping templates, regardless of logging level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#exclude_verbose_content AppsyncGraphQlApi#exclude_verbose_content}
    */
    readonly excludeVerboseContent?: boolean | cdktn.IResolvable;
    /**
    * The field logging level. Values can be NONE, ERROR, INFO, DEBUG, or ALL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#field_log_level AppsyncGraphQlApi#field_log_level}
    */
    readonly fieldLogLevel?: string;
}
export declare function appsyncGraphQlApiLogConfigToTerraform(struct?: AppsyncGraphQlApiLogConfig | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiLogConfigToHclTerraform(struct?: AppsyncGraphQlApiLogConfig | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncGraphQlApiLogConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiLogConfig | cdktn.IResolvable | undefined);
    private _cloudwatchLogsRoleArn?;
    get cloudwatchLogsRoleArn(): string;
    set cloudwatchLogsRoleArn(value: string);
    resetCloudwatchLogsRoleArn(): void;
    get cloudwatchLogsRoleArnInput(): string | undefined;
    private _excludeVerboseContent?;
    get excludeVerboseContent(): boolean | cdktn.IResolvable;
    set excludeVerboseContent(value: boolean | cdktn.IResolvable);
    resetExcludeVerboseContent(): void;
    get excludeVerboseContentInput(): boolean | cdktn.IResolvable | undefined;
    private _fieldLogLevel?;
    get fieldLogLevel(): string;
    set fieldLogLevel(value: string);
    resetFieldLogLevel(): void;
    get fieldLogLevelInput(): string | undefined;
}
export interface AppsyncGraphQlApiOpenIdConnectConfig {
    /**
    * The number of milliseconds that a token is valid after being authenticated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#auth_ttl AppsyncGraphQlApi#auth_ttl}
    */
    readonly authTtl?: number;
    /**
    * The client identifier of the Relying party at the OpenID identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#client_id AppsyncGraphQlApi#client_id}
    */
    readonly clientId?: string;
    /**
    * The number of milliseconds that a token is valid after it's issued to a user.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#iat_ttl AppsyncGraphQlApi#iat_ttl}
    */
    readonly iatTtl?: number;
    /**
    * The issuer for the OIDC configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#issuer AppsyncGraphQlApi#issuer}
    */
    readonly issuer?: string;
}
export declare function appsyncGraphQlApiOpenIdConnectConfigToTerraform(struct?: AppsyncGraphQlApiOpenIdConnectConfig | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiOpenIdConnectConfigToHclTerraform(struct?: AppsyncGraphQlApiOpenIdConnectConfig | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiOpenIdConnectConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncGraphQlApiOpenIdConnectConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiOpenIdConnectConfig | cdktn.IResolvable | undefined);
    private _authTtl?;
    get authTtl(): number;
    set authTtl(value: number);
    resetAuthTtl(): void;
    get authTtlInput(): number | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _iatTtl?;
    get iatTtl(): number;
    set iatTtl(value: number);
    resetIatTtl(): void;
    get iatTtlInput(): number | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    resetIssuer(): void;
    get issuerInput(): string | undefined;
}
export interface AppsyncGraphQlApiTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#key AppsyncGraphQlApi#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#value AppsyncGraphQlApi#value}
    */
    readonly value?: string;
}
export declare function appsyncGraphQlApiTagsToTerraform(struct?: AppsyncGraphQlApiTags | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiTagsToHclTerraform(struct?: AppsyncGraphQlApiTags | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncGraphQlApiTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppsyncGraphQlApiTagsList extends cdktn.ComplexList {
    internalValue?: AppsyncGraphQlApiTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncGraphQlApiTagsOutputReference;
}
export interface AppsyncGraphQlApiUserPoolConfig {
    /**
    * A regular expression for validating the incoming Amazon Cognito user pool app client ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#app_id_client_regex AppsyncGraphQlApi#app_id_client_regex}
    */
    readonly appIdClientRegex?: string;
    /**
    * The AWS Region in which the user pool was created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#aws_region AppsyncGraphQlApi#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * The action that you want your GraphQL API to take when a request that uses Amazon Cognito user pool authentication doesn't match the Amazon Cognito user pool configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#default_action AppsyncGraphQlApi#default_action}
    */
    readonly defaultAction?: string;
    /**
    * The user pool ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#user_pool_id AppsyncGraphQlApi#user_pool_id}
    */
    readonly userPoolId?: string;
}
export declare function appsyncGraphQlApiUserPoolConfigToTerraform(struct?: AppsyncGraphQlApiUserPoolConfig | cdktn.IResolvable): any;
export declare function appsyncGraphQlApiUserPoolConfigToHclTerraform(struct?: AppsyncGraphQlApiUserPoolConfig | cdktn.IResolvable): any;
export declare class AppsyncGraphQlApiUserPoolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncGraphQlApiUserPoolConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncGraphQlApiUserPoolConfig | cdktn.IResolvable | undefined);
    private _appIdClientRegex?;
    get appIdClientRegex(): string;
    set appIdClientRegex(value: string);
    resetAppIdClientRegex(): void;
    get appIdClientRegexInput(): string | undefined;
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _defaultAction?;
    get defaultAction(): string;
    set defaultAction(value: string);
    resetDefaultAction(): void;
    get defaultActionInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    resetUserPoolId(): void;
    get userPoolIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api awscc_appsync_graph_ql_api}
*/
export declare class AppsyncGraphQlApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_graph_ql_api";
    /**
    * Generates CDKTN code for importing a AppsyncGraphQlApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncGraphQlApi to import
    * @param importFromId The id of the existing AppsyncGraphQlApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncGraphQlApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_graph_ql_api awscc_appsync_graph_ql_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncGraphQlApiConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncGraphQlApiConfig);
    private _additionalAuthenticationProviders;
    get additionalAuthenticationProviders(): AppsyncGraphQlApiAdditionalAuthenticationProvidersList;
    putAdditionalAuthenticationProviders(value: AppsyncGraphQlApiAdditionalAuthenticationProviders[] | cdktn.IResolvable): void;
    resetAdditionalAuthenticationProviders(): void;
    get additionalAuthenticationProvidersInput(): cdktn.IResolvable | AppsyncGraphQlApiAdditionalAuthenticationProviders[] | undefined;
    get apiId(): string;
    private _apiType?;
    get apiType(): string;
    set apiType(value: string);
    resetApiType(): void;
    get apiTypeInput(): string | undefined;
    get arn(): string;
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    get authenticationTypeInput(): string | undefined;
    private _enhancedMetricsConfig;
    get enhancedMetricsConfig(): AppsyncGraphQlApiEnhancedMetricsConfigOutputReference;
    putEnhancedMetricsConfig(value: AppsyncGraphQlApiEnhancedMetricsConfig): void;
    resetEnhancedMetricsConfig(): void;
    get enhancedMetricsConfigInput(): cdktn.IResolvable | AppsyncGraphQlApiEnhancedMetricsConfig | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    get graphQlDns(): string;
    get graphQlEndpointArn(): string;
    get graphQlUrl(): string;
    get id(): string;
    private _introspectionConfig?;
    get introspectionConfig(): string;
    set introspectionConfig(value: string);
    resetIntrospectionConfig(): void;
    get introspectionConfigInput(): string | undefined;
    private _lambdaAuthorizerConfig;
    get lambdaAuthorizerConfig(): AppsyncGraphQlApiLambdaAuthorizerConfigOutputReference;
    putLambdaAuthorizerConfig(value: AppsyncGraphQlApiLambdaAuthorizerConfig): void;
    resetLambdaAuthorizerConfig(): void;
    get lambdaAuthorizerConfigInput(): cdktn.IResolvable | AppsyncGraphQlApiLambdaAuthorizerConfig | undefined;
    private _logConfig;
    get logConfig(): AppsyncGraphQlApiLogConfigOutputReference;
    putLogConfig(value: AppsyncGraphQlApiLogConfig): void;
    resetLogConfig(): void;
    get logConfigInput(): cdktn.IResolvable | AppsyncGraphQlApiLogConfig | undefined;
    private _mergedApiExecutionRoleArn?;
    get mergedApiExecutionRoleArn(): string;
    set mergedApiExecutionRoleArn(value: string);
    resetMergedApiExecutionRoleArn(): void;
    get mergedApiExecutionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _openIdConnectConfig;
    get openIdConnectConfig(): AppsyncGraphQlApiOpenIdConnectConfigOutputReference;
    putOpenIdConnectConfig(value: AppsyncGraphQlApiOpenIdConnectConfig): void;
    resetOpenIdConnectConfig(): void;
    get openIdConnectConfigInput(): cdktn.IResolvable | AppsyncGraphQlApiOpenIdConnectConfig | undefined;
    private _ownerContact?;
    get ownerContact(): string;
    set ownerContact(value: string);
    resetOwnerContact(): void;
    get ownerContactInput(): string | undefined;
    private _queryDepthLimit?;
    get queryDepthLimit(): number;
    set queryDepthLimit(value: number);
    resetQueryDepthLimit(): void;
    get queryDepthLimitInput(): number | undefined;
    get realtimeDns(): string;
    get realtimeUrl(): string;
    private _resolverCountLimit?;
    get resolverCountLimit(): number;
    set resolverCountLimit(value: number);
    resetResolverCountLimit(): void;
    get resolverCountLimitInput(): number | undefined;
    private _tags;
    get tags(): AppsyncGraphQlApiTagsList;
    putTags(value: AppsyncGraphQlApiTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppsyncGraphQlApiTags[] | undefined;
    private _userPoolConfig;
    get userPoolConfig(): AppsyncGraphQlApiUserPoolConfigOutputReference;
    putUserPoolConfig(value: AppsyncGraphQlApiUserPoolConfig): void;
    resetUserPoolConfig(): void;
    get userPoolConfigInput(): cdktn.IResolvable | AppsyncGraphQlApiUserPoolConfig | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
    private _xrayEnabled?;
    get xrayEnabled(): boolean | cdktn.IResolvable;
    set xrayEnabled(value: boolean | cdktn.IResolvable);
    resetXrayEnabled(): void;
    get xrayEnabledInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
