/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontConnectionFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * A flag that determines whether to automatically publish the function to the ``LIVE`` stage when it?s created. To automatically publish to the ``LIVE`` stage, set this property to ``true``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#auto_publish CloudfrontConnectionFunction#auto_publish}
    */
    readonly autoPublish?: boolean | cdktn.IResolvable;
    /**
    * The code for the connection function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#connection_function_code CloudfrontConnectionFunction#connection_function_code}
    */
    readonly connectionFunctionCode: string;
    /**
    * Contains configuration information about a CloudFront function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#connection_function_config CloudfrontConnectionFunction#connection_function_config}
    */
    readonly connectionFunctionConfig: CloudfrontConnectionFunctionConnectionFunctionConfig;
    /**
    * The connection function name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#name CloudfrontConnectionFunction#name}
    */
    readonly name: string;
    /**
    * A complex type that contains zero or more ``Tag`` elements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#tags CloudfrontConnectionFunction#tags}
    */
    readonly tags?: CloudfrontConnectionFunctionTags[] | cdktn.IResolvable;
}
export interface CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations {
    /**
    * The Amazon Resource Name (ARN) of the key value store association.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#key_value_store_arn CloudfrontConnectionFunction#key_value_store_arn}
    */
    readonly keyValueStoreArn?: string;
}
export declare function cloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationsToTerraform(struct?: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations | cdktn.IResolvable): any;
export declare function cloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationsToHclTerraform(struct?: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations | cdktn.IResolvable): any;
export declare class CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations | cdktn.IResolvable | undefined);
    private _keyValueStoreArn?;
    get keyValueStoreArn(): string;
    set keyValueStoreArn(value: string);
    resetKeyValueStoreArn(): void;
    get keyValueStoreArnInput(): string | undefined;
}
export declare class CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationsList extends cdktn.ComplexList {
    internalValue?: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationsOutputReference;
}
export interface CloudfrontConnectionFunctionConnectionFunctionConfig {
    /**
    * A comment to describe the function. The comment cannot be longer than 128 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#comment CloudfrontConnectionFunction#comment}
    */
    readonly comment: string;
    /**
    * The configuration for the key value store associations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#key_value_store_associations CloudfrontConnectionFunction#key_value_store_associations}
    */
    readonly keyValueStoreAssociations?: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations[] | cdktn.IResolvable;
    /**
    * The function's runtime environment version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#runtime CloudfrontConnectionFunction#runtime}
    */
    readonly runtime: string;
}
export declare function cloudfrontConnectionFunctionConnectionFunctionConfigToTerraform(struct?: CloudfrontConnectionFunctionConnectionFunctionConfig | cdktn.IResolvable): any;
export declare function cloudfrontConnectionFunctionConnectionFunctionConfigToHclTerraform(struct?: CloudfrontConnectionFunctionConnectionFunctionConfig | cdktn.IResolvable): any;
export declare class CloudfrontConnectionFunctionConnectionFunctionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontConnectionFunctionConnectionFunctionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontConnectionFunctionConnectionFunctionConfig | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    get commentInput(): string | undefined;
    private _keyValueStoreAssociations;
    get keyValueStoreAssociations(): CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationsList;
    putKeyValueStoreAssociations(value: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations[] | cdktn.IResolvable): void;
    resetKeyValueStoreAssociations(): void;
    get keyValueStoreAssociationsInput(): cdktn.IResolvable | CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociations[] | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    get runtimeInput(): string | undefined;
}
export interface CloudfrontConnectionFunctionTags {
    /**
    * A string that contains ``Tag`` key.
    *  The string length should be between 1 and 128 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#key CloudfrontConnectionFunction#key}
    */
    readonly key?: string;
    /**
    * A string that contains an optional ``Tag`` value.
    *  The string length should be between 0 and 256 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#value CloudfrontConnectionFunction#value}
    */
    readonly value?: string;
}
export declare function cloudfrontConnectionFunctionTagsToTerraform(struct?: CloudfrontConnectionFunctionTags | cdktn.IResolvable): any;
export declare function cloudfrontConnectionFunctionTagsToHclTerraform(struct?: CloudfrontConnectionFunctionTags | cdktn.IResolvable): any;
export declare class CloudfrontConnectionFunctionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontConnectionFunctionTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontConnectionFunctionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontConnectionFunctionTagsList extends cdktn.ComplexList {
    internalValue?: CloudfrontConnectionFunctionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontConnectionFunctionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function awscc_cloudfront_connection_function}
*/
export declare class CloudfrontConnectionFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_connection_function";
    /**
    * Generates CDKTN code for importing a CloudfrontConnectionFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontConnectionFunction to import
    * @param importFromId The id of the existing CloudfrontConnectionFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontConnectionFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_connection_function awscc_cloudfront_connection_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontConnectionFunctionConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontConnectionFunctionConfig);
    private _autoPublish?;
    get autoPublish(): boolean | cdktn.IResolvable;
    set autoPublish(value: boolean | cdktn.IResolvable);
    resetAutoPublish(): void;
    get autoPublishInput(): boolean | cdktn.IResolvable | undefined;
    get connectionFunctionArn(): string;
    private _connectionFunctionCode?;
    get connectionFunctionCode(): string;
    set connectionFunctionCode(value: string);
    get connectionFunctionCodeInput(): string | undefined;
    private _connectionFunctionConfig;
    get connectionFunctionConfig(): CloudfrontConnectionFunctionConnectionFunctionConfigOutputReference;
    putConnectionFunctionConfig(value: CloudfrontConnectionFunctionConnectionFunctionConfig): void;
    get connectionFunctionConfigInput(): cdktn.IResolvable | CloudfrontConnectionFunctionConnectionFunctionConfig | undefined;
    get connectionFunctionId(): string;
    get createdTime(): string;
    get eTag(): string;
    get id(): string;
    get lastModifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get stage(): string;
    get status(): string;
    private _tags;
    get tags(): CloudfrontConnectionFunctionTagsList;
    putTags(value: CloudfrontConnectionFunctionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudfrontConnectionFunctionTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
