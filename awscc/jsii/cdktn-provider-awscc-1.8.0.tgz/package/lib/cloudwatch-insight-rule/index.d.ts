/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchInsightRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule#apply_on_transformed_logs CloudwatchInsightRule#apply_on_transformed_logs}
    */
    readonly applyOnTransformedLogs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule#rule_body CloudwatchInsightRule#rule_body}
    */
    readonly ruleBody: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule#rule_name CloudwatchInsightRule#rule_name}
    */
    readonly ruleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule#rule_state CloudwatchInsightRule#rule_state}
    */
    readonly ruleState: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule#tags CloudwatchInsightRule#tags}
    */
    readonly tags?: CloudwatchInsightRuleTags[] | cdktn.IResolvable;
}
export interface CloudwatchInsightRuleTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule#key CloudwatchInsightRule#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule#value CloudwatchInsightRule#value}
    */
    readonly value?: string;
}
export declare function cloudwatchInsightRuleTagsToTerraform(struct?: CloudwatchInsightRuleTags | cdktn.IResolvable): any;
export declare function cloudwatchInsightRuleTagsToHclTerraform(struct?: CloudwatchInsightRuleTags | cdktn.IResolvable): any;
export declare class CloudwatchInsightRuleTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchInsightRuleTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchInsightRuleTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchInsightRuleTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchInsightRuleTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchInsightRuleTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule awscc_cloudwatch_insight_rule}
*/
export declare class CloudwatchInsightRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_insight_rule";
    /**
    * Generates CDKTN code for importing a CloudwatchInsightRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchInsightRule to import
    * @param importFromId The id of the existing CloudwatchInsightRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchInsightRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudwatch_insight_rule awscc_cloudwatch_insight_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchInsightRuleConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchInsightRuleConfig);
    private _applyOnTransformedLogs?;
    get applyOnTransformedLogs(): boolean | cdktn.IResolvable;
    set applyOnTransformedLogs(value: boolean | cdktn.IResolvable);
    resetApplyOnTransformedLogs(): void;
    get applyOnTransformedLogsInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    get id(): string;
    private _ruleBody?;
    get ruleBody(): string;
    set ruleBody(value: string);
    get ruleBodyInput(): string | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _ruleState?;
    get ruleState(): string;
    set ruleState(value: string);
    get ruleStateInput(): string | undefined;
    private _tags;
    get tags(): CloudwatchInsightRuleTagsList;
    putTags(value: CloudwatchInsightRuleTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchInsightRuleTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
