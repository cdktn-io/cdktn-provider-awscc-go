/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigConfigurationProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * The application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#application_id AppconfigConfigurationProfile#application_id}
    */
    readonly applicationId: string;
    /**
    * On resource deletion this controls whether the Deletion Protection check should be applied, bypassed, or (the default) whether the behavior should be controlled by the account-level Deletion Protection setting. See https://docs.aws.amazon.com/appconfig/latest/userguide/deletion-protection.html
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#deletion_protection_check AppconfigConfigurationProfile#deletion_protection_check}
    */
    readonly deletionProtectionCheck?: string;
    /**
    * A description of the configuration profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#description AppconfigConfigurationProfile#description}
    */
    readonly description?: string;
    /**
    * The AWS Key Management Service key identifier (key ID, key alias, or key ARN) provided when the resource was created or updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#kms_key_identifier AppconfigConfigurationProfile#kms_key_identifier}
    */
    readonly kmsKeyIdentifier?: string;
    /**
    * A URI to locate the configuration. You can specify the AWS AppConfig hosted configuration store, Systems Manager (SSM) document, an SSM Parameter Store parameter, or an Amazon S3 object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#location_uri AppconfigConfigurationProfile#location_uri}
    */
    readonly locationUri: string;
    /**
    * A name for the configuration profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#name AppconfigConfigurationProfile#name}
    */
    readonly name: string;
    /**
    * The ARN of an IAM role with permission to access the configuration at the specified LocationUri.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#retrieval_role_arn AppconfigConfigurationProfile#retrieval_role_arn}
    */
    readonly retrievalRoleArn?: string;
    /**
    * Metadata to assign to the configuration profile. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#tags AppconfigConfigurationProfile#tags}
    */
    readonly tags?: AppconfigConfigurationProfileTags[] | cdktn.IResolvable;
    /**
    * The type of configurations contained in the profile. When calling this API, enter one of the following values for Type: AWS.AppConfig.FeatureFlags, AWS.Freeform
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#type AppconfigConfigurationProfile#type}
    */
    readonly type?: string;
    /**
    * A list of methods for validating the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#validators AppconfigConfigurationProfile#validators}
    */
    readonly validators?: AppconfigConfigurationProfileValidators[] | cdktn.IResolvable;
}
export interface AppconfigConfigurationProfileTags {
    /**
    * The key-value string map. The tag key can be up to 128 characters and must not start with aws:.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#key AppconfigConfigurationProfile#key}
    */
    readonly key?: string;
    /**
    * The tag value can be up to 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#value AppconfigConfigurationProfile#value}
    */
    readonly value?: string;
}
export declare function appconfigConfigurationProfileTagsToTerraform(struct?: AppconfigConfigurationProfileTags | cdktn.IResolvable): any;
export declare function appconfigConfigurationProfileTagsToHclTerraform(struct?: AppconfigConfigurationProfileTags | cdktn.IResolvable): any;
export declare class AppconfigConfigurationProfileTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigConfigurationProfileTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigConfigurationProfileTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppconfigConfigurationProfileTagsList extends cdktn.ComplexList {
    internalValue?: AppconfigConfigurationProfileTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigConfigurationProfileTagsOutputReference;
}
export interface AppconfigConfigurationProfileValidators {
    /**
    * Either the JSON Schema content or the Amazon Resource Name (ARN) of an Lambda function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#content AppconfigConfigurationProfile#content}
    */
    readonly content?: string;
    /**
    * AWS AppConfig supports validators of type JSON_SCHEMA and LAMBDA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#type AppconfigConfigurationProfile#type}
    */
    readonly type?: string;
}
export declare function appconfigConfigurationProfileValidatorsToTerraform(struct?: AppconfigConfigurationProfileValidators | cdktn.IResolvable): any;
export declare function appconfigConfigurationProfileValidatorsToHclTerraform(struct?: AppconfigConfigurationProfileValidators | cdktn.IResolvable): any;
export declare class AppconfigConfigurationProfileValidatorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigConfigurationProfileValidators | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigConfigurationProfileValidators | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class AppconfigConfigurationProfileValidatorsList extends cdktn.ComplexList {
    internalValue?: AppconfigConfigurationProfileValidators[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigConfigurationProfileValidatorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile awscc_appconfig_configuration_profile}
*/
export declare class AppconfigConfigurationProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appconfig_configuration_profile";
    /**
    * Generates CDKTN code for importing a AppconfigConfigurationProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigConfigurationProfile to import
    * @param importFromId The id of the existing AppconfigConfigurationProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigConfigurationProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appconfig_configuration_profile awscc_appconfig_configuration_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigConfigurationProfileConfig
    */
    constructor(scope: Construct, id: string, config: AppconfigConfigurationProfileConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    get configurationProfileId(): string;
    private _deletionProtectionCheck?;
    get deletionProtectionCheck(): string;
    set deletionProtectionCheck(value: string);
    resetDeletionProtectionCheck(): void;
    get deletionProtectionCheckInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get kmsKeyArn(): string;
    private _kmsKeyIdentifier?;
    get kmsKeyIdentifier(): string;
    set kmsKeyIdentifier(value: string);
    resetKmsKeyIdentifier(): void;
    get kmsKeyIdentifierInput(): string | undefined;
    private _locationUri?;
    get locationUri(): string;
    set locationUri(value: string);
    get locationUriInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _retrievalRoleArn?;
    get retrievalRoleArn(): string;
    set retrievalRoleArn(value: string);
    resetRetrievalRoleArn(): void;
    get retrievalRoleArnInput(): string | undefined;
    private _tags;
    get tags(): AppconfigConfigurationProfileTagsList;
    putTags(value: AppconfigConfigurationProfileTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppconfigConfigurationProfileTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _validators;
    get validators(): AppconfigConfigurationProfileValidatorsList;
    putValidators(value: AppconfigConfigurationProfileValidators[] | cdktn.IResolvable): void;
    resetValidators(): void;
    get validatorsInput(): cdktn.IResolvable | AppconfigConfigurationProfileValidators[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
