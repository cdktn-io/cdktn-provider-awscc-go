/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AmazonmqConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The authentication strategy associated with the configuration. The default is SIMPLE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#authentication_strategy AmazonmqConfiguration#authentication_strategy}
    */
    readonly authenticationStrategy?: string;
    /**
    * The base64-encoded XML configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#data AmazonmqConfiguration#data}
    */
    readonly data?: string;
    /**
    * The description of the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#description AmazonmqConfiguration#description}
    */
    readonly description?: string;
    /**
    * The type of broker engine. Note: Currently, Amazon MQ only supports ACTIVEMQ for creating and editing broker configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#engine_type AmazonmqConfiguration#engine_type}
    */
    readonly engineType: string;
    /**
    * The version of the broker engine.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#engine_version AmazonmqConfiguration#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * The name of the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#name AmazonmqConfiguration#name}
    */
    readonly name: string;
    /**
    * Create tags when creating the configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#tags AmazonmqConfiguration#tags}
    */
    readonly tags?: AmazonmqConfigurationTags[] | cdktn.IResolvable;
}
export interface AmazonmqConfigurationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#key AmazonmqConfiguration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#value AmazonmqConfiguration#value}
    */
    readonly value?: string;
}
export declare function amazonmqConfigurationTagsToTerraform(struct?: AmazonmqConfigurationTags | cdktn.IResolvable): any;
export declare function amazonmqConfigurationTagsToHclTerraform(struct?: AmazonmqConfigurationTags | cdktn.IResolvable): any;
export declare class AmazonmqConfigurationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmazonmqConfigurationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AmazonmqConfigurationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AmazonmqConfigurationTagsList extends cdktn.ComplexList {
    internalValue?: AmazonmqConfigurationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmazonmqConfigurationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration awscc_amazonmq_configuration}
*/
export declare class AmazonmqConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_amazonmq_configuration";
    /**
    * Generates CDKTN code for importing a AmazonmqConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AmazonmqConfiguration to import
    * @param importFromId The id of the existing AmazonmqConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AmazonmqConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/amazonmq_configuration awscc_amazonmq_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AmazonmqConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AmazonmqConfigurationConfig);
    get arn(): string;
    private _authenticationStrategy?;
    get authenticationStrategy(): string;
    set authenticationStrategy(value: string);
    resetAuthenticationStrategy(): void;
    get authenticationStrategyInput(): string | undefined;
    get configurationId(): string;
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    get engineTypeInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get revision(): string;
    private _tags;
    get tags(): AmazonmqConfigurationTagsList;
    putTags(value: AmazonmqConfigurationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AmazonmqConfigurationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
