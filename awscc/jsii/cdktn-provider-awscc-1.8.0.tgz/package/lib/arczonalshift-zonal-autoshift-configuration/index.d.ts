/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArczonalshiftZonalAutoshiftConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#practice_run_configuration ArczonalshiftZonalAutoshiftConfiguration#practice_run_configuration}
    */
    readonly practiceRunConfiguration?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#resource_identifier ArczonalshiftZonalAutoshiftConfiguration#resource_identifier}
    */
    readonly resourceIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#zonal_autoshift_status ArczonalshiftZonalAutoshiftConfiguration#zonal_autoshift_status}
    */
    readonly zonalAutoshiftStatus?: string;
}
export interface ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#alarm_identifier ArczonalshiftZonalAutoshiftConfiguration#alarm_identifier}
    */
    readonly alarmIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#type ArczonalshiftZonalAutoshiftConfiguration#type}
    */
    readonly type?: string;
}
export declare function arczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarmsToTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms | cdktn.IResolvable): any;
export declare function arczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarmsToHclTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms | cdktn.IResolvable): any;
export declare class ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms | cdktn.IResolvable | undefined;
    set internalValue(value: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms | cdktn.IResolvable | undefined);
    private _alarmIdentifier?;
    get alarmIdentifier(): string;
    set alarmIdentifier(value: string);
    resetAlarmIdentifier(): void;
    get alarmIdentifierInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarmsList extends cdktn.ComplexList {
    internalValue?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarmsOutputReference;
}
export interface ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#alarm_identifier ArczonalshiftZonalAutoshiftConfiguration#alarm_identifier}
    */
    readonly alarmIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#type ArczonalshiftZonalAutoshiftConfiguration#type}
    */
    readonly type?: string;
}
export declare function arczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarmsToTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms | cdktn.IResolvable): any;
export declare function arczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarmsToHclTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms | cdktn.IResolvable): any;
export declare class ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms | cdktn.IResolvable | undefined;
    set internalValue(value: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms | cdktn.IResolvable | undefined);
    private _alarmIdentifier?;
    get alarmIdentifier(): string;
    set alarmIdentifier(value: string);
    resetAlarmIdentifier(): void;
    get alarmIdentifierInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarmsList extends cdktn.ComplexList {
    internalValue?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarmsOutputReference;
}
export interface ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocked_dates ArczonalshiftZonalAutoshiftConfiguration#blocked_dates}
    */
    readonly blockedDates?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocked_windows ArczonalshiftZonalAutoshiftConfiguration#blocked_windows}
    */
    readonly blockedWindows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocking_alarms ArczonalshiftZonalAutoshiftConfiguration#blocking_alarms}
    */
    readonly blockingAlarms?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#outcome_alarms ArczonalshiftZonalAutoshiftConfiguration#outcome_alarms}
    */
    readonly outcomeAlarms?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms[] | cdktn.IResolvable;
}
export declare function arczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationToTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfiguration | cdktn.IResolvable): any;
export declare function arczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationToHclTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfiguration | cdktn.IResolvable): any;
export declare class ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfiguration | cdktn.IResolvable | undefined);
    private _blockedDates?;
    get blockedDates(): string[];
    set blockedDates(value: string[]);
    resetBlockedDates(): void;
    get blockedDatesInput(): string[] | undefined;
    private _blockedWindows?;
    get blockedWindows(): string[];
    set blockedWindows(value: string[]);
    resetBlockedWindows(): void;
    get blockedWindowsInput(): string[] | undefined;
    private _blockingAlarms;
    get blockingAlarms(): ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarmsList;
    putBlockingAlarms(value: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms[] | cdktn.IResolvable): void;
    resetBlockingAlarms(): void;
    get blockingAlarmsInput(): cdktn.IResolvable | ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationBlockingAlarms[] | undefined;
    private _outcomeAlarms;
    get outcomeAlarms(): ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarmsList;
    putOutcomeAlarms(value: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms[] | cdktn.IResolvable): void;
    resetOutcomeAlarms(): void;
    get outcomeAlarmsInput(): cdktn.IResolvable | ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutcomeAlarms[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration awscc_arczonalshift_zonal_autoshift_configuration}
*/
export declare class ArczonalshiftZonalAutoshiftConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_arczonalshift_zonal_autoshift_configuration";
    /**
    * Generates CDKTN code for importing a ArczonalshiftZonalAutoshiftConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArczonalshiftZonalAutoshiftConfiguration to import
    * @param importFromId The id of the existing ArczonalshiftZonalAutoshiftConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArczonalshiftZonalAutoshiftConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/arczonalshift_zonal_autoshift_configuration awscc_arczonalshift_zonal_autoshift_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArczonalshiftZonalAutoshiftConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ArczonalshiftZonalAutoshiftConfigurationConfig);
    get id(): string;
    private _practiceRunConfiguration;
    get practiceRunConfiguration(): ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfigurationOutputReference;
    putPracticeRunConfiguration(value: ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfiguration): void;
    resetPracticeRunConfiguration(): void;
    get practiceRunConfigurationInput(): cdktn.IResolvable | ArczonalshiftZonalAutoshiftConfigurationPracticeRunConfiguration | undefined;
    private _resourceIdentifier?;
    get resourceIdentifier(): string;
    set resourceIdentifier(value: string);
    resetResourceIdentifier(): void;
    get resourceIdentifierInput(): string | undefined;
    private _zonalAutoshiftStatus?;
    get zonalAutoshiftStatus(): string;
    set zonalAutoshiftStatus(value: string);
    resetZonalAutoshiftStatus(): void;
    get zonalAutoshiftStatusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
