/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupFrameworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Contains detailed information about all of the controls of a framework. Each framework must contain at least one control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#framework_controls BackupFramework#framework_controls}
    */
    readonly frameworkControls: BackupFrameworkFrameworkControls[] | cdktn.IResolvable;
    /**
    * An optional description of the framework with a maximum 1,024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#framework_description BackupFramework#framework_description}
    */
    readonly frameworkDescription?: string;
    /**
    * The unique name of a framework. This name is between 1 and 256 characters, starting with a letter, and consisting of letters (a-z, A-Z), numbers (0-9), and underscores (_).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#framework_name BackupFramework#framework_name}
    */
    readonly frameworkName?: string;
    /**
    * Metadata that you can assign to help organize the frameworks that you create. Each tag is a key-value pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#framework_tags BackupFramework#framework_tags}
    */
    readonly frameworkTags?: BackupFrameworkFrameworkTags[] | cdktn.IResolvable;
}
export interface BackupFrameworkFrameworkControlsControlInputParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#parameter_name BackupFramework#parameter_name}
    */
    readonly parameterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#parameter_value BackupFramework#parameter_value}
    */
    readonly parameterValue?: string;
}
export declare function backupFrameworkFrameworkControlsControlInputParametersToTerraform(struct?: BackupFrameworkFrameworkControlsControlInputParameters | cdktn.IResolvable): any;
export declare function backupFrameworkFrameworkControlsControlInputParametersToHclTerraform(struct?: BackupFrameworkFrameworkControlsControlInputParameters | cdktn.IResolvable): any;
export declare class BackupFrameworkFrameworkControlsControlInputParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupFrameworkFrameworkControlsControlInputParameters | cdktn.IResolvable | undefined;
    set internalValue(value: BackupFrameworkFrameworkControlsControlInputParameters | cdktn.IResolvable | undefined);
    private _parameterName?;
    get parameterName(): string;
    set parameterName(value: string);
    resetParameterName(): void;
    get parameterNameInput(): string | undefined;
    private _parameterValue?;
    get parameterValue(): string;
    set parameterValue(value: string);
    resetParameterValue(): void;
    get parameterValueInput(): string | undefined;
}
export declare class BackupFrameworkFrameworkControlsControlInputParametersList extends cdktn.ComplexList {
    internalValue?: BackupFrameworkFrameworkControlsControlInputParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupFrameworkFrameworkControlsControlInputParametersOutputReference;
}
export interface BackupFrameworkFrameworkControlsControlScopeTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#key BackupFramework#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#value BackupFramework#value}
    */
    readonly value?: string;
}
export declare function backupFrameworkFrameworkControlsControlScopeTagsToTerraform(struct?: BackupFrameworkFrameworkControlsControlScopeTags | cdktn.IResolvable): any;
export declare function backupFrameworkFrameworkControlsControlScopeTagsToHclTerraform(struct?: BackupFrameworkFrameworkControlsControlScopeTags | cdktn.IResolvable): any;
export declare class BackupFrameworkFrameworkControlsControlScopeTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupFrameworkFrameworkControlsControlScopeTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupFrameworkFrameworkControlsControlScopeTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupFrameworkFrameworkControlsControlScopeTagsList extends cdktn.ComplexList {
    internalValue?: BackupFrameworkFrameworkControlsControlScopeTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupFrameworkFrameworkControlsControlScopeTagsOutputReference;
}
export interface BackupFrameworkFrameworkControlsControlScope {
    /**
    * The ID of the only AWS resource that you want your control scope to contain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#compliance_resource_ids BackupFramework#compliance_resource_ids}
    */
    readonly complianceResourceIds?: string[];
    /**
    * Describes whether the control scope includes one or more types of resources, such as `EFS` or `RDS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#compliance_resource_types BackupFramework#compliance_resource_types}
    */
    readonly complianceResourceTypes?: string[];
    /**
    * Describes whether the control scope includes resources with one or more tags. Each tag is a key-value pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#tags BackupFramework#tags}
    */
    readonly tags?: BackupFrameworkFrameworkControlsControlScopeTags[] | cdktn.IResolvable;
}
export declare function backupFrameworkFrameworkControlsControlScopeToTerraform(struct?: BackupFrameworkFrameworkControlsControlScope | cdktn.IResolvable): any;
export declare function backupFrameworkFrameworkControlsControlScopeToHclTerraform(struct?: BackupFrameworkFrameworkControlsControlScope | cdktn.IResolvable): any;
export declare class BackupFrameworkFrameworkControlsControlScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupFrameworkFrameworkControlsControlScope | cdktn.IResolvable | undefined;
    set internalValue(value: BackupFrameworkFrameworkControlsControlScope | cdktn.IResolvable | undefined);
    private _complianceResourceIds?;
    get complianceResourceIds(): string[];
    set complianceResourceIds(value: string[]);
    resetComplianceResourceIds(): void;
    get complianceResourceIdsInput(): string[] | undefined;
    private _complianceResourceTypes?;
    get complianceResourceTypes(): string[];
    set complianceResourceTypes(value: string[]);
    resetComplianceResourceTypes(): void;
    get complianceResourceTypesInput(): string[] | undefined;
    private _tags;
    get tags(): BackupFrameworkFrameworkControlsControlScopeTagsList;
    putTags(value: BackupFrameworkFrameworkControlsControlScopeTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BackupFrameworkFrameworkControlsControlScopeTags[] | undefined;
}
export interface BackupFrameworkFrameworkControls {
    /**
    * A list of ParameterName and ParameterValue pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#control_input_parameters BackupFramework#control_input_parameters}
    */
    readonly controlInputParameters?: BackupFrameworkFrameworkControlsControlInputParameters[] | cdktn.IResolvable;
    /**
    * The name of a control. This name is between 1 and 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#control_name BackupFramework#control_name}
    */
    readonly controlName: string;
    /**
    * The scope of a control. The control scope defines what the control will evaluate. Three examples of control scopes are: a specific backup plan, all backup plans with a specific tag, or all backup plans.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#control_scope BackupFramework#control_scope}
    */
    readonly controlScope?: BackupFrameworkFrameworkControlsControlScope;
}
export declare function backupFrameworkFrameworkControlsToTerraform(struct?: BackupFrameworkFrameworkControls | cdktn.IResolvable): any;
export declare function backupFrameworkFrameworkControlsToHclTerraform(struct?: BackupFrameworkFrameworkControls | cdktn.IResolvable): any;
export declare class BackupFrameworkFrameworkControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupFrameworkFrameworkControls | cdktn.IResolvable | undefined;
    set internalValue(value: BackupFrameworkFrameworkControls | cdktn.IResolvable | undefined);
    private _controlInputParameters;
    get controlInputParameters(): BackupFrameworkFrameworkControlsControlInputParametersList;
    putControlInputParameters(value: BackupFrameworkFrameworkControlsControlInputParameters[] | cdktn.IResolvable): void;
    resetControlInputParameters(): void;
    get controlInputParametersInput(): cdktn.IResolvable | BackupFrameworkFrameworkControlsControlInputParameters[] | undefined;
    private _controlName?;
    get controlName(): string;
    set controlName(value: string);
    get controlNameInput(): string | undefined;
    private _controlScope;
    get controlScope(): BackupFrameworkFrameworkControlsControlScopeOutputReference;
    putControlScope(value: BackupFrameworkFrameworkControlsControlScope): void;
    resetControlScope(): void;
    get controlScopeInput(): cdktn.IResolvable | BackupFrameworkFrameworkControlsControlScope | undefined;
}
export declare class BackupFrameworkFrameworkControlsList extends cdktn.ComplexList {
    internalValue?: BackupFrameworkFrameworkControls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupFrameworkFrameworkControlsOutputReference;
}
export interface BackupFrameworkFrameworkTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#key BackupFramework#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#value BackupFramework#value}
    */
    readonly value?: string;
}
export declare function backupFrameworkFrameworkTagsToTerraform(struct?: BackupFrameworkFrameworkTags | cdktn.IResolvable): any;
export declare function backupFrameworkFrameworkTagsToHclTerraform(struct?: BackupFrameworkFrameworkTags | cdktn.IResolvable): any;
export declare class BackupFrameworkFrameworkTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupFrameworkFrameworkTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupFrameworkFrameworkTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupFrameworkFrameworkTagsList extends cdktn.ComplexList {
    internalValue?: BackupFrameworkFrameworkTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupFrameworkFrameworkTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework awscc_backup_framework}
*/
export declare class BackupFramework extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_framework";
    /**
    * Generates CDKTN code for importing a BackupFramework resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupFramework to import
    * @param importFromId The id of the existing BackupFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/backup_framework awscc_backup_framework} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: BackupFrameworkConfig);
    get creationTime(): string;
    get deploymentStatus(): string;
    get frameworkArn(): string;
    private _frameworkControls;
    get frameworkControls(): BackupFrameworkFrameworkControlsList;
    putFrameworkControls(value: BackupFrameworkFrameworkControls[] | cdktn.IResolvable): void;
    get frameworkControlsInput(): cdktn.IResolvable | BackupFrameworkFrameworkControls[] | undefined;
    private _frameworkDescription?;
    get frameworkDescription(): string;
    set frameworkDescription(value: string);
    resetFrameworkDescription(): void;
    get frameworkDescriptionInput(): string | undefined;
    private _frameworkName?;
    get frameworkName(): string;
    set frameworkName(value: string);
    resetFrameworkName(): void;
    get frameworkNameInput(): string | undefined;
    get frameworkStatus(): string;
    private _frameworkTags;
    get frameworkTags(): BackupFrameworkFrameworkTagsList;
    putFrameworkTags(value: BackupFrameworkFrameworkTags[] | cdktn.IResolvable): void;
    resetFrameworkTags(): void;
    get frameworkTagsInput(): cdktn.IResolvable | BackupFrameworkFrameworkTags[] | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
