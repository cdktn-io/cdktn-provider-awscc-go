/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayRestApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#api_key_source_type ApigatewayRestApi#api_key_source_type}
    */
    readonly apiKeySourceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#binary_media_types ApigatewayRestApi#binary_media_types}
    */
    readonly binaryMediaTypes?: string[];
    /**
    * An OpenAPI specification that defines a set of RESTful APIs in JSON format. For YAML templates, you can also provide the specification in YAML format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#body ApigatewayRestApi#body}
    */
    readonly body?: string;
    /**
    * The Amazon Simple Storage Service (Amazon S3) location that points to an OpenAPI file, which defines a set of RESTful APIs in JSON or YAML format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#body_s3_location ApigatewayRestApi#body_s3_location}
    */
    readonly bodyS3Location?: ApigatewayRestApiBodyS3Location;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#clone_from ApigatewayRestApi#clone_from}
    */
    readonly cloneFrom?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#description ApigatewayRestApi#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#disable_execute_api_endpoint ApigatewayRestApi#disable_execute_api_endpoint}
    */
    readonly disableExecuteApiEndpoint?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#endpoint_access_mode ApigatewayRestApi#endpoint_access_mode}
    */
    readonly endpointAccessMode?: string;
    /**
    * A list of the endpoint types and IP address types of the API. Use this property when creating an API. When importing an existing API, specify the endpoint configuration types using the ``Parameters`` property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#endpoint_configuration ApigatewayRestApi#endpoint_configuration}
    */
    readonly endpointConfiguration?: ApigatewayRestApiEndpointConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#fail_on_warnings ApigatewayRestApi#fail_on_warnings}
    */
    readonly failOnWarnings?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#minimum_compression_size ApigatewayRestApi#minimum_compression_size}
    */
    readonly minimumCompressionSize?: number;
    /**
    * This property applies only when you use OpenAPI to define your REST API. The ``Mode`` determines how API Gateway handles resource updates.
    *  Valid values are ``overwrite`` or ``merge``.
    *  For ``overwrite``, the new API definition replaces the existing one. The existing API identifier remains unchanged.
    *   For ``merge``, the new API definition is merged with the existing API.
    *  If you don't specify this property, a default value is chosen. For REST APIs created before March 29, 2021, the default is ``overwrite``. For REST APIs created after March 29, 2021, the new API definition takes precedence, but any container types such as endpoint configurations and binary media types are merged with the existing API.
    *  Use the default mode to define top-level ``RestApi`` properties in addition to using OpenAPI. Generally, it's preferred to use API Gateway's OpenAPI extensions to model these properties.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#mode ApigatewayRestApi#mode}
    */
    readonly mode?: string;
    /**
    * The name of the RestApi. A name is required if the REST API is not based on an OpenAPI specification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#name ApigatewayRestApi#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#parameters ApigatewayRestApi#parameters}
    */
    readonly parameters?: string;
    /**
    * A policy document that contains the permissions for the ``RestApi`` resource. To set the ARN for the policy, use the ``!Join`` intrinsic function with ``""`` as delimiter and values of ``"execute-api:/"`` and ``"*"``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#policy ApigatewayRestApi#policy}
    */
    readonly policy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#security_policy ApigatewayRestApi#security_policy}
    */
    readonly securityPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#tags ApigatewayRestApi#tags}
    */
    readonly tags?: ApigatewayRestApiTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#version ApigatewayRestApi#version}
    */
    readonly version?: string;
}
export interface ApigatewayRestApiBodyS3Location {
    /**
    * The name of the S3 bucket where the OpenAPI file is stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#bucket ApigatewayRestApi#bucket}
    */
    readonly bucket?: string;
    /**
    * The Amazon S3 ETag (a file checksum) of the OpenAPI file. If you don't specify a value, API Gateway skips ETag validation of your OpenAPI file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#e_tag ApigatewayRestApi#e_tag}
    */
    readonly eTag?: string;
    /**
    * The file name of the OpenAPI file (Amazon S3 object name).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#key ApigatewayRestApi#key}
    */
    readonly key?: string;
    /**
    * For versioning-enabled buckets, a specific version of the OpenAPI file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#version ApigatewayRestApi#version}
    */
    readonly version?: string;
}
export declare function apigatewayRestApiBodyS3LocationToTerraform(struct?: ApigatewayRestApiBodyS3Location | cdktn.IResolvable): any;
export declare function apigatewayRestApiBodyS3LocationToHclTerraform(struct?: ApigatewayRestApiBodyS3Location | cdktn.IResolvable): any;
export declare class ApigatewayRestApiBodyS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayRestApiBodyS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayRestApiBodyS3Location | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _eTag?;
    get eTag(): string;
    set eTag(value: string);
    resetETag(): void;
    get eTagInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface ApigatewayRestApiEndpointConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#ip_address_type ApigatewayRestApi#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#types ApigatewayRestApi#types}
    */
    readonly types?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#vpc_endpoint_ids ApigatewayRestApi#vpc_endpoint_ids}
    */
    readonly vpcEndpointIds?: string[];
}
export declare function apigatewayRestApiEndpointConfigurationToTerraform(struct?: ApigatewayRestApiEndpointConfiguration | cdktn.IResolvable): any;
export declare function apigatewayRestApiEndpointConfigurationToHclTerraform(struct?: ApigatewayRestApiEndpointConfiguration | cdktn.IResolvable): any;
export declare class ApigatewayRestApiEndpointConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayRestApiEndpointConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayRestApiEndpointConfiguration | cdktn.IResolvable | undefined);
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
    private _vpcEndpointIds?;
    get vpcEndpointIds(): string[];
    set vpcEndpointIds(value: string[]);
    resetVpcEndpointIds(): void;
    get vpcEndpointIdsInput(): string[] | undefined;
}
export interface ApigatewayRestApiTags {
    /**
    * A string you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#key ApigatewayRestApi#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#value ApigatewayRestApi#value}
    */
    readonly value?: string;
}
export declare function apigatewayRestApiTagsToTerraform(struct?: ApigatewayRestApiTags | cdktn.IResolvable): any;
export declare function apigatewayRestApiTagsToHclTerraform(struct?: ApigatewayRestApiTags | cdktn.IResolvable): any;
export declare class ApigatewayRestApiTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayRestApiTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayRestApiTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigatewayRestApiTagsList extends cdktn.ComplexList {
    internalValue?: ApigatewayRestApiTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayRestApiTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api awscc_apigateway_rest_api}
*/
export declare class ApigatewayRestApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_rest_api";
    /**
    * Generates CDKTN code for importing a ApigatewayRestApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayRestApi to import
    * @param importFromId The id of the existing ApigatewayRestApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayRestApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_rest_api awscc_apigateway_rest_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayRestApiConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApigatewayRestApiConfig);
    private _apiKeySourceType?;
    get apiKeySourceType(): string;
    set apiKeySourceType(value: string);
    resetApiKeySourceType(): void;
    get apiKeySourceTypeInput(): string | undefined;
    private _binaryMediaTypes?;
    get binaryMediaTypes(): string[];
    set binaryMediaTypes(value: string[]);
    resetBinaryMediaTypes(): void;
    get binaryMediaTypesInput(): string[] | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _bodyS3Location;
    get bodyS3Location(): ApigatewayRestApiBodyS3LocationOutputReference;
    putBodyS3Location(value: ApigatewayRestApiBodyS3Location): void;
    resetBodyS3Location(): void;
    get bodyS3LocationInput(): cdktn.IResolvable | ApigatewayRestApiBodyS3Location | undefined;
    private _cloneFrom?;
    get cloneFrom(): string;
    set cloneFrom(value: string);
    resetCloneFrom(): void;
    get cloneFromInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableExecuteApiEndpoint?;
    get disableExecuteApiEndpoint(): boolean | cdktn.IResolvable;
    set disableExecuteApiEndpoint(value: boolean | cdktn.IResolvable);
    resetDisableExecuteApiEndpoint(): void;
    get disableExecuteApiEndpointInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointAccessMode?;
    get endpointAccessMode(): string;
    set endpointAccessMode(value: string);
    resetEndpointAccessMode(): void;
    get endpointAccessModeInput(): string | undefined;
    private _endpointConfiguration;
    get endpointConfiguration(): ApigatewayRestApiEndpointConfigurationOutputReference;
    putEndpointConfiguration(value: ApigatewayRestApiEndpointConfiguration): void;
    resetEndpointConfiguration(): void;
    get endpointConfigurationInput(): cdktn.IResolvable | ApigatewayRestApiEndpointConfiguration | undefined;
    private _failOnWarnings?;
    get failOnWarnings(): boolean | cdktn.IResolvable;
    set failOnWarnings(value: boolean | cdktn.IResolvable);
    resetFailOnWarnings(): void;
    get failOnWarningsInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _minimumCompressionSize?;
    get minimumCompressionSize(): number;
    set minimumCompressionSize(value: number);
    resetMinimumCompressionSize(): void;
    get minimumCompressionSizeInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parameters?;
    get parameters(): string;
    set parameters(value: string);
    resetParameters(): void;
    get parametersInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    get restApiId(): string;
    get rootResourceId(): string;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    resetSecurityPolicy(): void;
    get securityPolicyInput(): string | undefined;
    private _tags;
    get tags(): ApigatewayRestApiTagsList;
    putTags(value: ApigatewayRestApiTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApigatewayRestApiTags[] | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
