/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncSourceApiAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the SourceApiAssociation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_source_api_association#description AppsyncSourceApiAssociation#description}
    */
    readonly description?: string;
    /**
    * Identifier of the Merged GraphQLApi to associate. It could be either GraphQLApi ApiId or ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_source_api_association#merged_api_identifier AppsyncSourceApiAssociation#merged_api_identifier}
    */
    readonly mergedApiIdentifier?: string;
    /**
    * Customized configuration for SourceApiAssociation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_source_api_association#source_api_association_config AppsyncSourceApiAssociation#source_api_association_config}
    */
    readonly sourceApiAssociationConfig?: AppsyncSourceApiAssociationSourceApiAssociationConfig;
    /**
    * Identifier of the Source GraphQLApi to associate. It could be either GraphQLApi ApiId or ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_source_api_association#source_api_identifier AppsyncSourceApiAssociation#source_api_identifier}
    */
    readonly sourceApiIdentifier?: string;
}
export interface AppsyncSourceApiAssociationSourceApiAssociationConfig {
    /**
    * Configuration of the merged behavior for the association. For example when it could be auto or has to be manual.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_source_api_association#merge_type AppsyncSourceApiAssociation#merge_type}
    */
    readonly mergeType?: string;
}
export declare function appsyncSourceApiAssociationSourceApiAssociationConfigToTerraform(struct?: AppsyncSourceApiAssociationSourceApiAssociationConfig | cdktn.IResolvable): any;
export declare function appsyncSourceApiAssociationSourceApiAssociationConfigToHclTerraform(struct?: AppsyncSourceApiAssociationSourceApiAssociationConfig | cdktn.IResolvable): any;
export declare class AppsyncSourceApiAssociationSourceApiAssociationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncSourceApiAssociationSourceApiAssociationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncSourceApiAssociationSourceApiAssociationConfig | cdktn.IResolvable | undefined);
    private _mergeType?;
    get mergeType(): string;
    set mergeType(value: string);
    resetMergeType(): void;
    get mergeTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_source_api_association awscc_appsync_source_api_association}
*/
export declare class AppsyncSourceApiAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_source_api_association";
    /**
    * Generates CDKTN code for importing a AppsyncSourceApiAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncSourceApiAssociation to import
    * @param importFromId The id of the existing AppsyncSourceApiAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_source_api_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncSourceApiAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_source_api_association awscc_appsync_source_api_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncSourceApiAssociationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AppsyncSourceApiAssociationConfig);
    get associationArn(): string;
    get associationId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastSuccessfulMergeDate(): string;
    get mergedApiArn(): string;
    get mergedApiId(): string;
    private _mergedApiIdentifier?;
    get mergedApiIdentifier(): string;
    set mergedApiIdentifier(value: string);
    resetMergedApiIdentifier(): void;
    get mergedApiIdentifierInput(): string | undefined;
    get sourceApiArn(): string;
    private _sourceApiAssociationConfig;
    get sourceApiAssociationConfig(): AppsyncSourceApiAssociationSourceApiAssociationConfigOutputReference;
    putSourceApiAssociationConfig(value: AppsyncSourceApiAssociationSourceApiAssociationConfig): void;
    resetSourceApiAssociationConfig(): void;
    get sourceApiAssociationConfigInput(): cdktn.IResolvable | AppsyncSourceApiAssociationSourceApiAssociationConfig | undefined;
    get sourceApiAssociationStatus(): string;
    get sourceApiAssociationStatusDetail(): string;
    get sourceApiId(): string;
    private _sourceApiIdentifier?;
    get sourceApiIdentifier(): string;
    set sourceApiIdentifier(value: string);
    resetSourceApiIdentifier(): void;
    get sourceApiIdentifierInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
