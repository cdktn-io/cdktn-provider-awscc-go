/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApsWorkspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AMP Workspace alert manager definition data
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#alert_manager_definition ApsWorkspace#alert_manager_definition}
    */
    readonly alertManagerDefinition?: string;
    /**
    * AMP Workspace alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#alias ApsWorkspace#alias}
    */
    readonly alias?: string;
    /**
    * KMS Key ARN used to encrypt and decrypt AMP workspace data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#kms_key_arn ApsWorkspace#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Logging configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#logging_configuration ApsWorkspace#logging_configuration}
    */
    readonly loggingConfiguration?: ApsWorkspaceLoggingConfiguration;
    /**
    * Query logging configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#query_logging_configuration ApsWorkspace#query_logging_configuration}
    */
    readonly queryLoggingConfiguration?: ApsWorkspaceQueryLoggingConfiguration;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#tags ApsWorkspace#tags}
    */
    readonly tags?: ApsWorkspaceTags[] | cdktn.IResolvable;
    /**
    * Workspace configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#workspace_configuration ApsWorkspace#workspace_configuration}
    */
    readonly workspaceConfiguration?: ApsWorkspaceWorkspaceConfiguration;
}
export interface ApsWorkspaceLoggingConfiguration {
    /**
    * CloudWatch log group ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#log_group_arn ApsWorkspace#log_group_arn}
    */
    readonly logGroupArn?: string;
}
export declare function apsWorkspaceLoggingConfigurationToTerraform(struct?: ApsWorkspaceLoggingConfiguration | cdktn.IResolvable): any;
export declare function apsWorkspaceLoggingConfigurationToHclTerraform(struct?: ApsWorkspaceLoggingConfiguration | cdktn.IResolvable): any;
export declare class ApsWorkspaceLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsWorkspaceLoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceLoggingConfiguration | cdktn.IResolvable | undefined);
    private _logGroupArn?;
    get logGroupArn(): string;
    set logGroupArn(value: string);
    resetLogGroupArn(): void;
    get logGroupArnInput(): string | undefined;
}
export interface ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogs {
    /**
    * The ARN of the CloudWatch Logs log group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#log_group_arn ApsWorkspace#log_group_arn}
    */
    readonly logGroupArn?: string;
}
export declare function apsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogsToTerraform(struct?: ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogs | cdktn.IResolvable): any;
export declare function apsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogsToHclTerraform(struct?: ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogs | cdktn.IResolvable): any;
export declare class ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogs | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogs | cdktn.IResolvable | undefined);
    private _logGroupArn?;
    get logGroupArn(): string;
    set logGroupArn(value: string);
    resetLogGroupArn(): void;
    get logGroupArnInput(): string | undefined;
}
export interface ApsWorkspaceQueryLoggingConfigurationDestinationsFilters {
    /**
    * Query logs with QSP above this limit are vended
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#qsp_threshold ApsWorkspace#qsp_threshold}
    */
    readonly qspThreshold?: number;
}
export declare function apsWorkspaceQueryLoggingConfigurationDestinationsFiltersToTerraform(struct?: ApsWorkspaceQueryLoggingConfigurationDestinationsFilters | cdktn.IResolvable): any;
export declare function apsWorkspaceQueryLoggingConfigurationDestinationsFiltersToHclTerraform(struct?: ApsWorkspaceQueryLoggingConfigurationDestinationsFilters | cdktn.IResolvable): any;
export declare class ApsWorkspaceQueryLoggingConfigurationDestinationsFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsWorkspaceQueryLoggingConfigurationDestinationsFilters | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceQueryLoggingConfigurationDestinationsFilters | cdktn.IResolvable | undefined);
    private _qspThreshold?;
    get qspThreshold(): number;
    set qspThreshold(value: number);
    resetQspThreshold(): void;
    get qspThresholdInput(): number | undefined;
}
export interface ApsWorkspaceQueryLoggingConfigurationDestinations {
    /**
    * Represents a cloudwatch logs destination for query logging
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#cloudwatch_logs ApsWorkspace#cloudwatch_logs}
    */
    readonly cloudwatchLogs?: ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogs;
    /**
    * Filters for logging
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#filters ApsWorkspace#filters}
    */
    readonly filters?: ApsWorkspaceQueryLoggingConfigurationDestinationsFilters;
}
export declare function apsWorkspaceQueryLoggingConfigurationDestinationsToTerraform(struct?: ApsWorkspaceQueryLoggingConfigurationDestinations | cdktn.IResolvable): any;
export declare function apsWorkspaceQueryLoggingConfigurationDestinationsToHclTerraform(struct?: ApsWorkspaceQueryLoggingConfigurationDestinations | cdktn.IResolvable): any;
export declare class ApsWorkspaceQueryLoggingConfigurationDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsWorkspaceQueryLoggingConfigurationDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceQueryLoggingConfigurationDestinations | cdktn.IResolvable | undefined);
    private _cloudwatchLogs;
    get cloudwatchLogs(): ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogsOutputReference;
    putCloudwatchLogs(value: ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogs): void;
    resetCloudwatchLogs(): void;
    get cloudwatchLogsInput(): cdktn.IResolvable | ApsWorkspaceQueryLoggingConfigurationDestinationsCloudwatchLogs | undefined;
    private _filters;
    get filters(): ApsWorkspaceQueryLoggingConfigurationDestinationsFiltersOutputReference;
    putFilters(value: ApsWorkspaceQueryLoggingConfigurationDestinationsFilters): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | ApsWorkspaceQueryLoggingConfigurationDestinationsFilters | undefined;
}
export declare class ApsWorkspaceQueryLoggingConfigurationDestinationsList extends cdktn.ComplexList {
    internalValue?: ApsWorkspaceQueryLoggingConfigurationDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsWorkspaceQueryLoggingConfigurationDestinationsOutputReference;
}
export interface ApsWorkspaceQueryLoggingConfiguration {
    /**
    * The destinations configuration for query logging
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#destinations ApsWorkspace#destinations}
    */
    readonly destinations?: ApsWorkspaceQueryLoggingConfigurationDestinations[] | cdktn.IResolvable;
}
export declare function apsWorkspaceQueryLoggingConfigurationToTerraform(struct?: ApsWorkspaceQueryLoggingConfiguration | cdktn.IResolvable): any;
export declare function apsWorkspaceQueryLoggingConfigurationToHclTerraform(struct?: ApsWorkspaceQueryLoggingConfiguration | cdktn.IResolvable): any;
export declare class ApsWorkspaceQueryLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsWorkspaceQueryLoggingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceQueryLoggingConfiguration | cdktn.IResolvable | undefined);
    private _destinations;
    get destinations(): ApsWorkspaceQueryLoggingConfigurationDestinationsList;
    putDestinations(value: ApsWorkspaceQueryLoggingConfigurationDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | ApsWorkspaceQueryLoggingConfigurationDestinations[] | undefined;
}
export interface ApsWorkspaceTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#key ApsWorkspace#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#value ApsWorkspace#value}
    */
    readonly value?: string;
}
export declare function apsWorkspaceTagsToTerraform(struct?: ApsWorkspaceTags | cdktn.IResolvable): any;
export declare function apsWorkspaceTagsToHclTerraform(struct?: ApsWorkspaceTags | cdktn.IResolvable): any;
export declare class ApsWorkspaceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsWorkspaceTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApsWorkspaceTagsList extends cdktn.ComplexList {
    internalValue?: ApsWorkspaceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsWorkspaceTagsOutputReference;
}
export interface ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet {
    /**
    * Name of the label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#name ApsWorkspace#name}
    */
    readonly name?: string;
    /**
    * Value of the label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#value ApsWorkspace#value}
    */
    readonly value?: string;
}
export declare function apsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSetToTerraform(struct?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet | cdktn.IResolvable): any;
export declare function apsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSetToHclTerraform(struct?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet | cdktn.IResolvable): any;
export declare class ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSetList extends cdktn.ComplexList {
    internalValue?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSetOutputReference;
}
export interface ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimits {
    /**
    * The maximum number of active series that can be ingested for this label set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#max_series ApsWorkspace#max_series}
    */
    readonly maxSeries?: number;
}
export declare function apsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimitsToTerraform(struct?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimits | cdktn.IResolvable): any;
export declare function apsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimitsToHclTerraform(struct?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimits | cdktn.IResolvable): any;
export declare class ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimits | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimits | cdktn.IResolvable | undefined);
    private _maxSeries?;
    get maxSeries(): number;
    set maxSeries(value: number);
    resetMaxSeries(): void;
    get maxSeriesInput(): number | undefined;
}
export interface ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets {
    /**
    * An array of series labels
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#label_set ApsWorkspace#label_set}
    */
    readonly labelSet?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet[] | cdktn.IResolvable;
    /**
    * Limits that can be applied to a label set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#limits ApsWorkspace#limits}
    */
    readonly limits?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimits;
}
export declare function apsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsToTerraform(struct?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets | cdktn.IResolvable): any;
export declare function apsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsToHclTerraform(struct?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets | cdktn.IResolvable): any;
export declare class ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets | cdktn.IResolvable | undefined);
    private _labelSet;
    get labelSet(): ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSetList;
    putLabelSet(value: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet[] | cdktn.IResolvable): void;
    resetLabelSet(): void;
    get labelSetInput(): cdktn.IResolvable | ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLabelSet[] | undefined;
    private _limits;
    get limits(): ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimitsOutputReference;
    putLimits(value: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimits): void;
    resetLimits(): void;
    get limitsInput(): cdktn.IResolvable | ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsLimits | undefined;
}
export declare class ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsList extends cdktn.ComplexList {
    internalValue?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsOutputReference;
}
export interface ApsWorkspaceWorkspaceConfiguration {
    /**
    * An array of label set and associated limits
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#limits_per_label_sets ApsWorkspace#limits_per_label_sets}
    */
    readonly limitsPerLabelSets?: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets[] | cdktn.IResolvable;
    /**
    * The time window in seconds for accepting out-of-order samples
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#out_of_order_time_window_in_seconds ApsWorkspace#out_of_order_time_window_in_seconds}
    */
    readonly outOfOrderTimeWindowInSeconds?: number;
    /**
    * How many days that metrics are retained in the workspace
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#retention_period_in_days ApsWorkspace#retention_period_in_days}
    */
    readonly retentionPeriodInDays?: number;
    /**
    * Duration in seconds to offset rule evaluation queries into the past
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#rule_query_offset_in_seconds ApsWorkspace#rule_query_offset_in_seconds}
    */
    readonly ruleQueryOffsetInSeconds?: number;
}
export declare function apsWorkspaceWorkspaceConfigurationToTerraform(struct?: ApsWorkspaceWorkspaceConfiguration | cdktn.IResolvable): any;
export declare function apsWorkspaceWorkspaceConfigurationToHclTerraform(struct?: ApsWorkspaceWorkspaceConfiguration | cdktn.IResolvable): any;
export declare class ApsWorkspaceWorkspaceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApsWorkspaceWorkspaceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApsWorkspaceWorkspaceConfiguration | cdktn.IResolvable | undefined);
    private _limitsPerLabelSets;
    get limitsPerLabelSets(): ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSetsList;
    putLimitsPerLabelSets(value: ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets[] | cdktn.IResolvable): void;
    resetLimitsPerLabelSets(): void;
    get limitsPerLabelSetsInput(): cdktn.IResolvable | ApsWorkspaceWorkspaceConfigurationLimitsPerLabelSets[] | undefined;
    private _outOfOrderTimeWindowInSeconds?;
    get outOfOrderTimeWindowInSeconds(): number;
    set outOfOrderTimeWindowInSeconds(value: number);
    resetOutOfOrderTimeWindowInSeconds(): void;
    get outOfOrderTimeWindowInSecondsInput(): number | undefined;
    private _retentionPeriodInDays?;
    get retentionPeriodInDays(): number;
    set retentionPeriodInDays(value: number);
    resetRetentionPeriodInDays(): void;
    get retentionPeriodInDaysInput(): number | undefined;
    private _ruleQueryOffsetInSeconds?;
    get ruleQueryOffsetInSeconds(): number;
    set ruleQueryOffsetInSeconds(value: number);
    resetRuleQueryOffsetInSeconds(): void;
    get ruleQueryOffsetInSecondsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace awscc_aps_workspace}
*/
export declare class ApsWorkspace extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_aps_workspace";
    /**
    * Generates CDKTN code for importing a ApsWorkspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApsWorkspace to import
    * @param importFromId The id of the existing ApsWorkspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApsWorkspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aps_workspace awscc_aps_workspace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApsWorkspaceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApsWorkspaceConfig);
    private _alertManagerDefinition?;
    get alertManagerDefinition(): string;
    set alertManagerDefinition(value: string);
    resetAlertManagerDefinition(): void;
    get alertManagerDefinitionInput(): string | undefined;
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    get arn(): string;
    get id(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): ApsWorkspaceLoggingConfigurationOutputReference;
    putLoggingConfiguration(value: ApsWorkspaceLoggingConfiguration): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): cdktn.IResolvable | ApsWorkspaceLoggingConfiguration | undefined;
    get prometheusEndpoint(): string;
    private _queryLoggingConfiguration;
    get queryLoggingConfiguration(): ApsWorkspaceQueryLoggingConfigurationOutputReference;
    putQueryLoggingConfiguration(value: ApsWorkspaceQueryLoggingConfiguration): void;
    resetQueryLoggingConfiguration(): void;
    get queryLoggingConfigurationInput(): cdktn.IResolvable | ApsWorkspaceQueryLoggingConfiguration | undefined;
    private _tags;
    get tags(): ApsWorkspaceTagsList;
    putTags(value: ApsWorkspaceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApsWorkspaceTags[] | undefined;
    private _workspaceConfiguration;
    get workspaceConfiguration(): ApsWorkspaceWorkspaceConfigurationOutputReference;
    putWorkspaceConfiguration(value: ApsWorkspaceWorkspaceConfiguration): void;
    resetWorkspaceConfiguration(): void;
    get workspaceConfigurationInput(): cdktn.IResolvable | ApsWorkspaceWorkspaceConfiguration | undefined;
    get workspaceId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
