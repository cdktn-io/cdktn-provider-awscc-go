/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreApiKeyCredentialProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The API key to use for authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#api_key BedrockagentcoreApiKeyCredentialProvider#api_key}
    */
    readonly apiKey?: string;
    /**
    * Configuration for a customer-provided secret containing the API key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#api_key_secret_config BedrockagentcoreApiKeyCredentialProvider#api_key_secret_config}
    */
    readonly apiKeySecretConfig?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig;
    /**
    * The source of the API key secret. Use MANAGED for service-managed secrets or EXTERNAL for customer-provided secrets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#api_key_secret_source BedrockagentcoreApiKeyCredentialProvider#api_key_secret_source}
    */
    readonly apiKeySecretSource?: string;
    /**
    * The name of the API key credential provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#name BedrockagentcoreApiKeyCredentialProvider#name}
    */
    readonly name: string;
    /**
    * Tags to assign to the API key credential provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#tags BedrockagentcoreApiKeyCredentialProvider#tags}
    */
    readonly tags?: BedrockagentcoreApiKeyCredentialProviderTags[] | cdktn.IResolvable;
}
export interface BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn {
}
export declare function bedrockagentcoreApiKeyCredentialProviderApiKeySecretArnToTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn): any;
export declare function bedrockagentcoreApiKeyCredentialProviderApiKeySecretArnToHclTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn): any;
export declare class BedrockagentcoreApiKeyCredentialProviderApiKeySecretArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn | undefined;
    set internalValue(value: BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn | undefined);
    get secretArn(): string;
}
export interface BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig {
    /**
    * The JSON key within the secret that contains the credential value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#json_key BedrockagentcoreApiKeyCredentialProvider#json_key}
    */
    readonly jsonKey?: string;
    /**
    * The ID or ARN of the secret in AWS Secrets Manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#secret_id BedrockagentcoreApiKeyCredentialProvider#secret_id}
    */
    readonly secretId?: string;
}
export declare function bedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigToTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigToHclTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | cdktn.IResolvable | undefined);
    private _jsonKey?;
    get jsonKey(): string;
    set jsonKey(value: string);
    resetJsonKey(): void;
    get jsonKeyInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    resetSecretId(): void;
    get secretIdInput(): string | undefined;
}
export interface BedrockagentcoreApiKeyCredentialProviderTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#key BedrockagentcoreApiKeyCredentialProvider#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#value BedrockagentcoreApiKeyCredentialProvider#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcoreApiKeyCredentialProviderTagsToTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderTags | cdktn.IResolvable): any;
export declare function bedrockagentcoreApiKeyCredentialProviderTagsToHclTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderTags | cdktn.IResolvable): any;
export declare class BedrockagentcoreApiKeyCredentialProviderTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreApiKeyCredentialProviderTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreApiKeyCredentialProviderTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcoreApiKeyCredentialProviderTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreApiKeyCredentialProviderTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreApiKeyCredentialProviderTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider awscc_bedrockagentcore_api_key_credential_provider}
*/
export declare class BedrockagentcoreApiKeyCredentialProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_api_key_credential_provider";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreApiKeyCredentialProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreApiKeyCredentialProvider to import
    * @param importFromId The id of the existing BedrockagentcoreApiKeyCredentialProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreApiKeyCredentialProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_api_key_credential_provider awscc_bedrockagentcore_api_key_credential_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreApiKeyCredentialProviderConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreApiKeyCredentialProviderConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _apiKeySecretArn;
    get apiKeySecretArn(): BedrockagentcoreApiKeyCredentialProviderApiKeySecretArnOutputReference;
    private _apiKeySecretConfig;
    get apiKeySecretConfig(): BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigOutputReference;
    putApiKeySecretConfig(value: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig): void;
    resetApiKeySecretConfig(): void;
    get apiKeySecretConfigInput(): cdktn.IResolvable | BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | undefined;
    get apiKeySecretJsonKey(): string;
    private _apiKeySecretSource?;
    get apiKeySecretSource(): string;
    set apiKeySecretSource(value: string);
    resetApiKeySecretSource(): void;
    get apiKeySecretSourceInput(): string | undefined;
    get createdTime(): string;
    get credentialProviderArn(): string;
    get id(): string;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): BedrockagentcoreApiKeyCredentialProviderTagsList;
    putTags(value: BedrockagentcoreApiKeyCredentialProviderTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcoreApiKeyCredentialProviderTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
