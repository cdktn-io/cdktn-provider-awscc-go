/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayBasePathMappingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * The base path name that callers of the API must provide in the URL after the domain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_base_path_mapping_v2#base_path ApigatewayBasePathMappingV2#base_path}
    */
    readonly basePath?: string;
    /**
    * The Arn of an AWS::ApiGateway::DomainNameV2 resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_base_path_mapping_v2#domain_name_arn ApigatewayBasePathMappingV2#domain_name_arn}
    */
    readonly domainNameArn: string;
    /**
    * The ID of the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_base_path_mapping_v2#rest_api_id ApigatewayBasePathMappingV2#rest_api_id}
    */
    readonly restApiId: string;
    /**
    * The name of the API's stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_base_path_mapping_v2#stage ApigatewayBasePathMappingV2#stage}
    */
    readonly stage?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_base_path_mapping_v2 awscc_apigateway_base_path_mapping_v2}
*/
export declare class ApigatewayBasePathMappingV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_base_path_mapping_v2";
    /**
    * Generates CDKTN code for importing a ApigatewayBasePathMappingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayBasePathMappingV2 to import
    * @param importFromId The id of the existing ApigatewayBasePathMappingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_base_path_mapping_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayBasePathMappingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_base_path_mapping_v2 awscc_apigateway_base_path_mapping_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayBasePathMappingV2Config
    */
    constructor(scope: Construct, id: string, config: ApigatewayBasePathMappingV2Config);
    private _basePath?;
    get basePath(): string;
    set basePath(value: string);
    resetBasePath(): void;
    get basePathInput(): string | undefined;
    get basePathMappingArn(): string;
    private _domainNameArn?;
    get domainNameArn(): string;
    set domainNameArn(value: string);
    get domainNameArnInput(): string | undefined;
    get id(): string;
    private _restApiId?;
    get restApiId(): string;
    set restApiId(value: string);
    get restApiIdInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    resetStage(): void;
    get stageInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
