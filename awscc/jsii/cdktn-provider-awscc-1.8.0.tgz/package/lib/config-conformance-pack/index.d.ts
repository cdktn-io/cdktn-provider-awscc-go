/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigConformancePackConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of ConformancePackInputParameter objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#conformance_pack_input_parameters ConfigConformancePack#conformance_pack_input_parameters}
    */
    readonly conformancePackInputParameters?: ConfigConformancePackConformancePackInputParameters[] | cdktn.IResolvable;
    /**
    * Name of the conformance pack which will be assigned as the unique identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#conformance_pack_name ConfigConformancePack#conformance_pack_name}
    */
    readonly conformancePackName: string;
    /**
    * AWS Config stores intermediate files while processing conformance pack template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#delivery_s3_bucket ConfigConformancePack#delivery_s3_bucket}
    */
    readonly deliveryS3Bucket?: string;
    /**
    * The prefix for delivery S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#delivery_s3_key_prefix ConfigConformancePack#delivery_s3_key_prefix}
    */
    readonly deliveryS3KeyPrefix?: string;
    /**
    * The tags for the conformance pack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#tags ConfigConformancePack#tags}
    */
    readonly tags?: ConfigConformancePackTags[] | cdktn.IResolvable;
    /**
    * A string containing full conformance pack template body. You can only specify one of the template body or template S3Uri fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#template_body ConfigConformancePack#template_body}
    */
    readonly templateBody?: string;
    /**
    * Location of file containing the template body which points to the conformance pack template that is located in an Amazon S3 bucket. You can only specify one of the template body or template S3Uri fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#template_s3_uri ConfigConformancePack#template_s3_uri}
    */
    readonly templateS3Uri?: string;
    /**
    * The TemplateSSMDocumentDetails object contains the name of the SSM document and the version of the SSM document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#template_ssm_document_details ConfigConformancePack#template_ssm_document_details}
    */
    readonly templateSsmDocumentDetails?: ConfigConformancePackTemplateSsmDocumentDetails;
}
export interface ConfigConformancePackConformancePackInputParameters {
    /**
    * Key part of key-value pair with value being parameter value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#parameter_name ConfigConformancePack#parameter_name}
    */
    readonly parameterName?: string;
    /**
    * Value part of key-value pair with key being parameter Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#parameter_value ConfigConformancePack#parameter_value}
    */
    readonly parameterValue?: string;
}
export declare function configConformancePackConformancePackInputParametersToTerraform(struct?: ConfigConformancePackConformancePackInputParameters | cdktn.IResolvable): any;
export declare function configConformancePackConformancePackInputParametersToHclTerraform(struct?: ConfigConformancePackConformancePackInputParameters | cdktn.IResolvable): any;
export declare class ConfigConformancePackConformancePackInputParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigConformancePackConformancePackInputParameters | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConformancePackConformancePackInputParameters | cdktn.IResolvable | undefined);
    private _parameterName?;
    get parameterName(): string;
    set parameterName(value: string);
    resetParameterName(): void;
    get parameterNameInput(): string | undefined;
    private _parameterValue?;
    get parameterValue(): string;
    set parameterValue(value: string);
    resetParameterValue(): void;
    get parameterValueInput(): string | undefined;
}
export declare class ConfigConformancePackConformancePackInputParametersList extends cdktn.ComplexList {
    internalValue?: ConfigConformancePackConformancePackInputParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigConformancePackConformancePackInputParametersOutputReference;
}
export interface ConfigConformancePackTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#key ConfigConformancePack#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#value ConfigConformancePack#value}
    */
    readonly value?: string;
}
export declare function configConformancePackTagsToTerraform(struct?: ConfigConformancePackTags | cdktn.IResolvable): any;
export declare function configConformancePackTagsToHclTerraform(struct?: ConfigConformancePackTags | cdktn.IResolvable): any;
export declare class ConfigConformancePackTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigConformancePackTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConformancePackTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConfigConformancePackTagsList extends cdktn.ComplexList {
    internalValue?: ConfigConformancePackTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigConformancePackTagsOutputReference;
}
export interface ConfigConformancePackTemplateSsmDocumentDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#document_name ConfigConformancePack#document_name}
    */
    readonly documentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#document_version ConfigConformancePack#document_version}
    */
    readonly documentVersion?: string;
}
export declare function configConformancePackTemplateSsmDocumentDetailsToTerraform(struct?: ConfigConformancePackTemplateSsmDocumentDetails | cdktn.IResolvable): any;
export declare function configConformancePackTemplateSsmDocumentDetailsToHclTerraform(struct?: ConfigConformancePackTemplateSsmDocumentDetails | cdktn.IResolvable): any;
export declare class ConfigConformancePackTemplateSsmDocumentDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigConformancePackTemplateSsmDocumentDetails | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigConformancePackTemplateSsmDocumentDetails | cdktn.IResolvable | undefined);
    private _documentName?;
    get documentName(): string;
    set documentName(value: string);
    resetDocumentName(): void;
    get documentNameInput(): string | undefined;
    private _documentVersion?;
    get documentVersion(): string;
    set documentVersion(value: string);
    resetDocumentVersion(): void;
    get documentVersionInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack awscc_config_conformance_pack}
*/
export declare class ConfigConformancePack extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_conformance_pack";
    /**
    * Generates CDKTN code for importing a ConfigConformancePack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigConformancePack to import
    * @param importFromId The id of the existing ConfigConformancePack that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigConformancePack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/config_conformance_pack awscc_config_conformance_pack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigConformancePackConfig
    */
    constructor(scope: Construct, id: string, config: ConfigConformancePackConfig);
    get conformancePackArn(): string;
    private _conformancePackInputParameters;
    get conformancePackInputParameters(): ConfigConformancePackConformancePackInputParametersList;
    putConformancePackInputParameters(value: ConfigConformancePackConformancePackInputParameters[] | cdktn.IResolvable): void;
    resetConformancePackInputParameters(): void;
    get conformancePackInputParametersInput(): cdktn.IResolvable | ConfigConformancePackConformancePackInputParameters[] | undefined;
    private _conformancePackName?;
    get conformancePackName(): string;
    set conformancePackName(value: string);
    get conformancePackNameInput(): string | undefined;
    private _deliveryS3Bucket?;
    get deliveryS3Bucket(): string;
    set deliveryS3Bucket(value: string);
    resetDeliveryS3Bucket(): void;
    get deliveryS3BucketInput(): string | undefined;
    private _deliveryS3KeyPrefix?;
    get deliveryS3KeyPrefix(): string;
    set deliveryS3KeyPrefix(value: string);
    resetDeliveryS3KeyPrefix(): void;
    get deliveryS3KeyPrefixInput(): string | undefined;
    get id(): string;
    private _tags;
    get tags(): ConfigConformancePackTagsList;
    putTags(value: ConfigConformancePackTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConfigConformancePackTags[] | undefined;
    private _templateBody?;
    get templateBody(): string;
    set templateBody(value: string);
    resetTemplateBody(): void;
    get templateBodyInput(): string | undefined;
    private _templateS3Uri?;
    get templateS3Uri(): string;
    set templateS3Uri(value: string);
    resetTemplateS3Uri(): void;
    get templateS3UriInput(): string | undefined;
    private _templateSsmDocumentDetails;
    get templateSsmDocumentDetails(): ConfigConformancePackTemplateSsmDocumentDetailsOutputReference;
    putTemplateSsmDocumentDetails(value: ConfigConformancePackTemplateSsmDocumentDetails): void;
    resetTemplateSsmDocumentDetails(): void;
    get templateSsmDocumentDetailsInput(): cdktn.IResolvable | ConfigConformancePackTemplateSsmDocumentDetails | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
