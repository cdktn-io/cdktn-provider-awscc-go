/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayStageConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ``AccessLogSetting`` property type specifies settings for logging access in this stage.
    *  ``AccessLogSetting`` is a property of the [AWS::ApiGateway::Stage](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-stage.html) resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#access_log_setting ApigatewayStage#access_log_setting}
    */
    readonly accessLogSetting?: ApigatewayStageAccessLogSetting;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#cache_cluster_enabled ApigatewayStage#cache_cluster_enabled}
    */
    readonly cacheClusterEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#cache_cluster_size ApigatewayStage#cache_cluster_size}
    */
    readonly cacheClusterSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#canary_setting ApigatewayStage#canary_setting}
    */
    readonly canarySetting?: ApigatewayStageCanarySetting;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#client_certificate_id ApigatewayStage#client_certificate_id}
    */
    readonly clientCertificateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#deployment_id ApigatewayStage#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#description ApigatewayStage#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#documentation_version ApigatewayStage#documentation_version}
    */
    readonly documentationVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#method_settings ApigatewayStage#method_settings}
    */
    readonly methodSettings?: ApigatewayStageMethodSettings[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#rest_api_id ApigatewayStage#rest_api_id}
    */
    readonly restApiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#stage_name ApigatewayStage#stage_name}
    */
    readonly stageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#tags ApigatewayStage#tags}
    */
    readonly tags?: ApigatewayStageTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#tracing_enabled ApigatewayStage#tracing_enabled}
    */
    readonly tracingEnabled?: boolean | cdktn.IResolvable;
    /**
    * A map (string-to-string map) that defines the stage variables, where the variable name is the key and the variable value is the value. Variable names are limited to alphanumeric characters. Values must match the following regular expression: ``[A-Za-z0-9-._~:/?#&=,]+``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#variables ApigatewayStage#variables}
    */
    readonly variables?: {
        [key: string]: string;
    };
}
export interface ApigatewayStageAccessLogSetting {
    /**
    * The Amazon Resource Name (ARN) of the CloudWatch Logs log group or Kinesis Data Firehose delivery stream to receive access logs. If you specify a Kinesis Data Firehose delivery stream, the stream name must begin with ``amazon-apigateway-``. This parameter is required to enable access logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#destination_arn ApigatewayStage#destination_arn}
    */
    readonly destinationArn?: string;
    /**
    * A single line format of the access logs of data, as specified by selected [$context variables](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-mapping-template-reference.html#context-variable-reference). The format must include at least ``$context.requestId``. This parameter is required to enable access logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#format ApigatewayStage#format}
    */
    readonly format?: string;
}
export declare function apigatewayStageAccessLogSettingToTerraform(struct?: ApigatewayStageAccessLogSetting | cdktn.IResolvable): any;
export declare function apigatewayStageAccessLogSettingToHclTerraform(struct?: ApigatewayStageAccessLogSetting | cdktn.IResolvable): any;
export declare class ApigatewayStageAccessLogSettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayStageAccessLogSetting | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayStageAccessLogSetting | cdktn.IResolvable | undefined);
    private _destinationArn?;
    get destinationArn(): string;
    set destinationArn(value: string);
    resetDestinationArn(): void;
    get destinationArnInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
}
export interface ApigatewayStageCanarySetting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#deployment_id ApigatewayStage#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#percent_traffic ApigatewayStage#percent_traffic}
    */
    readonly percentTraffic?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#stage_variable_overrides ApigatewayStage#stage_variable_overrides}
    */
    readonly stageVariableOverrides?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#use_stage_cache ApigatewayStage#use_stage_cache}
    */
    readonly useStageCache?: boolean | cdktn.IResolvable;
}
export declare function apigatewayStageCanarySettingToTerraform(struct?: ApigatewayStageCanarySetting | cdktn.IResolvable): any;
export declare function apigatewayStageCanarySettingToHclTerraform(struct?: ApigatewayStageCanarySetting | cdktn.IResolvable): any;
export declare class ApigatewayStageCanarySettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayStageCanarySetting | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayStageCanarySetting | cdktn.IResolvable | undefined);
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _percentTraffic?;
    get percentTraffic(): number;
    set percentTraffic(value: number);
    resetPercentTraffic(): void;
    get percentTrafficInput(): number | undefined;
    private _stageVariableOverrides?;
    get stageVariableOverrides(): {
        [key: string]: string;
    };
    set stageVariableOverrides(value: {
        [key: string]: string;
    });
    resetStageVariableOverrides(): void;
    get stageVariableOverridesInput(): {
        [key: string]: string;
    } | undefined;
    private _useStageCache?;
    get useStageCache(): boolean | cdktn.IResolvable;
    set useStageCache(value: boolean | cdktn.IResolvable);
    resetUseStageCache(): void;
    get useStageCacheInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApigatewayStageMethodSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#cache_data_encrypted ApigatewayStage#cache_data_encrypted}
    */
    readonly cacheDataEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#cache_ttl_in_seconds ApigatewayStage#cache_ttl_in_seconds}
    */
    readonly cacheTtlInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#caching_enabled ApigatewayStage#caching_enabled}
    */
    readonly cachingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#data_trace_enabled ApigatewayStage#data_trace_enabled}
    */
    readonly dataTraceEnabled?: boolean | cdktn.IResolvable;
    /**
    * The HTTP method. To apply settings to multiple resources and methods, specify an asterisk (``*``) for the ``HttpMethod`` and ``/*`` for the ``ResourcePath``. This parameter is required when you specify a ``MethodSetting``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#http_method ApigatewayStage#http_method}
    */
    readonly httpMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#logging_level ApigatewayStage#logging_level}
    */
    readonly loggingLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#metrics_enabled ApigatewayStage#metrics_enabled}
    */
    readonly metricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * The resource path for this method. Forward slashes (``/``) are encoded as ``~1`` and the initial slash must include a forward slash. For example, the path value ``/resource/subresource`` must be encoded as ``/~1resource~1subresource``. To specify the root path, use only a slash (``/``). To apply settings to multiple resources and methods, specify an asterisk (``*``) for the ``HttpMethod`` and ``/*`` for the ``ResourcePath``. This parameter is required when you specify a ``MethodSetting``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#resource_path ApigatewayStage#resource_path}
    */
    readonly resourcePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#throttling_burst_limit ApigatewayStage#throttling_burst_limit}
    */
    readonly throttlingBurstLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#throttling_rate_limit ApigatewayStage#throttling_rate_limit}
    */
    readonly throttlingRateLimit?: number;
}
export declare function apigatewayStageMethodSettingsToTerraform(struct?: ApigatewayStageMethodSettings | cdktn.IResolvable): any;
export declare function apigatewayStageMethodSettingsToHclTerraform(struct?: ApigatewayStageMethodSettings | cdktn.IResolvable): any;
export declare class ApigatewayStageMethodSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayStageMethodSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayStageMethodSettings | cdktn.IResolvable | undefined);
    private _cacheDataEncrypted?;
    get cacheDataEncrypted(): boolean | cdktn.IResolvable;
    set cacheDataEncrypted(value: boolean | cdktn.IResolvable);
    resetCacheDataEncrypted(): void;
    get cacheDataEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheTtlInSeconds?;
    get cacheTtlInSeconds(): number;
    set cacheTtlInSeconds(value: number);
    resetCacheTtlInSeconds(): void;
    get cacheTtlInSecondsInput(): number | undefined;
    private _cachingEnabled?;
    get cachingEnabled(): boolean | cdktn.IResolvable;
    set cachingEnabled(value: boolean | cdktn.IResolvable);
    resetCachingEnabled(): void;
    get cachingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _dataTraceEnabled?;
    get dataTraceEnabled(): boolean | cdktn.IResolvable;
    set dataTraceEnabled(value: boolean | cdktn.IResolvable);
    resetDataTraceEnabled(): void;
    get dataTraceEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _httpMethod?;
    get httpMethod(): string;
    set httpMethod(value: string);
    resetHttpMethod(): void;
    get httpMethodInput(): string | undefined;
    private _loggingLevel?;
    get loggingLevel(): string;
    set loggingLevel(value: string);
    resetLoggingLevel(): void;
    get loggingLevelInput(): string | undefined;
    private _metricsEnabled?;
    get metricsEnabled(): boolean | cdktn.IResolvable;
    set metricsEnabled(value: boolean | cdktn.IResolvable);
    resetMetricsEnabled(): void;
    get metricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _resourcePath?;
    get resourcePath(): string;
    set resourcePath(value: string);
    resetResourcePath(): void;
    get resourcePathInput(): string | undefined;
    private _throttlingBurstLimit?;
    get throttlingBurstLimit(): number;
    set throttlingBurstLimit(value: number);
    resetThrottlingBurstLimit(): void;
    get throttlingBurstLimitInput(): number | undefined;
    private _throttlingRateLimit?;
    get throttlingRateLimit(): number;
    set throttlingRateLimit(value: number);
    resetThrottlingRateLimit(): void;
    get throttlingRateLimitInput(): number | undefined;
}
export declare class ApigatewayStageMethodSettingsList extends cdktn.ComplexList {
    internalValue?: ApigatewayStageMethodSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayStageMethodSettingsOutputReference;
}
export interface ApigatewayStageTags {
    /**
    * A string you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#key ApigatewayStage#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#value ApigatewayStage#value}
    */
    readonly value?: string;
}
export declare function apigatewayStageTagsToTerraform(struct?: ApigatewayStageTags | cdktn.IResolvable): any;
export declare function apigatewayStageTagsToHclTerraform(struct?: ApigatewayStageTags | cdktn.IResolvable): any;
export declare class ApigatewayStageTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayStageTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayStageTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigatewayStageTagsList extends cdktn.ComplexList {
    internalValue?: ApigatewayStageTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayStageTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage awscc_apigateway_stage}
*/
export declare class ApigatewayStage extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_stage";
    /**
    * Generates CDKTN code for importing a ApigatewayStage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayStage to import
    * @param importFromId The id of the existing ApigatewayStage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayStage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/apigateway_stage awscc_apigateway_stage} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayStageConfig
    */
    constructor(scope: Construct, id: string, config: ApigatewayStageConfig);
    private _accessLogSetting;
    get accessLogSetting(): ApigatewayStageAccessLogSettingOutputReference;
    putAccessLogSetting(value: ApigatewayStageAccessLogSetting): void;
    resetAccessLogSetting(): void;
    get accessLogSettingInput(): cdktn.IResolvable | ApigatewayStageAccessLogSetting | undefined;
    private _cacheClusterEnabled?;
    get cacheClusterEnabled(): boolean | cdktn.IResolvable;
    set cacheClusterEnabled(value: boolean | cdktn.IResolvable);
    resetCacheClusterEnabled(): void;
    get cacheClusterEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheClusterSize?;
    get cacheClusterSize(): string;
    set cacheClusterSize(value: string);
    resetCacheClusterSize(): void;
    get cacheClusterSizeInput(): string | undefined;
    private _canarySetting;
    get canarySetting(): ApigatewayStageCanarySettingOutputReference;
    putCanarySetting(value: ApigatewayStageCanarySetting): void;
    resetCanarySetting(): void;
    get canarySettingInput(): cdktn.IResolvable | ApigatewayStageCanarySetting | undefined;
    private _clientCertificateId?;
    get clientCertificateId(): string;
    set clientCertificateId(value: string);
    resetClientCertificateId(): void;
    get clientCertificateIdInput(): string | undefined;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _documentationVersion?;
    get documentationVersion(): string;
    set documentationVersion(value: string);
    resetDocumentationVersion(): void;
    get documentationVersionInput(): string | undefined;
    get id(): string;
    private _methodSettings;
    get methodSettings(): ApigatewayStageMethodSettingsList;
    putMethodSettings(value: ApigatewayStageMethodSettings[] | cdktn.IResolvable): void;
    resetMethodSettings(): void;
    get methodSettingsInput(): cdktn.IResolvable | ApigatewayStageMethodSettings[] | undefined;
    private _restApiId?;
    get restApiId(): string;
    set restApiId(value: string);
    get restApiIdInput(): string | undefined;
    private _stageName?;
    get stageName(): string;
    set stageName(value: string);
    resetStageName(): void;
    get stageNameInput(): string | undefined;
    private _tags;
    get tags(): ApigatewayStageTagsList;
    putTags(value: ApigatewayStageTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApigatewayStageTags[] | undefined;
    private _tracingEnabled?;
    get tracingEnabled(): boolean | cdktn.IResolvable;
    set tracingEnabled(value: boolean | cdktn.IResolvable);
    resetTracingEnabled(): void;
    get tracingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _variables?;
    get variables(): {
        [key: string]: string;
    };
    set variables(value: {
        [key: string]: string;
    });
    resetVariables(): void;
    get variablesInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
