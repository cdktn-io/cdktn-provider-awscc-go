/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CasesLayoutConfig extends cdktn.TerraformMetaArguments {
    /**
    * Defines the layout structure and field organization for the case interface. Specifies which fields appear in the top panel and More Info tab, and their display order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#content CasesLayout#content}
    */
    readonly content: CasesLayoutContent;
    /**
    * The unique identifier of the Cases domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#domain_id CasesLayout#domain_id}
    */
    readonly domainId?: string;
    /**
    * A descriptive name for the layout. Must be unique within the Cases domain and should clearly indicate the layout's purpose and field organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#name CasesLayout#name}
    */
    readonly name: string;
    /**
    * The tags that you attach to this layout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#tags CasesLayout#tags}
    */
    readonly tags?: CasesLayoutTags[] | cdktn.IResolvable;
}
export interface CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields {
    /**
    * The unique identifier of a field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#id CasesLayout#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function casesLayoutContentBasicMoreInfoSectionsFieldGroupFieldsToTerraform(struct?: CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicMoreInfoSectionsFieldGroupFieldsToHclTerraform(struct?: CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicMoreInfoSectionsFieldGroupFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export declare class CasesLayoutContentBasicMoreInfoSectionsFieldGroupFieldsList extends cdktn.ComplexList {
    internalValue?: CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesLayoutContentBasicMoreInfoSectionsFieldGroupFieldsOutputReference;
}
export interface CasesLayoutContentBasicMoreInfoSectionsFieldGroup {
    /**
    * An ordered list of fields to display in this group. The order determines the sequence in which fields appear in the agent interface. Each field is referenced by its unique field ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#fields CasesLayout#fields}
    */
    readonly fields?: CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields[] | cdktn.IResolvable;
    /**
    * A descriptive name for the field group. Helps organize related fields together in the layout interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#name CasesLayout#name}
    */
    readonly name?: string;
}
export declare function casesLayoutContentBasicMoreInfoSectionsFieldGroupToTerraform(struct?: CasesLayoutContentBasicMoreInfoSectionsFieldGroup | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicMoreInfoSectionsFieldGroupToHclTerraform(struct?: CasesLayoutContentBasicMoreInfoSectionsFieldGroup | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicMoreInfoSectionsFieldGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesLayoutContentBasicMoreInfoSectionsFieldGroup | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasicMoreInfoSectionsFieldGroup | cdktn.IResolvable | undefined);
    private _fields;
    get fields(): CasesLayoutContentBasicMoreInfoSectionsFieldGroupFieldsList;
    putFields(value: CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields[] | cdktn.IResolvable): void;
    resetFields(): void;
    get fieldsInput(): cdktn.IResolvable | CasesLayoutContentBasicMoreInfoSectionsFieldGroupFields[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface CasesLayoutContentBasicMoreInfoSections {
    /**
    * Consists of a group of fields and associated properties.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#field_group CasesLayout#field_group}
    */
    readonly fieldGroup?: CasesLayoutContentBasicMoreInfoSectionsFieldGroup;
}
export declare function casesLayoutContentBasicMoreInfoSectionsToTerraform(struct?: CasesLayoutContentBasicMoreInfoSections | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicMoreInfoSectionsToHclTerraform(struct?: CasesLayoutContentBasicMoreInfoSections | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicMoreInfoSectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesLayoutContentBasicMoreInfoSections | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasicMoreInfoSections | cdktn.IResolvable | undefined);
    private _fieldGroup;
    get fieldGroup(): CasesLayoutContentBasicMoreInfoSectionsFieldGroupOutputReference;
    putFieldGroup(value: CasesLayoutContentBasicMoreInfoSectionsFieldGroup): void;
    resetFieldGroup(): void;
    get fieldGroupInput(): cdktn.IResolvable | CasesLayoutContentBasicMoreInfoSectionsFieldGroup | undefined;
}
export declare class CasesLayoutContentBasicMoreInfoSectionsList extends cdktn.ComplexList {
    internalValue?: CasesLayoutContentBasicMoreInfoSections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesLayoutContentBasicMoreInfoSectionsOutputReference;
}
export interface CasesLayoutContentBasicMoreInfo {
    /**
    * Defines the sections within a panel or tab. Contains field groups that organize related fields together.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#sections CasesLayout#sections}
    */
    readonly sections?: CasesLayoutContentBasicMoreInfoSections[] | cdktn.IResolvable;
}
export declare function casesLayoutContentBasicMoreInfoToTerraform(struct?: CasesLayoutContentBasicMoreInfo | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicMoreInfoToHclTerraform(struct?: CasesLayoutContentBasicMoreInfo | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicMoreInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesLayoutContentBasicMoreInfo | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasicMoreInfo | cdktn.IResolvable | undefined);
    private _sections;
    get sections(): CasesLayoutContentBasicMoreInfoSectionsList;
    putSections(value: CasesLayoutContentBasicMoreInfoSections[] | cdktn.IResolvable): void;
    resetSections(): void;
    get sectionsInput(): cdktn.IResolvable | CasesLayoutContentBasicMoreInfoSections[] | undefined;
}
export interface CasesLayoutContentBasicTopPanelSectionsFieldGroupFields {
    /**
    * The unique identifier of a field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#id CasesLayout#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function casesLayoutContentBasicTopPanelSectionsFieldGroupFieldsToTerraform(struct?: CasesLayoutContentBasicTopPanelSectionsFieldGroupFields | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicTopPanelSectionsFieldGroupFieldsToHclTerraform(struct?: CasesLayoutContentBasicTopPanelSectionsFieldGroupFields | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicTopPanelSectionsFieldGroupFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesLayoutContentBasicTopPanelSectionsFieldGroupFields | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasicTopPanelSectionsFieldGroupFields | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export declare class CasesLayoutContentBasicTopPanelSectionsFieldGroupFieldsList extends cdktn.ComplexList {
    internalValue?: CasesLayoutContentBasicTopPanelSectionsFieldGroupFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesLayoutContentBasicTopPanelSectionsFieldGroupFieldsOutputReference;
}
export interface CasesLayoutContentBasicTopPanelSectionsFieldGroup {
    /**
    * An ordered list of fields to display in this group. The order determines the sequence in which fields appear in the agent interface. Each field is referenced by its unique field ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#fields CasesLayout#fields}
    */
    readonly fields?: CasesLayoutContentBasicTopPanelSectionsFieldGroupFields[] | cdktn.IResolvable;
    /**
    * A descriptive name for the field group. Helps organize related fields together in the layout interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#name CasesLayout#name}
    */
    readonly name?: string;
}
export declare function casesLayoutContentBasicTopPanelSectionsFieldGroupToTerraform(struct?: CasesLayoutContentBasicTopPanelSectionsFieldGroup | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicTopPanelSectionsFieldGroupToHclTerraform(struct?: CasesLayoutContentBasicTopPanelSectionsFieldGroup | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicTopPanelSectionsFieldGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesLayoutContentBasicTopPanelSectionsFieldGroup | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasicTopPanelSectionsFieldGroup | cdktn.IResolvable | undefined);
    private _fields;
    get fields(): CasesLayoutContentBasicTopPanelSectionsFieldGroupFieldsList;
    putFields(value: CasesLayoutContentBasicTopPanelSectionsFieldGroupFields[] | cdktn.IResolvable): void;
    resetFields(): void;
    get fieldsInput(): cdktn.IResolvable | CasesLayoutContentBasicTopPanelSectionsFieldGroupFields[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface CasesLayoutContentBasicTopPanelSections {
    /**
    * Consists of a group of fields and associated properties.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#field_group CasesLayout#field_group}
    */
    readonly fieldGroup?: CasesLayoutContentBasicTopPanelSectionsFieldGroup;
}
export declare function casesLayoutContentBasicTopPanelSectionsToTerraform(struct?: CasesLayoutContentBasicTopPanelSections | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicTopPanelSectionsToHclTerraform(struct?: CasesLayoutContentBasicTopPanelSections | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicTopPanelSectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesLayoutContentBasicTopPanelSections | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasicTopPanelSections | cdktn.IResolvable | undefined);
    private _fieldGroup;
    get fieldGroup(): CasesLayoutContentBasicTopPanelSectionsFieldGroupOutputReference;
    putFieldGroup(value: CasesLayoutContentBasicTopPanelSectionsFieldGroup): void;
    resetFieldGroup(): void;
    get fieldGroupInput(): cdktn.IResolvable | CasesLayoutContentBasicTopPanelSectionsFieldGroup | undefined;
}
export declare class CasesLayoutContentBasicTopPanelSectionsList extends cdktn.ComplexList {
    internalValue?: CasesLayoutContentBasicTopPanelSections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesLayoutContentBasicTopPanelSectionsOutputReference;
}
export interface CasesLayoutContentBasicTopPanel {
    /**
    * Defines the sections within a panel or tab. Contains field groups that organize related fields together.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#sections CasesLayout#sections}
    */
    readonly sections?: CasesLayoutContentBasicTopPanelSections[] | cdktn.IResolvable;
}
export declare function casesLayoutContentBasicTopPanelToTerraform(struct?: CasesLayoutContentBasicTopPanel | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicTopPanelToHclTerraform(struct?: CasesLayoutContentBasicTopPanel | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicTopPanelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesLayoutContentBasicTopPanel | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasicTopPanel | cdktn.IResolvable | undefined);
    private _sections;
    get sections(): CasesLayoutContentBasicTopPanelSectionsList;
    putSections(value: CasesLayoutContentBasicTopPanelSections[] | cdktn.IResolvable): void;
    resetSections(): void;
    get sectionsInput(): cdktn.IResolvable | CasesLayoutContentBasicTopPanelSections[] | undefined;
}
export interface CasesLayoutContentBasic {
    /**
    * Sections within a panel or tab of the page layout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#more_info CasesLayout#more_info}
    */
    readonly moreInfo?: CasesLayoutContentBasicMoreInfo;
    /**
    * Sections within a panel or tab of the page layout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#top_panel CasesLayout#top_panel}
    */
    readonly topPanel?: CasesLayoutContentBasicTopPanel;
}
export declare function casesLayoutContentBasicToTerraform(struct?: CasesLayoutContentBasic | cdktn.IResolvable): any;
export declare function casesLayoutContentBasicToHclTerraform(struct?: CasesLayoutContentBasic | cdktn.IResolvable): any;
export declare class CasesLayoutContentBasicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesLayoutContentBasic | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContentBasic | cdktn.IResolvable | undefined);
    private _moreInfo;
    get moreInfo(): CasesLayoutContentBasicMoreInfoOutputReference;
    putMoreInfo(value: CasesLayoutContentBasicMoreInfo): void;
    resetMoreInfo(): void;
    get moreInfoInput(): cdktn.IResolvable | CasesLayoutContentBasicMoreInfo | undefined;
    private _topPanel;
    get topPanel(): CasesLayoutContentBasicTopPanelOutputReference;
    putTopPanel(value: CasesLayoutContentBasicTopPanel): void;
    resetTopPanel(): void;
    get topPanelInput(): cdktn.IResolvable | CasesLayoutContentBasicTopPanel | undefined;
}
export interface CasesLayoutContent {
    /**
    * Defines the field layout for the agent's case interface. Configures which fields appear in the top panel (immediately visible) and More Info tab (expandable section) of the case view, allowing customization of the agent experience.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#basic CasesLayout#basic}
    */
    readonly basic?: CasesLayoutContentBasic;
}
export declare function casesLayoutContentToTerraform(struct?: CasesLayoutContent | cdktn.IResolvable): any;
export declare function casesLayoutContentToHclTerraform(struct?: CasesLayoutContent | cdktn.IResolvable): any;
export declare class CasesLayoutContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesLayoutContent | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutContent | cdktn.IResolvable | undefined);
    private _basic;
    get basic(): CasesLayoutContentBasicOutputReference;
    putBasic(value: CasesLayoutContentBasic): void;
    resetBasic(): void;
    get basicInput(): cdktn.IResolvable | CasesLayoutContentBasic | undefined;
}
export interface CasesLayoutTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#key CasesLayout#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#value CasesLayout#value}
    */
    readonly value?: string;
}
export declare function casesLayoutTagsToTerraform(struct?: CasesLayoutTags | cdktn.IResolvable): any;
export declare function casesLayoutTagsToHclTerraform(struct?: CasesLayoutTags | cdktn.IResolvable): any;
export declare class CasesLayoutTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesLayoutTags | cdktn.IResolvable | undefined;
    set internalValue(value: CasesLayoutTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CasesLayoutTagsList extends cdktn.ComplexList {
    internalValue?: CasesLayoutTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesLayoutTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout awscc_cases_layout}
*/
export declare class CasesLayout extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cases_layout";
    /**
    * Generates CDKTN code for importing a CasesLayout resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CasesLayout to import
    * @param importFromId The id of the existing CasesLayout that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CasesLayout to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cases_layout awscc_cases_layout} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CasesLayoutConfig
    */
    constructor(scope: Construct, id: string, config: CasesLayoutConfig);
    private _content;
    get content(): CasesLayoutContentOutputReference;
    putContent(value: CasesLayoutContent): void;
    get contentInput(): cdktn.IResolvable | CasesLayoutContent | undefined;
    get createdTime(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    resetDomainId(): void;
    get domainIdInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): string;
    get layoutArn(): string;
    get layoutId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): CasesLayoutTagsList;
    putTags(value: CasesLayoutTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CasesLayoutTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
