/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAppconfigExtensionAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_extension_association#id DataAwsccAppconfigExtensionAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAppconfigExtensionAssociationTags {
}
export declare function dataAwsccAppconfigExtensionAssociationTagsToTerraform(struct?: DataAwsccAppconfigExtensionAssociationTags): any;
export declare function dataAwsccAppconfigExtensionAssociationTagsToHclTerraform(struct?: DataAwsccAppconfigExtensionAssociationTags): any;
export declare class DataAwsccAppconfigExtensionAssociationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigExtensionAssociationTags | undefined;
    set internalValue(value: DataAwsccAppconfigExtensionAssociationTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAppconfigExtensionAssociationTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigExtensionAssociationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_extension_association awscc_appconfig_extension_association}
*/
export declare class DataAwsccAppconfigExtensionAssociation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_appconfig_extension_association";
    /**
    * Generates CDKTN code for importing a DataAwsccAppconfigExtensionAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAppconfigExtensionAssociation to import
    * @param importFromId The id of the existing DataAwsccAppconfigExtensionAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_extension_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAppconfigExtensionAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_extension_association awscc_appconfig_extension_association} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAppconfigExtensionAssociationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAppconfigExtensionAssociationConfig);
    get arn(): string;
    get extensionArn(): string;
    get extensionAssociationId(): string;
    get extensionIdentifier(): string;
    get extensionVersionNumber(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _parameters;
    get parameters(): cdktn.StringMap;
    get resourceArn(): string;
    get resourceIdentifier(): string;
    private _tags;
    get tags(): DataAwsccAppconfigExtensionAssociationTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
