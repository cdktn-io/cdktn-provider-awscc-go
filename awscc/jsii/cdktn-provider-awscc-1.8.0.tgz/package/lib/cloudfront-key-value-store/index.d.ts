/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontKeyValueStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * A comment to describe the Key Value Store. Omitting ``Comment`` from the template during updates will clear the existing comment (set to empty string). To preserve an existing comment, you must explicitly include it in the template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#comment CloudfrontKeyValueStore#comment}
    */
    readonly comment?: string;
    /**
    * The import source for the key value store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#import_source CloudfrontKeyValueStore#import_source}
    */
    readonly importSource?: CloudfrontKeyValueStoreImportSource;
    /**
    * The name of the key value store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#name CloudfrontKeyValueStore#name}
    */
    readonly name: string;
    /**
    * A complex type that contains zero or more ``Tag`` elements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#tags CloudfrontKeyValueStore#tags}
    */
    readonly tags?: CloudfrontKeyValueStoreTags[] | cdktn.IResolvable;
}
export interface CloudfrontKeyValueStoreImportSource {
    /**
    * The Amazon Resource Name (ARN) of the import source for the key value store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#source_arn CloudfrontKeyValueStore#source_arn}
    */
    readonly sourceArn?: string;
    /**
    * The source type of the import source for the key value store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#source_type CloudfrontKeyValueStore#source_type}
    */
    readonly sourceType?: string;
}
export declare function cloudfrontKeyValueStoreImportSourceToTerraform(struct?: CloudfrontKeyValueStoreImportSource | cdktn.IResolvable): any;
export declare function cloudfrontKeyValueStoreImportSourceToHclTerraform(struct?: CloudfrontKeyValueStoreImportSource | cdktn.IResolvable): any;
export declare class CloudfrontKeyValueStoreImportSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontKeyValueStoreImportSource | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontKeyValueStoreImportSource | cdktn.IResolvable | undefined);
    private _sourceArn?;
    get sourceArn(): string;
    set sourceArn(value: string);
    resetSourceArn(): void;
    get sourceArnInput(): string | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    resetSourceType(): void;
    get sourceTypeInput(): string | undefined;
}
export interface CloudfrontKeyValueStoreTags {
    /**
    * A string that contains ``Tag`` key.
    *  The string length should be between 1 and 128 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#key CloudfrontKeyValueStore#key}
    */
    readonly key?: string;
    /**
    * A string that contains an optional ``Tag`` value.
    *  The string length should be between 0 and 256 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#value CloudfrontKeyValueStore#value}
    */
    readonly value?: string;
}
export declare function cloudfrontKeyValueStoreTagsToTerraform(struct?: CloudfrontKeyValueStoreTags | cdktn.IResolvable): any;
export declare function cloudfrontKeyValueStoreTagsToHclTerraform(struct?: CloudfrontKeyValueStoreTags | cdktn.IResolvable): any;
export declare class CloudfrontKeyValueStoreTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontKeyValueStoreTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontKeyValueStoreTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontKeyValueStoreTagsList extends cdktn.ComplexList {
    internalValue?: CloudfrontKeyValueStoreTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontKeyValueStoreTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store awscc_cloudfront_key_value_store}
*/
export declare class CloudfrontKeyValueStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_key_value_store";
    /**
    * Generates CDKTN code for importing a CloudfrontKeyValueStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontKeyValueStore to import
    * @param importFromId The id of the existing CloudfrontKeyValueStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontKeyValueStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/cloudfront_key_value_store awscc_cloudfront_key_value_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontKeyValueStoreConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontKeyValueStoreConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get id(): string;
    private _importSource;
    get importSource(): CloudfrontKeyValueStoreImportSourceOutputReference;
    putImportSource(value: CloudfrontKeyValueStoreImportSource): void;
    resetImportSource(): void;
    get importSourceInput(): cdktn.IResolvable | CloudfrontKeyValueStoreImportSource | undefined;
    get keyValueStoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): CloudfrontKeyValueStoreTagsList;
    putTags(value: CloudfrontKeyValueStoreTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudfrontKeyValueStoreTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
