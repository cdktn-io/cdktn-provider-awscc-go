/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentregistryRegistryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Configuration for the registry's record approval workflow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#approval_configuration AgentregistryRegistry#approval_configuration}
    */
    readonly approvalConfiguration?: AgentregistryRegistryApprovalConfiguration;
    /**
    * The type of authorizer that controls how consumers access the registry's search and MCP invoke operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#authorizer_type AgentregistryRegistry#authorizer_type}
    */
    readonly authorizerType?: string;
    /**
    * Specifies whether auto-detection is requested for the registry. Must be specified together with AutoDetectionScope. Setting this to true is necessary but not sufficient for auto-detection to become active; the preconditions of the configured scope must also be met. To turn auto-detection off, explicitly set this to false - removing AutoDetectionEnabled and AutoDetectionScope from the template is a no-op and leaves the existing auto-detection settings unchanged. A registry cannot be deleted while auto-detection is enabled: set this to false and update the stack before deleting the registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#auto_detection_enabled AgentregistryRegistry#auto_detection_enabled}
    */
    readonly autoDetectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * The source from which resources are detected. ORGANIZATION sources resources from all member accounts of an AWS Organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#auto_detection_scope AgentregistryRegistry#auto_detection_scope}
    */
    readonly autoDetectionScope?: string;
    /**
    * Configuration that defines a typed metadata schema for a registry. A default schema and per-record-type schema overrides are both optional. Schema evolution is additive only: you can add fields and enum values, but you cannot remove fields, change types, or remove enum values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#custom_metadata_schema_configuration AgentregistryRegistry#custom_metadata_schema_configuration}
    */
    readonly customMetadataSchemaConfiguration?: AgentregistryRegistryCustomMetadataSchemaConfiguration;
    /**
    * The description of the registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#description AgentregistryRegistry#description}
    */
    readonly description?: string;
    /**
    * Discovery configuration for the registry. Controls how consumers are authorized to search the registry and invoke its MCP endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#discovery_configuration AgentregistryRegistry#discovery_configuration}
    */
    readonly discoveryConfiguration?: AgentregistryRegistryDiscoveryConfiguration;
    /**
    * The server-side encryption configuration for a registry. Specifies a customer managed key used to encrypt the registry's content. When omitted, the registry's content is encrypted with an AWS owned key. You cannot change the encryption configuration after registry creation. Specifying a different KMS key, adding this property to an existing registry, or removing it replaces the registry: CloudFormation creates a new registry with a new Amazon Resource Name (ARN) and then deletes the original, including all registry records it contains. Registry records that are not managed by the stack are not re-created in the new registry, and if any remain in the original registry its deletion fails and it is left behind.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#encryption_configuration AgentregistryRegistry#encryption_configuration}
    */
    readonly encryptionConfiguration?: AgentregistryRegistryEncryptionConfiguration;
    /**
    * The name of the registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#name AgentregistryRegistry#name}
    */
    readonly name: string;
    /**
    * Tags to assign to the registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#tags AgentregistryRegistry#tags}
    */
    readonly tags?: AgentregistryRegistryTags[] | cdktn.IResolvable;
}
export interface AgentregistryRegistryApprovalConfiguration {
    /**
    * The rules that determine which registry records are automatically approved on submission. When omitted or empty, submitted records require manual review.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#auto_approval_rules AgentregistryRegistry#auto_approval_rules}
    */
    readonly autoApprovalRules?: string[];
}
export declare function agentregistryRegistryApprovalConfigurationToTerraform(struct?: AgentregistryRegistryApprovalConfiguration | cdktn.IResolvable): any;
export declare function agentregistryRegistryApprovalConfigurationToHclTerraform(struct?: AgentregistryRegistryApprovalConfiguration | cdktn.IResolvable): any;
export declare class AgentregistryRegistryApprovalConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryApprovalConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryApprovalConfiguration | cdktn.IResolvable | undefined);
    private _autoApprovalRules?;
    get autoApprovalRules(): string[];
    set autoApprovalRules(value: string[]);
    resetAutoApprovalRules(): void;
    get autoApprovalRulesInput(): string[] | undefined;
}
export interface AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides {
    /**
    * The record type that this schema override applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#record_type AgentregistryRegistry#record_type}
    */
    readonly recordType?: string;
    /**
    * The JSON Schema for the specified record type. Must follow the same structural rules as the default schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#schema AgentregistryRegistry#schema}
    */
    readonly schema?: string;
}
export declare function agentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesToTerraform(struct?: AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides | cdktn.IResolvable): any;
export declare function agentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesToHclTerraform(struct?: AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides | cdktn.IResolvable): any;
export declare class AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides | cdktn.IResolvable | undefined);
    private _recordType?;
    get recordType(): string;
    set recordType(value: string);
    resetRecordType(): void;
    get recordTypeInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export declare class AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesList extends cdktn.ComplexList {
    internalValue?: AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesOutputReference;
}
export interface AgentregistryRegistryCustomMetadataSchemaConfiguration {
    /**
    * The default JSON Schema that applies to record types without a specific override. Supported property types are string, string with an enum constraint, string with a uri format, and boolean.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#default_schema AgentregistryRegistry#default_schema}
    */
    readonly defaultSchema?: string;
    /**
    * A list of per-record-type schema overrides. When a record's type matches an override, that override's schema is used instead of the default schema for validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#record_type_schema_overrides AgentregistryRegistry#record_type_schema_overrides}
    */
    readonly recordTypeSchemaOverrides?: AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides[] | cdktn.IResolvable;
}
export declare function agentregistryRegistryCustomMetadataSchemaConfigurationToTerraform(struct?: AgentregistryRegistryCustomMetadataSchemaConfiguration | cdktn.IResolvable): any;
export declare function agentregistryRegistryCustomMetadataSchemaConfigurationToHclTerraform(struct?: AgentregistryRegistryCustomMetadataSchemaConfiguration | cdktn.IResolvable): any;
export declare class AgentregistryRegistryCustomMetadataSchemaConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryCustomMetadataSchemaConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryCustomMetadataSchemaConfiguration | cdktn.IResolvable | undefined);
    private _defaultSchema?;
    get defaultSchema(): string;
    set defaultSchema(value: string);
    resetDefaultSchema(): void;
    get defaultSchemaInput(): string | undefined;
    private _recordTypeSchemaOverrides;
    get recordTypeSchemaOverrides(): AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverridesList;
    putRecordTypeSchemaOverrides(value: AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides[] | cdktn.IResolvable): void;
    resetRecordTypeSchemaOverrides(): void;
    get recordTypeSchemaOverridesInput(): cdktn.IResolvable | AgentregistryRegistryCustomMetadataSchemaConfigurationRecordTypeSchemaOverrides[] | undefined;
}
export interface AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#match_value_string AgentregistryRegistry#match_value_string}
    */
    readonly matchValueString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#match_value_string_list AgentregistryRegistry#match_value_string_list}
    */
    readonly matchValueStringList?: string[];
}
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueToHclTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare class AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined);
    private _matchValueString?;
    get matchValueString(): string;
    set matchValueString(value: string);
    resetMatchValueString(): void;
    get matchValueStringInput(): string | undefined;
    private _matchValueStringList?;
    get matchValueStringList(): string[];
    set matchValueStringList(value: string[]);
    resetMatchValueStringList(): void;
    get matchValueStringListInput(): string[] | undefined;
}
export interface AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#claim_match_operator AgentregistryRegistry#claim_match_operator}
    */
    readonly claimMatchOperator?: string;
    /**
    * The expected value used to match a claim. Exactly one member is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#claim_match_value AgentregistryRegistry#claim_match_value}
    */
    readonly claimMatchValue?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue;
}
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueToHclTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare class AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | cdktn.IResolvable | undefined);
    private _claimMatchOperator?;
    get claimMatchOperator(): string;
    set claimMatchOperator(value: string);
    resetClaimMatchOperator(): void;
    get claimMatchOperatorInput(): string | undefined;
    private _claimMatchValue;
    get claimMatchValue(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValueOutputReference;
    putClaimMatchValue(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue): void;
    resetClaimMatchValue(): void;
    get claimMatchValueInput(): cdktn.IResolvable | AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueClaimMatchValue | undefined;
}
export interface AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims {
    /**
    * The value and match operator used to authorize a claim during JWT validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#authorizing_claim_match_value AgentregistryRegistry#authorizing_claim_match_value}
    */
    readonly authorizingClaimMatchValue?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#inbound_token_claim_name AgentregistryRegistry#inbound_token_claim_name}
    */
    readonly inboundTokenClaimName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#inbound_token_claim_value_type AgentregistryRegistry#inbound_token_claim_value_type}
    */
    readonly inboundTokenClaimValueType?: string;
}
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsToHclTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable): any;
export declare class AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims | cdktn.IResolvable | undefined);
    private _authorizingClaimMatchValue;
    get authorizingClaimMatchValue(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValueOutputReference;
    putAuthorizingClaimMatchValue(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue): void;
    resetAuthorizingClaimMatchValue(): void;
    get authorizingClaimMatchValueInput(): cdktn.IResolvable | AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsAuthorizingClaimMatchValue | undefined;
    private _inboundTokenClaimName?;
    get inboundTokenClaimName(): string;
    set inboundTokenClaimName(value: string);
    resetInboundTokenClaimName(): void;
    get inboundTokenClaimNameInput(): string | undefined;
    private _inboundTokenClaimValueType?;
    get inboundTokenClaimValueType(): string;
    set inboundTokenClaimValueType(value: string);
    resetInboundTokenClaimValueType(): void;
    get inboundTokenClaimValueTypeInput(): string | undefined;
}
export declare class AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList extends cdktn.ComplexList {
    internalValue?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsOutputReference;
}
export interface AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer {
    /**
    * The audience values accepted during JWT validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#allowed_audience AgentregistryRegistry#allowed_audience}
    */
    readonly allowedAudience?: string[];
    /**
    * The client identifiers accepted during JWT validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#allowed_clients AgentregistryRegistry#allowed_clients}
    */
    readonly allowedClients?: string[];
    /**
    * The scopes accepted during JWT validation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#allowed_scopes AgentregistryRegistry#allowed_scopes}
    */
    readonly allowedScopes?: string[];
    /**
    * Additional custom claim validations applied to the inbound JWT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#custom_claims AgentregistryRegistry#custom_claims}
    */
    readonly customClaims?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable;
    /**
    * The OpenID Connect discovery URL used to retrieve the identity provider's metadata and signing keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#discovery_url AgentregistryRegistry#discovery_url}
    */
    readonly discoveryUrl?: string;
}
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerToTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerToHclTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare class AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined);
    private _allowedAudience?;
    get allowedAudience(): string[];
    set allowedAudience(value: string[]);
    resetAllowedAudience(): void;
    get allowedAudienceInput(): string[] | undefined;
    private _allowedClients?;
    get allowedClients(): string[];
    set allowedClients(value: string[]);
    resetAllowedClients(): void;
    get allowedClientsInput(): string[] | undefined;
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
    private _customClaims;
    get customClaims(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaimsList;
    putCustomClaims(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | cdktn.IResolvable): void;
    resetCustomClaims(): void;
    get customClaimsInput(): cdktn.IResolvable | AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerCustomClaims[] | undefined;
    private _discoveryUrl?;
    get discoveryUrl(): string;
    set discoveryUrl(value: string);
    resetDiscoveryUrl(): void;
    get discoveryUrlInput(): string | undefined;
}
export interface AgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration {
    /**
    * Configuration for a custom JWT authorizer that validates inbound bearer tokens against an OpenID Connect identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#custom_jwt_authorizer AgentregistryRegistry#custom_jwt_authorizer}
    */
    readonly customJwtAuthorizer?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer;
}
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationToTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration | cdktn.IResolvable): any;
export declare function agentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationToHclTerraform(struct?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration | cdktn.IResolvable): any;
export declare class AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration | cdktn.IResolvable | undefined);
    private _customJwtAuthorizer;
    get customJwtAuthorizer(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizerOutputReference;
    putCustomJwtAuthorizer(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer): void;
    resetCustomJwtAuthorizer(): void;
    get customJwtAuthorizerInput(): cdktn.IResolvable | AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationCustomJwtAuthorizer | undefined;
}
export interface AgentregistryRegistryDiscoveryConfiguration {
    /**
    * The authorizer configuration for the registry. This is a union - specify exactly one member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#authorizer_configuration AgentregistryRegistry#authorizer_configuration}
    */
    readonly authorizerConfiguration?: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration;
}
export declare function agentregistryRegistryDiscoveryConfigurationToTerraform(struct?: AgentregistryRegistryDiscoveryConfiguration | cdktn.IResolvable): any;
export declare function agentregistryRegistryDiscoveryConfigurationToHclTerraform(struct?: AgentregistryRegistryDiscoveryConfiguration | cdktn.IResolvable): any;
export declare class AgentregistryRegistryDiscoveryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryDiscoveryConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryDiscoveryConfiguration | cdktn.IResolvable | undefined);
    private _authorizerConfiguration;
    get authorizerConfiguration(): AgentregistryRegistryDiscoveryConfigurationAuthorizerConfigurationOutputReference;
    putAuthorizerConfiguration(value: AgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | AgentregistryRegistryDiscoveryConfigurationAuthorizerConfiguration | undefined;
}
export interface AgentregistryRegistryEncryptionConfiguration {
    /**
    * The Amazon Resource Name (ARN) of the customer-managed AWS KMS key used to encrypt the registry's content. The key must be a symmetric encryption key in the same AWS account and Region as the registry. Multi-Region keys are not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#kms_key_arn AgentregistryRegistry#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
}
export declare function agentregistryRegistryEncryptionConfigurationToTerraform(struct?: AgentregistryRegistryEncryptionConfiguration | cdktn.IResolvable): any;
export declare function agentregistryRegistryEncryptionConfigurationToHclTerraform(struct?: AgentregistryRegistryEncryptionConfiguration | cdktn.IResolvable): any;
export declare class AgentregistryRegistryEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
}
export interface AgentregistryRegistryTags {
    /**
    * The key of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#key AgentregistryRegistry#key}
    */
    readonly key?: string;
    /**
    * The value of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#value AgentregistryRegistry#value}
    */
    readonly value?: string;
}
export declare function agentregistryRegistryTagsToTerraform(struct?: AgentregistryRegistryTags | cdktn.IResolvable): any;
export declare function agentregistryRegistryTagsToHclTerraform(struct?: AgentregistryRegistryTags | cdktn.IResolvable): any;
export declare class AgentregistryRegistryTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentregistryRegistryTags | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AgentregistryRegistryTagsList extends cdktn.ComplexList {
    internalValue?: AgentregistryRegistryTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentregistryRegistryTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry awscc_agentregistry_registry}
*/
export declare class AgentregistryRegistry extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_agentregistry_registry";
    /**
    * Generates CDKTN code for importing a AgentregistryRegistry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentregistryRegistry to import
    * @param importFromId The id of the existing AgentregistryRegistry that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentregistryRegistry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry awscc_agentregistry_registry} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentregistryRegistryConfig
    */
    constructor(scope: Construct, id: string, config: AgentregistryRegistryConfig);
    private _approvalConfiguration;
    get approvalConfiguration(): AgentregistryRegistryApprovalConfigurationOutputReference;
    putApprovalConfiguration(value: AgentregistryRegistryApprovalConfiguration): void;
    resetApprovalConfiguration(): void;
    get approvalConfigurationInput(): cdktn.IResolvable | AgentregistryRegistryApprovalConfiguration | undefined;
    private _authorizerType?;
    get authorizerType(): string;
    set authorizerType(value: string);
    resetAuthorizerType(): void;
    get authorizerTypeInput(): string | undefined;
    private _autoDetectionEnabled?;
    get autoDetectionEnabled(): boolean | cdktn.IResolvable;
    set autoDetectionEnabled(value: boolean | cdktn.IResolvable);
    resetAutoDetectionEnabled(): void;
    get autoDetectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _autoDetectionScope?;
    get autoDetectionScope(): string;
    set autoDetectionScope(value: string);
    resetAutoDetectionScope(): void;
    get autoDetectionScopeInput(): string | undefined;
    get autoDetectionStatus(): string;
    get createdAt(): string;
    private _customMetadataSchemaConfiguration;
    get customMetadataSchemaConfiguration(): AgentregistryRegistryCustomMetadataSchemaConfigurationOutputReference;
    putCustomMetadataSchemaConfiguration(value: AgentregistryRegistryCustomMetadataSchemaConfiguration): void;
    resetCustomMetadataSchemaConfiguration(): void;
    get customMetadataSchemaConfigurationInput(): cdktn.IResolvable | AgentregistryRegistryCustomMetadataSchemaConfiguration | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _discoveryConfiguration;
    get discoveryConfiguration(): AgentregistryRegistryDiscoveryConfigurationOutputReference;
    putDiscoveryConfiguration(value: AgentregistryRegistryDiscoveryConfiguration): void;
    resetDiscoveryConfiguration(): void;
    get discoveryConfigurationInput(): cdktn.IResolvable | AgentregistryRegistryDiscoveryConfiguration | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AgentregistryRegistryEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: AgentregistryRegistryEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AgentregistryRegistryEncryptionConfiguration | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get registryArn(): string;
    get registryId(): string;
    get status(): string;
    private _tags;
    get tags(): AgentregistryRegistryTagsList;
    putTags(value: AgentregistryRegistryTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AgentregistryRegistryTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
