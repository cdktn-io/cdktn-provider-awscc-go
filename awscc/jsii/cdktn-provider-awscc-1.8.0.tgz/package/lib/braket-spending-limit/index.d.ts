/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BraketSpendingLimitConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the quantum device to apply the spending limit to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#device_arn BraketSpendingLimit#device_arn}
    */
    readonly deviceArn: string;
    /**
    * The maximum amount that can be spent on the specified device, in USD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#spending_limit BraketSpendingLimit#spending_limit}
    */
    readonly spendingLimit: string;
    /**
    * The tags to apply to the spending limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#tags BraketSpendingLimit#tags}
    */
    readonly tags?: BraketSpendingLimitTags[] | cdktn.IResolvable;
    /**
    * Defines a time range for spending limits, specifying when the limit is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#time_period BraketSpendingLimit#time_period}
    */
    readonly timePeriod?: BraketSpendingLimitTimePeriod;
}
export interface BraketSpendingLimitTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#key BraketSpendingLimit#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#value BraketSpendingLimit#value}
    */
    readonly value?: string;
}
export declare function braketSpendingLimitTagsToTerraform(struct?: BraketSpendingLimitTags | cdktn.IResolvable): any;
export declare function braketSpendingLimitTagsToHclTerraform(struct?: BraketSpendingLimitTags | cdktn.IResolvable): any;
export declare class BraketSpendingLimitTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BraketSpendingLimitTags | cdktn.IResolvable | undefined;
    set internalValue(value: BraketSpendingLimitTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BraketSpendingLimitTagsList extends cdktn.ComplexList {
    internalValue?: BraketSpendingLimitTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BraketSpendingLimitTagsOutputReference;
}
export interface BraketSpendingLimitTimePeriod {
    /**
    * The end date and time for the spending limit period, in ISO 8601 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#end_at BraketSpendingLimit#end_at}
    */
    readonly endAt?: string;
    /**
    * The start date and time for the spending limit period, in ISO 8601 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#start_at BraketSpendingLimit#start_at}
    */
    readonly startAt?: string;
}
export declare function braketSpendingLimitTimePeriodToTerraform(struct?: BraketSpendingLimitTimePeriod | cdktn.IResolvable): any;
export declare function braketSpendingLimitTimePeriodToHclTerraform(struct?: BraketSpendingLimitTimePeriod | cdktn.IResolvable): any;
export declare class BraketSpendingLimitTimePeriodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BraketSpendingLimitTimePeriod | cdktn.IResolvable | undefined;
    set internalValue(value: BraketSpendingLimitTimePeriod | cdktn.IResolvable | undefined);
    private _endAt?;
    get endAt(): string;
    set endAt(value: string);
    resetEndAt(): void;
    get endAtInput(): string | undefined;
    private _startAt?;
    get startAt(): string;
    set startAt(value: string);
    resetStartAt(): void;
    get startAtInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit awscc_braket_spending_limit}
*/
export declare class BraketSpendingLimit extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_braket_spending_limit";
    /**
    * Generates CDKTN code for importing a BraketSpendingLimit resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BraketSpendingLimit to import
    * @param importFromId The id of the existing BraketSpendingLimit that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BraketSpendingLimit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/braket_spending_limit awscc_braket_spending_limit} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BraketSpendingLimitConfig
    */
    constructor(scope: Construct, id: string, config: BraketSpendingLimitConfig);
    get createdAt(): string;
    private _deviceArn?;
    get deviceArn(): string;
    set deviceArn(value: string);
    get deviceArnInput(): string | undefined;
    get id(): string;
    get queuedSpend(): string;
    private _spendingLimit?;
    get spendingLimit(): string;
    set spendingLimit(value: string);
    get spendingLimitInput(): string | undefined;
    get spendingLimitArn(): string;
    private _tags;
    get tags(): BraketSpendingLimitTagsList;
    putTags(value: BraketSpendingLimitTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BraketSpendingLimitTags[] | undefined;
    private _timePeriod;
    get timePeriod(): BraketSpendingLimitTimePeriodOutputReference;
    putTimePeriod(value: BraketSpendingLimitTimePeriod): void;
    resetTimePeriod(): void;
    get timePeriodInput(): cdktn.IResolvable | BraketSpendingLimitTimePeriod | undefined;
    get totalSpend(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
