/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncResolverConfig extends cdktn.TerraformMetaArguments {
    /**
    * The APSYlong GraphQL API to which you want to attach this resolver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#api_id AppsyncResolver#api_id}
    */
    readonly apiId: string;
    /**
    * The caching configuration for the resolver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#caching_config AppsyncResolver#caching_config}
    */
    readonly cachingConfig?: AppsyncResolverCachingConfig;
    /**
    * The ``resolver`` code that contains the request and response functions. When code is used, the ``runtime`` is required. The runtime value must be ``APPSYNC_JS``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#code AppsyncResolver#code}
    */
    readonly code?: string;
    /**
    * The Amazon S3 endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#code_s3_location AppsyncResolver#code_s3_location}
    */
    readonly codeS3Location?: string;
    /**
    * The resolver data source name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#data_source_name AppsyncResolver#data_source_name}
    */
    readonly dataSourceName?: string;
    /**
    * The GraphQL field on a type that invokes the resolver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#field_name AppsyncResolver#field_name}
    */
    readonly fieldName: string;
    /**
    * The resolver type.
    *   +  *UNIT*: A UNIT resolver type. A UNIT resolver is the default resolver type. You can use a UNIT resolver to run a GraphQL query against a single data source.
    *   +  *PIPELINE*: A PIPELINE resolver type. You can use a PIPELINE resolver to invoke a series of ``Function`` objects in a serial manner. You can use a pipeline resolver to run a GraphQL query against multiple data sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#kind AppsyncResolver#kind}
    */
    readonly kind?: string;
    /**
    * The maximum number of resolver request inputs that will be sent to a single LAMlong function in a ``BatchInvoke`` operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#max_batch_size AppsyncResolver#max_batch_size}
    */
    readonly maxBatchSize?: number;
    /**
    * Enables or disables enhanced resolver metrics for specified resolvers. Note that ``MetricsConfig`` won't be used unless the ``resolverLevelMetricsBehavior`` value is set to ``PER_RESOLVER_METRICS``. If the ``resolverLevelMetricsBehavior`` is set to ``FULL_REQUEST_RESOLVER_METRICS`` instead, ``MetricsConfig`` will be ignored. However, you can still set its value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#metrics_config AppsyncResolver#metrics_config}
    */
    readonly metricsConfig?: string;
    /**
    * Functions linked with the pipeline resolver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#pipeline_config AppsyncResolver#pipeline_config}
    */
    readonly pipelineConfig?: AppsyncResolverPipelineConfig;
    /**
    * The request mapping template.
    *  Request mapping templates are optional when using a Lambda data source. For all other data sources, a request mapping template is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#request_mapping_template AppsyncResolver#request_mapping_template}
    */
    readonly requestMappingTemplate?: string;
    /**
    * The location of a request mapping template in an S3 bucket. Use this if you want to provision with a template file in S3 rather than embedding it in your CFNshort template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#request_mapping_template_s3_location AppsyncResolver#request_mapping_template_s3_location}
    */
    readonly requestMappingTemplateS3Location?: string;
    /**
    * The response mapping template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#response_mapping_template AppsyncResolver#response_mapping_template}
    */
    readonly responseMappingTemplate?: string;
    /**
    * The location of a response mapping template in an S3 bucket. Use this if you want to provision with a template file in S3 rather than embedding it in your CFNshort template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#response_mapping_template_s3_location AppsyncResolver#response_mapping_template_s3_location}
    */
    readonly responseMappingTemplateS3Location?: string;
    /**
    * Describes a runtime used by an APSYlong resolver or APSYlong function. Specifies the name and version of the runtime to use. Note that if a runtime is specified, code must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#runtime AppsyncResolver#runtime}
    */
    readonly runtime?: AppsyncResolverRuntime;
    /**
    * The ``SyncConfig`` for a resolver attached to a versioned data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#sync_config AppsyncResolver#sync_config}
    */
    readonly syncConfig?: AppsyncResolverSyncConfig;
    /**
    * The GraphQL type that invokes this resolver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#type_name AppsyncResolver#type_name}
    */
    readonly typeName: string;
}
export interface AppsyncResolverCachingConfig {
    /**
    * The caching keys for a resolver that has caching activated.
    *  Valid values are entries from the ``$context.arguments``, ``$context.source``, and ``$context.identity`` maps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#caching_keys AppsyncResolver#caching_keys}
    */
    readonly cachingKeys?: string[];
    /**
    * The TTL in seconds for a resolver that has caching activated.
    *  Valid values are 1?3,600 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#ttl AppsyncResolver#ttl}
    */
    readonly ttl?: number;
}
export declare function appsyncResolverCachingConfigToTerraform(struct?: AppsyncResolverCachingConfig | cdktn.IResolvable): any;
export declare function appsyncResolverCachingConfigToHclTerraform(struct?: AppsyncResolverCachingConfig | cdktn.IResolvable): any;
export declare class AppsyncResolverCachingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncResolverCachingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncResolverCachingConfig | cdktn.IResolvable | undefined);
    private _cachingKeys?;
    get cachingKeys(): string[];
    set cachingKeys(value: string[]);
    resetCachingKeys(): void;
    get cachingKeysInput(): string[] | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
}
export interface AppsyncResolverPipelineConfig {
    /**
    * A list of ``Function`` objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#functions AppsyncResolver#functions}
    */
    readonly functions?: string[];
}
export declare function appsyncResolverPipelineConfigToTerraform(struct?: AppsyncResolverPipelineConfig | cdktn.IResolvable): any;
export declare function appsyncResolverPipelineConfigToHclTerraform(struct?: AppsyncResolverPipelineConfig | cdktn.IResolvable): any;
export declare class AppsyncResolverPipelineConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncResolverPipelineConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncResolverPipelineConfig | cdktn.IResolvable | undefined);
    private _functions?;
    get functions(): string[];
    set functions(value: string[]);
    resetFunctions(): void;
    get functionsInput(): string[] | undefined;
}
export interface AppsyncResolverRuntime {
    /**
    * The ``name`` of the runtime to use. Currently, the only allowed value is ``APPSYNC_JS``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#name AppsyncResolver#name}
    */
    readonly name?: string;
    /**
    * The ``version`` of the runtime to use. Currently, the only allowed version is ``1.0.0``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#runtime_version AppsyncResolver#runtime_version}
    */
    readonly runtimeVersion?: string;
}
export declare function appsyncResolverRuntimeToTerraform(struct?: AppsyncResolverRuntime | cdktn.IResolvable): any;
export declare function appsyncResolverRuntimeToHclTerraform(struct?: AppsyncResolverRuntime | cdktn.IResolvable): any;
export declare class AppsyncResolverRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncResolverRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncResolverRuntime | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _runtimeVersion?;
    get runtimeVersion(): string;
    set runtimeVersion(value: string);
    resetRuntimeVersion(): void;
    get runtimeVersionInput(): string | undefined;
}
export interface AppsyncResolverSyncConfigLambdaConflictHandlerConfig {
    /**
    * The Amazon Resource Name (ARN) for the Lambda function to use as the Conflict Handler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#lambda_conflict_handler_arn AppsyncResolver#lambda_conflict_handler_arn}
    */
    readonly lambdaConflictHandlerArn?: string;
}
export declare function appsyncResolverSyncConfigLambdaConflictHandlerConfigToTerraform(struct?: AppsyncResolverSyncConfigLambdaConflictHandlerConfig | cdktn.IResolvable): any;
export declare function appsyncResolverSyncConfigLambdaConflictHandlerConfigToHclTerraform(struct?: AppsyncResolverSyncConfigLambdaConflictHandlerConfig | cdktn.IResolvable): any;
export declare class AppsyncResolverSyncConfigLambdaConflictHandlerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncResolverSyncConfigLambdaConflictHandlerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncResolverSyncConfigLambdaConflictHandlerConfig | cdktn.IResolvable | undefined);
    private _lambdaConflictHandlerArn?;
    get lambdaConflictHandlerArn(): string;
    set lambdaConflictHandlerArn(value: string);
    resetLambdaConflictHandlerArn(): void;
    get lambdaConflictHandlerArnInput(): string | undefined;
}
export interface AppsyncResolverSyncConfig {
    /**
    * The Conflict Detection strategy to use.
    *   +  *VERSION*: Detect conflicts based on object versions for this resolver.
    *   +  *NONE*: Do not detect conflicts when invoking this resolver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#conflict_detection AppsyncResolver#conflict_detection}
    */
    readonly conflictDetection?: string;
    /**
    * The Conflict Resolution strategy to perform in the event of a conflict.
    *   +  *OPTIMISTIC_CONCURRENCY*: Resolve conflicts by rejecting mutations when versions don't match the latest version at the server.
    *   +  *AUTOMERGE*: Resolve conflicts with the Automerge conflict resolution strategy.
    *   +  *LAMBDA*: Resolve conflicts with an LAMlong function supplied in the ``LambdaConflictHandlerConfig``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#conflict_handler AppsyncResolver#conflict_handler}
    */
    readonly conflictHandler?: string;
    /**
    * The ``LambdaConflictHandlerConfig`` when configuring ``LAMBDA`` as the Conflict Handler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#lambda_conflict_handler_config AppsyncResolver#lambda_conflict_handler_config}
    */
    readonly lambdaConflictHandlerConfig?: AppsyncResolverSyncConfigLambdaConflictHandlerConfig;
}
export declare function appsyncResolverSyncConfigToTerraform(struct?: AppsyncResolverSyncConfig | cdktn.IResolvable): any;
export declare function appsyncResolverSyncConfigToHclTerraform(struct?: AppsyncResolverSyncConfig | cdktn.IResolvable): any;
export declare class AppsyncResolverSyncConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncResolverSyncConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncResolverSyncConfig | cdktn.IResolvable | undefined);
    private _conflictDetection?;
    get conflictDetection(): string;
    set conflictDetection(value: string);
    resetConflictDetection(): void;
    get conflictDetectionInput(): string | undefined;
    private _conflictHandler?;
    get conflictHandler(): string;
    set conflictHandler(value: string);
    resetConflictHandler(): void;
    get conflictHandlerInput(): string | undefined;
    private _lambdaConflictHandlerConfig;
    get lambdaConflictHandlerConfig(): AppsyncResolverSyncConfigLambdaConflictHandlerConfigOutputReference;
    putLambdaConflictHandlerConfig(value: AppsyncResolverSyncConfigLambdaConflictHandlerConfig): void;
    resetLambdaConflictHandlerConfig(): void;
    get lambdaConflictHandlerConfigInput(): cdktn.IResolvable | AppsyncResolverSyncConfigLambdaConflictHandlerConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver awscc_appsync_resolver}
*/
export declare class AppsyncResolver extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_resolver";
    /**
    * Generates CDKTN code for importing a AppsyncResolver resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncResolver to import
    * @param importFromId The id of the existing AppsyncResolver that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncResolver to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/appsync_resolver awscc_appsync_resolver} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncResolverConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncResolverConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _cachingConfig;
    get cachingConfig(): AppsyncResolverCachingConfigOutputReference;
    putCachingConfig(value: AppsyncResolverCachingConfig): void;
    resetCachingConfig(): void;
    get cachingConfigInput(): cdktn.IResolvable | AppsyncResolverCachingConfig | undefined;
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _codeS3Location?;
    get codeS3Location(): string;
    set codeS3Location(value: string);
    resetCodeS3Location(): void;
    get codeS3LocationInput(): string | undefined;
    private _dataSourceName?;
    get dataSourceName(): string;
    set dataSourceName(value: string);
    resetDataSourceName(): void;
    get dataSourceNameInput(): string | undefined;
    private _fieldName?;
    get fieldName(): string;
    set fieldName(value: string);
    get fieldNameInput(): string | undefined;
    get id(): string;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _maxBatchSize?;
    get maxBatchSize(): number;
    set maxBatchSize(value: number);
    resetMaxBatchSize(): void;
    get maxBatchSizeInput(): number | undefined;
    private _metricsConfig?;
    get metricsConfig(): string;
    set metricsConfig(value: string);
    resetMetricsConfig(): void;
    get metricsConfigInput(): string | undefined;
    private _pipelineConfig;
    get pipelineConfig(): AppsyncResolverPipelineConfigOutputReference;
    putPipelineConfig(value: AppsyncResolverPipelineConfig): void;
    resetPipelineConfig(): void;
    get pipelineConfigInput(): cdktn.IResolvable | AppsyncResolverPipelineConfig | undefined;
    private _requestMappingTemplate?;
    get requestMappingTemplate(): string;
    set requestMappingTemplate(value: string);
    resetRequestMappingTemplate(): void;
    get requestMappingTemplateInput(): string | undefined;
    private _requestMappingTemplateS3Location?;
    get requestMappingTemplateS3Location(): string;
    set requestMappingTemplateS3Location(value: string);
    resetRequestMappingTemplateS3Location(): void;
    get requestMappingTemplateS3LocationInput(): string | undefined;
    get resolverArn(): string;
    private _responseMappingTemplate?;
    get responseMappingTemplate(): string;
    set responseMappingTemplate(value: string);
    resetResponseMappingTemplate(): void;
    get responseMappingTemplateInput(): string | undefined;
    private _responseMappingTemplateS3Location?;
    get responseMappingTemplateS3Location(): string;
    set responseMappingTemplateS3Location(value: string);
    resetResponseMappingTemplateS3Location(): void;
    get responseMappingTemplateS3LocationInput(): string | undefined;
    private _runtime;
    get runtime(): AppsyncResolverRuntimeOutputReference;
    putRuntime(value: AppsyncResolverRuntime): void;
    resetRuntime(): void;
    get runtimeInput(): cdktn.IResolvable | AppsyncResolverRuntime | undefined;
    private _syncConfig;
    get syncConfig(): AppsyncResolverSyncConfigOutputReference;
    putSyncConfig(value: AppsyncResolverSyncConfig): void;
    resetSyncConfig(): void;
    get syncConfigInput(): cdktn.IResolvable | AppsyncResolverSyncConfig | undefined;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    get typeNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
