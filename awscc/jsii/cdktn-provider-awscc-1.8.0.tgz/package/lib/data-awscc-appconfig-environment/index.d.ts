/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAppconfigEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_environment#id DataAwsccAppconfigEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAppconfigEnvironmentMonitors {
}
export declare function dataAwsccAppconfigEnvironmentMonitorsToTerraform(struct?: DataAwsccAppconfigEnvironmentMonitors): any;
export declare function dataAwsccAppconfigEnvironmentMonitorsToHclTerraform(struct?: DataAwsccAppconfigEnvironmentMonitors): any;
export declare class DataAwsccAppconfigEnvironmentMonitorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigEnvironmentMonitors | undefined;
    set internalValue(value: DataAwsccAppconfigEnvironmentMonitors | undefined);
    get alarmArn(): string;
    get alarmRoleArn(): string;
}
export declare class DataAwsccAppconfigEnvironmentMonitorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigEnvironmentMonitorsOutputReference;
}
export interface DataAwsccAppconfigEnvironmentTags {
}
export declare function dataAwsccAppconfigEnvironmentTagsToTerraform(struct?: DataAwsccAppconfigEnvironmentTags): any;
export declare function dataAwsccAppconfigEnvironmentTagsToHclTerraform(struct?: DataAwsccAppconfigEnvironmentTags): any;
export declare class DataAwsccAppconfigEnvironmentTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAppconfigEnvironmentTags | undefined;
    set internalValue(value: DataAwsccAppconfigEnvironmentTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAppconfigEnvironmentTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAppconfigEnvironmentTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_environment awscc_appconfig_environment}
*/
export declare class DataAwsccAppconfigEnvironment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_appconfig_environment";
    /**
    * Generates CDKTN code for importing a DataAwsccAppconfigEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAppconfigEnvironment to import
    * @param importFromId The id of the existing DataAwsccAppconfigEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAppconfigEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/data-sources/appconfig_environment awscc_appconfig_environment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAppconfigEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAppconfigEnvironmentConfig);
    get applicationId(): string;
    get deletionProtectionCheck(): string;
    get description(): string;
    get environmentId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _monitors;
    get monitors(): DataAwsccAppconfigEnvironmentMonitorsList;
    get name(): string;
    private _tags;
    get tags(): DataAwsccAppconfigEnvironmentTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
