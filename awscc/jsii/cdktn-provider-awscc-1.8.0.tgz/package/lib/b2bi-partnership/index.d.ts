/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface B2BiPartnershipConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#capabilities B2BiPartnership#capabilities}
    */
    readonly capabilities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#capability_options B2BiPartnership#capability_options}
    */
    readonly capabilityOptions?: B2BiPartnershipCapabilityOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#email B2BiPartnership#email}
    */
    readonly email: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#name B2BiPartnership#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#phone B2BiPartnership#phone}
    */
    readonly phone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#profile_id B2BiPartnership#profile_id}
    */
    readonly profileId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#tags B2BiPartnership#tags}
    */
    readonly tags?: B2BiPartnershipTags[] | cdktn.IResolvable;
}
export interface B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#functional_acknowledgment B2BiPartnership#functional_acknowledgment}
    */
    readonly functionalAcknowledgment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#technical_acknowledgment B2BiPartnership#technical_acknowledgment}
    */
    readonly technicalAcknowledgment?: string;
}
export declare function b2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptionsToTerraform(struct?: B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptions | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptionsToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptions | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptions | cdktn.IResolvable | undefined);
    private _functionalAcknowledgment?;
    get functionalAcknowledgment(): string;
    set functionalAcknowledgment(value: string);
    resetFunctionalAcknowledgment(): void;
    get functionalAcknowledgmentInput(): string | undefined;
    private _technicalAcknowledgment?;
    get technicalAcknowledgment(): string;
    set technicalAcknowledgment(value: string);
    resetTechnicalAcknowledgment(): void;
    get technicalAcknowledgmentInput(): string | undefined;
}
export interface B2BiPartnershipCapabilityOptionsInboundEdiX12 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#acknowledgment_options B2BiPartnership#acknowledgment_options}
    */
    readonly acknowledgmentOptions?: B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptions;
}
export declare function b2BiPartnershipCapabilityOptionsInboundEdiX12ToTerraform(struct?: B2BiPartnershipCapabilityOptionsInboundEdiX12 | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsInboundEdiX12ToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsInboundEdiX12 | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsInboundEdiX12OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsInboundEdiX12 | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsInboundEdiX12 | cdktn.IResolvable | undefined);
    private _acknowledgmentOptions;
    get acknowledgmentOptions(): B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptionsOutputReference;
    putAcknowledgmentOptions(value: B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptions): void;
    resetAcknowledgmentOptions(): void;
    get acknowledgmentOptionsInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsInboundEdiX12AcknowledgmentOptions | undefined;
}
export interface B2BiPartnershipCapabilityOptionsInboundEdi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#x12 B2BiPartnership#x12}
    */
    readonly x12?: B2BiPartnershipCapabilityOptionsInboundEdiX12;
}
export declare function b2BiPartnershipCapabilityOptionsInboundEdiToTerraform(struct?: B2BiPartnershipCapabilityOptionsInboundEdi | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsInboundEdiToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsInboundEdi | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsInboundEdiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsInboundEdi | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsInboundEdi | cdktn.IResolvable | undefined);
    private _x12;
    get x12(): B2BiPartnershipCapabilityOptionsInboundEdiX12OutputReference;
    putX12(value: B2BiPartnershipCapabilityOptionsInboundEdiX12): void;
    resetX12(): void;
    get x12Input(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsInboundEdiX12 | undefined;
}
export interface B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#starting_functional_group_control_number B2BiPartnership#starting_functional_group_control_number}
    */
    readonly startingFunctionalGroupControlNumber?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#starting_interchange_control_number B2BiPartnership#starting_interchange_control_number}
    */
    readonly startingInterchangeControlNumber?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#starting_transaction_set_control_number B2BiPartnership#starting_transaction_set_control_number}
    */
    readonly startingTransactionSetControlNumber?: number;
}
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbersToTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbers | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbersToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbers | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbers | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbers | cdktn.IResolvable | undefined);
    private _startingFunctionalGroupControlNumber?;
    get startingFunctionalGroupControlNumber(): number;
    set startingFunctionalGroupControlNumber(value: number);
    resetStartingFunctionalGroupControlNumber(): void;
    get startingFunctionalGroupControlNumberInput(): number | undefined;
    private _startingInterchangeControlNumber?;
    get startingInterchangeControlNumber(): number;
    set startingInterchangeControlNumber(value: number);
    resetStartingInterchangeControlNumber(): void;
    get startingInterchangeControlNumberInput(): number | undefined;
    private _startingTransactionSetControlNumber?;
    get startingTransactionSetControlNumber(): number;
    set startingTransactionSetControlNumber(value: number);
    resetStartingTransactionSetControlNumber(): void;
    get startingTransactionSetControlNumberInput(): number | undefined;
}
export interface B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimiters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#component_separator B2BiPartnership#component_separator}
    */
    readonly componentSeparator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#data_element_separator B2BiPartnership#data_element_separator}
    */
    readonly dataElementSeparator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#segment_terminator B2BiPartnership#segment_terminator}
    */
    readonly segmentTerminator?: string;
}
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimitersToTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimiters | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimitersToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimiters | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimitersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimiters | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimiters | cdktn.IResolvable | undefined);
    private _componentSeparator?;
    get componentSeparator(): string;
    set componentSeparator(value: string);
    resetComponentSeparator(): void;
    get componentSeparatorInput(): string | undefined;
    private _dataElementSeparator?;
    get dataElementSeparator(): string;
    set dataElementSeparator(value: string);
    resetDataElementSeparator(): void;
    get dataElementSeparatorInput(): string | undefined;
    private _segmentTerminator?;
    get segmentTerminator(): string;
    set segmentTerminator(value: string);
    resetSegmentTerminator(): void;
    get segmentTerminatorInput(): string | undefined;
}
export interface B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#application_receiver_code B2BiPartnership#application_receiver_code}
    */
    readonly applicationReceiverCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#application_sender_code B2BiPartnership#application_sender_code}
    */
    readonly applicationSenderCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#responsible_agency_code B2BiPartnership#responsible_agency_code}
    */
    readonly responsibleAgencyCode?: string;
}
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeadersToTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeaders | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeadersToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeaders | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeaders | cdktn.IResolvable | undefined);
    private _applicationReceiverCode?;
    get applicationReceiverCode(): string;
    set applicationReceiverCode(value: string);
    resetApplicationReceiverCode(): void;
    get applicationReceiverCodeInput(): string | undefined;
    private _applicationSenderCode?;
    get applicationSenderCode(): string;
    set applicationSenderCode(value: string);
    resetApplicationSenderCode(): void;
    get applicationSenderCodeInput(): string | undefined;
    private _responsibleAgencyCode?;
    get responsibleAgencyCode(): string;
    set responsibleAgencyCode(value: string);
    resetResponsibleAgencyCode(): void;
    get responsibleAgencyCodeInput(): string | undefined;
}
export interface B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#acknowledgment_requested_code B2BiPartnership#acknowledgment_requested_code}
    */
    readonly acknowledgmentRequestedCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#receiver_id B2BiPartnership#receiver_id}
    */
    readonly receiverId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#receiver_id_qualifier B2BiPartnership#receiver_id_qualifier}
    */
    readonly receiverIdQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#repetition_separator B2BiPartnership#repetition_separator}
    */
    readonly repetitionSeparator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#sender_id B2BiPartnership#sender_id}
    */
    readonly senderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#sender_id_qualifier B2BiPartnership#sender_id_qualifier}
    */
    readonly senderIdQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#usage_indicator_code B2BiPartnership#usage_indicator_code}
    */
    readonly usageIndicatorCode?: string;
}
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeadersToTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeaders | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeadersToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeaders | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeaders | cdktn.IResolvable | undefined);
    private _acknowledgmentRequestedCode?;
    get acknowledgmentRequestedCode(): string;
    set acknowledgmentRequestedCode(value: string);
    resetAcknowledgmentRequestedCode(): void;
    get acknowledgmentRequestedCodeInput(): string | undefined;
    private _receiverId?;
    get receiverId(): string;
    set receiverId(value: string);
    resetReceiverId(): void;
    get receiverIdInput(): string | undefined;
    private _receiverIdQualifier?;
    get receiverIdQualifier(): string;
    set receiverIdQualifier(value: string);
    resetReceiverIdQualifier(): void;
    get receiverIdQualifierInput(): string | undefined;
    private _repetitionSeparator?;
    get repetitionSeparator(): string;
    set repetitionSeparator(value: string);
    resetRepetitionSeparator(): void;
    get repetitionSeparatorInput(): string | undefined;
    private _senderId?;
    get senderId(): string;
    set senderId(value: string);
    resetSenderId(): void;
    get senderIdInput(): string | undefined;
    private _senderIdQualifier?;
    get senderIdQualifier(): string;
    set senderIdQualifier(value: string);
    resetSenderIdQualifier(): void;
    get senderIdQualifierInput(): string | undefined;
    private _usageIndicatorCode?;
    get usageIndicatorCode(): string;
    set usageIndicatorCode(value: string);
    resetUsageIndicatorCode(): void;
    get usageIndicatorCodeInput(): string | undefined;
}
export interface B2BiPartnershipCapabilityOptionsOutboundEdiX12Common {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#control_numbers B2BiPartnership#control_numbers}
    */
    readonly controlNumbers?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbers;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#delimiters B2BiPartnership#delimiters}
    */
    readonly delimiters?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimiters;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#functional_group_headers B2BiPartnership#functional_group_headers}
    */
    readonly functionalGroupHeaders?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeaders;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#gs_05_time_format B2BiPartnership#gs_05_time_format}
    */
    readonly gs05TimeFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#interchange_control_headers B2BiPartnership#interchange_control_headers}
    */
    readonly interchangeControlHeaders?: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeaders;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#validate_edi B2BiPartnership#validate_edi}
    */
    readonly validateEdi?: boolean | cdktn.IResolvable;
}
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonToTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12Common | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12CommonToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12Common | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsOutboundEdiX12Common | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12Common | cdktn.IResolvable | undefined);
    private _controlNumbers;
    get controlNumbers(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbersOutputReference;
    putControlNumbers(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbers): void;
    resetControlNumbers(): void;
    get controlNumbersInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonControlNumbers | undefined;
    private _delimiters;
    get delimiters(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimitersOutputReference;
    putDelimiters(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimiters): void;
    resetDelimiters(): void;
    get delimitersInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonDelimiters | undefined;
    private _functionalGroupHeaders;
    get functionalGroupHeaders(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeadersOutputReference;
    putFunctionalGroupHeaders(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeaders): void;
    resetFunctionalGroupHeaders(): void;
    get functionalGroupHeadersInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonFunctionalGroupHeaders | undefined;
    private _gs05TimeFormat?;
    get gs05TimeFormat(): string;
    set gs05TimeFormat(value: string);
    resetGs05TimeFormat(): void;
    get gs05TimeFormatInput(): string | undefined;
    private _interchangeControlHeaders;
    get interchangeControlHeaders(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeadersOutputReference;
    putInterchangeControlHeaders(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeaders): void;
    resetInterchangeControlHeaders(): void;
    get interchangeControlHeadersInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonInterchangeControlHeaders | undefined;
    private _validateEdi?;
    get validateEdi(): boolean | cdktn.IResolvable;
    set validateEdi(value: boolean | cdktn.IResolvable);
    resetValidateEdi(): void;
    get validateEdiInput(): boolean | cdktn.IResolvable | undefined;
}
export interface B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#line_length B2BiPartnership#line_length}
    */
    readonly lineLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#line_terminator B2BiPartnership#line_terminator}
    */
    readonly lineTerminator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#wrap_by B2BiPartnership#wrap_by}
    */
    readonly wrapBy?: string;
}
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptionsToTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptions | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptionsToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptions | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptions | cdktn.IResolvable | undefined);
    private _lineLength?;
    get lineLength(): number;
    set lineLength(value: number);
    resetLineLength(): void;
    get lineLengthInput(): number | undefined;
    private _lineTerminator?;
    get lineTerminator(): string;
    set lineTerminator(value: string);
    resetLineTerminator(): void;
    get lineTerminatorInput(): string | undefined;
    private _wrapBy?;
    get wrapBy(): string;
    set wrapBy(value: string);
    resetWrapBy(): void;
    get wrapByInput(): string | undefined;
}
export interface B2BiPartnershipCapabilityOptionsOutboundEdiX12 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#common B2BiPartnership#common}
    */
    readonly common?: B2BiPartnershipCapabilityOptionsOutboundEdiX12Common;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#wrap_options B2BiPartnership#wrap_options}
    */
    readonly wrapOptions?: B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptions;
}
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12ToTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12 | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiX12ToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdiX12 | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutboundEdiX12OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsOutboundEdiX12 | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12 | cdktn.IResolvable | undefined);
    private _common;
    get common(): B2BiPartnershipCapabilityOptionsOutboundEdiX12CommonOutputReference;
    putCommon(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12Common): void;
    resetCommon(): void;
    get commonInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsOutboundEdiX12Common | undefined;
    private _wrapOptions;
    get wrapOptions(): B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptionsOutputReference;
    putWrapOptions(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptions): void;
    resetWrapOptions(): void;
    get wrapOptionsInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsOutboundEdiX12WrapOptions | undefined;
}
export interface B2BiPartnershipCapabilityOptionsOutboundEdi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#x12 B2BiPartnership#x12}
    */
    readonly x12?: B2BiPartnershipCapabilityOptionsOutboundEdiX12;
}
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiToTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdi | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsOutboundEdiToHclTerraform(struct?: B2BiPartnershipCapabilityOptionsOutboundEdi | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutboundEdiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptionsOutboundEdi | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptionsOutboundEdi | cdktn.IResolvable | undefined);
    private _x12;
    get x12(): B2BiPartnershipCapabilityOptionsOutboundEdiX12OutputReference;
    putX12(value: B2BiPartnershipCapabilityOptionsOutboundEdiX12): void;
    resetX12(): void;
    get x12Input(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsOutboundEdiX12 | undefined;
}
export interface B2BiPartnershipCapabilityOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#inbound_edi B2BiPartnership#inbound_edi}
    */
    readonly inboundEdi?: B2BiPartnershipCapabilityOptionsInboundEdi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#outbound_edi B2BiPartnership#outbound_edi}
    */
    readonly outboundEdi?: B2BiPartnershipCapabilityOptionsOutboundEdi;
}
export declare function b2BiPartnershipCapabilityOptionsToTerraform(struct?: B2BiPartnershipCapabilityOptions | cdktn.IResolvable): any;
export declare function b2BiPartnershipCapabilityOptionsToHclTerraform(struct?: B2BiPartnershipCapabilityOptions | cdktn.IResolvable): any;
export declare class B2BiPartnershipCapabilityOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): B2BiPartnershipCapabilityOptions | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipCapabilityOptions | cdktn.IResolvable | undefined);
    private _inboundEdi;
    get inboundEdi(): B2BiPartnershipCapabilityOptionsInboundEdiOutputReference;
    putInboundEdi(value: B2BiPartnershipCapabilityOptionsInboundEdi): void;
    resetInboundEdi(): void;
    get inboundEdiInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsInboundEdi | undefined;
    private _outboundEdi;
    get outboundEdi(): B2BiPartnershipCapabilityOptionsOutboundEdiOutputReference;
    putOutboundEdi(value: B2BiPartnershipCapabilityOptionsOutboundEdi): void;
    resetOutboundEdi(): void;
    get outboundEdiInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptionsOutboundEdi | undefined;
}
export interface B2BiPartnershipTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#key B2BiPartnership#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#value B2BiPartnership#value}
    */
    readonly value?: string;
}
export declare function b2BiPartnershipTagsToTerraform(struct?: B2BiPartnershipTags | cdktn.IResolvable): any;
export declare function b2BiPartnershipTagsToHclTerraform(struct?: B2BiPartnershipTags | cdktn.IResolvable): any;
export declare class B2BiPartnershipTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): B2BiPartnershipTags | cdktn.IResolvable | undefined;
    set internalValue(value: B2BiPartnershipTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class B2BiPartnershipTagsList extends cdktn.ComplexList {
    internalValue?: B2BiPartnershipTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): B2BiPartnershipTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership awscc_b2bi_partnership}
*/
export declare class B2BiPartnership extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_b2bi_partnership";
    /**
    * Generates CDKTN code for importing a B2BiPartnership resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the B2BiPartnership to import
    * @param importFromId The id of the existing B2BiPartnership that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the B2BiPartnership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/b2bi_partnership awscc_b2bi_partnership} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options B2BiPartnershipConfig
    */
    constructor(scope: Construct, id: string, config: B2BiPartnershipConfig);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    get capabilitiesInput(): string[] | undefined;
    private _capabilityOptions;
    get capabilityOptions(): B2BiPartnershipCapabilityOptionsOutputReference;
    putCapabilityOptions(value: B2BiPartnershipCapabilityOptions): void;
    resetCapabilityOptions(): void;
    get capabilityOptionsInput(): cdktn.IResolvable | B2BiPartnershipCapabilityOptions | undefined;
    get createdAt(): string;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    get id(): string;
    get modifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get partnershipArn(): string;
    get partnershipId(): string;
    private _phone?;
    get phone(): string;
    set phone(value: string);
    resetPhone(): void;
    get phoneInput(): string | undefined;
    private _profileId?;
    get profileId(): string;
    set profileId(value: string);
    get profileIdInput(): string | undefined;
    private _tags;
    get tags(): B2BiPartnershipTagsList;
    putTags(value: B2BiPartnershipTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | B2BiPartnershipTags[] | undefined;
    get tradingPartnerId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
