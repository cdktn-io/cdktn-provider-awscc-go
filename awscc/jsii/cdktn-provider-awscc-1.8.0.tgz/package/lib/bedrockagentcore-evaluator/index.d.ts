/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreEvaluatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the evaluator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#description BedrockagentcoreEvaluator#description}
    */
    readonly description?: string;
    /**
    * The configuration for the evaluator, including LLM-as-a-Judge, code-based, or derived settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#evaluator_config BedrockagentcoreEvaluator#evaluator_config}
    */
    readonly evaluatorConfig: BedrockagentcoreEvaluatorEvaluatorConfig;
    /**
    * The name of the evaluator. Must be unique within your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#evaluator_name BedrockagentcoreEvaluator#evaluator_name}
    */
    readonly evaluatorName: string;
    /**
    * The ARN of the KMS key used to encrypt evaluator data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#kms_key_arn BedrockagentcoreEvaluator#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * The evaluation level that determines the scope of evaluation. Required for all evaluator configuration types. For Derived evaluators it must match the level of the base evaluator identified by BaseEvaluatorId.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#level BedrockagentcoreEvaluator#level}
    */
    readonly level: string;
    /**
    * A list of tags to assign to the evaluator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#tags BedrockagentcoreEvaluator#tags}
    */
    readonly tags?: BedrockagentcoreEvaluatorTags[] | cdktn.IResolvable;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig {
    /**
    * The ARN of the Lambda function used for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#lambda_arn BedrockagentcoreEvaluator#lambda_arn}
    */
    readonly lambdaArn?: string;
    /**
    * The timeout in seconds for the Lambda function invocation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#lambda_timeout_in_seconds BedrockagentcoreEvaluator#lambda_timeout_in_seconds}
    */
    readonly lambdaTimeoutInSeconds?: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    resetLambdaArn(): void;
    get lambdaArnInput(): string | undefined;
    private _lambdaTimeoutInSeconds?;
    get lambdaTimeoutInSeconds(): number;
    set lambdaTimeoutInSeconds(value: number);
    resetLambdaTimeoutInSeconds(): void;
    get lambdaTimeoutInSecondsInput(): number | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigCodeBased {
    /**
    * The Lambda function configuration for code-based evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#lambda_config BedrockagentcoreEvaluator#lambda_config}
    */
    readonly lambdaConfig?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigCodeBasedToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigCodeBasedToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | cdktn.IResolvable | undefined);
    private _lambdaConfig;
    get lambdaConfig(): BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigOutputReference;
    putLambdaConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfig {
    /**
    * The maximum number of tokens to generate in the model response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#max_tokens BedrockagentcoreEvaluator#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * The sequences that make the model stop generating further tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#stop_sequences BedrockagentcoreEvaluator#stop_sequences}
    */
    readonly stopSequences?: string[];
    /**
    * The temperature value that controls randomness in the model's responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#temperature BedrockagentcoreEvaluator#temperature}
    */
    readonly temperature?: number;
    /**
    * The top-p sampling parameter that controls the diversity of the model's responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#top_p BedrockagentcoreEvaluator#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _stopSequences?;
    get stopSequences(): string[];
    set stopSequences(value: string[]);
    resetStopSequences(): void;
    get stopSequencesInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfig {
    /**
    * Additional model-specific request fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#additional_model_request_fields BedrockagentcoreEvaluator#additional_model_request_fields}
    */
    readonly additionalModelRequestFields?: string;
    /**
    * The inference configuration parameters that control model behavior during evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#inference_config BedrockagentcoreEvaluator#inference_config}
    */
    readonly inferenceConfig?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfig;
    /**
    * The identifier of the Amazon Bedrock model to use for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#model_id BedrockagentcoreEvaluator#model_id}
    */
    readonly modelId?: string;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable | undefined);
    private _additionalModelRequestFields?;
    get additionalModelRequestFields(): string;
    set additionalModelRequestFields(value: string);
    resetAdditionalModelRequestFields(): void;
    get additionalModelRequestFieldsInput(): string | undefined;
    private _inferenceConfig;
    get inferenceConfig(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfigOutputReference;
    putInferenceConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfig): void;
    resetInferenceConfig(): void;
    get inferenceConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigInferenceConfig | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoning {
    /**
    * The level of reasoning effort the model applies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#effort BedrockagentcoreEvaluator#effort}
    */
    readonly effort?: string;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoningToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoning | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoningToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoning | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoning | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoning | cdktn.IResolvable | undefined);
    private _effort?;
    get effort(): string;
    set effort(value: string);
    resetEffort(): void;
    get effortInput(): string | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfig {
    /**
    * The maximum number of output tokens to generate, including visible output and reasoning tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#max_output_tokens BedrockagentcoreEvaluator#max_output_tokens}
    */
    readonly maxOutputTokens?: number;
    /**
    * The identifier of the model to use for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#model_id BedrockagentcoreEvaluator#model_id}
    */
    readonly modelId?: string;
    /**
    * The reasoning configuration for reasoning models.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#reasoning BedrockagentcoreEvaluator#reasoning}
    */
    readonly reasoning?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoning;
    /**
    * The sampling temperature between 0 and 2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#temperature BedrockagentcoreEvaluator#temperature}
    */
    readonly temperature?: number;
    /**
    * The nucleus sampling probability mass between 0 and 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#top_p BedrockagentcoreEvaluator#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfig | cdktn.IResolvable | undefined);
    private _maxOutputTokens?;
    get maxOutputTokens(): number;
    set maxOutputTokens(value: number);
    resetMaxOutputTokens(): void;
    get maxOutputTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
    private _reasoning;
    get reasoning(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoningOutputReference;
    putReasoning(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoning): void;
    resetReasoning(): void;
    get reasoningInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigReasoning | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfig {
    /**
    * The configuration for using Amazon Bedrock models in evaluator assessments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#bedrock_evaluator_model_config BedrockagentcoreEvaluator#bedrock_evaluator_model_config}
    */
    readonly bedrockEvaluatorModelConfig?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfig;
    /**
    * The configuration for using OpenResponses-compatible models in evaluator assessments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#responses_evaluator_model_config BedrockagentcoreEvaluator#responses_evaluator_model_config}
    */
    readonly responsesEvaluatorModelConfig?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfig;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfig | cdktn.IResolvable | undefined);
    private _bedrockEvaluatorModelConfig;
    get bedrockEvaluatorModelConfig(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfigOutputReference;
    putBedrockEvaluatorModelConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfig): void;
    resetBedrockEvaluatorModelConfig(): void;
    get bedrockEvaluatorModelConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigBedrockEvaluatorModelConfig | undefined;
    private _responsesEvaluatorModelConfig;
    get responsesEvaluatorModelConfig(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfigOutputReference;
    putResponsesEvaluatorModelConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfig): void;
    resetResponsesEvaluatorModelConfig(): void;
    get responsesEvaluatorModelConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigResponsesEvaluatorModelConfig | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigDerived {
    /**
    * The identifier of the base evaluator whose logic to run (a Builtin.* or ThirdParty.* evaluator).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#base_evaluator_id BedrockagentcoreEvaluator#base_evaluator_id}
    */
    readonly baseEvaluatorId?: string;
    /**
    * The model configuration that specifies which foundation model to use for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#model_config BedrockagentcoreEvaluator#model_config}
    */
    readonly modelConfig?: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfig;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerived | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigDerivedToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigDerived | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigDerivedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigDerived | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigDerived | cdktn.IResolvable | undefined);
    private _baseEvaluatorId?;
    get baseEvaluatorId(): string;
    set baseEvaluatorId(value: string);
    resetBaseEvaluatorId(): void;
    get baseEvaluatorIdInput(): string | undefined;
    private _modelConfig;
    get modelConfig(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfigOutputReference;
    putModelConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfig): void;
    resetModelConfig(): void;
    get modelConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigDerivedModelConfig | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig {
    /**
    * The maximum number of tokens to generate in the model response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#max_tokens BedrockagentcoreEvaluator#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * The sequences that make the model stop generating further tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#stop_sequences BedrockagentcoreEvaluator#stop_sequences}
    */
    readonly stopSequences?: string[];
    /**
    * The temperature value that controls randomness in the model's responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#temperature BedrockagentcoreEvaluator#temperature}
    */
    readonly temperature?: number;
    /**
    * The top-p sampling parameter that controls the diversity of the model's responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#top_p BedrockagentcoreEvaluator#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _stopSequences?;
    get stopSequences(): string[];
    set stopSequences(value: string[]);
    resetStopSequences(): void;
    get stopSequencesInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig {
    /**
    * Additional model-specific request fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#additional_model_request_fields BedrockagentcoreEvaluator#additional_model_request_fields}
    */
    readonly additionalModelRequestFields?: string;
    /**
    * The inference configuration parameters that control model behavior during evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#inference_config BedrockagentcoreEvaluator#inference_config}
    */
    readonly inferenceConfig?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig;
    /**
    * The identifier of the Amazon Bedrock model to use for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#model_id BedrockagentcoreEvaluator#model_id}
    */
    readonly modelId?: string;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable | undefined);
    private _additionalModelRequestFields?;
    get additionalModelRequestFields(): string;
    set additionalModelRequestFields(value: string);
    resetAdditionalModelRequestFields(): void;
    get additionalModelRequestFieldsInput(): string | undefined;
    private _inferenceConfig;
    get inferenceConfig(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigOutputReference;
    putInferenceConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig): void;
    resetInferenceConfig(): void;
    get inferenceConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoning {
    /**
    * The level of reasoning effort the model applies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#effort BedrockagentcoreEvaluator#effort}
    */
    readonly effort?: string;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoningToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoning | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoningToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoning | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoning | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoning | cdktn.IResolvable | undefined);
    private _effort?;
    get effort(): string;
    set effort(value: string);
    resetEffort(): void;
    get effortInput(): string | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfig {
    /**
    * The maximum number of output tokens to generate, including visible output and reasoning tokens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#max_output_tokens BedrockagentcoreEvaluator#max_output_tokens}
    */
    readonly maxOutputTokens?: number;
    /**
    * The identifier of the model to use for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#model_id BedrockagentcoreEvaluator#model_id}
    */
    readonly modelId?: string;
    /**
    * The reasoning configuration for reasoning models.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#reasoning BedrockagentcoreEvaluator#reasoning}
    */
    readonly reasoning?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoning;
    /**
    * The sampling temperature between 0 and 2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#temperature BedrockagentcoreEvaluator#temperature}
    */
    readonly temperature?: number;
    /**
    * The nucleus sampling probability mass between 0 and 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#top_p BedrockagentcoreEvaluator#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfig | cdktn.IResolvable | undefined);
    private _maxOutputTokens?;
    get maxOutputTokens(): number;
    set maxOutputTokens(value: number);
    resetMaxOutputTokens(): void;
    get maxOutputTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
    private _reasoning;
    get reasoning(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoningOutputReference;
    putReasoning(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoning): void;
    resetReasoning(): void;
    get reasoningInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigReasoning | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig {
    /**
    * The configuration for using Amazon Bedrock models in evaluator assessments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#bedrock_evaluator_model_config BedrockagentcoreEvaluator#bedrock_evaluator_model_config}
    */
    readonly bedrockEvaluatorModelConfig?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig;
    /**
    * The configuration for using OpenResponses-compatible models in evaluator assessments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#responses_evaluator_model_config BedrockagentcoreEvaluator#responses_evaluator_model_config}
    */
    readonly responsesEvaluatorModelConfig?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfig;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | cdktn.IResolvable | undefined);
    private _bedrockEvaluatorModelConfig;
    get bedrockEvaluatorModelConfig(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigOutputReference;
    putBedrockEvaluatorModelConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig): void;
    resetBedrockEvaluatorModelConfig(): void;
    get bedrockEvaluatorModelConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | undefined;
    private _responsesEvaluatorModelConfig;
    get responsesEvaluatorModelConfig(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfigOutputReference;
    putResponsesEvaluatorModelConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfig): void;
    resetResponsesEvaluatorModelConfig(): void;
    get responsesEvaluatorModelConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigResponsesEvaluatorModelConfig | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical {
    /**
    * The description that explains what this categorical rating represents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#definition BedrockagentcoreEvaluator#definition}
    */
    readonly definition?: string;
    /**
    * The label of this categorical rating option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#label BedrockagentcoreEvaluator#label}
    */
    readonly label?: string;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    resetDefinition(): void;
    get definitionInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical {
    /**
    * The description that explains what this numerical rating represents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#definition BedrockagentcoreEvaluator#definition}
    */
    readonly definition?: string;
    /**
    * The label that describes this numerical rating option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#label BedrockagentcoreEvaluator#label}
    */
    readonly label?: string;
    /**
    * The numerical value for this rating scale option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#value BedrockagentcoreEvaluator#value}
    */
    readonly value?: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    resetDefinition(): void;
    get definitionInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#categorical BedrockagentcoreEvaluator#categorical}
    */
    readonly categorical?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#numerical BedrockagentcoreEvaluator#numerical}
    */
    readonly numerical?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | cdktn.IResolvable | undefined);
    private _categorical;
    get categorical(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalList;
    putCategorical(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical[] | cdktn.IResolvable): void;
    resetCategorical(): void;
    get categoricalInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical[] | undefined;
    private _numerical;
    get numerical(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalList;
    putNumerical(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical[] | cdktn.IResolvable): void;
    resetNumerical(): void;
    get numericalInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical[] | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge {
    /**
    * The evaluation instructions that guide the language model in assessing agent performance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#instructions BedrockagentcoreEvaluator#instructions}
    */
    readonly instructions?: string;
    /**
    * The model configuration that specifies which foundation model to use for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#model_config BedrockagentcoreEvaluator#model_config}
    */
    readonly modelConfig?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig;
    /**
    * The rating scale that defines how evaluators should score agent performance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#rating_scale BedrockagentcoreEvaluator#rating_scale}
    */
    readonly ratingScale?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | cdktn.IResolvable | undefined);
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    resetInstructions(): void;
    get instructionsInput(): string | undefined;
    private _modelConfig;
    get modelConfig(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigOutputReference;
    putModelConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig): void;
    resetModelConfig(): void;
    get modelConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | undefined;
    private _ratingScale;
    get ratingScale(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleOutputReference;
    putRatingScale(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale): void;
    resetRatingScale(): void;
    get ratingScaleInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | undefined;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfig {
    /**
    * The configuration for code-based evaluation using a Lambda function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#code_based BedrockagentcoreEvaluator#code_based}
    */
    readonly codeBased?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased;
    /**
    * The configuration for an evaluator derived from an existing base evaluator (a built-in or third-party evaluator), run on your own model. The base evaluator supplies the prompt and scoring logic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#derived BedrockagentcoreEvaluator#derived}
    */
    readonly derived?: BedrockagentcoreEvaluatorEvaluatorConfigDerived;
    /**
    * The configuration for LLM-as-a-Judge evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#llm_as_a_judge BedrockagentcoreEvaluator#llm_as_a_judge}
    */
    readonly llmAsAJudge?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfig | cdktn.IResolvable | undefined);
    private _codeBased;
    get codeBased(): BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedOutputReference;
    putCodeBased(value: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased): void;
    resetCodeBased(): void;
    get codeBasedInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | undefined;
    private _derived;
    get derived(): BedrockagentcoreEvaluatorEvaluatorConfigDerivedOutputReference;
    putDerived(value: BedrockagentcoreEvaluatorEvaluatorConfigDerived): void;
    resetDerived(): void;
    get derivedInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigDerived | undefined;
    private _llmAsAJudge;
    get llmAsAJudge(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeOutputReference;
    putLlmAsAJudge(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge): void;
    resetLlmAsAJudge(): void;
    get llmAsAJudgeInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | undefined;
}
export interface BedrockagentcoreEvaluatorTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#key BedrockagentcoreEvaluator#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#value BedrockagentcoreEvaluator#value}
    */
    readonly value?: string;
}
export declare function bedrockagentcoreEvaluatorTagsToTerraform(struct?: BedrockagentcoreEvaluatorTags | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorTagsToHclTerraform(struct?: BedrockagentcoreEvaluatorTags | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockagentcoreEvaluatorTagsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator awscc_bedrockagentcore_evaluator}
*/
export declare class BedrockagentcoreEvaluator extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_evaluator";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreEvaluator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreEvaluator to import
    * @param importFromId The id of the existing BedrockagentcoreEvaluator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreEvaluator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/bedrockagentcore_evaluator awscc_bedrockagentcore_evaluator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreEvaluatorConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreEvaluatorConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get evaluatorArn(): string;
    private _evaluatorConfig;
    get evaluatorConfig(): BedrockagentcoreEvaluatorEvaluatorConfigOutputReference;
    putEvaluatorConfig(value: BedrockagentcoreEvaluatorEvaluatorConfig): void;
    get evaluatorConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfig | undefined;
    get evaluatorId(): string;
    private _evaluatorName?;
    get evaluatorName(): string;
    set evaluatorName(value: string);
    get evaluatorNameInput(): string | undefined;
    get evaluatorType(): string;
    get id(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    get levelInput(): string | undefined;
    get providerName(): string;
    get status(): string;
    private _tags;
    get tags(): BedrockagentcoreEvaluatorTagsList;
    putTags(value: BedrockagentcoreEvaluatorTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
