/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeChannelFlowConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the app instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#app_instance_arn ChimeChannelFlow#app_instance_arn}
    */
    readonly appInstanceArn: string;
    /**
    * The name of the channel flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#name ChimeChannelFlow#name}
    */
    readonly name: string;
    /**
    * Information about the processor Lambda functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#processors ChimeChannelFlow#processors}
    */
    readonly processors: ChimeChannelFlowProcessors[] | cdktn.IResolvable;
    /**
    * The tags for the channel flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#tags ChimeChannelFlow#tags}
    */
    readonly tags?: ChimeChannelFlowTags[] | cdktn.IResolvable;
}
export interface ChimeChannelFlowProcessorsConfigurationLambda {
    /**
    * Controls how the Lambda function is invoked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#invocation_type ChimeChannelFlow#invocation_type}
    */
    readonly invocationType: string;
    /**
    * The ARN of the Lambda message processing function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#resource_arn ChimeChannelFlow#resource_arn}
    */
    readonly resourceArn: string;
}
export declare function chimeChannelFlowProcessorsConfigurationLambdaToTerraform(struct?: ChimeChannelFlowProcessorsConfigurationLambda | cdktn.IResolvable): any;
export declare function chimeChannelFlowProcessorsConfigurationLambdaToHclTerraform(struct?: ChimeChannelFlowProcessorsConfigurationLambda | cdktn.IResolvable): any;
export declare class ChimeChannelFlowProcessorsConfigurationLambdaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeChannelFlowProcessorsConfigurationLambda | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeChannelFlowProcessorsConfigurationLambda | cdktn.IResolvable | undefined);
    private _invocationType?;
    get invocationType(): string;
    set invocationType(value: string);
    get invocationTypeInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
}
export interface ChimeChannelFlowProcessorsConfiguration {
    /**
    * Stores metadata about a Lambda processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#lambda ChimeChannelFlow#lambda}
    */
    readonly lambda: ChimeChannelFlowProcessorsConfigurationLambda;
}
export declare function chimeChannelFlowProcessorsConfigurationToTerraform(struct?: ChimeChannelFlowProcessorsConfiguration | cdktn.IResolvable): any;
export declare function chimeChannelFlowProcessorsConfigurationToHclTerraform(struct?: ChimeChannelFlowProcessorsConfiguration | cdktn.IResolvable): any;
export declare class ChimeChannelFlowProcessorsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeChannelFlowProcessorsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeChannelFlowProcessorsConfiguration | cdktn.IResolvable | undefined);
    private _lambda;
    get lambda(): ChimeChannelFlowProcessorsConfigurationLambdaOutputReference;
    putLambda(value: ChimeChannelFlowProcessorsConfigurationLambda): void;
    get lambdaInput(): cdktn.IResolvable | ChimeChannelFlowProcessorsConfigurationLambda | undefined;
}
export interface ChimeChannelFlowProcessors {
    /**
    * A processor's metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#configuration ChimeChannelFlow#configuration}
    */
    readonly configuration: ChimeChannelFlowProcessorsConfiguration;
    /**
    * The sequence in which processors run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#execution_order ChimeChannelFlow#execution_order}
    */
    readonly executionOrder: number;
    /**
    * Determines whether to continue or stop processing when communication with a processor fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#fallback_action ChimeChannelFlow#fallback_action}
    */
    readonly fallbackAction: string;
    /**
    * The name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#name ChimeChannelFlow#name}
    */
    readonly name: string;
}
export declare function chimeChannelFlowProcessorsToTerraform(struct?: ChimeChannelFlowProcessors | cdktn.IResolvable): any;
export declare function chimeChannelFlowProcessorsToHclTerraform(struct?: ChimeChannelFlowProcessors | cdktn.IResolvable): any;
export declare class ChimeChannelFlowProcessorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeChannelFlowProcessors | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeChannelFlowProcessors | cdktn.IResolvable | undefined);
    private _configuration;
    get configuration(): ChimeChannelFlowProcessorsConfigurationOutputReference;
    putConfiguration(value: ChimeChannelFlowProcessorsConfiguration): void;
    get configurationInput(): cdktn.IResolvable | ChimeChannelFlowProcessorsConfiguration | undefined;
    private _executionOrder?;
    get executionOrder(): number;
    set executionOrder(value: number);
    get executionOrderInput(): number | undefined;
    private _fallbackAction?;
    get fallbackAction(): string;
    set fallbackAction(value: string);
    get fallbackActionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ChimeChannelFlowProcessorsList extends cdktn.ComplexList {
    internalValue?: ChimeChannelFlowProcessors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeChannelFlowProcessorsOutputReference;
}
export interface ChimeChannelFlowTags {
    /**
    * The key in a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#key ChimeChannelFlow#key}
    */
    readonly key?: string;
    /**
    * The value in a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#value ChimeChannelFlow#value}
    */
    readonly value?: string;
}
export declare function chimeChannelFlowTagsToTerraform(struct?: ChimeChannelFlowTags | cdktn.IResolvable): any;
export declare function chimeChannelFlowTagsToHclTerraform(struct?: ChimeChannelFlowTags | cdktn.IResolvable): any;
export declare class ChimeChannelFlowTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeChannelFlowTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeChannelFlowTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeChannelFlowTagsList extends cdktn.ComplexList {
    internalValue?: ChimeChannelFlowTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeChannelFlowTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow awscc_chime_channel_flow}
*/
export declare class ChimeChannelFlow extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_channel_flow";
    /**
    * Generates CDKTN code for importing a ChimeChannelFlow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeChannelFlow to import
    * @param importFromId The id of the existing ChimeChannelFlow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeChannelFlow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/chime_channel_flow awscc_chime_channel_flow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeChannelFlowConfig
    */
    constructor(scope: Construct, id: string, config: ChimeChannelFlowConfig);
    private _appInstanceArn?;
    get appInstanceArn(): string;
    set appInstanceArn(value: string);
    get appInstanceArnInput(): string | undefined;
    get appInstanceId(): string;
    get arn(): string;
    get channelFlowId(): string;
    get createdTimestamp(): string;
    get id(): string;
    get lastUpdatedTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _processors;
    get processors(): ChimeChannelFlowProcessorsList;
    putProcessors(value: ChimeChannelFlowProcessors[] | cdktn.IResolvable): void;
    get processorsInput(): cdktn.IResolvable | ChimeChannelFlowProcessors[] | undefined;
    private _tags;
    get tags(): ChimeChannelFlowTagsList;
    putTags(value: ChimeChannelFlowTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeChannelFlowTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
