/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BatchJobQueueConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#compute_environment_order BatchJobQueue#compute_environment_order}
    */
    readonly computeEnvironmentOrder?: BatchJobQueueComputeEnvironmentOrder[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#job_queue_name BatchJobQueue#job_queue_name}
    */
    readonly jobQueueName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#job_queue_type BatchJobQueue#job_queue_type}
    */
    readonly jobQueueType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#job_state_time_limit_actions BatchJobQueue#job_state_time_limit_actions}
    */
    readonly jobStateTimeLimitActions?: BatchJobQueueJobStateTimeLimitActions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#priority BatchJobQueue#priority}
    */
    readonly priority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#scheduling_policy_arn BatchJobQueue#scheduling_policy_arn}
    */
    readonly schedulingPolicyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#service_environment_order BatchJobQueue#service_environment_order}
    */
    readonly serviceEnvironmentOrder?: BatchJobQueueServiceEnvironmentOrder[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#state BatchJobQueue#state}
    */
    readonly state?: string;
    /**
    * A key-value pair to associate with a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#tags BatchJobQueue#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BatchJobQueueComputeEnvironmentOrder {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#compute_environment BatchJobQueue#compute_environment}
    */
    readonly computeEnvironment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#order BatchJobQueue#order}
    */
    readonly order?: number;
}
export declare function batchJobQueueComputeEnvironmentOrderToTerraform(struct?: BatchJobQueueComputeEnvironmentOrder | cdktn.IResolvable): any;
export declare function batchJobQueueComputeEnvironmentOrderToHclTerraform(struct?: BatchJobQueueComputeEnvironmentOrder | cdktn.IResolvable): any;
export declare class BatchJobQueueComputeEnvironmentOrderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobQueueComputeEnvironmentOrder | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobQueueComputeEnvironmentOrder | cdktn.IResolvable | undefined);
    private _computeEnvironment?;
    get computeEnvironment(): string;
    set computeEnvironment(value: string);
    resetComputeEnvironment(): void;
    get computeEnvironmentInput(): string | undefined;
    private _order?;
    get order(): number;
    set order(value: number);
    resetOrder(): void;
    get orderInput(): number | undefined;
}
export declare class BatchJobQueueComputeEnvironmentOrderList extends cdktn.ComplexList {
    internalValue?: BatchJobQueueComputeEnvironmentOrder[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobQueueComputeEnvironmentOrderOutputReference;
}
export interface BatchJobQueueJobStateTimeLimitActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#action BatchJobQueue#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#max_time_seconds BatchJobQueue#max_time_seconds}
    */
    readonly maxTimeSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#reason BatchJobQueue#reason}
    */
    readonly reason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#state BatchJobQueue#state}
    */
    readonly state?: string;
}
export declare function batchJobQueueJobStateTimeLimitActionsToTerraform(struct?: BatchJobQueueJobStateTimeLimitActions | cdktn.IResolvable): any;
export declare function batchJobQueueJobStateTimeLimitActionsToHclTerraform(struct?: BatchJobQueueJobStateTimeLimitActions | cdktn.IResolvable): any;
export declare class BatchJobQueueJobStateTimeLimitActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobQueueJobStateTimeLimitActions | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobQueueJobStateTimeLimitActions | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _maxTimeSeconds?;
    get maxTimeSeconds(): number;
    set maxTimeSeconds(value: number);
    resetMaxTimeSeconds(): void;
    get maxTimeSecondsInput(): number | undefined;
    private _reason?;
    get reason(): string;
    set reason(value: string);
    resetReason(): void;
    get reasonInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export declare class BatchJobQueueJobStateTimeLimitActionsList extends cdktn.ComplexList {
    internalValue?: BatchJobQueueJobStateTimeLimitActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobQueueJobStateTimeLimitActionsOutputReference;
}
export interface BatchJobQueueServiceEnvironmentOrder {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#order BatchJobQueue#order}
    */
    readonly order?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#service_environment BatchJobQueue#service_environment}
    */
    readonly serviceEnvironment?: string;
}
export declare function batchJobQueueServiceEnvironmentOrderToTerraform(struct?: BatchJobQueueServiceEnvironmentOrder | cdktn.IResolvable): any;
export declare function batchJobQueueServiceEnvironmentOrderToHclTerraform(struct?: BatchJobQueueServiceEnvironmentOrder | cdktn.IResolvable): any;
export declare class BatchJobQueueServiceEnvironmentOrderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchJobQueueServiceEnvironmentOrder | cdktn.IResolvable | undefined;
    set internalValue(value: BatchJobQueueServiceEnvironmentOrder | cdktn.IResolvable | undefined);
    private _order?;
    get order(): number;
    set order(value: number);
    resetOrder(): void;
    get orderInput(): number | undefined;
    private _serviceEnvironment?;
    get serviceEnvironment(): string;
    set serviceEnvironment(value: string);
    resetServiceEnvironment(): void;
    get serviceEnvironmentInput(): string | undefined;
}
export declare class BatchJobQueueServiceEnvironmentOrderList extends cdktn.ComplexList {
    internalValue?: BatchJobQueueServiceEnvironmentOrder[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchJobQueueServiceEnvironmentOrderOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue awscc_batch_job_queue}
*/
export declare class BatchJobQueue extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_batch_job_queue";
    /**
    * Generates CDKTN code for importing a BatchJobQueue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BatchJobQueue to import
    * @param importFromId The id of the existing BatchJobQueue that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BatchJobQueue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/batch_job_queue awscc_batch_job_queue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BatchJobQueueConfig
    */
    constructor(scope: Construct, id: string, config: BatchJobQueueConfig);
    private _computeEnvironmentOrder;
    get computeEnvironmentOrder(): BatchJobQueueComputeEnvironmentOrderList;
    putComputeEnvironmentOrder(value: BatchJobQueueComputeEnvironmentOrder[] | cdktn.IResolvable): void;
    resetComputeEnvironmentOrder(): void;
    get computeEnvironmentOrderInput(): cdktn.IResolvable | BatchJobQueueComputeEnvironmentOrder[] | undefined;
    get id(): string;
    get jobQueueArn(): string;
    private _jobQueueName?;
    get jobQueueName(): string;
    set jobQueueName(value: string);
    resetJobQueueName(): void;
    get jobQueueNameInput(): string | undefined;
    private _jobQueueType?;
    get jobQueueType(): string;
    set jobQueueType(value: string);
    resetJobQueueType(): void;
    get jobQueueTypeInput(): string | undefined;
    private _jobStateTimeLimitActions;
    get jobStateTimeLimitActions(): BatchJobQueueJobStateTimeLimitActionsList;
    putJobStateTimeLimitActions(value: BatchJobQueueJobStateTimeLimitActions[] | cdktn.IResolvable): void;
    resetJobStateTimeLimitActions(): void;
    get jobStateTimeLimitActionsInput(): cdktn.IResolvable | BatchJobQueueJobStateTimeLimitActions[] | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _schedulingPolicyArn?;
    get schedulingPolicyArn(): string;
    set schedulingPolicyArn(value: string);
    resetSchedulingPolicyArn(): void;
    get schedulingPolicyArnInput(): string | undefined;
    private _serviceEnvironmentOrder;
    get serviceEnvironmentOrder(): BatchJobQueueServiceEnvironmentOrderList;
    putServiceEnvironmentOrder(value: BatchJobQueueServiceEnvironmentOrder[] | cdktn.IResolvable): void;
    resetServiceEnvironmentOrder(): void;
    get serviceEnvironmentOrderInput(): cdktn.IResolvable | BatchJobQueueServiceEnvironmentOrder[] | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
