/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentregistryRegistryRecordConfig extends cdktn.TerraformMetaArguments {
    /**
    * The custom metadata to attach to the registry record. Each key must match a property defined in the registry's custom metadata schema. Values can be strings (maximum 128 characters) or native JSON booleans (true or false).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#custom_metadata AgentregistryRegistryRecord#custom_metadata}
    */
    readonly customMetadata?: string;
    /**
    * The description of the registry record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#description AgentregistryRegistryRecord#description}
    */
    readonly description?: string;
    /**
    * The typed set of descriptors for a registry record. Exactly one descriptor field is populated based on the record type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#descriptors AgentregistryRegistryRecord#descriptors}
    */
    readonly descriptors: AgentregistryRegistryRecordDescriptors;
    /**
    * The human-readable display name of the registry record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#display_name AgentregistryRegistryRecord#display_name}
    */
    readonly displayName?: string;
    /**
    * The name of the registry record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#name AgentregistryRegistryRecord#name}
    */
    readonly name: string;
    /**
    * The type of the registry record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#record_type AgentregistryRegistryRecord#record_type}
    */
    readonly recordType: string;
    /**
    * The version of the registry record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#record_version AgentregistryRegistryRecord#record_version}
    */
    readonly recordVersion?: string;
    /**
    * The identifier of the registry in which to create the record. You can specify either the registry ID or the registry Amazon Resource Name (ARN). Use the ARN form to reference a registry shared from another account via AWS Resource Access Manager (RAM).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#registry_id AgentregistryRegistryRecord#registry_id}
    */
    readonly registryId?: string;
    /**
    * Tags to assign to the registry record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#tags AgentregistryRegistryRecord#tags}
    */
    readonly tags?: AgentregistryRegistryRecordTags[] | cdktn.IResolvable;
}
export interface AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider {
    /**
    * The SigV4 signing region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#region AgentregistryRegistryRecord#region}
    */
    readonly region?: string;
    /**
    * The ARN of the IAM role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#role_arn AgentregistryRegistryRecord#role_arn}
    */
    readonly roleArn?: string;
    /**
    * The SigV4 signing service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#service AgentregistryRegistryRecord#service}
    */
    readonly service?: string;
}
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderToTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider {
    /**
    * Additional custom parameters for the OAuth flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#custom_parameters AgentregistryRegistryRecord#custom_parameters}
    */
    readonly customParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#grant_type AgentregistryRegistryRecord#grant_type}
    */
    readonly grantType?: string;
    /**
    * The ARN of the OAuth credential provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#provider_arn AgentregistryRegistryRecord#provider_arn}
    */
    readonly providerArn?: string;
    /**
    * OAuth scopes to request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#scopes AgentregistryRegistryRecord#scopes}
    */
    readonly scopes?: string[];
}
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderToTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | cdktn.IResolvable | undefined);
    private _customParameters?;
    get customParameters(): {
        [key: string]: string;
    };
    set customParameters(value: {
        [key: string]: string;
    });
    resetCustomParameters(): void;
    get customParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _grantType?;
    get grantType(): string;
    set grantType(value: string);
    resetGrantType(): void;
    get grantTypeInput(): string | undefined;
    private _providerArn?;
    get providerArn(): string;
    set providerArn(value: string);
    resetProviderArn(): void;
    get providerArnInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider {
    /**
    * IAM credential provider configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#iam_credential_provider AgentregistryRegistryRecord#iam_credential_provider}
    */
    readonly iamCredentialProvider?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider;
    /**
    * OAuth credential provider configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#oauth_credential_provider AgentregistryRegistryRecord#oauth_credential_provider}
    */
    readonly oauthCredentialProvider?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider;
}
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderToTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider | cdktn.IResolvable | undefined);
    private _iamCredentialProvider;
    get iamCredentialProvider(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderOutputReference;
    putIamCredentialProvider(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider): void;
    resetIamCredentialProvider(): void;
    get iamCredentialProviderInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | undefined;
    private _oauthCredentialProvider;
    get oauthCredentialProvider(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderOutputReference;
    putOauthCredentialProvider(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider): void;
    resetOauthCredentialProvider(): void;
    get oauthCredentialProviderInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations {
    /**
    * The credential provider details. Specify exactly one member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#credential_provider AgentregistryRegistryRecord#credential_provider}
    */
    readonly credentialProvider?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#credential_provider_type AgentregistryRegistryRecord#credential_provider_type}
    */
    readonly credentialProviderType?: string;
}
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsToTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations | cdktn.IResolvable | undefined);
    private _credentialProvider;
    get credentialProvider(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProviderOutputReference;
    putCredentialProvider(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider): void;
    resetCredentialProvider(): void;
    get credentialProviderInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsCredentialProvider | undefined;
    private _credentialProviderType?;
    get credentialProviderType(): string;
    set credentialProviderType(value: string);
    resetCredentialProviderType(): void;
    get credentialProviderTypeInput(): string | undefined;
}
export declare class AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsList extends cdktn.ComplexList {
    internalValue?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsOutputReference;
}
export interface AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl {
    /**
    * The credential providers used to authenticate when fetching descriptor content from the source URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#credential_provider_configurations AgentregistryRegistryRecord#credential_provider_configurations}
    */
    readonly credentialProviderConfigurations?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations[] | cdktn.IResolvable;
    /**
    * URL source for descriptor content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#url AgentregistryRegistryRecord#url}
    */
    readonly url?: string;
}
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlToTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl | cdktn.IResolvable | undefined);
    private _credentialProviderConfigurations;
    get credentialProviderConfigurations(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurationsList;
    putCredentialProviderConfigurations(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations[] | cdktn.IResolvable): void;
    resetCredentialProviderConfigurations(): void;
    get credentialProviderConfigurationsInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlCredentialProviderConfigurations[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsA2AAgentCardSource {
    /**
    * URL-based descriptor source configuration, with credential provider configurations for authenticated URL retrieval.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#from_url AgentregistryRegistryRecord#from_url}
    */
    readonly fromUrl?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl;
}
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceToTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSource | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardSourceToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSource | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSource | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSource | cdktn.IResolvable | undefined);
    private _fromUrl;
    get fromUrl(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrlOutputReference;
    putFromUrl(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl): void;
    resetFromUrl(): void;
    get fromUrlInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceFromUrl | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsA2AAgentCard {
    /**
    * Descriptor payload data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data AgentregistryRegistryRecord#data}
    */
    readonly data?: string;
    /**
    * Version of the descriptor type schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data_schema_version AgentregistryRegistryRecord#data_schema_version}
    */
    readonly dataSchemaVersion?: string;
    /**
    * The source configuration that defines where descriptor content is retrieved from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#source AgentregistryRegistryRecord#source}
    */
    readonly source?: AgentregistryRegistryRecordDescriptorsA2AAgentCardSource;
}
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardToTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCard | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsA2AAgentCardToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsA2AAgentCard | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsA2AAgentCardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsA2AAgentCard | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsA2AAgentCard | cdktn.IResolvable | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _dataSchemaVersion?;
    get dataSchemaVersion(): string;
    set dataSchemaVersion(value: string);
    resetDataSchemaVersion(): void;
    get dataSchemaVersionInput(): string | undefined;
    private _source;
    get source(): AgentregistryRegistryRecordDescriptorsA2AAgentCardSourceOutputReference;
    putSource(value: AgentregistryRegistryRecordDescriptorsA2AAgentCardSource): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsA2AAgentCardSource | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl {
    /**
    * URL source for the SkillMd document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#url AgentregistryRegistryRecord#url}
    */
    readonly url?: string;
}
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrlToTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrlToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl | cdktn.IResolvable | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource {
    /**
    * URL-based source for SkillMd content (sync is skipped; content is provided inline via Data).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#from_url AgentregistryRegistryRecord#from_url}
    */
    readonly fromUrl?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl;
}
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceToTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource | cdktn.IResolvable | undefined);
    private _fromUrl;
    get fromUrl(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrlOutputReference;
    putFromUrl(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl): void;
    resetFromUrl(): void;
    get fromUrlInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceFromUrl | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd {
    /**
    * Descriptor payload data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data AgentregistryRegistryRecord#data}
    */
    readonly data?: string;
    /**
    * Version of the descriptor type schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data_schema_version AgentregistryRegistryRecord#data_schema_version}
    */
    readonly dataSchemaVersion?: string;
    /**
    * Source configuration for a SkillMd document. Unlike MCP/A2A sources, SkillMd does not support credential providers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#source AgentregistryRegistryRecord#source}
    */
    readonly source?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource;
}
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdToTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd | cdktn.IResolvable | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _dataSchemaVersion?;
    get dataSchemaVersion(): string;
    set dataSchemaVersion(value: string);
    resetDataSchemaVersion(): void;
    get dataSchemaVersionInput(): string | undefined;
    private _source;
    get source(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSourceOutputReference;
    putSource(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdSource | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData {
    /**
    * Markdown-format descriptor containing an agent skills document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#skill_md AgentregistryRegistryRecord#skill_md}
    */
    readonly skillMd?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd;
}
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataToTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData | cdktn.IResolvable | undefined);
    private _skillMd;
    get skillMd(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMdOutputReference;
    putSkillMd(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd): void;
    resetSkillMd(): void;
    get skillMdInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataSkillMd | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsAgentSkillsDefinition {
    /**
    * Additional data associated with an agent skills definition descriptor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#additional_data AgentregistryRegistryRecord#additional_data}
    */
    readonly additionalData?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData;
    /**
    * Descriptor payload data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data AgentregistryRegistryRecord#data}
    */
    readonly data?: string;
    /**
    * Version of the descriptor type schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data_schema_version AgentregistryRegistryRecord#data_schema_version}
    */
    readonly dataSchemaVersion?: string;
}
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionToTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinition | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsAgentSkillsDefinitionToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinition | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinition | cdktn.IResolvable | undefined);
    private _additionalData;
    get additionalData(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalDataOutputReference;
    putAdditionalData(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData): void;
    resetAdditionalData(): void;
    get additionalDataInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionAdditionalData | undefined;
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _dataSchemaVersion?;
    get dataSchemaVersion(): string;
    set dataSchemaVersion(value: string);
    resetDataSchemaVersion(): void;
    get dataSchemaVersionInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsAguiSourceFromUrl {
    /**
    * URL source for descriptor content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#url AgentregistryRegistryRecord#url}
    */
    readonly url?: string;
}
export declare function agentregistryRegistryRecordDescriptorsAguiSourceFromUrlToTerraform(struct?: AgentregistryRegistryRecordDescriptorsAguiSourceFromUrl | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsAguiSourceFromUrlToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsAguiSourceFromUrl | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsAguiSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsAguiSourceFromUrl | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsAguiSourceFromUrl | cdktn.IResolvable | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsAguiSource {
    /**
    * URL-based source configuration for a source-only descriptor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#from_url AgentregistryRegistryRecord#from_url}
    */
    readonly fromUrl?: AgentregistryRegistryRecordDescriptorsAguiSourceFromUrl;
}
export declare function agentregistryRegistryRecordDescriptorsAguiSourceToTerraform(struct?: AgentregistryRegistryRecordDescriptorsAguiSource | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsAguiSourceToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsAguiSource | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsAguiSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsAguiSource | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsAguiSource | cdktn.IResolvable | undefined);
    private _fromUrl;
    get fromUrl(): AgentregistryRegistryRecordDescriptorsAguiSourceFromUrlOutputReference;
    putFromUrl(value: AgentregistryRegistryRecordDescriptorsAguiSourceFromUrl): void;
    resetFromUrl(): void;
    get fromUrlInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsAguiSourceFromUrl | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsAgui {
    /**
    * Source configuration for a source-only descriptor. Unlike mcpServer/a2aAgentCard sources, source-only descriptors do not support credential providers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#source AgentregistryRegistryRecord#source}
    */
    readonly source?: AgentregistryRegistryRecordDescriptorsAguiSource;
}
export declare function agentregistryRegistryRecordDescriptorsAguiToTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgui | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsAguiToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsAgui | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsAguiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsAgui | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsAgui | cdktn.IResolvable | undefined);
    private _source;
    get source(): AgentregistryRegistryRecordDescriptorsAguiSourceOutputReference;
    putSource(value: AgentregistryRegistryRecordDescriptorsAguiSource): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsAguiSource | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsCustom {
    /**
    * Descriptor payload data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data AgentregistryRegistryRecord#data}
    */
    readonly data?: string;
}
export declare function agentregistryRegistryRecordDescriptorsCustomToTerraform(struct?: AgentregistryRegistryRecordDescriptorsCustom | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsCustomToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsCustom | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsCustom | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsCustom | cdktn.IResolvable | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsHttpSourceFromUrl {
    /**
    * URL source for descriptor content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#url AgentregistryRegistryRecord#url}
    */
    readonly url?: string;
}
export declare function agentregistryRegistryRecordDescriptorsHttpSourceFromUrlToTerraform(struct?: AgentregistryRegistryRecordDescriptorsHttpSourceFromUrl | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsHttpSourceFromUrlToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsHttpSourceFromUrl | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsHttpSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsHttpSourceFromUrl | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsHttpSourceFromUrl | cdktn.IResolvable | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsHttpSource {
    /**
    * URL-based source configuration for a source-only descriptor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#from_url AgentregistryRegistryRecord#from_url}
    */
    readonly fromUrl?: AgentregistryRegistryRecordDescriptorsHttpSourceFromUrl;
}
export declare function agentregistryRegistryRecordDescriptorsHttpSourceToTerraform(struct?: AgentregistryRegistryRecordDescriptorsHttpSource | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsHttpSourceToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsHttpSource | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsHttpSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsHttpSource | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsHttpSource | cdktn.IResolvable | undefined);
    private _fromUrl;
    get fromUrl(): AgentregistryRegistryRecordDescriptorsHttpSourceFromUrlOutputReference;
    putFromUrl(value: AgentregistryRegistryRecordDescriptorsHttpSourceFromUrl): void;
    resetFromUrl(): void;
    get fromUrlInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsHttpSourceFromUrl | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsHttp {
    /**
    * Source configuration for a source-only descriptor. Unlike mcpServer/a2aAgentCard sources, source-only descriptors do not support credential providers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#source AgentregistryRegistryRecord#source}
    */
    readonly source?: AgentregistryRegistryRecordDescriptorsHttpSource;
}
export declare function agentregistryRegistryRecordDescriptorsHttpToTerraform(struct?: AgentregistryRegistryRecordDescriptorsHttp | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsHttpToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsHttp | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsHttp | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsHttp | cdktn.IResolvable | undefined);
    private _source;
    get source(): AgentregistryRegistryRecordDescriptorsHttpSourceOutputReference;
    putSource(value: AgentregistryRegistryRecordDescriptorsHttpSource): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsHttpSource | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools {
    /**
    * Descriptor payload data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data AgentregistryRegistryRecord#data}
    */
    readonly data?: string;
    /**
    * Version of the tools descriptor schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data_schema_version AgentregistryRegistryRecord#data_schema_version}
    */
    readonly dataSchemaVersion?: string;
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToolsToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToolsToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools | cdktn.IResolvable | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _dataSchemaVersion?;
    get dataSchemaVersion(): string;
    set dataSchemaVersion(value: string);
    resetDataSchemaVersion(): void;
    get dataSchemaVersionInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServerAdditionalData {
    /**
    * The MCP tools descriptor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#tools AgentregistryRegistryRecord#tools}
    */
    readonly tools?: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools;
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalData | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalData | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServerAdditionalData | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalData | cdktn.IResolvable | undefined);
    private _tools;
    get tools(): AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataToolsOutputReference;
    putTools(value: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools): void;
    resetTools(): void;
    get toolsInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataTools | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider {
    /**
    * The SigV4 signing region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#region AgentregistryRegistryRecord#region}
    */
    readonly region?: string;
    /**
    * The ARN of the IAM role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#role_arn AgentregistryRegistryRecord#role_arn}
    */
    readonly roleArn?: string;
    /**
    * The SigV4 signing service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#service AgentregistryRegistryRecord#service}
    */
    readonly service?: string;
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider {
    /**
    * Additional custom parameters for the OAuth flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#custom_parameters AgentregistryRegistryRecord#custom_parameters}
    */
    readonly customParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#grant_type AgentregistryRegistryRecord#grant_type}
    */
    readonly grantType?: string;
    /**
    * The ARN of the OAuth credential provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#provider_arn AgentregistryRegistryRecord#provider_arn}
    */
    readonly providerArn?: string;
    /**
    * OAuth scopes to request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#scopes AgentregistryRegistryRecord#scopes}
    */
    readonly scopes?: string[];
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | cdktn.IResolvable | undefined);
    private _customParameters?;
    get customParameters(): {
        [key: string]: string;
    };
    set customParameters(value: {
        [key: string]: string;
    });
    resetCustomParameters(): void;
    get customParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _grantType?;
    get grantType(): string;
    set grantType(value: string);
    resetGrantType(): void;
    get grantTypeInput(): string | undefined;
    private _providerArn?;
    get providerArn(): string;
    set providerArn(value: string);
    resetProviderArn(): void;
    get providerArnInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider {
    /**
    * IAM credential provider configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#iam_credential_provider AgentregistryRegistryRecord#iam_credential_provider}
    */
    readonly iamCredentialProvider?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider;
    /**
    * OAuth credential provider configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#oauth_credential_provider AgentregistryRegistryRecord#oauth_credential_provider}
    */
    readonly oauthCredentialProvider?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider;
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider | cdktn.IResolvable | undefined);
    private _iamCredentialProvider;
    get iamCredentialProvider(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProviderOutputReference;
    putIamCredentialProvider(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider): void;
    resetIamCredentialProvider(): void;
    get iamCredentialProviderInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderIamCredentialProvider | undefined;
    private _oauthCredentialProvider;
    get oauthCredentialProvider(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProviderOutputReference;
    putOauthCredentialProvider(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider): void;
    resetOauthCredentialProvider(): void;
    get oauthCredentialProviderInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOauthCredentialProvider | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations {
    /**
    * The credential provider details. Specify exactly one member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#credential_provider AgentregistryRegistryRecord#credential_provider}
    */
    readonly credentialProvider?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#credential_provider_type AgentregistryRegistryRecord#credential_provider_type}
    */
    readonly credentialProviderType?: string;
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations | cdktn.IResolvable | undefined);
    private _credentialProvider;
    get credentialProvider(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProviderOutputReference;
    putCredentialProvider(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider): void;
    resetCredentialProvider(): void;
    get credentialProviderInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsCredentialProvider | undefined;
    private _credentialProviderType?;
    get credentialProviderType(): string;
    set credentialProviderType(value: string);
    resetCredentialProviderType(): void;
    get credentialProviderTypeInput(): string | undefined;
}
export declare class AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsList extends cdktn.ComplexList {
    internalValue?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsOutputReference;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl {
    /**
    * The credential providers used to authenticate when fetching descriptor content from the source URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#credential_provider_configurations AgentregistryRegistryRecord#credential_provider_configurations}
    */
    readonly credentialProviderConfigurations?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations[] | cdktn.IResolvable;
    /**
    * URL source for descriptor content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#url AgentregistryRegistryRecord#url}
    */
    readonly url?: string;
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl | cdktn.IResolvable | undefined);
    private _credentialProviderConfigurations;
    get credentialProviderConfigurations(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurationsList;
    putCredentialProviderConfigurations(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations[] | cdktn.IResolvable): void;
    resetCredentialProviderConfigurations(): void;
    get credentialProviderConfigurationsInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlCredentialProviderConfigurations[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServerSource {
    /**
    * URL-based descriptor source configuration, with credential provider configurations for authenticated URL retrieval.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#from_url AgentregistryRegistryRecord#from_url}
    */
    readonly fromUrl?: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl;
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSource | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerSourceToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServerSource | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServerSource | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServerSource | cdktn.IResolvable | undefined);
    private _fromUrl;
    get fromUrl(): AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrlOutputReference;
    putFromUrl(value: AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl): void;
    resetFromUrl(): void;
    get fromUrlInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServerSourceFromUrl | undefined;
}
export interface AgentregistryRegistryRecordDescriptorsMcpServer {
    /**
    * Additional data associated with an MCP server descriptor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#additional_data AgentregistryRegistryRecord#additional_data}
    */
    readonly additionalData?: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalData;
    /**
    * Descriptor payload data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data AgentregistryRegistryRecord#data}
    */
    readonly data?: string;
    /**
    * Version of the descriptor type schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#data_schema_version AgentregistryRegistryRecord#data_schema_version}
    */
    readonly dataSchemaVersion?: string;
    /**
    * The source configuration that defines where descriptor content is retrieved from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#source AgentregistryRegistryRecord#source}
    */
    readonly source?: AgentregistryRegistryRecordDescriptorsMcpServerSource;
}
export declare function agentregistryRegistryRecordDescriptorsMcpServerToTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServer | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsMcpServerToHclTerraform(struct?: AgentregistryRegistryRecordDescriptorsMcpServer | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsMcpServerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptorsMcpServer | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptorsMcpServer | cdktn.IResolvable | undefined);
    private _additionalData;
    get additionalData(): AgentregistryRegistryRecordDescriptorsMcpServerAdditionalDataOutputReference;
    putAdditionalData(value: AgentregistryRegistryRecordDescriptorsMcpServerAdditionalData): void;
    resetAdditionalData(): void;
    get additionalDataInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServerAdditionalData | undefined;
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _dataSchemaVersion?;
    get dataSchemaVersion(): string;
    set dataSchemaVersion(value: string);
    resetDataSchemaVersion(): void;
    get dataSchemaVersionInput(): string | undefined;
    private _source;
    get source(): AgentregistryRegistryRecordDescriptorsMcpServerSourceOutputReference;
    putSource(value: AgentregistryRegistryRecordDescriptorsMcpServerSource): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServerSource | undefined;
}
export interface AgentregistryRegistryRecordDescriptors {
    /**
    * The A2A agent card descriptor, populated when the record type is AGENT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#a2_a_agent_card AgentregistryRegistryRecord#a2_a_agent_card}
    */
    readonly a2AAgentCard?: AgentregistryRegistryRecordDescriptorsA2AAgentCard;
    /**
    * The agent skills definition descriptor, populated when the record type is SKILL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#agent_skills_definition AgentregistryRegistryRecord#agent_skills_definition}
    */
    readonly agentSkillsDefinition?: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinition;
    /**
    * The AG-UI (Agent-User Interaction) descriptor, populated for records detected from an AG-UI protocol source. This descriptor is source-only: its content is synchronized from the configured source URL rather than supplied inline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#agui AgentregistryRegistryRecord#agui}
    */
    readonly agui?: AgentregistryRegistryRecordDescriptorsAgui;
    /**
    * The custom descriptor, populated when the record type is CUSTOM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#custom AgentregistryRegistryRecord#custom}
    */
    readonly custom?: AgentregistryRegistryRecordDescriptorsCustom;
    /**
    * The HTTP descriptor, populated for records detected from an HTTP protocol source. This descriptor is source-only: its content is synchronized from the configured source URL rather than supplied inline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#http AgentregistryRegistryRecord#http}
    */
    readonly http?: AgentregistryRegistryRecordDescriptorsHttp;
    /**
    * The MCP server descriptor, populated when the record type is MCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#mcp_server AgentregistryRegistryRecord#mcp_server}
    */
    readonly mcpServer?: AgentregistryRegistryRecordDescriptorsMcpServer;
}
export declare function agentregistryRegistryRecordDescriptorsToTerraform(struct?: AgentregistryRegistryRecordDescriptors | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordDescriptorsToHclTerraform(struct?: AgentregistryRegistryRecordDescriptors | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordDescriptorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentregistryRegistryRecordDescriptors | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordDescriptors | cdktn.IResolvable | undefined);
    private _a2AAgentCard;
    get a2AAgentCard(): AgentregistryRegistryRecordDescriptorsA2AAgentCardOutputReference;
    putA2AAgentCard(value: AgentregistryRegistryRecordDescriptorsA2AAgentCard): void;
    resetA2AAgentCard(): void;
    get a2AAgentCardInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsA2AAgentCard | undefined;
    private _agentSkillsDefinition;
    get agentSkillsDefinition(): AgentregistryRegistryRecordDescriptorsAgentSkillsDefinitionOutputReference;
    putAgentSkillsDefinition(value: AgentregistryRegistryRecordDescriptorsAgentSkillsDefinition): void;
    resetAgentSkillsDefinition(): void;
    get agentSkillsDefinitionInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsAgentSkillsDefinition | undefined;
    private _agui;
    get agui(): AgentregistryRegistryRecordDescriptorsAguiOutputReference;
    putAgui(value: AgentregistryRegistryRecordDescriptorsAgui): void;
    resetAgui(): void;
    get aguiInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsAgui | undefined;
    private _custom;
    get custom(): AgentregistryRegistryRecordDescriptorsCustomOutputReference;
    putCustom(value: AgentregistryRegistryRecordDescriptorsCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsCustom | undefined;
    private _http;
    get http(): AgentregistryRegistryRecordDescriptorsHttpOutputReference;
    putHttp(value: AgentregistryRegistryRecordDescriptorsHttp): void;
    resetHttp(): void;
    get httpInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsHttp | undefined;
    private _mcpServer;
    get mcpServer(): AgentregistryRegistryRecordDescriptorsMcpServerOutputReference;
    putMcpServer(value: AgentregistryRegistryRecordDescriptorsMcpServer): void;
    resetMcpServer(): void;
    get mcpServerInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptorsMcpServer | undefined;
}
export interface AgentregistryRegistryRecordTags {
    /**
    * The key of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#key AgentregistryRegistryRecord#key}
    */
    readonly key?: string;
    /**
    * The value of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#value AgentregistryRegistryRecord#value}
    */
    readonly value?: string;
}
export declare function agentregistryRegistryRecordTagsToTerraform(struct?: AgentregistryRegistryRecordTags | cdktn.IResolvable): any;
export declare function agentregistryRegistryRecordTagsToHclTerraform(struct?: AgentregistryRegistryRecordTags | cdktn.IResolvable): any;
export declare class AgentregistryRegistryRecordTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AgentregistryRegistryRecordTags | cdktn.IResolvable | undefined;
    set internalValue(value: AgentregistryRegistryRecordTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AgentregistryRegistryRecordTagsList extends cdktn.ComplexList {
    internalValue?: AgentregistryRegistryRecordTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AgentregistryRegistryRecordTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record awscc_agentregistry_registry_record}
*/
export declare class AgentregistryRegistryRecord extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_agentregistry_registry_record";
    /**
    * Generates CDKTN code for importing a AgentregistryRegistryRecord resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentregistryRegistryRecord to import
    * @param importFromId The id of the existing AgentregistryRegistryRecord that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentregistryRegistryRecord to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/agentregistry_registry_record awscc_agentregistry_registry_record} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentregistryRegistryRecordConfig
    */
    constructor(scope: Construct, id: string, config: AgentregistryRegistryRecordConfig);
    get createdAt(): string;
    get createdBy(): string;
    private _customMetadata?;
    get customMetadata(): string;
    set customMetadata(value: string);
    resetCustomMetadata(): void;
    get customMetadataInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _descriptors;
    get descriptors(): AgentregistryRegistryRecordDescriptorsOutputReference;
    putDescriptors(value: AgentregistryRegistryRecordDescriptors): void;
    get descriptorsInput(): cdktn.IResolvable | AgentregistryRegistryRecordDescriptors | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get recordArn(): string;
    get recordId(): string;
    private _recordType?;
    get recordType(): string;
    set recordType(value: string);
    get recordTypeInput(): string | undefined;
    private _recordVersion?;
    get recordVersion(): string;
    set recordVersion(value: string);
    resetRecordVersion(): void;
    get recordVersionInput(): string | undefined;
    get registryArn(): string;
    private _registryId?;
    get registryId(): string;
    set registryId(value: string);
    resetRegistryId(): void;
    get registryIdInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): AgentregistryRegistryRecordTagsList;
    putTags(value: AgentregistryRegistryRecordTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AgentregistryRegistryRecordTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
