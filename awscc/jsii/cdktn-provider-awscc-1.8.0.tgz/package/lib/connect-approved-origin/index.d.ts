/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectApprovedOriginConfig extends cdktn.TerraformMetaArguments {
    /**
    * Amazon Connect instance identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_approved_origin#instance_id ConnectApprovedOrigin#instance_id}
    */
    readonly instanceId: string;
    /**
    * Domain name to be added to the allowlist of instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_approved_origin#origin ConnectApprovedOrigin#origin}
    */
    readonly origin: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_approved_origin awscc_connect_approved_origin}
*/
export declare class ConnectApprovedOrigin extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_approved_origin";
    /**
    * Generates CDKTN code for importing a ConnectApprovedOrigin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectApprovedOrigin to import
    * @param importFromId The id of the existing ConnectApprovedOrigin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_approved_origin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectApprovedOrigin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/connect_approved_origin awscc_connect_approved_origin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectApprovedOriginConfig
    */
    constructor(scope: Construct, id: string, config: ConnectApprovedOriginConfig);
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _origin?;
    get origin(): string;
    set origin(value: string);
    get originInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
