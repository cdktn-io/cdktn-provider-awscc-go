/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiopsInvestigationGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * An array of key-value pairs of notification channels to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#chatbot_notification_channels AiopsInvestigationGroup#chatbot_notification_channels}
    */
    readonly chatbotNotificationChannels?: AiopsInvestigationGroupChatbotNotificationChannels[] | cdktn.IResolvable;
    /**
    * An array of cross account configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#cross_account_configurations AiopsInvestigationGroup#cross_account_configurations}
    */
    readonly crossAccountConfigurations?: AiopsInvestigationGroupCrossAccountConfigurations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#encryption_config AiopsInvestigationGroup#encryption_config}
    */
    readonly encryptionConfig?: AiopsInvestigationGroupEncryptionConfig;
    /**
    * Investigation Group policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#investigation_group_policy AiopsInvestigationGroup#investigation_group_policy}
    */
    readonly investigationGroupPolicy?: string;
    /**
    * Flag to enable cloud trail history
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#is_cloud_trail_event_history_enabled AiopsInvestigationGroup#is_cloud_trail_event_history_enabled}
    */
    readonly isCloudTrailEventHistoryEnabled?: boolean | cdktn.IResolvable;
    /**
    * User friendly name for resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#name AiopsInvestigationGroup#name}
    */
    readonly name: string;
    /**
    * The number of days to retain the investigation group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#retention_in_days AiopsInvestigationGroup#retention_in_days}
    */
    readonly retentionInDays?: number;
    /**
    * The Investigation Role's ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#role_arn AiopsInvestigationGroup#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#tag_key_boundaries AiopsInvestigationGroup#tag_key_boundaries}
    */
    readonly tagKeyBoundaries?: string[];
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#tags AiopsInvestigationGroup#tags}
    */
    readonly tags?: AiopsInvestigationGroupTags[] | cdktn.IResolvable;
}
export interface AiopsInvestigationGroupChatbotNotificationChannels {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#chat_configuration_arns AiopsInvestigationGroup#chat_configuration_arns}
    */
    readonly chatConfigurationArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#sns_topic_arn AiopsInvestigationGroup#sns_topic_arn}
    */
    readonly snsTopicArn?: string;
}
export declare function aiopsInvestigationGroupChatbotNotificationChannelsToTerraform(struct?: AiopsInvestigationGroupChatbotNotificationChannels | cdktn.IResolvable): any;
export declare function aiopsInvestigationGroupChatbotNotificationChannelsToHclTerraform(struct?: AiopsInvestigationGroupChatbotNotificationChannels | cdktn.IResolvable): any;
export declare class AiopsInvestigationGroupChatbotNotificationChannelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiopsInvestigationGroupChatbotNotificationChannels | cdktn.IResolvable | undefined;
    set internalValue(value: AiopsInvestigationGroupChatbotNotificationChannels | cdktn.IResolvable | undefined);
    private _chatConfigurationArns?;
    get chatConfigurationArns(): string[];
    set chatConfigurationArns(value: string[]);
    resetChatConfigurationArns(): void;
    get chatConfigurationArnsInput(): string[] | undefined;
    private _snsTopicArn?;
    get snsTopicArn(): string;
    set snsTopicArn(value: string);
    resetSnsTopicArn(): void;
    get snsTopicArnInput(): string | undefined;
}
export declare class AiopsInvestigationGroupChatbotNotificationChannelsList extends cdktn.ComplexList {
    internalValue?: AiopsInvestigationGroupChatbotNotificationChannels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiopsInvestigationGroupChatbotNotificationChannelsOutputReference;
}
export interface AiopsInvestigationGroupCrossAccountConfigurations {
    /**
    * The Investigation Role's ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#source_role_arn AiopsInvestigationGroup#source_role_arn}
    */
    readonly sourceRoleArn?: string;
}
export declare function aiopsInvestigationGroupCrossAccountConfigurationsToTerraform(struct?: AiopsInvestigationGroupCrossAccountConfigurations | cdktn.IResolvable): any;
export declare function aiopsInvestigationGroupCrossAccountConfigurationsToHclTerraform(struct?: AiopsInvestigationGroupCrossAccountConfigurations | cdktn.IResolvable): any;
export declare class AiopsInvestigationGroupCrossAccountConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiopsInvestigationGroupCrossAccountConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: AiopsInvestigationGroupCrossAccountConfigurations | cdktn.IResolvable | undefined);
    private _sourceRoleArn?;
    get sourceRoleArn(): string;
    set sourceRoleArn(value: string);
    resetSourceRoleArn(): void;
    get sourceRoleArnInput(): string | undefined;
}
export declare class AiopsInvestigationGroupCrossAccountConfigurationsList extends cdktn.ComplexList {
    internalValue?: AiopsInvestigationGroupCrossAccountConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiopsInvestigationGroupCrossAccountConfigurationsOutputReference;
}
export interface AiopsInvestigationGroupEncryptionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#encryption_configuration_type AiopsInvestigationGroup#encryption_configuration_type}
    */
    readonly encryptionConfigurationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#kms_key_id AiopsInvestigationGroup#kms_key_id}
    */
    readonly kmsKeyId?: string;
}
export declare function aiopsInvestigationGroupEncryptionConfigToTerraform(struct?: AiopsInvestigationGroupEncryptionConfig | cdktn.IResolvable): any;
export declare function aiopsInvestigationGroupEncryptionConfigToHclTerraform(struct?: AiopsInvestigationGroupEncryptionConfig | cdktn.IResolvable): any;
export declare class AiopsInvestigationGroupEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiopsInvestigationGroupEncryptionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiopsInvestigationGroupEncryptionConfig | cdktn.IResolvable | undefined);
    private _encryptionConfigurationType?;
    get encryptionConfigurationType(): string;
    set encryptionConfigurationType(value: string);
    resetEncryptionConfigurationType(): void;
    get encryptionConfigurationTypeInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
}
export interface AiopsInvestigationGroupTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#key AiopsInvestigationGroup#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#value AiopsInvestigationGroup#value}
    */
    readonly value?: string;
}
export declare function aiopsInvestigationGroupTagsToTerraform(struct?: AiopsInvestigationGroupTags | cdktn.IResolvable): any;
export declare function aiopsInvestigationGroupTagsToHclTerraform(struct?: AiopsInvestigationGroupTags | cdktn.IResolvable): any;
export declare class AiopsInvestigationGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiopsInvestigationGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: AiopsInvestigationGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AiopsInvestigationGroupTagsList extends cdktn.ComplexList {
    internalValue?: AiopsInvestigationGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiopsInvestigationGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group awscc_aiops_investigation_group}
*/
export declare class AiopsInvestigationGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_aiops_investigation_group";
    /**
    * Generates CDKTN code for importing a AiopsInvestigationGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiopsInvestigationGroup to import
    * @param importFromId The id of the existing AiopsInvestigationGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiopsInvestigationGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.106.0/docs/resources/aiops_investigation_group awscc_aiops_investigation_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiopsInvestigationGroupConfig
    */
    constructor(scope: Construct, id: string, config: AiopsInvestigationGroupConfig);
    get arn(): string;
    private _chatbotNotificationChannels;
    get chatbotNotificationChannels(): AiopsInvestigationGroupChatbotNotificationChannelsList;
    putChatbotNotificationChannels(value: AiopsInvestigationGroupChatbotNotificationChannels[] | cdktn.IResolvable): void;
    resetChatbotNotificationChannels(): void;
    get chatbotNotificationChannelsInput(): cdktn.IResolvable | AiopsInvestigationGroupChatbotNotificationChannels[] | undefined;
    get createdAt(): string;
    get createdBy(): string;
    private _crossAccountConfigurations;
    get crossAccountConfigurations(): AiopsInvestigationGroupCrossAccountConfigurationsList;
    putCrossAccountConfigurations(value: AiopsInvestigationGroupCrossAccountConfigurations[] | cdktn.IResolvable): void;
    resetCrossAccountConfigurations(): void;
    get crossAccountConfigurationsInput(): cdktn.IResolvable | AiopsInvestigationGroupCrossAccountConfigurations[] | undefined;
    private _encryptionConfig;
    get encryptionConfig(): AiopsInvestigationGroupEncryptionConfigOutputReference;
    putEncryptionConfig(value: AiopsInvestigationGroupEncryptionConfig): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): cdktn.IResolvable | AiopsInvestigationGroupEncryptionConfig | undefined;
    get id(): string;
    private _investigationGroupPolicy?;
    get investigationGroupPolicy(): string;
    set investigationGroupPolicy(value: string);
    resetInvestigationGroupPolicy(): void;
    get investigationGroupPolicyInput(): string | undefined;
    private _isCloudTrailEventHistoryEnabled?;
    get isCloudTrailEventHistoryEnabled(): boolean | cdktn.IResolvable;
    set isCloudTrailEventHistoryEnabled(value: boolean | cdktn.IResolvable);
    resetIsCloudTrailEventHistoryEnabled(): void;
    get isCloudTrailEventHistoryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get lastModifiedAt(): string;
    get lastModifiedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _retentionInDays?;
    get retentionInDays(): number;
    set retentionInDays(value: number);
    resetRetentionInDays(): void;
    get retentionInDaysInput(): number | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _tagKeyBoundaries?;
    get tagKeyBoundaries(): string[];
    set tagKeyBoundaries(value: string[]);
    resetTagKeyBoundaries(): void;
    get tagKeyBoundariesInput(): string[] | undefined;
    private _tags;
    get tags(): AiopsInvestigationGroupTagsList;
    putTags(value: AiopsInvestigationGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AiopsInvestigationGroupTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
