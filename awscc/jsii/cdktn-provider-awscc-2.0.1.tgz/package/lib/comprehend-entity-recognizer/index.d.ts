/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComprehendEntityRecognizerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the IAM role that grants Amazon Comprehend read access to your input data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#data_access_role_arn ComprehendEntityRecognizer#data_access_role_arn}
    */
    readonly dataAccessRoleArn: string;
    /**
    * Specifies the format and location of the input data. The S3 bucket containing the input data must be located in the same Region as the entity recognizer being created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#input_data_config ComprehendEntityRecognizer#input_data_config}
    */
    readonly inputDataConfig: ComprehendEntityRecognizerInputDataConfig;
    /**
    * The language of the input documents. All documents must be in the same language.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#language_code ComprehendEntityRecognizer#language_code}
    */
    readonly languageCode: string;
    /**
    * ID for the AWS KMS key that Amazon Comprehend uses to encrypt trained custom models.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#model_kms_key_id ComprehendEntityRecognizer#model_kms_key_id}
    */
    readonly modelKmsKeyId?: string;
    /**
    * The JSON resource-based policy to attach to your custom entity recognizer model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#model_policy ComprehendEntityRecognizer#model_policy}
    */
    readonly modelPolicy?: string;
    /**
    * The name given to the entity recognizer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#recognizer_name ComprehendEntityRecognizer#recognizer_name}
    */
    readonly recognizerName: string;
    /**
    * Tags to associate with the entity recognizer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#tags ComprehendEntityRecognizer#tags}
    */
    readonly tags?: ComprehendEntityRecognizerTags[] | cdktn.IResolvable;
    /**
    * The version name given to the entity recognizer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#version_name ComprehendEntityRecognizer#version_name}
    */
    readonly versionName?: string;
    /**
    * ID for the AWS KMS key that Amazon Comprehend uses to encrypt data on the storage volume attached to the ML compute instance(s).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#volume_kms_key_id ComprehendEntityRecognizer#volume_kms_key_id}
    */
    readonly volumeKmsKeyId?: string;
    /**
    * Configuration parameters for an optional private VPC containing the resources you are using for your custom entity recognizer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#vpc_config ComprehendEntityRecognizer#vpc_config}
    */
    readonly vpcConfig?: ComprehendEntityRecognizerVpcConfig;
}
export interface ComprehendEntityRecognizerInputDataConfigAnnotations {
    /**
    * Specifies the Amazon S3 location where the annotations are located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#s3_uri ComprehendEntityRecognizer#s3_uri}
    */
    readonly s3Uri?: string;
    /**
    * Specifies the Amazon S3 location where the test annotations are located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#test_s3_uri ComprehendEntityRecognizer#test_s3_uri}
    */
    readonly testS3Uri?: string;
}
export declare function comprehendEntityRecognizerInputDataConfigAnnotationsToTerraform(struct?: ComprehendEntityRecognizerInputDataConfigAnnotations | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerInputDataConfigAnnotationsToHclTerraform(struct?: ComprehendEntityRecognizerInputDataConfigAnnotations | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerInputDataConfigAnnotationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendEntityRecognizerInputDataConfigAnnotations | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerInputDataConfigAnnotations | cdktn.IResolvable | undefined);
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    resetS3Uri(): void;
    get s3UriInput(): string | undefined;
    private _testS3Uri?;
    get testS3Uri(): string;
    set testS3Uri(value: string);
    resetTestS3Uri(): void;
    get testS3UriInput(): string | undefined;
}
export interface ComprehendEntityRecognizerInputDataConfigAugmentedManifests {
    /**
    * The S3 prefix to the annotation files that are referred in the augmented manifest file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#annotation_data_s3_uri ComprehendEntityRecognizer#annotation_data_s3_uri}
    */
    readonly annotationDataS3Uri?: string;
    /**
    * The JSON attribute that contains the annotations for your training documents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#attribute_names ComprehendEntityRecognizer#attribute_names}
    */
    readonly attributeNames?: string[];
    /**
    * The type of augmented manifest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#document_type ComprehendEntityRecognizer#document_type}
    */
    readonly documentType?: string;
    /**
    * The Amazon S3 location of the augmented manifest file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#s3_uri ComprehendEntityRecognizer#s3_uri}
    */
    readonly s3Uri?: string;
    /**
    * The S3 prefix to the source files (PDFs) that are referred to in the augmented manifest file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#source_documents_s3_uri ComprehendEntityRecognizer#source_documents_s3_uri}
    */
    readonly sourceDocumentsS3Uri?: string;
    /**
    * The purpose of the data you've provided in the augmented manifest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#split ComprehendEntityRecognizer#split}
    */
    readonly split?: string;
}
export declare function comprehendEntityRecognizerInputDataConfigAugmentedManifestsToTerraform(struct?: ComprehendEntityRecognizerInputDataConfigAugmentedManifests | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerInputDataConfigAugmentedManifestsToHclTerraform(struct?: ComprehendEntityRecognizerInputDataConfigAugmentedManifests | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerInputDataConfigAugmentedManifestsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendEntityRecognizerInputDataConfigAugmentedManifests | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerInputDataConfigAugmentedManifests | cdktn.IResolvable | undefined);
    private _annotationDataS3Uri?;
    get annotationDataS3Uri(): string;
    set annotationDataS3Uri(value: string);
    resetAnnotationDataS3Uri(): void;
    get annotationDataS3UriInput(): string | undefined;
    private _attributeNames?;
    get attributeNames(): string[];
    set attributeNames(value: string[]);
    resetAttributeNames(): void;
    get attributeNamesInput(): string[] | undefined;
    private _documentType?;
    get documentType(): string;
    set documentType(value: string);
    resetDocumentType(): void;
    get documentTypeInput(): string | undefined;
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    resetS3Uri(): void;
    get s3UriInput(): string | undefined;
    private _sourceDocumentsS3Uri?;
    get sourceDocumentsS3Uri(): string;
    set sourceDocumentsS3Uri(value: string);
    resetSourceDocumentsS3Uri(): void;
    get sourceDocumentsS3UriInput(): string | undefined;
    private _split?;
    get split(): string;
    set split(value: string);
    resetSplit(): void;
    get splitInput(): string | undefined;
}
export declare class ComprehendEntityRecognizerInputDataConfigAugmentedManifestsList extends cdktn.ComplexList {
    internalValue?: ComprehendEntityRecognizerInputDataConfigAugmentedManifests[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendEntityRecognizerInputDataConfigAugmentedManifestsOutputReference;
}
export interface ComprehendEntityRecognizerInputDataConfigDocuments {
    /**
    * Specifies how the text in an input file should be processed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#input_format ComprehendEntityRecognizer#input_format}
    */
    readonly inputFormat?: string;
    /**
    * Specifies the Amazon S3 location where the training documents are located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#s3_uri ComprehendEntityRecognizer#s3_uri}
    */
    readonly s3Uri?: string;
    /**
    * Specifies the Amazon S3 location where the test documents are located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#test_s3_uri ComprehendEntityRecognizer#test_s3_uri}
    */
    readonly testS3Uri?: string;
}
export declare function comprehendEntityRecognizerInputDataConfigDocumentsToTerraform(struct?: ComprehendEntityRecognizerInputDataConfigDocuments | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerInputDataConfigDocumentsToHclTerraform(struct?: ComprehendEntityRecognizerInputDataConfigDocuments | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerInputDataConfigDocumentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendEntityRecognizerInputDataConfigDocuments | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerInputDataConfigDocuments | cdktn.IResolvable | undefined);
    private _inputFormat?;
    get inputFormat(): string;
    set inputFormat(value: string);
    resetInputFormat(): void;
    get inputFormatInput(): string | undefined;
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    resetS3Uri(): void;
    get s3UriInput(): string | undefined;
    private _testS3Uri?;
    get testS3Uri(): string;
    set testS3Uri(value: string);
    resetTestS3Uri(): void;
    get testS3UriInput(): string | undefined;
}
export interface ComprehendEntityRecognizerInputDataConfigEntityListStruct {
    /**
    * Specifies the Amazon S3 location where the entity list is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#s3_uri ComprehendEntityRecognizer#s3_uri}
    */
    readonly s3Uri?: string;
}
export declare function comprehendEntityRecognizerInputDataConfigEntityListStructToTerraform(struct?: ComprehendEntityRecognizerInputDataConfigEntityListStruct | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerInputDataConfigEntityListStructToHclTerraform(struct?: ComprehendEntityRecognizerInputDataConfigEntityListStruct | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerInputDataConfigEntityListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendEntityRecognizerInputDataConfigEntityListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerInputDataConfigEntityListStruct | cdktn.IResolvable | undefined);
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    resetS3Uri(): void;
    get s3UriInput(): string | undefined;
}
export interface ComprehendEntityRecognizerInputDataConfigEntityTypes {
    /**
    * An entity type within a labeled training dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#type ComprehendEntityRecognizer#type}
    */
    readonly type: string;
}
export declare function comprehendEntityRecognizerInputDataConfigEntityTypesToTerraform(struct?: ComprehendEntityRecognizerInputDataConfigEntityTypes | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerInputDataConfigEntityTypesToHclTerraform(struct?: ComprehendEntityRecognizerInputDataConfigEntityTypes | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerInputDataConfigEntityTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendEntityRecognizerInputDataConfigEntityTypes | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerInputDataConfigEntityTypes | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ComprehendEntityRecognizerInputDataConfigEntityTypesList extends cdktn.ComplexList {
    internalValue?: ComprehendEntityRecognizerInputDataConfigEntityTypes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendEntityRecognizerInputDataConfigEntityTypesOutputReference;
}
export interface ComprehendEntityRecognizerInputDataConfig {
    /**
    * The S3 location of the CSV file that annotates your training documents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#annotations ComprehendEntityRecognizer#annotations}
    */
    readonly annotations?: ComprehendEntityRecognizerInputDataConfigAnnotations;
    /**
    * A list of augmented manifest files that provide training data for a custom model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#augmented_manifests ComprehendEntityRecognizer#augmented_manifests}
    */
    readonly augmentedManifests?: ComprehendEntityRecognizerInputDataConfigAugmentedManifests[] | cdktn.IResolvable;
    /**
    * The format of your training data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#data_format ComprehendEntityRecognizer#data_format}
    */
    readonly dataFormat?: string;
    /**
    * The S3 location of the folder that contains the training documents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#documents ComprehendEntityRecognizer#documents}
    */
    readonly documents?: ComprehendEntityRecognizerInputDataConfigDocuments;
    /**
    * The S3 location of the CSV file that has the entity list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#entity_list ComprehendEntityRecognizer#entity_list}
    */
    readonly entityList?: ComprehendEntityRecognizerInputDataConfigEntityListStruct;
    /**
    * The entity types in the labeled training data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#entity_types ComprehendEntityRecognizer#entity_types}
    */
    readonly entityTypes: ComprehendEntityRecognizerInputDataConfigEntityTypes[] | cdktn.IResolvable;
}
export declare function comprehendEntityRecognizerInputDataConfigToTerraform(struct?: ComprehendEntityRecognizerInputDataConfig | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerInputDataConfigToHclTerraform(struct?: ComprehendEntityRecognizerInputDataConfig | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerInputDataConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendEntityRecognizerInputDataConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerInputDataConfig | cdktn.IResolvable | undefined);
    private _annotations;
    get annotations(): ComprehendEntityRecognizerInputDataConfigAnnotationsOutputReference;
    putAnnotations(value: ComprehendEntityRecognizerInputDataConfigAnnotations): void;
    resetAnnotations(): void;
    get annotationsInput(): cdktn.IResolvable | ComprehendEntityRecognizerInputDataConfigAnnotations | undefined;
    private _augmentedManifests;
    get augmentedManifests(): ComprehendEntityRecognizerInputDataConfigAugmentedManifestsList;
    putAugmentedManifests(value: ComprehendEntityRecognizerInputDataConfigAugmentedManifests[] | cdktn.IResolvable): void;
    resetAugmentedManifests(): void;
    get augmentedManifestsInput(): cdktn.IResolvable | ComprehendEntityRecognizerInputDataConfigAugmentedManifests[] | undefined;
    private _dataFormat?;
    get dataFormat(): string;
    set dataFormat(value: string);
    resetDataFormat(): void;
    get dataFormatInput(): string | undefined;
    private _documents;
    get documents(): ComprehendEntityRecognizerInputDataConfigDocumentsOutputReference;
    putDocuments(value: ComprehendEntityRecognizerInputDataConfigDocuments): void;
    resetDocuments(): void;
    get documentsInput(): cdktn.IResolvable | ComprehendEntityRecognizerInputDataConfigDocuments | undefined;
    private _entityList;
    get entityList(): ComprehendEntityRecognizerInputDataConfigEntityListStructOutputReference;
    putEntityList(value: ComprehendEntityRecognizerInputDataConfigEntityListStruct): void;
    resetEntityList(): void;
    get entityListInput(): cdktn.IResolvable | ComprehendEntityRecognizerInputDataConfigEntityListStruct | undefined;
    private _entityTypes;
    get entityTypes(): ComprehendEntityRecognizerInputDataConfigEntityTypesList;
    putEntityTypes(value: ComprehendEntityRecognizerInputDataConfigEntityTypes[] | cdktn.IResolvable): void;
    get entityTypesInput(): cdktn.IResolvable | ComprehendEntityRecognizerInputDataConfigEntityTypes[] | undefined;
}
export interface ComprehendEntityRecognizerTags {
    /**
    * The key of the key-value pair that forms a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#key ComprehendEntityRecognizer#key}
    */
    readonly key?: string;
    /**
    * The value of the key-value pair that forms a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#value ComprehendEntityRecognizer#value}
    */
    readonly value?: string;
}
export declare function comprehendEntityRecognizerTagsToTerraform(struct?: ComprehendEntityRecognizerTags | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerTagsToHclTerraform(struct?: ComprehendEntityRecognizerTags | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendEntityRecognizerTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComprehendEntityRecognizerTagsList extends cdktn.ComplexList {
    internalValue?: ComprehendEntityRecognizerTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendEntityRecognizerTagsOutputReference;
}
export interface ComprehendEntityRecognizerVpcConfig {
    /**
    * The ID number for a security group on an instance of your private VPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#security_group_ids ComprehendEntityRecognizer#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * The ID for each subnet being used in your private VPC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#subnets ComprehendEntityRecognizer#subnets}
    */
    readonly subnets?: string[];
}
export declare function comprehendEntityRecognizerVpcConfigToTerraform(struct?: ComprehendEntityRecognizerVpcConfig | cdktn.IResolvable): any;
export declare function comprehendEntityRecognizerVpcConfigToHclTerraform(struct?: ComprehendEntityRecognizerVpcConfig | cdktn.IResolvable): any;
export declare class ComprehendEntityRecognizerVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComprehendEntityRecognizerVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendEntityRecognizerVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer awscc_comprehend_entity_recognizer}
*/
export declare class ComprehendEntityRecognizer extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_comprehend_entity_recognizer";
    /**
    * Generates CDKTN code for importing a ComprehendEntityRecognizer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComprehendEntityRecognizer to import
    * @param importFromId The id of the existing ComprehendEntityRecognizer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComprehendEntityRecognizer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_entity_recognizer awscc_comprehend_entity_recognizer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComprehendEntityRecognizerConfig
    */
    constructor(scope: Construct, id: string, config: ComprehendEntityRecognizerConfig);
    get arn(): string;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    get dataAccessRoleArnInput(): string | undefined;
    get id(): string;
    private _inputDataConfig;
    get inputDataConfig(): ComprehendEntityRecognizerInputDataConfigOutputReference;
    putInputDataConfig(value: ComprehendEntityRecognizerInputDataConfig): void;
    get inputDataConfigInput(): cdktn.IResolvable | ComprehendEntityRecognizerInputDataConfig | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    private _modelKmsKeyId?;
    get modelKmsKeyId(): string;
    set modelKmsKeyId(value: string);
    resetModelKmsKeyId(): void;
    get modelKmsKeyIdInput(): string | undefined;
    private _modelPolicy?;
    get modelPolicy(): string;
    set modelPolicy(value: string);
    resetModelPolicy(): void;
    get modelPolicyInput(): string | undefined;
    private _recognizerName?;
    get recognizerName(): string;
    set recognizerName(value: string);
    get recognizerNameInput(): string | undefined;
    private _tags;
    get tags(): ComprehendEntityRecognizerTagsList;
    putTags(value: ComprehendEntityRecognizerTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ComprehendEntityRecognizerTags[] | undefined;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    resetVersionName(): void;
    get versionNameInput(): string | undefined;
    private _volumeKmsKeyId?;
    get volumeKmsKeyId(): string;
    set volumeKmsKeyId(value: string);
    resetVolumeKmsKeyId(): void;
    get volumeKmsKeyIdInput(): string | undefined;
    private _vpcConfig;
    get vpcConfig(): ComprehendEntityRecognizerVpcConfigOutputReference;
    putVpcConfig(value: ComprehendEntityRecognizerVpcConfig): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | ComprehendEntityRecognizerVpcConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
