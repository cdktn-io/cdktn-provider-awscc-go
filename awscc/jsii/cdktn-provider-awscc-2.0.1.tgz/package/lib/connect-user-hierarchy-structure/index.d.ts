/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectUserHierarchyStructureConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#instance_arn ConnectUserHierarchyStructure#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Information about the hierarchy structure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#user_hierarchy_structure ConnectUserHierarchyStructure#user_hierarchy_structure}
    */
    readonly userHierarchyStructure?: ConnectUserHierarchyStructureUserHierarchyStructure;
}
export interface ConnectUserHierarchyStructureUserHierarchyStructureLevelFive {
    /**
    * The Amazon Resource Name (ARN) of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_arn ConnectUserHierarchyStructure#hierarchy_level_arn}
    */
    readonly hierarchyLevelArn?: string;
    /**
    * The identifier of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_id ConnectUserHierarchyStructure#hierarchy_level_id}
    */
    readonly hierarchyLevelId?: string;
    /**
    * The name of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#name ConnectUserHierarchyStructure#name}
    */
    readonly name?: string;
}
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelFiveToTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelFive | cdktn.IResolvable): any;
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelFiveToHclTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelFive | cdktn.IResolvable): any;
export declare class ConnectUserHierarchyStructureUserHierarchyStructureLevelFiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserHierarchyStructureUserHierarchyStructureLevelFive | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelFive | cdktn.IResolvable | undefined);
    private _hierarchyLevelArn?;
    get hierarchyLevelArn(): string;
    set hierarchyLevelArn(value: string);
    resetHierarchyLevelArn(): void;
    get hierarchyLevelArnInput(): string | undefined;
    private _hierarchyLevelId?;
    get hierarchyLevelId(): string;
    set hierarchyLevelId(value: string);
    resetHierarchyLevelId(): void;
    get hierarchyLevelIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectUserHierarchyStructureUserHierarchyStructureLevelFour {
    /**
    * The Amazon Resource Name (ARN) of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_arn ConnectUserHierarchyStructure#hierarchy_level_arn}
    */
    readonly hierarchyLevelArn?: string;
    /**
    * The identifier of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_id ConnectUserHierarchyStructure#hierarchy_level_id}
    */
    readonly hierarchyLevelId?: string;
    /**
    * The name of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#name ConnectUserHierarchyStructure#name}
    */
    readonly name?: string;
}
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelFourToTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelFour | cdktn.IResolvable): any;
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelFourToHclTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelFour | cdktn.IResolvable): any;
export declare class ConnectUserHierarchyStructureUserHierarchyStructureLevelFourOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserHierarchyStructureUserHierarchyStructureLevelFour | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelFour | cdktn.IResolvable | undefined);
    private _hierarchyLevelArn?;
    get hierarchyLevelArn(): string;
    set hierarchyLevelArn(value: string);
    resetHierarchyLevelArn(): void;
    get hierarchyLevelArnInput(): string | undefined;
    private _hierarchyLevelId?;
    get hierarchyLevelId(): string;
    set hierarchyLevelId(value: string);
    resetHierarchyLevelId(): void;
    get hierarchyLevelIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectUserHierarchyStructureUserHierarchyStructureLevelOne {
    /**
    * The Amazon Resource Name (ARN) of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_arn ConnectUserHierarchyStructure#hierarchy_level_arn}
    */
    readonly hierarchyLevelArn?: string;
    /**
    * The identifier of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_id ConnectUserHierarchyStructure#hierarchy_level_id}
    */
    readonly hierarchyLevelId?: string;
    /**
    * The name of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#name ConnectUserHierarchyStructure#name}
    */
    readonly name?: string;
}
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelOneToTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelOne | cdktn.IResolvable): any;
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelOneToHclTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelOne | cdktn.IResolvable): any;
export declare class ConnectUserHierarchyStructureUserHierarchyStructureLevelOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserHierarchyStructureUserHierarchyStructureLevelOne | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelOne | cdktn.IResolvable | undefined);
    private _hierarchyLevelArn?;
    get hierarchyLevelArn(): string;
    set hierarchyLevelArn(value: string);
    resetHierarchyLevelArn(): void;
    get hierarchyLevelArnInput(): string | undefined;
    private _hierarchyLevelId?;
    get hierarchyLevelId(): string;
    set hierarchyLevelId(value: string);
    resetHierarchyLevelId(): void;
    get hierarchyLevelIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectUserHierarchyStructureUserHierarchyStructureLevelThree {
    /**
    * The Amazon Resource Name (ARN) of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_arn ConnectUserHierarchyStructure#hierarchy_level_arn}
    */
    readonly hierarchyLevelArn?: string;
    /**
    * The identifier of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_id ConnectUserHierarchyStructure#hierarchy_level_id}
    */
    readonly hierarchyLevelId?: string;
    /**
    * The name of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#name ConnectUserHierarchyStructure#name}
    */
    readonly name?: string;
}
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelThreeToTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelThree | cdktn.IResolvable): any;
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelThreeToHclTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelThree | cdktn.IResolvable): any;
export declare class ConnectUserHierarchyStructureUserHierarchyStructureLevelThreeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserHierarchyStructureUserHierarchyStructureLevelThree | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelThree | cdktn.IResolvable | undefined);
    private _hierarchyLevelArn?;
    get hierarchyLevelArn(): string;
    set hierarchyLevelArn(value: string);
    resetHierarchyLevelArn(): void;
    get hierarchyLevelArnInput(): string | undefined;
    private _hierarchyLevelId?;
    get hierarchyLevelId(): string;
    set hierarchyLevelId(value: string);
    resetHierarchyLevelId(): void;
    get hierarchyLevelIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectUserHierarchyStructureUserHierarchyStructureLevelTwo {
    /**
    * The Amazon Resource Name (ARN) of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_arn ConnectUserHierarchyStructure#hierarchy_level_arn}
    */
    readonly hierarchyLevelArn?: string;
    /**
    * The identifier of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#hierarchy_level_id ConnectUserHierarchyStructure#hierarchy_level_id}
    */
    readonly hierarchyLevelId?: string;
    /**
    * The name of the hierarchy level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#name ConnectUserHierarchyStructure#name}
    */
    readonly name?: string;
}
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelTwoToTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelTwo | cdktn.IResolvable): any;
export declare function connectUserHierarchyStructureUserHierarchyStructureLevelTwoToHclTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructureLevelTwo | cdktn.IResolvable): any;
export declare class ConnectUserHierarchyStructureUserHierarchyStructureLevelTwoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserHierarchyStructureUserHierarchyStructureLevelTwo | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelTwo | cdktn.IResolvable | undefined);
    private _hierarchyLevelArn?;
    get hierarchyLevelArn(): string;
    set hierarchyLevelArn(value: string);
    resetHierarchyLevelArn(): void;
    get hierarchyLevelArnInput(): string | undefined;
    private _hierarchyLevelId?;
    get hierarchyLevelId(): string;
    set hierarchyLevelId(value: string);
    resetHierarchyLevelId(): void;
    get hierarchyLevelIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface ConnectUserHierarchyStructureUserHierarchyStructure {
    /**
    * Information about level five.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#level_five ConnectUserHierarchyStructure#level_five}
    */
    readonly levelFive?: ConnectUserHierarchyStructureUserHierarchyStructureLevelFive;
    /**
    * Information about level four.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#level_four ConnectUserHierarchyStructure#level_four}
    */
    readonly levelFour?: ConnectUserHierarchyStructureUserHierarchyStructureLevelFour;
    /**
    * Information about level one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#level_one ConnectUserHierarchyStructure#level_one}
    */
    readonly levelOne?: ConnectUserHierarchyStructureUserHierarchyStructureLevelOne;
    /**
    * Information about level three.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#level_three ConnectUserHierarchyStructure#level_three}
    */
    readonly levelThree?: ConnectUserHierarchyStructureUserHierarchyStructureLevelThree;
    /**
    * Information about level two.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#level_two ConnectUserHierarchyStructure#level_two}
    */
    readonly levelTwo?: ConnectUserHierarchyStructureUserHierarchyStructureLevelTwo;
}
export declare function connectUserHierarchyStructureUserHierarchyStructureToTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructure | cdktn.IResolvable): any;
export declare function connectUserHierarchyStructureUserHierarchyStructureToHclTerraform(struct?: ConnectUserHierarchyStructureUserHierarchyStructure | cdktn.IResolvable): any;
export declare class ConnectUserHierarchyStructureUserHierarchyStructureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserHierarchyStructureUserHierarchyStructure | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserHierarchyStructureUserHierarchyStructure | cdktn.IResolvable | undefined);
    private _levelFive;
    get levelFive(): ConnectUserHierarchyStructureUserHierarchyStructureLevelFiveOutputReference;
    putLevelFive(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelFive): void;
    resetLevelFive(): void;
    get levelFiveInput(): cdktn.IResolvable | ConnectUserHierarchyStructureUserHierarchyStructureLevelFive | undefined;
    private _levelFour;
    get levelFour(): ConnectUserHierarchyStructureUserHierarchyStructureLevelFourOutputReference;
    putLevelFour(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelFour): void;
    resetLevelFour(): void;
    get levelFourInput(): cdktn.IResolvable | ConnectUserHierarchyStructureUserHierarchyStructureLevelFour | undefined;
    private _levelOne;
    get levelOne(): ConnectUserHierarchyStructureUserHierarchyStructureLevelOneOutputReference;
    putLevelOne(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelOne): void;
    resetLevelOne(): void;
    get levelOneInput(): cdktn.IResolvable | ConnectUserHierarchyStructureUserHierarchyStructureLevelOne | undefined;
    private _levelThree;
    get levelThree(): ConnectUserHierarchyStructureUserHierarchyStructureLevelThreeOutputReference;
    putLevelThree(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelThree): void;
    resetLevelThree(): void;
    get levelThreeInput(): cdktn.IResolvable | ConnectUserHierarchyStructureUserHierarchyStructureLevelThree | undefined;
    private _levelTwo;
    get levelTwo(): ConnectUserHierarchyStructureUserHierarchyStructureLevelTwoOutputReference;
    putLevelTwo(value: ConnectUserHierarchyStructureUserHierarchyStructureLevelTwo): void;
    resetLevelTwo(): void;
    get levelTwoInput(): cdktn.IResolvable | ConnectUserHierarchyStructureUserHierarchyStructureLevelTwo | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure awscc_connect_user_hierarchy_structure}
*/
export declare class ConnectUserHierarchyStructure extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_user_hierarchy_structure";
    /**
    * Generates CDKTN code for importing a ConnectUserHierarchyStructure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectUserHierarchyStructure to import
    * @param importFromId The id of the existing ConnectUserHierarchyStructure that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectUserHierarchyStructure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user_hierarchy_structure awscc_connect_user_hierarchy_structure} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectUserHierarchyStructureConfig
    */
    constructor(scope: Construct, id: string, config: ConnectUserHierarchyStructureConfig);
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _userHierarchyStructure;
    get userHierarchyStructure(): ConnectUserHierarchyStructureUserHierarchyStructureOutputReference;
    putUserHierarchyStructure(value: ConnectUserHierarchyStructureUserHierarchyStructure): void;
    resetUserHierarchyStructure(): void;
    get userHierarchyStructureInput(): cdktn.IResolvable | ConnectUserHierarchyStructureUserHierarchyStructure | undefined;
    get userHierarchyStructureArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
