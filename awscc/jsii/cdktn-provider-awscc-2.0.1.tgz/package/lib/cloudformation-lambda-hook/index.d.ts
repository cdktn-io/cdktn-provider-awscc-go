/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationLambdaHookConfig extends cdktn.TerraformMetaArguments {
    /**
    * The typename alias for the hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#alias CloudformationLambdaHook#alias}
    */
    readonly alias: string;
    /**
    * Whether to automatically update the extension in this account and Region when a new minor version is published by the extension publisher.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#auto_update CloudformationLambdaHook#auto_update}
    */
    readonly autoUpdate?: boolean | cdktn.IResolvable;
    /**
    * The execution role ARN assumed by Hooks to invoke Lambda.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#execution_role CloudformationLambdaHook#execution_role}
    */
    readonly executionRole: string;
    /**
    * Attribute to specify CloudFormation behavior on hook failure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#failure_mode CloudformationLambdaHook#failure_mode}
    */
    readonly failureMode: string;
    /**
    * Attribute to specify which stacks this hook applies to or should get invoked for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#hook_status CloudformationLambdaHook#hook_status}
    */
    readonly hookStatus?: string;
    /**
    * Amazon Resource Name (ARN), Partial ARN, name, version, or alias of the Lambda function to invoke with this hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#lambda_function CloudformationLambdaHook#lambda_function}
    */
    readonly lambdaFunction: string;
    /**
    * Contains logging configuration information for the hook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#logging_config CloudformationLambdaHook#logging_config}
    */
    readonly loggingConfig?: CloudformationLambdaHookLoggingConfig;
    /**
    * Filters to allow hooks to target specific stack attributes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#stack_filters CloudformationLambdaHook#stack_filters}
    */
    readonly stackFilters?: CloudformationLambdaHookStackFilters;
    /**
    * Attribute to specify which targets should invoke the hook
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#target_filters CloudformationLambdaHook#target_filters}
    */
    readonly targetFilters?: CloudformationLambdaHookTargetFilters;
    /**
    * Which operations should this Hook run against? Resource changes, stacks or change sets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#target_operations CloudformationLambdaHook#target_operations}
    */
    readonly targetOperations: string[];
}
export interface CloudformationLambdaHookLoggingConfig {
    /**
    * The Amazon CloudWatch Logs group to which CloudFormation sends error logging information when invoking the extension's handlers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#log_group_name CloudformationLambdaHook#log_group_name}
    */
    readonly logGroupName?: string;
    /**
    * The ARN of the role that CloudFormation should assume when sending log entries to CloudWatch Logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#log_role_arn CloudformationLambdaHook#log_role_arn}
    */
    readonly logRoleArn?: string;
}
export declare function cloudformationLambdaHookLoggingConfigToTerraform(struct?: CloudformationLambdaHookLoggingConfig | cdktn.IResolvable): any;
export declare function cloudformationLambdaHookLoggingConfigToHclTerraform(struct?: CloudformationLambdaHookLoggingConfig | cdktn.IResolvable): any;
export declare class CloudformationLambdaHookLoggingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationLambdaHookLoggingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationLambdaHookLoggingConfig | cdktn.IResolvable | undefined);
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    resetLogGroupName(): void;
    get logGroupNameInput(): string | undefined;
    private _logRoleArn?;
    get logRoleArn(): string;
    set logRoleArn(value: string);
    resetLogRoleArn(): void;
    get logRoleArnInput(): string | undefined;
}
export interface CloudformationLambdaHookStackFiltersStackNames {
    /**
    * List of stack names that the hook is going to be excluded from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#exclude CloudformationLambdaHook#exclude}
    */
    readonly exclude?: string[];
    /**
    * List of stack names that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#include CloudformationLambdaHook#include}
    */
    readonly include?: string[];
}
export declare function cloudformationLambdaHookStackFiltersStackNamesToTerraform(struct?: CloudformationLambdaHookStackFiltersStackNames | cdktn.IResolvable): any;
export declare function cloudformationLambdaHookStackFiltersStackNamesToHclTerraform(struct?: CloudformationLambdaHookStackFiltersStackNames | cdktn.IResolvable): any;
export declare class CloudformationLambdaHookStackFiltersStackNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationLambdaHookStackFiltersStackNames | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationLambdaHookStackFiltersStackNames | cdktn.IResolvable | undefined);
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface CloudformationLambdaHookStackFiltersStackRoles {
    /**
    * List of stack roles that the hook is going to be excluded from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#exclude CloudformationLambdaHook#exclude}
    */
    readonly exclude?: string[];
    /**
    * List of stack roles that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#include CloudformationLambdaHook#include}
    */
    readonly include?: string[];
}
export declare function cloudformationLambdaHookStackFiltersStackRolesToTerraform(struct?: CloudformationLambdaHookStackFiltersStackRoles | cdktn.IResolvable): any;
export declare function cloudformationLambdaHookStackFiltersStackRolesToHclTerraform(struct?: CloudformationLambdaHookStackFiltersStackRoles | cdktn.IResolvable): any;
export declare class CloudformationLambdaHookStackFiltersStackRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationLambdaHookStackFiltersStackRoles | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationLambdaHookStackFiltersStackRoles | cdktn.IResolvable | undefined);
    private _exclude?;
    get exclude(): string[];
    set exclude(value: string[]);
    resetExclude(): void;
    get excludeInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface CloudformationLambdaHookStackFilters {
    /**
    * Attribute to specify the filtering behavior. ANY will make the Hook pass if one filter matches. ALL will make the Hook pass if all filters match
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#filtering_criteria CloudformationLambdaHook#filtering_criteria}
    */
    readonly filteringCriteria?: string;
    /**
    * List of stack names as filters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#stack_names CloudformationLambdaHook#stack_names}
    */
    readonly stackNames?: CloudformationLambdaHookStackFiltersStackNames;
    /**
    * List of stack roles that are performing the stack operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#stack_roles CloudformationLambdaHook#stack_roles}
    */
    readonly stackRoles?: CloudformationLambdaHookStackFiltersStackRoles;
}
export declare function cloudformationLambdaHookStackFiltersToTerraform(struct?: CloudformationLambdaHookStackFilters | cdktn.IResolvable): any;
export declare function cloudformationLambdaHookStackFiltersToHclTerraform(struct?: CloudformationLambdaHookStackFilters | cdktn.IResolvable): any;
export declare class CloudformationLambdaHookStackFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationLambdaHookStackFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationLambdaHookStackFilters | cdktn.IResolvable | undefined);
    private _filteringCriteria?;
    get filteringCriteria(): string;
    set filteringCriteria(value: string);
    resetFilteringCriteria(): void;
    get filteringCriteriaInput(): string | undefined;
    private _stackNames;
    get stackNames(): CloudformationLambdaHookStackFiltersStackNamesOutputReference;
    putStackNames(value: CloudformationLambdaHookStackFiltersStackNames): void;
    resetStackNames(): void;
    get stackNamesInput(): cdktn.IResolvable | CloudformationLambdaHookStackFiltersStackNames | undefined;
    private _stackRoles;
    get stackRoles(): CloudformationLambdaHookStackFiltersStackRolesOutputReference;
    putStackRoles(value: CloudformationLambdaHookStackFiltersStackRoles): void;
    resetStackRoles(): void;
    get stackRolesInput(): cdktn.IResolvable | CloudformationLambdaHookStackFiltersStackRoles | undefined;
}
export interface CloudformationLambdaHookTargetFiltersTargets {
    /**
    * Target actions are the type of operation hooks will be executed at.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#action CloudformationLambdaHook#action}
    */
    readonly action?: string;
    /**
    * Invocation points are the point in provisioning workflow where hooks will be executed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#invocation_point CloudformationLambdaHook#invocation_point}
    */
    readonly invocationPoint?: string;
    /**
    * Type name of hook target. Hook targets are the destination where hooks will be invoked against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#target_name CloudformationLambdaHook#target_name}
    */
    readonly targetName?: string;
}
export declare function cloudformationLambdaHookTargetFiltersTargetsToTerraform(struct?: CloudformationLambdaHookTargetFiltersTargets | cdktn.IResolvable): any;
export declare function cloudformationLambdaHookTargetFiltersTargetsToHclTerraform(struct?: CloudformationLambdaHookTargetFiltersTargets | cdktn.IResolvable): any;
export declare class CloudformationLambdaHookTargetFiltersTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationLambdaHookTargetFiltersTargets | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationLambdaHookTargetFiltersTargets | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _invocationPoint?;
    get invocationPoint(): string;
    set invocationPoint(value: string);
    resetInvocationPoint(): void;
    get invocationPointInput(): string | undefined;
    private _targetName?;
    get targetName(): string;
    set targetName(value: string);
    resetTargetName(): void;
    get targetNameInput(): string | undefined;
}
export declare class CloudformationLambdaHookTargetFiltersTargetsList extends cdktn.ComplexList {
    internalValue?: CloudformationLambdaHookTargetFiltersTargets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationLambdaHookTargetFiltersTargetsOutputReference;
}
export interface CloudformationLambdaHookTargetFilters {
    /**
    * List of actions that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#actions CloudformationLambdaHook#actions}
    */
    readonly actions?: string[];
    /**
    * List of invocation points that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#invocation_points CloudformationLambdaHook#invocation_points}
    */
    readonly invocationPoints?: string[];
    /**
    * List of type names that the hook is going to target
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#target_names CloudformationLambdaHook#target_names}
    */
    readonly targetNames?: string[];
    /**
    * List of hook targets
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#targets CloudformationLambdaHook#targets}
    */
    readonly targets?: CloudformationLambdaHookTargetFiltersTargets[] | cdktn.IResolvable;
}
export declare function cloudformationLambdaHookTargetFiltersToTerraform(struct?: CloudformationLambdaHookTargetFilters | cdktn.IResolvable): any;
export declare function cloudformationLambdaHookTargetFiltersToHclTerraform(struct?: CloudformationLambdaHookTargetFilters | cdktn.IResolvable): any;
export declare class CloudformationLambdaHookTargetFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationLambdaHookTargetFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationLambdaHookTargetFilters | cdktn.IResolvable | undefined);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    resetActions(): void;
    get actionsInput(): string[] | undefined;
    private _invocationPoints?;
    get invocationPoints(): string[];
    set invocationPoints(value: string[]);
    resetInvocationPoints(): void;
    get invocationPointsInput(): string[] | undefined;
    private _targetNames?;
    get targetNames(): string[];
    set targetNames(value: string[]);
    resetTargetNames(): void;
    get targetNamesInput(): string[] | undefined;
    private _targets;
    get targets(): CloudformationLambdaHookTargetFiltersTargetsList;
    putTargets(value: CloudformationLambdaHookTargetFiltersTargets[] | cdktn.IResolvable): void;
    resetTargets(): void;
    get targetsInput(): cdktn.IResolvable | CloudformationLambdaHookTargetFiltersTargets[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook awscc_cloudformation_lambda_hook}
*/
export declare class CloudformationLambdaHook extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_lambda_hook";
    /**
    * Generates CDKTN code for importing a CloudformationLambdaHook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationLambdaHook to import
    * @param importFromId The id of the existing CloudformationLambdaHook that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationLambdaHook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_lambda_hook awscc_cloudformation_lambda_hook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationLambdaHookConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationLambdaHookConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    get aliasInput(): string | undefined;
    private _autoUpdate?;
    get autoUpdate(): boolean | cdktn.IResolvable;
    set autoUpdate(value: boolean | cdktn.IResolvable);
    resetAutoUpdate(): void;
    get autoUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    get executionRoleInput(): string | undefined;
    private _failureMode?;
    get failureMode(): string;
    set failureMode(value: string);
    get failureModeInput(): string | undefined;
    get hookArn(): string;
    private _hookStatus?;
    get hookStatus(): string;
    set hookStatus(value: string);
    resetHookStatus(): void;
    get hookStatusInput(): string | undefined;
    get id(): string;
    private _lambdaFunction?;
    get lambdaFunction(): string;
    set lambdaFunction(value: string);
    get lambdaFunctionInput(): string | undefined;
    private _loggingConfig;
    get loggingConfig(): CloudformationLambdaHookLoggingConfigOutputReference;
    putLoggingConfig(value: CloudformationLambdaHookLoggingConfig): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): cdktn.IResolvable | CloudformationLambdaHookLoggingConfig | undefined;
    private _stackFilters;
    get stackFilters(): CloudformationLambdaHookStackFiltersOutputReference;
    putStackFilters(value: CloudformationLambdaHookStackFilters): void;
    resetStackFilters(): void;
    get stackFiltersInput(): cdktn.IResolvable | CloudformationLambdaHookStackFilters | undefined;
    private _targetFilters;
    get targetFilters(): CloudformationLambdaHookTargetFiltersOutputReference;
    putTargetFilters(value: CloudformationLambdaHookTargetFilters): void;
    resetTargetFilters(): void;
    get targetFiltersInput(): cdktn.IResolvable | CloudformationLambdaHookTargetFilters | undefined;
    private _targetOperations?;
    get targetOperations(): string[];
    set targetOperations(value: string[]);
    get targetOperationsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
