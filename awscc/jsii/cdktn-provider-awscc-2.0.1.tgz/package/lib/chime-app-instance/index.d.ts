/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeAppInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The metadata of the AppInstance. Limited to a 1KB string in UTF-8.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance#metadata ChimeAppInstance#metadata}
    */
    readonly metadata?: string;
    /**
    * The name of the AppInstance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance#name ChimeAppInstance#name}
    */
    readonly name: string;
    /**
    * Tags assigned to the AppInstance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance#tags ChimeAppInstance#tags}
    */
    readonly tags?: ChimeAppInstanceTags[] | cdktn.IResolvable;
}
export interface ChimeAppInstanceTags {
    /**
    * The key in a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance#key ChimeAppInstance#key}
    */
    readonly key?: string;
    /**
    * The value in a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance#value ChimeAppInstance#value}
    */
    readonly value?: string;
}
export declare function chimeAppInstanceTagsToTerraform(struct?: ChimeAppInstanceTags | cdktn.IResolvable): any;
export declare function chimeAppInstanceTagsToHclTerraform(struct?: ChimeAppInstanceTags | cdktn.IResolvable): any;
export declare class ChimeAppInstanceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeAppInstanceTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeAppInstanceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeAppInstanceTagsList extends cdktn.ComplexList {
    internalValue?: ChimeAppInstanceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeAppInstanceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance awscc_chime_app_instance}
*/
export declare class ChimeAppInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_app_instance";
    /**
    * Generates CDKTN code for importing a ChimeAppInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeAppInstance to import
    * @param importFromId The id of the existing ChimeAppInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeAppInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance awscc_chime_app_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeAppInstanceConfig
    */
    constructor(scope: Construct, id: string, config: ChimeAppInstanceConfig);
    get appInstanceArn(): string;
    get createdTimestamp(): string;
    get id(): string;
    get lastUpdatedTimestamp(): string;
    private _metadata?;
    get metadata(): string;
    set metadata(value: string);
    resetMetadata(): void;
    get metadataInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): ChimeAppInstanceTagsList;
    putTags(value: ChimeAppInstanceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeAppInstanceTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
