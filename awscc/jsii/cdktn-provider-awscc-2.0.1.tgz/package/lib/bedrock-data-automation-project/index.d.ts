/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockDataAutomationProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Custom output configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#custom_output_configuration BedrockDataAutomationProject#custom_output_configuration}
    */
    readonly customOutputConfiguration?: BedrockDataAutomationProjectCustomOutputConfiguration;
    /**
    * KMS encryption context
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#kms_encryption_context BedrockDataAutomationProject#kms_encryption_context}
    */
    readonly kmsEncryptionContext?: {
        [key: string]: string;
    };
    /**
    * KMS key identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#kms_key_id BedrockDataAutomationProject#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Override configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#override_configuration BedrockDataAutomationProject#override_configuration}
    */
    readonly overrideConfiguration?: BedrockDataAutomationProjectOverrideConfiguration;
    /**
    * Description of the DataAutomationProject
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#project_description BedrockDataAutomationProject#project_description}
    */
    readonly projectDescription?: string;
    /**
    * Name of the DataAutomationProject
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#project_name BedrockDataAutomationProject#project_name}
    */
    readonly projectName: string;
    /**
    * Type of the DataAutomationProject - Sync or Async
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#project_type BedrockDataAutomationProject#project_type}
    */
    readonly projectType?: string;
    /**
    * Standard output configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#standard_output_configuration BedrockDataAutomationProject#standard_output_configuration}
    */
    readonly standardOutputConfiguration?: BedrockDataAutomationProjectStandardOutputConfiguration;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#tags BedrockDataAutomationProject#tags}
    */
    readonly tags?: BedrockDataAutomationProjectTags[] | cdktn.IResolvable;
}
export interface BedrockDataAutomationProjectCustomOutputConfigurationBlueprints {
    /**
    * ARN of a Blueprint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#blueprint_arn BedrockDataAutomationProject#blueprint_arn}
    */
    readonly blueprintArn?: string;
    /**
    * Stage of the Blueprint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#blueprint_stage BedrockDataAutomationProject#blueprint_stage}
    */
    readonly blueprintStage?: string;
    /**
    * Blueprint Version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#blueprint_version BedrockDataAutomationProject#blueprint_version}
    */
    readonly blueprintVersion?: string;
}
export declare function bedrockDataAutomationProjectCustomOutputConfigurationBlueprintsToTerraform(struct?: BedrockDataAutomationProjectCustomOutputConfigurationBlueprints | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectCustomOutputConfigurationBlueprintsToHclTerraform(struct?: BedrockDataAutomationProjectCustomOutputConfigurationBlueprints | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectCustomOutputConfigurationBlueprintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataAutomationProjectCustomOutputConfigurationBlueprints | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectCustomOutputConfigurationBlueprints | cdktn.IResolvable | undefined);
    private _blueprintArn?;
    get blueprintArn(): string;
    set blueprintArn(value: string);
    resetBlueprintArn(): void;
    get blueprintArnInput(): string | undefined;
    private _blueprintStage?;
    get blueprintStage(): string;
    set blueprintStage(value: string);
    resetBlueprintStage(): void;
    get blueprintStageInput(): string | undefined;
    private _blueprintVersion?;
    get blueprintVersion(): string;
    set blueprintVersion(value: string);
    resetBlueprintVersion(): void;
    get blueprintVersionInput(): string | undefined;
}
export declare class BedrockDataAutomationProjectCustomOutputConfigurationBlueprintsList extends cdktn.ComplexList {
    internalValue?: BedrockDataAutomationProjectCustomOutputConfigurationBlueprints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataAutomationProjectCustomOutputConfigurationBlueprintsOutputReference;
}
export interface BedrockDataAutomationProjectCustomOutputConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#blueprints BedrockDataAutomationProject#blueprints}
    */
    readonly blueprints?: BedrockDataAutomationProjectCustomOutputConfigurationBlueprints[] | cdktn.IResolvable;
}
export declare function bedrockDataAutomationProjectCustomOutputConfigurationToTerraform(struct?: BedrockDataAutomationProjectCustomOutputConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectCustomOutputConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectCustomOutputConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectCustomOutputConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectCustomOutputConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectCustomOutputConfiguration | cdktn.IResolvable | undefined);
    private _blueprints;
    get blueprints(): BedrockDataAutomationProjectCustomOutputConfigurationBlueprintsList;
    putBlueprints(value: BedrockDataAutomationProjectCustomOutputConfigurationBlueprints[] | cdktn.IResolvable): void;
    resetBlueprints(): void;
    get blueprintsInput(): cdktn.IResolvable | BedrockDataAutomationProjectCustomOutputConfigurationBlueprints[] | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#generative_output_language BedrockDataAutomationProject#generative_output_language}
    */
    readonly generativeOutputLanguage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#identify_multiple_languages BedrockDataAutomationProject#identify_multiple_languages}
    */
    readonly identifyMultipleLanguages?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#input_languages BedrockDataAutomationProject#input_languages}
    */
    readonly inputLanguages?: string[];
}
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfiguration | cdktn.IResolvable | undefined);
    private _generativeOutputLanguage?;
    get generativeOutputLanguage(): string;
    set generativeOutputLanguage(value: string);
    resetGenerativeOutputLanguage(): void;
    get generativeOutputLanguageInput(): string | undefined;
    private _identifyMultipleLanguages?;
    get identifyMultipleLanguages(): boolean | cdktn.IResolvable;
    set identifyMultipleLanguages(value: boolean | cdktn.IResolvable);
    resetIdentifyMultipleLanguages(): void;
    get identifyMultipleLanguagesInput(): boolean | cdktn.IResolvable | undefined;
    private _inputLanguages?;
    get inputLanguages(): string[];
    set inputLanguages(value: string[]);
    resetInputLanguages(): void;
    get inputLanguagesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessingToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessing | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessingToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessing | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessing | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessing | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#pii_entity_types BedrockDataAutomationProject#pii_entity_types}
    */
    readonly piiEntityTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#redaction_mask_mode BedrockDataAutomationProject#redaction_mask_mode}
    */
    readonly redactionMaskMode?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable | undefined);
    private _piiEntityTypes?;
    get piiEntityTypes(): string[];
    set piiEntityTypes(value: string[]);
    resetPiiEntityTypes(): void;
    get piiEntityTypesInput(): string[] | undefined;
    private _redactionMaskMode?;
    get redactionMaskMode(): string;
    set redactionMaskMode(value: string);
    resetRedactionMaskMode(): void;
    get redactionMaskModeInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#detection_mode BedrockDataAutomationProject#detection_mode}
    */
    readonly detectionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#detection_scope BedrockDataAutomationProject#detection_scope}
    */
    readonly detectionScope?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#pii_entities_configuration BedrockDataAutomationProject#pii_entities_configuration}
    */
    readonly piiEntitiesConfiguration?: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfiguration;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfiguration | cdktn.IResolvable | undefined);
    private _detectionMode?;
    get detectionMode(): string;
    set detectionMode(value: string);
    resetDetectionMode(): void;
    get detectionModeInput(): string | undefined;
    private _detectionScope?;
    get detectionScope(): string[];
    set detectionScope(value: string[]);
    resetDetectionScope(): void;
    get detectionScopeInput(): string[] | undefined;
    private _piiEntitiesConfiguration;
    get piiEntitiesConfiguration(): BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfigurationOutputReference;
    putPiiEntitiesConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfiguration): void;
    resetPiiEntitiesConfiguration(): void;
    get piiEntitiesConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationPiiEntitiesConfiguration | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationAudio {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#language_configuration BedrockDataAutomationProject#language_configuration}
    */
    readonly languageConfiguration?: BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#modality_processing BedrockDataAutomationProject#modality_processing}
    */
    readonly modalityProcessing?: BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessing;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#sensitive_data_configuration BedrockDataAutomationProject#sensitive_data_configuration}
    */
    readonly sensitiveDataConfiguration?: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfiguration;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudio | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationAudioToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationAudio | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationAudioOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationAudio | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationAudio | cdktn.IResolvable | undefined);
    private _languageConfiguration;
    get languageConfiguration(): BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfigurationOutputReference;
    putLanguageConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfiguration): void;
    resetLanguageConfiguration(): void;
    get languageConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationAudioLanguageConfiguration | undefined;
    private _modalityProcessing;
    get modalityProcessing(): BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessingOutputReference;
    putModalityProcessing(value: BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessing): void;
    resetModalityProcessing(): void;
    get modalityProcessingInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationAudioModalityProcessing | undefined;
    private _sensitiveDataConfiguration;
    get sensitiveDataConfiguration(): BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfigurationOutputReference;
    putSensitiveDataConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfiguration): void;
    resetSensitiveDataConfiguration(): void;
    get sensitiveDataConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationAudioSensitiveDataConfiguration | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessingToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessing | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessingToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessing | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessing | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessing | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#pii_entity_types BedrockDataAutomationProject#pii_entity_types}
    */
    readonly piiEntityTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#redaction_mask_mode BedrockDataAutomationProject#redaction_mask_mode}
    */
    readonly redactionMaskMode?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable | undefined);
    private _piiEntityTypes?;
    get piiEntityTypes(): string[];
    set piiEntityTypes(value: string[]);
    resetPiiEntityTypes(): void;
    get piiEntityTypesInput(): string[] | undefined;
    private _redactionMaskMode?;
    get redactionMaskMode(): string;
    set redactionMaskMode(value: string);
    resetRedactionMaskMode(): void;
    get redactionMaskModeInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#detection_mode BedrockDataAutomationProject#detection_mode}
    */
    readonly detectionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#detection_scope BedrockDataAutomationProject#detection_scope}
    */
    readonly detectionScope?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#pii_entities_configuration BedrockDataAutomationProject#pii_entities_configuration}
    */
    readonly piiEntitiesConfiguration?: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfiguration;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfiguration | cdktn.IResolvable | undefined);
    private _detectionMode?;
    get detectionMode(): string;
    set detectionMode(value: string);
    resetDetectionMode(): void;
    get detectionModeInput(): string | undefined;
    private _detectionScope?;
    get detectionScope(): string[];
    set detectionScope(value: string[]);
    resetDetectionScope(): void;
    get detectionScopeInput(): string[] | undefined;
    private _piiEntitiesConfiguration;
    get piiEntitiesConfiguration(): BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfigurationOutputReference;
    putPiiEntitiesConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfiguration): void;
    resetPiiEntitiesConfiguration(): void;
    get piiEntitiesConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationPiiEntitiesConfiguration | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationDocumentSplitter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentSplitterToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocumentSplitter | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentSplitterToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocumentSplitter | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationDocumentSplitterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationDocumentSplitter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationDocumentSplitter | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationDocument {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#modality_processing BedrockDataAutomationProject#modality_processing}
    */
    readonly modalityProcessing?: BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessing;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#sensitive_data_configuration BedrockDataAutomationProject#sensitive_data_configuration}
    */
    readonly sensitiveDataConfiguration?: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#splitter BedrockDataAutomationProject#splitter}
    */
    readonly splitter?: BedrockDataAutomationProjectOverrideConfigurationDocumentSplitter;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocument | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationDocumentToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationDocument | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationDocumentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationDocument | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationDocument | cdktn.IResolvable | undefined);
    private _modalityProcessing;
    get modalityProcessing(): BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessingOutputReference;
    putModalityProcessing(value: BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessing): void;
    resetModalityProcessing(): void;
    get modalityProcessingInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationDocumentModalityProcessing | undefined;
    private _sensitiveDataConfiguration;
    get sensitiveDataConfiguration(): BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfigurationOutputReference;
    putSensitiveDataConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfiguration): void;
    resetSensitiveDataConfiguration(): void;
    get sensitiveDataConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationDocumentSensitiveDataConfiguration | undefined;
    private _splitter;
    get splitter(): BedrockDataAutomationProjectOverrideConfigurationDocumentSplitterOutputReference;
    putSplitter(value: BedrockDataAutomationProjectOverrideConfigurationDocumentSplitter): void;
    resetSplitter(): void;
    get splitterInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationDocumentSplitter | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationImageModalityProcessingToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessing | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationImageModalityProcessingToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessing | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessing | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessing | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#pii_entity_types BedrockDataAutomationProject#pii_entity_types}
    */
    readonly piiEntityTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#redaction_mask_mode BedrockDataAutomationProject#redaction_mask_mode}
    */
    readonly redactionMaskMode?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable | undefined);
    private _piiEntityTypes?;
    get piiEntityTypes(): string[];
    set piiEntityTypes(value: string[]);
    resetPiiEntityTypes(): void;
    get piiEntityTypesInput(): string[] | undefined;
    private _redactionMaskMode?;
    get redactionMaskMode(): string;
    set redactionMaskMode(value: string);
    resetRedactionMaskMode(): void;
    get redactionMaskModeInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#detection_mode BedrockDataAutomationProject#detection_mode}
    */
    readonly detectionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#detection_scope BedrockDataAutomationProject#detection_scope}
    */
    readonly detectionScope?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#pii_entities_configuration BedrockDataAutomationProject#pii_entities_configuration}
    */
    readonly piiEntitiesConfiguration?: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfiguration;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfiguration | cdktn.IResolvable | undefined);
    private _detectionMode?;
    get detectionMode(): string;
    set detectionMode(value: string);
    resetDetectionMode(): void;
    get detectionModeInput(): string | undefined;
    private _detectionScope?;
    get detectionScope(): string[];
    set detectionScope(value: string[]);
    resetDetectionScope(): void;
    get detectionScopeInput(): string[] | undefined;
    private _piiEntitiesConfiguration;
    get piiEntitiesConfiguration(): BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfigurationOutputReference;
    putPiiEntitiesConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfiguration): void;
    resetPiiEntitiesConfiguration(): void;
    get piiEntitiesConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationPiiEntitiesConfiguration | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#modality_processing BedrockDataAutomationProject#modality_processing}
    */
    readonly modalityProcessing?: BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessing;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#sensitive_data_configuration BedrockDataAutomationProject#sensitive_data_configuration}
    */
    readonly sensitiveDataConfiguration?: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfiguration;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationImageToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationImage | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationImageToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationImage | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationImage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationImage | cdktn.IResolvable | undefined);
    private _modalityProcessing;
    get modalityProcessing(): BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessingOutputReference;
    putModalityProcessing(value: BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessing): void;
    resetModalityProcessing(): void;
    get modalityProcessingInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationImageModalityProcessing | undefined;
    private _sensitiveDataConfiguration;
    get sensitiveDataConfiguration(): BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfigurationOutputReference;
    putSensitiveDataConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfiguration): void;
    resetSensitiveDataConfiguration(): void;
    get sensitiveDataConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationImageSensitiveDataConfiguration | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationModalityRouting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#jpeg BedrockDataAutomationProject#jpeg}
    */
    readonly jpeg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#mov BedrockDataAutomationProject#mov}
    */
    readonly mov?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#mp_4 BedrockDataAutomationProject#mp_4}
    */
    readonly mp4?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#png BedrockDataAutomationProject#png}
    */
    readonly png?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationModalityRoutingToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationModalityRouting | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationModalityRoutingToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationModalityRouting | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationModalityRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationModalityRouting | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationModalityRouting | cdktn.IResolvable | undefined);
    private _jpeg?;
    get jpeg(): string;
    set jpeg(value: string);
    resetJpeg(): void;
    get jpegInput(): string | undefined;
    private _mov?;
    get mov(): string;
    set mov(value: string);
    resetMov(): void;
    get movInput(): string | undefined;
    private _mp4?;
    get mp4(): string;
    set mp4(value: string);
    resetMp4(): void;
    get mp4Input(): string | undefined;
    private _png?;
    get png(): string;
    set png(value: string);
    resetPng(): void;
    get pngInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessingToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessing | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessingToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessing | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessing | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessing | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#pii_entity_types BedrockDataAutomationProject#pii_entity_types}
    */
    readonly piiEntityTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#redaction_mask_mode BedrockDataAutomationProject#redaction_mask_mode}
    */
    readonly redactionMaskMode?: string;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfiguration | cdktn.IResolvable | undefined);
    private _piiEntityTypes?;
    get piiEntityTypes(): string[];
    set piiEntityTypes(value: string[]);
    resetPiiEntityTypes(): void;
    get piiEntityTypesInput(): string[] | undefined;
    private _redactionMaskMode?;
    get redactionMaskMode(): string;
    set redactionMaskMode(value: string);
    resetRedactionMaskMode(): void;
    get redactionMaskModeInput(): string | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#detection_mode BedrockDataAutomationProject#detection_mode}
    */
    readonly detectionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#detection_scope BedrockDataAutomationProject#detection_scope}
    */
    readonly detectionScope?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#pii_entities_configuration BedrockDataAutomationProject#pii_entities_configuration}
    */
    readonly piiEntitiesConfiguration?: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfiguration;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfiguration | cdktn.IResolvable | undefined);
    private _detectionMode?;
    get detectionMode(): string;
    set detectionMode(value: string);
    resetDetectionMode(): void;
    get detectionModeInput(): string | undefined;
    private _detectionScope?;
    get detectionScope(): string[];
    set detectionScope(value: string[]);
    resetDetectionScope(): void;
    get detectionScopeInput(): string[] | undefined;
    private _piiEntitiesConfiguration;
    get piiEntitiesConfiguration(): BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfigurationOutputReference;
    putPiiEntitiesConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfiguration): void;
    resetPiiEntitiesConfiguration(): void;
    get piiEntitiesConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationPiiEntitiesConfiguration | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfigurationVideo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#modality_processing BedrockDataAutomationProject#modality_processing}
    */
    readonly modalityProcessing?: BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessing;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#sensitive_data_configuration BedrockDataAutomationProject#sensitive_data_configuration}
    */
    readonly sensitiveDataConfiguration?: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfiguration;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationVideoToTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationVideo | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationVideoToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfigurationVideo | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationVideoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfigurationVideo | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfigurationVideo | cdktn.IResolvable | undefined);
    private _modalityProcessing;
    get modalityProcessing(): BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessingOutputReference;
    putModalityProcessing(value: BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessing): void;
    resetModalityProcessing(): void;
    get modalityProcessingInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationVideoModalityProcessing | undefined;
    private _sensitiveDataConfiguration;
    get sensitiveDataConfiguration(): BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfigurationOutputReference;
    putSensitiveDataConfiguration(value: BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfiguration): void;
    resetSensitiveDataConfiguration(): void;
    get sensitiveDataConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationVideoSensitiveDataConfiguration | undefined;
}
export interface BedrockDataAutomationProjectOverrideConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#audio BedrockDataAutomationProject#audio}
    */
    readonly audio?: BedrockDataAutomationProjectOverrideConfigurationAudio;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#document BedrockDataAutomationProject#document}
    */
    readonly document?: BedrockDataAutomationProjectOverrideConfigurationDocument;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#image BedrockDataAutomationProject#image}
    */
    readonly image?: BedrockDataAutomationProjectOverrideConfigurationImage;
    /**
    * Modality routing configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#modality_routing BedrockDataAutomationProject#modality_routing}
    */
    readonly modalityRouting?: BedrockDataAutomationProjectOverrideConfigurationModalityRouting;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#video BedrockDataAutomationProject#video}
    */
    readonly video?: BedrockDataAutomationProjectOverrideConfigurationVideo;
}
export declare function bedrockDataAutomationProjectOverrideConfigurationToTerraform(struct?: BedrockDataAutomationProjectOverrideConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectOverrideConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectOverrideConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectOverrideConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectOverrideConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectOverrideConfiguration | cdktn.IResolvable | undefined);
    private _audio;
    get audio(): BedrockDataAutomationProjectOverrideConfigurationAudioOutputReference;
    putAudio(value: BedrockDataAutomationProjectOverrideConfigurationAudio): void;
    resetAudio(): void;
    get audioInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationAudio | undefined;
    private _document;
    get document(): BedrockDataAutomationProjectOverrideConfigurationDocumentOutputReference;
    putDocument(value: BedrockDataAutomationProjectOverrideConfigurationDocument): void;
    resetDocument(): void;
    get documentInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationDocument | undefined;
    private _image;
    get image(): BedrockDataAutomationProjectOverrideConfigurationImageOutputReference;
    putImage(value: BedrockDataAutomationProjectOverrideConfigurationImage): void;
    resetImage(): void;
    get imageInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationImage | undefined;
    private _modalityRouting;
    get modalityRouting(): BedrockDataAutomationProjectOverrideConfigurationModalityRoutingOutputReference;
    putModalityRouting(value: BedrockDataAutomationProjectOverrideConfigurationModalityRouting): void;
    resetModalityRouting(): void;
    get modalityRoutingInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationModalityRouting | undefined;
    private _video;
    get video(): BedrockDataAutomationProjectOverrideConfigurationVideoOutputReference;
    putVideo(value: BedrockDataAutomationProjectOverrideConfigurationVideo): void;
    resetVideo(): void;
    get videoInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfigurationVideo | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabeling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabelingToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabeling | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabelingToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabeling | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabelingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabeling | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabeling | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabeling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabelingToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabeling | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabelingToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabeling | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabelingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabeling | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabeling | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscript {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#channel_labeling BedrockDataAutomationProject#channel_labeling}
    */
    readonly channelLabeling?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabeling;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#speaker_labeling BedrockDataAutomationProject#speaker_labeling}
    */
    readonly speakerLabeling?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabeling;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscript | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscript | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscript | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscript | cdktn.IResolvable | undefined);
    private _channelLabeling;
    get channelLabeling(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabelingOutputReference;
    putChannelLabeling(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabeling): void;
    resetChannelLabeling(): void;
    get channelLabelingInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptChannelLabeling | undefined;
    private _speakerLabeling;
    get speakerLabeling(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabelingOutputReference;
    putSpeakerLabeling(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabeling): void;
    resetSpeakerLabeling(): void;
    get speakerLabelingInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptSpeakerLabeling | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#transcript BedrockDataAutomationProject#transcript}
    */
    readonly transcript?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscript;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfiguration | cdktn.IResolvable | undefined);
    private _transcript;
    get transcript(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscriptOutputReference;
    putTranscript(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscript): void;
    resetTranscript(): void;
    get transcriptInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationTranscript | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategory {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#type_configuration BedrockDataAutomationProject#type_configuration}
    */
    readonly typeConfiguration?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#types BedrockDataAutomationProject#types}
    */
    readonly types?: string[];
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategory | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategory | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategory | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategory | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _typeConfiguration;
    get typeConfiguration(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfigurationOutputReference;
    putTypeConfiguration(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfiguration): void;
    resetTypeConfiguration(): void;
    get typeConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryTypeConfiguration | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationAudioExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#category BedrockDataAutomationProject#category}
    */
    readonly category?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategory;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtraction | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtraction | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtraction | cdktn.IResolvable | undefined);
    private _category;
    get category(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategoryOutputReference;
    putCategory(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategory): void;
    resetCategory(): void;
    get categoryInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionCategory | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeField {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#types BedrockDataAutomationProject#types}
    */
    readonly types?: string[];
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeFieldToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeField | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeFieldToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeField | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeField | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeField | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationAudio {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#extraction BedrockDataAutomationProject#extraction}
    */
    readonly extraction?: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtraction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#generative_field BedrockDataAutomationProject#generative_field}
    */
    readonly generativeField?: BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeField;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudio | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationAudioToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationAudio | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationAudioOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationAudio | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationAudio | cdktn.IResolvable | undefined);
    private _extraction;
    get extraction(): BedrockDataAutomationProjectStandardOutputConfigurationAudioExtractionOutputReference;
    putExtraction(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioExtraction): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationAudioExtraction | undefined;
    private _generativeField;
    get generativeField(): BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeFieldOutputReference;
    putGenerativeField(value: BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeField): void;
    resetGenerativeField(): void;
    get generativeFieldInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationAudioGenerativeField | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBox {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBoxToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBox | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBoxToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBox | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBoxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBox | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBox | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#types BedrockDataAutomationProject#types}
    */
    readonly types?: string[];
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularityToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularity | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularityToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularity | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularity | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularity | cdktn.IResolvable | undefined);
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#bounding_box BedrockDataAutomationProject#bounding_box}
    */
    readonly boundingBox?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBox;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#granularity BedrockDataAutomationProject#granularity}
    */
    readonly granularity?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularity;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtraction | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtraction | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtraction | cdktn.IResolvable | undefined);
    private _boundingBox;
    get boundingBox(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBoxOutputReference;
    putBoundingBox(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBox): void;
    resetBoundingBox(): void;
    get boundingBoxInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionBoundingBox | undefined;
    private _granularity;
    get granularity(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularityOutputReference;
    putGranularity(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularity): void;
    resetGranularity(): void;
    get granularityInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionGranularity | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeField {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeFieldToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeField | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeFieldToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeField | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeField | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeField | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormatToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormat | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormatToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormat | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormat | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormat | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#types BedrockDataAutomationProject#types}
    */
    readonly types?: string[];
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormatToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormat | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormatToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormat | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormat | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormat | cdktn.IResolvable | undefined);
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormat {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#additional_file_format BedrockDataAutomationProject#additional_file_format}
    */
    readonly additionalFileFormat?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormat;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#text_format BedrockDataAutomationProject#text_format}
    */
    readonly textFormat?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormat;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormat | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormat | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormat | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormat | cdktn.IResolvable | undefined);
    private _additionalFileFormat;
    get additionalFileFormat(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormatOutputReference;
    putAdditionalFileFormat(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormat): void;
    resetAdditionalFileFormat(): void;
    get additionalFileFormatInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatAdditionalFileFormat | undefined;
    private _textFormat;
    get textFormat(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormatOutputReference;
    putTextFormat(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormat): void;
    resetTextFormat(): void;
    get textFormatInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatTextFormat | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationDocument {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#extraction BedrockDataAutomationProject#extraction}
    */
    readonly extraction?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtraction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#generative_field BedrockDataAutomationProject#generative_field}
    */
    readonly generativeField?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeField;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#output_format BedrockDataAutomationProject#output_format}
    */
    readonly outputFormat?: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormat;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocument | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationDocumentToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationDocument | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationDocument | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationDocument | cdktn.IResolvable | undefined);
    private _extraction;
    get extraction(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtractionOutputReference;
    putExtraction(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtraction): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationDocumentExtraction | undefined;
    private _generativeField;
    get generativeField(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeFieldOutputReference;
    putGenerativeField(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeField): void;
    resetGenerativeField(): void;
    get generativeFieldInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationDocumentGenerativeField | undefined;
    private _outputFormat;
    get outputFormat(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormatOutputReference;
    putOutputFormat(value: BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormat): void;
    resetOutputFormat(): void;
    get outputFormatInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputFormat | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBox {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBoxToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBox | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBoxToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBox | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBoxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBox | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBox | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategory {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#types BedrockDataAutomationProject#types}
    */
    readonly types?: string[];
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategoryToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategory | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategoryToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategory | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategory | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategory | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationImageExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#bounding_box BedrockDataAutomationProject#bounding_box}
    */
    readonly boundingBox?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBox;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#category BedrockDataAutomationProject#category}
    */
    readonly category?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategory;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageExtractionToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtraction | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageExtractionToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtraction | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationImageExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationImageExtraction | cdktn.IResolvable | undefined);
    private _boundingBox;
    get boundingBox(): BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBoxOutputReference;
    putBoundingBox(value: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBox): void;
    resetBoundingBox(): void;
    get boundingBoxInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionBoundingBox | undefined;
    private _category;
    get category(): BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategoryOutputReference;
    putCategory(value: BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategory): void;
    resetCategory(): void;
    get categoryInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionCategory | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeField {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#types BedrockDataAutomationProject#types}
    */
    readonly types?: string[];
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeFieldToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeField | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeFieldToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeField | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeField | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeField | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#extraction BedrockDataAutomationProject#extraction}
    */
    readonly extraction?: BedrockDataAutomationProjectStandardOutputConfigurationImageExtraction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#generative_field BedrockDataAutomationProject#generative_field}
    */
    readonly generativeField?: BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeField;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImage | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationImageToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationImage | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationImage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationImage | cdktn.IResolvable | undefined);
    private _extraction;
    get extraction(): BedrockDataAutomationProjectStandardOutputConfigurationImageExtractionOutputReference;
    putExtraction(value: BedrockDataAutomationProjectStandardOutputConfigurationImageExtraction): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationImageExtraction | undefined;
    private _generativeField;
    get generativeField(): BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeFieldOutputReference;
    putGenerativeField(value: BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeField): void;
    resetGenerativeField(): void;
    get generativeFieldInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationImageGenerativeField | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBox {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBoxToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBox | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBoxToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBox | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBoxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBox | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBox | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategory {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#types BedrockDataAutomationProject#types}
    */
    readonly types?: string[];
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategoryToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategory | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategoryToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategory | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategory | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategory | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationVideoExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#bounding_box BedrockDataAutomationProject#bounding_box}
    */
    readonly boundingBox?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBox;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#category BedrockDataAutomationProject#category}
    */
    readonly category?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategory;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtraction | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtraction | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationVideoExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtraction | cdktn.IResolvable | undefined);
    private _boundingBox;
    get boundingBox(): BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBoxOutputReference;
    putBoundingBox(value: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBox): void;
    resetBoundingBox(): void;
    get boundingBoxInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionBoundingBox | undefined;
    private _category;
    get category(): BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategoryOutputReference;
    putCategory(value: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategory): void;
    resetCategory(): void;
    get categoryInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionCategory | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeField {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#state BedrockDataAutomationProject#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#types BedrockDataAutomationProject#types}
    */
    readonly types?: string[];
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeFieldToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeField | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeFieldToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeField | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeField | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeField | cdktn.IResolvable | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfigurationVideo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#extraction BedrockDataAutomationProject#extraction}
    */
    readonly extraction?: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtraction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#generative_field BedrockDataAutomationProject#generative_field}
    */
    readonly generativeField?: BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeField;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideo | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationVideoToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfigurationVideo | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationVideoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfigurationVideo | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfigurationVideo | cdktn.IResolvable | undefined);
    private _extraction;
    get extraction(): BedrockDataAutomationProjectStandardOutputConfigurationVideoExtractionOutputReference;
    putExtraction(value: BedrockDataAutomationProjectStandardOutputConfigurationVideoExtraction): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationVideoExtraction | undefined;
    private _generativeField;
    get generativeField(): BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeFieldOutputReference;
    putGenerativeField(value: BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeField): void;
    resetGenerativeField(): void;
    get generativeFieldInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationVideoGenerativeField | undefined;
}
export interface BedrockDataAutomationProjectStandardOutputConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#audio BedrockDataAutomationProject#audio}
    */
    readonly audio?: BedrockDataAutomationProjectStandardOutputConfigurationAudio;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#document BedrockDataAutomationProject#document}
    */
    readonly document?: BedrockDataAutomationProjectStandardOutputConfigurationDocument;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#image BedrockDataAutomationProject#image}
    */
    readonly image?: BedrockDataAutomationProjectStandardOutputConfigurationImage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#video BedrockDataAutomationProject#video}
    */
    readonly video?: BedrockDataAutomationProjectStandardOutputConfigurationVideo;
}
export declare function bedrockDataAutomationProjectStandardOutputConfigurationToTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfiguration | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectStandardOutputConfigurationToHclTerraform(struct?: BedrockDataAutomationProjectStandardOutputConfiguration | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectStandardOutputConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockDataAutomationProjectStandardOutputConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectStandardOutputConfiguration | cdktn.IResolvable | undefined);
    private _audio;
    get audio(): BedrockDataAutomationProjectStandardOutputConfigurationAudioOutputReference;
    putAudio(value: BedrockDataAutomationProjectStandardOutputConfigurationAudio): void;
    resetAudio(): void;
    get audioInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationAudio | undefined;
    private _document;
    get document(): BedrockDataAutomationProjectStandardOutputConfigurationDocumentOutputReference;
    putDocument(value: BedrockDataAutomationProjectStandardOutputConfigurationDocument): void;
    resetDocument(): void;
    get documentInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationDocument | undefined;
    private _image;
    get image(): BedrockDataAutomationProjectStandardOutputConfigurationImageOutputReference;
    putImage(value: BedrockDataAutomationProjectStandardOutputConfigurationImage): void;
    resetImage(): void;
    get imageInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationImage | undefined;
    private _video;
    get video(): BedrockDataAutomationProjectStandardOutputConfigurationVideoOutputReference;
    putVideo(value: BedrockDataAutomationProjectStandardOutputConfigurationVideo): void;
    resetVideo(): void;
    get videoInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfigurationVideo | undefined;
}
export interface BedrockDataAutomationProjectTags {
    /**
    * Key for the tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#key BedrockDataAutomationProject#key}
    */
    readonly key?: string;
    /**
    * Value for the tag
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#value BedrockDataAutomationProject#value}
    */
    readonly value?: string;
}
export declare function bedrockDataAutomationProjectTagsToTerraform(struct?: BedrockDataAutomationProjectTags | cdktn.IResolvable): any;
export declare function bedrockDataAutomationProjectTagsToHclTerraform(struct?: BedrockDataAutomationProjectTags | cdktn.IResolvable): any;
export declare class BedrockDataAutomationProjectTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockDataAutomationProjectTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockDataAutomationProjectTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockDataAutomationProjectTagsList extends cdktn.ComplexList {
    internalValue?: BedrockDataAutomationProjectTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockDataAutomationProjectTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project awscc_bedrock_data_automation_project}
*/
export declare class BedrockDataAutomationProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_data_automation_project";
    /**
    * Generates CDKTN code for importing a BedrockDataAutomationProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockDataAutomationProject to import
    * @param importFromId The id of the existing BedrockDataAutomationProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockDataAutomationProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_data_automation_project awscc_bedrock_data_automation_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockDataAutomationProjectConfig
    */
    constructor(scope: Construct, id: string, config: BedrockDataAutomationProjectConfig);
    get creationTime(): string;
    private _customOutputConfiguration;
    get customOutputConfiguration(): BedrockDataAutomationProjectCustomOutputConfigurationOutputReference;
    putCustomOutputConfiguration(value: BedrockDataAutomationProjectCustomOutputConfiguration): void;
    resetCustomOutputConfiguration(): void;
    get customOutputConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectCustomOutputConfiguration | undefined;
    get id(): string;
    private _kmsEncryptionContext?;
    get kmsEncryptionContext(): {
        [key: string]: string;
    };
    set kmsEncryptionContext(value: {
        [key: string]: string;
    });
    resetKmsEncryptionContext(): void;
    get kmsEncryptionContextInput(): {
        [key: string]: string;
    } | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get lastModifiedTime(): string;
    private _overrideConfiguration;
    get overrideConfiguration(): BedrockDataAutomationProjectOverrideConfigurationOutputReference;
    putOverrideConfiguration(value: BedrockDataAutomationProjectOverrideConfiguration): void;
    resetOverrideConfiguration(): void;
    get overrideConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectOverrideConfiguration | undefined;
    get projectArn(): string;
    private _projectDescription?;
    get projectDescription(): string;
    set projectDescription(value: string);
    resetProjectDescription(): void;
    get projectDescriptionInput(): string | undefined;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    get projectStage(): string;
    private _projectType?;
    get projectType(): string;
    set projectType(value: string);
    resetProjectType(): void;
    get projectTypeInput(): string | undefined;
    private _standardOutputConfiguration;
    get standardOutputConfiguration(): BedrockDataAutomationProjectStandardOutputConfigurationOutputReference;
    putStandardOutputConfiguration(value: BedrockDataAutomationProjectStandardOutputConfiguration): void;
    resetStandardOutputConfiguration(): void;
    get standardOutputConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationProjectStandardOutputConfiguration | undefined;
    get status(): string;
    private _tags;
    get tags(): BedrockDataAutomationProjectTagsList;
    putTags(value: BedrockDataAutomationProjectTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockDataAutomationProjectTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
