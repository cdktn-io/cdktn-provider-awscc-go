/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodedeployApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * A name for the application. If you don't specify a name, AWS CloudFormation generates a unique physical ID and uses that ID for the application name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_application#application_name CodedeployApplication#application_name}
    */
    readonly applicationName?: string;
    /**
    * The compute platform that CodeDeploy deploys the application to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_application#compute_platform CodedeployApplication#compute_platform}
    */
    readonly computePlatform?: string;
    /**
    * The metadata that you apply to CodeDeploy applications to help you organize and categorize them. Each tag consists of a key and an optional value, both of which you define.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_application#tags CodedeployApplication#tags}
    */
    readonly tags?: CodedeployApplicationTags[] | cdktn.IResolvable;
}
export interface CodedeployApplicationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_application#key CodedeployApplication#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_application#value CodedeployApplication#value}
    */
    readonly value?: string;
}
export declare function codedeployApplicationTagsToTerraform(struct?: CodedeployApplicationTags | cdktn.IResolvable): any;
export declare function codedeployApplicationTagsToHclTerraform(struct?: CodedeployApplicationTags | cdktn.IResolvable): any;
export declare class CodedeployApplicationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodedeployApplicationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployApplicationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodedeployApplicationTagsList extends cdktn.ComplexList {
    internalValue?: CodedeployApplicationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodedeployApplicationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_application awscc_codedeploy_application}
*/
export declare class CodedeployApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codedeploy_application";
    /**
    * Generates CDKTN code for importing a CodedeployApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodedeployApplication to import
    * @param importFromId The id of the existing CodedeployApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodedeployApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_application awscc_codedeploy_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodedeployApplicationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CodedeployApplicationConfig);
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    resetApplicationName(): void;
    get applicationNameInput(): string | undefined;
    private _computePlatform?;
    get computePlatform(): string;
    set computePlatform(value: string);
    resetComputePlatform(): void;
    get computePlatformInput(): string | undefined;
    get id(): string;
    private _tags;
    get tags(): CodedeployApplicationTagsList;
    putTags(value: CodedeployApplicationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodedeployApplicationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
