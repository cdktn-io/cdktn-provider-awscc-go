/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationsignalsServiceLevelObjectiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Each object in this array defines the length of the look-back window used to calculate one burn rate metric for this SLO. The burn rate measures how fast the service is consuming the error budget, relative to the attainment goal of the SLO.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#burn_rate_configurations ApplicationsignalsServiceLevelObjective#burn_rate_configurations}
    */
    readonly burnRateConfigurations?: ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations[] | cdktn.IResolvable;
    /**
    * An optional description for this SLO. Default is 'No description'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#description ApplicationsignalsServiceLevelObjective#description}
    */
    readonly description?: string;
    /**
    * Each object in this array defines a time exclusion window for this SLO. The time exclusion window is used to exclude breaching data points from affecting attainment rate, error budget, and burn rate metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#exclusion_windows ApplicationsignalsServiceLevelObjective#exclusion_windows}
    */
    readonly exclusionWindows?: ApplicationsignalsServiceLevelObjectiveExclusionWindows[] | cdktn.IResolvable;
    /**
    * A structure that contains the attributes that determine the goal of the SLO. This includes the time period for evaluation and the attainment threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#goal ApplicationsignalsServiceLevelObjective#goal}
    */
    readonly goal?: ApplicationsignalsServiceLevelObjectiveGoal;
    /**
    * The name of this SLO.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#name ApplicationsignalsServiceLevelObjective#name}
    */
    readonly name: string;
    /**
    * This structure contains information about the performance metric that a request-based SLO monitors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#request_based_sli ApplicationsignalsServiceLevelObjective#request_based_sli}
    */
    readonly requestBasedSli?: ApplicationsignalsServiceLevelObjectiveRequestBasedSli;
    /**
    * This structure contains information about the performance metric that an SLO monitors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#sli ApplicationsignalsServiceLevelObjective#sli}
    */
    readonly sli?: ApplicationsignalsServiceLevelObjectiveSli;
    /**
    * The list of tag keys and values associated with the resource you specified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#tags ApplicationsignalsServiceLevelObjective#tags}
    */
    readonly tags?: ApplicationsignalsServiceLevelObjectiveTags[] | cdktn.IResolvable;
}
export interface ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations {
    /**
    * The number of minutes to use as the look-back window.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#look_back_window_minutes ApplicationsignalsServiceLevelObjective#look_back_window_minutes}
    */
    readonly lookBackWindowMinutes?: number;
}
export declare function applicationsignalsServiceLevelObjectiveBurnRateConfigurationsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveBurnRateConfigurationsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveBurnRateConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations | cdktn.IResolvable | undefined);
    private _lookBackWindowMinutes?;
    get lookBackWindowMinutes(): number;
    set lookBackWindowMinutes(value: number);
    resetLookBackWindowMinutes(): void;
    get lookBackWindowMinutesInput(): number | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveBurnRateConfigurationsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveBurnRateConfigurationsOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRule {
    /**
    * A cron or rate expression denoting how often to repeat this exclusion window.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#expression ApplicationsignalsServiceLevelObjective#expression}
    */
    readonly expression?: string;
}
export declare function applicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRuleToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRule | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRuleToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRule | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRule | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRule | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindow {
    /**
    * Specifies the duration of each interval. For example, if `Duration` is 1 and `DurationUnit` is `MONTH`, each interval is one month, aligned with the calendar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#duration ApplicationsignalsServiceLevelObjective#duration}
    */
    readonly duration?: number;
    /**
    * Specifies the interval unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#duration_unit ApplicationsignalsServiceLevelObjective#duration_unit}
    */
    readonly durationUnit?: string;
}
export declare function applicationsignalsServiceLevelObjectiveExclusionWindowsWindowToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindow | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveExclusionWindowsWindowToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindow | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindow | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindow | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _durationUnit?;
    get durationUnit(): string;
    set durationUnit(value: string);
    resetDurationUnit(): void;
    get durationUnitInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveExclusionWindows {
    /**
    * An optional reason for scheduling this time exclusion window. Default is 'No reason'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#reason ApplicationsignalsServiceLevelObjective#reason}
    */
    readonly reason?: string;
    /**
    * This object defines how often to repeat a time exclusion window.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#recurrence_rule ApplicationsignalsServiceLevelObjective#recurrence_rule}
    */
    readonly recurrenceRule?: ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRule;
    /**
    * The time you want the exclusion window to start at. Note that time exclusion windows can only be scheduled in the future, not the past.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#start_time ApplicationsignalsServiceLevelObjective#start_time}
    */
    readonly startTime?: string;
    /**
    * This object defines the length of time an exclusion window should span.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#window ApplicationsignalsServiceLevelObjective#window}
    */
    readonly window?: ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindow;
}
export declare function applicationsignalsServiceLevelObjectiveExclusionWindowsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveExclusionWindows | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveExclusionWindowsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveExclusionWindows | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveExclusionWindowsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveExclusionWindows | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveExclusionWindows | cdktn.IResolvable | undefined);
    private _reason?;
    get reason(): string;
    set reason(value: string);
    resetReason(): void;
    get reasonInput(): string | undefined;
    private _recurrenceRule;
    get recurrenceRule(): ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRuleOutputReference;
    putRecurrenceRule(value: ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRule): void;
    resetRecurrenceRule(): void;
    get recurrenceRuleInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveExclusionWindowsRecurrenceRule | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    private _window;
    get window(): ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindowOutputReference;
    putWindow(value: ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindow): void;
    resetWindow(): void;
    get windowInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveExclusionWindowsWindow | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveExclusionWindowsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveExclusionWindows[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveExclusionWindowsOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarInterval {
    /**
    * Specifies the duration of each interval. For example, if `Duration` is 1 and `DurationUnit` is `MONTH`, each interval is one month, aligned with the calendar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#duration ApplicationsignalsServiceLevelObjective#duration}
    */
    readonly duration?: number;
    /**
    * Specifies the interval unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#duration_unit ApplicationsignalsServiceLevelObjective#duration_unit}
    */
    readonly durationUnit?: string;
    /**
    * Epoch time in seconds you want the first interval to start. Be sure to choose a time that configures the intervals the way that you want. For example, if you want weekly intervals starting on Mondays at 6 a.m., be sure to specify a start time that is a Monday at 6 a.m.
    * As soon as one calendar interval ends, another automatically begins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#start_time ApplicationsignalsServiceLevelObjective#start_time}
    */
    readonly startTime?: number;
}
export declare function applicationsignalsServiceLevelObjectiveGoalIntervalCalendarIntervalToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarInterval | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveGoalIntervalCalendarIntervalToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarInterval | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarInterval | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarInterval | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _durationUnit?;
    get durationUnit(): string;
    set durationUnit(value: string);
    resetDurationUnit(): void;
    get durationUnitInput(): string | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingInterval {
    /**
    * Specifies the duration of each interval. For example, if `Duration` is 1 and `DurationUnit` is `MONTH`, each interval is one month, aligned with the calendar.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#duration ApplicationsignalsServiceLevelObjective#duration}
    */
    readonly duration?: number;
    /**
    * Specifies the interval unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#duration_unit ApplicationsignalsServiceLevelObjective#duration_unit}
    */
    readonly durationUnit?: string;
}
export declare function applicationsignalsServiceLevelObjectiveGoalIntervalRollingIntervalToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingInterval | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveGoalIntervalRollingIntervalToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingInterval | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingInterval | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingInterval | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _durationUnit?;
    get durationUnit(): string;
    set durationUnit(value: string);
    resetDurationUnit(): void;
    get durationUnitInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveGoalInterval {
    /**
    * If the interval for this service level objective is a calendar interval, this structure contains the interval specifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#calendar_interval ApplicationsignalsServiceLevelObjective#calendar_interval}
    */
    readonly calendarInterval?: ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarInterval;
    /**
    * If the interval is a calendar interval, this structure contains the interval specifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#rolling_interval ApplicationsignalsServiceLevelObjective#rolling_interval}
    */
    readonly rollingInterval?: ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingInterval;
}
export declare function applicationsignalsServiceLevelObjectiveGoalIntervalToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveGoalInterval | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveGoalIntervalToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveGoalInterval | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveGoalIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveGoalInterval | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveGoalInterval | cdktn.IResolvable | undefined);
    private _calendarInterval;
    get calendarInterval(): ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarIntervalOutputReference;
    putCalendarInterval(value: ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarInterval): void;
    resetCalendarInterval(): void;
    get calendarIntervalInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveGoalIntervalCalendarInterval | undefined;
    private _rollingInterval;
    get rollingInterval(): ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingIntervalOutputReference;
    putRollingInterval(value: ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingInterval): void;
    resetRollingInterval(): void;
    get rollingIntervalInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveGoalIntervalRollingInterval | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveGoal {
    /**
    * The threshold that determines if the goal is being met. An attainment goal is the ratio of good periods that meet the threshold requirements to the total periods within the interval. For example, an attainment goal of 99.9% means that within your interval, you are targeting 99.9% of the periods to be in healthy state.
    * If you omit this parameter, 99 is used to represent 99% as the attainment goal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#attainment_goal ApplicationsignalsServiceLevelObjective#attainment_goal}
    */
    readonly attainmentGoal?: number;
    /**
    * The time period used to evaluate the SLO. It can be either a calendar interval or rolling interval.
    * If you omit this parameter, a rolling interval of 7 days is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#interval ApplicationsignalsServiceLevelObjective#interval}
    */
    readonly interval?: ApplicationsignalsServiceLevelObjectiveGoalInterval;
    /**
    * The percentage of remaining budget over total budget that you want to get warnings for. If you omit this parameter, the default of 50.0 is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#warning_threshold ApplicationsignalsServiceLevelObjective#warning_threshold}
    */
    readonly warningThreshold?: number;
}
export declare function applicationsignalsServiceLevelObjectiveGoalToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveGoal | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveGoalToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveGoal | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveGoalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveGoal | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveGoal | cdktn.IResolvable | undefined);
    private _attainmentGoal?;
    get attainmentGoal(): number;
    set attainmentGoal(value: number);
    resetAttainmentGoal(): void;
    get attainmentGoalInput(): number | undefined;
    private _interval;
    get interval(): ApplicationsignalsServiceLevelObjectiveGoalIntervalOutputReference;
    putInterval(value: ApplicationsignalsServiceLevelObjectiveGoalInterval): void;
    resetInterval(): void;
    get intervalInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveGoalInterval | undefined;
    private _warningThreshold?;
    get warningThreshold(): number;
    set warningThreshold(value: number);
    resetWarningThreshold(): void;
    get warningThresholdInput(): number | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#operation_name ApplicationsignalsServiceLevelObjective#operation_name}
    */
    readonly operationName?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponentsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponentsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents | cdktn.IResolvable | undefined);
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponentsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponentsOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#pattern ApplicationsignalsServiceLevelObjective#pattern}
    */
    readonly pattern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#type ApplicationsignalsServiceLevelObjective#type}
    */
    readonly type?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfigToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfig | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfigToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfig | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfig | cdktn.IResolvable | undefined);
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#composite_sli_components ApplicationsignalsServiceLevelObjective#composite_sli_components}
    */
    readonly compositeSliComponents?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#selection_config ApplicationsignalsServiceLevelObjective#selection_config}
    */
    readonly selectionConfig?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfig;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfig | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfig | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfig | cdktn.IResolvable | undefined);
    private _compositeSliComponents;
    get compositeSliComponents(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponentsList;
    putCompositeSliComponents(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents[] | cdktn.IResolvable): void;
    resetCompositeSliComponents(): void;
    get compositeSliComponentsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigCompositeSliComponents[] | undefined;
    private _selectionConfig;
    get selectionConfig(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfigOutputReference;
    putSelectionConfig(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfig): void;
    resetSelectionConfig(): void;
    get selectionConfigInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigSelectionConfig | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfig {
    /**
    * If this SLO is related to a metric collected by Application Signals, you must use this field to specify which dependency the SLO metric is related to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dependency_key_attributes ApplicationsignalsServiceLevelObjective#dependency_key_attributes}
    */
    readonly dependencyKeyAttributes?: {
        [key: string]: string;
    };
    /**
    * When the SLO monitors a specific operation of the dependency, this field specifies the name of that operation in the dependency.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dependency_operation_name ApplicationsignalsServiceLevelObjective#dependency_operation_name}
    */
    readonly dependencyOperationName?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfigToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfig | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfigToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfig | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfig | cdktn.IResolvable | undefined);
    private _dependencyKeyAttributes?;
    get dependencyKeyAttributes(): {
        [key: string]: string;
    };
    set dependencyKeyAttributes(value: {
        [key: string]: string;
    });
    resetDependencyKeyAttributes(): void;
    get dependencyKeyAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _dependencyOperationName?;
    get dependencyOperationName(): string;
    set dependencyOperationName(value: string);
    resetDependencyOperationName(): void;
    get dependencyOperationNameInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSource {
    /**
    * Optional additional attributes for the metric source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_source_attributes ApplicationsignalsServiceLevelObjective#metric_source_attributes}
    */
    readonly metricSourceAttributes?: {
        [key: string]: string;
    };
    /**
    * Required attributes that identify the metric source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_source_key_attributes ApplicationsignalsServiceLevelObjective#metric_source_key_attributes}
    */
    readonly metricSourceKeyAttributes?: {
        [key: string]: string;
    };
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSourceToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSource | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSourceToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSource | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSource | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSource | cdktn.IResolvable | undefined);
    private _metricSourceAttributes?;
    get metricSourceAttributes(): {
        [key: string]: string;
    };
    set metricSourceAttributes(value: {
        [key: string]: string;
    });
    resetMetricSourceAttributes(): void;
    get metricSourceAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _metricSourceKeyAttributes?;
    get metricSourceKeyAttributes(): {
        [key: string]: string;
    };
    set metricSourceKeyAttributes(value: {
        [key: string]: string;
    });
    resetMetricSourceKeyAttributes(): void;
    get metricSourceKeyAttributesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions {
    /**
    * The name of the dimension. Dimension names must contain only ASCII characters, must include at least one non-whitespace character, and cannot start with a colon (:). ASCII control characters are not supported as part of dimension names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#name ApplicationsignalsServiceLevelObjective#name}
    */
    readonly name?: string;
    /**
    * The value of the dimension. Dimension values must contain only ASCII characters and must include at least one non-whitespace character. ASCII control characters are not supported as part of dimension values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#value ApplicationsignalsServiceLevelObjective#value}
    */
    readonly value?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensionsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensionsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensionsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensionsOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetric {
    /**
    * An array of one or more dimensions to use to define the metric that you want to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dimensions ApplicationsignalsServiceLevelObjective#dimensions}
    */
    readonly dimensions?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * The name of the metric to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_name ApplicationsignalsServiceLevelObjective#metric_name}
    */
    readonly metricName?: string;
    /**
    * The namespace of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#namespace ApplicationsignalsServiceLevelObjective#namespace}
    */
    readonly namespace?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetric | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensionsList;
    putDimensions(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStat {
    /**
    * This structure defines the metric used for a service level indicator, including the metric name, namespace, and dimensions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric ApplicationsignalsServiceLevelObjective#metric}
    */
    readonly metric?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetric;
    /**
    * The granularity, in seconds, to be used for the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#period ApplicationsignalsServiceLevelObjective#period}
    */
    readonly period?: number;
    /**
    * The statistic to use for comparison to the threshold. It can be any CloudWatch statistic or extended statistic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#stat ApplicationsignalsServiceLevelObjective#stat}
    */
    readonly stat?: string;
    /**
    * If you omit Unit then all data that was collected with any unit is returned, along with the corresponding units that were specified when the data was reported to CloudWatch. If you specify a unit, the operation returns only data that was collected with that unit specified. If you specify a unit that does not match the data collected, the results of the operation are null. CloudWatch does not perform unit conversions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#unit ApplicationsignalsServiceLevelObjective#unit}
    */
    readonly unit?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStat | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStat | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStat | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStat | cdktn.IResolvable | undefined);
    private _metric;
    get metric(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetricOutputReference;
    putMetric(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetric): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatMetric | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric {
    /**
    * The ID of the account where the metrics are located, if this is a cross-account alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#account_id ApplicationsignalsServiceLevelObjective#account_id}
    */
    readonly accountId?: string;
    /**
    * The math expression to be performed on the returned data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#expression ApplicationsignalsServiceLevelObjective#expression}
    */
    readonly expression?: string;
    /**
    * A short name used to tie this object to the results in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#id ApplicationsignalsServiceLevelObjective#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A metric to be used directly for the SLO, or to be used in the math expression that will be used for the SLO. Within one MetricDataQuery, you must specify either Expression or MetricStat but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_stat ApplicationsignalsServiceLevelObjective#metric_stat}
    */
    readonly metricStat?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStat;
    /**
    * This option indicates whether to return the timestamps and raw data values of this metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#return_data ApplicationsignalsServiceLevelObjective#return_data}
    */
    readonly returnData?: boolean | cdktn.IResolvable;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricStat;
    get metricStat(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStatOutputReference;
    putMetricStat(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStat): void;
    resetMetricStat(): void;
    get metricStatInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricMetricStat | undefined;
    private _returnData?;
    get returnData(): boolean | cdktn.IResolvable;
    set returnData(value: boolean | cdktn.IResolvable);
    resetReturnData(): void;
    get returnDataInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions {
    /**
    * The name of the dimension. Dimension names must contain only ASCII characters, must include at least one non-whitespace character, and cannot start with a colon (:). ASCII control characters are not supported as part of dimension names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#name ApplicationsignalsServiceLevelObjective#name}
    */
    readonly name?: string;
    /**
    * The value of the dimension. Dimension values must contain only ASCII characters and must include at least one non-whitespace character. ASCII control characters are not supported as part of dimension values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#value ApplicationsignalsServiceLevelObjective#value}
    */
    readonly value?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensionsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensionsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensionsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensionsOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetric {
    /**
    * An array of one or more dimensions to use to define the metric that you want to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dimensions ApplicationsignalsServiceLevelObjective#dimensions}
    */
    readonly dimensions?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * The name of the metric to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_name ApplicationsignalsServiceLevelObjective#metric_name}
    */
    readonly metricName?: string;
    /**
    * The namespace of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#namespace ApplicationsignalsServiceLevelObjective#namespace}
    */
    readonly namespace?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetric | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensionsList;
    putDimensions(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStat {
    /**
    * This structure defines the metric used for a service level indicator, including the metric name, namespace, and dimensions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric ApplicationsignalsServiceLevelObjective#metric}
    */
    readonly metric?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetric;
    /**
    * The granularity, in seconds, to be used for the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#period ApplicationsignalsServiceLevelObjective#period}
    */
    readonly period?: number;
    /**
    * The statistic to use for comparison to the threshold. It can be any CloudWatch statistic or extended statistic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#stat ApplicationsignalsServiceLevelObjective#stat}
    */
    readonly stat?: string;
    /**
    * If you omit Unit then all data that was collected with any unit is returned, along with the corresponding units that were specified when the data was reported to CloudWatch. If you specify a unit, the operation returns only data that was collected with that unit specified. If you specify a unit that does not match the data collected, the results of the operation are null. CloudWatch does not perform unit conversions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#unit ApplicationsignalsServiceLevelObjective#unit}
    */
    readonly unit?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStat | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStat | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStat | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStat | cdktn.IResolvable | undefined);
    private _metric;
    get metric(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetricOutputReference;
    putMetric(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetric): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatMetric | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric {
    /**
    * The ID of the account where the metrics are located, if this is a cross-account alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#account_id ApplicationsignalsServiceLevelObjective#account_id}
    */
    readonly accountId?: string;
    /**
    * The math expression to be performed on the returned data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#expression ApplicationsignalsServiceLevelObjective#expression}
    */
    readonly expression?: string;
    /**
    * A short name used to tie this object to the results in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#id ApplicationsignalsServiceLevelObjective#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A metric to be used directly for the SLO, or to be used in the math expression that will be used for the SLO. Within one MetricDataQuery, you must specify either Expression or MetricStat but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_stat ApplicationsignalsServiceLevelObjective#metric_stat}
    */
    readonly metricStat?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStat;
    /**
    * This option indicates whether to return the timestamps and raw data values of this metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#return_data ApplicationsignalsServiceLevelObjective#return_data}
    */
    readonly returnData?: boolean | cdktn.IResolvable;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricStat;
    get metricStat(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStatOutputReference;
    putMetricStat(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStat): void;
    resetMetricStat(): void;
    get metricStatInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricMetricStat | undefined;
    private _returnData?;
    get returnData(): boolean | cdktn.IResolvable;
    set returnData(value: boolean | cdktn.IResolvable);
    resetReturnData(): void;
    get returnDataInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetric {
    /**
    * If you want to count "bad requests" to determine the percentage of successful requests for this request-based SLO, specify the metric to use as "bad requests" in this structure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#bad_count_metric ApplicationsignalsServiceLevelObjective#bad_count_metric}
    */
    readonly badCountMetric?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric[] | cdktn.IResolvable;
    /**
    * If you want to count "good requests" to determine the percentage of successful requests for this request-based SLO, specify the metric to use as "good requests" in this structure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#good_count_metric ApplicationsignalsServiceLevelObjective#good_count_metric}
    */
    readonly goodCountMetric?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric[] | cdktn.IResolvable;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetric | cdktn.IResolvable | undefined);
    private _badCountMetric;
    get badCountMetric(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetricList;
    putBadCountMetric(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric[] | cdktn.IResolvable): void;
    resetBadCountMetric(): void;
    get badCountMetricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricBadCountMetric[] | undefined;
    private _goodCountMetric;
    get goodCountMetric(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetricList;
    putGoodCountMetric(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric[] | cdktn.IResolvable): void;
    resetGoodCountMetric(): void;
    get goodCountMetricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricGoodCountMetric[] | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions {
    /**
    * The name of the dimension. Dimension names must contain only ASCII characters, must include at least one non-whitespace character, and cannot start with a colon (:). ASCII control characters are not supported as part of dimension names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#name ApplicationsignalsServiceLevelObjective#name}
    */
    readonly name?: string;
    /**
    * The value of the dimension. Dimension values must contain only ASCII characters and must include at least one non-whitespace character. ASCII control characters are not supported as part of dimension values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#value ApplicationsignalsServiceLevelObjective#value}
    */
    readonly value?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensionsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensionsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensionsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensionsOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetric {
    /**
    * An array of one or more dimensions to use to define the metric that you want to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dimensions ApplicationsignalsServiceLevelObjective#dimensions}
    */
    readonly dimensions?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * The name of the metric to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_name ApplicationsignalsServiceLevelObjective#metric_name}
    */
    readonly metricName?: string;
    /**
    * The namespace of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#namespace ApplicationsignalsServiceLevelObjective#namespace}
    */
    readonly namespace?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetric | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensionsList;
    putDimensions(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStat {
    /**
    * This structure defines the metric used for a service level indicator, including the metric name, namespace, and dimensions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric ApplicationsignalsServiceLevelObjective#metric}
    */
    readonly metric?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetric;
    /**
    * The granularity, in seconds, to be used for the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#period ApplicationsignalsServiceLevelObjective#period}
    */
    readonly period?: number;
    /**
    * The statistic to use for comparison to the threshold. It can be any CloudWatch statistic or extended statistic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#stat ApplicationsignalsServiceLevelObjective#stat}
    */
    readonly stat?: string;
    /**
    * If you omit Unit then all data that was collected with any unit is returned, along with the corresponding units that were specified when the data was reported to CloudWatch. If you specify a unit, the operation returns only data that was collected with that unit specified. If you specify a unit that does not match the data collected, the results of the operation are null. CloudWatch does not perform unit conversions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#unit ApplicationsignalsServiceLevelObjective#unit}
    */
    readonly unit?: string;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStat | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStat | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStat | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStat | cdktn.IResolvable | undefined);
    private _metric;
    get metric(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetricOutputReference;
    putMetric(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetric): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatMetric | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric {
    /**
    * The ID of the account where the metrics are located, if this is a cross-account alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#account_id ApplicationsignalsServiceLevelObjective#account_id}
    */
    readonly accountId?: string;
    /**
    * The math expression to be performed on the returned data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#expression ApplicationsignalsServiceLevelObjective#expression}
    */
    readonly expression?: string;
    /**
    * A short name used to tie this object to the results in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#id ApplicationsignalsServiceLevelObjective#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A metric to be used directly for the SLO, or to be used in the math expression that will be used for the SLO. Within one MetricDataQuery, you must specify either Expression or MetricStat but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_stat ApplicationsignalsServiceLevelObjective#metric_stat}
    */
    readonly metricStat?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStat;
    /**
    * This option indicates whether to return the timestamps and raw data values of this metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#return_data ApplicationsignalsServiceLevelObjective#return_data}
    */
    readonly returnData?: boolean | cdktn.IResolvable;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricStat;
    get metricStat(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStatOutputReference;
    putMetricStat(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStat): void;
    resetMetricStat(): void;
    get metricStatInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricMetricStat | undefined;
    private _returnData?;
    get returnData(): boolean | cdktn.IResolvable;
    set returnData(value: boolean | cdktn.IResolvable);
    resetReturnData(): void;
    get returnDataInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetric {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#composite_sli_config ApplicationsignalsServiceLevelObjective#composite_sli_config}
    */
    readonly compositeSliConfig?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfig;
    /**
    * Configuration for identifying a dependency and its operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dependency_config ApplicationsignalsServiceLevelObjective#dependency_config}
    */
    readonly dependencyConfig?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfig;
    /**
    * This is a string-to-string map that contains information about the type of object that this SLO is related to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#key_attributes ApplicationsignalsServiceLevelObjective#key_attributes}
    */
    readonly keyAttributes?: {
        [key: string]: string;
    };
    /**
    * The name of the metric for non-Application Signals services
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_name ApplicationsignalsServiceLevelObjective#metric_name}
    */
    readonly metricName?: string;
    /**
    * Configuration for identifying the source of metrics for non-Application Signals services
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_source ApplicationsignalsServiceLevelObjective#metric_source}
    */
    readonly metricSource?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSource;
    /**
    * If the SLO monitors either the LATENCY or AVAILABILITY metric that Application Signals collects, this field displays which of those metrics is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_type ApplicationsignalsServiceLevelObjective#metric_type}
    */
    readonly metricType?: string;
    /**
    * This structure defines the metric that is used as the "good request" or "bad request" value for a request-based SLO. This value observed for the metric defined in `TotalRequestCountMetric` is divided by the number found for `MonitoredRequestCountMetric` to determine the percentage of successful requests that this SLO tracks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#monitored_request_count_metric ApplicationsignalsServiceLevelObjective#monitored_request_count_metric}
    */
    readonly monitoredRequestCountMetric?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetric;
    /**
    * If the SLO monitors a specific operation of the service, this field displays that operation name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#operation_name ApplicationsignalsServiceLevelObjective#operation_name}
    */
    readonly operationName?: string;
    /**
    * This structure defines the metric that is used as the "total requests" number for a request-based SLO. The number observed for this metric is divided by the number of "good requests" or "bad requests" that is observed for the metric defined in `MonitoredRequestCountMetric`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#total_request_count_metric ApplicationsignalsServiceLevelObjective#total_request_count_metric}
    */
    readonly totalRequestCountMetric?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric[] | cdktn.IResolvable;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetric | cdktn.IResolvable | undefined);
    private _compositeSliConfig;
    get compositeSliConfig(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfigOutputReference;
    putCompositeSliConfig(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfig): void;
    resetCompositeSliConfig(): void;
    get compositeSliConfigInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricCompositeSliConfig | undefined;
    private _dependencyConfig;
    get dependencyConfig(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfigOutputReference;
    putDependencyConfig(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfig): void;
    resetDependencyConfig(): void;
    get dependencyConfigInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricDependencyConfig | undefined;
    private _keyAttributes?;
    get keyAttributes(): {
        [key: string]: string;
    };
    set keyAttributes(value: {
        [key: string]: string;
    });
    resetKeyAttributes(): void;
    get keyAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metricSource;
    get metricSource(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSourceOutputReference;
    putMetricSource(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSource): void;
    resetMetricSource(): void;
    get metricSourceInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMetricSource | undefined;
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    resetMetricType(): void;
    get metricTypeInput(): string | undefined;
    private _monitoredRequestCountMetric;
    get monitoredRequestCountMetric(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetricOutputReference;
    putMonitoredRequestCountMetric(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetric): void;
    resetMonitoredRequestCountMetric(): void;
    get monitoredRequestCountMetricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricMonitoredRequestCountMetric | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _totalRequestCountMetric;
    get totalRequestCountMetric(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetricList;
    putTotalRequestCountMetric(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric[] | cdktn.IResolvable): void;
    resetTotalRequestCountMetric(): void;
    get totalRequestCountMetricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricTotalRequestCountMetric[] | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveRequestBasedSli {
    /**
    * The arithmetic operation used when comparing the specified metric to the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#comparison_operator ApplicationsignalsServiceLevelObjective#comparison_operator}
    */
    readonly comparisonOperator?: string;
    /**
    * The value that the SLI metric is compared to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_threshold ApplicationsignalsServiceLevelObjective#metric_threshold}
    */
    readonly metricThreshold?: number;
    /**
    * This structure contains the information about the metric that is used for a request-based SLO.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#request_based_sli_metric ApplicationsignalsServiceLevelObjective#request_based_sli_metric}
    */
    readonly requestBasedSliMetric?: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetric;
}
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSli | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveRequestBasedSliToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveRequestBasedSli | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveRequestBasedSliOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveRequestBasedSli | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSli | cdktn.IResolvable | undefined);
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    resetComparisonOperator(): void;
    get comparisonOperatorInput(): string | undefined;
    private _metricThreshold?;
    get metricThreshold(): number;
    set metricThreshold(value: number);
    resetMetricThreshold(): void;
    get metricThresholdInput(): number | undefined;
    private _requestBasedSliMetric;
    get requestBasedSliMetric(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetricOutputReference;
    putRequestBasedSliMetric(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetric): void;
    resetRequestBasedSliMetric(): void;
    get requestBasedSliMetricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSliRequestBasedSliMetric | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#operation_name ApplicationsignalsServiceLevelObjective#operation_name}
    */
    readonly operationName?: string;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponentsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponentsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents | cdktn.IResolvable | undefined);
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponentsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponentsOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#pattern ApplicationsignalsServiceLevelObjective#pattern}
    */
    readonly pattern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#type ApplicationsignalsServiceLevelObjective#type}
    */
    readonly type?: string;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfigToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfig | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfigToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfig | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfig | cdktn.IResolvable | undefined);
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#composite_sli_components ApplicationsignalsServiceLevelObjective#composite_sli_components}
    */
    readonly compositeSliComponents?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#selection_config ApplicationsignalsServiceLevelObjective#selection_config}
    */
    readonly selectionConfig?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfig;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfig | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfig | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfig | cdktn.IResolvable | undefined);
    private _compositeSliComponents;
    get compositeSliComponents(): ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponentsList;
    putCompositeSliComponents(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents[] | cdktn.IResolvable): void;
    resetCompositeSliComponents(): void;
    get compositeSliComponentsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigCompositeSliComponents[] | undefined;
    private _selectionConfig;
    get selectionConfig(): ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfigOutputReference;
    putSelectionConfig(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfig): void;
    resetSelectionConfig(): void;
    get selectionConfigInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigSelectionConfig | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfig {
    /**
    * If this SLO is related to a metric collected by Application Signals, you must use this field to specify which dependency the SLO metric is related to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dependency_key_attributes ApplicationsignalsServiceLevelObjective#dependency_key_attributes}
    */
    readonly dependencyKeyAttributes?: {
        [key: string]: string;
    };
    /**
    * When the SLO monitors a specific operation of the dependency, this field specifies the name of that operation in the dependency.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dependency_operation_name ApplicationsignalsServiceLevelObjective#dependency_operation_name}
    */
    readonly dependencyOperationName?: string;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfigToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfig | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfigToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfig | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfig | cdktn.IResolvable | undefined);
    private _dependencyKeyAttributes?;
    get dependencyKeyAttributes(): {
        [key: string]: string;
    };
    set dependencyKeyAttributes(value: {
        [key: string]: string;
    });
    resetDependencyKeyAttributes(): void;
    get dependencyKeyAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _dependencyOperationName?;
    get dependencyOperationName(): string;
    set dependencyOperationName(value: string);
    resetDependencyOperationName(): void;
    get dependencyOperationNameInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions {
    /**
    * The name of the dimension. Dimension names must contain only ASCII characters, must include at least one non-whitespace character, and cannot start with a colon (:). ASCII control characters are not supported as part of dimension names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#name ApplicationsignalsServiceLevelObjective#name}
    */
    readonly name?: string;
    /**
    * The value of the dimension. Dimension values must contain only ASCII characters and must include at least one non-whitespace character. ASCII control characters are not supported as part of dimension values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#value ApplicationsignalsServiceLevelObjective#value}
    */
    readonly value?: string;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensionsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensionsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensionsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensionsOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetric {
    /**
    * An array of one or more dimensions to use to define the metric that you want to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dimensions ApplicationsignalsServiceLevelObjective#dimensions}
    */
    readonly dimensions?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * The name of the metric to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_name ApplicationsignalsServiceLevelObjective#metric_name}
    */
    readonly metricName?: string;
    /**
    * The namespace of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#namespace ApplicationsignalsServiceLevelObjective#namespace}
    */
    readonly namespace?: string;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetric | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensionsList;
    putDimensions(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStat {
    /**
    * This structure defines the metric used for a service level indicator, including the metric name, namespace, and dimensions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric ApplicationsignalsServiceLevelObjective#metric}
    */
    readonly metric?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetric;
    /**
    * The granularity, in seconds, to be used for the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#period ApplicationsignalsServiceLevelObjective#period}
    */
    readonly period?: number;
    /**
    * The statistic to use for comparison to the threshold. It can be any CloudWatch statistic or extended statistic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#stat ApplicationsignalsServiceLevelObjective#stat}
    */
    readonly stat?: string;
    /**
    * If you omit Unit then all data that was collected with any unit is returned, along with the corresponding units that were specified when the data was reported to CloudWatch. If you specify a unit, the operation returns only data that was collected with that unit specified. If you specify a unit that does not match the data collected, the results of the operation are null. CloudWatch does not perform unit conversions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#unit ApplicationsignalsServiceLevelObjective#unit}
    */
    readonly unit?: string;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStat | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStat | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStat | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStat | cdktn.IResolvable | undefined);
    private _metric;
    get metric(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetricOutputReference;
    putMetric(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetric): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatMetric | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries {
    /**
    * The ID of the account where the metrics are located, if this is a cross-account alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#account_id ApplicationsignalsServiceLevelObjective#account_id}
    */
    readonly accountId?: string;
    /**
    * The math expression to be performed on the returned data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#expression ApplicationsignalsServiceLevelObjective#expression}
    */
    readonly expression?: string;
    /**
    * A short name used to tie this object to the results in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#id ApplicationsignalsServiceLevelObjective#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A metric to be used directly for the SLO, or to be used in the math expression that will be used for the SLO. Within one MetricDataQuery, you must specify either Expression or MetricStat but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_stat ApplicationsignalsServiceLevelObjective#metric_stat}
    */
    readonly metricStat?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStat;
    /**
    * This option indicates whether to return the timestamps and raw data values of this metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#return_data ApplicationsignalsServiceLevelObjective#return_data}
    */
    readonly returnData?: boolean | cdktn.IResolvable;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricStat;
    get metricStat(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStatOutputReference;
    putMetricStat(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStat): void;
    resetMetricStat(): void;
    get metricStatInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesMetricStat | undefined;
    private _returnData?;
    get returnData(): boolean | cdktn.IResolvable;
    set returnData(value: boolean | cdktn.IResolvable);
    resetReturnData(): void;
    get returnDataInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesOutputReference;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSource {
    /**
    * Optional additional attributes for the metric source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_source_attributes ApplicationsignalsServiceLevelObjective#metric_source_attributes}
    */
    readonly metricSourceAttributes?: {
        [key: string]: string;
    };
    /**
    * Required attributes that identify the metric source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_source_key_attributes ApplicationsignalsServiceLevelObjective#metric_source_key_attributes}
    */
    readonly metricSourceKeyAttributes?: {
        [key: string]: string;
    };
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricSourceToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSource | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricMetricSourceToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSource | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSource | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSource | cdktn.IResolvable | undefined);
    private _metricSourceAttributes?;
    get metricSourceAttributes(): {
        [key: string]: string;
    };
    set metricSourceAttributes(value: {
        [key: string]: string;
    });
    resetMetricSourceAttributes(): void;
    get metricSourceAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _metricSourceKeyAttributes?;
    get metricSourceKeyAttributes(): {
        [key: string]: string;
    };
    set metricSourceKeyAttributes(value: {
        [key: string]: string;
    });
    resetMetricSourceKeyAttributes(): void;
    get metricSourceKeyAttributesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveSliSliMetric {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#composite_sli_config ApplicationsignalsServiceLevelObjective#composite_sli_config}
    */
    readonly compositeSliConfig?: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfig;
    /**
    * Configuration for identifying a dependency and its operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#dependency_config ApplicationsignalsServiceLevelObjective#dependency_config}
    */
    readonly dependencyConfig?: ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfig;
    /**
    * This is a string-to-string map that contains information about the type of object that this SLO is related to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#key_attributes ApplicationsignalsServiceLevelObjective#key_attributes}
    */
    readonly keyAttributes?: {
        [key: string]: string;
    };
    /**
    * If this SLO monitors a CloudWatch metric or the result of a CloudWatch metric math expression, this structure includes the information about that metric or expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_data_queries ApplicationsignalsServiceLevelObjective#metric_data_queries}
    */
    readonly metricDataQueries?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries[] | cdktn.IResolvable;
    /**
    * The name of the metric for non-Application Signals services
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_name ApplicationsignalsServiceLevelObjective#metric_name}
    */
    readonly metricName?: string;
    /**
    * Configuration for identifying the source of metrics for non-Application Signals services
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_source ApplicationsignalsServiceLevelObjective#metric_source}
    */
    readonly metricSource?: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSource;
    /**
    * If the SLO monitors either the LATENCY or AVAILABILITY metric that Application Signals collects, this field displays which of those metrics is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_type ApplicationsignalsServiceLevelObjective#metric_type}
    */
    readonly metricType?: string;
    /**
    * If the SLO monitors a specific operation of the service, this field displays that operation name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#operation_name ApplicationsignalsServiceLevelObjective#operation_name}
    */
    readonly operationName?: string;
    /**
    * The number of seconds to use as the period for SLO evaluation. Your application's performance is compared to the SLI during each period. For each period, the application is determined to have either achieved or not achieved the necessary performance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#period_seconds ApplicationsignalsServiceLevelObjective#period_seconds}
    */
    readonly periodSeconds?: number;
    /**
    * The statistic to use for comparison to the threshold. It can be any CloudWatch statistic or extended statistic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#statistic ApplicationsignalsServiceLevelObjective#statistic}
    */
    readonly statistic?: string;
}
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetric | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliSliMetricToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSliSliMetric | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliSliMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSliSliMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSliSliMetric | cdktn.IResolvable | undefined);
    private _compositeSliConfig;
    get compositeSliConfig(): ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfigOutputReference;
    putCompositeSliConfig(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfig): void;
    resetCompositeSliConfig(): void;
    get compositeSliConfigInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricCompositeSliConfig | undefined;
    private _dependencyConfig;
    get dependencyConfig(): ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfigOutputReference;
    putDependencyConfig(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfig): void;
    resetDependencyConfig(): void;
    get dependencyConfigInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricDependencyConfig | undefined;
    private _keyAttributes?;
    get keyAttributes(): {
        [key: string]: string;
    };
    set keyAttributes(value: {
        [key: string]: string;
    });
    resetKeyAttributes(): void;
    get keyAttributesInput(): {
        [key: string]: string;
    } | undefined;
    private _metricDataQueries;
    get metricDataQueries(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueriesList;
    putMetricDataQueries(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries[] | cdktn.IResolvable): void;
    resetMetricDataQueries(): void;
    get metricDataQueriesInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricDataQueries[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metricSource;
    get metricSource(): ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSourceOutputReference;
    putMetricSource(value: ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSource): void;
    resetMetricSource(): void;
    get metricSourceInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetricMetricSource | undefined;
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    resetMetricType(): void;
    get metricTypeInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _periodSeconds?;
    get periodSeconds(): number;
    set periodSeconds(value: number);
    resetPeriodSeconds(): void;
    get periodSecondsInput(): number | undefined;
    private _statistic?;
    get statistic(): string;
    set statistic(value: string);
    resetStatistic(): void;
    get statisticInput(): string | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveSli {
    /**
    * The arithmetic operation used when comparing the specified metric to the threshold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#comparison_operator ApplicationsignalsServiceLevelObjective#comparison_operator}
    */
    readonly comparisonOperator?: string;
    /**
    * The value that the SLI metric is compared to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#metric_threshold ApplicationsignalsServiceLevelObjective#metric_threshold}
    */
    readonly metricThreshold?: number;
    /**
    * A structure that contains information about the metric that the SLO monitors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#sli_metric ApplicationsignalsServiceLevelObjective#sli_metric}
    */
    readonly sliMetric?: ApplicationsignalsServiceLevelObjectiveSliSliMetric;
}
export declare function applicationsignalsServiceLevelObjectiveSliToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSli | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveSliToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveSli | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveSliOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveSli | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveSli | cdktn.IResolvable | undefined);
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    resetComparisonOperator(): void;
    get comparisonOperatorInput(): string | undefined;
    private _metricThreshold?;
    get metricThreshold(): number;
    set metricThreshold(value: number);
    resetMetricThreshold(): void;
    get metricThresholdInput(): number | undefined;
    private _sliMetric;
    get sliMetric(): ApplicationsignalsServiceLevelObjectiveSliSliMetricOutputReference;
    putSliMetric(value: ApplicationsignalsServiceLevelObjectiveSliSliMetric): void;
    resetSliMetric(): void;
    get sliMetricInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSliSliMetric | undefined;
}
export interface ApplicationsignalsServiceLevelObjectiveTags {
    /**
    * A string that you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#key ApplicationsignalsServiceLevelObjective#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#value ApplicationsignalsServiceLevelObjective#value}
    */
    readonly value?: string;
}
export declare function applicationsignalsServiceLevelObjectiveTagsToTerraform(struct?: ApplicationsignalsServiceLevelObjectiveTags | cdktn.IResolvable): any;
export declare function applicationsignalsServiceLevelObjectiveTagsToHclTerraform(struct?: ApplicationsignalsServiceLevelObjectiveTags | cdktn.IResolvable): any;
export declare class ApplicationsignalsServiceLevelObjectiveTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsServiceLevelObjectiveTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsServiceLevelObjectiveTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApplicationsignalsServiceLevelObjectiveTagsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsServiceLevelObjectiveTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsServiceLevelObjectiveTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective awscc_applicationsignals_service_level_objective}
*/
export declare class ApplicationsignalsServiceLevelObjective extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_applicationsignals_service_level_objective";
    /**
    * Generates CDKTN code for importing a ApplicationsignalsServiceLevelObjective resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationsignalsServiceLevelObjective to import
    * @param importFromId The id of the existing ApplicationsignalsServiceLevelObjective that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationsignalsServiceLevelObjective to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_service_level_objective awscc_applicationsignals_service_level_objective} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationsignalsServiceLevelObjectiveConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationsignalsServiceLevelObjectiveConfig);
    get arn(): string;
    private _burnRateConfigurations;
    get burnRateConfigurations(): ApplicationsignalsServiceLevelObjectiveBurnRateConfigurationsList;
    putBurnRateConfigurations(value: ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations[] | cdktn.IResolvable): void;
    resetBurnRateConfigurations(): void;
    get burnRateConfigurationsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveBurnRateConfigurations[] | undefined;
    get createdTime(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get evaluationType(): string;
    private _exclusionWindows;
    get exclusionWindows(): ApplicationsignalsServiceLevelObjectiveExclusionWindowsList;
    putExclusionWindows(value: ApplicationsignalsServiceLevelObjectiveExclusionWindows[] | cdktn.IResolvable): void;
    resetExclusionWindows(): void;
    get exclusionWindowsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveExclusionWindows[] | undefined;
    private _goal;
    get goal(): ApplicationsignalsServiceLevelObjectiveGoalOutputReference;
    putGoal(value: ApplicationsignalsServiceLevelObjectiveGoal): void;
    resetGoal(): void;
    get goalInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveGoal | undefined;
    get id(): string;
    get lastUpdatedTime(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _requestBasedSli;
    get requestBasedSli(): ApplicationsignalsServiceLevelObjectiveRequestBasedSliOutputReference;
    putRequestBasedSli(value: ApplicationsignalsServiceLevelObjectiveRequestBasedSli): void;
    resetRequestBasedSli(): void;
    get requestBasedSliInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveRequestBasedSli | undefined;
    private _sli;
    get sli(): ApplicationsignalsServiceLevelObjectiveSliOutputReference;
    putSli(value: ApplicationsignalsServiceLevelObjectiveSli): void;
    resetSli(): void;
    get sliInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveSli | undefined;
    private _tags;
    get tags(): ApplicationsignalsServiceLevelObjectiveTagsList;
    putTags(value: ApplicationsignalsServiceLevelObjectiveTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApplicationsignalsServiceLevelObjectiveTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
