/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BillingconductorPricingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The seller of services provided by AWS, their affiliates, or third-party providers selling services via AWS Marketplaces. Supported billing entities are AWS, AWS Marketplace, and AISPL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#billing_entity BillingconductorPricingRule#billing_entity}
    */
    readonly billingEntity?: string;
    /**
    * Pricing rule description
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#description BillingconductorPricingRule#description}
    */
    readonly description?: string;
    /**
    * Pricing rule modifier percentage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#modifier_percentage BillingconductorPricingRule#modifier_percentage}
    */
    readonly modifierPercentage?: number;
    /**
    * Pricing rule name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#name BillingconductorPricingRule#name}
    */
    readonly name: string;
    /**
    * The Operation which a SKU pricing rule is modifying
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#operation BillingconductorPricingRule#operation}
    */
    readonly operation?: string;
    /**
    * A term used to categorize the granularity of a Pricing Rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#scope BillingconductorPricingRule#scope}
    */
    readonly scope: string;
    /**
    * The service which a pricing rule is applied on
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#service BillingconductorPricingRule#service}
    */
    readonly service?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#tags BillingconductorPricingRule#tags}
    */
    readonly tags?: BillingconductorPricingRuleTags[] | cdktn.IResolvable;
    /**
    * The set of tiering configurations for the pricing rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#tiering BillingconductorPricingRule#tiering}
    */
    readonly tiering?: BillingconductorPricingRuleTiering;
    /**
    * One of MARKUP, DISCOUNT or TIERING that describes the behaviour of the pricing rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#type BillingconductorPricingRule#type}
    */
    readonly type: string;
    /**
    * The UsageType which a SKU pricing rule is modifying
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#usage_type BillingconductorPricingRule#usage_type}
    */
    readonly usageType?: string;
}
export interface BillingconductorPricingRuleTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#key BillingconductorPricingRule#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#value BillingconductorPricingRule#value}
    */
    readonly value?: string;
}
export declare function billingconductorPricingRuleTagsToTerraform(struct?: BillingconductorPricingRuleTags | cdktn.IResolvable): any;
export declare function billingconductorPricingRuleTagsToHclTerraform(struct?: BillingconductorPricingRuleTags | cdktn.IResolvable): any;
export declare class BillingconductorPricingRuleTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingconductorPricingRuleTags | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorPricingRuleTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BillingconductorPricingRuleTagsList extends cdktn.ComplexList {
    internalValue?: BillingconductorPricingRuleTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingconductorPricingRuleTagsOutputReference;
}
export interface BillingconductorPricingRuleTieringCustomTiers {
    /**
    * The inclusive beginning of the tier's usage range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#begin_range_inclusive BillingconductorPricingRule#begin_range_inclusive}
    */
    readonly beginRangeInclusive?: number;
    /**
    * The exclusive end of the tier's usage range. Omit for the last tier (infinity).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#end_range_exclusive BillingconductorPricingRule#end_range_exclusive}
    */
    readonly endRangeExclusive?: number;
    /**
    * The custom rate applied to usage within the tier's range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#rate_value BillingconductorPricingRule#rate_value}
    */
    readonly rateValue?: number;
}
export declare function billingconductorPricingRuleTieringCustomTiersToTerraform(struct?: BillingconductorPricingRuleTieringCustomTiers | cdktn.IResolvable): any;
export declare function billingconductorPricingRuleTieringCustomTiersToHclTerraform(struct?: BillingconductorPricingRuleTieringCustomTiers | cdktn.IResolvable): any;
export declare class BillingconductorPricingRuleTieringCustomTiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingconductorPricingRuleTieringCustomTiers | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorPricingRuleTieringCustomTiers | cdktn.IResolvable | undefined);
    private _beginRangeInclusive?;
    get beginRangeInclusive(): number;
    set beginRangeInclusive(value: number);
    resetBeginRangeInclusive(): void;
    get beginRangeInclusiveInput(): number | undefined;
    private _endRangeExclusive?;
    get endRangeExclusive(): number;
    set endRangeExclusive(value: number);
    resetEndRangeExclusive(): void;
    get endRangeExclusiveInput(): number | undefined;
    private _rateValue?;
    get rateValue(): number;
    set rateValue(value: number);
    resetRateValue(): void;
    get rateValueInput(): number | undefined;
}
export declare class BillingconductorPricingRuleTieringCustomTiersList extends cdktn.ComplexList {
    internalValue?: BillingconductorPricingRuleTieringCustomTiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingconductorPricingRuleTieringCustomTiersOutputReference;
}
export interface BillingconductorPricingRuleTieringFreeTier {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#activated BillingconductorPricingRule#activated}
    */
    readonly activated?: boolean | cdktn.IResolvable;
}
export declare function billingconductorPricingRuleTieringFreeTierToTerraform(struct?: BillingconductorPricingRuleTieringFreeTier | cdktn.IResolvable): any;
export declare function billingconductorPricingRuleTieringFreeTierToHclTerraform(struct?: BillingconductorPricingRuleTieringFreeTier | cdktn.IResolvable): any;
export declare class BillingconductorPricingRuleTieringFreeTierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorPricingRuleTieringFreeTier | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorPricingRuleTieringFreeTier | cdktn.IResolvable | undefined);
    private _activated?;
    get activated(): boolean | cdktn.IResolvable;
    set activated(value: boolean | cdktn.IResolvable);
    resetActivated(): void;
    get activatedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BillingconductorPricingRuleTiering {
    /**
    * The set of custom volume tiers for a SKU-scoped TIERING pricing rule. Tiers must start at 0, be contiguous, and the last tier must have no end range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#custom_tiers BillingconductorPricingRule#custom_tiers}
    */
    readonly customTiers?: BillingconductorPricingRuleTieringCustomTiers[] | cdktn.IResolvable;
    /**
    * The possible customizable free tier configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#free_tier BillingconductorPricingRule#free_tier}
    */
    readonly freeTier?: BillingconductorPricingRuleTieringFreeTier;
}
export declare function billingconductorPricingRuleTieringToTerraform(struct?: BillingconductorPricingRuleTiering | cdktn.IResolvable): any;
export declare function billingconductorPricingRuleTieringToHclTerraform(struct?: BillingconductorPricingRuleTiering | cdktn.IResolvable): any;
export declare class BillingconductorPricingRuleTieringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingconductorPricingRuleTiering | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorPricingRuleTiering | cdktn.IResolvable | undefined);
    private _customTiers;
    get customTiers(): BillingconductorPricingRuleTieringCustomTiersList;
    putCustomTiers(value: BillingconductorPricingRuleTieringCustomTiers[] | cdktn.IResolvable): void;
    resetCustomTiers(): void;
    get customTiersInput(): cdktn.IResolvable | BillingconductorPricingRuleTieringCustomTiers[] | undefined;
    private _freeTier;
    get freeTier(): BillingconductorPricingRuleTieringFreeTierOutputReference;
    putFreeTier(value: BillingconductorPricingRuleTieringFreeTier): void;
    resetFreeTier(): void;
    get freeTierInput(): cdktn.IResolvable | BillingconductorPricingRuleTieringFreeTier | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule awscc_billingconductor_pricing_rule}
*/
export declare class BillingconductorPricingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_billingconductor_pricing_rule";
    /**
    * Generates CDKTN code for importing a BillingconductorPricingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BillingconductorPricingRule to import
    * @param importFromId The id of the existing BillingconductorPricingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BillingconductorPricingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_rule awscc_billingconductor_pricing_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BillingconductorPricingRuleConfig
    */
    constructor(scope: Construct, id: string, config: BillingconductorPricingRuleConfig);
    get arn(): string;
    get associatedPricingPlanCount(): number;
    private _billingEntity?;
    get billingEntity(): string;
    set billingEntity(value: string);
    resetBillingEntity(): void;
    get billingEntityInput(): string | undefined;
    get creationTime(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): number;
    private _modifierPercentage?;
    get modifierPercentage(): number;
    set modifierPercentage(value: number);
    resetModifierPercentage(): void;
    get modifierPercentageInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    resetOperation(): void;
    get operationInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _tags;
    get tags(): BillingconductorPricingRuleTagsList;
    putTags(value: BillingconductorPricingRuleTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BillingconductorPricingRuleTags[] | undefined;
    private _tiering;
    get tiering(): BillingconductorPricingRuleTieringOutputReference;
    putTiering(value: BillingconductorPricingRuleTiering): void;
    resetTiering(): void;
    get tieringInput(): cdktn.IResolvable | BillingconductorPricingRuleTiering | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _usageType?;
    get usageType(): string;
    set usageType(value: string);
    resetUsageType(): void;
    get usageTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
