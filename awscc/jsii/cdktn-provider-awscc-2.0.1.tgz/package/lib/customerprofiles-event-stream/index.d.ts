/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesEventStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream#domain_name CustomerprofilesEventStream#domain_name}
    */
    readonly domainName: string;
    /**
    * The name of the event stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream#event_stream_name CustomerprofilesEventStream#event_stream_name}
    */
    readonly eventStreamName: string;
    /**
    * The tags used to organize, track, or control access for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream#tags CustomerprofilesEventStream#tags}
    */
    readonly tags?: CustomerprofilesEventStreamTags[] | cdktn.IResolvable;
    /**
    * The StreamARN of the destination to deliver profile events to. For example, arn:aws:kinesis:region:account-id:stream/stream-name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream#uri CustomerprofilesEventStream#uri}
    */
    readonly uri: string;
}
export interface CustomerprofilesEventStreamDestinationDetails {
}
export declare function customerprofilesEventStreamDestinationDetailsToTerraform(struct?: CustomerprofilesEventStreamDestinationDetails): any;
export declare function customerprofilesEventStreamDestinationDetailsToHclTerraform(struct?: CustomerprofilesEventStreamDestinationDetails): any;
export declare class CustomerprofilesEventStreamDestinationDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesEventStreamDestinationDetails | undefined;
    set internalValue(value: CustomerprofilesEventStreamDestinationDetails | undefined);
    get status(): string;
    get uri(): string;
}
export interface CustomerprofilesEventStreamTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream#key CustomerprofilesEventStream#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream#value CustomerprofilesEventStream#value}
    */
    readonly value?: string;
}
export declare function customerprofilesEventStreamTagsToTerraform(struct?: CustomerprofilesEventStreamTags | cdktn.IResolvable): any;
export declare function customerprofilesEventStreamTagsToHclTerraform(struct?: CustomerprofilesEventStreamTags | cdktn.IResolvable): any;
export declare class CustomerprofilesEventStreamTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesEventStreamTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesEventStreamTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesEventStreamTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesEventStreamTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesEventStreamTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream awscc_customerprofiles_event_stream}
*/
export declare class CustomerprofilesEventStream extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_event_stream";
    /**
    * Generates CDKTN code for importing a CustomerprofilesEventStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesEventStream to import
    * @param importFromId The id of the existing CustomerprofilesEventStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesEventStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_stream awscc_customerprofiles_event_stream} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesEventStreamConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesEventStreamConfig);
    get createdAt(): string;
    private _destinationDetails;
    get destinationDetails(): CustomerprofilesEventStreamDestinationDetailsOutputReference;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get eventStreamArn(): string;
    private _eventStreamName?;
    get eventStreamName(): string;
    set eventStreamName(value: string);
    get eventStreamNameInput(): string | undefined;
    get id(): string;
    get state(): string;
    private _tags;
    get tags(): CustomerprofilesEventStreamTagsList;
    putTags(value: CustomerprofilesEventStreamTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesEventStreamTags[] | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
