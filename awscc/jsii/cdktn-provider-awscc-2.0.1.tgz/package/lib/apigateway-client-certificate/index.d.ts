/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayClientCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_client_certificate#description ApigatewayClientCertificate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_client_certificate#tags ApigatewayClientCertificate#tags}
    */
    readonly tags?: ApigatewayClientCertificateTags[] | cdktn.IResolvable;
}
export interface ApigatewayClientCertificateTags {
    /**
    * A string you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_client_certificate#key ApigatewayClientCertificate#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_client_certificate#value ApigatewayClientCertificate#value}
    */
    readonly value?: string;
}
export declare function apigatewayClientCertificateTagsToTerraform(struct?: ApigatewayClientCertificateTags | cdktn.IResolvable): any;
export declare function apigatewayClientCertificateTagsToHclTerraform(struct?: ApigatewayClientCertificateTags | cdktn.IResolvable): any;
export declare class ApigatewayClientCertificateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayClientCertificateTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayClientCertificateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigatewayClientCertificateTagsList extends cdktn.ComplexList {
    internalValue?: ApigatewayClientCertificateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayClientCertificateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_client_certificate awscc_apigateway_client_certificate}
*/
export declare class ApigatewayClientCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_client_certificate";
    /**
    * Generates CDKTN code for importing a ApigatewayClientCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayClientCertificate to import
    * @param importFromId The id of the existing ApigatewayClientCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_client_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayClientCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_client_certificate awscc_apigateway_client_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayClientCertificateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApigatewayClientCertificateConfig);
    get clientCertificateId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _tags;
    get tags(): ApigatewayClientCertificateTagsList;
    putTags(value: ApigatewayClientCertificateTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApigatewayClientCertificateTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
