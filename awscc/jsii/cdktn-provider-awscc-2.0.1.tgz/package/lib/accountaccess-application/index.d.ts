/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountaccessApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identity source for the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application#identity_source AccountaccessApplication#identity_source}
    */
    readonly identitySource: AccountaccessApplicationIdentitySource;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application#tags AccountaccessApplication#tags}
    */
    readonly tags?: AccountaccessApplicationTags[] | cdktn.IResolvable;
}
export interface AccountaccessApplicationIdentitySourceIdentityCenter {
    /**
    * The ARN of the Identity Center instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application#instance_arn AccountaccessApplication#instance_arn}
    */
    readonly instanceArn: string;
}
export declare function accountaccessApplicationIdentitySourceIdentityCenterToTerraform(struct?: AccountaccessApplicationIdentitySourceIdentityCenter | cdktn.IResolvable): any;
export declare function accountaccessApplicationIdentitySourceIdentityCenterToHclTerraform(struct?: AccountaccessApplicationIdentitySourceIdentityCenter | cdktn.IResolvable): any;
export declare class AccountaccessApplicationIdentitySourceIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountaccessApplicationIdentitySourceIdentityCenter | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessApplicationIdentitySourceIdentityCenter | cdktn.IResolvable | undefined);
    get applicationArn(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
}
export interface AccountaccessApplicationIdentitySource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application#identity_center AccountaccessApplication#identity_center}
    */
    readonly identityCenter: AccountaccessApplicationIdentitySourceIdentityCenter;
}
export declare function accountaccessApplicationIdentitySourceToTerraform(struct?: AccountaccessApplicationIdentitySource | cdktn.IResolvable): any;
export declare function accountaccessApplicationIdentitySourceToHclTerraform(struct?: AccountaccessApplicationIdentitySource | cdktn.IResolvable): any;
export declare class AccountaccessApplicationIdentitySourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountaccessApplicationIdentitySource | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessApplicationIdentitySource | cdktn.IResolvable | undefined);
    private _identityCenter;
    get identityCenter(): AccountaccessApplicationIdentitySourceIdentityCenterOutputReference;
    putIdentityCenter(value: AccountaccessApplicationIdentitySourceIdentityCenter): void;
    get identityCenterInput(): cdktn.IResolvable | AccountaccessApplicationIdentitySourceIdentityCenter | undefined;
}
export interface AccountaccessApplicationTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application#key AccountaccessApplication#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 255 Unicode characters in length and cannot be prefixed with aws:.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application#value AccountaccessApplication#value}
    */
    readonly value?: string;
}
export declare function accountaccessApplicationTagsToTerraform(struct?: AccountaccessApplicationTags | cdktn.IResolvable): any;
export declare function accountaccessApplicationTagsToHclTerraform(struct?: AccountaccessApplicationTags | cdktn.IResolvable): any;
export declare class AccountaccessApplicationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountaccessApplicationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessApplicationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AccountaccessApplicationTagsList extends cdktn.ComplexList {
    internalValue?: AccountaccessApplicationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountaccessApplicationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application awscc_accountaccess_application}
*/
export declare class AccountaccessApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_accountaccess_application";
    /**
    * Generates CDKTN code for importing a AccountaccessApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountaccessApplication to import
    * @param importFromId The id of the existing AccountaccessApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountaccessApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/accountaccess_application awscc_accountaccess_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountaccessApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AccountaccessApplicationConfig);
    get applicationArn(): string;
    get createdAt(): string;
    get id(): string;
    private _identitySource;
    get identitySource(): AccountaccessApplicationIdentitySourceOutputReference;
    putIdentitySource(value: AccountaccessApplicationIdentitySource): void;
    get identitySourceInput(): cdktn.IResolvable | AccountaccessApplicationIdentitySource | undefined;
    get status(): string;
    private _tags;
    get tags(): AccountaccessApplicationTagsList;
    putTags(value: AccountaccessApplicationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AccountaccessApplicationTags[] | undefined;
    get tenantId(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
