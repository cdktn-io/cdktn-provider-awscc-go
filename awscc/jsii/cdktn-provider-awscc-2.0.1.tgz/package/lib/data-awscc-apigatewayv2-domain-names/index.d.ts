/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2DomainNamesConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigatewayv2_domain_names awscc_apigatewayv2_domain_names}
*/
export declare class DataAwsccApigatewayv2DomainNames extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_domain_names";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2DomainNames resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2DomainNames to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2DomainNames that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigatewayv2_domain_names#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2DomainNames to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigatewayv2_domain_names awscc_apigatewayv2_domain_names} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2DomainNamesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsccApigatewayv2DomainNamesConfig);
    get id(): string;
    get ids(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
