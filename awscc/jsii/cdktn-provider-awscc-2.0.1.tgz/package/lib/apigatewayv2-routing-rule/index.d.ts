/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Apigatewayv2RoutingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resulting action based on matching a routing rules condition. Only InvokeApi is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#actions Apigatewayv2RoutingRule#actions}
    */
    readonly actions: Apigatewayv2RoutingRuleActions[] | cdktn.IResolvable;
    /**
    * The conditions of the routing rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#conditions Apigatewayv2RoutingRule#conditions}
    */
    readonly conditions: Apigatewayv2RoutingRuleConditions[] | cdktn.IResolvable;
    /**
    * The ARN of the domain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#domain_name_arn Apigatewayv2RoutingRule#domain_name_arn}
    */
    readonly domainNameArn: string;
    /**
    * The order in which API Gateway evaluates a rule. Priority is evaluated from the lowest value to the highest value. Rules can't have the same priority. Priority values 1-1,000,000 are supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#priority Apigatewayv2RoutingRule#priority}
    */
    readonly priority: number;
}
export interface Apigatewayv2RoutingRuleActionsInvokeApi {
    /**
    * The API identifier of the target API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#api_id Apigatewayv2RoutingRule#api_id}
    */
    readonly apiId: string;
    /**
    * The name of the target stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#stage Apigatewayv2RoutingRule#stage}
    */
    readonly stage: string;
    /**
    * The strip base path setting. When true, API Gateway strips the incoming matched base path when forwarding the request to the target API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#strip_base_path Apigatewayv2RoutingRule#strip_base_path}
    */
    readonly stripBasePath?: boolean | cdktn.IResolvable;
}
export declare function apigatewayv2RoutingRuleActionsInvokeApiToTerraform(struct?: Apigatewayv2RoutingRuleActionsInvokeApi | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleActionsInvokeApiToHclTerraform(struct?: Apigatewayv2RoutingRuleActionsInvokeApi | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleActionsInvokeApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2RoutingRuleActionsInvokeApi | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleActionsInvokeApi | cdktn.IResolvable | undefined);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    get stageInput(): string | undefined;
    private _stripBasePath?;
    get stripBasePath(): boolean | cdktn.IResolvable;
    set stripBasePath(value: boolean | cdktn.IResolvable);
    resetStripBasePath(): void;
    get stripBasePathInput(): boolean | cdktn.IResolvable | undefined;
}
export interface Apigatewayv2RoutingRuleActions {
    /**
    * Represents an InvokeApi action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#invoke_api Apigatewayv2RoutingRule#invoke_api}
    */
    readonly invokeApi: Apigatewayv2RoutingRuleActionsInvokeApi;
}
export declare function apigatewayv2RoutingRuleActionsToTerraform(struct?: Apigatewayv2RoutingRuleActions | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleActionsToHclTerraform(struct?: Apigatewayv2RoutingRuleActions | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleActions | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleActions | cdktn.IResolvable | undefined);
    private _invokeApi;
    get invokeApi(): Apigatewayv2RoutingRuleActionsInvokeApiOutputReference;
    putInvokeApi(value: Apigatewayv2RoutingRuleActionsInvokeApi): void;
    get invokeApiInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleActionsInvokeApi | undefined;
}
export declare class Apigatewayv2RoutingRuleActionsList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleActionsOutputReference;
}
export interface Apigatewayv2RoutingRuleConditionsMatchBasePaths {
    /**
    * The string of the case sensitive base path to be matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#any_of Apigatewayv2RoutingRule#any_of}
    */
    readonly anyOf?: string[];
}
export declare function apigatewayv2RoutingRuleConditionsMatchBasePathsToTerraform(struct?: Apigatewayv2RoutingRuleConditionsMatchBasePaths | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleConditionsMatchBasePathsToHclTerraform(struct?: Apigatewayv2RoutingRuleConditionsMatchBasePaths | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleConditionsMatchBasePathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2RoutingRuleConditionsMatchBasePaths | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleConditionsMatchBasePaths | cdktn.IResolvable | undefined);
    private _anyOf?;
    get anyOf(): string[];
    set anyOf(value: string[]);
    resetAnyOf(): void;
    get anyOfInput(): string[] | undefined;
}
export interface Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf {
    /**
    * The case insensitive header name to be matched. The header name must be less than 40 characters and the only allowed characters are ``a-z``, ``A-Z``, ``0-9``, and the following special characters: ``*?-!#$%&'.^_`|~.``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#header Apigatewayv2RoutingRule#header}
    */
    readonly header?: string;
    /**
    * The case sensitive header glob value to be matched against entire header value. The header glob value must be less than 128 characters and the only allowed characters are ``a-z``, ``A-Z``, ``0-9``, and the following special characters: ``*?-!#$%&'.^_`|~``. Wildcard matching is supported for header glob values but must be for ``*prefix-match``, ``suffix-match*``, or ``*infix*-match``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#value_glob Apigatewayv2RoutingRule#value_glob}
    */
    readonly valueGlob?: string;
}
export declare function apigatewayv2RoutingRuleConditionsMatchHeadersAnyOfToTerraform(struct?: Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleConditionsMatchHeadersAnyOfToHclTerraform(struct?: Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    resetHeader(): void;
    get headerInput(): string | undefined;
    private _valueGlob?;
    get valueGlob(): string;
    set valueGlob(value: string);
    resetValueGlob(): void;
    get valueGlobInput(): string | undefined;
}
export declare class Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOfList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOfOutputReference;
}
export interface Apigatewayv2RoutingRuleConditionsMatchHeaders {
    /**
    * The header name and header value glob to be matched. The matchHeaders condition is matched if any of the header name and header value globs are matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#any_of Apigatewayv2RoutingRule#any_of}
    */
    readonly anyOf?: Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf[] | cdktn.IResolvable;
}
export declare function apigatewayv2RoutingRuleConditionsMatchHeadersToTerraform(struct?: Apigatewayv2RoutingRuleConditionsMatchHeaders | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleConditionsMatchHeadersToHclTerraform(struct?: Apigatewayv2RoutingRuleConditionsMatchHeaders | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleConditionsMatchHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): Apigatewayv2RoutingRuleConditionsMatchHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleConditionsMatchHeaders | cdktn.IResolvable | undefined);
    private _anyOf;
    get anyOf(): Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOfList;
    putAnyOf(value: Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf[] | cdktn.IResolvable): void;
    resetAnyOf(): void;
    get anyOfInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleConditionsMatchHeadersAnyOf[] | undefined;
}
export interface Apigatewayv2RoutingRuleConditions {
    /**
    * The base path to be matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#match_base_paths Apigatewayv2RoutingRule#match_base_paths}
    */
    readonly matchBasePaths?: Apigatewayv2RoutingRuleConditionsMatchBasePaths;
    /**
    * The headers to be matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#match_headers Apigatewayv2RoutingRule#match_headers}
    */
    readonly matchHeaders?: Apigatewayv2RoutingRuleConditionsMatchHeaders;
}
export declare function apigatewayv2RoutingRuleConditionsToTerraform(struct?: Apigatewayv2RoutingRuleConditions | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleConditionsToHclTerraform(struct?: Apigatewayv2RoutingRuleConditions | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleConditions | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleConditions | cdktn.IResolvable | undefined);
    private _matchBasePaths;
    get matchBasePaths(): Apigatewayv2RoutingRuleConditionsMatchBasePathsOutputReference;
    putMatchBasePaths(value: Apigatewayv2RoutingRuleConditionsMatchBasePaths): void;
    resetMatchBasePaths(): void;
    get matchBasePathsInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleConditionsMatchBasePaths | undefined;
    private _matchHeaders;
    get matchHeaders(): Apigatewayv2RoutingRuleConditionsMatchHeadersOutputReference;
    putMatchHeaders(value: Apigatewayv2RoutingRuleConditionsMatchHeaders): void;
    resetMatchHeaders(): void;
    get matchHeadersInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleConditionsMatchHeaders | undefined;
}
export declare class Apigatewayv2RoutingRuleConditionsList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleConditionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule awscc_apigatewayv2_routing_rule}
*/
export declare class Apigatewayv2RoutingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigatewayv2_routing_rule";
    /**
    * Generates CDKTN code for importing a Apigatewayv2RoutingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Apigatewayv2RoutingRule to import
    * @param importFromId The id of the existing Apigatewayv2RoutingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Apigatewayv2RoutingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigatewayv2_routing_rule awscc_apigatewayv2_routing_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Apigatewayv2RoutingRuleConfig
    */
    constructor(scope: Construct, id: string, config: Apigatewayv2RoutingRuleConfig);
    private _actions;
    get actions(): Apigatewayv2RoutingRuleActionsList;
    putActions(value: Apigatewayv2RoutingRuleActions[] | cdktn.IResolvable): void;
    get actionsInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleActions[] | undefined;
    private _conditions;
    get conditions(): Apigatewayv2RoutingRuleConditionsList;
    putConditions(value: Apigatewayv2RoutingRuleConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleConditions[] | undefined;
    private _domainNameArn?;
    get domainNameArn(): string;
    set domainNameArn(value: string);
    get domainNameArnInput(): string | undefined;
    get id(): string;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    get routingRuleArn(): string;
    get routingRuleId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
