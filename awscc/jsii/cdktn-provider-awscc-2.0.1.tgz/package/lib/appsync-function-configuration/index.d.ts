/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncFunctionConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AWS AppSync GraphQL API that you want to attach using this function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#api_id AppsyncFunctionConfiguration#api_id}
    */
    readonly apiId: string;
    /**
    * The resolver code that contains the request and response functions. When code is used, the runtime is required. The runtime value must be APPSYNC_JS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#code AppsyncFunctionConfiguration#code}
    */
    readonly code?: string;
    /**
    * The Amazon S3 endpoint (where the code is located??).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#code_s3_location AppsyncFunctionConfiguration#code_s3_location}
    */
    readonly codeS3Location?: string;
    /**
    * The name of data source this function will attach.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#data_source_name AppsyncFunctionConfiguration#data_source_name}
    */
    readonly dataSourceName: string;
    /**
    * The function description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#description AppsyncFunctionConfiguration#description}
    */
    readonly description?: string;
    /**
    * The version of the request mapping template. Currently, only the 2018-05-29 version of the template is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#function_version AppsyncFunctionConfiguration#function_version}
    */
    readonly functionVersion?: string;
    /**
    * The maximum number of resolver request inputs that will be sent to a single AWS Lambda function in a BatchInvoke operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#max_batch_size AppsyncFunctionConfiguration#max_batch_size}
    */
    readonly maxBatchSize?: number;
    /**
    * The name of the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#name AppsyncFunctionConfiguration#name}
    */
    readonly name: string;
    /**
    * The Function request mapping template. Functions support only the 2018-05-29 version of the request mapping template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#request_mapping_template AppsyncFunctionConfiguration#request_mapping_template}
    */
    readonly requestMappingTemplate?: string;
    /**
    * Describes a Sync configuration for a resolver. Contains information on which Conflict Detection, as well as Resolution strategy, should be performed when the resolver is invoked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#request_mapping_template_s3_location AppsyncFunctionConfiguration#request_mapping_template_s3_location}
    */
    readonly requestMappingTemplateS3Location?: string;
    /**
    * The Function response mapping template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#response_mapping_template AppsyncFunctionConfiguration#response_mapping_template}
    */
    readonly responseMappingTemplate?: string;
    /**
    * The location of a response mapping template in an Amazon S3 bucket. Use this if you want to provision with a template file in Amazon S3 rather than embedding it in your CloudFormation template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#response_mapping_template_s3_location AppsyncFunctionConfiguration#response_mapping_template_s3_location}
    */
    readonly responseMappingTemplateS3Location?: string;
    /**
    * Describes a runtime used by an AWS AppSync pipeline resolver or AWS AppSync function. Specifies the name and version of the runtime to use. Note that if a runtime is specified, code must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#runtime AppsyncFunctionConfiguration#runtime}
    */
    readonly runtime?: AppsyncFunctionConfigurationRuntime;
    /**
    * Describes a Sync configuration for a resolver. Specifies which Conflict Detection strategy and Resolution strategy to use when the resolver is invoked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#sync_config AppsyncFunctionConfiguration#sync_config}
    */
    readonly syncConfig?: AppsyncFunctionConfigurationSyncConfig;
}
export interface AppsyncFunctionConfigurationRuntime {
    /**
    * The name of the runtime to use. Currently, the only allowed value is APPSYNC_JS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#name AppsyncFunctionConfiguration#name}
    */
    readonly name?: string;
    /**
    * The version of the runtime to use. Currently, the only allowed version is 1.0.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#runtime_version AppsyncFunctionConfiguration#runtime_version}
    */
    readonly runtimeVersion?: string;
}
export declare function appsyncFunctionConfigurationRuntimeToTerraform(struct?: AppsyncFunctionConfigurationRuntime | cdktn.IResolvable): any;
export declare function appsyncFunctionConfigurationRuntimeToHclTerraform(struct?: AppsyncFunctionConfigurationRuntime | cdktn.IResolvable): any;
export declare class AppsyncFunctionConfigurationRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncFunctionConfigurationRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncFunctionConfigurationRuntime | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _runtimeVersion?;
    get runtimeVersion(): string;
    set runtimeVersion(value: string);
    resetRuntimeVersion(): void;
    get runtimeVersionInput(): string | undefined;
}
export interface AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfig {
    /**
    * The Amazon Resource Name (ARN) for the Lambda function to use as the Conflict Handler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#lambda_conflict_handler_arn AppsyncFunctionConfiguration#lambda_conflict_handler_arn}
    */
    readonly lambdaConflictHandlerArn?: string;
}
export declare function appsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfigToTerraform(struct?: AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfig | cdktn.IResolvable): any;
export declare function appsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfigToHclTerraform(struct?: AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfig | cdktn.IResolvable): any;
export declare class AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfig | cdktn.IResolvable | undefined);
    private _lambdaConflictHandlerArn?;
    get lambdaConflictHandlerArn(): string;
    set lambdaConflictHandlerArn(value: string);
    resetLambdaConflictHandlerArn(): void;
    get lambdaConflictHandlerArnInput(): string | undefined;
}
export interface AppsyncFunctionConfigurationSyncConfig {
    /**
    * The Conflict Detection strategy to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#conflict_detection AppsyncFunctionConfiguration#conflict_detection}
    */
    readonly conflictDetection?: string;
    /**
    * The Conflict Resolution strategy to perform in the event of a conflict.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#conflict_handler AppsyncFunctionConfiguration#conflict_handler}
    */
    readonly conflictHandler?: string;
    /**
    * The LambdaConflictHandlerConfig when configuring LAMBDA as the Conflict Handler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#lambda_conflict_handler_config AppsyncFunctionConfiguration#lambda_conflict_handler_config}
    */
    readonly lambdaConflictHandlerConfig?: AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfig;
}
export declare function appsyncFunctionConfigurationSyncConfigToTerraform(struct?: AppsyncFunctionConfigurationSyncConfig | cdktn.IResolvable): any;
export declare function appsyncFunctionConfigurationSyncConfigToHclTerraform(struct?: AppsyncFunctionConfigurationSyncConfig | cdktn.IResolvable): any;
export declare class AppsyncFunctionConfigurationSyncConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncFunctionConfigurationSyncConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncFunctionConfigurationSyncConfig | cdktn.IResolvable | undefined);
    private _conflictDetection?;
    get conflictDetection(): string;
    set conflictDetection(value: string);
    resetConflictDetection(): void;
    get conflictDetectionInput(): string | undefined;
    private _conflictHandler?;
    get conflictHandler(): string;
    set conflictHandler(value: string);
    resetConflictHandler(): void;
    get conflictHandlerInput(): string | undefined;
    private _lambdaConflictHandlerConfig;
    get lambdaConflictHandlerConfig(): AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfigOutputReference;
    putLambdaConflictHandlerConfig(value: AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfig): void;
    resetLambdaConflictHandlerConfig(): void;
    get lambdaConflictHandlerConfigInput(): cdktn.IResolvable | AppsyncFunctionConfigurationSyncConfigLambdaConflictHandlerConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration awscc_appsync_function_configuration}
*/
export declare class AppsyncFunctionConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_function_configuration";
    /**
    * Generates CDKTN code for importing a AppsyncFunctionConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncFunctionConfiguration to import
    * @param importFromId The id of the existing AppsyncFunctionConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncFunctionConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_function_configuration awscc_appsync_function_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncFunctionConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncFunctionConfigurationConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _codeS3Location?;
    get codeS3Location(): string;
    set codeS3Location(value: string);
    resetCodeS3Location(): void;
    get codeS3LocationInput(): string | undefined;
    private _dataSourceName?;
    get dataSourceName(): string;
    set dataSourceName(value: string);
    get dataSourceNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get functionArn(): string;
    get functionId(): string;
    private _functionVersion?;
    get functionVersion(): string;
    set functionVersion(value: string);
    resetFunctionVersion(): void;
    get functionVersionInput(): string | undefined;
    get id(): string;
    private _maxBatchSize?;
    get maxBatchSize(): number;
    set maxBatchSize(value: number);
    resetMaxBatchSize(): void;
    get maxBatchSizeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _requestMappingTemplate?;
    get requestMappingTemplate(): string;
    set requestMappingTemplate(value: string);
    resetRequestMappingTemplate(): void;
    get requestMappingTemplateInput(): string | undefined;
    private _requestMappingTemplateS3Location?;
    get requestMappingTemplateS3Location(): string;
    set requestMappingTemplateS3Location(value: string);
    resetRequestMappingTemplateS3Location(): void;
    get requestMappingTemplateS3LocationInput(): string | undefined;
    private _responseMappingTemplate?;
    get responseMappingTemplate(): string;
    set responseMappingTemplate(value: string);
    resetResponseMappingTemplate(): void;
    get responseMappingTemplateInput(): string | undefined;
    private _responseMappingTemplateS3Location?;
    get responseMappingTemplateS3Location(): string;
    set responseMappingTemplateS3Location(value: string);
    resetResponseMappingTemplateS3Location(): void;
    get responseMappingTemplateS3LocationInput(): string | undefined;
    private _runtime;
    get runtime(): AppsyncFunctionConfigurationRuntimeOutputReference;
    putRuntime(value: AppsyncFunctionConfigurationRuntime): void;
    resetRuntime(): void;
    get runtimeInput(): cdktn.IResolvable | AppsyncFunctionConfigurationRuntime | undefined;
    private _syncConfig;
    get syncConfig(): AppsyncFunctionConfigurationSyncConfigOutputReference;
    putSyncConfig(value: AppsyncFunctionConfigurationSyncConfig): void;
    resetSyncConfig(): void;
    get syncConfigInput(): cdktn.IResolvable | AppsyncFunctionConfigurationSyncConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
