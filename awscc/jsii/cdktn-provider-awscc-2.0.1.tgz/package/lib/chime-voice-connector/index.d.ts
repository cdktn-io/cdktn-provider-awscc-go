/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeVoiceConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AWS Region in which the Voice Connector is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector#aws_region ChimeVoiceConnector#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * The name of the Voice Connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector#name ChimeVoiceConnector#name}
    */
    readonly name: string;
    /**
    * The type of network for the Voice Connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector#network_type ChimeVoiceConnector#network_type}
    */
    readonly networkType?: string;
    /**
    * Enables or disables encryption for the Voice Connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector#require_encryption ChimeVoiceConnector#require_encryption}
    */
    readonly requireEncryption: boolean | cdktn.IResolvable;
    /**
    * The tags assigned to the Voice Connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector#tags ChimeVoiceConnector#tags}
    */
    readonly tags?: ChimeVoiceConnectorTags[] | cdktn.IResolvable;
}
export interface ChimeVoiceConnectorTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector#key ChimeVoiceConnector#key}
    */
    readonly key?: string;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector#value ChimeVoiceConnector#value}
    */
    readonly value?: string;
}
export declare function chimeVoiceConnectorTagsToTerraform(struct?: ChimeVoiceConnectorTags | cdktn.IResolvable): any;
export declare function chimeVoiceConnectorTagsToHclTerraform(struct?: ChimeVoiceConnectorTags | cdktn.IResolvable): any;
export declare class ChimeVoiceConnectorTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeVoiceConnectorTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeVoiceConnectorTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeVoiceConnectorTagsList extends cdktn.ComplexList {
    internalValue?: ChimeVoiceConnectorTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeVoiceConnectorTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector awscc_chime_voice_connector}
*/
export declare class ChimeVoiceConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_voice_connector";
    /**
    * Generates CDKTN code for importing a ChimeVoiceConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeVoiceConnector to import
    * @param importFromId The id of the existing ChimeVoiceConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeVoiceConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_voice_connector awscc_chime_voice_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeVoiceConnectorConfig
    */
    constructor(scope: Construct, id: string, config: ChimeVoiceConnectorConfig);
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    get createdTimestamp(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    get outboundHostName(): string;
    private _requireEncryption?;
    get requireEncryption(): boolean | cdktn.IResolvable;
    set requireEncryption(value: boolean | cdktn.IResolvable);
    get requireEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _tags;
    get tags(): ChimeVoiceConnectorTagsList;
    putTags(value: ChimeVoiceConnectorTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeVoiceConnectorTags[] | undefined;
    get updatedTimestamp(): string;
    get voiceConnectorArn(): string;
    get voiceConnectorId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
