/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontOriginRequestPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The origin request policy configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#origin_request_policy_config CloudfrontOriginRequestPolicy#origin_request_policy_config}
    */
    readonly originRequestPolicyConfig: CloudfrontOriginRequestPolicyOriginRequestPolicyConfig;
}
export interface CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfig {
    /**
    * Determines whether cookies in viewer requests are included in requests that CloudFront sends to the origin. Valid values are:
    *   +  ``none`` ? No cookies in viewer requests are included in requests that CloudFront sends to the origin. Even when this field is set to ``none``, any cookies that are listed in a ``CachePolicy``*are* included in origin requests.
    *   +  ``whitelist`` ? Only the cookies in viewer requests that are listed in the ``CookieNames`` type are included in requests that CloudFront sends to the origin.
    *   +  ``all`` ? All cookies in viewer requests are included in requests that CloudFront sends to the origin.
    *   +  ``allExcept`` ? All cookies in viewer requests are included in requests that CloudFront sends to the origin, *except* for those listed in the ``CookieNames`` type, which are not included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#cookie_behavior CloudfrontOriginRequestPolicy#cookie_behavior}
    */
    readonly cookieBehavior: string;
    /**
    * Contains a list of cookie names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#cookies CloudfrontOriginRequestPolicy#cookies}
    */
    readonly cookies?: string[];
}
export declare function cloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfigToTerraform(struct?: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfig | cdktn.IResolvable): any;
export declare function cloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfigToHclTerraform(struct?: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfig | cdktn.IResolvable): any;
export declare class CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfig | cdktn.IResolvable | undefined);
    private _cookieBehavior?;
    get cookieBehavior(): string;
    set cookieBehavior(value: string);
    get cookieBehaviorInput(): string | undefined;
    private _cookies?;
    get cookies(): string[];
    set cookies(value: string[]);
    resetCookies(): void;
    get cookiesInput(): string[] | undefined;
}
export interface CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfig {
    /**
    * Determines whether any HTTP headers are included in requests that CloudFront sends to the origin. Valid values are:
    *   +  ``none`` ? No HTTP headers in viewer requests are included in requests that CloudFront sends to the origin. Even when this field is set to ``none``, any headers that are listed in a ``CachePolicy``*are* included in origin requests.
    *   +  ``whitelist`` ? Only the HTTP headers that are listed in the ``Headers`` type are included in requests that CloudFront sends to the origin.
    *   +  ``allViewer`` ? All HTTP headers in viewer requests are included in requests that CloudFront sends to the origin.
    *   +  ``allViewerAndWhitelistCloudFront`` ? All HTTP headers in viewer requests and the additional CloudFront headers that are listed in the ``Headers`` type are included in requests that CloudFront sends to the origin. The additional headers are added by CloudFront.
    *   +  ``allExcept`` ? All HTTP headers in viewer requests are included in requests that CloudFront sends to the origin, *except* for those listed in the ``Headers`` type, which are not included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#header_behavior CloudfrontOriginRequestPolicy#header_behavior}
    */
    readonly headerBehavior: string;
    /**
    * Contains a list of HTTP header names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#headers CloudfrontOriginRequestPolicy#headers}
    */
    readonly headers?: string[];
}
export declare function cloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfigToTerraform(struct?: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfig | cdktn.IResolvable): any;
export declare function cloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfigToHclTerraform(struct?: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfig | cdktn.IResolvable): any;
export declare class CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfig | cdktn.IResolvable | undefined);
    private _headerBehavior?;
    get headerBehavior(): string;
    set headerBehavior(value: string);
    get headerBehaviorInput(): string | undefined;
    private _headers?;
    get headers(): string[];
    set headers(value: string[]);
    resetHeaders(): void;
    get headersInput(): string[] | undefined;
}
export interface CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfig {
    /**
    * Determines whether any URL query strings in viewer requests are included in requests that CloudFront sends to the origin. Valid values are:
    *   +  ``none`` ? No query strings in viewer requests are included in requests that CloudFront sends to the origin. Even when this field is set to ``none``, any query strings that are listed in a ``CachePolicy``*are* included in origin requests.
    *   +  ``whitelist`` ? Only the query strings in viewer requests that are listed in the ``QueryStringNames`` type are included in requests that CloudFront sends to the origin.
    *   +  ``all`` ? All query strings in viewer requests are included in requests that CloudFront sends to the origin.
    *   +  ``allExcept`` ? All query strings in viewer requests are included in requests that CloudFront sends to the origin, *except* for those listed in the ``QueryStringNames`` type, which are not included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#query_string_behavior CloudfrontOriginRequestPolicy#query_string_behavior}
    */
    readonly queryStringBehavior: string;
    /**
    * Contains a list of query string names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#query_strings CloudfrontOriginRequestPolicy#query_strings}
    */
    readonly queryStrings?: string[];
}
export declare function cloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfigToTerraform(struct?: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfig | cdktn.IResolvable): any;
export declare function cloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfigToHclTerraform(struct?: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfig | cdktn.IResolvable): any;
export declare class CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfig | cdktn.IResolvable | undefined);
    private _queryStringBehavior?;
    get queryStringBehavior(): string;
    set queryStringBehavior(value: string);
    get queryStringBehaviorInput(): string | undefined;
    private _queryStrings?;
    get queryStrings(): string[];
    set queryStrings(value: string[]);
    resetQueryStrings(): void;
    get queryStringsInput(): string[] | undefined;
}
export interface CloudfrontOriginRequestPolicyOriginRequestPolicyConfig {
    /**
    * A comment to describe the origin request policy. The comment cannot be longer than 128 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#comment CloudfrontOriginRequestPolicy#comment}
    */
    readonly comment?: string;
    /**
    * The cookies from viewer requests to include in origin requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#cookies_config CloudfrontOriginRequestPolicy#cookies_config}
    */
    readonly cookiesConfig: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfig;
    /**
    * The HTTP headers to include in origin requests. These can include headers from viewer requests and additional headers added by CloudFront.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#headers_config CloudfrontOriginRequestPolicy#headers_config}
    */
    readonly headersConfig: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfig;
    /**
    * A unique name to identify the origin request policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#name CloudfrontOriginRequestPolicy#name}
    */
    readonly name: string;
    /**
    * The URL query strings from viewer requests to include in origin requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#query_strings_config CloudfrontOriginRequestPolicy#query_strings_config}
    */
    readonly queryStringsConfig: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfig;
}
export declare function cloudfrontOriginRequestPolicyOriginRequestPolicyConfigToTerraform(struct?: CloudfrontOriginRequestPolicyOriginRequestPolicyConfig | cdktn.IResolvable): any;
export declare function cloudfrontOriginRequestPolicyOriginRequestPolicyConfigToHclTerraform(struct?: CloudfrontOriginRequestPolicyOriginRequestPolicyConfig | cdktn.IResolvable): any;
export declare class CloudfrontOriginRequestPolicyOriginRequestPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontOriginRequestPolicyOriginRequestPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontOriginRequestPolicyOriginRequestPolicyConfig | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _cookiesConfig;
    get cookiesConfig(): CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfigOutputReference;
    putCookiesConfig(value: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfig): void;
    get cookiesConfigInput(): cdktn.IResolvable | CloudfrontOriginRequestPolicyOriginRequestPolicyConfigCookiesConfig | undefined;
    private _headersConfig;
    get headersConfig(): CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfigOutputReference;
    putHeadersConfig(value: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfig): void;
    get headersConfigInput(): cdktn.IResolvable | CloudfrontOriginRequestPolicyOriginRequestPolicyConfigHeadersConfig | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _queryStringsConfig;
    get queryStringsConfig(): CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfigOutputReference;
    putQueryStringsConfig(value: CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfig): void;
    get queryStringsConfigInput(): cdktn.IResolvable | CloudfrontOriginRequestPolicyOriginRequestPolicyConfigQueryStringsConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy awscc_cloudfront_origin_request_policy}
*/
export declare class CloudfrontOriginRequestPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_origin_request_policy";
    /**
    * Generates CDKTN code for importing a CloudfrontOriginRequestPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontOriginRequestPolicy to import
    * @param importFromId The id of the existing CloudfrontOriginRequestPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontOriginRequestPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_request_policy awscc_cloudfront_origin_request_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontOriginRequestPolicyConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontOriginRequestPolicyConfig);
    get id(): string;
    get lastModifiedTime(): string;
    private _originRequestPolicyConfig;
    get originRequestPolicyConfig(): CloudfrontOriginRequestPolicyOriginRequestPolicyConfigOutputReference;
    putOriginRequestPolicyConfig(value: CloudfrontOriginRequestPolicyOriginRequestPolicyConfig): void;
    get originRequestPolicyConfigInput(): cdktn.IResolvable | CloudfrontOriginRequestPolicyOriginRequestPolicyConfig | undefined;
    get originRequestPolicyId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
