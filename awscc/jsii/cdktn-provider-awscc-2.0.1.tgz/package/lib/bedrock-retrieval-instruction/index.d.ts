/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockRetrievalInstructionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the customer managed KMS key protecting this content, when one was supplied at create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#customer_encryption_key_arn BedrockRetrievalInstruction#customer_encryption_key_arn}
    */
    readonly customerEncryptionKeyArn?: string;
    /**
    * A description of the retrieval instruction. On a numbered version, the description of that version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#description BedrockRetrievalInstruction#description}
    */
    readonly description?: string;
    /**
    * The reviewed content this instruction serves ? what AgenticRetrieveStream resolves while status is ACTIVE. Absent until the first create review passes. Always present on a numbered version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#instruction BedrockRetrievalInstruction#instruction}
    */
    readonly instruction: BedrockRetrievalInstructionInstruction;
    /**
    * The name of the retrieval instruction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#name BedrockRetrievalInstruction#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#tags BedrockRetrievalInstruction#tags}
    */
    readonly tags?: BedrockRetrievalInstructionTags[] | cdktn.IResolvable;
}
export interface BedrockRetrievalInstructionInstruction {
    /**
    * How the answer is structured, including how sources are cited.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#answer_format BedrockRetrievalInstruction#answer_format}
    */
    readonly answerFormat?: string;
    /**
    * Whether and how to answer: how strongly an answer must be supported, and what to do with questions outside scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#answer_policy BedrockRetrievalInstruction#answer_policy}
    */
    readonly answerPolicy?: string;
    /**
    * Who the assistant is: identity, tone and language.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#persona BedrockRetrievalInstruction#persona}
    */
    readonly persona?: string;
    /**
    * How to interpret and decompose the question, and what to prioritise when searching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#retrieval_guidance BedrockRetrievalInstruction#retrieval_guidance}
    */
    readonly retrievalGuidance?: string;
}
export declare function bedrockRetrievalInstructionInstructionToTerraform(struct?: BedrockRetrievalInstructionInstruction | cdktn.IResolvable): any;
export declare function bedrockRetrievalInstructionInstructionToHclTerraform(struct?: BedrockRetrievalInstructionInstruction | cdktn.IResolvable): any;
export declare class BedrockRetrievalInstructionInstructionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockRetrievalInstructionInstruction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockRetrievalInstructionInstruction | cdktn.IResolvable | undefined);
    private _answerFormat?;
    get answerFormat(): string;
    set answerFormat(value: string);
    resetAnswerFormat(): void;
    get answerFormatInput(): string | undefined;
    private _answerPolicy?;
    get answerPolicy(): string;
    set answerPolicy(value: string);
    resetAnswerPolicy(): void;
    get answerPolicyInput(): string | undefined;
    private _persona?;
    get persona(): string;
    set persona(value: string);
    resetPersona(): void;
    get personaInput(): string | undefined;
    private _retrievalGuidance?;
    get retrievalGuidance(): string;
    set retrievalGuidance(value: string);
    resetRetrievalGuidance(): void;
    get retrievalGuidanceInput(): string | undefined;
}
export interface BedrockRetrievalInstructionTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#key BedrockRetrievalInstruction#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#value BedrockRetrievalInstruction#value}
    */
    readonly value?: string;
}
export declare function bedrockRetrievalInstructionTagsToTerraform(struct?: BedrockRetrievalInstructionTags | cdktn.IResolvable): any;
export declare function bedrockRetrievalInstructionTagsToHclTerraform(struct?: BedrockRetrievalInstructionTags | cdktn.IResolvable): any;
export declare class BedrockRetrievalInstructionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockRetrievalInstructionTags | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockRetrievalInstructionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BedrockRetrievalInstructionTagsList extends cdktn.ComplexList {
    internalValue?: BedrockRetrievalInstructionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockRetrievalInstructionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction awscc_bedrock_retrieval_instruction}
*/
export declare class BedrockRetrievalInstruction extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_retrieval_instruction";
    /**
    * Generates CDKTN code for importing a BedrockRetrievalInstruction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockRetrievalInstruction to import
    * @param importFromId The id of the existing BedrockRetrievalInstruction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockRetrievalInstruction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_retrieval_instruction awscc_bedrock_retrieval_instruction} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockRetrievalInstructionConfig
    */
    constructor(scope: Construct, id: string, config: BedrockRetrievalInstructionConfig);
    get arn(): string;
    get createdAt(): string;
    private _customerEncryptionKeyArn?;
    get customerEncryptionKeyArn(): string;
    set customerEncryptionKeyArn(value: string);
    resetCustomerEncryptionKeyArn(): void;
    get customerEncryptionKeyArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instruction;
    get instruction(): BedrockRetrievalInstructionInstructionOutputReference;
    putInstruction(value: BedrockRetrievalInstructionInstruction): void;
    get instructionInput(): cdktn.IResolvable | BedrockRetrievalInstructionInstruction | undefined;
    get lastTransitionStatus(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get retrievalInstructionId(): string;
    get status(): string;
    private _tags;
    get tags(): BedrockRetrievalInstructionTagsList;
    putTags(value: BedrockRetrievalInstructionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BedrockRetrievalInstructionTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
