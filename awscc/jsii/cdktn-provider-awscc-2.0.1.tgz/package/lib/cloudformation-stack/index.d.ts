/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationStackConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#capabilities CloudformationStack#capabilities}
    */
    readonly capabilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#description CloudformationStack#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#disable_rollback CloudformationStack#disable_rollback}
    */
    readonly disableRollback?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#enable_termination_protection CloudformationStack#enable_termination_protection}
    */
    readonly enableTerminationProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#notification_ar_ns CloudformationStack#notification_ar_ns}
    */
    readonly notificationArNs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#parameters CloudformationStack#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#role_arn CloudformationStack#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#stack_name CloudformationStack#stack_name}
    */
    readonly stackName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#stack_policy_body CloudformationStack#stack_policy_body}
    */
    readonly stackPolicyBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#stack_policy_url CloudformationStack#stack_policy_url}
    */
    readonly stackPolicyUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#stack_status_reason CloudformationStack#stack_status_reason}
    */
    readonly stackStatusReason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#tags CloudformationStack#tags}
    */
    readonly tags?: CloudformationStackTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#template_body CloudformationStack#template_body}
    */
    readonly templateBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#template_url CloudformationStack#template_url}
    */
    readonly templateUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#timeout_in_minutes CloudformationStack#timeout_in_minutes}
    */
    readonly timeoutInMinutes?: number;
}
export interface CloudformationStackOutputs {
}
export declare function cloudformationStackOutputsToTerraform(struct?: CloudformationStackOutputs): any;
export declare function cloudformationStackOutputsToHclTerraform(struct?: CloudformationStackOutputs): any;
export declare class CloudformationStackOutputsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationStackOutputs | undefined;
    set internalValue(value: CloudformationStackOutputs | undefined);
    get description(): string;
    get exportName(): string;
    get outputKey(): string;
    get outputValue(): string;
}
export declare class CloudformationStackOutputsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationStackOutputsOutputReference;
}
export interface CloudformationStackTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#key CloudformationStack#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#value CloudformationStack#value}
    */
    readonly value?: string;
}
export declare function cloudformationStackTagsToTerraform(struct?: CloudformationStackTags | cdktn.IResolvable): any;
export declare function cloudformationStackTagsToHclTerraform(struct?: CloudformationStackTags | cdktn.IResolvable): any;
export declare class CloudformationStackTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationStackTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudformationStackTagsList extends cdktn.ComplexList {
    internalValue?: CloudformationStackTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationStackTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack awscc_cloudformation_stack}
*/
export declare class CloudformationStack extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_stack";
    /**
    * Generates CDKTN code for importing a CloudformationStack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationStack to import
    * @param importFromId The id of the existing CloudformationStack that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationStack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack awscc_cloudformation_stack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationStackConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationStackConfig);
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    resetCapabilities(): void;
    get capabilitiesInput(): string[] | undefined;
    get changeSetId(): string;
    get creationTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableRollback?;
    get disableRollback(): boolean | cdktn.IResolvable;
    set disableRollback(value: boolean | cdktn.IResolvable);
    resetDisableRollback(): void;
    get disableRollbackInput(): boolean | cdktn.IResolvable | undefined;
    private _enableTerminationProtection?;
    get enableTerminationProtection(): boolean | cdktn.IResolvable;
    set enableTerminationProtection(value: boolean | cdktn.IResolvable);
    resetEnableTerminationProtection(): void;
    get enableTerminationProtectionInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get lastUpdateTime(): string;
    private _notificationArNs?;
    get notificationArNs(): string[];
    set notificationArNs(value: string[]);
    resetNotificationArNs(): void;
    get notificationArNsInput(): string[] | undefined;
    private _outputs;
    get outputs(): CloudformationStackOutputsList;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    get parentId(): string;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    get rootId(): string;
    get stackId(): string;
    private _stackName?;
    get stackName(): string;
    set stackName(value: string);
    get stackNameInput(): string | undefined;
    private _stackPolicyBody?;
    get stackPolicyBody(): string;
    set stackPolicyBody(value: string);
    resetStackPolicyBody(): void;
    get stackPolicyBodyInput(): string | undefined;
    private _stackPolicyUrl?;
    get stackPolicyUrl(): string;
    set stackPolicyUrl(value: string);
    resetStackPolicyUrl(): void;
    get stackPolicyUrlInput(): string | undefined;
    get stackStatus(): string;
    private _stackStatusReason?;
    get stackStatusReason(): string;
    set stackStatusReason(value: string);
    resetStackStatusReason(): void;
    get stackStatusReasonInput(): string | undefined;
    private _tags;
    get tags(): CloudformationStackTagsList;
    putTags(value: CloudformationStackTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudformationStackTags[] | undefined;
    private _templateBody?;
    get templateBody(): string;
    set templateBody(value: string);
    resetTemplateBody(): void;
    get templateBodyInput(): string | undefined;
    private _templateUrl?;
    get templateUrl(): string;
    set templateUrl(value: string);
    resetTemplateUrl(): void;
    get templateUrlInput(): string | undefined;
    private _timeoutInMinutes?;
    get timeoutInMinutes(): number;
    set timeoutInMinutes(value: number);
    resetTimeoutInMinutes(): void;
    get timeoutInMinutesInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
