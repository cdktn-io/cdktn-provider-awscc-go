/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsmlTrainingDatasetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#description CleanroomsmlTrainingDataset#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#name CleanroomsmlTrainingDataset#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#role_arn CleanroomsmlTrainingDataset#role_arn}
    */
    readonly roleArn: string;
    /**
    * An arbitrary set of tags (key-value pairs) for this cleanrooms-ml training dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#tags CleanroomsmlTrainingDataset#tags}
    */
    readonly tags?: CleanroomsmlTrainingDatasetTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#training_data CleanroomsmlTrainingDataset#training_data}
    */
    readonly trainingData: CleanroomsmlTrainingDatasetTrainingData[] | cdktn.IResolvable;
}
export interface CleanroomsmlTrainingDatasetTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#key CleanroomsmlTrainingDataset#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#value CleanroomsmlTrainingDataset#value}
    */
    readonly value?: string;
}
export declare function cleanroomsmlTrainingDatasetTagsToTerraform(struct?: CleanroomsmlTrainingDatasetTags | cdktn.IResolvable): any;
export declare function cleanroomsmlTrainingDatasetTagsToHclTerraform(struct?: CleanroomsmlTrainingDatasetTags | cdktn.IResolvable): any;
export declare class CleanroomsmlTrainingDatasetTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsmlTrainingDatasetTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlTrainingDatasetTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsmlTrainingDatasetTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsmlTrainingDatasetTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsmlTrainingDatasetTagsOutputReference;
}
export interface CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#catalog_id CleanroomsmlTrainingDataset#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#database_name CleanroomsmlTrainingDataset#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#table_name CleanroomsmlTrainingDataset#table_name}
    */
    readonly tableName: string;
}
export declare function cleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSourceToTerraform(struct?: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSource | cdktn.IResolvable): any;
export declare function cleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSourceToHclTerraform(struct?: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSource | cdktn.IResolvable): any;
export declare class CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSource | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSource | cdktn.IResolvable | undefined);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#glue_data_source CleanroomsmlTrainingDataset#glue_data_source}
    */
    readonly glueDataSource: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSource;
}
export declare function cleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceToTerraform(struct?: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSource | cdktn.IResolvable): any;
export declare function cleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceToHclTerraform(struct?: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSource | cdktn.IResolvable): any;
export declare class CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSource | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSource | cdktn.IResolvable | undefined);
    private _glueDataSource;
    get glueDataSource(): CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSourceOutputReference;
    putGlueDataSource(value: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSource): void;
    get glueDataSourceInput(): cdktn.IResolvable | CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceGlueDataSource | undefined;
}
export interface CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#column_name CleanroomsmlTrainingDataset#column_name}
    */
    readonly columnName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#column_types CleanroomsmlTrainingDataset#column_types}
    */
    readonly columnTypes: string[];
}
export declare function cleanroomsmlTrainingDatasetTrainingDataInputConfigSchemaToTerraform(struct?: CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema | cdktn.IResolvable): any;
export declare function cleanroomsmlTrainingDatasetTrainingDataInputConfigSchemaToHclTerraform(struct?: CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema | cdktn.IResolvable): any;
export declare class CleanroomsmlTrainingDatasetTrainingDataInputConfigSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    get columnNameInput(): string | undefined;
    private _columnTypes?;
    get columnTypes(): string[];
    set columnTypes(value: string[]);
    get columnTypesInput(): string[] | undefined;
}
export declare class CleanroomsmlTrainingDatasetTrainingDataInputConfigSchemaList extends cdktn.ComplexList {
    internalValue?: CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsmlTrainingDatasetTrainingDataInputConfigSchemaOutputReference;
}
export interface CleanroomsmlTrainingDatasetTrainingDataInputConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#data_source CleanroomsmlTrainingDataset#data_source}
    */
    readonly dataSource: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#schema CleanroomsmlTrainingDataset#schema}
    */
    readonly schema: CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema[] | cdktn.IResolvable;
}
export declare function cleanroomsmlTrainingDatasetTrainingDataInputConfigToTerraform(struct?: CleanroomsmlTrainingDatasetTrainingDataInputConfig | cdktn.IResolvable): any;
export declare function cleanroomsmlTrainingDatasetTrainingDataInputConfigToHclTerraform(struct?: CleanroomsmlTrainingDatasetTrainingDataInputConfig | cdktn.IResolvable): any;
export declare class CleanroomsmlTrainingDatasetTrainingDataInputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsmlTrainingDatasetTrainingDataInputConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlTrainingDatasetTrainingDataInputConfig | cdktn.IResolvable | undefined);
    private _dataSource;
    get dataSource(): CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSourceOutputReference;
    putDataSource(value: CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSource): void;
    get dataSourceInput(): cdktn.IResolvable | CleanroomsmlTrainingDatasetTrainingDataInputConfigDataSource | undefined;
    private _schema;
    get schema(): CleanroomsmlTrainingDatasetTrainingDataInputConfigSchemaList;
    putSchema(value: CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema[] | cdktn.IResolvable): void;
    get schemaInput(): cdktn.IResolvable | CleanroomsmlTrainingDatasetTrainingDataInputConfigSchema[] | undefined;
}
export interface CleanroomsmlTrainingDatasetTrainingData {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#input_config CleanroomsmlTrainingDataset#input_config}
    */
    readonly inputConfig: CleanroomsmlTrainingDatasetTrainingDataInputConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#type CleanroomsmlTrainingDataset#type}
    */
    readonly type: string;
}
export declare function cleanroomsmlTrainingDatasetTrainingDataToTerraform(struct?: CleanroomsmlTrainingDatasetTrainingData | cdktn.IResolvable): any;
export declare function cleanroomsmlTrainingDatasetTrainingDataToHclTerraform(struct?: CleanroomsmlTrainingDatasetTrainingData | cdktn.IResolvable): any;
export declare class CleanroomsmlTrainingDatasetTrainingDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsmlTrainingDatasetTrainingData | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsmlTrainingDatasetTrainingData | cdktn.IResolvable | undefined);
    private _inputConfig;
    get inputConfig(): CleanroomsmlTrainingDatasetTrainingDataInputConfigOutputReference;
    putInputConfig(value: CleanroomsmlTrainingDatasetTrainingDataInputConfig): void;
    get inputConfigInput(): cdktn.IResolvable | CleanroomsmlTrainingDatasetTrainingDataInputConfig | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class CleanroomsmlTrainingDatasetTrainingDataList extends cdktn.ComplexList {
    internalValue?: CleanroomsmlTrainingDatasetTrainingData[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsmlTrainingDatasetTrainingDataOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset awscc_cleanroomsml_training_dataset}
*/
export declare class CleanroomsmlTrainingDataset extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanroomsml_training_dataset";
    /**
    * Generates CDKTN code for importing a CleanroomsmlTrainingDataset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsmlTrainingDataset to import
    * @param importFromId The id of the existing CleanroomsmlTrainingDataset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsmlTrainingDataset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanroomsml_training_dataset awscc_cleanroomsml_training_dataset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsmlTrainingDatasetConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsmlTrainingDatasetConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): CleanroomsmlTrainingDatasetTagsList;
    putTags(value: CleanroomsmlTrainingDatasetTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsmlTrainingDatasetTags[] | undefined;
    private _trainingData;
    get trainingData(): CleanroomsmlTrainingDatasetTrainingDataList;
    putTrainingData(value: CleanroomsmlTrainingDatasetTrainingData[] | cdktn.IResolvable): void;
    get trainingDataInput(): cdktn.IResolvable | CleanroomsmlTrainingDatasetTrainingData[] | undefined;
    get trainingDatasetArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
