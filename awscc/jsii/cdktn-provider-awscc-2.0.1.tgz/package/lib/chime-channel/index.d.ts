/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the AppInstance that contains the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#app_instance_arn ChimeChannel#app_instance_arn}
    */
    readonly appInstanceArn: string;
    /**
    * The ID of the channel. When omitted, the service generates a UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#channel_id ChimeChannel#channel_id}
    */
    readonly channelId?: string;
    /**
    * The ARN of the AppInstanceUser or AppInstanceBot that performs every operation on this channel. Whichever of the two creates a channel automatically becomes one of its moderators, so the same ARN can subsequently read, update and delete the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#chime_bearer ChimeChannel#chime_bearer}
    */
    readonly chimeBearer: string;
    /**
    * The attributes required to configure and create an elastic channel. An elastic channel must use RESTRICTED mode, cannot be created with MemberArns, and is available only in some regions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#elastic_channel_configuration ChimeChannel#elastic_channel_configuration}
    */
    readonly elasticChannelConfiguration?: ChimeChannelElasticChannelConfiguration;
    /**
    * Settings that control the interval after which the channel is automatically deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#expiration_settings ChimeChannel#expiration_settings}
    */
    readonly expirationSettings?: ChimeChannelExpirationSettings;
    /**
    * The ARNs of the AppInstanceUsers to add to the channel as members when it is created. Cannot be combined with ElasticChannelConfiguration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#member_arns ChimeChannel#member_arns}
    */
    readonly memberArns?: string[];
    /**
    * The metadata of the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#metadata ChimeChannel#metadata}
    */
    readonly metadata?: string;
    /**
    * The channel mode. In an UNRESTRICTED channel, members can add themselves and other members; in a RESTRICTED channel, only administrators and moderators can add members. An elastic channel must be RESTRICTED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#mode ChimeChannel#mode}
    */
    readonly mode?: string;
    /**
    * The ARNs of the AppInstanceUsers to add to the channel as moderators when it is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#moderator_arns ChimeChannel#moderator_arns}
    */
    readonly moderatorArns?: string[];
    /**
    * The name of the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#name ChimeChannel#name}
    */
    readonly name: string;
    /**
    * The channel's privacy level. A PUBLIC channel is discoverable by anyone in the AppInstance; a PRIVATE channel is not. Privacy cannot be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#privacy ChimeChannel#privacy}
    */
    readonly privacy?: string;
    /**
    * The tags for the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#tags ChimeChannel#tags}
    */
    readonly tags?: ChimeChannelTags[] | cdktn.IResolvable;
}
export interface ChimeChannelCreatedBy {
}
export declare function chimeChannelCreatedByToTerraform(struct?: ChimeChannelCreatedBy): any;
export declare function chimeChannelCreatedByToHclTerraform(struct?: ChimeChannelCreatedBy): any;
export declare class ChimeChannelCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeChannelCreatedBy | undefined;
    set internalValue(value: ChimeChannelCreatedBy | undefined);
    get arn(): string;
    get name(): string;
}
export interface ChimeChannelElasticChannelConfiguration {
    /**
    * The maximum number of SubChannels allowed in the elastic channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#maximum_sub_channels ChimeChannel#maximum_sub_channels}
    */
    readonly maximumSubChannels?: number;
    /**
    * The minimum allowed percentage of TargetMembershipsPerSubChannel users, used to balance members across SubChannels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#minimum_membership_percentage ChimeChannel#minimum_membership_percentage}
    */
    readonly minimumMembershipPercentage?: number;
    /**
    * The maximum number of members allowed in a SubChannel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#target_memberships_per_sub_channel ChimeChannel#target_memberships_per_sub_channel}
    */
    readonly targetMembershipsPerSubChannel?: number;
}
export declare function chimeChannelElasticChannelConfigurationToTerraform(struct?: ChimeChannelElasticChannelConfiguration | cdktn.IResolvable): any;
export declare function chimeChannelElasticChannelConfigurationToHclTerraform(struct?: ChimeChannelElasticChannelConfiguration | cdktn.IResolvable): any;
export declare class ChimeChannelElasticChannelConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeChannelElasticChannelConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeChannelElasticChannelConfiguration | cdktn.IResolvable | undefined);
    private _maximumSubChannels?;
    get maximumSubChannels(): number;
    set maximumSubChannels(value: number);
    resetMaximumSubChannels(): void;
    get maximumSubChannelsInput(): number | undefined;
    private _minimumMembershipPercentage?;
    get minimumMembershipPercentage(): number;
    set minimumMembershipPercentage(value: number);
    resetMinimumMembershipPercentage(): void;
    get minimumMembershipPercentageInput(): number | undefined;
    private _targetMembershipsPerSubChannel?;
    get targetMembershipsPerSubChannel(): number;
    set targetMembershipsPerSubChannel(value: number);
    resetTargetMembershipsPerSubChannel(): void;
    get targetMembershipsPerSubChannelInput(): number | undefined;
}
export interface ChimeChannelExpirationSettings {
    /**
    * The condition the expiration period is measured from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#expiration_criterion ChimeChannel#expiration_criterion}
    */
    readonly expirationCriterion?: string;
    /**
    * The period in days after which the system automatically deletes the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#expiration_days ChimeChannel#expiration_days}
    */
    readonly expirationDays?: number;
}
export declare function chimeChannelExpirationSettingsToTerraform(struct?: ChimeChannelExpirationSettings | cdktn.IResolvable): any;
export declare function chimeChannelExpirationSettingsToHclTerraform(struct?: ChimeChannelExpirationSettings | cdktn.IResolvable): any;
export declare class ChimeChannelExpirationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeChannelExpirationSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeChannelExpirationSettings | cdktn.IResolvable | undefined);
    private _expirationCriterion?;
    get expirationCriterion(): string;
    set expirationCriterion(value: string);
    resetExpirationCriterion(): void;
    get expirationCriterionInput(): string | undefined;
    private _expirationDays?;
    get expirationDays(): number;
    set expirationDays(value: number);
    resetExpirationDays(): void;
    get expirationDaysInput(): number | undefined;
}
export interface ChimeChannelTags {
    /**
    * The key in a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#key ChimeChannel#key}
    */
    readonly key?: string;
    /**
    * The value in a tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#value ChimeChannel#value}
    */
    readonly value?: string;
}
export declare function chimeChannelTagsToTerraform(struct?: ChimeChannelTags | cdktn.IResolvable): any;
export declare function chimeChannelTagsToHclTerraform(struct?: ChimeChannelTags | cdktn.IResolvable): any;
export declare class ChimeChannelTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeChannelTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeChannelTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeChannelTagsList extends cdktn.ComplexList {
    internalValue?: ChimeChannelTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeChannelTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel awscc_chime_channel}
*/
export declare class ChimeChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_channel";
    /**
    * Generates CDKTN code for importing a ChimeChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeChannel to import
    * @param importFromId The id of the existing ChimeChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_channel awscc_chime_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeChannelConfig
    */
    constructor(scope: Construct, id: string, config: ChimeChannelConfig);
    private _appInstanceArn?;
    get appInstanceArn(): string;
    set appInstanceArn(value: string);
    get appInstanceArnInput(): string | undefined;
    get arn(): string;
    get channelFlowArn(): string;
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    resetChannelId(): void;
    get channelIdInput(): string | undefined;
    private _chimeBearer?;
    get chimeBearer(): string;
    set chimeBearer(value: string);
    get chimeBearerInput(): string | undefined;
    private _createdBy;
    get createdBy(): ChimeChannelCreatedByOutputReference;
    get createdTimestamp(): string;
    private _elasticChannelConfiguration;
    get elasticChannelConfiguration(): ChimeChannelElasticChannelConfigurationOutputReference;
    putElasticChannelConfiguration(value: ChimeChannelElasticChannelConfiguration): void;
    resetElasticChannelConfiguration(): void;
    get elasticChannelConfigurationInput(): cdktn.IResolvable | ChimeChannelElasticChannelConfiguration | undefined;
    private _expirationSettings;
    get expirationSettings(): ChimeChannelExpirationSettingsOutputReference;
    putExpirationSettings(value: ChimeChannelExpirationSettings): void;
    resetExpirationSettings(): void;
    get expirationSettingsInput(): cdktn.IResolvable | ChimeChannelExpirationSettings | undefined;
    get id(): string;
    get lastMessageTimestamp(): string;
    get lastUpdatedTimestamp(): string;
    private _memberArns?;
    get memberArns(): string[];
    set memberArns(value: string[]);
    resetMemberArns(): void;
    get memberArnsInput(): string[] | undefined;
    private _metadata?;
    get metadata(): string;
    set metadata(value: string);
    resetMetadata(): void;
    get metadataInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _moderatorArns?;
    get moderatorArns(): string[];
    set moderatorArns(value: string[]);
    resetModeratorArns(): void;
    get moderatorArnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _privacy?;
    get privacy(): string;
    set privacy(value: string);
    resetPrivacy(): void;
    get privacyInput(): string | undefined;
    private _tags;
    get tags(): ChimeChannelTagsList;
    putTags(value: ChimeChannelTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeChannelTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
