/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BatchComputeEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#compute_environment_name BatchComputeEnvironment#compute_environment_name}
    */
    readonly computeEnvironmentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#compute_resources BatchComputeEnvironment#compute_resources}
    */
    readonly computeResources?: BatchComputeEnvironmentComputeResources;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#context BatchComputeEnvironment#context}
    */
    readonly context?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#ecs_settings BatchComputeEnvironment#ecs_settings}
    */
    readonly ecsSettings?: BatchComputeEnvironmentEcsSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#eks_configuration BatchComputeEnvironment#eks_configuration}
    */
    readonly eksConfiguration?: BatchComputeEnvironmentEksConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#replace_compute_environment BatchComputeEnvironment#replace_compute_environment}
    */
    readonly replaceComputeEnvironment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#service_role BatchComputeEnvironment#service_role}
    */
    readonly serviceRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#state BatchComputeEnvironment#state}
    */
    readonly state?: string;
    /**
    * A key-value pair to associate with a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#tags BatchComputeEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#type BatchComputeEnvironment#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#unmanagedv_cpus BatchComputeEnvironment#unmanagedv_cpus}
    */
    readonly unmanagedvCpus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#update_policy BatchComputeEnvironment#update_policy}
    */
    readonly updatePolicy?: BatchComputeEnvironmentUpdatePolicy;
}
export interface BatchComputeEnvironmentComputeResourcesEc2Configuration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#batch_image_status BatchComputeEnvironment#batch_image_status}
    */
    readonly batchImageStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#image_id_override BatchComputeEnvironment#image_id_override}
    */
    readonly imageIdOverride?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#image_kubernetes_version BatchComputeEnvironment#image_kubernetes_version}
    */
    readonly imageKubernetesVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#image_type BatchComputeEnvironment#image_type}
    */
    readonly imageType?: string;
}
export declare function batchComputeEnvironmentComputeResourcesEc2ConfigurationToTerraform(struct?: BatchComputeEnvironmentComputeResourcesEc2Configuration | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesEc2ConfigurationToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesEc2Configuration | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesEc2ConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchComputeEnvironmentComputeResourcesEc2Configuration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesEc2Configuration | cdktn.IResolvable | undefined);
    private _batchImageStatus?;
    get batchImageStatus(): string;
    set batchImageStatus(value: string);
    resetBatchImageStatus(): void;
    get batchImageStatusInput(): string | undefined;
    private _imageIdOverride?;
    get imageIdOverride(): string;
    set imageIdOverride(value: string);
    resetImageIdOverride(): void;
    get imageIdOverrideInput(): string | undefined;
    private _imageKubernetesVersion?;
    get imageKubernetesVersion(): string;
    set imageKubernetesVersion(value: string);
    resetImageKubernetesVersion(): void;
    get imageKubernetesVersionInput(): string | undefined;
    private _imageType?;
    get imageType(): string;
    set imageType(value: string);
    resetImageType(): void;
    get imageTypeInput(): string | undefined;
}
export declare class BatchComputeEnvironmentComputeResourcesEc2ConfigurationList extends cdktn.ComplexList {
    internalValue?: BatchComputeEnvironmentComputeResourcesEc2Configuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchComputeEnvironmentComputeResourcesEc2ConfigurationOutputReference;
}
export interface BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#launch_template_id BatchComputeEnvironment#launch_template_id}
    */
    readonly launchTemplateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#launch_template_name BatchComputeEnvironment#launch_template_name}
    */
    readonly launchTemplateName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#target_instance_types BatchComputeEnvironment#target_instance_types}
    */
    readonly targetInstanceTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#userdata_type BatchComputeEnvironment#userdata_type}
    */
    readonly userdataType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#version BatchComputeEnvironment#version}
    */
    readonly version?: string;
}
export declare function batchComputeEnvironmentComputeResourcesLaunchTemplateOverridesToTerraform(struct?: BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesLaunchTemplateOverridesToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesLaunchTemplateOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides | cdktn.IResolvable | undefined);
    private _launchTemplateId?;
    get launchTemplateId(): string;
    set launchTemplateId(value: string);
    resetLaunchTemplateId(): void;
    get launchTemplateIdInput(): string | undefined;
    private _launchTemplateName?;
    get launchTemplateName(): string;
    set launchTemplateName(value: string);
    resetLaunchTemplateName(): void;
    get launchTemplateNameInput(): string | undefined;
    private _targetInstanceTypes?;
    get targetInstanceTypes(): string[];
    set targetInstanceTypes(value: string[]);
    resetTargetInstanceTypes(): void;
    get targetInstanceTypesInput(): string[] | undefined;
    private _userdataType?;
    get userdataType(): string;
    set userdataType(value: string);
    resetUserdataType(): void;
    get userdataTypeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class BatchComputeEnvironmentComputeResourcesLaunchTemplateOverridesList extends cdktn.ComplexList {
    internalValue?: BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchComputeEnvironmentComputeResourcesLaunchTemplateOverridesOutputReference;
}
export interface BatchComputeEnvironmentComputeResourcesLaunchTemplate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#launch_template_id BatchComputeEnvironment#launch_template_id}
    */
    readonly launchTemplateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#launch_template_name BatchComputeEnvironment#launch_template_name}
    */
    readonly launchTemplateName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#overrides BatchComputeEnvironment#overrides}
    */
    readonly overrides?: BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#userdata_type BatchComputeEnvironment#userdata_type}
    */
    readonly userdataType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#version BatchComputeEnvironment#version}
    */
    readonly version?: string;
}
export declare function batchComputeEnvironmentComputeResourcesLaunchTemplateToTerraform(struct?: BatchComputeEnvironmentComputeResourcesLaunchTemplate | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesLaunchTemplateToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesLaunchTemplate | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesLaunchTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesLaunchTemplate | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesLaunchTemplate | cdktn.IResolvable | undefined);
    private _launchTemplateId?;
    get launchTemplateId(): string;
    set launchTemplateId(value: string);
    resetLaunchTemplateId(): void;
    get launchTemplateIdInput(): string | undefined;
    private _launchTemplateName?;
    get launchTemplateName(): string;
    set launchTemplateName(value: string);
    resetLaunchTemplateName(): void;
    get launchTemplateNameInput(): string | undefined;
    private _overrides;
    get overrides(): BatchComputeEnvironmentComputeResourcesLaunchTemplateOverridesList;
    putOverrides(value: BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides[] | cdktn.IResolvable): void;
    resetOverrides(): void;
    get overridesInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesLaunchTemplateOverrides[] | undefined;
    private _userdataType?;
    get userdataType(): string;
    set userdataType(value: string);
    resetUserdataType(): void;
    get userdataTypeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimization {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#scale_in_after BatchComputeEnvironment#scale_in_after}
    */
    readonly scaleInAfter?: number;
}
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimizationToTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimization | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimizationToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimization | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimization | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimization | cdktn.IResolvable | undefined);
    private _scaleInAfter?;
    get scaleInAfter(): number;
    set scaleInAfter(value: number);
    resetScaleInAfter(): void;
    get scaleInAfterInput(): number | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#reservation_group_arn BatchComputeEnvironment#reservation_group_arn}
    */
    readonly reservationGroupArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#reservation_preference BatchComputeEnvironment#reservation_preference}
    */
    readonly reservationPreference?: string;
}
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservationsToTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservations | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservationsToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservations | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservations | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservations | cdktn.IResolvable | undefined);
    private _reservationGroupArn?;
    get reservationGroupArn(): string;
    set reservationGroupArn(value: string);
    resetReservationGroupArn(): void;
    get reservationGroupArnInput(): string | undefined;
    private _reservationPreference?;
    get reservationPreference(): string;
    set reservationPreference(value: string);
    resetReservationPreference(): void;
    get reservationPreferenceInput(): string | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirements {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#allowed_instance_types BatchComputeEnvironment#allowed_instance_types}
    */
    readonly allowedInstanceTypes?: string[];
}
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirementsToTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirements | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirementsToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirements | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirements | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirements | cdktn.IResolvable | undefined);
    private _allowedInstanceTypes?;
    get allowedInstanceTypes(): string[];
    set allowedInstanceTypes(value: string[]);
    resetAllowedInstanceTypes(): void;
    get allowedInstanceTypesInput(): string[] | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#use_local_storage BatchComputeEnvironment#use_local_storage}
    */
    readonly useLocalStorage?: boolean | cdktn.IResolvable;
}
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfigurationToTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfiguration | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfigurationToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfiguration | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfiguration | cdktn.IResolvable | undefined);
    private _useLocalStorage?;
    get useLocalStorage(): boolean | cdktn.IResolvable;
    set useLocalStorage(value: boolean | cdktn.IResolvable);
    resetUseLocalStorage(): void;
    get useLocalStorageInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#security_groups BatchComputeEnvironment#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#subnets BatchComputeEnvironment#subnets}
    */
    readonly subnets?: string[];
}
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfigurationToTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfiguration | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfigurationToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfiguration | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfiguration | cdktn.IResolvable | undefined);
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#storage_size_gi_b BatchComputeEnvironment#storage_size_gi_b}
    */
    readonly storageSizeGiB?: number;
}
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfigurationToTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfiguration | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfigurationToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfiguration | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfiguration | cdktn.IResolvable | undefined);
    private _storageSizeGiB?;
    get storageSizeGiB(): number;
    set storageSizeGiB(value: number);
    resetStorageSizeGiB(): void;
    get storageSizeGiBInput(): number | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#capacity_option_type BatchComputeEnvironment#capacity_option_type}
    */
    readonly capacityOptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#capacity_reservations BatchComputeEnvironment#capacity_reservations}
    */
    readonly capacityReservations?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservations;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#ec_2_instance_profile_arn BatchComputeEnvironment#ec_2_instance_profile_arn}
    */
    readonly ec2InstanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#fips_enabled BatchComputeEnvironment#fips_enabled}
    */
    readonly fipsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#instance_metadata_tags_propagation BatchComputeEnvironment#instance_metadata_tags_propagation}
    */
    readonly instanceMetadataTagsPropagation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#instance_requirements BatchComputeEnvironment#instance_requirements}
    */
    readonly instanceRequirements?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirements;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#local_storage_configuration BatchComputeEnvironment#local_storage_configuration}
    */
    readonly localStorageConfiguration?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#monitoring BatchComputeEnvironment#monitoring}
    */
    readonly monitoring?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#network_configuration BatchComputeEnvironment#network_configuration}
    */
    readonly networkConfiguration?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#storage_configuration BatchComputeEnvironment#storage_configuration}
    */
    readonly storageConfiguration?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfiguration;
}
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateToTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplate | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplate | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplate | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplate | cdktn.IResolvable | undefined);
    private _capacityOptionType?;
    get capacityOptionType(): string;
    set capacityOptionType(value: string);
    resetCapacityOptionType(): void;
    get capacityOptionTypeInput(): string | undefined;
    private _capacityReservations;
    get capacityReservations(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservationsOutputReference;
    putCapacityReservations(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservations): void;
    resetCapacityReservations(): void;
    get capacityReservationsInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateCapacityReservations | undefined;
    private _ec2InstanceProfileArn?;
    get ec2InstanceProfileArn(): string;
    set ec2InstanceProfileArn(value: string);
    resetEc2InstanceProfileArn(): void;
    get ec2InstanceProfileArnInput(): string | undefined;
    private _fipsEnabled?;
    get fipsEnabled(): boolean | cdktn.IResolvable;
    set fipsEnabled(value: boolean | cdktn.IResolvable);
    resetFipsEnabled(): void;
    get fipsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _instanceMetadataTagsPropagation?;
    get instanceMetadataTagsPropagation(): boolean | cdktn.IResolvable;
    set instanceMetadataTagsPropagation(value: boolean | cdktn.IResolvable);
    resetInstanceMetadataTagsPropagation(): void;
    get instanceMetadataTagsPropagationInput(): boolean | cdktn.IResolvable | undefined;
    private _instanceRequirements;
    get instanceRequirements(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirementsOutputReference;
    putInstanceRequirements(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirements): void;
    resetInstanceRequirements(): void;
    get instanceRequirementsInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateInstanceRequirements | undefined;
    private _localStorageConfiguration;
    get localStorageConfiguration(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfigurationOutputReference;
    putLocalStorageConfiguration(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfiguration): void;
    resetLocalStorageConfiguration(): void;
    get localStorageConfigurationInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateLocalStorageConfiguration | undefined;
    private _monitoring?;
    get monitoring(): string;
    set monitoring(value: string);
    resetMonitoring(): void;
    get monitoringInput(): string | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfigurationOutputReference;
    putNetworkConfiguration(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfiguration): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateNetworkConfiguration | undefined;
    private _storageConfiguration;
    get storageConfiguration(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfigurationOutputReference;
    putStorageConfiguration(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfiguration): void;
    resetStorageConfiguration(): void;
    get storageConfigurationInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateStorageConfiguration | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesManagedInstancesProvider {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#infrastructure_optimization BatchComputeEnvironment#infrastructure_optimization}
    */
    readonly infrastructureOptimization?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimization;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#infrastructure_role_arn BatchComputeEnvironment#infrastructure_role_arn}
    */
    readonly infrastructureRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#instance_launch_template BatchComputeEnvironment#instance_launch_template}
    */
    readonly instanceLaunchTemplate?: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplate;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#propagate_tags BatchComputeEnvironment#propagate_tags}
    */
    readonly propagateTags?: string;
}
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderToTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProvider | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesManagedInstancesProviderToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesManagedInstancesProvider | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesManagedInstancesProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesManagedInstancesProvider | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProvider | cdktn.IResolvable | undefined);
    private _infrastructureOptimization;
    get infrastructureOptimization(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimizationOutputReference;
    putInfrastructureOptimization(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimization): void;
    resetInfrastructureOptimization(): void;
    get infrastructureOptimizationInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInfrastructureOptimization | undefined;
    private _infrastructureRoleArn?;
    get infrastructureRoleArn(): string;
    set infrastructureRoleArn(value: string);
    resetInfrastructureRoleArn(): void;
    get infrastructureRoleArnInput(): string | undefined;
    private _instanceLaunchTemplate;
    get instanceLaunchTemplate(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplateOutputReference;
    putInstanceLaunchTemplate(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplate): void;
    resetInstanceLaunchTemplate(): void;
    get instanceLaunchTemplateInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesManagedInstancesProviderInstanceLaunchTemplate | undefined;
    private _propagateTags?;
    get propagateTags(): string;
    set propagateTags(value: string);
    resetPropagateTags(): void;
    get propagateTagsInput(): string | undefined;
}
export interface BatchComputeEnvironmentComputeResourcesScalingPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#min_scale_down_delay_minutes BatchComputeEnvironment#min_scale_down_delay_minutes}
    */
    readonly minScaleDownDelayMinutes?: number;
}
export declare function batchComputeEnvironmentComputeResourcesScalingPolicyToTerraform(struct?: BatchComputeEnvironmentComputeResourcesScalingPolicy | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesScalingPolicyToHclTerraform(struct?: BatchComputeEnvironmentComputeResourcesScalingPolicy | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesScalingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResourcesScalingPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResourcesScalingPolicy | cdktn.IResolvable | undefined);
    private _minScaleDownDelayMinutes?;
    get minScaleDownDelayMinutes(): number;
    set minScaleDownDelayMinutes(value: number);
    resetMinScaleDownDelayMinutes(): void;
    get minScaleDownDelayMinutesInput(): number | undefined;
}
export interface BatchComputeEnvironmentComputeResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#allocation_strategy BatchComputeEnvironment#allocation_strategy}
    */
    readonly allocationStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#bid_percentage BatchComputeEnvironment#bid_percentage}
    */
    readonly bidPercentage?: number;
    /**
    * Capacity-level tags for compute environments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#capacity_tags BatchComputeEnvironment#capacity_tags}
    */
    readonly capacityTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#desiredv_cpus BatchComputeEnvironment#desiredv_cpus}
    */
    readonly desiredvCpus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#ec_2_configuration BatchComputeEnvironment#ec_2_configuration}
    */
    readonly ec2Configuration?: BatchComputeEnvironmentComputeResourcesEc2Configuration[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#ec_2_key_pair BatchComputeEnvironment#ec_2_key_pair}
    */
    readonly ec2KeyPair?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#image_id BatchComputeEnvironment#image_id}
    */
    readonly imageId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#instance_role BatchComputeEnvironment#instance_role}
    */
    readonly instanceRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#instance_types BatchComputeEnvironment#instance_types}
    */
    readonly instanceTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#launch_template BatchComputeEnvironment#launch_template}
    */
    readonly launchTemplate?: BatchComputeEnvironmentComputeResourcesLaunchTemplate;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#managed_instances_provider BatchComputeEnvironment#managed_instances_provider}
    */
    readonly managedInstancesProvider?: BatchComputeEnvironmentComputeResourcesManagedInstancesProvider;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#maxv_cpus BatchComputeEnvironment#maxv_cpus}
    */
    readonly maxvCpus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#minv_cpus BatchComputeEnvironment#minv_cpus}
    */
    readonly minvCpus?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#placement_group BatchComputeEnvironment#placement_group}
    */
    readonly placementGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#scaling_policy BatchComputeEnvironment#scaling_policy}
    */
    readonly scalingPolicy?: BatchComputeEnvironmentComputeResourcesScalingPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#security_group_ids BatchComputeEnvironment#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#spot_iam_fleet_role BatchComputeEnvironment#spot_iam_fleet_role}
    */
    readonly spotIamFleetRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#subnets BatchComputeEnvironment#subnets}
    */
    readonly subnets?: string[];
    /**
    * A key-value pair to associate with a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#tags BatchComputeEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#type BatchComputeEnvironment#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#update_to_latest_image_version BatchComputeEnvironment#update_to_latest_image_version}
    */
    readonly updateToLatestImageVersion?: boolean | cdktn.IResolvable;
}
export declare function batchComputeEnvironmentComputeResourcesToTerraform(struct?: BatchComputeEnvironmentComputeResources | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentComputeResourcesToHclTerraform(struct?: BatchComputeEnvironmentComputeResources | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentComputeResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentComputeResources | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentComputeResources | cdktn.IResolvable | undefined);
    private _allocationStrategy?;
    get allocationStrategy(): string;
    set allocationStrategy(value: string);
    resetAllocationStrategy(): void;
    get allocationStrategyInput(): string | undefined;
    private _bidPercentage?;
    get bidPercentage(): number;
    set bidPercentage(value: number);
    resetBidPercentage(): void;
    get bidPercentageInput(): number | undefined;
    private _capacityTags?;
    get capacityTags(): {
        [key: string]: string;
    };
    set capacityTags(value: {
        [key: string]: string;
    });
    resetCapacityTags(): void;
    get capacityTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _desiredvCpus?;
    get desiredvCpus(): number;
    set desiredvCpus(value: number);
    resetDesiredvCpus(): void;
    get desiredvCpusInput(): number | undefined;
    private _ec2Configuration;
    get ec2Configuration(): BatchComputeEnvironmentComputeResourcesEc2ConfigurationList;
    putEc2Configuration(value: BatchComputeEnvironmentComputeResourcesEc2Configuration[] | cdktn.IResolvable): void;
    resetEc2Configuration(): void;
    get ec2ConfigurationInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesEc2Configuration[] | undefined;
    private _ec2KeyPair?;
    get ec2KeyPair(): string;
    set ec2KeyPair(value: string);
    resetEc2KeyPair(): void;
    get ec2KeyPairInput(): string | undefined;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _instanceRole?;
    get instanceRole(): string;
    set instanceRole(value: string);
    resetInstanceRole(): void;
    get instanceRoleInput(): string | undefined;
    private _instanceTypes?;
    get instanceTypes(): string[];
    set instanceTypes(value: string[]);
    resetInstanceTypes(): void;
    get instanceTypesInput(): string[] | undefined;
    private _launchTemplate;
    get launchTemplate(): BatchComputeEnvironmentComputeResourcesLaunchTemplateOutputReference;
    putLaunchTemplate(value: BatchComputeEnvironmentComputeResourcesLaunchTemplate): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesLaunchTemplate | undefined;
    private _managedInstancesProvider;
    get managedInstancesProvider(): BatchComputeEnvironmentComputeResourcesManagedInstancesProviderOutputReference;
    putManagedInstancesProvider(value: BatchComputeEnvironmentComputeResourcesManagedInstancesProvider): void;
    resetManagedInstancesProvider(): void;
    get managedInstancesProviderInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesManagedInstancesProvider | undefined;
    private _maxvCpus?;
    get maxvCpus(): number;
    set maxvCpus(value: number);
    resetMaxvCpus(): void;
    get maxvCpusInput(): number | undefined;
    private _minvCpus?;
    get minvCpus(): number;
    set minvCpus(value: number);
    resetMinvCpus(): void;
    get minvCpusInput(): number | undefined;
    private _placementGroup?;
    get placementGroup(): string;
    set placementGroup(value: string);
    resetPlacementGroup(): void;
    get placementGroupInput(): string | undefined;
    private _scalingPolicy;
    get scalingPolicy(): BatchComputeEnvironmentComputeResourcesScalingPolicyOutputReference;
    putScalingPolicy(value: BatchComputeEnvironmentComputeResourcesScalingPolicy): void;
    resetScalingPolicy(): void;
    get scalingPolicyInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResourcesScalingPolicy | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _spotIamFleetRole?;
    get spotIamFleetRole(): string;
    set spotIamFleetRole(value: string);
    resetSpotIamFleetRole(): void;
    get spotIamFleetRoleInput(): string | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _updateToLatestImageVersion?;
    get updateToLatestImageVersion(): boolean | cdktn.IResolvable;
    set updateToLatestImageVersion(value: boolean | cdktn.IResolvable);
    resetUpdateToLatestImageVersion(): void;
    get updateToLatestImageVersionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BatchComputeEnvironmentEcsSettings {
    /**
    * The CloudWatch Container Insights setting applied to the Amazon ECS cluster that backs this compute environment. After you set this property, you can't revert it to the default (unset) state in which the setting is managed outside of AWS Batch. If you remove this property after previously setting it, AWS Batch treats the omission as DISABLED, because the underlying API has no way to unset the value. Because of this, if a stack rollback would return this property to its previous unset state, AWS Batch sets it to DISABLED instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#container_insights BatchComputeEnvironment#container_insights}
    */
    readonly containerInsights?: string;
}
export declare function batchComputeEnvironmentEcsSettingsToTerraform(struct?: BatchComputeEnvironmentEcsSettings | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentEcsSettingsToHclTerraform(struct?: BatchComputeEnvironmentEcsSettings | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentEcsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentEcsSettings | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentEcsSettings | cdktn.IResolvable | undefined);
    private _containerInsights?;
    get containerInsights(): string;
    set containerInsights(value: string);
    resetContainerInsights(): void;
    get containerInsightsInput(): string | undefined;
}
export interface BatchComputeEnvironmentEksConfigurationAccessEntry {
    /**
    * The desired state of the EKS access entry managed by AWS Batch. When omitted, AWS Batch applies INHERIT_FROM_CLUSTER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#desired_state BatchComputeEnvironment#desired_state}
    */
    readonly desiredState?: string;
}
export declare function batchComputeEnvironmentEksConfigurationAccessEntryToTerraform(struct?: BatchComputeEnvironmentEksConfigurationAccessEntry | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentEksConfigurationAccessEntryToHclTerraform(struct?: BatchComputeEnvironmentEksConfigurationAccessEntry | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentEksConfigurationAccessEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentEksConfigurationAccessEntry | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentEksConfigurationAccessEntry | cdktn.IResolvable | undefined);
    private _desiredState?;
    get desiredState(): string;
    set desiredState(value: string);
    resetDesiredState(): void;
    get desiredStateInput(): string | undefined;
    get status(): string;
}
export interface BatchComputeEnvironmentEksConfiguration {
    /**
    * The EKS access entry configuration for the compute environment. Controls whether AWS Batch manages the EKS access entry for the compute environment's service role, or inherits it from the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#access_entry BatchComputeEnvironment#access_entry}
    */
    readonly accessEntry?: BatchComputeEnvironmentEksConfigurationAccessEntry;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#eks_cluster_arn BatchComputeEnvironment#eks_cluster_arn}
    */
    readonly eksClusterArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#kubernetes_namespace BatchComputeEnvironment#kubernetes_namespace}
    */
    readonly kubernetesNamespace?: string;
}
export declare function batchComputeEnvironmentEksConfigurationToTerraform(struct?: BatchComputeEnvironmentEksConfiguration | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentEksConfigurationToHclTerraform(struct?: BatchComputeEnvironmentEksConfiguration | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentEksConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentEksConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentEksConfiguration | cdktn.IResolvable | undefined);
    private _accessEntry;
    get accessEntry(): BatchComputeEnvironmentEksConfigurationAccessEntryOutputReference;
    putAccessEntry(value: BatchComputeEnvironmentEksConfigurationAccessEntry): void;
    resetAccessEntry(): void;
    get accessEntryInput(): cdktn.IResolvable | BatchComputeEnvironmentEksConfigurationAccessEntry | undefined;
    private _eksClusterArn?;
    get eksClusterArn(): string;
    set eksClusterArn(value: string);
    resetEksClusterArn(): void;
    get eksClusterArnInput(): string | undefined;
    private _kubernetesNamespace?;
    get kubernetesNamespace(): string;
    set kubernetesNamespace(value: string);
    resetKubernetesNamespace(): void;
    get kubernetesNamespaceInput(): string | undefined;
}
export interface BatchComputeEnvironmentUpdatePolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#job_execution_timeout_minutes BatchComputeEnvironment#job_execution_timeout_minutes}
    */
    readonly jobExecutionTimeoutMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#terminate_jobs_on_update BatchComputeEnvironment#terminate_jobs_on_update}
    */
    readonly terminateJobsOnUpdate?: boolean | cdktn.IResolvable;
}
export declare function batchComputeEnvironmentUpdatePolicyToTerraform(struct?: BatchComputeEnvironmentUpdatePolicy | cdktn.IResolvable): any;
export declare function batchComputeEnvironmentUpdatePolicyToHclTerraform(struct?: BatchComputeEnvironmentUpdatePolicy | cdktn.IResolvable): any;
export declare class BatchComputeEnvironmentUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchComputeEnvironmentUpdatePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: BatchComputeEnvironmentUpdatePolicy | cdktn.IResolvable | undefined);
    private _jobExecutionTimeoutMinutes?;
    get jobExecutionTimeoutMinutes(): number;
    set jobExecutionTimeoutMinutes(value: number);
    resetJobExecutionTimeoutMinutes(): void;
    get jobExecutionTimeoutMinutesInput(): number | undefined;
    private _terminateJobsOnUpdate?;
    get terminateJobsOnUpdate(): boolean | cdktn.IResolvable;
    set terminateJobsOnUpdate(value: boolean | cdktn.IResolvable);
    resetTerminateJobsOnUpdate(): void;
    get terminateJobsOnUpdateInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment awscc_batch_compute_environment}
*/
export declare class BatchComputeEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_batch_compute_environment";
    /**
    * Generates CDKTN code for importing a BatchComputeEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BatchComputeEnvironment to import
    * @param importFromId The id of the existing BatchComputeEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BatchComputeEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/batch_compute_environment awscc_batch_compute_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BatchComputeEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: BatchComputeEnvironmentConfig);
    get computeEnvironmentArn(): string;
    private _computeEnvironmentName?;
    get computeEnvironmentName(): string;
    set computeEnvironmentName(value: string);
    resetComputeEnvironmentName(): void;
    get computeEnvironmentNameInput(): string | undefined;
    private _computeResources;
    get computeResources(): BatchComputeEnvironmentComputeResourcesOutputReference;
    putComputeResources(value: BatchComputeEnvironmentComputeResources): void;
    resetComputeResources(): void;
    get computeResourcesInput(): cdktn.IResolvable | BatchComputeEnvironmentComputeResources | undefined;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _ecsSettings;
    get ecsSettings(): BatchComputeEnvironmentEcsSettingsOutputReference;
    putEcsSettings(value: BatchComputeEnvironmentEcsSettings): void;
    resetEcsSettings(): void;
    get ecsSettingsInput(): cdktn.IResolvable | BatchComputeEnvironmentEcsSettings | undefined;
    private _eksConfiguration;
    get eksConfiguration(): BatchComputeEnvironmentEksConfigurationOutputReference;
    putEksConfiguration(value: BatchComputeEnvironmentEksConfiguration): void;
    resetEksConfiguration(): void;
    get eksConfigurationInput(): cdktn.IResolvable | BatchComputeEnvironmentEksConfiguration | undefined;
    get id(): string;
    private _replaceComputeEnvironment?;
    get replaceComputeEnvironment(): boolean | cdktn.IResolvable;
    set replaceComputeEnvironment(value: boolean | cdktn.IResolvable);
    resetReplaceComputeEnvironment(): void;
    get replaceComputeEnvironmentInput(): boolean | cdktn.IResolvable | undefined;
    private _serviceRole?;
    get serviceRole(): string;
    set serviceRole(value: string);
    resetServiceRole(): void;
    get serviceRoleInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _unmanagedvCpus?;
    get unmanagedvCpus(): number;
    set unmanagedvCpus(value: number);
    resetUnmanagedvCpus(): void;
    get unmanagedvCpusInput(): number | undefined;
    private _updatePolicy;
    get updatePolicy(): BatchComputeEnvironmentUpdatePolicyOutputReference;
    putUpdatePolicy(value: BatchComputeEnvironmentUpdatePolicy): void;
    resetUpdatePolicy(): void;
    get updatePolicyInput(): cdktn.IResolvable | BatchComputeEnvironmentUpdatePolicy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
