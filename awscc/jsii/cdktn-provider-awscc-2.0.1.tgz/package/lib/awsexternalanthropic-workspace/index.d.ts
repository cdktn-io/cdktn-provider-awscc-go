/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsexternalanthropicWorkspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Data residency configuration for the workspace. WorkspaceGeo is immutable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#data_residency AwsexternalanthropicWorkspace#data_residency}
    */
    readonly dataResidency?: AwsexternalanthropicWorkspaceDataResidency;
    /**
    * The name of the workspace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#name AwsexternalanthropicWorkspace#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#tags AwsexternalanthropicWorkspace#tags}
    */
    readonly tags?: AwsexternalanthropicWorkspaceTags[] | cdktn.IResolvable;
}
export interface AwsexternalanthropicWorkspaceDataResidency {
    /**
    * Permitted inference geo values. Omit to allow all geos (the service default of 'unrestricted'); otherwise list specific geos.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#allowed_inference_geos AwsexternalanthropicWorkspace#allowed_inference_geos}
    */
    readonly allowedInferenceGeos?: string[];
    /**
    * Default inference geo applied when requests omit the parameter. Defaults to 'global' if omitted. Must be a member of AllowedInferenceGeos unless AllowedInferenceGeos is omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#default_inference_geo AwsexternalanthropicWorkspace#default_inference_geo}
    */
    readonly defaultInferenceGeo?: string;
    /**
    * Geographic region for workspace data storage. Immutable after creation. Defaults to 'us' if omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#workspace_geo AwsexternalanthropicWorkspace#workspace_geo}
    */
    readonly workspaceGeo?: string;
}
export declare function awsexternalanthropicWorkspaceDataResidencyToTerraform(struct?: AwsexternalanthropicWorkspaceDataResidency | cdktn.IResolvable): any;
export declare function awsexternalanthropicWorkspaceDataResidencyToHclTerraform(struct?: AwsexternalanthropicWorkspaceDataResidency | cdktn.IResolvable): any;
export declare class AwsexternalanthropicWorkspaceDataResidencyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AwsexternalanthropicWorkspaceDataResidency | cdktn.IResolvable | undefined;
    set internalValue(value: AwsexternalanthropicWorkspaceDataResidency | cdktn.IResolvable | undefined);
    private _allowedInferenceGeos?;
    get allowedInferenceGeos(): string[];
    set allowedInferenceGeos(value: string[]);
    resetAllowedInferenceGeos(): void;
    get allowedInferenceGeosInput(): string[] | undefined;
    private _defaultInferenceGeo?;
    get defaultInferenceGeo(): string;
    set defaultInferenceGeo(value: string);
    resetDefaultInferenceGeo(): void;
    get defaultInferenceGeoInput(): string | undefined;
    private _workspaceGeo?;
    get workspaceGeo(): string;
    set workspaceGeo(value: string);
    resetWorkspaceGeo(): void;
    get workspaceGeoInput(): string | undefined;
}
export interface AwsexternalanthropicWorkspaceTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#key AwsexternalanthropicWorkspace#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#value AwsexternalanthropicWorkspace#value}
    */
    readonly value?: string;
}
export declare function awsexternalanthropicWorkspaceTagsToTerraform(struct?: AwsexternalanthropicWorkspaceTags | cdktn.IResolvable): any;
export declare function awsexternalanthropicWorkspaceTagsToHclTerraform(struct?: AwsexternalanthropicWorkspaceTags | cdktn.IResolvable): any;
export declare class AwsexternalanthropicWorkspaceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AwsexternalanthropicWorkspaceTags | cdktn.IResolvable | undefined;
    set internalValue(value: AwsexternalanthropicWorkspaceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AwsexternalanthropicWorkspaceTagsList extends cdktn.ComplexList {
    internalValue?: AwsexternalanthropicWorkspaceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AwsexternalanthropicWorkspaceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace awscc_awsexternalanthropic_workspace}
*/
export declare class AwsexternalanthropicWorkspace extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_awsexternalanthropic_workspace";
    /**
    * Generates CDKTN code for importing a AwsexternalanthropicWorkspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsexternalanthropicWorkspace to import
    * @param importFromId The id of the existing AwsexternalanthropicWorkspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsexternalanthropicWorkspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/awsexternalanthropic_workspace awscc_awsexternalanthropic_workspace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsexternalanthropicWorkspaceConfig
    */
    constructor(scope: Construct, id: string, config: AwsexternalanthropicWorkspaceConfig);
    get arn(): string;
    get createdAt(): string;
    private _dataResidency;
    get dataResidency(): AwsexternalanthropicWorkspaceDataResidencyOutputReference;
    putDataResidency(value: AwsexternalanthropicWorkspaceDataResidency): void;
    resetDataResidency(): void;
    get dataResidencyInput(): cdktn.IResolvable | AwsexternalanthropicWorkspaceDataResidency | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): AwsexternalanthropicWorkspaceTagsList;
    putTags(value: AwsexternalanthropicWorkspaceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AwsexternalanthropicWorkspaceTags[] | undefined;
    get workspaceId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
