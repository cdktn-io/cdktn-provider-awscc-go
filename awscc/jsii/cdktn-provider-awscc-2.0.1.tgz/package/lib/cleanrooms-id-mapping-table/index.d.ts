/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsIdMappingTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#description CleanroomsIdMappingTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#input_reference_config CleanroomsIdMappingTable#input_reference_config}
    */
    readonly inputReferenceConfig: CleanroomsIdMappingTableInputReferenceConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#kms_key_arn CleanroomsIdMappingTable#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#membership_identifier CleanroomsIdMappingTable#membership_identifier}
    */
    readonly membershipIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#name CleanroomsIdMappingTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#tags CleanroomsIdMappingTable#tags}
    */
    readonly tags?: CleanroomsIdMappingTableTags[] | cdktn.IResolvable;
}
export interface CleanroomsIdMappingTableInputReferenceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#input_reference_arn CleanroomsIdMappingTable#input_reference_arn}
    */
    readonly inputReferenceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#manage_resource_policies CleanroomsIdMappingTable#manage_resource_policies}
    */
    readonly manageResourcePolicies: boolean | cdktn.IResolvable;
}
export declare function cleanroomsIdMappingTableInputReferenceConfigToTerraform(struct?: CleanroomsIdMappingTableInputReferenceConfig | cdktn.IResolvable): any;
export declare function cleanroomsIdMappingTableInputReferenceConfigToHclTerraform(struct?: CleanroomsIdMappingTableInputReferenceConfig | cdktn.IResolvable): any;
export declare class CleanroomsIdMappingTableInputReferenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIdMappingTableInputReferenceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIdMappingTableInputReferenceConfig | cdktn.IResolvable | undefined);
    private _inputReferenceArn?;
    get inputReferenceArn(): string;
    set inputReferenceArn(value: string);
    get inputReferenceArnInput(): string | undefined;
    private _manageResourcePolicies?;
    get manageResourcePolicies(): boolean | cdktn.IResolvable;
    set manageResourcePolicies(value: boolean | cdktn.IResolvable);
    get manageResourcePoliciesInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSource {
}
export declare function cleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSourceToTerraform(struct?: CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSource): any;
export declare function cleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSourceToHclTerraform(struct?: CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSource): any;
export declare class CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSource | undefined;
    set internalValue(value: CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSource | undefined);
    get idNamespaceAssociationId(): string;
    get type(): string;
}
export declare class CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSourceOutputReference;
}
export interface CleanroomsIdMappingTableInputReferenceProperties {
}
export declare function cleanroomsIdMappingTableInputReferencePropertiesToTerraform(struct?: CleanroomsIdMappingTableInputReferenceProperties): any;
export declare function cleanroomsIdMappingTableInputReferencePropertiesToHclTerraform(struct?: CleanroomsIdMappingTableInputReferenceProperties): any;
export declare class CleanroomsIdMappingTableInputReferencePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsIdMappingTableInputReferenceProperties | undefined;
    set internalValue(value: CleanroomsIdMappingTableInputReferenceProperties | undefined);
    private _idMappingTableInputSource;
    get idMappingTableInputSource(): CleanroomsIdMappingTableInputReferencePropertiesIdMappingTableInputSourceList;
}
export interface CleanroomsIdMappingTableTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#key CleanroomsIdMappingTable#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#value CleanroomsIdMappingTable#value}
    */
    readonly value?: string;
}
export declare function cleanroomsIdMappingTableTagsToTerraform(struct?: CleanroomsIdMappingTableTags | cdktn.IResolvable): any;
export declare function cleanroomsIdMappingTableTagsToHclTerraform(struct?: CleanroomsIdMappingTableTags | cdktn.IResolvable): any;
export declare class CleanroomsIdMappingTableTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsIdMappingTableTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsIdMappingTableTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsIdMappingTableTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsIdMappingTableTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsIdMappingTableTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table awscc_cleanrooms_id_mapping_table}
*/
export declare class CleanroomsIdMappingTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanrooms_id_mapping_table";
    /**
    * Generates CDKTN code for importing a CleanroomsIdMappingTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsIdMappingTable to import
    * @param importFromId The id of the existing CleanroomsIdMappingTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsIdMappingTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_id_mapping_table awscc_cleanrooms_id_mapping_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsIdMappingTableConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsIdMappingTableConfig);
    get arn(): string;
    get collaborationArn(): string;
    get collaborationIdentifier(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get idMappingTableIdentifier(): string;
    private _inputReferenceConfig;
    get inputReferenceConfig(): CleanroomsIdMappingTableInputReferenceConfigOutputReference;
    putInputReferenceConfig(value: CleanroomsIdMappingTableInputReferenceConfig): void;
    get inputReferenceConfigInput(): cdktn.IResolvable | CleanroomsIdMappingTableInputReferenceConfig | undefined;
    private _inputReferenceProperties;
    get inputReferenceProperties(): CleanroomsIdMappingTableInputReferencePropertiesOutputReference;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    get membershipArn(): string;
    private _membershipIdentifier?;
    get membershipIdentifier(): string;
    set membershipIdentifier(value: string);
    get membershipIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): CleanroomsIdMappingTableTagsList;
    putTags(value: CleanroomsIdMappingTableTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsIdMappingTableTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
