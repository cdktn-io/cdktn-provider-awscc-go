/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodestarconnectionsSyncConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the branch of the repository from which resources are to be synchronized,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#branch CodestarconnectionsSyncConfiguration#branch}
    */
    readonly branch: string;
    /**
    * The source provider repository path of the sync configuration file of the respective SyncType.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#config_file CodestarconnectionsSyncConfiguration#config_file}
    */
    readonly configFile: string;
    /**
    * Whether to enable or disable publishing of deployment status to source providers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#publish_deployment_status CodestarconnectionsSyncConfiguration#publish_deployment_status}
    */
    readonly publishDeploymentStatus?: string;
    /**
    * A UUID that uniquely identifies the RepositoryLink that the SyncConfig is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#repository_link_id CodestarconnectionsSyncConfiguration#repository_link_id}
    */
    readonly repositoryLinkId: string;
    /**
    * The name of the resource that is being synchronized to the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#resource_name CodestarconnectionsSyncConfiguration#resource_name}
    */
    readonly resourceName: string;
    /**
    * The IAM Role that allows AWS to update CloudFormation stacks based on content in the specified repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#role_arn CodestarconnectionsSyncConfiguration#role_arn}
    */
    readonly roleArn: string;
    /**
    * The type of resource synchronization service that is to be configured, for example, CFN_STACK_SYNC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#sync_type CodestarconnectionsSyncConfiguration#sync_type}
    */
    readonly syncType: string;
    /**
    * When to trigger Git sync to begin the stack update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#trigger_resource_update_on CodestarconnectionsSyncConfiguration#trigger_resource_update_on}
    */
    readonly triggerResourceUpdateOn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration awscc_codestarconnections_sync_configuration}
*/
export declare class CodestarconnectionsSyncConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codestarconnections_sync_configuration";
    /**
    * Generates CDKTN code for importing a CodestarconnectionsSyncConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodestarconnectionsSyncConfiguration to import
    * @param importFromId The id of the existing CodestarconnectionsSyncConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodestarconnectionsSyncConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codestarconnections_sync_configuration awscc_codestarconnections_sync_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodestarconnectionsSyncConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: CodestarconnectionsSyncConfigurationConfig);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    get branchInput(): string | undefined;
    private _configFile?;
    get configFile(): string;
    set configFile(value: string);
    get configFileInput(): string | undefined;
    get id(): string;
    get ownerId(): string;
    get providerType(): string;
    private _publishDeploymentStatus?;
    get publishDeploymentStatus(): string;
    set publishDeploymentStatus(value: string);
    resetPublishDeploymentStatus(): void;
    get publishDeploymentStatusInput(): string | undefined;
    private _repositoryLinkId?;
    get repositoryLinkId(): string;
    set repositoryLinkId(value: string);
    get repositoryLinkIdInput(): string | undefined;
    get repositoryName(): string;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _syncType?;
    get syncType(): string;
    set syncType(value: string);
    get syncTypeInput(): string | undefined;
    private _triggerResourceUpdateOn?;
    get triggerResourceUpdateOn(): string;
    set triggerResourceUpdateOn(value: string);
    resetTriggerResourceUpdateOn(): void;
    get triggerResourceUpdateOnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
