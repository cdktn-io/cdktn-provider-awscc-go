/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayDocumentationPartConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_documentation_part#id DataAwsccApigatewayDocumentationPart#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayDocumentationPartLocation {
}
export declare function dataAwsccApigatewayDocumentationPartLocationToTerraform(struct?: DataAwsccApigatewayDocumentationPartLocation): any;
export declare function dataAwsccApigatewayDocumentationPartLocationToHclTerraform(struct?: DataAwsccApigatewayDocumentationPartLocation): any;
export declare class DataAwsccApigatewayDocumentationPartLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayDocumentationPartLocation | undefined;
    set internalValue(value: DataAwsccApigatewayDocumentationPartLocation | undefined);
    get method(): string;
    get name(): string;
    get path(): string;
    get statusCode(): string;
    get type(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_documentation_part awscc_apigateway_documentation_part}
*/
export declare class DataAwsccApigatewayDocumentationPart extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_documentation_part";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayDocumentationPart resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayDocumentationPart to import
    * @param importFromId The id of the existing DataAwsccApigatewayDocumentationPart that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_documentation_part#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayDocumentationPart to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_documentation_part awscc_apigateway_documentation_part} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayDocumentationPartConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayDocumentationPartConfig);
    get documentationPartId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _location;
    get location(): DataAwsccApigatewayDocumentationPartLocationOutputReference;
    get properties(): string;
    get restApiId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
