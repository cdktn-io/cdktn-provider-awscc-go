/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsConfiguredTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#allowed_columns CleanroomsConfiguredTable#allowed_columns}
    */
    readonly allowedColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#analysis_method CleanroomsConfiguredTable#analysis_method}
    */
    readonly analysisMethod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#analysis_rules CleanroomsConfiguredTable#analysis_rules}
    */
    readonly analysisRules?: CleanroomsConfiguredTableAnalysisRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#description CleanroomsConfiguredTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#name CleanroomsConfiguredTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#selected_analysis_methods CleanroomsConfiguredTable#selected_analysis_methods}
    */
    readonly selectedAnalysisMethods?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#table_reference CleanroomsConfiguredTable#table_reference}
    */
    readonly tableReference: CleanroomsConfiguredTableTableReference;
    /**
    * An arbitrary set of tags (key-value pairs) for this cleanrooms collaboration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#tags CleanroomsConfiguredTable#tags}
    */
    readonly tags?: CleanroomsConfiguredTableTags[] | cdktn.IResolvable;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#column_names CleanroomsConfiguredTable#column_names}
    */
    readonly columnNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#function CleanroomsConfiguredTable#function}
    */
    readonly function?: string;
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumnsToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumnsToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    resetFunction(): void;
    get functionInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumnsList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumnsOutputReference;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#column_name CleanroomsConfiguredTable#column_name}
    */
    readonly columnName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#minimum CleanroomsConfiguredTable#minimum}
    */
    readonly minimum?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#type CleanroomsConfiguredTable#type}
    */
    readonly type?: string;
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraintsToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraintsToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    resetColumnName(): void;
    get columnNameInput(): string | undefined;
    private _minimum?;
    get minimum(): number;
    set minimum(value: number);
    resetMinimum(): void;
    get minimumInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraintsList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraintsOutputReference;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1Aggregation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#additional_analyses CleanroomsConfiguredTable#additional_analyses}
    */
    readonly additionalAnalyses?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#aggregate_columns CleanroomsConfiguredTable#aggregate_columns}
    */
    readonly aggregateColumns?: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#allowed_join_operators CleanroomsConfiguredTable#allowed_join_operators}
    */
    readonly allowedJoinOperators?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#dimension_columns CleanroomsConfiguredTable#dimension_columns}
    */
    readonly dimensionColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#join_columns CleanroomsConfiguredTable#join_columns}
    */
    readonly joinColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#join_required CleanroomsConfiguredTable#join_required}
    */
    readonly joinRequired?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#output_constraints CleanroomsConfiguredTable#output_constraints}
    */
    readonly outputConstraints?: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#scalar_functions CleanroomsConfiguredTable#scalar_functions}
    */
    readonly scalarFunctions?: string[];
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1Aggregation | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1Aggregation | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1Aggregation | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1Aggregation | cdktn.IResolvable | undefined);
    private _additionalAnalyses?;
    get additionalAnalyses(): string;
    set additionalAnalyses(value: string);
    resetAdditionalAnalyses(): void;
    get additionalAnalysesInput(): string | undefined;
    private _aggregateColumns;
    get aggregateColumns(): CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumnsList;
    putAggregateColumns(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns[] | cdktn.IResolvable): void;
    resetAggregateColumns(): void;
    get aggregateColumnsInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationAggregateColumns[] | undefined;
    private _allowedJoinOperators?;
    get allowedJoinOperators(): string[];
    set allowedJoinOperators(value: string[]);
    resetAllowedJoinOperators(): void;
    get allowedJoinOperatorsInput(): string[] | undefined;
    private _dimensionColumns?;
    get dimensionColumns(): string[];
    set dimensionColumns(value: string[]);
    resetDimensionColumns(): void;
    get dimensionColumnsInput(): string[] | undefined;
    private _joinColumns?;
    get joinColumns(): string[];
    set joinColumns(value: string[]);
    resetJoinColumns(): void;
    get joinColumnsInput(): string[] | undefined;
    private _joinRequired?;
    get joinRequired(): string;
    set joinRequired(value: string);
    resetJoinRequired(): void;
    get joinRequiredInput(): string | undefined;
    private _outputConstraints;
    get outputConstraints(): CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraintsList;
    putOutputConstraints(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints[] | cdktn.IResolvable): void;
    resetOutputConstraints(): void;
    get outputConstraintsInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputConstraints[] | undefined;
    private _scalarFunctions?;
    get scalarFunctions(): string[];
    set scalarFunctions(value: string[]);
    resetScalarFunctions(): void;
    get scalarFunctionsInput(): string[] | undefined;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#minimum_identity_count CleanroomsConfiguredTable#minimum_identity_count}
    */
    readonly minimumIdentityCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#output_column_name CleanroomsConfiguredTable#output_column_name}
    */
    readonly outputColumnName?: string;
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds | cdktn.IResolvable | undefined);
    private _minimumIdentityCount?;
    get minimumIdentityCount(): number;
    set minimumIdentityCount(value: number);
    resetMinimumIdentityCount(): void;
    get minimumIdentityCountInput(): number | undefined;
    private _outputColumnName?;
    get outputColumnName(): string;
    set outputColumnName(value: string);
    resetOutputColumnName(): void;
    get outputColumnNameInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsOutputReference;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#allowed_aggregate_expression_type CleanroomsConfiguredTable#allowed_aggregate_expression_type}
    */
    readonly allowedAggregateExpressionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#identity_columns CleanroomsConfiguredTable#identity_columns}
    */
    readonly identityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#minimum_identity_count CleanroomsConfiguredTable#minimum_identity_count}
    */
    readonly minimumIdentityCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#output_column_thresholds CleanroomsConfiguredTable#output_column_thresholds}
    */
    readonly outputColumnThresholds?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#type CleanroomsConfiguredTable#type}
    */
    readonly type?: string;
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds | cdktn.IResolvable | undefined);
    private _allowedAggregateExpressionType?;
    get allowedAggregateExpressionType(): string;
    set allowedAggregateExpressionType(value: string);
    resetAllowedAggregateExpressionType(): void;
    get allowedAggregateExpressionTypeInput(): string | undefined;
    private _identityColumns?;
    get identityColumns(): string[];
    set identityColumns(value: string[]);
    resetIdentityColumns(): void;
    get identityColumnsInput(): string[] | undefined;
    private _minimumIdentityCount?;
    get minimumIdentityCount(): number;
    set minimumIdentityCount(value: number);
    resetMinimumIdentityCount(): void;
    get minimumIdentityCountInput(): number | undefined;
    private _outputColumnThresholds;
    get outputColumnThresholds(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholdsList;
    putOutputColumnThresholds(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds[] | cdktn.IResolvable): void;
    resetOutputColumnThresholds(): void;
    get outputColumnThresholdsInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputColumnThresholds[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsOutputReference;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#allowed_column_comparison_columns CleanroomsConfiguredTable#allowed_column_comparison_columns}
    */
    readonly allowedColumnComparisonColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#allowed_literal_comparison_columns CleanroomsConfiguredTable#allowed_literal_comparison_columns}
    */
    readonly allowedLiteralComparisonColumns?: string[];
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControlsToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControls | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControlsToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControls | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControls | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControls | cdktn.IResolvable | undefined);
    private _allowedColumnComparisonColumns?;
    get allowedColumnComparisonColumns(): string[];
    set allowedColumnComparisonColumns(value: string[]);
    resetAllowedColumnComparisonColumns(): void;
    get allowedColumnComparisonColumnsInput(): string[] | undefined;
    private _allowedLiteralComparisonColumns?;
    get allowedLiteralComparisonColumns(): string[];
    set allowedLiteralComparisonColumns(value: string[]);
    resetAllowedLiteralComparisonColumns(): void;
    get allowedLiteralComparisonColumnsInput(): string[] | undefined;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#name CleanroomsConfiguredTable#name}
    */
    readonly name?: string;
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsOutputReference;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#columns CleanroomsConfiguredTable#columns}
    */
    readonly columns?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns[] | cdktn.IResolvable;
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | cdktn.IResolvable | undefined);
    private _columns;
    get columns(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumnsList;
    putColumns(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns[] | cdktn.IResolvable): void;
    resetColumns(): void;
    get columnsInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyColumns[] | undefined;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1Custom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#additional_analyses CleanroomsConfiguredTable#additional_analyses}
    */
    readonly additionalAnalyses?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#aggregation_thresholds CleanroomsConfiguredTable#aggregation_thresholds}
    */
    readonly aggregationThresholds?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#allowed_analyses CleanroomsConfiguredTable#allowed_analyses}
    */
    readonly allowedAnalyses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#allowed_analysis_providers CleanroomsConfiguredTable#allowed_analysis_providers}
    */
    readonly allowedAnalysisProviders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#comparison_controls CleanroomsConfiguredTable#comparison_controls}
    */
    readonly comparisonControls?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControls;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#differential_privacy CleanroomsConfiguredTable#differential_privacy}
    */
    readonly differentialPrivacy?: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#disallowed_output_columns CleanroomsConfiguredTable#disallowed_output_columns}
    */
    readonly disallowedOutputColumns?: string[];
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1Custom | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1CustomToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1Custom | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1Custom | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1Custom | cdktn.IResolvable | undefined);
    private _additionalAnalyses?;
    get additionalAnalyses(): string;
    set additionalAnalyses(value: string);
    resetAdditionalAnalyses(): void;
    get additionalAnalysesInput(): string | undefined;
    private _aggregationThresholds;
    get aggregationThresholds(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholdsList;
    putAggregationThresholds(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds[] | cdktn.IResolvable): void;
    resetAggregationThresholds(): void;
    get aggregationThresholdsInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomAggregationThresholds[] | undefined;
    private _allowedAnalyses?;
    get allowedAnalyses(): string[];
    set allowedAnalyses(value: string[]);
    resetAllowedAnalyses(): void;
    get allowedAnalysesInput(): string[] | undefined;
    private _allowedAnalysisProviders?;
    get allowedAnalysisProviders(): string[];
    set allowedAnalysisProviders(value: string[]);
    resetAllowedAnalysisProviders(): void;
    get allowedAnalysisProvidersInput(): string[] | undefined;
    private _comparisonControls;
    get comparisonControls(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControlsOutputReference;
    putComparisonControls(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControls): void;
    resetComparisonControls(): void;
    get comparisonControlsInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomComparisonControls | undefined;
    private _differentialPrivacy;
    get differentialPrivacy(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacyOutputReference;
    putDifferentialPrivacy(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacy): void;
    resetDifferentialPrivacy(): void;
    get differentialPrivacyInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomDifferentialPrivacy | undefined;
    private _disallowedOutputColumns?;
    get disallowedOutputColumns(): string[];
    set disallowedOutputColumns(value: string[]);
    resetDisallowedOutputColumns(): void;
    get disallowedOutputColumnsInput(): string[] | undefined;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#additional_analyses CleanroomsConfiguredTable#additional_analyses}
    */
    readonly additionalAnalyses?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#allowed_join_operators CleanroomsConfiguredTable#allowed_join_operators}
    */
    readonly allowedJoinOperators?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#join_columns CleanroomsConfiguredTable#join_columns}
    */
    readonly joinColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#list_columns CleanroomsConfiguredTable#list_columns}
    */
    readonly listColumns?: string[];
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1ListStructToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStruct | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1ListStructToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStruct | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStruct | cdktn.IResolvable | undefined);
    private _additionalAnalyses?;
    get additionalAnalyses(): string;
    set additionalAnalyses(value: string);
    resetAdditionalAnalyses(): void;
    get additionalAnalysesInput(): string | undefined;
    private _allowedJoinOperators?;
    get allowedJoinOperators(): string[];
    set allowedJoinOperators(value: string[]);
    resetAllowedJoinOperators(): void;
    get allowedJoinOperatorsInput(): string[] | undefined;
    private _joinColumns?;
    get joinColumns(): string[];
    set joinColumns(value: string[]);
    resetJoinColumns(): void;
    get joinColumnsInput(): string[] | undefined;
    private _listColumns?;
    get listColumns(): string[];
    set listColumns(value: string[]);
    resetListColumns(): void;
    get listColumnsInput(): string[] | undefined;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicyV1 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#aggregation CleanroomsConfiguredTable#aggregation}
    */
    readonly aggregation?: CleanroomsConfiguredTableAnalysisRulesPolicyV1Aggregation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#custom CleanroomsConfiguredTable#custom}
    */
    readonly custom?: CleanroomsConfiguredTableAnalysisRulesPolicyV1Custom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#list CleanroomsConfiguredTable#list}
    */
    readonly list?: CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStruct;
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1ToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1 | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyV1ToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicyV1 | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyV1OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicyV1 | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1 | cdktn.IResolvable | undefined);
    private _aggregation;
    get aggregation(): CleanroomsConfiguredTableAnalysisRulesPolicyV1AggregationOutputReference;
    putAggregation(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1Aggregation): void;
    resetAggregation(): void;
    get aggregationInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1Aggregation | undefined;
    private _custom;
    get custom(): CleanroomsConfiguredTableAnalysisRulesPolicyV1CustomOutputReference;
    putCustom(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1Custom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1Custom | undefined;
    private _list;
    get list(): CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStructOutputReference;
    putList(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStruct): void;
    resetList(): void;
    get listInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1ListStruct | undefined;
}
export interface CleanroomsConfiguredTableAnalysisRulesPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#v1 CleanroomsConfiguredTable#v1}
    */
    readonly v1?: CleanroomsConfiguredTableAnalysisRulesPolicyV1;
}
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyToTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicy | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesPolicyToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRulesPolicy | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableAnalysisRulesPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRulesPolicy | cdktn.IResolvable | undefined);
    private _v1;
    get v1(): CleanroomsConfiguredTableAnalysisRulesPolicyV1OutputReference;
    putV1(value: CleanroomsConfiguredTableAnalysisRulesPolicyV1): void;
    resetV1(): void;
    get v1Input(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicyV1 | undefined;
}
export interface CleanroomsConfiguredTableAnalysisRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#policy CleanroomsConfiguredTable#policy}
    */
    readonly policy?: CleanroomsConfiguredTableAnalysisRulesPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#type CleanroomsConfiguredTable#type}
    */
    readonly type?: string;
}
export declare function cleanroomsConfiguredTableAnalysisRulesToTerraform(struct?: CleanroomsConfiguredTableAnalysisRules | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableAnalysisRulesToHclTerraform(struct?: CleanroomsConfiguredTableAnalysisRules | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableAnalysisRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableAnalysisRules | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableAnalysisRules | cdktn.IResolvable | undefined);
    private _policy;
    get policy(): CleanroomsConfiguredTableAnalysisRulesPolicyOutputReference;
    putPolicy(value: CleanroomsConfiguredTableAnalysisRulesPolicy): void;
    resetPolicy(): void;
    get policyInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRulesPolicy | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableAnalysisRulesList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableAnalysisRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableAnalysisRulesOutputReference;
}
export interface CleanroomsConfiguredTableTableReferenceAthena {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#catalog_name CleanroomsConfiguredTable#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#database_name CleanroomsConfiguredTable#database_name}
    */
    readonly databaseName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#output_location CleanroomsConfiguredTable#output_location}
    */
    readonly outputLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#region CleanroomsConfiguredTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#table_name CleanroomsConfiguredTable#table_name}
    */
    readonly tableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#work_group CleanroomsConfiguredTable#work_group}
    */
    readonly workGroup?: string;
}
export declare function cleanroomsConfiguredTableTableReferenceAthenaToTerraform(struct?: CleanroomsConfiguredTableTableReferenceAthena | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableTableReferenceAthenaToHclTerraform(struct?: CleanroomsConfiguredTableTableReferenceAthena | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableTableReferenceAthenaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableTableReferenceAthena | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableTableReferenceAthena | cdktn.IResolvable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _outputLocation?;
    get outputLocation(): string;
    set outputLocation(value: string);
    resetOutputLocation(): void;
    get outputLocationInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
    private _workGroup?;
    get workGroup(): string;
    set workGroup(value: string);
    resetWorkGroup(): void;
    get workGroupInput(): string | undefined;
}
export interface CleanroomsConfiguredTableTableReferenceGlue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#database_name CleanroomsConfiguredTable#database_name}
    */
    readonly databaseName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#region CleanroomsConfiguredTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#table_name CleanroomsConfiguredTable#table_name}
    */
    readonly tableName?: string;
}
export declare function cleanroomsConfiguredTableTableReferenceGlueToTerraform(struct?: CleanroomsConfiguredTableTableReferenceGlue | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableTableReferenceGlueToHclTerraform(struct?: CleanroomsConfiguredTableTableReferenceGlue | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableTableReferenceGlueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableTableReferenceGlue | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableTableReferenceGlue | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
}
export interface CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#column_name CleanroomsConfiguredTable#column_name}
    */
    readonly columnName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#column_type CleanroomsConfiguredTable#column_type}
    */
    readonly columnType?: string;
}
export declare function cleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1ToTerraform(struct?: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1 | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1ToHclTerraform(struct?: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1 | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1 | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1 | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    resetColumnName(): void;
    get columnNameInput(): string | undefined;
    private _columnType?;
    get columnType(): string;
    set columnType(value: string);
    resetColumnType(): void;
    get columnTypeInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1List extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1OutputReference;
}
export interface CleanroomsConfiguredTableTableReferenceSnowflakeTableSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#v1 CleanroomsConfiguredTable#v1}
    */
    readonly v1?: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1[] | cdktn.IResolvable;
}
export declare function cleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaToTerraform(struct?: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchema | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaToHclTerraform(struct?: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchema | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableTableReferenceSnowflakeTableSchema | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchema | cdktn.IResolvable | undefined);
    private _v1;
    get v1(): CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1List;
    putV1(value: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1[] | cdktn.IResolvable): void;
    resetV1(): void;
    get v1Input(): cdktn.IResolvable | CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaV1[] | undefined;
}
export interface CleanroomsConfiguredTableTableReferenceSnowflake {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#account_identifier CleanroomsConfiguredTable#account_identifier}
    */
    readonly accountIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#database_name CleanroomsConfiguredTable#database_name}
    */
    readonly databaseName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#schema_name CleanroomsConfiguredTable#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#secret_arn CleanroomsConfiguredTable#secret_arn}
    */
    readonly secretArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#table_name CleanroomsConfiguredTable#table_name}
    */
    readonly tableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#table_schema CleanroomsConfiguredTable#table_schema}
    */
    readonly tableSchema?: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchema;
}
export declare function cleanroomsConfiguredTableTableReferenceSnowflakeToTerraform(struct?: CleanroomsConfiguredTableTableReferenceSnowflake | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableTableReferenceSnowflakeToHclTerraform(struct?: CleanroomsConfiguredTableTableReferenceSnowflake | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableTableReferenceSnowflakeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableTableReferenceSnowflake | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableTableReferenceSnowflake | cdktn.IResolvable | undefined);
    private _accountIdentifier?;
    get accountIdentifier(): string;
    set accountIdentifier(value: string);
    resetAccountIdentifier(): void;
    get accountIdentifierInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _secretArn?;
    get secretArn(): string;
    set secretArn(value: string);
    resetSecretArn(): void;
    get secretArnInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
    private _tableSchema;
    get tableSchema(): CleanroomsConfiguredTableTableReferenceSnowflakeTableSchemaOutputReference;
    putTableSchema(value: CleanroomsConfiguredTableTableReferenceSnowflakeTableSchema): void;
    resetTableSchema(): void;
    get tableSchemaInput(): cdktn.IResolvable | CleanroomsConfiguredTableTableReferenceSnowflakeTableSchema | undefined;
}
export interface CleanroomsConfiguredTableTableReference {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#athena CleanroomsConfiguredTable#athena}
    */
    readonly athena?: CleanroomsConfiguredTableTableReferenceAthena;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#glue CleanroomsConfiguredTable#glue}
    */
    readonly glue?: CleanroomsConfiguredTableTableReferenceGlue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#snowflake CleanroomsConfiguredTable#snowflake}
    */
    readonly snowflake?: CleanroomsConfiguredTableTableReferenceSnowflake;
}
export declare function cleanroomsConfiguredTableTableReferenceToTerraform(struct?: CleanroomsConfiguredTableTableReference | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableTableReferenceToHclTerraform(struct?: CleanroomsConfiguredTableTableReference | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableTableReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsConfiguredTableTableReference | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableTableReference | cdktn.IResolvable | undefined);
    private _athena;
    get athena(): CleanroomsConfiguredTableTableReferenceAthenaOutputReference;
    putAthena(value: CleanroomsConfiguredTableTableReferenceAthena): void;
    resetAthena(): void;
    get athenaInput(): cdktn.IResolvable | CleanroomsConfiguredTableTableReferenceAthena | undefined;
    private _glue;
    get glue(): CleanroomsConfiguredTableTableReferenceGlueOutputReference;
    putGlue(value: CleanroomsConfiguredTableTableReferenceGlue): void;
    resetGlue(): void;
    get glueInput(): cdktn.IResolvable | CleanroomsConfiguredTableTableReferenceGlue | undefined;
    private _snowflake;
    get snowflake(): CleanroomsConfiguredTableTableReferenceSnowflakeOutputReference;
    putSnowflake(value: CleanroomsConfiguredTableTableReferenceSnowflake): void;
    resetSnowflake(): void;
    get snowflakeInput(): cdktn.IResolvable | CleanroomsConfiguredTableTableReferenceSnowflake | undefined;
}
export interface CleanroomsConfiguredTableTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#key CleanroomsConfiguredTable#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#value CleanroomsConfiguredTable#value}
    */
    readonly value?: string;
}
export declare function cleanroomsConfiguredTableTagsToTerraform(struct?: CleanroomsConfiguredTableTags | cdktn.IResolvable): any;
export declare function cleanroomsConfiguredTableTagsToHclTerraform(struct?: CleanroomsConfiguredTableTags | cdktn.IResolvable): any;
export declare class CleanroomsConfiguredTableTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsConfiguredTableTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsConfiguredTableTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsConfiguredTableTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsConfiguredTableTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsConfiguredTableTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table awscc_cleanrooms_configured_table}
*/
export declare class CleanroomsConfiguredTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanrooms_configured_table";
    /**
    * Generates CDKTN code for importing a CleanroomsConfiguredTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsConfiguredTable to import
    * @param importFromId The id of the existing CleanroomsConfiguredTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsConfiguredTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_configured_table awscc_cleanrooms_configured_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsConfiguredTableConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsConfiguredTableConfig);
    private _allowedColumns?;
    get allowedColumns(): string[];
    set allowedColumns(value: string[]);
    get allowedColumnsInput(): string[] | undefined;
    private _analysisMethod?;
    get analysisMethod(): string;
    set analysisMethod(value: string);
    get analysisMethodInput(): string | undefined;
    private _analysisRules;
    get analysisRules(): CleanroomsConfiguredTableAnalysisRulesList;
    putAnalysisRules(value: CleanroomsConfiguredTableAnalysisRules[] | cdktn.IResolvable): void;
    resetAnalysisRules(): void;
    get analysisRulesInput(): cdktn.IResolvable | CleanroomsConfiguredTableAnalysisRules[] | undefined;
    get arn(): string;
    get configuredTableIdentifier(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _selectedAnalysisMethods?;
    get selectedAnalysisMethods(): string[];
    set selectedAnalysisMethods(value: string[]);
    resetSelectedAnalysisMethods(): void;
    get selectedAnalysisMethodsInput(): string[] | undefined;
    private _tableReference;
    get tableReference(): CleanroomsConfiguredTableTableReferenceOutputReference;
    putTableReference(value: CleanroomsConfiguredTableTableReference): void;
    get tableReferenceInput(): cdktn.IResolvable | CleanroomsConfiguredTableTableReference | undefined;
    private _tags;
    get tags(): CleanroomsConfiguredTableTagsList;
    putTags(value: CleanroomsConfiguredTableTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsConfiguredTableTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
