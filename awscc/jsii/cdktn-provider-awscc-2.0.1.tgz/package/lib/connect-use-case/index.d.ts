/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectUseCaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case#instance_id ConnectUseCase#instance_id}
    */
    readonly instanceId: string;
    /**
    * The identifier for the integration association.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case#integration_association_id ConnectUseCase#integration_association_id}
    */
    readonly integrationAssociationId: string;
    /**
    * The tags used to organize, track, or control access for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case#tags ConnectUseCase#tags}
    */
    readonly tags?: ConnectUseCaseTags[] | cdktn.IResolvable;
    /**
    * The type of use case to associate to the integration association.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case#use_case_type ConnectUseCase#use_case_type}
    */
    readonly useCaseType: string;
}
export interface ConnectUseCaseTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case#key ConnectUseCase#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case#value ConnectUseCase#value}
    */
    readonly value?: string;
}
export declare function connectUseCaseTagsToTerraform(struct?: ConnectUseCaseTags | cdktn.IResolvable): any;
export declare function connectUseCaseTagsToHclTerraform(struct?: ConnectUseCaseTags | cdktn.IResolvable): any;
export declare class ConnectUseCaseTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUseCaseTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUseCaseTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectUseCaseTagsList extends cdktn.ComplexList {
    internalValue?: ConnectUseCaseTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUseCaseTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case awscc_connect_use_case}
*/
export declare class ConnectUseCase extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_use_case";
    /**
    * Generates CDKTN code for importing a ConnectUseCase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectUseCase to import
    * @param importFromId The id of the existing ConnectUseCase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectUseCase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_use_case awscc_connect_use_case} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectUseCaseConfig
    */
    constructor(scope: Construct, id: string, config: ConnectUseCaseConfig);
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _integrationAssociationId?;
    get integrationAssociationId(): string;
    set integrationAssociationId(value: string);
    get integrationAssociationIdInput(): string | undefined;
    private _tags;
    get tags(): ConnectUseCaseTagsList;
    putTags(value: ConnectUseCaseTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectUseCaseTags[] | undefined;
    get useCaseArn(): string;
    get useCaseId(): string;
    private _useCaseType?;
    get useCaseType(): string;
    set useCaseType(value: string);
    get useCaseTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
