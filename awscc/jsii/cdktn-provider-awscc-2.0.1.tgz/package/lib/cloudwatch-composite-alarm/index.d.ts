/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchCompositeAlarmConfig extends cdktn.TerraformMetaArguments {
    /**
    * Configuration that applies to the notifications this alarm sends when it performs its actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#action_configuration CloudwatchCompositeAlarm#action_configuration}
    */
    readonly actionConfiguration?: CloudwatchCompositeAlarmActionConfiguration;
    /**
    * Indicates whether actions should be executed during any changes to the alarm state. The default is TRUE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#actions_enabled CloudwatchCompositeAlarm#actions_enabled}
    */
    readonly actionsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Actions will be suppressed if the suppressor alarm is in the ALARM state. ActionsSuppressor can be an AlarmName or an Amazon Resource Name (ARN) from an existing alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#actions_suppressor CloudwatchCompositeAlarm#actions_suppressor}
    */
    readonly actionsSuppressor?: string;
    /**
    * Actions will be suppressed if WaitPeriod is active. The length of time that actions are suppressed is in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#actions_suppressor_extension_period CloudwatchCompositeAlarm#actions_suppressor_extension_period}
    */
    readonly actionsSuppressorExtensionPeriod?: number;
    /**
    * Actions will be suppressed if ExtensionPeriod is active. The length of time that actions are suppressed is in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#actions_suppressor_wait_period CloudwatchCompositeAlarm#actions_suppressor_wait_period}
    */
    readonly actionsSuppressorWaitPeriod?: number;
    /**
    * The list of actions to execute when this alarm transitions into an ALARM state from any other state. Specify each action as an Amazon Resource Name (ARN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#alarm_actions CloudwatchCompositeAlarm#alarm_actions}
    */
    readonly alarmActions?: string[];
    /**
    * The description of the alarm
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#alarm_description CloudwatchCompositeAlarm#alarm_description}
    */
    readonly alarmDescription?: string;
    /**
    * The name of the Composite Alarm
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#alarm_name CloudwatchCompositeAlarm#alarm_name}
    */
    readonly alarmName?: string;
    /**
    * Expression which aggregates the state of other Alarms (Metric or Composite Alarms)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#alarm_rule CloudwatchCompositeAlarm#alarm_rule}
    */
    readonly alarmRule: string;
    /**
    * The actions to execute when this alarm transitions to the INSUFFICIENT_DATA state from any other state. Each action is specified as an Amazon Resource Name (ARN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#insufficient_data_actions CloudwatchCompositeAlarm#insufficient_data_actions}
    */
    readonly insufficientDataActions?: string[];
    /**
    * The actions to execute when this alarm transitions to the OK state from any other state. Each action is specified as an Amazon Resource Name (ARN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#ok_actions CloudwatchCompositeAlarm#ok_actions}
    */
    readonly okActions?: string[];
    /**
    * A list of key-value pairs to associate with the composite alarm. You can associate as many as 50 tags with an alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#tags CloudwatchCompositeAlarm#tags}
    */
    readonly tags?: CloudwatchCompositeAlarmTags[] | cdktn.IResolvable;
}
export interface CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagation {
    /**
    * Whether the alarm's tags are included in its action notifications and state-change events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#enabled CloudwatchCompositeAlarm#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The tag keys to leave out. Cannot be specified together with IncludedTagKeys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#excluded_tag_keys CloudwatchCompositeAlarm#excluded_tag_keys}
    */
    readonly excludedTagKeys?: string[];
    /**
    * The only tag keys to include. Cannot be specified together with ExcludedTagKeys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#included_tag_keys CloudwatchCompositeAlarm#included_tag_keys}
    */
    readonly includedTagKeys?: string[];
}
export declare function cloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagationToTerraform(struct?: CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagation | cdktn.IResolvable): any;
export declare function cloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagationToHclTerraform(struct?: CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagation | cdktn.IResolvable): any;
export declare class CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagation | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedTagKeys?;
    get excludedTagKeys(): string[];
    set excludedTagKeys(value: string[]);
    resetExcludedTagKeys(): void;
    get excludedTagKeysInput(): string[] | undefined;
    private _includedTagKeys?;
    get includedTagKeys(): string[];
    set includedTagKeys(value: string[]);
    resetIncludedTagKeys(): void;
    get includedTagKeysInput(): string[] | undefined;
}
export interface CloudwatchCompositeAlarmActionConfiguration {
    /**
    * Whether the alarm's tags are included in its action notifications and state-change events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#alarm_tags_propagation CloudwatchCompositeAlarm#alarm_tags_propagation}
    */
    readonly alarmTagsPropagation?: CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagation;
}
export declare function cloudwatchCompositeAlarmActionConfigurationToTerraform(struct?: CloudwatchCompositeAlarmActionConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchCompositeAlarmActionConfigurationToHclTerraform(struct?: CloudwatchCompositeAlarmActionConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchCompositeAlarmActionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchCompositeAlarmActionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchCompositeAlarmActionConfiguration | cdktn.IResolvable | undefined);
    private _alarmTagsPropagation;
    get alarmTagsPropagation(): CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagationOutputReference;
    putAlarmTagsPropagation(value: CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagation): void;
    resetAlarmTagsPropagation(): void;
    get alarmTagsPropagationInput(): cdktn.IResolvable | CloudwatchCompositeAlarmActionConfigurationAlarmTagsPropagation | undefined;
}
export interface CloudwatchCompositeAlarmTags {
    /**
    * A unique identifier for the tag. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#key CloudwatchCompositeAlarm#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#value CloudwatchCompositeAlarm#value}
    */
    readonly value?: string;
}
export declare function cloudwatchCompositeAlarmTagsToTerraform(struct?: CloudwatchCompositeAlarmTags | cdktn.IResolvable): any;
export declare function cloudwatchCompositeAlarmTagsToHclTerraform(struct?: CloudwatchCompositeAlarmTags | cdktn.IResolvable): any;
export declare class CloudwatchCompositeAlarmTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchCompositeAlarmTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchCompositeAlarmTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchCompositeAlarmTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchCompositeAlarmTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchCompositeAlarmTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm awscc_cloudwatch_composite_alarm}
*/
export declare class CloudwatchCompositeAlarm extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_composite_alarm";
    /**
    * Generates CDKTN code for importing a CloudwatchCompositeAlarm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchCompositeAlarm to import
    * @param importFromId The id of the existing CloudwatchCompositeAlarm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchCompositeAlarm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_composite_alarm awscc_cloudwatch_composite_alarm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchCompositeAlarmConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchCompositeAlarmConfig);
    private _actionConfiguration;
    get actionConfiguration(): CloudwatchCompositeAlarmActionConfigurationOutputReference;
    putActionConfiguration(value: CloudwatchCompositeAlarmActionConfiguration): void;
    resetActionConfiguration(): void;
    get actionConfigurationInput(): cdktn.IResolvable | CloudwatchCompositeAlarmActionConfiguration | undefined;
    private _actionsEnabled?;
    get actionsEnabled(): boolean | cdktn.IResolvable;
    set actionsEnabled(value: boolean | cdktn.IResolvable);
    resetActionsEnabled(): void;
    get actionsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _actionsSuppressor?;
    get actionsSuppressor(): string;
    set actionsSuppressor(value: string);
    resetActionsSuppressor(): void;
    get actionsSuppressorInput(): string | undefined;
    private _actionsSuppressorExtensionPeriod?;
    get actionsSuppressorExtensionPeriod(): number;
    set actionsSuppressorExtensionPeriod(value: number);
    resetActionsSuppressorExtensionPeriod(): void;
    get actionsSuppressorExtensionPeriodInput(): number | undefined;
    private _actionsSuppressorWaitPeriod?;
    get actionsSuppressorWaitPeriod(): number;
    set actionsSuppressorWaitPeriod(value: number);
    resetActionsSuppressorWaitPeriod(): void;
    get actionsSuppressorWaitPeriodInput(): number | undefined;
    private _alarmActions?;
    get alarmActions(): string[];
    set alarmActions(value: string[]);
    resetAlarmActions(): void;
    get alarmActionsInput(): string[] | undefined;
    private _alarmDescription?;
    get alarmDescription(): string;
    set alarmDescription(value: string);
    resetAlarmDescription(): void;
    get alarmDescriptionInput(): string | undefined;
    private _alarmName?;
    get alarmName(): string;
    set alarmName(value: string);
    resetAlarmName(): void;
    get alarmNameInput(): string | undefined;
    private _alarmRule?;
    get alarmRule(): string;
    set alarmRule(value: string);
    get alarmRuleInput(): string | undefined;
    get arn(): string;
    get id(): string;
    private _insufficientDataActions?;
    get insufficientDataActions(): string[];
    set insufficientDataActions(value: string[]);
    resetInsufficientDataActions(): void;
    get insufficientDataActionsInput(): string[] | undefined;
    private _okActions?;
    get okActions(): string[];
    set okActions(value: string[]);
    resetOkActions(): void;
    get okActionsInput(): string[] | undefined;
    private _tags;
    get tags(): CloudwatchCompositeAlarmTagsList;
    putTags(value: CloudwatchCompositeAlarmTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchCompositeAlarmTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
