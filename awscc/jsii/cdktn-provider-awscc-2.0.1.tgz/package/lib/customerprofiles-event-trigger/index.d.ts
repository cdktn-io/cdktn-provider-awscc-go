/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesEventTriggerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the event trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#description CustomerprofilesEventTrigger#description}
    */
    readonly description?: string;
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#domain_name CustomerprofilesEventTrigger#domain_name}
    */
    readonly domainName: string;
    /**
    * A list of conditions that determine when an event should trigger the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#event_trigger_conditions CustomerprofilesEventTrigger#event_trigger_conditions}
    */
    readonly eventTriggerConditions: CustomerprofilesEventTriggerEventTriggerConditions[] | cdktn.IResolvable;
    /**
    * Defines limits controlling whether an event triggers the destination, based on ingestion latency and the number of invocations per profile over specific time periods.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#event_trigger_limits CustomerprofilesEventTrigger#event_trigger_limits}
    */
    readonly eventTriggerLimits?: CustomerprofilesEventTriggerEventTriggerLimits;
    /**
    * The unique name of the event trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#event_trigger_name CustomerprofilesEventTrigger#event_trigger_name}
    */
    readonly eventTriggerName: string;
    /**
    * The unique name of the object type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#object_type_name CustomerprofilesEventTrigger#object_type_name}
    */
    readonly objectTypeName: string;
    /**
    * The destination is triggered only for profiles that meet the criteria of a segment definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#segment_filter CustomerprofilesEventTrigger#segment_filter}
    */
    readonly segmentFilter?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#tags CustomerprofilesEventTrigger#tags}
    */
    readonly tags?: CustomerprofilesEventTriggerTags[] | cdktn.IResolvable;
}
export interface CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes {
    /**
    * The operator used to compare an attribute against a list of values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#comparison_operator CustomerprofilesEventTrigger#comparison_operator}
    */
    readonly comparisonOperator: string;
    /**
    * A field defined within an object type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#field_name CustomerprofilesEventTrigger#field_name}
    */
    readonly fieldName?: string;
    /**
    * An attribute contained within a source object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#source CustomerprofilesEventTrigger#source}
    */
    readonly source?: string;
    /**
    * A list of attribute values used for comparison.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#values CustomerprofilesEventTrigger#values}
    */
    readonly values: string[];
}
export declare function customerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributesToTerraform(struct?: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes | cdktn.IResolvable): any;
export declare function customerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributesToHclTerraform(struct?: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes | cdktn.IResolvable): any;
export declare class CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes | cdktn.IResolvable | undefined);
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    get comparisonOperatorInput(): string | undefined;
    private _fieldName?;
    get fieldName(): string;
    set fieldName(value: string);
    resetFieldName(): void;
    get fieldNameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributesList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributesOutputReference;
}
export interface CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions {
    /**
    * A list of object attributes to be evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#object_attributes CustomerprofilesEventTrigger#object_attributes}
    */
    readonly objectAttributes: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes[] | cdktn.IResolvable;
}
export declare function customerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsToTerraform(struct?: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions | cdktn.IResolvable): any;
export declare function customerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsToHclTerraform(struct?: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions | cdktn.IResolvable): any;
export declare class CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions | cdktn.IResolvable | undefined);
    private _objectAttributes;
    get objectAttributes(): CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributesList;
    putObjectAttributes(value: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes[] | cdktn.IResolvable): void;
    get objectAttributesInput(): cdktn.IResolvable | CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsObjectAttributes[] | undefined;
}
export declare class CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsOutputReference;
}
export interface CustomerprofilesEventTriggerEventTriggerConditions {
    /**
    * A list of dimensions to be evaluated for the event.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#event_trigger_dimensions CustomerprofilesEventTrigger#event_trigger_dimensions}
    */
    readonly eventTriggerDimensions: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions[] | cdktn.IResolvable;
    /**
    * The operator used to combine multiple dimensions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#logical_operator CustomerprofilesEventTrigger#logical_operator}
    */
    readonly logicalOperator: string;
}
export declare function customerprofilesEventTriggerEventTriggerConditionsToTerraform(struct?: CustomerprofilesEventTriggerEventTriggerConditions | cdktn.IResolvable): any;
export declare function customerprofilesEventTriggerEventTriggerConditionsToHclTerraform(struct?: CustomerprofilesEventTriggerEventTriggerConditions | cdktn.IResolvable): any;
export declare class CustomerprofilesEventTriggerEventTriggerConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesEventTriggerEventTriggerConditions | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesEventTriggerEventTriggerConditions | cdktn.IResolvable | undefined);
    private _eventTriggerDimensions;
    get eventTriggerDimensions(): CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensionsList;
    putEventTriggerDimensions(value: CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions[] | cdktn.IResolvable): void;
    get eventTriggerDimensionsInput(): cdktn.IResolvable | CustomerprofilesEventTriggerEventTriggerConditionsEventTriggerDimensions[] | undefined;
    private _logicalOperator?;
    get logicalOperator(): string;
    set logicalOperator(value: string);
    get logicalOperatorInput(): string | undefined;
}
export declare class CustomerprofilesEventTriggerEventTriggerConditionsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesEventTriggerEventTriggerConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesEventTriggerEventTriggerConditionsOutputReference;
}
export interface CustomerprofilesEventTriggerEventTriggerLimitsPeriods {
    /**
    * The maximum allowed number of destination invocations per profile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#max_invocations_per_profile CustomerprofilesEventTrigger#max_invocations_per_profile}
    */
    readonly maxInvocationsPerProfile?: number;
    /**
    * The unit of time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#unit CustomerprofilesEventTrigger#unit}
    */
    readonly unit?: string;
    /**
    * If set to true, there is no limit on the number of destination invocations per profile. The default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#unlimited CustomerprofilesEventTrigger#unlimited}
    */
    readonly unlimited?: boolean | cdktn.IResolvable;
    /**
    * The amount of time of the specified unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#value CustomerprofilesEventTrigger#value}
    */
    readonly value?: number;
}
export declare function customerprofilesEventTriggerEventTriggerLimitsPeriodsToTerraform(struct?: CustomerprofilesEventTriggerEventTriggerLimitsPeriods | cdktn.IResolvable): any;
export declare function customerprofilesEventTriggerEventTriggerLimitsPeriodsToHclTerraform(struct?: CustomerprofilesEventTriggerEventTriggerLimitsPeriods | cdktn.IResolvable): any;
export declare class CustomerprofilesEventTriggerEventTriggerLimitsPeriodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesEventTriggerEventTriggerLimitsPeriods | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesEventTriggerEventTriggerLimitsPeriods | cdktn.IResolvable | undefined);
    private _maxInvocationsPerProfile?;
    get maxInvocationsPerProfile(): number;
    set maxInvocationsPerProfile(value: number);
    resetMaxInvocationsPerProfile(): void;
    get maxInvocationsPerProfileInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _unlimited?;
    get unlimited(): boolean | cdktn.IResolvable;
    set unlimited(value: boolean | cdktn.IResolvable);
    resetUnlimited(): void;
    get unlimitedInput(): boolean | cdktn.IResolvable | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export declare class CustomerprofilesEventTriggerEventTriggerLimitsPeriodsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesEventTriggerEventTriggerLimitsPeriods[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesEventTriggerEventTriggerLimitsPeriodsOutputReference;
}
export interface CustomerprofilesEventTriggerEventTriggerLimits {
    /**
    * Specifies that an event will only trigger the destination if it is processed within a certain latency period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#event_expiration CustomerprofilesEventTrigger#event_expiration}
    */
    readonly eventExpiration?: number;
    /**
    * A list of time periods during which the limits apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#periods CustomerprofilesEventTrigger#periods}
    */
    readonly periods?: CustomerprofilesEventTriggerEventTriggerLimitsPeriods[] | cdktn.IResolvable;
}
export declare function customerprofilesEventTriggerEventTriggerLimitsToTerraform(struct?: CustomerprofilesEventTriggerEventTriggerLimits | cdktn.IResolvable): any;
export declare function customerprofilesEventTriggerEventTriggerLimitsToHclTerraform(struct?: CustomerprofilesEventTriggerEventTriggerLimits | cdktn.IResolvable): any;
export declare class CustomerprofilesEventTriggerEventTriggerLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomerprofilesEventTriggerEventTriggerLimits | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesEventTriggerEventTriggerLimits | cdktn.IResolvable | undefined);
    private _eventExpiration?;
    get eventExpiration(): number;
    set eventExpiration(value: number);
    resetEventExpiration(): void;
    get eventExpirationInput(): number | undefined;
    private _periods;
    get periods(): CustomerprofilesEventTriggerEventTriggerLimitsPeriodsList;
    putPeriods(value: CustomerprofilesEventTriggerEventTriggerLimitsPeriods[] | cdktn.IResolvable): void;
    resetPeriods(): void;
    get periodsInput(): cdktn.IResolvable | CustomerprofilesEventTriggerEventTriggerLimitsPeriods[] | undefined;
}
export interface CustomerprofilesEventTriggerTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#key CustomerprofilesEventTrigger#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#value CustomerprofilesEventTrigger#value}
    */
    readonly value?: string;
}
export declare function customerprofilesEventTriggerTagsToTerraform(struct?: CustomerprofilesEventTriggerTags | cdktn.IResolvable): any;
export declare function customerprofilesEventTriggerTagsToHclTerraform(struct?: CustomerprofilesEventTriggerTags | cdktn.IResolvable): any;
export declare class CustomerprofilesEventTriggerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesEventTriggerTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesEventTriggerTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesEventTriggerTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesEventTriggerTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesEventTriggerTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger awscc_customerprofiles_event_trigger}
*/
export declare class CustomerprofilesEventTrigger extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_event_trigger";
    /**
    * Generates CDKTN code for importing a CustomerprofilesEventTrigger resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesEventTrigger to import
    * @param importFromId The id of the existing CustomerprofilesEventTrigger that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesEventTrigger to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_event_trigger awscc_customerprofiles_event_trigger} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesEventTriggerConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesEventTriggerConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _eventTriggerConditions;
    get eventTriggerConditions(): CustomerprofilesEventTriggerEventTriggerConditionsList;
    putEventTriggerConditions(value: CustomerprofilesEventTriggerEventTriggerConditions[] | cdktn.IResolvable): void;
    get eventTriggerConditionsInput(): cdktn.IResolvable | CustomerprofilesEventTriggerEventTriggerConditions[] | undefined;
    private _eventTriggerLimits;
    get eventTriggerLimits(): CustomerprofilesEventTriggerEventTriggerLimitsOutputReference;
    putEventTriggerLimits(value: CustomerprofilesEventTriggerEventTriggerLimits): void;
    resetEventTriggerLimits(): void;
    get eventTriggerLimitsInput(): cdktn.IResolvable | CustomerprofilesEventTriggerEventTriggerLimits | undefined;
    private _eventTriggerName?;
    get eventTriggerName(): string;
    set eventTriggerName(value: string);
    get eventTriggerNameInput(): string | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    private _objectTypeName?;
    get objectTypeName(): string;
    set objectTypeName(value: string);
    get objectTypeNameInput(): string | undefined;
    private _segmentFilter?;
    get segmentFilter(): string;
    set segmentFilter(value: string);
    resetSegmentFilter(): void;
    get segmentFilterInput(): string | undefined;
    private _tags;
    get tags(): CustomerprofilesEventTriggerTagsList;
    putTags(value: CustomerprofilesEventTriggerTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesEventTriggerTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
