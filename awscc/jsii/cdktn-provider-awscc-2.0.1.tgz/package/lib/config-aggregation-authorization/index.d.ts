/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigAggregationAuthorizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The 12-digit account ID of the account authorized to aggregate data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_aggregation_authorization#authorized_account_id ConfigAggregationAuthorization#authorized_account_id}
    */
    readonly authorizedAccountId: string;
    /**
    * The region authorized to collect aggregated data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_aggregation_authorization#authorized_aws_region ConfigAggregationAuthorization#authorized_aws_region}
    */
    readonly authorizedAwsRegion: string;
    /**
    * The tags for the AggregationAuthorization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_aggregation_authorization#tags ConfigAggregationAuthorization#tags}
    */
    readonly tags?: ConfigAggregationAuthorizationTags[] | cdktn.IResolvable;
}
export interface ConfigAggregationAuthorizationTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_aggregation_authorization#key ConfigAggregationAuthorization#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_aggregation_authorization#value ConfigAggregationAuthorization#value}
    */
    readonly value?: string;
}
export declare function configAggregationAuthorizationTagsToTerraform(struct?: ConfigAggregationAuthorizationTags | cdktn.IResolvable): any;
export declare function configAggregationAuthorizationTagsToHclTerraform(struct?: ConfigAggregationAuthorizationTags | cdktn.IResolvable): any;
export declare class ConfigAggregationAuthorizationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigAggregationAuthorizationTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigAggregationAuthorizationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConfigAggregationAuthorizationTagsList extends cdktn.ComplexList {
    internalValue?: ConfigAggregationAuthorizationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigAggregationAuthorizationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_aggregation_authorization awscc_config_aggregation_authorization}
*/
export declare class ConfigAggregationAuthorization extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_aggregation_authorization";
    /**
    * Generates CDKTN code for importing a ConfigAggregationAuthorization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigAggregationAuthorization to import
    * @param importFromId The id of the existing ConfigAggregationAuthorization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_aggregation_authorization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigAggregationAuthorization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_aggregation_authorization awscc_config_aggregation_authorization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigAggregationAuthorizationConfig
    */
    constructor(scope: Construct, id: string, config: ConfigAggregationAuthorizationConfig);
    get aggregationAuthorizationArn(): string;
    private _authorizedAccountId?;
    get authorizedAccountId(): string;
    set authorizedAccountId(value: string);
    get authorizedAccountIdInput(): string | undefined;
    private _authorizedAwsRegion?;
    get authorizedAwsRegion(): string;
    set authorizedAwsRegion(value: string);
    get authorizedAwsRegionInput(): string | undefined;
    get id(): string;
    private _tags;
    get tags(): ConfigAggregationAuthorizationTagsList;
    putTags(value: ConfigAggregationAuthorizationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConfigAggregationAuthorizationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
