/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsAnalysisTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The member who can query can provide this placeholder for a literal data value in an analysis template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#analysis_parameters CleanroomsAnalysisTemplate#analysis_parameters}
    */
    readonly analysisParameters?: CleanroomsAnalysisTemplateAnalysisParameters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#description CleanroomsAnalysisTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#error_message_configuration CleanroomsAnalysisTemplate#error_message_configuration}
    */
    readonly errorMessageConfiguration?: CleanroomsAnalysisTemplateErrorMessageConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#format CleanroomsAnalysisTemplate#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#membership_identifier CleanroomsAnalysisTemplate#membership_identifier}
    */
    readonly membershipIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#name CleanroomsAnalysisTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#schema CleanroomsAnalysisTemplate#schema}
    */
    readonly schema?: CleanroomsAnalysisTemplateSchema;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#source CleanroomsAnalysisTemplate#source}
    */
    readonly source: CleanroomsAnalysisTemplateSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#source_metadata CleanroomsAnalysisTemplate#source_metadata}
    */
    readonly sourceMetadata?: CleanroomsAnalysisTemplateSourceMetadata;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#synthetic_data_parameters CleanroomsAnalysisTemplate#synthetic_data_parameters}
    */
    readonly syntheticDataParameters?: CleanroomsAnalysisTemplateSyntheticDataParameters;
    /**
    * An arbitrary set of tags (key-value pairs) for this cleanrooms analysis template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#tags CleanroomsAnalysisTemplate#tags}
    */
    readonly tags?: CleanroomsAnalysisTemplateTags[] | cdktn.IResolvable;
}
export interface CleanroomsAnalysisTemplateAnalysisParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#default_value CleanroomsAnalysisTemplate#default_value}
    */
    readonly defaultValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#name CleanroomsAnalysisTemplate#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#type CleanroomsAnalysisTemplate#type}
    */
    readonly type?: string;
}
export declare function cleanroomsAnalysisTemplateAnalysisParametersToTerraform(struct?: CleanroomsAnalysisTemplateAnalysisParameters | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateAnalysisParametersToHclTerraform(struct?: CleanroomsAnalysisTemplateAnalysisParameters | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateAnalysisParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsAnalysisTemplateAnalysisParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateAnalysisParameters | cdktn.IResolvable | undefined);
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CleanroomsAnalysisTemplateAnalysisParametersList extends cdktn.ComplexList {
    internalValue?: CleanroomsAnalysisTemplateAnalysisParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsAnalysisTemplateAnalysisParametersOutputReference;
}
export interface CleanroomsAnalysisTemplateErrorMessageConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#type CleanroomsAnalysisTemplate#type}
    */
    readonly type?: string;
}
export declare function cleanroomsAnalysisTemplateErrorMessageConfigurationToTerraform(struct?: CleanroomsAnalysisTemplateErrorMessageConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateErrorMessageConfigurationToHclTerraform(struct?: CleanroomsAnalysisTemplateErrorMessageConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateErrorMessageConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateErrorMessageConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateErrorMessageConfiguration | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CleanroomsAnalysisTemplateSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#referenced_tables CleanroomsAnalysisTemplate#referenced_tables}
    */
    readonly referencedTables?: string[];
}
export declare function cleanroomsAnalysisTemplateSchemaToTerraform(struct?: CleanroomsAnalysisTemplateSchema | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSchemaToHclTerraform(struct?: CleanroomsAnalysisTemplateSchema | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSchema | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSchema | cdktn.IResolvable | undefined);
    private _referencedTables?;
    get referencedTables(): string[];
    set referencedTables(value: string[]);
    resetReferencedTables(): void;
    get referencedTablesInput(): string[] | undefined;
}
export interface CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#bucket CleanroomsAnalysisTemplate#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#key CleanroomsAnalysisTemplate#key}
    */
    readonly key?: string;
}
export declare function cleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocationToTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocation | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocationToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocation | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocation | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocation | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
}
export interface CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#location CleanroomsAnalysisTemplate#location}
    */
    readonly location?: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocation;
}
export declare function cleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsToTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts | cdktn.IResolvable | undefined);
    private _location;
    get location(): CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocationOutputReference;
    putLocation(value: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocation): void;
    resetLocation(): void;
    get locationInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsLocation | undefined;
}
export declare class CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsList extends cdktn.ComplexList {
    internalValue?: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsOutputReference;
}
export interface CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#bucket CleanroomsAnalysisTemplate#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#key CleanroomsAnalysisTemplate#key}
    */
    readonly key?: string;
}
export declare function cleanroomsAnalysisTemplateSourceArtifactsEntryPointLocationToTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocation | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceArtifactsEntryPointLocationToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocation | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocation | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocation | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
}
export interface CleanroomsAnalysisTemplateSourceArtifactsEntryPoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#location CleanroomsAnalysisTemplate#location}
    */
    readonly location?: CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocation;
}
export declare function cleanroomsAnalysisTemplateSourceArtifactsEntryPointToTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifactsEntryPoint | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceArtifactsEntryPointToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifactsEntryPoint | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceArtifactsEntryPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSourceArtifactsEntryPoint | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceArtifactsEntryPoint | cdktn.IResolvable | undefined);
    private _location;
    get location(): CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocationOutputReference;
    putLocation(value: CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocation): void;
    resetLocation(): void;
    get locationInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceArtifactsEntryPointLocation | undefined;
}
export interface CleanroomsAnalysisTemplateSourceArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#additional_artifacts CleanroomsAnalysisTemplate#additional_artifacts}
    */
    readonly additionalArtifacts?: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#entry_point CleanroomsAnalysisTemplate#entry_point}
    */
    readonly entryPoint?: CleanroomsAnalysisTemplateSourceArtifactsEntryPoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#role_arn CleanroomsAnalysisTemplate#role_arn}
    */
    readonly roleArn?: string;
}
export declare function cleanroomsAnalysisTemplateSourceArtifactsToTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifacts | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceArtifactsToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceArtifacts | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSourceArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceArtifacts | cdktn.IResolvable | undefined);
    private _additionalArtifacts;
    get additionalArtifacts(): CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifactsList;
    putAdditionalArtifacts(value: CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts[] | cdktn.IResolvable): void;
    resetAdditionalArtifacts(): void;
    get additionalArtifactsInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceArtifactsAdditionalArtifacts[] | undefined;
    private _entryPoint;
    get entryPoint(): CleanroomsAnalysisTemplateSourceArtifactsEntryPointOutputReference;
    putEntryPoint(value: CleanroomsAnalysisTemplateSourceArtifactsEntryPoint): void;
    resetEntryPoint(): void;
    get entryPointInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceArtifactsEntryPoint | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
}
export interface CleanroomsAnalysisTemplateSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#artifacts CleanroomsAnalysisTemplate#artifacts}
    */
    readonly artifacts?: CleanroomsAnalysisTemplateSourceArtifacts;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#text CleanroomsAnalysisTemplate#text}
    */
    readonly text?: string;
}
export declare function cleanroomsAnalysisTemplateSourceToTerraform(struct?: CleanroomsAnalysisTemplateSource | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceToHclTerraform(struct?: CleanroomsAnalysisTemplateSource | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSource | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSource | cdktn.IResolvable | undefined);
    private _artifacts;
    get artifacts(): CleanroomsAnalysisTemplateSourceArtifactsOutputReference;
    putArtifacts(value: CleanroomsAnalysisTemplateSourceArtifacts): void;
    resetArtifacts(): void;
    get artifactsInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceArtifacts | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
}
export interface CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#sha_256 CleanroomsAnalysisTemplate#sha_256}
    */
    readonly sha256?: string;
}
export declare function cleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashesToTerraform(struct?: CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashesToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes | cdktn.IResolvable | undefined);
    private _sha256?;
    get sha256(): string;
    set sha256(value: string);
    resetSha256(): void;
    get sha256Input(): string | undefined;
}
export declare class CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashesList extends cdktn.ComplexList {
    internalValue?: CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashesOutputReference;
}
export interface CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHash {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#sha_256 CleanroomsAnalysisTemplate#sha_256}
    */
    readonly sha256?: string;
}
export declare function cleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHashToTerraform(struct?: CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHash | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHashToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHash | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHash | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHash | cdktn.IResolvable | undefined);
    private _sha256?;
    get sha256(): string;
    set sha256(value: string);
    resetSha256(): void;
    get sha256Input(): string | undefined;
}
export interface CleanroomsAnalysisTemplateSourceMetadataArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#additional_artifact_hashes CleanroomsAnalysisTemplate#additional_artifact_hashes}
    */
    readonly additionalArtifactHashes?: CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#entry_point_hash CleanroomsAnalysisTemplate#entry_point_hash}
    */
    readonly entryPointHash?: CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHash;
}
export declare function cleanroomsAnalysisTemplateSourceMetadataArtifactsToTerraform(struct?: CleanroomsAnalysisTemplateSourceMetadataArtifacts | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceMetadataArtifactsToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceMetadataArtifacts | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceMetadataArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSourceMetadataArtifacts | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceMetadataArtifacts | cdktn.IResolvable | undefined);
    private _additionalArtifactHashes;
    get additionalArtifactHashes(): CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashesList;
    putAdditionalArtifactHashes(value: CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes[] | cdktn.IResolvable): void;
    resetAdditionalArtifactHashes(): void;
    get additionalArtifactHashesInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceMetadataArtifactsAdditionalArtifactHashes[] | undefined;
    private _entryPointHash;
    get entryPointHash(): CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHashOutputReference;
    putEntryPointHash(value: CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHash): void;
    resetEntryPointHash(): void;
    get entryPointHashInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceMetadataArtifactsEntryPointHash | undefined;
}
export interface CleanroomsAnalysisTemplateSourceMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#artifacts CleanroomsAnalysisTemplate#artifacts}
    */
    readonly artifacts?: CleanroomsAnalysisTemplateSourceMetadataArtifacts;
}
export declare function cleanroomsAnalysisTemplateSourceMetadataToTerraform(struct?: CleanroomsAnalysisTemplateSourceMetadata | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSourceMetadataToHclTerraform(struct?: CleanroomsAnalysisTemplateSourceMetadata | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSourceMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSourceMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSourceMetadata | cdktn.IResolvable | undefined);
    private _artifacts;
    get artifacts(): CleanroomsAnalysisTemplateSourceMetadataArtifactsOutputReference;
    putArtifacts(value: CleanroomsAnalysisTemplateSourceMetadataArtifacts): void;
    resetArtifacts(): void;
    get artifactsInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceMetadataArtifacts | undefined;
}
export interface CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#column_name CleanroomsAnalysisTemplate#column_name}
    */
    readonly columnName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#column_type CleanroomsAnalysisTemplate#column_type}
    */
    readonly columnType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#is_predictive_value CleanroomsAnalysisTemplate#is_predictive_value}
    */
    readonly isPredictiveValue?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMappingToTerraform(struct?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMappingToHclTerraform(struct?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    resetColumnName(): void;
    get columnNameInput(): string | undefined;
    private _columnType?;
    get columnType(): string;
    set columnType(value: string);
    resetColumnType(): void;
    get columnTypeInput(): string | undefined;
    private _isPredictiveValue?;
    get isPredictiveValue(): boolean | cdktn.IResolvable;
    set isPredictiveValue(value: boolean | cdktn.IResolvable);
    resetIsPredictiveValue(): void;
    get isPredictiveValueInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMappingList extends cdktn.ComplexList {
    internalValue?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMappingOutputReference;
}
export interface CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassification {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#column_mapping CleanroomsAnalysisTemplate#column_mapping}
    */
    readonly columnMapping?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping[] | cdktn.IResolvable;
}
export declare function cleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationToTerraform(struct?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassification | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationToHclTerraform(struct?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassification | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassification | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassification | cdktn.IResolvable | undefined);
    private _columnMapping;
    get columnMapping(): CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMappingList;
    putColumnMapping(value: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping[] | cdktn.IResolvable): void;
    resetColumnMapping(): void;
    get columnMappingInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationColumnMapping[] | undefined;
}
export interface CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#column_classification CleanroomsAnalysisTemplate#column_classification}
    */
    readonly columnClassification?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassification;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#epsilon CleanroomsAnalysisTemplate#epsilon}
    */
    readonly epsilon?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#max_membership_inference_attack_score CleanroomsAnalysisTemplate#max_membership_inference_attack_score}
    */
    readonly maxMembershipInferenceAttackScore?: number;
}
export declare function cleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersToTerraform(struct?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParameters | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersToHclTerraform(struct?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParameters | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParameters | cdktn.IResolvable | undefined);
    private _columnClassification;
    get columnClassification(): CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassificationOutputReference;
    putColumnClassification(value: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassification): void;
    resetColumnClassification(): void;
    get columnClassificationInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersColumnClassification | undefined;
    private _epsilon?;
    get epsilon(): number;
    set epsilon(value: number);
    resetEpsilon(): void;
    get epsilonInput(): number | undefined;
    private _maxMembershipInferenceAttackScore?;
    get maxMembershipInferenceAttackScore(): number;
    set maxMembershipInferenceAttackScore(value: number);
    resetMaxMembershipInferenceAttackScore(): void;
    get maxMembershipInferenceAttackScoreInput(): number | undefined;
}
export interface CleanroomsAnalysisTemplateSyntheticDataParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#ml_synthetic_data_parameters CleanroomsAnalysisTemplate#ml_synthetic_data_parameters}
    */
    readonly mlSyntheticDataParameters?: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParameters;
}
export declare function cleanroomsAnalysisTemplateSyntheticDataParametersToTerraform(struct?: CleanroomsAnalysisTemplateSyntheticDataParameters | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateSyntheticDataParametersToHclTerraform(struct?: CleanroomsAnalysisTemplateSyntheticDataParameters | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateSyntheticDataParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsAnalysisTemplateSyntheticDataParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateSyntheticDataParameters | cdktn.IResolvable | undefined);
    private _mlSyntheticDataParameters;
    get mlSyntheticDataParameters(): CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParametersOutputReference;
    putMlSyntheticDataParameters(value: CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParameters): void;
    resetMlSyntheticDataParameters(): void;
    get mlSyntheticDataParametersInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSyntheticDataParametersMlSyntheticDataParameters | undefined;
}
export interface CleanroomsAnalysisTemplateTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#key CleanroomsAnalysisTemplate#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#value CleanroomsAnalysisTemplate#value}
    */
    readonly value?: string;
}
export declare function cleanroomsAnalysisTemplateTagsToTerraform(struct?: CleanroomsAnalysisTemplateTags | cdktn.IResolvable): any;
export declare function cleanroomsAnalysisTemplateTagsToHclTerraform(struct?: CleanroomsAnalysisTemplateTags | cdktn.IResolvable): any;
export declare class CleanroomsAnalysisTemplateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsAnalysisTemplateTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsAnalysisTemplateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsAnalysisTemplateTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsAnalysisTemplateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsAnalysisTemplateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template awscc_cleanrooms_analysis_template}
*/
export declare class CleanroomsAnalysisTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanrooms_analysis_template";
    /**
    * Generates CDKTN code for importing a CleanroomsAnalysisTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsAnalysisTemplate to import
    * @param importFromId The id of the existing CleanroomsAnalysisTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsAnalysisTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_analysis_template awscc_cleanrooms_analysis_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsAnalysisTemplateConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsAnalysisTemplateConfig);
    private _analysisParameters;
    get analysisParameters(): CleanroomsAnalysisTemplateAnalysisParametersList;
    putAnalysisParameters(value: CleanroomsAnalysisTemplateAnalysisParameters[] | cdktn.IResolvable): void;
    resetAnalysisParameters(): void;
    get analysisParametersInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateAnalysisParameters[] | undefined;
    get analysisTemplateIdentifier(): string;
    get arn(): string;
    get collaborationArn(): string;
    get collaborationIdentifier(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _errorMessageConfiguration;
    get errorMessageConfiguration(): CleanroomsAnalysisTemplateErrorMessageConfigurationOutputReference;
    putErrorMessageConfiguration(value: CleanroomsAnalysisTemplateErrorMessageConfiguration): void;
    resetErrorMessageConfiguration(): void;
    get errorMessageConfigurationInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateErrorMessageConfiguration | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    get id(): string;
    get membershipArn(): string;
    private _membershipIdentifier?;
    get membershipIdentifier(): string;
    set membershipIdentifier(value: string);
    get membershipIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema;
    get schema(): CleanroomsAnalysisTemplateSchemaOutputReference;
    putSchema(value: CleanroomsAnalysisTemplateSchema): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSchema | undefined;
    private _source;
    get source(): CleanroomsAnalysisTemplateSourceOutputReference;
    putSource(value: CleanroomsAnalysisTemplateSource): void;
    get sourceInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSource | undefined;
    private _sourceMetadata;
    get sourceMetadata(): CleanroomsAnalysisTemplateSourceMetadataOutputReference;
    putSourceMetadata(value: CleanroomsAnalysisTemplateSourceMetadata): void;
    resetSourceMetadata(): void;
    get sourceMetadataInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSourceMetadata | undefined;
    private _syntheticDataParameters;
    get syntheticDataParameters(): CleanroomsAnalysisTemplateSyntheticDataParametersOutputReference;
    putSyntheticDataParameters(value: CleanroomsAnalysisTemplateSyntheticDataParameters): void;
    resetSyntheticDataParameters(): void;
    get syntheticDataParametersInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateSyntheticDataParameters | undefined;
    private _tags;
    get tags(): CleanroomsAnalysisTemplateTagsList;
    putTags(value: CleanroomsAnalysisTemplateTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsAnalysisTemplateTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
