/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupLegalHoldConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the legal hold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#description BackupLegalHold#description}
    */
    readonly description: string;
    /**
    * The criteria to assign a set of resources, such as resource types or backup vaults.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#recovery_point_selection BackupLegalHold#recovery_point_selection}
    */
    readonly recoveryPointSelection: BackupLegalHoldRecoveryPointSelection;
    /**
    * Optional tags to include.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#tags BackupLegalHold#tags}
    */
    readonly tags?: BackupLegalHoldTags[] | cdktn.IResolvable;
    /**
    * The title of the legal hold.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#title BackupLegalHold#title}
    */
    readonly title: string;
}
export interface BackupLegalHoldRecoveryPointSelectionDateRange {
    /**
    * The beginning date, inclusive. ISO 8601 date-time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#from_date BackupLegalHold#from_date}
    */
    readonly fromDate?: string;
    /**
    * The end date, inclusive. ISO 8601 date-time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#to_date BackupLegalHold#to_date}
    */
    readonly toDate?: string;
}
export declare function backupLegalHoldRecoveryPointSelectionDateRangeToTerraform(struct?: BackupLegalHoldRecoveryPointSelectionDateRange | cdktn.IResolvable): any;
export declare function backupLegalHoldRecoveryPointSelectionDateRangeToHclTerraform(struct?: BackupLegalHoldRecoveryPointSelectionDateRange | cdktn.IResolvable): any;
export declare class BackupLegalHoldRecoveryPointSelectionDateRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupLegalHoldRecoveryPointSelectionDateRange | cdktn.IResolvable | undefined;
    set internalValue(value: BackupLegalHoldRecoveryPointSelectionDateRange | cdktn.IResolvable | undefined);
    private _fromDate?;
    get fromDate(): string;
    set fromDate(value: string);
    resetFromDate(): void;
    get fromDateInput(): string | undefined;
    private _toDate?;
    get toDate(): string;
    set toDate(value: string);
    resetToDate(): void;
    get toDateInput(): string | undefined;
}
export interface BackupLegalHoldRecoveryPointSelection {
    /**
    * A date range for filtering recovery points.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#date_range BackupLegalHold#date_range}
    */
    readonly dateRange?: BackupLegalHoldRecoveryPointSelectionDateRange;
    /**
    * The resources included in the resource selection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#resource_identifiers BackupLegalHold#resource_identifiers}
    */
    readonly resourceIdentifiers?: string[];
    /**
    * The names of the vaults in which the selected recovery points are contained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#vault_names BackupLegalHold#vault_names}
    */
    readonly vaultNames?: string[];
}
export declare function backupLegalHoldRecoveryPointSelectionToTerraform(struct?: BackupLegalHoldRecoveryPointSelection | cdktn.IResolvable): any;
export declare function backupLegalHoldRecoveryPointSelectionToHclTerraform(struct?: BackupLegalHoldRecoveryPointSelection | cdktn.IResolvable): any;
export declare class BackupLegalHoldRecoveryPointSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupLegalHoldRecoveryPointSelection | cdktn.IResolvable | undefined;
    set internalValue(value: BackupLegalHoldRecoveryPointSelection | cdktn.IResolvable | undefined);
    private _dateRange;
    get dateRange(): BackupLegalHoldRecoveryPointSelectionDateRangeOutputReference;
    putDateRange(value: BackupLegalHoldRecoveryPointSelectionDateRange): void;
    resetDateRange(): void;
    get dateRangeInput(): cdktn.IResolvable | BackupLegalHoldRecoveryPointSelectionDateRange | undefined;
    private _resourceIdentifiers?;
    get resourceIdentifiers(): string[];
    set resourceIdentifiers(value: string[]);
    resetResourceIdentifiers(): void;
    get resourceIdentifiersInput(): string[] | undefined;
    private _vaultNames?;
    get vaultNames(): string[];
    set vaultNames(value: string[]);
    resetVaultNames(): void;
    get vaultNamesInput(): string[] | undefined;
}
export interface BackupLegalHoldTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#key BackupLegalHold#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#value BackupLegalHold#value}
    */
    readonly value?: string;
}
export declare function backupLegalHoldTagsToTerraform(struct?: BackupLegalHoldTags | cdktn.IResolvable): any;
export declare function backupLegalHoldTagsToHclTerraform(struct?: BackupLegalHoldTags | cdktn.IResolvable): any;
export declare class BackupLegalHoldTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupLegalHoldTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupLegalHoldTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupLegalHoldTagsList extends cdktn.ComplexList {
    internalValue?: BackupLegalHoldTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupLegalHoldTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold awscc_backup_legal_hold}
*/
export declare class BackupLegalHold extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_legal_hold";
    /**
    * Generates CDKTN code for importing a BackupLegalHold resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupLegalHold to import
    * @param importFromId The id of the existing BackupLegalHold that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupLegalHold to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_legal_hold awscc_backup_legal_hold} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupLegalHoldConfig
    */
    constructor(scope: Construct, id: string, config: BackupLegalHoldConfig);
    get arn(): string;
    get creationDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    get legalHoldId(): string;
    private _recoveryPointSelection;
    get recoveryPointSelection(): BackupLegalHoldRecoveryPointSelectionOutputReference;
    putRecoveryPointSelection(value: BackupLegalHoldRecoveryPointSelection): void;
    get recoveryPointSelectionInput(): cdktn.IResolvable | BackupLegalHoldRecoveryPointSelection | undefined;
    get status(): string;
    private _tags;
    get tags(): BackupLegalHoldTagsList;
    putTags(value: BackupLegalHoldTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BackupLegalHoldTags[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
