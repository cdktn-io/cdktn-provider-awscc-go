/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodedeployDeploymentConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The destination platform type for the deployment (Lambda, Server, or ECS).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#compute_platform CodedeployDeploymentConfig#compute_platform}
    */
    readonly computePlatform?: string;
    /**
    * A name for the deployment configuration. If you don't specify a name, AWS CloudFormation generates a unique physical ID and uses that ID for the deployment configuration name. For more information, see Name Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#deployment_config_name CodedeployDeploymentConfig#deployment_config_name}
    */
    readonly deploymentConfigName?: string;
    /**
    * The minimum number of healthy instances that should be available at any time during the deployment. There are two parameters expected in the input: type and value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#minimum_healthy_hosts CodedeployDeploymentConfig#minimum_healthy_hosts}
    */
    readonly minimumHealthyHosts?: CodedeployDeploymentConfigMinimumHealthyHosts;
    /**
    * The configuration that specifies how the deployment traffic is routed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#traffic_routing_config CodedeployDeploymentConfig#traffic_routing_config}
    */
    readonly trafficRoutingConfig?: CodedeployDeploymentConfigTrafficRoutingConfig;
    /**
    * The zonal deployment config that specifies how the zonal deployment behaves
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#zonal_config CodedeployDeploymentConfig#zonal_config}
    */
    readonly zonalConfig?: CodedeployDeploymentConfigZonalConfig;
}
export interface CodedeployDeploymentConfigMinimumHealthyHosts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#type CodedeployDeploymentConfig#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#value CodedeployDeploymentConfig#value}
    */
    readonly value?: number;
}
export declare function codedeployDeploymentConfigMinimumHealthyHostsToTerraform(struct?: CodedeployDeploymentConfigMinimumHealthyHosts | cdktn.IResolvable): any;
export declare function codedeployDeploymentConfigMinimumHealthyHostsToHclTerraform(struct?: CodedeployDeploymentConfigMinimumHealthyHosts | cdktn.IResolvable): any;
export declare class CodedeployDeploymentConfigMinimumHealthyHostsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentConfigMinimumHealthyHosts | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentConfigMinimumHealthyHosts | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#canary_interval CodedeployDeploymentConfig#canary_interval}
    */
    readonly canaryInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#canary_percentage CodedeployDeploymentConfig#canary_percentage}
    */
    readonly canaryPercentage?: number;
}
export declare function codedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanaryToTerraform(struct?: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanary | cdktn.IResolvable): any;
export declare function codedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanaryToHclTerraform(struct?: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanary | cdktn.IResolvable): any;
export declare class CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanary | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanary | cdktn.IResolvable | undefined);
    private _canaryInterval?;
    get canaryInterval(): number;
    set canaryInterval(value: number);
    resetCanaryInterval(): void;
    get canaryIntervalInput(): number | undefined;
    private _canaryPercentage?;
    get canaryPercentage(): number;
    set canaryPercentage(value: number);
    resetCanaryPercentage(): void;
    get canaryPercentageInput(): number | undefined;
}
export interface CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinear {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#linear_interval CodedeployDeploymentConfig#linear_interval}
    */
    readonly linearInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#linear_percentage CodedeployDeploymentConfig#linear_percentage}
    */
    readonly linearPercentage?: number;
}
export declare function codedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinearToTerraform(struct?: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinear | cdktn.IResolvable): any;
export declare function codedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinearToHclTerraform(struct?: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinear | cdktn.IResolvable): any;
export declare class CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinearOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinear | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinear | cdktn.IResolvable | undefined);
    private _linearInterval?;
    get linearInterval(): number;
    set linearInterval(value: number);
    resetLinearInterval(): void;
    get linearIntervalInput(): number | undefined;
    private _linearPercentage?;
    get linearPercentage(): number;
    set linearPercentage(value: number);
    resetLinearPercentage(): void;
    get linearPercentageInput(): number | undefined;
}
export interface CodedeployDeploymentConfigTrafficRoutingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#time_based_canary CodedeployDeploymentConfig#time_based_canary}
    */
    readonly timeBasedCanary?: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanary;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#time_based_linear CodedeployDeploymentConfig#time_based_linear}
    */
    readonly timeBasedLinear?: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinear;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#type CodedeployDeploymentConfig#type}
    */
    readonly type?: string;
}
export declare function codedeployDeploymentConfigTrafficRoutingConfigToTerraform(struct?: CodedeployDeploymentConfigTrafficRoutingConfig | cdktn.IResolvable): any;
export declare function codedeployDeploymentConfigTrafficRoutingConfigToHclTerraform(struct?: CodedeployDeploymentConfigTrafficRoutingConfig | cdktn.IResolvable): any;
export declare class CodedeployDeploymentConfigTrafficRoutingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentConfigTrafficRoutingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentConfigTrafficRoutingConfig | cdktn.IResolvable | undefined);
    private _timeBasedCanary;
    get timeBasedCanary(): CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanaryOutputReference;
    putTimeBasedCanary(value: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanary): void;
    resetTimeBasedCanary(): void;
    get timeBasedCanaryInput(): cdktn.IResolvable | CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedCanary | undefined;
    private _timeBasedLinear;
    get timeBasedLinear(): CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinearOutputReference;
    putTimeBasedLinear(value: CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinear): void;
    resetTimeBasedLinear(): void;
    get timeBasedLinearInput(): cdktn.IResolvable | CodedeployDeploymentConfigTrafficRoutingConfigTimeBasedLinear | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZone {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#type CodedeployDeploymentConfig#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#value CodedeployDeploymentConfig#value}
    */
    readonly value?: number;
}
export declare function codedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZoneToTerraform(struct?: CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZone | cdktn.IResolvable): any;
export declare function codedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZoneToHclTerraform(struct?: CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZone | cdktn.IResolvable): any;
export declare class CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZone | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZone | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface CodedeployDeploymentConfigZonalConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#first_zone_monitor_duration_in_seconds CodedeployDeploymentConfig#first_zone_monitor_duration_in_seconds}
    */
    readonly firstZoneMonitorDurationInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#minimum_healthy_hosts_per_zone CodedeployDeploymentConfig#minimum_healthy_hosts_per_zone}
    */
    readonly minimumHealthyHostsPerZone?: CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZone;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#monitor_duration_in_seconds CodedeployDeploymentConfig#monitor_duration_in_seconds}
    */
    readonly monitorDurationInSeconds?: number;
}
export declare function codedeployDeploymentConfigZonalConfigToTerraform(struct?: CodedeployDeploymentConfigZonalConfig | cdktn.IResolvable): any;
export declare function codedeployDeploymentConfigZonalConfigToHclTerraform(struct?: CodedeployDeploymentConfigZonalConfig | cdktn.IResolvable): any;
export declare class CodedeployDeploymentConfigZonalConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodedeployDeploymentConfigZonalConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CodedeployDeploymentConfigZonalConfig | cdktn.IResolvable | undefined);
    private _firstZoneMonitorDurationInSeconds?;
    get firstZoneMonitorDurationInSeconds(): number;
    set firstZoneMonitorDurationInSeconds(value: number);
    resetFirstZoneMonitorDurationInSeconds(): void;
    get firstZoneMonitorDurationInSecondsInput(): number | undefined;
    private _minimumHealthyHostsPerZone;
    get minimumHealthyHostsPerZone(): CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZoneOutputReference;
    putMinimumHealthyHostsPerZone(value: CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZone): void;
    resetMinimumHealthyHostsPerZone(): void;
    get minimumHealthyHostsPerZoneInput(): cdktn.IResolvable | CodedeployDeploymentConfigZonalConfigMinimumHealthyHostsPerZone | undefined;
    private _monitorDurationInSeconds?;
    get monitorDurationInSeconds(): number;
    set monitorDurationInSeconds(value: number);
    resetMonitorDurationInSeconds(): void;
    get monitorDurationInSecondsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config awscc_codedeploy_deployment_config}
*/
export declare class CodedeployDeploymentConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codedeploy_deployment_config";
    /**
    * Generates CDKTN code for importing a CodedeployDeploymentConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodedeployDeploymentConfig to import
    * @param importFromId The id of the existing CodedeployDeploymentConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodedeployDeploymentConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codedeploy_deployment_config awscc_codedeploy_deployment_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodedeployDeploymentConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CodedeployDeploymentConfigConfig);
    private _computePlatform?;
    get computePlatform(): string;
    set computePlatform(value: string);
    resetComputePlatform(): void;
    get computePlatformInput(): string | undefined;
    private _deploymentConfigName?;
    get deploymentConfigName(): string;
    set deploymentConfigName(value: string);
    resetDeploymentConfigName(): void;
    get deploymentConfigNameInput(): string | undefined;
    get id(): string;
    private _minimumHealthyHosts;
    get minimumHealthyHosts(): CodedeployDeploymentConfigMinimumHealthyHostsOutputReference;
    putMinimumHealthyHosts(value: CodedeployDeploymentConfigMinimumHealthyHosts): void;
    resetMinimumHealthyHosts(): void;
    get minimumHealthyHostsInput(): cdktn.IResolvable | CodedeployDeploymentConfigMinimumHealthyHosts | undefined;
    private _trafficRoutingConfig;
    get trafficRoutingConfig(): CodedeployDeploymentConfigTrafficRoutingConfigOutputReference;
    putTrafficRoutingConfig(value: CodedeployDeploymentConfigTrafficRoutingConfig): void;
    resetTrafficRoutingConfig(): void;
    get trafficRoutingConfigInput(): cdktn.IResolvable | CodedeployDeploymentConfigTrafficRoutingConfig | undefined;
    private _zonalConfig;
    get zonalConfig(): CodedeployDeploymentConfigZonalConfigOutputReference;
    putZonalConfig(value: CodedeployDeploymentConfigZonalConfig): void;
    resetZonalConfig(): void;
    get zonalConfigInput(): cdktn.IResolvable | CodedeployDeploymentConfigZonalConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
