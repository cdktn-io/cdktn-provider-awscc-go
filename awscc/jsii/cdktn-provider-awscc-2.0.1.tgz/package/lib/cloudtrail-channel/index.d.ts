/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudtrailChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * One or more resources to which events arriving through a channel are logged and stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#destinations CloudtrailChannel#destinations}
    */
    readonly destinations?: CloudtrailChannelDestinations[] | cdktn.IResolvable;
    /**
    * The name of the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#name CloudtrailChannel#name}
    */
    readonly name?: string;
    /**
    * The ARN of an on-premises storage solution or application, or a partner event source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#source CloudtrailChannel#source}
    */
    readonly source?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#tags CloudtrailChannel#tags}
    */
    readonly tags?: CloudtrailChannelTags[] | cdktn.IResolvable;
}
export interface CloudtrailChannelDestinations {
    /**
    * The ARN of a resource that receives events from a channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#location CloudtrailChannel#location}
    */
    readonly location?: string;
    /**
    * The type of destination for events arriving from a channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#type CloudtrailChannel#type}
    */
    readonly type?: string;
}
export declare function cloudtrailChannelDestinationsToTerraform(struct?: CloudtrailChannelDestinations | cdktn.IResolvable): any;
export declare function cloudtrailChannelDestinationsToHclTerraform(struct?: CloudtrailChannelDestinations | cdktn.IResolvable): any;
export declare class CloudtrailChannelDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailChannelDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailChannelDestinations | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CloudtrailChannelDestinationsList extends cdktn.ComplexList {
    internalValue?: CloudtrailChannelDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailChannelDestinationsOutputReference;
}
export interface CloudtrailChannelTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#key CloudtrailChannel#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#value CloudtrailChannel#value}
    */
    readonly value?: string;
}
export declare function cloudtrailChannelTagsToTerraform(struct?: CloudtrailChannelTags | cdktn.IResolvable): any;
export declare function cloudtrailChannelTagsToHclTerraform(struct?: CloudtrailChannelTags | cdktn.IResolvable): any;
export declare class CloudtrailChannelTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudtrailChannelTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudtrailChannelTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudtrailChannelTagsList extends cdktn.ComplexList {
    internalValue?: CloudtrailChannelTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudtrailChannelTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel awscc_cloudtrail_channel}
*/
export declare class CloudtrailChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudtrail_channel";
    /**
    * Generates CDKTN code for importing a CloudtrailChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudtrailChannel to import
    * @param importFromId The id of the existing CloudtrailChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudtrailChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudtrail_channel awscc_cloudtrail_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudtrailChannelConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudtrailChannelConfig);
    get channelArn(): string;
    private _destinations;
    get destinations(): CloudtrailChannelDestinationsList;
    putDestinations(value: CloudtrailChannelDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | CloudtrailChannelDestinations[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _tags;
    get tags(): CloudtrailChannelTagsList;
    putTags(value: CloudtrailChannelTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudtrailChannelTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
