/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuditmanagerAssessmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The destination in which evidence reports are stored for the specified assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#assessment_reports_destination AuditmanagerAssessment#assessment_reports_destination}
    */
    readonly assessmentReportsDestination?: AuditmanagerAssessmentAssessmentReportsDestination;
    /**
    * The AWS account associated with the assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#aws_account AuditmanagerAssessment#aws_account}
    */
    readonly awsAccount?: AuditmanagerAssessmentAwsAccount;
    /**
    * The list of delegations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#delegations AuditmanagerAssessment#delegations}
    */
    readonly delegations?: AuditmanagerAssessmentDelegations[] | cdktn.IResolvable;
    /**
    * The description of the specified assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#description AuditmanagerAssessment#description}
    */
    readonly description?: string;
    /**
    * The identifier for the specified framework.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#framework_id AuditmanagerAssessment#framework_id}
    */
    readonly frameworkId?: string;
    /**
    * The name of the related assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#name AuditmanagerAssessment#name}
    */
    readonly name?: string;
    /**
    * The list of roles for the specified assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#roles AuditmanagerAssessment#roles}
    */
    readonly roles?: AuditmanagerAssessmentRoles[] | cdktn.IResolvable;
    /**
    * The wrapper that contains the AWS accounts and AWS services in scope for the assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#scope AuditmanagerAssessment#scope}
    */
    readonly scope?: AuditmanagerAssessmentScope;
    /**
    * The status of the specified assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#status AuditmanagerAssessment#status}
    */
    readonly status?: string;
    /**
    * The tags associated with the assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#tags AuditmanagerAssessment#tags}
    */
    readonly tags?: AuditmanagerAssessmentTags[] | cdktn.IResolvable;
}
export interface AuditmanagerAssessmentAssessmentReportsDestination {
    /**
    * The URL of the specified Amazon S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#destination AuditmanagerAssessment#destination}
    */
    readonly destination?: string;
    /**
    * The destination type, such as Amazon S3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#destination_type AuditmanagerAssessment#destination_type}
    */
    readonly destinationType?: string;
}
export declare function auditmanagerAssessmentAssessmentReportsDestinationToTerraform(struct?: AuditmanagerAssessmentAssessmentReportsDestination | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentAssessmentReportsDestinationToHclTerraform(struct?: AuditmanagerAssessmentAssessmentReportsDestination | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentAssessmentReportsDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuditmanagerAssessmentAssessmentReportsDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentAssessmentReportsDestination | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    resetDestinationType(): void;
    get destinationTypeInput(): string | undefined;
}
export interface AuditmanagerAssessmentAwsAccount {
    /**
    * The unique identifier for the email account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#email_address AuditmanagerAssessment#email_address}
    */
    readonly emailAddress?: string;
    /**
    * The identifier for the specified AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#id AuditmanagerAssessment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the specified AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#name AuditmanagerAssessment#name}
    */
    readonly name?: string;
}
export declare function auditmanagerAssessmentAwsAccountToTerraform(struct?: AuditmanagerAssessmentAwsAccount | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentAwsAccountToHclTerraform(struct?: AuditmanagerAssessmentAwsAccount | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentAwsAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuditmanagerAssessmentAwsAccount | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentAwsAccount | cdktn.IResolvable | undefined);
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    resetEmailAddress(): void;
    get emailAddressInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface AuditmanagerAssessmentDelegations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#assessment_id AuditmanagerAssessment#assessment_id}
    */
    readonly assessmentId?: string;
    /**
    * The name of the related assessment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#assessment_name AuditmanagerAssessment#assessment_name}
    */
    readonly assessmentName?: string;
    /**
    * The comment related to the delegation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#comment AuditmanagerAssessment#comment}
    */
    readonly comment?: string;
    /**
    * The identifier for the specified control set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#control_set_id AuditmanagerAssessment#control_set_id}
    */
    readonly controlSetId?: string;
    /**
    * The IAM user or role that performed the action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#created_by AuditmanagerAssessment#created_by}
    */
    readonly createdBy?: string;
    /**
    * The sequence of characters that identifies when the event occurred.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#creation_time AuditmanagerAssessment#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#id AuditmanagerAssessment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The sequence of characters that identifies when the event occurred.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#last_updated AuditmanagerAssessment#last_updated}
    */
    readonly lastUpdated?: number;
    /**
    * The Amazon Resource Name (ARN) of the IAM user or role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#role_arn AuditmanagerAssessment#role_arn}
    */
    readonly roleArn?: string;
    /**
    *  The IAM role type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#role_type AuditmanagerAssessment#role_type}
    */
    readonly roleType?: string;
    /**
    * The status of the delegation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#status AuditmanagerAssessment#status}
    */
    readonly status?: string;
}
export declare function auditmanagerAssessmentDelegationsToTerraform(struct?: AuditmanagerAssessmentDelegations | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentDelegationsToHclTerraform(struct?: AuditmanagerAssessmentDelegations | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentDelegationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuditmanagerAssessmentDelegations | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentDelegations | cdktn.IResolvable | undefined);
    private _assessmentId?;
    get assessmentId(): string;
    set assessmentId(value: string);
    resetAssessmentId(): void;
    get assessmentIdInput(): string | undefined;
    private _assessmentName?;
    get assessmentName(): string;
    set assessmentName(value: string);
    resetAssessmentName(): void;
    get assessmentNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _controlSetId?;
    get controlSetId(): string;
    set controlSetId(value: string);
    resetControlSetId(): void;
    get controlSetIdInput(): string | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastUpdated?;
    get lastUpdated(): number;
    set lastUpdated(value: number);
    resetLastUpdated(): void;
    get lastUpdatedInput(): number | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _roleType?;
    get roleType(): string;
    set roleType(value: string);
    resetRoleType(): void;
    get roleTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export declare class AuditmanagerAssessmentDelegationsList extends cdktn.ComplexList {
    internalValue?: AuditmanagerAssessmentDelegations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuditmanagerAssessmentDelegationsOutputReference;
}
export interface AuditmanagerAssessmentRoles {
    /**
    * The Amazon Resource Name (ARN) of the IAM user or role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#role_arn AuditmanagerAssessment#role_arn}
    */
    readonly roleArn?: string;
    /**
    *  The IAM role type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#role_type AuditmanagerAssessment#role_type}
    */
    readonly roleType?: string;
}
export declare function auditmanagerAssessmentRolesToTerraform(struct?: AuditmanagerAssessmentRoles | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentRolesToHclTerraform(struct?: AuditmanagerAssessmentRoles | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuditmanagerAssessmentRoles | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentRoles | cdktn.IResolvable | undefined);
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _roleType?;
    get roleType(): string;
    set roleType(value: string);
    resetRoleType(): void;
    get roleTypeInput(): string | undefined;
}
export declare class AuditmanagerAssessmentRolesList extends cdktn.ComplexList {
    internalValue?: AuditmanagerAssessmentRoles[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuditmanagerAssessmentRolesOutputReference;
}
export interface AuditmanagerAssessmentScopeAwsAccounts {
    /**
    * The unique identifier for the email account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#email_address AuditmanagerAssessment#email_address}
    */
    readonly emailAddress?: string;
    /**
    * The identifier for the specified AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#id AuditmanagerAssessment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the specified AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#name AuditmanagerAssessment#name}
    */
    readonly name?: string;
}
export declare function auditmanagerAssessmentScopeAwsAccountsToTerraform(struct?: AuditmanagerAssessmentScopeAwsAccounts | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentScopeAwsAccountsToHclTerraform(struct?: AuditmanagerAssessmentScopeAwsAccounts | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentScopeAwsAccountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuditmanagerAssessmentScopeAwsAccounts | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentScopeAwsAccounts | cdktn.IResolvable | undefined);
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    resetEmailAddress(): void;
    get emailAddressInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class AuditmanagerAssessmentScopeAwsAccountsList extends cdktn.ComplexList {
    internalValue?: AuditmanagerAssessmentScopeAwsAccounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuditmanagerAssessmentScopeAwsAccountsOutputReference;
}
export interface AuditmanagerAssessmentScopeAwsServices {
    /**
    * The name of the AWS service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#service_name AuditmanagerAssessment#service_name}
    */
    readonly serviceName?: string;
}
export declare function auditmanagerAssessmentScopeAwsServicesToTerraform(struct?: AuditmanagerAssessmentScopeAwsServices | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentScopeAwsServicesToHclTerraform(struct?: AuditmanagerAssessmentScopeAwsServices | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentScopeAwsServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuditmanagerAssessmentScopeAwsServices | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentScopeAwsServices | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
}
export declare class AuditmanagerAssessmentScopeAwsServicesList extends cdktn.ComplexList {
    internalValue?: AuditmanagerAssessmentScopeAwsServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuditmanagerAssessmentScopeAwsServicesOutputReference;
}
export interface AuditmanagerAssessmentScope {
    /**
    * The AWS accounts included in scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#aws_accounts AuditmanagerAssessment#aws_accounts}
    */
    readonly awsAccounts?: AuditmanagerAssessmentScopeAwsAccounts[] | cdktn.IResolvable;
    /**
    * The AWS services included in scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#aws_services AuditmanagerAssessment#aws_services}
    */
    readonly awsServices?: AuditmanagerAssessmentScopeAwsServices[] | cdktn.IResolvable;
}
export declare function auditmanagerAssessmentScopeToTerraform(struct?: AuditmanagerAssessmentScope | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentScopeToHclTerraform(struct?: AuditmanagerAssessmentScope | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuditmanagerAssessmentScope | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentScope | cdktn.IResolvable | undefined);
    private _awsAccounts;
    get awsAccounts(): AuditmanagerAssessmentScopeAwsAccountsList;
    putAwsAccounts(value: AuditmanagerAssessmentScopeAwsAccounts[] | cdktn.IResolvable): void;
    resetAwsAccounts(): void;
    get awsAccountsInput(): cdktn.IResolvable | AuditmanagerAssessmentScopeAwsAccounts[] | undefined;
    private _awsServices;
    get awsServices(): AuditmanagerAssessmentScopeAwsServicesList;
    putAwsServices(value: AuditmanagerAssessmentScopeAwsServices[] | cdktn.IResolvable): void;
    resetAwsServices(): void;
    get awsServicesInput(): cdktn.IResolvable | AuditmanagerAssessmentScopeAwsServices[] | undefined;
}
export interface AuditmanagerAssessmentTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#key AuditmanagerAssessment#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 255 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#value AuditmanagerAssessment#value}
    */
    readonly value?: string;
}
export declare function auditmanagerAssessmentTagsToTerraform(struct?: AuditmanagerAssessmentTags | cdktn.IResolvable): any;
export declare function auditmanagerAssessmentTagsToHclTerraform(struct?: AuditmanagerAssessmentTags | cdktn.IResolvable): any;
export declare class AuditmanagerAssessmentTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuditmanagerAssessmentTags | cdktn.IResolvable | undefined;
    set internalValue(value: AuditmanagerAssessmentTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AuditmanagerAssessmentTagsList extends cdktn.ComplexList {
    internalValue?: AuditmanagerAssessmentTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuditmanagerAssessmentTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment awscc_auditmanager_assessment}
*/
export declare class AuditmanagerAssessment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_auditmanager_assessment";
    /**
    * Generates CDKTN code for importing a AuditmanagerAssessment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuditmanagerAssessment to import
    * @param importFromId The id of the existing AuditmanagerAssessment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuditmanagerAssessment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/auditmanager_assessment awscc_auditmanager_assessment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuditmanagerAssessmentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AuditmanagerAssessmentConfig);
    get arn(): string;
    get assessmentId(): string;
    private _assessmentReportsDestination;
    get assessmentReportsDestination(): AuditmanagerAssessmentAssessmentReportsDestinationOutputReference;
    putAssessmentReportsDestination(value: AuditmanagerAssessmentAssessmentReportsDestination): void;
    resetAssessmentReportsDestination(): void;
    get assessmentReportsDestinationInput(): cdktn.IResolvable | AuditmanagerAssessmentAssessmentReportsDestination | undefined;
    private _awsAccount;
    get awsAccount(): AuditmanagerAssessmentAwsAccountOutputReference;
    putAwsAccount(value: AuditmanagerAssessmentAwsAccount): void;
    resetAwsAccount(): void;
    get awsAccountInput(): cdktn.IResolvable | AuditmanagerAssessmentAwsAccount | undefined;
    get creationTime(): number;
    private _delegations;
    get delegations(): AuditmanagerAssessmentDelegationsList;
    putDelegations(value: AuditmanagerAssessmentDelegations[] | cdktn.IResolvable): void;
    resetDelegations(): void;
    get delegationsInput(): cdktn.IResolvable | AuditmanagerAssessmentDelegations[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _frameworkId?;
    get frameworkId(): string;
    set frameworkId(value: string);
    resetFrameworkId(): void;
    get frameworkIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _roles;
    get roles(): AuditmanagerAssessmentRolesList;
    putRoles(value: AuditmanagerAssessmentRoles[] | cdktn.IResolvable): void;
    resetRoles(): void;
    get rolesInput(): cdktn.IResolvable | AuditmanagerAssessmentRoles[] | undefined;
    private _scope;
    get scope(): AuditmanagerAssessmentScopeOutputReference;
    putScope(value: AuditmanagerAssessmentScope): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | AuditmanagerAssessmentScope | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags;
    get tags(): AuditmanagerAssessmentTagsList;
    putTags(value: AuditmanagerAssessmentTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AuditmanagerAssessmentTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
