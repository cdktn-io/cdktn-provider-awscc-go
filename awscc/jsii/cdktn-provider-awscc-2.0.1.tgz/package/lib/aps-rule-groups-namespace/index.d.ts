/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApsRuleGroupsNamespaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The RuleGroupsNamespace data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace#data ApsRuleGroupsNamespace#data}
    */
    readonly data: string;
    /**
    * The RuleGroupsNamespace name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace#name ApsRuleGroupsNamespace#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace#tags ApsRuleGroupsNamespace#tags}
    */
    readonly tags?: ApsRuleGroupsNamespaceTags[] | cdktn.IResolvable;
    /**
    * Required to identify a specific APS Workspace associated with this RuleGroupsNamespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace#workspace ApsRuleGroupsNamespace#workspace}
    */
    readonly workspace: string;
}
export interface ApsRuleGroupsNamespaceTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace#key ApsRuleGroupsNamespace#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace#value ApsRuleGroupsNamespace#value}
    */
    readonly value?: string;
}
export declare function apsRuleGroupsNamespaceTagsToTerraform(struct?: ApsRuleGroupsNamespaceTags | cdktn.IResolvable): any;
export declare function apsRuleGroupsNamespaceTagsToHclTerraform(struct?: ApsRuleGroupsNamespaceTags | cdktn.IResolvable): any;
export declare class ApsRuleGroupsNamespaceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApsRuleGroupsNamespaceTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApsRuleGroupsNamespaceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApsRuleGroupsNamespaceTagsList extends cdktn.ComplexList {
    internalValue?: ApsRuleGroupsNamespaceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApsRuleGroupsNamespaceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace awscc_aps_rule_groups_namespace}
*/
export declare class ApsRuleGroupsNamespace extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_aps_rule_groups_namespace";
    /**
    * Generates CDKTN code for importing a ApsRuleGroupsNamespace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApsRuleGroupsNamespace to import
    * @param importFromId The id of the existing ApsRuleGroupsNamespace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApsRuleGroupsNamespace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/aps_rule_groups_namespace awscc_aps_rule_groups_namespace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApsRuleGroupsNamespaceConfig
    */
    constructor(scope: Construct, id: string, config: ApsRuleGroupsNamespaceConfig);
    get arn(): string;
    private _data?;
    get data(): string;
    set data(value: string);
    get dataInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): ApsRuleGroupsNamespaceTagsList;
    putTags(value: ApsRuleGroupsNamespaceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApsRuleGroupsNamespaceTags[] | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    get workspaceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
