/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoUserPoolClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#access_token_validity CognitoUserPoolClient#access_token_validity}
    */
    readonly accessTokenValidity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#allowed_o_auth_flows CognitoUserPoolClient#allowed_o_auth_flows}
    */
    readonly allowedOAuthFlows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#allowed_o_auth_flows_user_pool_client CognitoUserPoolClient#allowed_o_auth_flows_user_pool_client}
    */
    readonly allowedOAuthFlowsUserPoolClient?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#allowed_o_auth_scopes CognitoUserPoolClient#allowed_o_auth_scopes}
    */
    readonly allowedOAuthScopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#analytics_configuration CognitoUserPoolClient#analytics_configuration}
    */
    readonly analyticsConfiguration?: CognitoUserPoolClientAnalyticsConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#auth_session_validity CognitoUserPoolClient#auth_session_validity}
    */
    readonly authSessionValidity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#callback_ur_ls CognitoUserPoolClient#callback_ur_ls}
    */
    readonly callbackUrLs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#client_name CognitoUserPoolClient#client_name}
    */
    readonly clientName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#default_redirect_uri CognitoUserPoolClient#default_redirect_uri}
    */
    readonly defaultRedirectUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#enable_propagate_additional_user_context_data CognitoUserPoolClient#enable_propagate_additional_user_context_data}
    */
    readonly enablePropagateAdditionalUserContextData?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#enable_token_revocation CognitoUserPoolClient#enable_token_revocation}
    */
    readonly enableTokenRevocation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#explicit_auth_flows CognitoUserPoolClient#explicit_auth_flows}
    */
    readonly explicitAuthFlows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#generate_secret CognitoUserPoolClient#generate_secret}
    */
    readonly generateSecret?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#id_token_validity CognitoUserPoolClient#id_token_validity}
    */
    readonly idTokenValidity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#logout_ur_ls CognitoUserPoolClient#logout_ur_ls}
    */
    readonly logoutUrLs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#prevent_user_existence_errors CognitoUserPoolClient#prevent_user_existence_errors}
    */
    readonly preventUserExistenceErrors?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#read_attributes CognitoUserPoolClient#read_attributes}
    */
    readonly readAttributes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#refresh_token_rotation CognitoUserPoolClient#refresh_token_rotation}
    */
    readonly refreshTokenRotation?: CognitoUserPoolClientRefreshTokenRotation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#refresh_token_validity CognitoUserPoolClient#refresh_token_validity}
    */
    readonly refreshTokenValidity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#supported_identity_providers CognitoUserPoolClient#supported_identity_providers}
    */
    readonly supportedIdentityProviders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#token_validity_units CognitoUserPoolClient#token_validity_units}
    */
    readonly tokenValidityUnits?: CognitoUserPoolClientTokenValidityUnits;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#user_pool_id CognitoUserPoolClient#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#write_attributes CognitoUserPoolClient#write_attributes}
    */
    readonly writeAttributes?: string[];
}
export interface CognitoUserPoolClientAnalyticsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#application_arn CognitoUserPoolClient#application_arn}
    */
    readonly applicationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#application_id CognitoUserPoolClient#application_id}
    */
    readonly applicationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#external_id CognitoUserPoolClient#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#role_arn CognitoUserPoolClient#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#user_data_shared CognitoUserPoolClient#user_data_shared}
    */
    readonly userDataShared?: boolean | cdktn.IResolvable;
}
export declare function cognitoUserPoolClientAnalyticsConfigurationToTerraform(struct?: CognitoUserPoolClientAnalyticsConfiguration | cdktn.IResolvable): any;
export declare function cognitoUserPoolClientAnalyticsConfigurationToHclTerraform(struct?: CognitoUserPoolClientAnalyticsConfiguration | cdktn.IResolvable): any;
export declare class CognitoUserPoolClientAnalyticsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolClientAnalyticsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolClientAnalyticsConfiguration | cdktn.IResolvable | undefined);
    private _applicationArn?;
    get applicationArn(): string;
    set applicationArn(value: string);
    resetApplicationArn(): void;
    get applicationArnInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    resetApplicationId(): void;
    get applicationIdInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _userDataShared?;
    get userDataShared(): boolean | cdktn.IResolvable;
    set userDataShared(value: boolean | cdktn.IResolvable);
    resetUserDataShared(): void;
    get userDataSharedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CognitoUserPoolClientRefreshTokenRotation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#feature CognitoUserPoolClient#feature}
    */
    readonly feature?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#retry_grace_period_seconds CognitoUserPoolClient#retry_grace_period_seconds}
    */
    readonly retryGracePeriodSeconds?: number;
}
export declare function cognitoUserPoolClientRefreshTokenRotationToTerraform(struct?: CognitoUserPoolClientRefreshTokenRotation | cdktn.IResolvable): any;
export declare function cognitoUserPoolClientRefreshTokenRotationToHclTerraform(struct?: CognitoUserPoolClientRefreshTokenRotation | cdktn.IResolvable): any;
export declare class CognitoUserPoolClientRefreshTokenRotationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolClientRefreshTokenRotation | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolClientRefreshTokenRotation | cdktn.IResolvable | undefined);
    private _feature?;
    get feature(): string;
    set feature(value: string);
    resetFeature(): void;
    get featureInput(): string | undefined;
    private _retryGracePeriodSeconds?;
    get retryGracePeriodSeconds(): number;
    set retryGracePeriodSeconds(value: number);
    resetRetryGracePeriodSeconds(): void;
    get retryGracePeriodSecondsInput(): number | undefined;
}
export interface CognitoUserPoolClientTokenValidityUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#access_token CognitoUserPoolClient#access_token}
    */
    readonly accessToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#id_token CognitoUserPoolClient#id_token}
    */
    readonly idToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#refresh_token CognitoUserPoolClient#refresh_token}
    */
    readonly refreshToken?: string;
}
export declare function cognitoUserPoolClientTokenValidityUnitsToTerraform(struct?: CognitoUserPoolClientTokenValidityUnits | cdktn.IResolvable): any;
export declare function cognitoUserPoolClientTokenValidityUnitsToHclTerraform(struct?: CognitoUserPoolClientTokenValidityUnits | cdktn.IResolvable): any;
export declare class CognitoUserPoolClientTokenValidityUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolClientTokenValidityUnits | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolClientTokenValidityUnits | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    private _idToken?;
    get idToken(): string;
    set idToken(value: string);
    resetIdToken(): void;
    get idTokenInput(): string | undefined;
    private _refreshToken?;
    get refreshToken(): string;
    set refreshToken(value: string);
    resetRefreshToken(): void;
    get refreshTokenInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client awscc_cognito_user_pool_client}
*/
export declare class CognitoUserPoolClient extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_user_pool_client";
    /**
    * Generates CDKTN code for importing a CognitoUserPoolClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoUserPoolClient to import
    * @param importFromId The id of the existing CognitoUserPoolClient that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoUserPoolClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_client awscc_cognito_user_pool_client} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoUserPoolClientConfig
    */
    constructor(scope: Construct, id: string, config: CognitoUserPoolClientConfig);
    private _accessTokenValidity?;
    get accessTokenValidity(): number;
    set accessTokenValidity(value: number);
    resetAccessTokenValidity(): void;
    get accessTokenValidityInput(): number | undefined;
    private _allowedOAuthFlows?;
    get allowedOAuthFlows(): string[];
    set allowedOAuthFlows(value: string[]);
    resetAllowedOAuthFlows(): void;
    get allowedOAuthFlowsInput(): string[] | undefined;
    private _allowedOAuthFlowsUserPoolClient?;
    get allowedOAuthFlowsUserPoolClient(): boolean | cdktn.IResolvable;
    set allowedOAuthFlowsUserPoolClient(value: boolean | cdktn.IResolvable);
    resetAllowedOAuthFlowsUserPoolClient(): void;
    get allowedOAuthFlowsUserPoolClientInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedOAuthScopes?;
    get allowedOAuthScopes(): string[];
    set allowedOAuthScopes(value: string[]);
    resetAllowedOAuthScopes(): void;
    get allowedOAuthScopesInput(): string[] | undefined;
    private _analyticsConfiguration;
    get analyticsConfiguration(): CognitoUserPoolClientAnalyticsConfigurationOutputReference;
    putAnalyticsConfiguration(value: CognitoUserPoolClientAnalyticsConfiguration): void;
    resetAnalyticsConfiguration(): void;
    get analyticsConfigurationInput(): cdktn.IResolvable | CognitoUserPoolClientAnalyticsConfiguration | undefined;
    private _authSessionValidity?;
    get authSessionValidity(): number;
    set authSessionValidity(value: number);
    resetAuthSessionValidity(): void;
    get authSessionValidityInput(): number | undefined;
    private _callbackUrLs?;
    get callbackUrLs(): string[];
    set callbackUrLs(value: string[]);
    resetCallbackUrLs(): void;
    get callbackUrLsInput(): string[] | undefined;
    get clientId(): string;
    private _clientName?;
    get clientName(): string;
    set clientName(value: string);
    resetClientName(): void;
    get clientNameInput(): string | undefined;
    get clientSecret(): string;
    private _defaultRedirectUri?;
    get defaultRedirectUri(): string;
    set defaultRedirectUri(value: string);
    resetDefaultRedirectUri(): void;
    get defaultRedirectUriInput(): string | undefined;
    private _enablePropagateAdditionalUserContextData?;
    get enablePropagateAdditionalUserContextData(): boolean | cdktn.IResolvable;
    set enablePropagateAdditionalUserContextData(value: boolean | cdktn.IResolvable);
    resetEnablePropagateAdditionalUserContextData(): void;
    get enablePropagateAdditionalUserContextDataInput(): boolean | cdktn.IResolvable | undefined;
    private _enableTokenRevocation?;
    get enableTokenRevocation(): boolean | cdktn.IResolvable;
    set enableTokenRevocation(value: boolean | cdktn.IResolvable);
    resetEnableTokenRevocation(): void;
    get enableTokenRevocationInput(): boolean | cdktn.IResolvable | undefined;
    private _explicitAuthFlows?;
    get explicitAuthFlows(): string[];
    set explicitAuthFlows(value: string[]);
    resetExplicitAuthFlows(): void;
    get explicitAuthFlowsInput(): string[] | undefined;
    private _generateSecret?;
    get generateSecret(): boolean | cdktn.IResolvable;
    set generateSecret(value: boolean | cdktn.IResolvable);
    resetGenerateSecret(): void;
    get generateSecretInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _idTokenValidity?;
    get idTokenValidity(): number;
    set idTokenValidity(value: number);
    resetIdTokenValidity(): void;
    get idTokenValidityInput(): number | undefined;
    private _logoutUrLs?;
    get logoutUrLs(): string[];
    set logoutUrLs(value: string[]);
    resetLogoutUrLs(): void;
    get logoutUrLsInput(): string[] | undefined;
    get name(): string;
    private _preventUserExistenceErrors?;
    get preventUserExistenceErrors(): string;
    set preventUserExistenceErrors(value: string);
    resetPreventUserExistenceErrors(): void;
    get preventUserExistenceErrorsInput(): string | undefined;
    private _readAttributes?;
    get readAttributes(): string[];
    set readAttributes(value: string[]);
    resetReadAttributes(): void;
    get readAttributesInput(): string[] | undefined;
    private _refreshTokenRotation;
    get refreshTokenRotation(): CognitoUserPoolClientRefreshTokenRotationOutputReference;
    putRefreshTokenRotation(value: CognitoUserPoolClientRefreshTokenRotation): void;
    resetRefreshTokenRotation(): void;
    get refreshTokenRotationInput(): cdktn.IResolvable | CognitoUserPoolClientRefreshTokenRotation | undefined;
    private _refreshTokenValidity?;
    get refreshTokenValidity(): number;
    set refreshTokenValidity(value: number);
    resetRefreshTokenValidity(): void;
    get refreshTokenValidityInput(): number | undefined;
    private _supportedIdentityProviders?;
    get supportedIdentityProviders(): string[];
    set supportedIdentityProviders(value: string[]);
    resetSupportedIdentityProviders(): void;
    get supportedIdentityProvidersInput(): string[] | undefined;
    private _tokenValidityUnits;
    get tokenValidityUnits(): CognitoUserPoolClientTokenValidityUnitsOutputReference;
    putTokenValidityUnits(value: CognitoUserPoolClientTokenValidityUnits): void;
    resetTokenValidityUnits(): void;
    get tokenValidityUnitsInput(): cdktn.IResolvable | CognitoUserPoolClientTokenValidityUnits | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _writeAttributes?;
    get writeAttributes(): string[];
    set writeAttributes(value: string[]);
    resetWriteAttributes(): void;
    get writeAttributesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
