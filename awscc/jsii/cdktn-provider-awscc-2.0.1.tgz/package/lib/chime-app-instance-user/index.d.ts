/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeAppInstanceUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#app_instance_arn ChimeAppInstanceUser#app_instance_arn}
    */
    readonly appInstanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#app_instance_user_id ChimeAppInstanceUser#app_instance_user_id}
    */
    readonly appInstanceUserId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#expiration_settings ChimeAppInstanceUser#expiration_settings}
    */
    readonly expirationSettings?: ChimeAppInstanceUserExpirationSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#metadata ChimeAppInstanceUser#metadata}
    */
    readonly metadata?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#name ChimeAppInstanceUser#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#tags ChimeAppInstanceUser#tags}
    */
    readonly tags?: ChimeAppInstanceUserTags[] | cdktn.IResolvable;
}
export interface ChimeAppInstanceUserExpirationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#expiration_criterion ChimeAppInstanceUser#expiration_criterion}
    */
    readonly expirationCriterion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#expiration_days ChimeAppInstanceUser#expiration_days}
    */
    readonly expirationDays?: number;
}
export declare function chimeAppInstanceUserExpirationSettingsToTerraform(struct?: ChimeAppInstanceUserExpirationSettings | cdktn.IResolvable): any;
export declare function chimeAppInstanceUserExpirationSettingsToHclTerraform(struct?: ChimeAppInstanceUserExpirationSettings | cdktn.IResolvable): any;
export declare class ChimeAppInstanceUserExpirationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeAppInstanceUserExpirationSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeAppInstanceUserExpirationSettings | cdktn.IResolvable | undefined);
    private _expirationCriterion?;
    get expirationCriterion(): string;
    set expirationCriterion(value: string);
    resetExpirationCriterion(): void;
    get expirationCriterionInput(): string | undefined;
    private _expirationDays?;
    get expirationDays(): number;
    set expirationDays(value: number);
    resetExpirationDays(): void;
    get expirationDaysInput(): number | undefined;
}
export interface ChimeAppInstanceUserTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#key ChimeAppInstanceUser#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#value ChimeAppInstanceUser#value}
    */
    readonly value?: string;
}
export declare function chimeAppInstanceUserTagsToTerraform(struct?: ChimeAppInstanceUserTags | cdktn.IResolvable): any;
export declare function chimeAppInstanceUserTagsToHclTerraform(struct?: ChimeAppInstanceUserTags | cdktn.IResolvable): any;
export declare class ChimeAppInstanceUserTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeAppInstanceUserTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeAppInstanceUserTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeAppInstanceUserTagsList extends cdktn.ComplexList {
    internalValue?: ChimeAppInstanceUserTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeAppInstanceUserTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user awscc_chime_app_instance_user}
*/
export declare class ChimeAppInstanceUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_app_instance_user";
    /**
    * Generates CDKTN code for importing a ChimeAppInstanceUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeAppInstanceUser to import
    * @param importFromId The id of the existing ChimeAppInstanceUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeAppInstanceUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_app_instance_user awscc_chime_app_instance_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeAppInstanceUserConfig
    */
    constructor(scope: Construct, id: string, config: ChimeAppInstanceUserConfig);
    private _appInstanceArn?;
    get appInstanceArn(): string;
    set appInstanceArn(value: string);
    get appInstanceArnInput(): string | undefined;
    get appInstanceUserArn(): string;
    private _appInstanceUserId?;
    get appInstanceUserId(): string;
    set appInstanceUserId(value: string);
    get appInstanceUserIdInput(): string | undefined;
    private _expirationSettings;
    get expirationSettings(): ChimeAppInstanceUserExpirationSettingsOutputReference;
    putExpirationSettings(value: ChimeAppInstanceUserExpirationSettings): void;
    resetExpirationSettings(): void;
    get expirationSettingsInput(): cdktn.IResolvable | ChimeAppInstanceUserExpirationSettings | undefined;
    get id(): string;
    private _metadata?;
    get metadata(): string;
    set metadata(value: string);
    resetMetadata(): void;
    get metadataInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _tags;
    get tags(): ChimeAppInstanceUserTagsList;
    putTags(value: ChimeAppInstanceUserTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeAppInstanceUserTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
