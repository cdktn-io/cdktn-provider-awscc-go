/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontDistributionTenantConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the connection group for the distribution tenant. If you don't specify a connection group, CloudFront uses the default connection group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#connection_group_id CloudfrontDistributionTenant#connection_group_id}
    */
    readonly connectionGroupId?: string;
    /**
    * Customizations for the distribution tenant. For each distribution tenant, you can specify the geographic restrictions, and the Amazon Resource Names (ARNs) for the ACM certificate and WAF web ACL. These are specific values that you can override or disable from the multi-tenant distribution that was used to create the distribution tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#customizations CloudfrontDistributionTenant#customizations}
    */
    readonly customizations?: CloudfrontDistributionTenantCustomizations;
    /**
    * The ID of the multi-tenant distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#distribution_id CloudfrontDistributionTenant#distribution_id}
    */
    readonly distributionId: string;
    /**
    * The domains associated with the distribution tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#domains CloudfrontDistributionTenant#domains}
    */
    readonly domains: string[];
    /**
    * Indicates whether the distribution tenant is in an enabled state. If disabled, the distribution tenant won't serve traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#enabled CloudfrontDistributionTenant#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * An object that represents the request for the Amazon CloudFront managed ACM certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#managed_certificate_request CloudfrontDistributionTenant#managed_certificate_request}
    */
    readonly managedCertificateRequest?: CloudfrontDistributionTenantManagedCertificateRequest;
    /**
    * The name of the distribution tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#name CloudfrontDistributionTenant#name}
    */
    readonly name: string;
    /**
    * A list of parameter values to add to the resource. A parameter is specified as a key-value pair. A valid parameter value must exist for any parameter that is marked as required in the multi-tenant distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#parameters CloudfrontDistributionTenant#parameters}
    */
    readonly parameters?: CloudfrontDistributionTenantParameters[] | cdktn.IResolvable;
    /**
    * A complex type that contains zero or more ``Tag`` elements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#tags CloudfrontDistributionTenant#tags}
    */
    readonly tags?: CloudfrontDistributionTenantTags[] | cdktn.IResolvable;
}
export interface CloudfrontDistributionTenantCustomizationsCertificate {
    /**
    * The Amazon Resource Name (ARN) of the ACM certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#arn CloudfrontDistributionTenant#arn}
    */
    readonly arn?: string;
}
export declare function cloudfrontDistributionTenantCustomizationsCertificateToTerraform(struct?: CloudfrontDistributionTenantCustomizationsCertificate | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantCustomizationsCertificateToHclTerraform(struct?: CloudfrontDistributionTenantCustomizationsCertificate | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantCustomizationsCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontDistributionTenantCustomizationsCertificate | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantCustomizationsCertificate | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
}
export interface CloudfrontDistributionTenantCustomizationsGeoRestrictions {
    /**
    * The locations for geographic restrictions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#locations CloudfrontDistributionTenant#locations}
    */
    readonly locations?: string[];
    /**
    * The method that you want to use to restrict distribution of your content by country:
    *   +  ``none``: No geographic restriction is enabled, meaning access to content is not restricted by client geo location.
    *   +  ``blacklist``: The ``Location`` elements specify the countries in which you don't want CloudFront to distribute your content.
    *   +  ``whitelist``: The ``Location`` elements specify the countries in which you want CloudFront to distribute your content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#restriction_type CloudfrontDistributionTenant#restriction_type}
    */
    readonly restrictionType?: string;
}
export declare function cloudfrontDistributionTenantCustomizationsGeoRestrictionsToTerraform(struct?: CloudfrontDistributionTenantCustomizationsGeoRestrictions | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantCustomizationsGeoRestrictionsToHclTerraform(struct?: CloudfrontDistributionTenantCustomizationsGeoRestrictions | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantCustomizationsGeoRestrictionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontDistributionTenantCustomizationsGeoRestrictions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantCustomizationsGeoRestrictions | cdktn.IResolvable | undefined);
    private _locations?;
    get locations(): string[];
    set locations(value: string[]);
    resetLocations(): void;
    get locationsInput(): string[] | undefined;
    private _restrictionType?;
    get restrictionType(): string;
    set restrictionType(value: string);
    resetRestrictionType(): void;
    get restrictionTypeInput(): string | undefined;
}
export interface CloudfrontDistributionTenantCustomizationsWebAcl {
    /**
    * The action for the WAF web ACL customization. You can specify ``override`` to specify a separate WAF web ACL for the distribution tenant. If you specify ``disable``, the distribution tenant won't have WAF web ACL protections and won't inherit from the multi-tenant distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#action CloudfrontDistributionTenant#action}
    */
    readonly action?: string;
    /**
    * The Amazon Resource Name (ARN) of the WAF web ACL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#arn CloudfrontDistributionTenant#arn}
    */
    readonly arn?: string;
}
export declare function cloudfrontDistributionTenantCustomizationsWebAclToTerraform(struct?: CloudfrontDistributionTenantCustomizationsWebAcl | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantCustomizationsWebAclToHclTerraform(struct?: CloudfrontDistributionTenantCustomizationsWebAcl | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantCustomizationsWebAclOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontDistributionTenantCustomizationsWebAcl | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantCustomizationsWebAcl | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
}
export interface CloudfrontDistributionTenantCustomizations {
    /**
    * The ACMlong (ACM) certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#certificate CloudfrontDistributionTenant#certificate}
    */
    readonly certificate?: CloudfrontDistributionTenantCustomizationsCertificate;
    /**
    * The geographic restrictions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#geo_restrictions CloudfrontDistributionTenant#geo_restrictions}
    */
    readonly geoRestrictions?: CloudfrontDistributionTenantCustomizationsGeoRestrictions;
    /**
    * The WAF web ACL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#web_acl CloudfrontDistributionTenant#web_acl}
    */
    readonly webAcl?: CloudfrontDistributionTenantCustomizationsWebAcl;
}
export declare function cloudfrontDistributionTenantCustomizationsToTerraform(struct?: CloudfrontDistributionTenantCustomizations | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantCustomizationsToHclTerraform(struct?: CloudfrontDistributionTenantCustomizations | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantCustomizationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontDistributionTenantCustomizations | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantCustomizations | cdktn.IResolvable | undefined);
    private _certificate;
    get certificate(): CloudfrontDistributionTenantCustomizationsCertificateOutputReference;
    putCertificate(value: CloudfrontDistributionTenantCustomizationsCertificate): void;
    resetCertificate(): void;
    get certificateInput(): cdktn.IResolvable | CloudfrontDistributionTenantCustomizationsCertificate | undefined;
    private _geoRestrictions;
    get geoRestrictions(): CloudfrontDistributionTenantCustomizationsGeoRestrictionsOutputReference;
    putGeoRestrictions(value: CloudfrontDistributionTenantCustomizationsGeoRestrictions): void;
    resetGeoRestrictions(): void;
    get geoRestrictionsInput(): cdktn.IResolvable | CloudfrontDistributionTenantCustomizationsGeoRestrictions | undefined;
    private _webAcl;
    get webAcl(): CloudfrontDistributionTenantCustomizationsWebAclOutputReference;
    putWebAcl(value: CloudfrontDistributionTenantCustomizationsWebAcl): void;
    resetWebAcl(): void;
    get webAclInput(): cdktn.IResolvable | CloudfrontDistributionTenantCustomizationsWebAcl | undefined;
}
export interface CloudfrontDistributionTenantDomainResults {
}
export declare function cloudfrontDistributionTenantDomainResultsToTerraform(struct?: CloudfrontDistributionTenantDomainResults): any;
export declare function cloudfrontDistributionTenantDomainResultsToHclTerraform(struct?: CloudfrontDistributionTenantDomainResults): any;
export declare class CloudfrontDistributionTenantDomainResultsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantDomainResults | undefined;
    set internalValue(value: CloudfrontDistributionTenantDomainResults | undefined);
    get domain(): string;
    get status(): string;
}
export declare class CloudfrontDistributionTenantDomainResultsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantDomainResultsOutputReference;
}
export interface CloudfrontDistributionTenantManagedCertificateRequest {
    /**
    * You can opt out of certificate transparency logging by specifying the ``disabled`` option. Opt in by specifying ``enabled``. For more information, see [Certificate Transparency Logging](https://docs.aws.amazon.com/acm/latest/userguide/acm-concepts.html#concept-transparency) in the *User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#certificate_transparency_logging_preference CloudfrontDistributionTenant#certificate_transparency_logging_preference}
    */
    readonly certificateTransparencyLoggingPreference?: string;
    /**
    * The primary domain name associated with the CloudFront managed ACM certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#primary_domain_name CloudfrontDistributionTenant#primary_domain_name}
    */
    readonly primaryDomainName?: string;
    /**
    * Specify how the HTTP validation token will be served when requesting the CloudFront managed ACM certificate.
    *   +  For ``cloudfront``, CloudFront will automatically serve the validation token. Choose this mode if you can point the domain's DNS to CloudFront immediately.
    *   +  For ``self-hosted``, you serve the validation token from your existing infrastructure. Choose this mode when you need to maintain current traffic flow while your certificate is being issued. You can place the validation token at the well-known path on your existing web server, wait for ACM to validate and issue the certificate, and then update your DNS to point to CloudFront.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#validation_token_host CloudfrontDistributionTenant#validation_token_host}
    */
    readonly validationTokenHost?: string;
}
export declare function cloudfrontDistributionTenantManagedCertificateRequestToTerraform(struct?: CloudfrontDistributionTenantManagedCertificateRequest | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantManagedCertificateRequestToHclTerraform(struct?: CloudfrontDistributionTenantManagedCertificateRequest | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantManagedCertificateRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontDistributionTenantManagedCertificateRequest | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantManagedCertificateRequest | cdktn.IResolvable | undefined);
    private _certificateTransparencyLoggingPreference?;
    get certificateTransparencyLoggingPreference(): string;
    set certificateTransparencyLoggingPreference(value: string);
    resetCertificateTransparencyLoggingPreference(): void;
    get certificateTransparencyLoggingPreferenceInput(): string | undefined;
    private _primaryDomainName?;
    get primaryDomainName(): string;
    set primaryDomainName(value: string);
    resetPrimaryDomainName(): void;
    get primaryDomainNameInput(): string | undefined;
    private _validationTokenHost?;
    get validationTokenHost(): string;
    set validationTokenHost(value: string);
    resetValidationTokenHost(): void;
    get validationTokenHostInput(): string | undefined;
}
export interface CloudfrontDistributionTenantParameters {
    /**
    * The parameter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#name CloudfrontDistributionTenant#name}
    */
    readonly name?: string;
    /**
    * The parameter value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#value CloudfrontDistributionTenant#value}
    */
    readonly value?: string;
}
export declare function cloudfrontDistributionTenantParametersToTerraform(struct?: CloudfrontDistributionTenantParameters | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantParametersToHclTerraform(struct?: CloudfrontDistributionTenantParameters | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantParameters | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontDistributionTenantParametersList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantParametersOutputReference;
}
export interface CloudfrontDistributionTenantTags {
    /**
    * A string that contains ``Tag`` key.
    *  The string length should be between 1 and 128 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#key CloudfrontDistributionTenant#key}
    */
    readonly key?: string;
    /**
    * A string that contains an optional ``Tag`` value.
    *  The string length should be between 0 and 256 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#value CloudfrontDistributionTenant#value}
    */
    readonly value?: string;
}
export declare function cloudfrontDistributionTenantTagsToTerraform(struct?: CloudfrontDistributionTenantTags | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantTagsToHclTerraform(struct?: CloudfrontDistributionTenantTags | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontDistributionTenantTagsList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant awscc_cloudfront_distribution_tenant}
*/
export declare class CloudfrontDistributionTenant extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_distribution_tenant";
    /**
    * Generates CDKTN code for importing a CloudfrontDistributionTenant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontDistributionTenant to import
    * @param importFromId The id of the existing CloudfrontDistributionTenant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontDistributionTenant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_distribution_tenant awscc_cloudfront_distribution_tenant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontDistributionTenantConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontDistributionTenantConfig);
    get arn(): string;
    private _connectionGroupId?;
    get connectionGroupId(): string;
    set connectionGroupId(value: string);
    resetConnectionGroupId(): void;
    get connectionGroupIdInput(): string | undefined;
    get createdTime(): string;
    private _customizations;
    get customizations(): CloudfrontDistributionTenantCustomizationsOutputReference;
    putCustomizations(value: CloudfrontDistributionTenantCustomizations): void;
    resetCustomizations(): void;
    get customizationsInput(): cdktn.IResolvable | CloudfrontDistributionTenantCustomizations | undefined;
    private _distributionId?;
    get distributionId(): string;
    set distributionId(value: string);
    get distributionIdInput(): string | undefined;
    get distributionTenantId(): string;
    private _domainResults;
    get domainResults(): CloudfrontDistributionTenantDomainResultsList;
    private _domains?;
    get domains(): string[];
    set domains(value: string[]);
    get domainsInput(): string[] | undefined;
    get eTag(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get lastModifiedTime(): string;
    private _managedCertificateRequest;
    get managedCertificateRequest(): CloudfrontDistributionTenantManagedCertificateRequestOutputReference;
    putManagedCertificateRequest(value: CloudfrontDistributionTenantManagedCertificateRequest): void;
    resetManagedCertificateRequest(): void;
    get managedCertificateRequestInput(): cdktn.IResolvable | CloudfrontDistributionTenantManagedCertificateRequest | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): CloudfrontDistributionTenantParametersList;
    putParameters(value: CloudfrontDistributionTenantParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | CloudfrontDistributionTenantParameters[] | undefined;
    get status(): string;
    private _tags;
    get tags(): CloudfrontDistributionTenantTagsList;
    putTags(value: CloudfrontDistributionTenantTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudfrontDistributionTenantTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
