/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchAlarmConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#action_configuration CloudwatchAlarm#action_configuration}
    */
    readonly actionConfiguration?: CloudwatchAlarmActionConfiguration;
    /**
    * Indicates whether actions should be executed during any changes to the alarm state. The default is TRUE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#actions_enabled CloudwatchAlarm#actions_enabled}
    */
    readonly actionsEnabled?: boolean | cdktn.IResolvable;
    /**
    * The list of actions to execute when this alarm transitions into an ALARM state from any other state. Specify each action as an Amazon Resource Name (ARN). For more information about creating alarms and the actions that you can specify, see [PutMetricAlarm](https://docs.aws.amazon.com/AmazonCloudWatch/latest/APIReference/API_PutMetricAlarm.html) in the *API Reference*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#alarm_actions CloudwatchAlarm#alarm_actions}
    */
    readonly alarmActions?: string[];
    /**
    * The description of the alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#alarm_description CloudwatchAlarm#alarm_description}
    */
    readonly alarmDescription?: string;
    /**
    * The name of the alarm. If you don't specify a name, CFN generates a unique physical ID and uses that ID for the alarm name.
    *   If you specify a name, you cannot perform updates that require replacement of this resource. You can perform updates that require no or some interruption. If you must replace the resource, specify a new name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#alarm_name CloudwatchAlarm#alarm_name}
    */
    readonly alarmName?: string;
    /**
    * The arithmetic operation to use when comparing the specified statistic and threshold. The specified statistic value is used as the first operand.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#comparison_operator CloudwatchAlarm#comparison_operator}
    */
    readonly comparisonOperator?: string;
    /**
    * The number of datapoints that must be breaching to trigger the alarm. This is used only if you are setting an "M out of N" alarm. In that case, this value is the M, and the value that you set for ``EvaluationPeriods`` is the N value. For more information, see [Evaluating an Alarm](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html#alarm-evaluation) in the *User Guide*.
    *  If you omit this parameter, CW uses the same value here that you set for ``EvaluationPeriods``, and the alarm goes to alarm state if that many consecutive periods are breaching.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#datapoints_to_alarm CloudwatchAlarm#datapoints_to_alarm}
    */
    readonly datapointsToAlarm?: number;
    /**
    * The dimensions for the metric associated with the alarm. For an alarm based on a math expression, you can't specify ``Dimensions``. Instead, you use ``Metrics``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#dimensions CloudwatchAlarm#dimensions}
    */
    readonly dimensions?: CloudwatchAlarmDimensions[] | cdktn.IResolvable;
    /**
    * Used only for alarms based on percentiles. If ``ignore``, the alarm state does not change during periods with too few data points to be statistically significant. If ``evaluate`` or this parameter is not used, the alarm is always evaluated and possibly changes state no matter how many data points are available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#evaluate_low_sample_count_percentile CloudwatchAlarm#evaluate_low_sample_count_percentile}
    */
    readonly evaluateLowSampleCountPercentile?: string;
    /**
    * The evaluation criteria for the alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#evaluation_criteria CloudwatchAlarm#evaluation_criteria}
    */
    readonly evaluationCriteria?: CloudwatchAlarmEvaluationCriteria;
    /**
    * The frequency, in seconds, at which the alarm is evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#evaluation_interval CloudwatchAlarm#evaluation_interval}
    */
    readonly evaluationInterval?: number;
    /**
    * The number of periods over which data is compared to the specified threshold. If you are setting an alarm that requires that a number of consecutive data points be breaching to trigger the alarm, this value specifies that number. If you are setting an "M out of N" alarm, this value is the N, and ``DatapointsToAlarm`` is the M.
    *  For more information, see [Evaluating an Alarm](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html#alarm-evaluation) in the *User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#evaluation_periods CloudwatchAlarm#evaluation_periods}
    */
    readonly evaluationPeriods?: number;
    /**
    * The evaluation window that the alarm uses to select the range of metric data that it evaluates. This is either a sliding window or a wall clock window. For more information, see [Alarm evaluation windows](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/alarm-evaluation-window.html) in the *CloudWatch User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#evaluation_window CloudwatchAlarm#evaluation_window}
    */
    readonly evaluationWindow?: CloudwatchAlarmEvaluationWindow;
    /**
    * The percentile statistic for the metric associated with the alarm. Specify a value between p0.0 and p100.
    *  For an alarm based on a metric, you must specify either ``Statistic`` or ``ExtendedStatistic`` but not both.
    *  For an alarm based on a math expression, you can't specify ``ExtendedStatistic``. Instead, you use ``Metrics``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#extended_statistic CloudwatchAlarm#extended_statistic}
    */
    readonly extendedStatistic?: string;
    /**
    * The actions to execute when this alarm transitions to the ``INSUFFICIENT_DATA`` state from any other state. Each action is specified as an Amazon Resource Name (ARN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#insufficient_data_actions CloudwatchAlarm#insufficient_data_actions}
    */
    readonly insufficientDataActions?: string[];
    /**
    * The name of the metric associated with the alarm. This is required for an alarm based on a metric. For an alarm based on a math expression, you use ``Metrics`` instead and you can't specify ``MetricName``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#metric_name CloudwatchAlarm#metric_name}
    */
    readonly metricName?: string;
    /**
    * An array that enables you to create an alarm based on the result of a metric math expression. Each item in the array either retrieves a metric or performs a math expression.
    *  If you specify the ``Metrics`` parameter, you cannot specify ``MetricName``, ``Dimensions``, ``Period``, ``Namespace``, ``Statistic``, ``ExtendedStatistic``, or ``Unit``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#metrics CloudwatchAlarm#metrics}
    */
    readonly metrics?: CloudwatchAlarmMetrics[] | cdktn.IResolvable;
    /**
    * The namespace of the metric associated with the alarm. This is required for an alarm based on a metric. For an alarm based on a math expression, you can't specify ``Namespace`` and you use ``Metrics`` instead.
    *  For a list of namespaces for metrics from AWS services, see [Services That Publish Metrics.](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/aws-services-cloudwatch-metrics.html)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#namespace CloudwatchAlarm#namespace}
    */
    readonly namespace?: string;
    /**
    * The actions to execute when this alarm transitions to the ``OK`` state from any other state. Each action is specified as an Amazon Resource Name (ARN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#ok_actions CloudwatchAlarm#ok_actions}
    */
    readonly okActions?: string[];
    /**
    * The period, in seconds, over which the statistic is applied. This is required for an alarm based on a metric. Valid values are 10, 20, 30, 60, and any multiple of 60.
    *  For an alarm based on a math expression, you can't specify ``Period``, and instead you use the ``Metrics`` parameter.
    *  *Minimum:* 10
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#period CloudwatchAlarm#period}
    */
    readonly period?: number;
    /**
    * The statistic for the metric associated with the alarm, other than percentile. For percentile statistics, use ``ExtendedStatistic``.
    *  For an alarm based on a metric, you must specify either ``Statistic`` or ``ExtendedStatistic`` but not both.
    *  For an alarm based on a math expression, you can't specify ``Statistic``. Instead, you use ``Metrics``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#statistic CloudwatchAlarm#statistic}
    */
    readonly statistic?: string;
    /**
    * A list of key-value pairs to associate with the alarm. You can associate as many as 50 tags with an alarm. To be able to associate tags with the alarm when you create the alarm, you must have the ``cloudwatch:TagResource`` permission.
    *  Tags can help you organize and categorize your resources. You can also use them to scope user permissions by granting a user permission to access or change only resources with certain tag values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#tags CloudwatchAlarm#tags}
    */
    readonly tags?: CloudwatchAlarmTags[] | cdktn.IResolvable;
    /**
    * The value to compare with the specified statistic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#threshold CloudwatchAlarm#threshold}
    */
    readonly threshold?: number;
    /**
    * In an alarm based on an anomaly detection model, this is the ID of the ``ANOMALY_DETECTION_BAND`` function used as the threshold for the alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#threshold_metric_id CloudwatchAlarm#threshold_metric_id}
    */
    readonly thresholdMetricId?: string;
    /**
    * Sets how this alarm is to handle missing data points. Valid values are ``breaching``, ``notBreaching``, ``ignore``, and ``missing``. For more information, see [Configuring How Alarms Treat Missing Data](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html#alarms-and-missing-data) in the *Amazon User Guide*.
    *  If you omit this parameter, the default behavior of ``missing`` is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#treat_missing_data CloudwatchAlarm#treat_missing_data}
    */
    readonly treatMissingData?: string;
    /**
    * The unit of the metric associated with the alarm. Specify this only if you are creating an alarm based on a single metric. Do not specify this if you are specifying a ``Metrics`` array.
    *   You can specify the following values: Seconds, Microseconds, Milliseconds, Bytes, Kilobytes, Megabytes, Gigabytes, Terabytes, Bits, Kilobits, Megabits, Gigabits, Terabits, Percent, Count, Bytes/Second, Kilobytes/Second, Megabytes/Second, Gigabytes/Second, Terabytes/Second, Bits/Second, Kilobits/Second, Megabits/Second, Gigabits/Second, Terabits/Second, Count/Second, or None.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#unit CloudwatchAlarm#unit}
    */
    readonly unit?: string;
    /**
    * The warm-up configuration for the alarm. A warm-up period delays alarm evaluation after you create or update the alarm. During the warm-up period, the alarm stays in ``INSUFFICIENT_DATA`` and does not perform alarm actions.
    *  For more information, see [Alarm warm-up periods](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/alarm-warm-up.html) in the *Amazon CloudWatch User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#warm_up_configuration CloudwatchAlarm#warm_up_configuration}
    */
    readonly warmUpConfiguration?: CloudwatchAlarmWarmUpConfiguration;
}
export interface CloudwatchAlarmActionConfigurationAlarmTagsPropagation {
    /**
    * Whether the alarm's tags are included in its action notifications and state-change events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#enabled CloudwatchAlarm#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The tag keys to leave out. Cannot be specified together with IncludedTagKeys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#excluded_tag_keys CloudwatchAlarm#excluded_tag_keys}
    */
    readonly excludedTagKeys?: string[];
    /**
    * The only tag keys to include. Cannot be specified together with ExcludedTagKeys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#included_tag_keys CloudwatchAlarm#included_tag_keys}
    */
    readonly includedTagKeys?: string[];
}
export declare function cloudwatchAlarmActionConfigurationAlarmTagsPropagationToTerraform(struct?: CloudwatchAlarmActionConfigurationAlarmTagsPropagation | cdktn.IResolvable): any;
export declare function cloudwatchAlarmActionConfigurationAlarmTagsPropagationToHclTerraform(struct?: CloudwatchAlarmActionConfigurationAlarmTagsPropagation | cdktn.IResolvable): any;
export declare class CloudwatchAlarmActionConfigurationAlarmTagsPropagationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmActionConfigurationAlarmTagsPropagation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmActionConfigurationAlarmTagsPropagation | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedTagKeys?;
    get excludedTagKeys(): string[];
    set excludedTagKeys(value: string[]);
    resetExcludedTagKeys(): void;
    get excludedTagKeysInput(): string[] | undefined;
    private _includedTagKeys?;
    get includedTagKeys(): string[];
    set includedTagKeys(value: string[]);
    resetIncludedTagKeys(): void;
    get includedTagKeysInput(): string[] | undefined;
}
export interface CloudwatchAlarmActionConfiguration {
    /**
    * Whether the alarm's tags are included in its action notifications and state-change events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#alarm_tags_propagation CloudwatchAlarm#alarm_tags_propagation}
    */
    readonly alarmTagsPropagation?: CloudwatchAlarmActionConfigurationAlarmTagsPropagation;
}
export declare function cloudwatchAlarmActionConfigurationToTerraform(struct?: CloudwatchAlarmActionConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchAlarmActionConfigurationToHclTerraform(struct?: CloudwatchAlarmActionConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchAlarmActionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmActionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmActionConfiguration | cdktn.IResolvable | undefined);
    private _alarmTagsPropagation;
    get alarmTagsPropagation(): CloudwatchAlarmActionConfigurationAlarmTagsPropagationOutputReference;
    putAlarmTagsPropagation(value: CloudwatchAlarmActionConfigurationAlarmTagsPropagation): void;
    resetAlarmTagsPropagation(): void;
    get alarmTagsPropagationInput(): cdktn.IResolvable | CloudwatchAlarmActionConfigurationAlarmTagsPropagation | undefined;
}
export interface CloudwatchAlarmDimensions {
    /**
    * The name of the dimension, from 1–255 characters in length. This dimension name must have been included when the metric was published.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#name CloudwatchAlarm#name}
    */
    readonly name?: string;
    /**
    * The value for the dimension, from 1–255 characters in length.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#value CloudwatchAlarm#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAlarmDimensionsToTerraform(struct?: CloudwatchAlarmDimensions | cdktn.IResolvable): any;
export declare function cloudwatchAlarmDimensionsToHclTerraform(struct?: CloudwatchAlarmDimensions | cdktn.IResolvable): any;
export declare class CloudwatchAlarmDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlarmDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAlarmDimensionsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlarmDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlarmDimensionsOutputReference;
}
export interface CloudwatchAlarmEvaluationCriteriaPromQlCriteria {
    /**
    * The duration, in seconds, that a contributor must be continuously breaching before it transitions to the ``ALARM`` state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#pending_period CloudwatchAlarm#pending_period}
    */
    readonly pendingPeriod?: number;
    /**
    * The PromQL query that the alarm evaluates. The query must return a result of vector type. Each entry in the vector result represents an alarm contributor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#query CloudwatchAlarm#query}
    */
    readonly query?: string;
    /**
    * The duration, in seconds, that a contributor must continuously not be breaching before it transitions back to the ``OK`` state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#recovery_period CloudwatchAlarm#recovery_period}
    */
    readonly recoveryPeriod?: number;
}
export declare function cloudwatchAlarmEvaluationCriteriaPromQlCriteriaToTerraform(struct?: CloudwatchAlarmEvaluationCriteriaPromQlCriteria | cdktn.IResolvable): any;
export declare function cloudwatchAlarmEvaluationCriteriaPromQlCriteriaToHclTerraform(struct?: CloudwatchAlarmEvaluationCriteriaPromQlCriteria | cdktn.IResolvable): any;
export declare class CloudwatchAlarmEvaluationCriteriaPromQlCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmEvaluationCriteriaPromQlCriteria | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmEvaluationCriteriaPromQlCriteria | cdktn.IResolvable | undefined);
    private _pendingPeriod?;
    get pendingPeriod(): number;
    set pendingPeriod(value: number);
    resetPendingPeriod(): void;
    get pendingPeriodInput(): number | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _recoveryPeriod?;
    get recoveryPeriod(): number;
    set recoveryPeriod(value: number);
    resetRecoveryPeriod(): void;
    get recoveryPeriodInput(): number | undefined;
}
export interface CloudwatchAlarmEvaluationCriteria {
    /**
    * The PromQL criteria for the alarm evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#prom_ql_criteria CloudwatchAlarm#prom_ql_criteria}
    */
    readonly promQlCriteria?: CloudwatchAlarmEvaluationCriteriaPromQlCriteria;
}
export declare function cloudwatchAlarmEvaluationCriteriaToTerraform(struct?: CloudwatchAlarmEvaluationCriteria | cdktn.IResolvable): any;
export declare function cloudwatchAlarmEvaluationCriteriaToHclTerraform(struct?: CloudwatchAlarmEvaluationCriteria | cdktn.IResolvable): any;
export declare class CloudwatchAlarmEvaluationCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmEvaluationCriteria | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmEvaluationCriteria | cdktn.IResolvable | undefined);
    private _promQlCriteria;
    get promQlCriteria(): CloudwatchAlarmEvaluationCriteriaPromQlCriteriaOutputReference;
    putPromQlCriteria(value: CloudwatchAlarmEvaluationCriteriaPromQlCriteria): void;
    resetPromQlCriteria(): void;
    get promQlCriteriaInput(): cdktn.IResolvable | CloudwatchAlarmEvaluationCriteriaPromQlCriteria | undefined;
}
export interface CloudwatchAlarmEvaluationWindowWallClockWindow {
    /**
    * The time zone to use when the alarm aligns the evaluation window to clock boundaries. You can specify an IANA time zone name (for example, ``America/New_York``), a fixed UTC offset (for example, ``+05:30``), or an offset-prefixed identifier (for example, ``UTC+05:30``). The offset must be aligned to a multiple of 5 minutes. If you don't specify a time zone, CloudWatch uses ``UTC``.
    *  The time zone affects window alignment for all periods, including periods of one hour or shorter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#timezone CloudwatchAlarm#timezone}
    */
    readonly timezone?: string;
}
export declare function cloudwatchAlarmEvaluationWindowWallClockWindowToTerraform(struct?: CloudwatchAlarmEvaluationWindowWallClockWindow | cdktn.IResolvable): any;
export declare function cloudwatchAlarmEvaluationWindowWallClockWindowToHclTerraform(struct?: CloudwatchAlarmEvaluationWindowWallClockWindow | cdktn.IResolvable): any;
export declare class CloudwatchAlarmEvaluationWindowWallClockWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmEvaluationWindowWallClockWindow | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmEvaluationWindowWallClockWindow | cdktn.IResolvable | undefined);
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
export interface CloudwatchAlarmEvaluationWindow {
    /**
    * A sliding window, which advances each time the alarm is evaluated, forming a rolling time window. This is the default evaluation window.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#sliding_window CloudwatchAlarm#sliding_window}
    */
    readonly slidingWindow?: string;
    /**
    * A wall clock window, which aligns the evaluated range to fixed clock boundaries that match the alarm's period, such as the top of the hour, midnight, or the start of the calendar week.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#wall_clock_window CloudwatchAlarm#wall_clock_window}
    */
    readonly wallClockWindow?: CloudwatchAlarmEvaluationWindowWallClockWindow;
}
export declare function cloudwatchAlarmEvaluationWindowToTerraform(struct?: CloudwatchAlarmEvaluationWindow | cdktn.IResolvable): any;
export declare function cloudwatchAlarmEvaluationWindowToHclTerraform(struct?: CloudwatchAlarmEvaluationWindow | cdktn.IResolvable): any;
export declare class CloudwatchAlarmEvaluationWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmEvaluationWindow | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmEvaluationWindow | cdktn.IResolvable | undefined);
    private _slidingWindow?;
    get slidingWindow(): string;
    set slidingWindow(value: string);
    resetSlidingWindow(): void;
    get slidingWindowInput(): string | undefined;
    private _wallClockWindow;
    get wallClockWindow(): CloudwatchAlarmEvaluationWindowWallClockWindowOutputReference;
    putWallClockWindow(value: CloudwatchAlarmEvaluationWindowWallClockWindow): void;
    resetWallClockWindow(): void;
    get wallClockWindowInput(): cdktn.IResolvable | CloudwatchAlarmEvaluationWindowWallClockWindow | undefined;
}
export interface CloudwatchAlarmMetricsMetricStatMetricDimensions {
    /**
    * The name of the dimension, from 1–255 characters in length. This dimension name must have been included when the metric was published.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#name CloudwatchAlarm#name}
    */
    readonly name?: string;
    /**
    * The value for the dimension, from 1–255 characters in length.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#value CloudwatchAlarm#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAlarmMetricsMetricStatMetricDimensionsToTerraform(struct?: CloudwatchAlarmMetricsMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMetricsMetricStatMetricDimensionsToHclTerraform(struct?: CloudwatchAlarmMetricsMetricStatMetricDimensions | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMetricsMetricStatMetricDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlarmMetricsMetricStatMetricDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMetricsMetricStatMetricDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAlarmMetricsMetricStatMetricDimensionsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlarmMetricsMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlarmMetricsMetricStatMetricDimensionsOutputReference;
}
export interface CloudwatchAlarmMetricsMetricStatMetric {
    /**
    * The metric dimensions that you want to be used for the metric that the alarm will watch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#dimensions CloudwatchAlarm#dimensions}
    */
    readonly dimensions?: CloudwatchAlarmMetricsMetricStatMetricDimensions[] | cdktn.IResolvable;
    /**
    * The name of the metric that you want the alarm to watch. This is a required field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#metric_name CloudwatchAlarm#metric_name}
    */
    readonly metricName?: string;
    /**
    * The namespace of the metric that the alarm will watch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#namespace CloudwatchAlarm#namespace}
    */
    readonly namespace?: string;
}
export declare function cloudwatchAlarmMetricsMetricStatMetricToTerraform(struct?: CloudwatchAlarmMetricsMetricStatMetric | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMetricsMetricStatMetricToHclTerraform(struct?: CloudwatchAlarmMetricsMetricStatMetric | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMetricsMetricStatMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmMetricsMetricStatMetric | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMetricsMetricStatMetric | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): CloudwatchAlarmMetricsMetricStatMetricDimensionsList;
    putDimensions(value: CloudwatchAlarmMetricsMetricStatMetricDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | CloudwatchAlarmMetricsMetricStatMetricDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface CloudwatchAlarmMetricsMetricStat {
    /**
    * The metric to return, including the metric name, namespace, and dimensions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#metric CloudwatchAlarm#metric}
    */
    readonly metric?: CloudwatchAlarmMetricsMetricStatMetric;
    /**
    * The granularity, in seconds, of the returned data points. For metrics with regular resolution, a period can be as short as one minute (60 seconds) and must be a multiple of 60. For high-resolution metrics that are collected at intervals of less than one minute, the period can be 1, 5, 10, 20, 30, 60, or any multiple of 60. High-resolution metrics are those metrics stored by a ``PutMetricData`` call that includes a ``StorageResolution`` of 1 second.
    *  If the ``StartTime`` parameter specifies a time stamp that is greater than 3 hours ago, you must specify the period as follows or no data points in that time range is returned:
    *   +  Start time between 3 hours and 15 days ago - Use a multiple of 60 seconds (1 minute).
    *   +  Start time between 15 and 63 days ago - Use a multiple of 300 seconds (5 minutes).
    *   +  Start time greater than 63 days ago - Use a multiple of 3600 seconds (1 hour).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#period CloudwatchAlarm#period}
    */
    readonly period?: number;
    /**
    * The statistic to return. It can include any CW statistic or extended statistic. For a list of valid values, see the table in [Statistics](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/cloudwatch_concepts.html#Statistic) in the *User Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#stat CloudwatchAlarm#stat}
    */
    readonly stat?: string;
    /**
    * The unit to use for the returned data points.
    *  Valid values are: Seconds, Microseconds, Milliseconds, Bytes, Kilobytes, Megabytes, Gigabytes, Terabytes, Bits, Kilobits, Megabits, Gigabits, Terabits, Percent, Count, Bytes/Second, Kilobytes/Second, Megabytes/Second, Gigabytes/Second, Terabytes/Second, Bits/Second, Kilobits/Second, Megabits/Second, Gigabits/Second, Terabits/Second, Count/Second, or None.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#unit CloudwatchAlarm#unit}
    */
    readonly unit?: string;
}
export declare function cloudwatchAlarmMetricsMetricStatToTerraform(struct?: CloudwatchAlarmMetricsMetricStat | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMetricsMetricStatToHclTerraform(struct?: CloudwatchAlarmMetricsMetricStat | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMetricsMetricStatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmMetricsMetricStat | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMetricsMetricStat | cdktn.IResolvable | undefined);
    private _metric;
    get metric(): CloudwatchAlarmMetricsMetricStatMetricOutputReference;
    putMetric(value: CloudwatchAlarmMetricsMetricStatMetric): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | CloudwatchAlarmMetricsMetricStatMetric | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    resetStat(): void;
    get statInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface CloudwatchAlarmMetrics {
    /**
    * The ID of the account where the metrics are located, if this is a cross-account alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#account_id CloudwatchAlarm#account_id}
    */
    readonly accountId?: string;
    /**
    * The math expression to be performed on the returned data, if this object is performing a math expression. This expression can use the ``Id`` of the other metrics to refer to those metrics, and can also use the ``Id`` of other expressions to use the result of those expressions. For more information about metric math expressions, see [Metric Math Syntax and Functions](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html#metric-math-syntax) in the *User Guide*.
    *  Within each MetricDataQuery object, you must specify either ``Expression`` or ``MetricStat`` but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#expression CloudwatchAlarm#expression}
    */
    readonly expression?: string;
    /**
    * A short name used to tie this object to the results in the response. This name must be unique within a single call to ``GetMetricData``. If you are performing math expressions on this set of data, this name represents that data and can serve as a variable in the mathematical expression. The valid characters are letters, numbers, and underscore. The first character must be a lowercase letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#id CloudwatchAlarm#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A human-readable label for this metric or expression. This is especially useful if this is an expression, so that you know what the value represents. If the metric or expression is shown in a CW dashboard widget, the label is shown. If ``Label`` is omitted, CW generates a default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#label CloudwatchAlarm#label}
    */
    readonly label?: string;
    /**
    * The metric to be returned, along with statistics, period, and units. Use this parameter only if this object is retrieving a metric and not performing a math expression on returned data.
    *  Within one MetricDataQuery object, you must specify either ``Expression`` or ``MetricStat`` but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#metric_stat CloudwatchAlarm#metric_stat}
    */
    readonly metricStat?: CloudwatchAlarmMetricsMetricStat;
    /**
    * The granularity, in seconds, of the returned data points. For metrics with regular resolution, a period can be as short as one minute (60 seconds) and must be a multiple of 60. For high-resolution metrics that are collected at intervals of less than one minute, the period can be 1, 5, 10, 20, 30, 60, or any multiple of 60. High-resolution metrics are those metrics stored by a ``PutMetricData`` operation that includes a ``StorageResolution of 1 second``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#period CloudwatchAlarm#period}
    */
    readonly period?: number;
    /**
    * This option indicates whether to return the timestamps and raw data values of this metric.
    *  When you create an alarm based on a metric math expression, specify ``True`` for this value for only the one math expression that the alarm is based on. You must specify ``False`` for ``ReturnData`` for all the other metrics and expressions used in the alarm.
    *  This field is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#return_data CloudwatchAlarm#return_data}
    */
    readonly returnData?: boolean | cdktn.IResolvable;
}
export declare function cloudwatchAlarmMetricsToTerraform(struct?: CloudwatchAlarmMetrics | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMetricsToHclTerraform(struct?: CloudwatchAlarmMetrics | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlarmMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMetrics | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _metricStat;
    get metricStat(): CloudwatchAlarmMetricsMetricStatOutputReference;
    putMetricStat(value: CloudwatchAlarmMetricsMetricStat): void;
    resetMetricStat(): void;
    get metricStatInput(): cdktn.IResolvable | CloudwatchAlarmMetricsMetricStat | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _returnData?;
    get returnData(): boolean | cdktn.IResolvable;
    set returnData(value: boolean | cdktn.IResolvable);
    resetReturnData(): void;
    get returnDataInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class CloudwatchAlarmMetricsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlarmMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlarmMetricsOutputReference;
}
export interface CloudwatchAlarmTags {
    /**
    * A string that you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#key CloudwatchAlarm#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#value CloudwatchAlarm#value}
    */
    readonly value?: string;
}
export declare function cloudwatchAlarmTagsToTerraform(struct?: CloudwatchAlarmTags | cdktn.IResolvable): any;
export declare function cloudwatchAlarmTagsToHclTerraform(struct?: CloudwatchAlarmTags | cdktn.IResolvable): any;
export declare class CloudwatchAlarmTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlarmTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchAlarmTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlarmTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlarmTagsOutputReference;
}
export interface CloudwatchAlarmWarmUpConfiguration {
    /**
    * Specifies whether the alarm waits for the full warm-up period before it starts to evaluate. The default is ``false``. If ``true``, the alarm waits the entire ``WarmUpPeriodDurationInMinutes`` before it starts to evaluate, even if metric data arrives earlier. If ``false``, the alarm ends the warm-up period early. Evaluation begins as soon as the alarm has enough metric data to fill its evaluation window.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#only_start_evaluating_after_warm_up_period_ends CloudwatchAlarm#only_start_evaluating_after_warm_up_period_ends}
    */
    readonly onlyStartEvaluatingAfterWarmUpPeriodEnds?: boolean | cdktn.IResolvable;
    /**
    * The length of the warm-up period, in minutes. After you create or update the alarm, the alarm stays in ``INSUFFICIENT_DATA`` for this duration. During this time, the alarm does not perform alarm actions.
    *  You can change this value at any time, including after the warm-up period ends. If you change it after the warm-up period ends, the new value does not restart the warm-up period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#warm_up_period_duration_in_minutes CloudwatchAlarm#warm_up_period_duration_in_minutes}
    */
    readonly warmUpPeriodDurationInMinutes?: number;
}
export declare function cloudwatchAlarmWarmUpConfigurationToTerraform(struct?: CloudwatchAlarmWarmUpConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchAlarmWarmUpConfigurationToHclTerraform(struct?: CloudwatchAlarmWarmUpConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchAlarmWarmUpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchAlarmWarmUpConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmWarmUpConfiguration | cdktn.IResolvable | undefined);
    private _onlyStartEvaluatingAfterWarmUpPeriodEnds?;
    get onlyStartEvaluatingAfterWarmUpPeriodEnds(): boolean | cdktn.IResolvable;
    set onlyStartEvaluatingAfterWarmUpPeriodEnds(value: boolean | cdktn.IResolvable);
    resetOnlyStartEvaluatingAfterWarmUpPeriodEnds(): void;
    get onlyStartEvaluatingAfterWarmUpPeriodEndsInput(): boolean | cdktn.IResolvable | undefined;
    private _warmUpPeriodDurationInMinutes?;
    get warmUpPeriodDurationInMinutes(): number;
    set warmUpPeriodDurationInMinutes(value: number);
    resetWarmUpPeriodDurationInMinutes(): void;
    get warmUpPeriodDurationInMinutesInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm awscc_cloudwatch_alarm}
*/
export declare class CloudwatchAlarm extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_alarm";
    /**
    * Generates CDKTN code for importing a CloudwatchAlarm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchAlarm to import
    * @param importFromId The id of the existing CloudwatchAlarm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchAlarm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_alarm awscc_cloudwatch_alarm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchAlarmConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudwatchAlarmConfig);
    private _actionConfiguration;
    get actionConfiguration(): CloudwatchAlarmActionConfigurationOutputReference;
    putActionConfiguration(value: CloudwatchAlarmActionConfiguration): void;
    resetActionConfiguration(): void;
    get actionConfigurationInput(): cdktn.IResolvable | CloudwatchAlarmActionConfiguration | undefined;
    private _actionsEnabled?;
    get actionsEnabled(): boolean | cdktn.IResolvable;
    set actionsEnabled(value: boolean | cdktn.IResolvable);
    resetActionsEnabled(): void;
    get actionsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _alarmActions?;
    get alarmActions(): string[];
    set alarmActions(value: string[]);
    resetAlarmActions(): void;
    get alarmActionsInput(): string[] | undefined;
    private _alarmDescription?;
    get alarmDescription(): string;
    set alarmDescription(value: string);
    resetAlarmDescription(): void;
    get alarmDescriptionInput(): string | undefined;
    private _alarmName?;
    get alarmName(): string;
    set alarmName(value: string);
    resetAlarmName(): void;
    get alarmNameInput(): string | undefined;
    get arn(): string;
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    resetComparisonOperator(): void;
    get comparisonOperatorInput(): string | undefined;
    private _datapointsToAlarm?;
    get datapointsToAlarm(): number;
    set datapointsToAlarm(value: number);
    resetDatapointsToAlarm(): void;
    get datapointsToAlarmInput(): number | undefined;
    private _dimensions;
    get dimensions(): CloudwatchAlarmDimensionsList;
    putDimensions(value: CloudwatchAlarmDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | CloudwatchAlarmDimensions[] | undefined;
    private _evaluateLowSampleCountPercentile?;
    get evaluateLowSampleCountPercentile(): string;
    set evaluateLowSampleCountPercentile(value: string);
    resetEvaluateLowSampleCountPercentile(): void;
    get evaluateLowSampleCountPercentileInput(): string | undefined;
    private _evaluationCriteria;
    get evaluationCriteria(): CloudwatchAlarmEvaluationCriteriaOutputReference;
    putEvaluationCriteria(value: CloudwatchAlarmEvaluationCriteria): void;
    resetEvaluationCriteria(): void;
    get evaluationCriteriaInput(): cdktn.IResolvable | CloudwatchAlarmEvaluationCriteria | undefined;
    private _evaluationInterval?;
    get evaluationInterval(): number;
    set evaluationInterval(value: number);
    resetEvaluationInterval(): void;
    get evaluationIntervalInput(): number | undefined;
    private _evaluationPeriods?;
    get evaluationPeriods(): number;
    set evaluationPeriods(value: number);
    resetEvaluationPeriods(): void;
    get evaluationPeriodsInput(): number | undefined;
    private _evaluationWindow;
    get evaluationWindow(): CloudwatchAlarmEvaluationWindowOutputReference;
    putEvaluationWindow(value: CloudwatchAlarmEvaluationWindow): void;
    resetEvaluationWindow(): void;
    get evaluationWindowInput(): cdktn.IResolvable | CloudwatchAlarmEvaluationWindow | undefined;
    private _extendedStatistic?;
    get extendedStatistic(): string;
    set extendedStatistic(value: string);
    resetExtendedStatistic(): void;
    get extendedStatisticInput(): string | undefined;
    get id(): string;
    private _insufficientDataActions?;
    get insufficientDataActions(): string[];
    set insufficientDataActions(value: string[]);
    resetInsufficientDataActions(): void;
    get insufficientDataActionsInput(): string[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _metrics;
    get metrics(): CloudwatchAlarmMetricsList;
    putMetrics(value: CloudwatchAlarmMetrics[] | cdktn.IResolvable): void;
    resetMetrics(): void;
    get metricsInput(): cdktn.IResolvable | CloudwatchAlarmMetrics[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _okActions?;
    get okActions(): string[];
    set okActions(value: string[]);
    resetOkActions(): void;
    get okActionsInput(): string[] | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _statistic?;
    get statistic(): string;
    set statistic(value: string);
    resetStatistic(): void;
    get statisticInput(): string | undefined;
    private _tags;
    get tags(): CloudwatchAlarmTagsList;
    putTags(value: CloudwatchAlarmTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchAlarmTags[] | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
    private _thresholdMetricId?;
    get thresholdMetricId(): string;
    set thresholdMetricId(value: string);
    resetThresholdMetricId(): void;
    get thresholdMetricIdInput(): string | undefined;
    private _treatMissingData?;
    get treatMissingData(): string;
    set treatMissingData(value: string);
    resetTreatMissingData(): void;
    get treatMissingDataInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _warmUpConfiguration;
    get warmUpConfiguration(): CloudwatchAlarmWarmUpConfigurationOutputReference;
    putWarmUpConfiguration(value: CloudwatchAlarmWarmUpConfiguration): void;
    resetWarmUpConfiguration(): void;
    get warmUpConfigurationInput(): cdktn.IResolvable | CloudwatchAlarmWarmUpConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
