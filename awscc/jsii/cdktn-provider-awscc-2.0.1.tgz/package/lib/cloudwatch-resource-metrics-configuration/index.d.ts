/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchResourceMetricsConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The metric selections that define which metrics are enabled for detailed monitoring on the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_resource_metrics_configuration#metric_selections CloudwatchResourceMetricsConfiguration#metric_selections}
    */
    readonly metricSelections?: CloudwatchResourceMetricsConfigurationMetricSelections[] | cdktn.IResolvable;
    /**
    * The Amazon Resource Name (ARN) of the resource for which the detailed monitoring metrics configuration is managed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_resource_metrics_configuration#resource_arn CloudwatchResourceMetricsConfiguration#resource_arn}
    */
    readonly resourceArn: string;
}
export interface CloudwatchResourceMetricsConfigurationMetricSelections {
    /**
    * The list of metric names to include in detailed monitoring for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_resource_metrics_configuration#include_metrics CloudwatchResourceMetricsConfiguration#include_metrics}
    */
    readonly includeMetrics?: string[];
}
export declare function cloudwatchResourceMetricsConfigurationMetricSelectionsToTerraform(struct?: CloudwatchResourceMetricsConfigurationMetricSelections | cdktn.IResolvable): any;
export declare function cloudwatchResourceMetricsConfigurationMetricSelectionsToHclTerraform(struct?: CloudwatchResourceMetricsConfigurationMetricSelections | cdktn.IResolvable): any;
export declare class CloudwatchResourceMetricsConfigurationMetricSelectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchResourceMetricsConfigurationMetricSelections | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchResourceMetricsConfigurationMetricSelections | cdktn.IResolvable | undefined);
    private _includeMetrics?;
    get includeMetrics(): string[];
    set includeMetrics(value: string[]);
    resetIncludeMetrics(): void;
    get includeMetricsInput(): string[] | undefined;
}
export declare class CloudwatchResourceMetricsConfigurationMetricSelectionsList extends cdktn.ComplexList {
    internalValue?: CloudwatchResourceMetricsConfigurationMetricSelections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchResourceMetricsConfigurationMetricSelectionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_resource_metrics_configuration awscc_cloudwatch_resource_metrics_configuration}
*/
export declare class CloudwatchResourceMetricsConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_resource_metrics_configuration";
    /**
    * Generates CDKTN code for importing a CloudwatchResourceMetricsConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchResourceMetricsConfiguration to import
    * @param importFromId The id of the existing CloudwatchResourceMetricsConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_resource_metrics_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchResourceMetricsConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_resource_metrics_configuration awscc_cloudwatch_resource_metrics_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchResourceMetricsConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchResourceMetricsConfigurationConfig);
    get createdAt(): string;
    get id(): string;
    private _metricSelections;
    get metricSelections(): CloudwatchResourceMetricsConfigurationMetricSelectionsList;
    putMetricSelections(value: CloudwatchResourceMetricsConfigurationMetricSelections[] | cdktn.IResolvable): void;
    resetMetricSelections(): void;
    get metricSelectionsInput(): cdktn.IResolvable | CloudwatchResourceMetricsConfigurationMetricSelections[] | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
