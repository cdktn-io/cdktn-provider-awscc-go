/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AcmpcaPermissionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The actions that the specified AWS service principal can use. Actions IssueCertificate, GetCertificate and ListPermissions must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/acmpca_permission#actions AcmpcaPermission#actions}
    */
    readonly actions: string[];
    /**
    * The Amazon Resource Name (ARN) of the Private Certificate Authority that grants the permission.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/acmpca_permission#certificate_authority_arn AcmpcaPermission#certificate_authority_arn}
    */
    readonly certificateAuthorityArn: string;
    /**
    * The AWS service or identity that receives the permission. At this time, the only valid principal is acm.amazonaws.com.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/acmpca_permission#principal AcmpcaPermission#principal}
    */
    readonly principal: string;
    /**
    * The ID of the calling account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/acmpca_permission#source_account AcmpcaPermission#source_account}
    */
    readonly sourceAccount?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/acmpca_permission awscc_acmpca_permission}
*/
export declare class AcmpcaPermission extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_acmpca_permission";
    /**
    * Generates CDKTN code for importing a AcmpcaPermission resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AcmpcaPermission to import
    * @param importFromId The id of the existing AcmpcaPermission that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/acmpca_permission#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AcmpcaPermission to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/acmpca_permission awscc_acmpca_permission} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AcmpcaPermissionConfig
    */
    constructor(scope: Construct, id: string, config: AcmpcaPermissionConfig);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    get actionsInput(): string[] | undefined;
    private _certificateAuthorityArn?;
    get certificateAuthorityArn(): string;
    set certificateAuthorityArn(value: string);
    get certificateAuthorityArnInput(): string | undefined;
    get id(): string;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _sourceAccount?;
    get sourceAccount(): string;
    set sourceAccount(value: string);
    resetSourceAccount(): void;
    get sourceAccountInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
