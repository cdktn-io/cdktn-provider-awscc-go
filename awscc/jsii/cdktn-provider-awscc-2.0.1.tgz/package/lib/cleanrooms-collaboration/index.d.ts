/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CleanroomsCollaborationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#allowed_result_regions CleanroomsCollaboration#allowed_result_regions}
    */
    readonly allowedResultRegions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#analytics_engine CleanroomsCollaboration#analytics_engine}
    */
    readonly analyticsEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#auto_approved_change_types CleanroomsCollaboration#auto_approved_change_types}
    */
    readonly autoApprovedChangeTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#creator_display_name CleanroomsCollaboration#creator_display_name}
    */
    readonly creatorDisplayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#creator_member_abilities CleanroomsCollaboration#creator_member_abilities}
    */
    readonly creatorMemberAbilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#creator_ml_member_abilities CleanroomsCollaboration#creator_ml_member_abilities}
    */
    readonly creatorMlMemberAbilities?: CleanroomsCollaborationCreatorMlMemberAbilities;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#creator_payment_configuration CleanroomsCollaboration#creator_payment_configuration}
    */
    readonly creatorPaymentConfiguration?: CleanroomsCollaborationCreatorPaymentConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#data_encryption_metadata CleanroomsCollaboration#data_encryption_metadata}
    */
    readonly dataEncryptionMetadata?: CleanroomsCollaborationDataEncryptionMetadata;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#description CleanroomsCollaboration#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_metrics_enabled CleanroomsCollaboration#is_metrics_enabled}
    */
    readonly isMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#job_log_status CleanroomsCollaboration#job_log_status}
    */
    readonly jobLogStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#members CleanroomsCollaboration#members}
    */
    readonly members?: CleanroomsCollaborationMembers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#name CleanroomsCollaboration#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#query_log_status CleanroomsCollaboration#query_log_status}
    */
    readonly queryLogStatus: string;
    /**
    * An arbitrary set of tags (key-value pairs) for this cleanrooms collaboration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#tags CleanroomsCollaboration#tags}
    */
    readonly tags?: CleanroomsCollaborationTags[] | cdktn.IResolvable;
}
export interface CleanroomsCollaborationCreatorMlMemberAbilities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#custom_ml_member_abilities CleanroomsCollaboration#custom_ml_member_abilities}
    */
    readonly customMlMemberAbilities?: string[];
}
export declare function cleanroomsCollaborationCreatorMlMemberAbilitiesToTerraform(struct?: CleanroomsCollaborationCreatorMlMemberAbilities | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationCreatorMlMemberAbilitiesToHclTerraform(struct?: CleanroomsCollaborationCreatorMlMemberAbilities | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationCreatorMlMemberAbilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationCreatorMlMemberAbilities | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationCreatorMlMemberAbilities | cdktn.IResolvable | undefined);
    private _customMlMemberAbilities?;
    get customMlMemberAbilities(): string[];
    set customMlMemberAbilities(value: string[]);
    resetCustomMlMemberAbilities(): void;
    get customMlMemberAbilitiesInput(): string[] | undefined;
}
export interface CleanroomsCollaborationCreatorPaymentConfigurationJobCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationCreatorPaymentConfigurationJobComputeToTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationJobCompute | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationCreatorPaymentConfigurationJobComputeToHclTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationJobCompute | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationCreatorPaymentConfigurationJobComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationCreatorPaymentConfigurationJobCompute | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationCreatorPaymentConfigurationJobCompute | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInference {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInferenceToTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInferenceToHclTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTraining {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTrainingToTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTrainingToHclTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTrainingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGeneration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGenerationToTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGenerationToHclTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGenerationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationCreatorPaymentConfigurationMachineLearning {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#model_inference CleanroomsCollaboration#model_inference}
    */
    readonly modelInference?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInference;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#model_training CleanroomsCollaboration#model_training}
    */
    readonly modelTraining?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTraining;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#synthetic_data_generation CleanroomsCollaboration#synthetic_data_generation}
    */
    readonly syntheticDataGeneration?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGeneration;
}
export declare function cleanroomsCollaborationCreatorPaymentConfigurationMachineLearningToTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearning | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationCreatorPaymentConfigurationMachineLearningToHclTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearning | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationCreatorPaymentConfigurationMachineLearning | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearning | cdktn.IResolvable | undefined);
    private _modelInference;
    get modelInference(): CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInferenceOutputReference;
    putModelInference(value: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInference): void;
    resetModelInference(): void;
    get modelInferenceInput(): cdktn.IResolvable | CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelInference | undefined;
    private _modelTraining;
    get modelTraining(): CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTrainingOutputReference;
    putModelTraining(value: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTraining): void;
    resetModelTraining(): void;
    get modelTrainingInput(): cdktn.IResolvable | CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningModelTraining | undefined;
    private _syntheticDataGeneration;
    get syntheticDataGeneration(): CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGenerationOutputReference;
    putSyntheticDataGeneration(value: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGeneration): void;
    resetSyntheticDataGeneration(): void;
    get syntheticDataGenerationInput(): cdktn.IResolvable | CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningSyntheticDataGeneration | undefined;
}
export interface CleanroomsCollaborationCreatorPaymentConfigurationQueryCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationCreatorPaymentConfigurationQueryComputeToTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationQueryCompute | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationCreatorPaymentConfigurationQueryComputeToHclTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfigurationQueryCompute | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationCreatorPaymentConfigurationQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationCreatorPaymentConfigurationQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationCreatorPaymentConfigurationQueryCompute | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationCreatorPaymentConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#job_compute CleanroomsCollaboration#job_compute}
    */
    readonly jobCompute?: CleanroomsCollaborationCreatorPaymentConfigurationJobCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#machine_learning CleanroomsCollaboration#machine_learning}
    */
    readonly machineLearning?: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearning;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#query_compute CleanroomsCollaboration#query_compute}
    */
    readonly queryCompute?: CleanroomsCollaborationCreatorPaymentConfigurationQueryCompute;
}
export declare function cleanroomsCollaborationCreatorPaymentConfigurationToTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationCreatorPaymentConfigurationToHclTerraform(struct?: CleanroomsCollaborationCreatorPaymentConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationCreatorPaymentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationCreatorPaymentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationCreatorPaymentConfiguration | cdktn.IResolvable | undefined);
    private _jobCompute;
    get jobCompute(): CleanroomsCollaborationCreatorPaymentConfigurationJobComputeOutputReference;
    putJobCompute(value: CleanroomsCollaborationCreatorPaymentConfigurationJobCompute): void;
    resetJobCompute(): void;
    get jobComputeInput(): cdktn.IResolvable | CleanroomsCollaborationCreatorPaymentConfigurationJobCompute | undefined;
    private _machineLearning;
    get machineLearning(): CleanroomsCollaborationCreatorPaymentConfigurationMachineLearningOutputReference;
    putMachineLearning(value: CleanroomsCollaborationCreatorPaymentConfigurationMachineLearning): void;
    resetMachineLearning(): void;
    get machineLearningInput(): cdktn.IResolvable | CleanroomsCollaborationCreatorPaymentConfigurationMachineLearning | undefined;
    private _queryCompute;
    get queryCompute(): CleanroomsCollaborationCreatorPaymentConfigurationQueryComputeOutputReference;
    putQueryCompute(value: CleanroomsCollaborationCreatorPaymentConfigurationQueryCompute): void;
    resetQueryCompute(): void;
    get queryComputeInput(): cdktn.IResolvable | CleanroomsCollaborationCreatorPaymentConfigurationQueryCompute | undefined;
}
export interface CleanroomsCollaborationDataEncryptionMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#allow_cleartext CleanroomsCollaboration#allow_cleartext}
    */
    readonly allowCleartext?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#allow_duplicates CleanroomsCollaboration#allow_duplicates}
    */
    readonly allowDuplicates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#allow_joins_on_columns_with_different_names CleanroomsCollaboration#allow_joins_on_columns_with_different_names}
    */
    readonly allowJoinsOnColumnsWithDifferentNames?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#preserve_nulls CleanroomsCollaboration#preserve_nulls}
    */
    readonly preserveNulls?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationDataEncryptionMetadataToTerraform(struct?: CleanroomsCollaborationDataEncryptionMetadata | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationDataEncryptionMetadataToHclTerraform(struct?: CleanroomsCollaborationDataEncryptionMetadata | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationDataEncryptionMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationDataEncryptionMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationDataEncryptionMetadata | cdktn.IResolvable | undefined);
    private _allowCleartext?;
    get allowCleartext(): boolean | cdktn.IResolvable;
    set allowCleartext(value: boolean | cdktn.IResolvable);
    resetAllowCleartext(): void;
    get allowCleartextInput(): boolean | cdktn.IResolvable | undefined;
    private _allowDuplicates?;
    get allowDuplicates(): boolean | cdktn.IResolvable;
    set allowDuplicates(value: boolean | cdktn.IResolvable);
    resetAllowDuplicates(): void;
    get allowDuplicatesInput(): boolean | cdktn.IResolvable | undefined;
    private _allowJoinsOnColumnsWithDifferentNames?;
    get allowJoinsOnColumnsWithDifferentNames(): boolean | cdktn.IResolvable;
    set allowJoinsOnColumnsWithDifferentNames(value: boolean | cdktn.IResolvable);
    resetAllowJoinsOnColumnsWithDifferentNames(): void;
    get allowJoinsOnColumnsWithDifferentNamesInput(): boolean | cdktn.IResolvable | undefined;
    private _preserveNulls?;
    get preserveNulls(): boolean | cdktn.IResolvable;
    set preserveNulls(value: boolean | cdktn.IResolvable);
    resetPreserveNulls(): void;
    get preserveNullsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationMembersMlMemberAbilities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#custom_ml_member_abilities CleanroomsCollaboration#custom_ml_member_abilities}
    */
    readonly customMlMemberAbilities?: string[];
}
export declare function cleanroomsCollaborationMembersMlMemberAbilitiesToTerraform(struct?: CleanroomsCollaborationMembersMlMemberAbilities | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersMlMemberAbilitiesToHclTerraform(struct?: CleanroomsCollaborationMembersMlMemberAbilities | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersMlMemberAbilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationMembersMlMemberAbilities | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembersMlMemberAbilities | cdktn.IResolvable | undefined);
    private _customMlMemberAbilities?;
    get customMlMemberAbilities(): string[];
    set customMlMemberAbilities(value: string[]);
    resetCustomMlMemberAbilities(): void;
    get customMlMemberAbilitiesInput(): string[] | undefined;
}
export interface CleanroomsCollaborationMembersPaymentConfigurationJobCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationMembersPaymentConfigurationJobComputeToTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationJobCompute | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersPaymentConfigurationJobComputeToHclTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationJobCompute | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersPaymentConfigurationJobComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationMembersPaymentConfigurationJobCompute | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembersPaymentConfigurationJobCompute | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInference {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInferenceToTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInferenceToHclTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInference | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTraining {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTrainingToTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTrainingToHclTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTrainingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTraining | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGeneration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGenerationToTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGenerationToHclTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGenerationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGeneration | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationMembersPaymentConfigurationMachineLearning {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#model_inference CleanroomsCollaboration#model_inference}
    */
    readonly modelInference?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInference;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#model_training CleanroomsCollaboration#model_training}
    */
    readonly modelTraining?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTraining;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#synthetic_data_generation CleanroomsCollaboration#synthetic_data_generation}
    */
    readonly syntheticDataGeneration?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGeneration;
}
export declare function cleanroomsCollaborationMembersPaymentConfigurationMachineLearningToTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearning | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersPaymentConfigurationMachineLearningToHclTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearning | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersPaymentConfigurationMachineLearningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationMembersPaymentConfigurationMachineLearning | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembersPaymentConfigurationMachineLearning | cdktn.IResolvable | undefined);
    private _modelInference;
    get modelInference(): CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInferenceOutputReference;
    putModelInference(value: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInference): void;
    resetModelInference(): void;
    get modelInferenceInput(): cdktn.IResolvable | CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelInference | undefined;
    private _modelTraining;
    get modelTraining(): CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTrainingOutputReference;
    putModelTraining(value: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTraining): void;
    resetModelTraining(): void;
    get modelTrainingInput(): cdktn.IResolvable | CleanroomsCollaborationMembersPaymentConfigurationMachineLearningModelTraining | undefined;
    private _syntheticDataGeneration;
    get syntheticDataGeneration(): CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGenerationOutputReference;
    putSyntheticDataGeneration(value: CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGeneration): void;
    resetSyntheticDataGeneration(): void;
    get syntheticDataGenerationInput(): cdktn.IResolvable | CleanroomsCollaborationMembersPaymentConfigurationMachineLearningSyntheticDataGeneration | undefined;
}
export interface CleanroomsCollaborationMembersPaymentConfigurationQueryCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#is_responsible CleanroomsCollaboration#is_responsible}
    */
    readonly isResponsible?: boolean | cdktn.IResolvable;
}
export declare function cleanroomsCollaborationMembersPaymentConfigurationQueryComputeToTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationQueryCompute | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersPaymentConfigurationQueryComputeToHclTerraform(struct?: CleanroomsCollaborationMembersPaymentConfigurationQueryCompute | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersPaymentConfigurationQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationMembersPaymentConfigurationQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembersPaymentConfigurationQueryCompute | cdktn.IResolvable | undefined);
    private _isResponsible?;
    get isResponsible(): boolean | cdktn.IResolvable;
    set isResponsible(value: boolean | cdktn.IResolvable);
    resetIsResponsible(): void;
    get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CleanroomsCollaborationMembersPaymentConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#job_compute CleanroomsCollaboration#job_compute}
    */
    readonly jobCompute?: CleanroomsCollaborationMembersPaymentConfigurationJobCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#machine_learning CleanroomsCollaboration#machine_learning}
    */
    readonly machineLearning?: CleanroomsCollaborationMembersPaymentConfigurationMachineLearning;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#query_compute CleanroomsCollaboration#query_compute}
    */
    readonly queryCompute?: CleanroomsCollaborationMembersPaymentConfigurationQueryCompute;
}
export declare function cleanroomsCollaborationMembersPaymentConfigurationToTerraform(struct?: CleanroomsCollaborationMembersPaymentConfiguration | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersPaymentConfigurationToHclTerraform(struct?: CleanroomsCollaborationMembersPaymentConfiguration | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersPaymentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CleanroomsCollaborationMembersPaymentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembersPaymentConfiguration | cdktn.IResolvable | undefined);
    private _jobCompute;
    get jobCompute(): CleanroomsCollaborationMembersPaymentConfigurationJobComputeOutputReference;
    putJobCompute(value: CleanroomsCollaborationMembersPaymentConfigurationJobCompute): void;
    resetJobCompute(): void;
    get jobComputeInput(): cdktn.IResolvable | CleanroomsCollaborationMembersPaymentConfigurationJobCompute | undefined;
    private _machineLearning;
    get machineLearning(): CleanroomsCollaborationMembersPaymentConfigurationMachineLearningOutputReference;
    putMachineLearning(value: CleanroomsCollaborationMembersPaymentConfigurationMachineLearning): void;
    resetMachineLearning(): void;
    get machineLearningInput(): cdktn.IResolvable | CleanroomsCollaborationMembersPaymentConfigurationMachineLearning | undefined;
    private _queryCompute;
    get queryCompute(): CleanroomsCollaborationMembersPaymentConfigurationQueryComputeOutputReference;
    putQueryCompute(value: CleanroomsCollaborationMembersPaymentConfigurationQueryCompute): void;
    resetQueryCompute(): void;
    get queryComputeInput(): cdktn.IResolvable | CleanroomsCollaborationMembersPaymentConfigurationQueryCompute | undefined;
}
export interface CleanroomsCollaborationMembers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#account_id CleanroomsCollaboration#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#display_name CleanroomsCollaboration#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#member_abilities CleanroomsCollaboration#member_abilities}
    */
    readonly memberAbilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#ml_member_abilities CleanroomsCollaboration#ml_member_abilities}
    */
    readonly mlMemberAbilities?: CleanroomsCollaborationMembersMlMemberAbilities;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#payment_configuration CleanroomsCollaboration#payment_configuration}
    */
    readonly paymentConfiguration?: CleanroomsCollaborationMembersPaymentConfiguration;
}
export declare function cleanroomsCollaborationMembersToTerraform(struct?: CleanroomsCollaborationMembers | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationMembersToHclTerraform(struct?: CleanroomsCollaborationMembers | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationMembersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsCollaborationMembers | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationMembers | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _memberAbilities?;
    get memberAbilities(): string[];
    set memberAbilities(value: string[]);
    resetMemberAbilities(): void;
    get memberAbilitiesInput(): string[] | undefined;
    private _mlMemberAbilities;
    get mlMemberAbilities(): CleanroomsCollaborationMembersMlMemberAbilitiesOutputReference;
    putMlMemberAbilities(value: CleanroomsCollaborationMembersMlMemberAbilities): void;
    resetMlMemberAbilities(): void;
    get mlMemberAbilitiesInput(): cdktn.IResolvable | CleanroomsCollaborationMembersMlMemberAbilities | undefined;
    private _paymentConfiguration;
    get paymentConfiguration(): CleanroomsCollaborationMembersPaymentConfigurationOutputReference;
    putPaymentConfiguration(value: CleanroomsCollaborationMembersPaymentConfiguration): void;
    resetPaymentConfiguration(): void;
    get paymentConfigurationInput(): cdktn.IResolvable | CleanroomsCollaborationMembersPaymentConfiguration | undefined;
}
export declare class CleanroomsCollaborationMembersList extends cdktn.ComplexList {
    internalValue?: CleanroomsCollaborationMembers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsCollaborationMembersOutputReference;
}
export interface CleanroomsCollaborationTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#key CleanroomsCollaboration#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#value CleanroomsCollaboration#value}
    */
    readonly value?: string;
}
export declare function cleanroomsCollaborationTagsToTerraform(struct?: CleanroomsCollaborationTags | cdktn.IResolvable): any;
export declare function cleanroomsCollaborationTagsToHclTerraform(struct?: CleanroomsCollaborationTags | cdktn.IResolvable): any;
export declare class CleanroomsCollaborationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CleanroomsCollaborationTags | cdktn.IResolvable | undefined;
    set internalValue(value: CleanroomsCollaborationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CleanroomsCollaborationTagsList extends cdktn.ComplexList {
    internalValue?: CleanroomsCollaborationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CleanroomsCollaborationTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration awscc_cleanrooms_collaboration}
*/
export declare class CleanroomsCollaboration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cleanrooms_collaboration";
    /**
    * Generates CDKTN code for importing a CleanroomsCollaboration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CleanroomsCollaboration to import
    * @param importFromId The id of the existing CleanroomsCollaboration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CleanroomsCollaboration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cleanrooms_collaboration awscc_cleanrooms_collaboration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CleanroomsCollaborationConfig
    */
    constructor(scope: Construct, id: string, config: CleanroomsCollaborationConfig);
    private _allowedResultRegions?;
    get allowedResultRegions(): string[];
    set allowedResultRegions(value: string[]);
    resetAllowedResultRegions(): void;
    get allowedResultRegionsInput(): string[] | undefined;
    private _analyticsEngine?;
    get analyticsEngine(): string;
    set analyticsEngine(value: string);
    resetAnalyticsEngine(): void;
    get analyticsEngineInput(): string | undefined;
    get arn(): string;
    private _autoApprovedChangeTypes?;
    get autoApprovedChangeTypes(): string[];
    set autoApprovedChangeTypes(value: string[]);
    resetAutoApprovedChangeTypes(): void;
    get autoApprovedChangeTypesInput(): string[] | undefined;
    get collaborationIdentifier(): string;
    private _creatorDisplayName?;
    get creatorDisplayName(): string;
    set creatorDisplayName(value: string);
    get creatorDisplayNameInput(): string | undefined;
    private _creatorMemberAbilities?;
    get creatorMemberAbilities(): string[];
    set creatorMemberAbilities(value: string[]);
    resetCreatorMemberAbilities(): void;
    get creatorMemberAbilitiesInput(): string[] | undefined;
    private _creatorMlMemberAbilities;
    get creatorMlMemberAbilities(): CleanroomsCollaborationCreatorMlMemberAbilitiesOutputReference;
    putCreatorMlMemberAbilities(value: CleanroomsCollaborationCreatorMlMemberAbilities): void;
    resetCreatorMlMemberAbilities(): void;
    get creatorMlMemberAbilitiesInput(): cdktn.IResolvable | CleanroomsCollaborationCreatorMlMemberAbilities | undefined;
    private _creatorPaymentConfiguration;
    get creatorPaymentConfiguration(): CleanroomsCollaborationCreatorPaymentConfigurationOutputReference;
    putCreatorPaymentConfiguration(value: CleanroomsCollaborationCreatorPaymentConfiguration): void;
    resetCreatorPaymentConfiguration(): void;
    get creatorPaymentConfigurationInput(): cdktn.IResolvable | CleanroomsCollaborationCreatorPaymentConfiguration | undefined;
    private _dataEncryptionMetadata;
    get dataEncryptionMetadata(): CleanroomsCollaborationDataEncryptionMetadataOutputReference;
    putDataEncryptionMetadata(value: CleanroomsCollaborationDataEncryptionMetadata): void;
    resetDataEncryptionMetadata(): void;
    get dataEncryptionMetadataInput(): cdktn.IResolvable | CleanroomsCollaborationDataEncryptionMetadata | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _isMetricsEnabled?;
    get isMetricsEnabled(): boolean | cdktn.IResolvable;
    set isMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetIsMetricsEnabled(): void;
    get isMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _jobLogStatus?;
    get jobLogStatus(): string;
    set jobLogStatus(value: string);
    resetJobLogStatus(): void;
    get jobLogStatusInput(): string | undefined;
    private _members;
    get members(): CleanroomsCollaborationMembersList;
    putMembers(value: CleanroomsCollaborationMembers[] | cdktn.IResolvable): void;
    resetMembers(): void;
    get membersInput(): cdktn.IResolvable | CleanroomsCollaborationMembers[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _queryLogStatus?;
    get queryLogStatus(): string;
    set queryLogStatus(value: string);
    get queryLogStatusInput(): string | undefined;
    private _tags;
    get tags(): CleanroomsCollaborationTagsList;
    putTags(value: CleanroomsCollaborationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CleanroomsCollaborationTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
