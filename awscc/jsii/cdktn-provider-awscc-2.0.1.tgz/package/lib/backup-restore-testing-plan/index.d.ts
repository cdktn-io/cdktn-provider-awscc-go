/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupRestoreTestingPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#recovery_point_selection BackupRestoreTestingPlan#recovery_point_selection}
    */
    readonly recoveryPointSelection: BackupRestoreTestingPlanRecoveryPointSelection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#restore_testing_plan_name BackupRestoreTestingPlan#restore_testing_plan_name}
    */
    readonly restoreTestingPlanName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#schedule_expression BackupRestoreTestingPlan#schedule_expression}
    */
    readonly scheduleExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#schedule_expression_timezone BackupRestoreTestingPlan#schedule_expression_timezone}
    */
    readonly scheduleExpressionTimezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#start_window_hours BackupRestoreTestingPlan#start_window_hours}
    */
    readonly startWindowHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#tags BackupRestoreTestingPlan#tags}
    */
    readonly tags?: BackupRestoreTestingPlanTags[] | cdktn.IResolvable;
}
export interface BackupRestoreTestingPlanRecoveryPointSelection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#algorithm BackupRestoreTestingPlan#algorithm}
    */
    readonly algorithm: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#exclude_vaults BackupRestoreTestingPlan#exclude_vaults}
    */
    readonly excludeVaults?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#include_vaults BackupRestoreTestingPlan#include_vaults}
    */
    readonly includeVaults: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#recovery_point_types BackupRestoreTestingPlan#recovery_point_types}
    */
    readonly recoveryPointTypes: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#selection_window_days BackupRestoreTestingPlan#selection_window_days}
    */
    readonly selectionWindowDays?: number;
}
export declare function backupRestoreTestingPlanRecoveryPointSelectionToTerraform(struct?: BackupRestoreTestingPlanRecoveryPointSelection | cdktn.IResolvable): any;
export declare function backupRestoreTestingPlanRecoveryPointSelectionToHclTerraform(struct?: BackupRestoreTestingPlanRecoveryPointSelection | cdktn.IResolvable): any;
export declare class BackupRestoreTestingPlanRecoveryPointSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupRestoreTestingPlanRecoveryPointSelection | cdktn.IResolvable | undefined;
    set internalValue(value: BackupRestoreTestingPlanRecoveryPointSelection | cdktn.IResolvable | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
    private _excludeVaults?;
    get excludeVaults(): string[];
    set excludeVaults(value: string[]);
    resetExcludeVaults(): void;
    get excludeVaultsInput(): string[] | undefined;
    private _includeVaults?;
    get includeVaults(): string[];
    set includeVaults(value: string[]);
    get includeVaultsInput(): string[] | undefined;
    private _recoveryPointTypes?;
    get recoveryPointTypes(): string[];
    set recoveryPointTypes(value: string[]);
    get recoveryPointTypesInput(): string[] | undefined;
    private _selectionWindowDays?;
    get selectionWindowDays(): number;
    set selectionWindowDays(value: number);
    resetSelectionWindowDays(): void;
    get selectionWindowDaysInput(): number | undefined;
}
export interface BackupRestoreTestingPlanTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#key BackupRestoreTestingPlan#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#value BackupRestoreTestingPlan#value}
    */
    readonly value?: string;
}
export declare function backupRestoreTestingPlanTagsToTerraform(struct?: BackupRestoreTestingPlanTags | cdktn.IResolvable): any;
export declare function backupRestoreTestingPlanTagsToHclTerraform(struct?: BackupRestoreTestingPlanTags | cdktn.IResolvable): any;
export declare class BackupRestoreTestingPlanTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupRestoreTestingPlanTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupRestoreTestingPlanTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupRestoreTestingPlanTagsList extends cdktn.ComplexList {
    internalValue?: BackupRestoreTestingPlanTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupRestoreTestingPlanTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan awscc_backup_restore_testing_plan}
*/
export declare class BackupRestoreTestingPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_restore_testing_plan";
    /**
    * Generates CDKTN code for importing a BackupRestoreTestingPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupRestoreTestingPlan to import
    * @param importFromId The id of the existing BackupRestoreTestingPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupRestoreTestingPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_restore_testing_plan awscc_backup_restore_testing_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupRestoreTestingPlanConfig
    */
    constructor(scope: Construct, id: string, config: BackupRestoreTestingPlanConfig);
    get id(): string;
    private _recoveryPointSelection;
    get recoveryPointSelection(): BackupRestoreTestingPlanRecoveryPointSelectionOutputReference;
    putRecoveryPointSelection(value: BackupRestoreTestingPlanRecoveryPointSelection): void;
    get recoveryPointSelectionInput(): cdktn.IResolvable | BackupRestoreTestingPlanRecoveryPointSelection | undefined;
    get restoreTestingPlanArn(): string;
    private _restoreTestingPlanName?;
    get restoreTestingPlanName(): string;
    set restoreTestingPlanName(value: string);
    get restoreTestingPlanNameInput(): string | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    get scheduleExpressionInput(): string | undefined;
    private _scheduleExpressionTimezone?;
    get scheduleExpressionTimezone(): string;
    set scheduleExpressionTimezone(value: string);
    resetScheduleExpressionTimezone(): void;
    get scheduleExpressionTimezoneInput(): string | undefined;
    private _startWindowHours?;
    get startWindowHours(): number;
    set startWindowHours(value: number);
    resetStartWindowHours(): void;
    get startWindowHoursInput(): number | undefined;
    private _tags;
    get tags(): BackupRestoreTestingPlanTagsList;
    putTags(value: BackupRestoreTestingPlanTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BackupRestoreTestingPlanTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
