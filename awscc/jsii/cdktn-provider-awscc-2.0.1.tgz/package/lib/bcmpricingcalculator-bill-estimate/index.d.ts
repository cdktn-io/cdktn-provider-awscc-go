/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BcmpricingcalculatorBillEstimateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the bill scenario this estimate is based on
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate#bill_scenario_id BcmpricingcalculatorBillEstimate#bill_scenario_id}
    */
    readonly billScenarioId?: string;
    /**
    * The timestamp when the bill estimate expires
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate#expires_at BcmpricingcalculatorBillEstimate#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * The name of the bill estimate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate#name BcmpricingcalculatorBillEstimate#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate#tags BcmpricingcalculatorBillEstimate#tags}
    */
    readonly tags?: BcmpricingcalculatorBillEstimateTags[] | cdktn.IResolvable;
}
export interface BcmpricingcalculatorBillEstimateBillInterval {
}
export declare function bcmpricingcalculatorBillEstimateBillIntervalToTerraform(struct?: BcmpricingcalculatorBillEstimateBillInterval): any;
export declare function bcmpricingcalculatorBillEstimateBillIntervalToHclTerraform(struct?: BcmpricingcalculatorBillEstimateBillInterval): any;
export declare class BcmpricingcalculatorBillEstimateBillIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmpricingcalculatorBillEstimateBillInterval | undefined;
    set internalValue(value: BcmpricingcalculatorBillEstimateBillInterval | undefined);
    get end(): string;
    get start(): string;
}
export interface BcmpricingcalculatorBillEstimateTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate#key BcmpricingcalculatorBillEstimate#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate#value BcmpricingcalculatorBillEstimate#value}
    */
    readonly value?: string;
}
export declare function bcmpricingcalculatorBillEstimateTagsToTerraform(struct?: BcmpricingcalculatorBillEstimateTags | cdktn.IResolvable): any;
export declare function bcmpricingcalculatorBillEstimateTagsToHclTerraform(struct?: BcmpricingcalculatorBillEstimateTags | cdktn.IResolvable): any;
export declare class BcmpricingcalculatorBillEstimateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmpricingcalculatorBillEstimateTags | cdktn.IResolvable | undefined;
    set internalValue(value: BcmpricingcalculatorBillEstimateTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BcmpricingcalculatorBillEstimateTagsList extends cdktn.ComplexList {
    internalValue?: BcmpricingcalculatorBillEstimateTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmpricingcalculatorBillEstimateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate awscc_bcmpricingcalculator_bill_estimate}
*/
export declare class BcmpricingcalculatorBillEstimate extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bcmpricingcalculator_bill_estimate";
    /**
    * Generates CDKTN code for importing a BcmpricingcalculatorBillEstimate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BcmpricingcalculatorBillEstimate to import
    * @param importFromId The id of the existing BcmpricingcalculatorBillEstimate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BcmpricingcalculatorBillEstimate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcmpricingcalculator_bill_estimate awscc_bcmpricingcalculator_bill_estimate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BcmpricingcalculatorBillEstimateConfig
    */
    constructor(scope: Construct, id: string, config: BcmpricingcalculatorBillEstimateConfig);
    get arn(): string;
    get billEstimateId(): string;
    private _billInterval;
    get billInterval(): BcmpricingcalculatorBillEstimateBillIntervalOutputReference;
    private _billScenarioId?;
    get billScenarioId(): string;
    set billScenarioId(value: string);
    resetBillScenarioId(): void;
    get billScenarioIdInput(): string | undefined;
    get costCategoryGroupSharingPreferenceArn(): string;
    get costCategoryGroupSharingPreferenceEffectiveDate(): string;
    get createdAt(): string;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    get groupSharingPreference(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): BcmpricingcalculatorBillEstimateTagsList;
    putTags(value: BcmpricingcalculatorBillEstimateTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BcmpricingcalculatorBillEstimateTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
