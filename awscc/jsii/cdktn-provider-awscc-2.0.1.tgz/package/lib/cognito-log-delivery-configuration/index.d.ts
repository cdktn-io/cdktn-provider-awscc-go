/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoLogDeliveryConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#log_configurations CognitoLogDeliveryConfiguration#log_configurations}
    */
    readonly logConfigurations?: CognitoLogDeliveryConfigurationLogConfigurations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#user_pool_id CognitoLogDeliveryConfiguration#user_pool_id}
    */
    readonly userPoolId: string;
}
export interface CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#log_group_arn CognitoLogDeliveryConfiguration#log_group_arn}
    */
    readonly logGroupArn?: string;
}
export declare function cognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfigurationToTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfiguration | cdktn.IResolvable): any;
export declare function cognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfigurationToHclTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfiguration | cdktn.IResolvable): any;
export declare class CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfiguration | cdktn.IResolvable | undefined);
    private _logGroupArn?;
    get logGroupArn(): string;
    set logGroupArn(value: string);
    resetLogGroupArn(): void;
    get logGroupArnInput(): string | undefined;
}
export interface CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#stream_arn CognitoLogDeliveryConfiguration#stream_arn}
    */
    readonly streamArn?: string;
}
export declare function cognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationToTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | cdktn.IResolvable): any;
export declare function cognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationToHclTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | cdktn.IResolvable): any;
export declare class CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | cdktn.IResolvable | undefined);
    private _streamArn?;
    get streamArn(): string;
    set streamArn(value: string);
    resetStreamArn(): void;
    get streamArnInput(): string | undefined;
}
export interface CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#bucket_arn CognitoLogDeliveryConfiguration#bucket_arn}
    */
    readonly bucketArn?: string;
}
export declare function cognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationToTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | cdktn.IResolvable): any;
export declare function cognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationToHclTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | cdktn.IResolvable): any;
export declare class CognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | cdktn.IResolvable | undefined);
    private _bucketArn?;
    get bucketArn(): string;
    set bucketArn(value: string);
    resetBucketArn(): void;
    get bucketArnInput(): string | undefined;
}
export interface CognitoLogDeliveryConfigurationLogConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#cloudwatch_logs_configuration CognitoLogDeliveryConfiguration#cloudwatch_logs_configuration}
    */
    readonly cloudwatchLogsConfiguration?: CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#event_source CognitoLogDeliveryConfiguration#event_source}
    */
    readonly eventSource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#firehose_configuration CognitoLogDeliveryConfiguration#firehose_configuration}
    */
    readonly firehoseConfiguration?: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#log_level CognitoLogDeliveryConfiguration#log_level}
    */
    readonly logLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#s3_configuration CognitoLogDeliveryConfiguration#s3_configuration}
    */
    readonly s3Configuration?: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration;
}
export declare function cognitoLogDeliveryConfigurationLogConfigurationsToTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurations | cdktn.IResolvable): any;
export declare function cognitoLogDeliveryConfigurationLogConfigurationsToHclTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurations | cdktn.IResolvable): any;
export declare class CognitoLogDeliveryConfigurationLogConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoLogDeliveryConfigurationLogConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoLogDeliveryConfigurationLogConfigurations | cdktn.IResolvable | undefined);
    private _cloudwatchLogsConfiguration;
    get cloudwatchLogsConfiguration(): CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfigurationOutputReference;
    putCloudwatchLogsConfiguration(value: CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfiguration): void;
    resetCloudwatchLogsConfiguration(): void;
    get cloudwatchLogsConfigurationInput(): cdktn.IResolvable | CognitoLogDeliveryConfigurationLogConfigurationsCloudwatchLogsConfiguration | undefined;
    private _eventSource?;
    get eventSource(): string;
    set eventSource(value: string);
    resetEventSource(): void;
    get eventSourceInput(): string | undefined;
    private _firehoseConfiguration;
    get firehoseConfiguration(): CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationOutputReference;
    putFirehoseConfiguration(value: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration): void;
    resetFirehoseConfiguration(): void;
    get firehoseConfigurationInput(): cdktn.IResolvable | CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | undefined;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    resetLogLevel(): void;
    get logLevelInput(): string | undefined;
    private _s3Configuration;
    get s3Configuration(): CognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationOutputReference;
    putS3Configuration(value: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration): void;
    resetS3Configuration(): void;
    get s3ConfigurationInput(): cdktn.IResolvable | CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | undefined;
}
export declare class CognitoLogDeliveryConfigurationLogConfigurationsList extends cdktn.ComplexList {
    internalValue?: CognitoLogDeliveryConfigurationLogConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoLogDeliveryConfigurationLogConfigurationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration awscc_cognito_log_delivery_configuration}
*/
export declare class CognitoLogDeliveryConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_log_delivery_configuration";
    /**
    * Generates CDKTN code for importing a CognitoLogDeliveryConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoLogDeliveryConfiguration to import
    * @param importFromId The id of the existing CognitoLogDeliveryConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoLogDeliveryConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_log_delivery_configuration awscc_cognito_log_delivery_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoLogDeliveryConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: CognitoLogDeliveryConfigurationConfig);
    get id(): string;
    private _logConfigurations;
    get logConfigurations(): CognitoLogDeliveryConfigurationLogConfigurationsList;
    putLogConfigurations(value: CognitoLogDeliveryConfigurationLogConfigurations[] | cdktn.IResolvable): void;
    resetLogConfigurations(): void;
    get logConfigurationsInput(): cdktn.IResolvable | CognitoLogDeliveryConfigurationLogConfigurations[] | undefined;
    get logDeliveryConfigurationId(): string;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
