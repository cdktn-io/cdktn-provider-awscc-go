/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AmplifyAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#access_token AmplifyApp#access_token}
    */
    readonly accessToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#auto_branch_creation_config AmplifyApp#auto_branch_creation_config}
    */
    readonly autoBranchCreationConfig?: AmplifyAppAutoBranchCreationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#basic_auth_config AmplifyApp#basic_auth_config}
    */
    readonly basicAuthConfig?: AmplifyAppBasicAuthConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#build_spec AmplifyApp#build_spec}
    */
    readonly buildSpec?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#cache_config AmplifyApp#cache_config}
    */
    readonly cacheConfig?: AmplifyAppCacheConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#compute_role_arn AmplifyApp#compute_role_arn}
    */
    readonly computeRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#custom_headers AmplifyApp#custom_headers}
    */
    readonly customHeaders?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#custom_rules AmplifyApp#custom_rules}
    */
    readonly customRules?: AmplifyAppCustomRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#description AmplifyApp#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#enable_branch_auto_deletion AmplifyApp#enable_branch_auto_deletion}
    */
    readonly enableBranchAutoDeletion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#environment_variables AmplifyApp#environment_variables}
    */
    readonly environmentVariables?: AmplifyAppEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#iam_service_role AmplifyApp#iam_service_role}
    */
    readonly iamServiceRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#job_config AmplifyApp#job_config}
    */
    readonly jobConfig?: AmplifyAppJobConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#name AmplifyApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#oauth_token AmplifyApp#oauth_token}
    */
    readonly oauthToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#platform AmplifyApp#platform}
    */
    readonly platform?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#repository AmplifyApp#repository}
    */
    readonly repository?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#tags AmplifyApp#tags}
    */
    readonly tags?: AmplifyAppTags[] | cdktn.IResolvable;
}
export interface AmplifyAppAutoBranchCreationConfigBasicAuthConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#enable_basic_auth AmplifyApp#enable_basic_auth}
    */
    readonly enableBasicAuth?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#password AmplifyApp#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#username AmplifyApp#username}
    */
    readonly username?: string;
}
export declare function amplifyAppAutoBranchCreationConfigBasicAuthConfigToTerraform(struct?: AmplifyAppAutoBranchCreationConfigBasicAuthConfig | cdktn.IResolvable): any;
export declare function amplifyAppAutoBranchCreationConfigBasicAuthConfigToHclTerraform(struct?: AmplifyAppAutoBranchCreationConfigBasicAuthConfig | cdktn.IResolvable): any;
export declare class AmplifyAppAutoBranchCreationConfigBasicAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyAppAutoBranchCreationConfigBasicAuthConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppAutoBranchCreationConfigBasicAuthConfig | cdktn.IResolvable | undefined);
    private _enableBasicAuth?;
    get enableBasicAuth(): boolean | cdktn.IResolvable;
    set enableBasicAuth(value: boolean | cdktn.IResolvable);
    resetEnableBasicAuth(): void;
    get enableBasicAuthInput(): boolean | cdktn.IResolvable | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AmplifyAppAutoBranchCreationConfigEnvironmentVariables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#name AmplifyApp#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#value AmplifyApp#value}
    */
    readonly value?: string;
}
export declare function amplifyAppAutoBranchCreationConfigEnvironmentVariablesToTerraform(struct?: AmplifyAppAutoBranchCreationConfigEnvironmentVariables | cdktn.IResolvable): any;
export declare function amplifyAppAutoBranchCreationConfigEnvironmentVariablesToHclTerraform(struct?: AmplifyAppAutoBranchCreationConfigEnvironmentVariables | cdktn.IResolvable): any;
export declare class AmplifyAppAutoBranchCreationConfigEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmplifyAppAutoBranchCreationConfigEnvironmentVariables | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppAutoBranchCreationConfigEnvironmentVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AmplifyAppAutoBranchCreationConfigEnvironmentVariablesList extends cdktn.ComplexList {
    internalValue?: AmplifyAppAutoBranchCreationConfigEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmplifyAppAutoBranchCreationConfigEnvironmentVariablesOutputReference;
}
export interface AmplifyAppAutoBranchCreationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#auto_branch_creation_patterns AmplifyApp#auto_branch_creation_patterns}
    */
    readonly autoBranchCreationPatterns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#basic_auth_config AmplifyApp#basic_auth_config}
    */
    readonly basicAuthConfig?: AmplifyAppAutoBranchCreationConfigBasicAuthConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#build_spec AmplifyApp#build_spec}
    */
    readonly buildSpec?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#enable_auto_branch_creation AmplifyApp#enable_auto_branch_creation}
    */
    readonly enableAutoBranchCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#enable_auto_build AmplifyApp#enable_auto_build}
    */
    readonly enableAutoBuild?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#enable_performance_mode AmplifyApp#enable_performance_mode}
    */
    readonly enablePerformanceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#enable_pull_request_preview AmplifyApp#enable_pull_request_preview}
    */
    readonly enablePullRequestPreview?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#environment_variables AmplifyApp#environment_variables}
    */
    readonly environmentVariables?: AmplifyAppAutoBranchCreationConfigEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#framework AmplifyApp#framework}
    */
    readonly framework?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#pull_request_environment_name AmplifyApp#pull_request_environment_name}
    */
    readonly pullRequestEnvironmentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#stage AmplifyApp#stage}
    */
    readonly stage?: string;
}
export declare function amplifyAppAutoBranchCreationConfigToTerraform(struct?: AmplifyAppAutoBranchCreationConfig | cdktn.IResolvable): any;
export declare function amplifyAppAutoBranchCreationConfigToHclTerraform(struct?: AmplifyAppAutoBranchCreationConfig | cdktn.IResolvable): any;
export declare class AmplifyAppAutoBranchCreationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyAppAutoBranchCreationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppAutoBranchCreationConfig | cdktn.IResolvable | undefined);
    private _autoBranchCreationPatterns?;
    get autoBranchCreationPatterns(): string[];
    set autoBranchCreationPatterns(value: string[]);
    resetAutoBranchCreationPatterns(): void;
    get autoBranchCreationPatternsInput(): string[] | undefined;
    private _basicAuthConfig;
    get basicAuthConfig(): AmplifyAppAutoBranchCreationConfigBasicAuthConfigOutputReference;
    putBasicAuthConfig(value: AmplifyAppAutoBranchCreationConfigBasicAuthConfig): void;
    resetBasicAuthConfig(): void;
    get basicAuthConfigInput(): cdktn.IResolvable | AmplifyAppAutoBranchCreationConfigBasicAuthConfig | undefined;
    private _buildSpec?;
    get buildSpec(): string;
    set buildSpec(value: string);
    resetBuildSpec(): void;
    get buildSpecInput(): string | undefined;
    private _enableAutoBranchCreation?;
    get enableAutoBranchCreation(): boolean | cdktn.IResolvable;
    set enableAutoBranchCreation(value: boolean | cdktn.IResolvable);
    resetEnableAutoBranchCreation(): void;
    get enableAutoBranchCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _enableAutoBuild?;
    get enableAutoBuild(): boolean | cdktn.IResolvable;
    set enableAutoBuild(value: boolean | cdktn.IResolvable);
    resetEnableAutoBuild(): void;
    get enableAutoBuildInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePerformanceMode?;
    get enablePerformanceMode(): boolean | cdktn.IResolvable;
    set enablePerformanceMode(value: boolean | cdktn.IResolvable);
    resetEnablePerformanceMode(): void;
    get enablePerformanceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePullRequestPreview?;
    get enablePullRequestPreview(): boolean | cdktn.IResolvable;
    set enablePullRequestPreview(value: boolean | cdktn.IResolvable);
    resetEnablePullRequestPreview(): void;
    get enablePullRequestPreviewInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentVariables;
    get environmentVariables(): AmplifyAppAutoBranchCreationConfigEnvironmentVariablesList;
    putEnvironmentVariables(value: AmplifyAppAutoBranchCreationConfigEnvironmentVariables[] | cdktn.IResolvable): void;
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): cdktn.IResolvable | AmplifyAppAutoBranchCreationConfigEnvironmentVariables[] | undefined;
    private _framework?;
    get framework(): string;
    set framework(value: string);
    resetFramework(): void;
    get frameworkInput(): string | undefined;
    private _pullRequestEnvironmentName?;
    get pullRequestEnvironmentName(): string;
    set pullRequestEnvironmentName(value: string);
    resetPullRequestEnvironmentName(): void;
    get pullRequestEnvironmentNameInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    resetStage(): void;
    get stageInput(): string | undefined;
}
export interface AmplifyAppBasicAuthConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#enable_basic_auth AmplifyApp#enable_basic_auth}
    */
    readonly enableBasicAuth?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#password AmplifyApp#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#username AmplifyApp#username}
    */
    readonly username?: string;
}
export declare function amplifyAppBasicAuthConfigToTerraform(struct?: AmplifyAppBasicAuthConfig | cdktn.IResolvable): any;
export declare function amplifyAppBasicAuthConfigToHclTerraform(struct?: AmplifyAppBasicAuthConfig | cdktn.IResolvable): any;
export declare class AmplifyAppBasicAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyAppBasicAuthConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppBasicAuthConfig | cdktn.IResolvable | undefined);
    private _enableBasicAuth?;
    get enableBasicAuth(): boolean | cdktn.IResolvable;
    set enableBasicAuth(value: boolean | cdktn.IResolvable);
    resetEnableBasicAuth(): void;
    get enableBasicAuthInput(): boolean | cdktn.IResolvable | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface AmplifyAppCacheConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#type AmplifyApp#type}
    */
    readonly type?: string;
}
export declare function amplifyAppCacheConfigToTerraform(struct?: AmplifyAppCacheConfig | cdktn.IResolvable): any;
export declare function amplifyAppCacheConfigToHclTerraform(struct?: AmplifyAppCacheConfig | cdktn.IResolvable): any;
export declare class AmplifyAppCacheConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyAppCacheConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppCacheConfig | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface AmplifyAppCustomRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#condition AmplifyApp#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#source AmplifyApp#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#status AmplifyApp#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#target AmplifyApp#target}
    */
    readonly target?: string;
}
export declare function amplifyAppCustomRulesToTerraform(struct?: AmplifyAppCustomRules | cdktn.IResolvable): any;
export declare function amplifyAppCustomRulesToHclTerraform(struct?: AmplifyAppCustomRules | cdktn.IResolvable): any;
export declare class AmplifyAppCustomRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmplifyAppCustomRules | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppCustomRules | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
}
export declare class AmplifyAppCustomRulesList extends cdktn.ComplexList {
    internalValue?: AmplifyAppCustomRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmplifyAppCustomRulesOutputReference;
}
export interface AmplifyAppEnvironmentVariables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#name AmplifyApp#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#value AmplifyApp#value}
    */
    readonly value?: string;
}
export declare function amplifyAppEnvironmentVariablesToTerraform(struct?: AmplifyAppEnvironmentVariables | cdktn.IResolvable): any;
export declare function amplifyAppEnvironmentVariablesToHclTerraform(struct?: AmplifyAppEnvironmentVariables | cdktn.IResolvable): any;
export declare class AmplifyAppEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmplifyAppEnvironmentVariables | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppEnvironmentVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AmplifyAppEnvironmentVariablesList extends cdktn.ComplexList {
    internalValue?: AmplifyAppEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmplifyAppEnvironmentVariablesOutputReference;
}
export interface AmplifyAppJobConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#build_compute_type AmplifyApp#build_compute_type}
    */
    readonly buildComputeType?: string;
}
export declare function amplifyAppJobConfigToTerraform(struct?: AmplifyAppJobConfig | cdktn.IResolvable): any;
export declare function amplifyAppJobConfigToHclTerraform(struct?: AmplifyAppJobConfig | cdktn.IResolvable): any;
export declare class AmplifyAppJobConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AmplifyAppJobConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppJobConfig | cdktn.IResolvable | undefined);
    private _buildComputeType?;
    get buildComputeType(): string;
    set buildComputeType(value: string);
    resetBuildComputeType(): void;
    get buildComputeTypeInput(): string | undefined;
}
export interface AmplifyAppTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#key AmplifyApp#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#value AmplifyApp#value}
    */
    readonly value?: string;
}
export declare function amplifyAppTagsToTerraform(struct?: AmplifyAppTags | cdktn.IResolvable): any;
export declare function amplifyAppTagsToHclTerraform(struct?: AmplifyAppTags | cdktn.IResolvable): any;
export declare class AmplifyAppTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AmplifyAppTags | cdktn.IResolvable | undefined;
    set internalValue(value: AmplifyAppTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AmplifyAppTagsList extends cdktn.ComplexList {
    internalValue?: AmplifyAppTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AmplifyAppTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app awscc_amplify_app}
*/
export declare class AmplifyApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_amplify_app";
    /**
    * Generates CDKTN code for importing a AmplifyApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AmplifyApp to import
    * @param importFromId The id of the existing AmplifyApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AmplifyApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/amplify_app awscc_amplify_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AmplifyAppConfig
    */
    constructor(scope: Construct, id: string, config: AmplifyAppConfig);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    get appId(): string;
    get appName(): string;
    get arn(): string;
    private _autoBranchCreationConfig;
    get autoBranchCreationConfig(): AmplifyAppAutoBranchCreationConfigOutputReference;
    putAutoBranchCreationConfig(value: AmplifyAppAutoBranchCreationConfig): void;
    resetAutoBranchCreationConfig(): void;
    get autoBranchCreationConfigInput(): cdktn.IResolvable | AmplifyAppAutoBranchCreationConfig | undefined;
    private _basicAuthConfig;
    get basicAuthConfig(): AmplifyAppBasicAuthConfigOutputReference;
    putBasicAuthConfig(value: AmplifyAppBasicAuthConfig): void;
    resetBasicAuthConfig(): void;
    get basicAuthConfigInput(): cdktn.IResolvable | AmplifyAppBasicAuthConfig | undefined;
    private _buildSpec?;
    get buildSpec(): string;
    set buildSpec(value: string);
    resetBuildSpec(): void;
    get buildSpecInput(): string | undefined;
    private _cacheConfig;
    get cacheConfig(): AmplifyAppCacheConfigOutputReference;
    putCacheConfig(value: AmplifyAppCacheConfig): void;
    resetCacheConfig(): void;
    get cacheConfigInput(): cdktn.IResolvable | AmplifyAppCacheConfig | undefined;
    private _computeRoleArn?;
    get computeRoleArn(): string;
    set computeRoleArn(value: string);
    resetComputeRoleArn(): void;
    get computeRoleArnInput(): string | undefined;
    private _customHeaders?;
    get customHeaders(): string;
    set customHeaders(value: string);
    resetCustomHeaders(): void;
    get customHeadersInput(): string | undefined;
    private _customRules;
    get customRules(): AmplifyAppCustomRulesList;
    putCustomRules(value: AmplifyAppCustomRules[] | cdktn.IResolvable): void;
    resetCustomRules(): void;
    get customRulesInput(): cdktn.IResolvable | AmplifyAppCustomRules[] | undefined;
    get defaultDomain(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableBranchAutoDeletion?;
    get enableBranchAutoDeletion(): boolean | cdktn.IResolvable;
    set enableBranchAutoDeletion(value: boolean | cdktn.IResolvable);
    resetEnableBranchAutoDeletion(): void;
    get enableBranchAutoDeletionInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentVariables;
    get environmentVariables(): AmplifyAppEnvironmentVariablesList;
    putEnvironmentVariables(value: AmplifyAppEnvironmentVariables[] | cdktn.IResolvable): void;
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): cdktn.IResolvable | AmplifyAppEnvironmentVariables[] | undefined;
    private _iamServiceRole?;
    get iamServiceRole(): string;
    set iamServiceRole(value: string);
    resetIamServiceRole(): void;
    get iamServiceRoleInput(): string | undefined;
    get id(): string;
    private _jobConfig;
    get jobConfig(): AmplifyAppJobConfigOutputReference;
    putJobConfig(value: AmplifyAppJobConfig): void;
    resetJobConfig(): void;
    get jobConfigInput(): cdktn.IResolvable | AmplifyAppJobConfig | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _oauthToken?;
    get oauthToken(): string;
    set oauthToken(value: string);
    resetOauthToken(): void;
    get oauthTokenInput(): string | undefined;
    private _platform?;
    get platform(): string;
    set platform(value: string);
    resetPlatform(): void;
    get platformInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _tags;
    get tags(): AmplifyAppTagsList;
    putTags(value: AmplifyAppTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AmplifyAppTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
