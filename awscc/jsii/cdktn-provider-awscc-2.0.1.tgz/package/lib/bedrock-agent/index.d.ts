/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of ActionGroups
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#action_groups BedrockAgent#action_groups}
    */
    readonly actionGroups?: BedrockAgentActionGroups[] | cdktn.IResolvable;
    /**
    * Agent collaboration state
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#agent_collaboration BedrockAgent#agent_collaboration}
    */
    readonly agentCollaboration?: string;
    /**
    * List of Agent Collaborators
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#agent_collaborators BedrockAgent#agent_collaborators}
    */
    readonly agentCollaborators?: BedrockAgentAgentCollaborators[] | cdktn.IResolvable;
    /**
    * Name for a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#agent_name BedrockAgent#agent_name}
    */
    readonly agentName: string;
    /**
    * ARN of a IAM role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#agent_resource_role_arn BedrockAgent#agent_resource_role_arn}
    */
    readonly agentResourceRoleArn?: string;
    /**
    * Specifies whether to automatically prepare after creating or updating the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#auto_prepare BedrockAgent#auto_prepare}
    */
    readonly autoPrepare?: boolean | cdktn.IResolvable;
    /**
    * Structure for custom orchestration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#custom_orchestration BedrockAgent#custom_orchestration}
    */
    readonly customOrchestration?: BedrockAgentCustomOrchestration;
    /**
    * A KMS key ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#customer_encryption_key_arn BedrockAgent#customer_encryption_key_arn}
    */
    readonly customerEncryptionKeyArn?: string;
    /**
    * Description of the Resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#description BedrockAgent#description}
    */
    readonly description?: string;
    /**
    * ARN or name of a Bedrock model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#foundation_model BedrockAgent#foundation_model}
    */
    readonly foundationModel?: string;
    /**
    * Configuration for a guardrail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#guardrail_configuration BedrockAgent#guardrail_configuration}
    */
    readonly guardrailConfiguration?: BedrockAgentGuardrailConfiguration;
    /**
    * Max Session Time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#idle_session_ttl_in_seconds BedrockAgent#idle_session_ttl_in_seconds}
    */
    readonly idleSessionTtlInSeconds?: number;
    /**
    * Instruction for the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#instruction BedrockAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * List of Agent Knowledge Bases
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#knowledge_bases BedrockAgent#knowledge_bases}
    */
    readonly knowledgeBases?: BedrockAgentKnowledgeBases[] | cdktn.IResolvable;
    /**
    * Configuration for memory storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#memory_configuration BedrockAgent#memory_configuration}
    */
    readonly memoryConfiguration?: BedrockAgentMemoryConfiguration;
    /**
    * Types of orchestration strategy for agents
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#orchestration_type BedrockAgent#orchestration_type}
    */
    readonly orchestrationType?: string;
    /**
    * Configuration for prompt override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#prompt_override_configuration BedrockAgent#prompt_override_configuration}
    */
    readonly promptOverrideConfiguration?: BedrockAgentPromptOverrideConfiguration;
    /**
    * Specifies whether to allow deleting agent while it is in use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#skip_resource_in_use_check_on_delete BedrockAgent#skip_resource_in_use_check_on_delete}
    */
    readonly skipResourceInUseCheckOnDelete?: boolean | cdktn.IResolvable;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#tags BedrockAgent#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#test_alias_tags BedrockAgent#test_alias_tags}
    */
    readonly testAliasTags?: {
        [key: string]: string;
    };
}
export interface BedrockAgentActionGroupsActionGroupExecutor {
    /**
    * Custom control of action execution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#custom_control BedrockAgent#custom_control}
    */
    readonly customControl?: string;
    /**
    * ARN of a Lambda.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#lambda BedrockAgent#lambda}
    */
    readonly lambda?: string;
}
export declare function bedrockAgentActionGroupsActionGroupExecutorToTerraform(struct?: BedrockAgentActionGroupsActionGroupExecutor | cdktn.IResolvable): any;
export declare function bedrockAgentActionGroupsActionGroupExecutorToHclTerraform(struct?: BedrockAgentActionGroupsActionGroupExecutor | cdktn.IResolvable): any;
export declare class BedrockAgentActionGroupsActionGroupExecutorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentActionGroupsActionGroupExecutor | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentActionGroupsActionGroupExecutor | cdktn.IResolvable | undefined);
    private _customControl?;
    get customControl(): string;
    set customControl(value: string);
    resetCustomControl(): void;
    get customControlInput(): string | undefined;
    private _lambda?;
    get lambda(): string;
    set lambda(value: string);
    resetLambda(): void;
    get lambdaInput(): string | undefined;
}
export interface BedrockAgentActionGroupsApiSchemaS3 {
    /**
    * A bucket in S3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#s3_bucket_name BedrockAgent#s3_bucket_name}
    */
    readonly s3BucketName?: string;
    /**
    * A object key in S3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#s3_object_key BedrockAgent#s3_object_key}
    */
    readonly s3ObjectKey?: string;
}
export declare function bedrockAgentActionGroupsApiSchemaS3ToTerraform(struct?: BedrockAgentActionGroupsApiSchemaS3 | cdktn.IResolvable): any;
export declare function bedrockAgentActionGroupsApiSchemaS3ToHclTerraform(struct?: BedrockAgentActionGroupsApiSchemaS3 | cdktn.IResolvable): any;
export declare class BedrockAgentActionGroupsApiSchemaS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentActionGroupsApiSchemaS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentActionGroupsApiSchemaS3 | cdktn.IResolvable | undefined);
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    resetS3BucketName(): void;
    get s3BucketNameInput(): string | undefined;
    private _s3ObjectKey?;
    get s3ObjectKey(): string;
    set s3ObjectKey(value: string);
    resetS3ObjectKey(): void;
    get s3ObjectKeyInput(): string | undefined;
}
export interface BedrockAgentActionGroupsApiSchema {
    /**
    * String OpenAPI Payload
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#payload BedrockAgent#payload}
    */
    readonly payload?: string;
    /**
    * The identifier for the S3 resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#s3 BedrockAgent#s3}
    */
    readonly s3?: BedrockAgentActionGroupsApiSchemaS3;
}
export declare function bedrockAgentActionGroupsApiSchemaToTerraform(struct?: BedrockAgentActionGroupsApiSchema | cdktn.IResolvable): any;
export declare function bedrockAgentActionGroupsApiSchemaToHclTerraform(struct?: BedrockAgentActionGroupsApiSchema | cdktn.IResolvable): any;
export declare class BedrockAgentActionGroupsApiSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentActionGroupsApiSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentActionGroupsApiSchema | cdktn.IResolvable | undefined);
    private _payload?;
    get payload(): string;
    set payload(value: string);
    resetPayload(): void;
    get payloadInput(): string | undefined;
    private _s3;
    get s3(): BedrockAgentActionGroupsApiSchemaS3OutputReference;
    putS3(value: BedrockAgentActionGroupsApiSchemaS3): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockAgentActionGroupsApiSchemaS3 | undefined;
}
export interface BedrockAgentActionGroupsFunctionSchemaFunctionsParameters {
    /**
    * Description of function parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#description BedrockAgent#description}
    */
    readonly description?: string;
    /**
    * Information about if a parameter is required for function call. Default to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#required BedrockAgent#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Parameter Type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#type BedrockAgent#type}
    */
    readonly type?: string;
}
export declare function bedrockAgentActionGroupsFunctionSchemaFunctionsParametersToTerraform(struct?: BedrockAgentActionGroupsFunctionSchemaFunctionsParameters | cdktn.IResolvable): any;
export declare function bedrockAgentActionGroupsFunctionSchemaFunctionsParametersToHclTerraform(struct?: BedrockAgentActionGroupsFunctionSchemaFunctionsParameters | cdktn.IResolvable): any;
export declare class BedrockAgentActionGroupsFunctionSchemaFunctionsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): BedrockAgentActionGroupsFunctionSchemaFunctionsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentActionGroupsFunctionSchemaFunctionsParameters | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockAgentActionGroupsFunctionSchemaFunctionsParametersMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: BedrockAgentActionGroupsFunctionSchemaFunctionsParameters;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): BedrockAgentActionGroupsFunctionSchemaFunctionsParametersOutputReference;
}
export interface BedrockAgentActionGroupsFunctionSchemaFunctions {
    /**
    * Description of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#description BedrockAgent#description}
    */
    readonly description?: string;
    /**
    * Name for a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#name BedrockAgent#name}
    */
    readonly name?: string;
    /**
    * A map of parameter name and detail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#parameters BedrockAgent#parameters}
    */
    readonly parameters?: {
        [key: string]: BedrockAgentActionGroupsFunctionSchemaFunctionsParameters;
    } | cdktn.IResolvable;
    /**
    * ENUM to check if action requires user confirmation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#require_confirmation BedrockAgent#require_confirmation}
    */
    readonly requireConfirmation?: string;
}
export declare function bedrockAgentActionGroupsFunctionSchemaFunctionsToTerraform(struct?: BedrockAgentActionGroupsFunctionSchemaFunctions | cdktn.IResolvable): any;
export declare function bedrockAgentActionGroupsFunctionSchemaFunctionsToHclTerraform(struct?: BedrockAgentActionGroupsFunctionSchemaFunctions | cdktn.IResolvable): any;
export declare class BedrockAgentActionGroupsFunctionSchemaFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAgentActionGroupsFunctionSchemaFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentActionGroupsFunctionSchemaFunctions | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): BedrockAgentActionGroupsFunctionSchemaFunctionsParametersMap;
    putParameters(value: {
        [key: string]: BedrockAgentActionGroupsFunctionSchemaFunctionsParameters;
    } | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | {
        [key: string]: BedrockAgentActionGroupsFunctionSchemaFunctionsParameters;
    } | undefined;
    private _requireConfirmation?;
    get requireConfirmation(): string;
    set requireConfirmation(value: string);
    resetRequireConfirmation(): void;
    get requireConfirmationInput(): string | undefined;
}
export declare class BedrockAgentActionGroupsFunctionSchemaFunctionsList extends cdktn.ComplexList {
    internalValue?: BedrockAgentActionGroupsFunctionSchemaFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAgentActionGroupsFunctionSchemaFunctionsOutputReference;
}
export interface BedrockAgentActionGroupsFunctionSchema {
    /**
    * List of Function definitions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#functions BedrockAgent#functions}
    */
    readonly functions?: BedrockAgentActionGroupsFunctionSchemaFunctions[] | cdktn.IResolvable;
}
export declare function bedrockAgentActionGroupsFunctionSchemaToTerraform(struct?: BedrockAgentActionGroupsFunctionSchema | cdktn.IResolvable): any;
export declare function bedrockAgentActionGroupsFunctionSchemaToHclTerraform(struct?: BedrockAgentActionGroupsFunctionSchema | cdktn.IResolvable): any;
export declare class BedrockAgentActionGroupsFunctionSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentActionGroupsFunctionSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentActionGroupsFunctionSchema | cdktn.IResolvable | undefined);
    private _functions;
    get functions(): BedrockAgentActionGroupsFunctionSchemaFunctionsList;
    putFunctions(value: BedrockAgentActionGroupsFunctionSchemaFunctions[] | cdktn.IResolvable): void;
    resetFunctions(): void;
    get functionsInput(): cdktn.IResolvable | BedrockAgentActionGroupsFunctionSchemaFunctions[] | undefined;
}
export interface BedrockAgentActionGroups {
    /**
    * Type of Executors for an Action Group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#action_group_executor BedrockAgent#action_group_executor}
    */
    readonly actionGroupExecutor?: BedrockAgentActionGroupsActionGroupExecutor;
    /**
    * Name of the action group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#action_group_name BedrockAgent#action_group_name}
    */
    readonly actionGroupName?: string;
    /**
    * State of the action group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#action_group_state BedrockAgent#action_group_state}
    */
    readonly actionGroupState?: string;
    /**
    * Contains information about the API Schema for the Action Group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#api_schema BedrockAgent#api_schema}
    */
    readonly apiSchema?: BedrockAgentActionGroupsApiSchema;
    /**
    * Description of action group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#description BedrockAgent#description}
    */
    readonly description?: string;
    /**
    * Schema of Functions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#function_schema BedrockAgent#function_schema}
    */
    readonly functionSchema?: BedrockAgentActionGroupsFunctionSchema;
    /**
    * Action Group Signature for a BuiltIn Action
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#parent_action_group_signature BedrockAgent#parent_action_group_signature}
    */
    readonly parentActionGroupSignature?: string;
    /**
    * Specifies whether to allow deleting action group while it is in use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#skip_resource_in_use_check_on_delete BedrockAgent#skip_resource_in_use_check_on_delete}
    */
    readonly skipResourceInUseCheckOnDelete?: boolean | cdktn.IResolvable;
}
export declare function bedrockAgentActionGroupsToTerraform(struct?: BedrockAgentActionGroups | cdktn.IResolvable): any;
export declare function bedrockAgentActionGroupsToHclTerraform(struct?: BedrockAgentActionGroups | cdktn.IResolvable): any;
export declare class BedrockAgentActionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAgentActionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentActionGroups | cdktn.IResolvable | undefined);
    private _actionGroupExecutor;
    get actionGroupExecutor(): BedrockAgentActionGroupsActionGroupExecutorOutputReference;
    putActionGroupExecutor(value: BedrockAgentActionGroupsActionGroupExecutor): void;
    resetActionGroupExecutor(): void;
    get actionGroupExecutorInput(): cdktn.IResolvable | BedrockAgentActionGroupsActionGroupExecutor | undefined;
    private _actionGroupName?;
    get actionGroupName(): string;
    set actionGroupName(value: string);
    resetActionGroupName(): void;
    get actionGroupNameInput(): string | undefined;
    private _actionGroupState?;
    get actionGroupState(): string;
    set actionGroupState(value: string);
    resetActionGroupState(): void;
    get actionGroupStateInput(): string | undefined;
    private _apiSchema;
    get apiSchema(): BedrockAgentActionGroupsApiSchemaOutputReference;
    putApiSchema(value: BedrockAgentActionGroupsApiSchema): void;
    resetApiSchema(): void;
    get apiSchemaInput(): cdktn.IResolvable | BedrockAgentActionGroupsApiSchema | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _functionSchema;
    get functionSchema(): BedrockAgentActionGroupsFunctionSchemaOutputReference;
    putFunctionSchema(value: BedrockAgentActionGroupsFunctionSchema): void;
    resetFunctionSchema(): void;
    get functionSchemaInput(): cdktn.IResolvable | BedrockAgentActionGroupsFunctionSchema | undefined;
    private _parentActionGroupSignature?;
    get parentActionGroupSignature(): string;
    set parentActionGroupSignature(value: string);
    resetParentActionGroupSignature(): void;
    get parentActionGroupSignatureInput(): string | undefined;
    private _skipResourceInUseCheckOnDelete?;
    get skipResourceInUseCheckOnDelete(): boolean | cdktn.IResolvable;
    set skipResourceInUseCheckOnDelete(value: boolean | cdktn.IResolvable);
    resetSkipResourceInUseCheckOnDelete(): void;
    get skipResourceInUseCheckOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class BedrockAgentActionGroupsList extends cdktn.ComplexList {
    internalValue?: BedrockAgentActionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAgentActionGroupsOutputReference;
}
export interface BedrockAgentAgentCollaboratorsAgentDescriptor {
    /**
    * Alias ARN for agent descriptor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#alias_arn BedrockAgent#alias_arn}
    */
    readonly aliasArn?: string;
}
export declare function bedrockAgentAgentCollaboratorsAgentDescriptorToTerraform(struct?: BedrockAgentAgentCollaboratorsAgentDescriptor | cdktn.IResolvable): any;
export declare function bedrockAgentAgentCollaboratorsAgentDescriptorToHclTerraform(struct?: BedrockAgentAgentCollaboratorsAgentDescriptor | cdktn.IResolvable): any;
export declare class BedrockAgentAgentCollaboratorsAgentDescriptorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentAgentCollaboratorsAgentDescriptor | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentAgentCollaboratorsAgentDescriptor | cdktn.IResolvable | undefined);
    private _aliasArn?;
    get aliasArn(): string;
    set aliasArn(value: string);
    resetAliasArn(): void;
    get aliasArnInput(): string | undefined;
}
export interface BedrockAgentAgentCollaborators {
    /**
    * Agent descriptor for agent collaborator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#agent_descriptor BedrockAgent#agent_descriptor}
    */
    readonly agentDescriptor?: BedrockAgentAgentCollaboratorsAgentDescriptor;
    /**
    * Agent collaborator instruction
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#collaboration_instruction BedrockAgent#collaboration_instruction}
    */
    readonly collaborationInstruction?: string;
    /**
    * Agent collaborator name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#collaborator_name BedrockAgent#collaborator_name}
    */
    readonly collaboratorName?: string;
    /**
    * Relay conversation history state
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#relay_conversation_history BedrockAgent#relay_conversation_history}
    */
    readonly relayConversationHistory?: string;
}
export declare function bedrockAgentAgentCollaboratorsToTerraform(struct?: BedrockAgentAgentCollaborators | cdktn.IResolvable): any;
export declare function bedrockAgentAgentCollaboratorsToHclTerraform(struct?: BedrockAgentAgentCollaborators | cdktn.IResolvable): any;
export declare class BedrockAgentAgentCollaboratorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAgentAgentCollaborators | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentAgentCollaborators | cdktn.IResolvable | undefined);
    private _agentDescriptor;
    get agentDescriptor(): BedrockAgentAgentCollaboratorsAgentDescriptorOutputReference;
    putAgentDescriptor(value: BedrockAgentAgentCollaboratorsAgentDescriptor): void;
    resetAgentDescriptor(): void;
    get agentDescriptorInput(): cdktn.IResolvable | BedrockAgentAgentCollaboratorsAgentDescriptor | undefined;
    private _collaborationInstruction?;
    get collaborationInstruction(): string;
    set collaborationInstruction(value: string);
    resetCollaborationInstruction(): void;
    get collaborationInstructionInput(): string | undefined;
    private _collaboratorName?;
    get collaboratorName(): string;
    set collaboratorName(value: string);
    resetCollaboratorName(): void;
    get collaboratorNameInput(): string | undefined;
    private _relayConversationHistory?;
    get relayConversationHistory(): string;
    set relayConversationHistory(value: string);
    resetRelayConversationHistory(): void;
    get relayConversationHistoryInput(): string | undefined;
}
export declare class BedrockAgentAgentCollaboratorsList extends cdktn.ComplexList {
    internalValue?: BedrockAgentAgentCollaborators[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAgentAgentCollaboratorsOutputReference;
}
export interface BedrockAgentCustomOrchestrationExecutor {
    /**
    * ARN of a Lambda.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#lambda BedrockAgent#lambda}
    */
    readonly lambda?: string;
}
export declare function bedrockAgentCustomOrchestrationExecutorToTerraform(struct?: BedrockAgentCustomOrchestrationExecutor | cdktn.IResolvable): any;
export declare function bedrockAgentCustomOrchestrationExecutorToHclTerraform(struct?: BedrockAgentCustomOrchestrationExecutor | cdktn.IResolvable): any;
export declare class BedrockAgentCustomOrchestrationExecutorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentCustomOrchestrationExecutor | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentCustomOrchestrationExecutor | cdktn.IResolvable | undefined);
    private _lambda?;
    get lambda(): string;
    set lambda(value: string);
    resetLambda(): void;
    get lambdaInput(): string | undefined;
}
export interface BedrockAgentCustomOrchestration {
    /**
    * Types of executors for custom orchestration strategy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#executor BedrockAgent#executor}
    */
    readonly executor?: BedrockAgentCustomOrchestrationExecutor;
}
export declare function bedrockAgentCustomOrchestrationToTerraform(struct?: BedrockAgentCustomOrchestration | cdktn.IResolvable): any;
export declare function bedrockAgentCustomOrchestrationToHclTerraform(struct?: BedrockAgentCustomOrchestration | cdktn.IResolvable): any;
export declare class BedrockAgentCustomOrchestrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentCustomOrchestration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentCustomOrchestration | cdktn.IResolvable | undefined);
    private _executor;
    get executor(): BedrockAgentCustomOrchestrationExecutorOutputReference;
    putExecutor(value: BedrockAgentCustomOrchestrationExecutor): void;
    resetExecutor(): void;
    get executorInput(): cdktn.IResolvable | BedrockAgentCustomOrchestrationExecutor | undefined;
}
export interface BedrockAgentGuardrailConfiguration {
    /**
    * Identifier for the guardrail, could be the id or the arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#guardrail_identifier BedrockAgent#guardrail_identifier}
    */
    readonly guardrailIdentifier?: string;
    /**
    * Version of the guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#guardrail_version BedrockAgent#guardrail_version}
    */
    readonly guardrailVersion?: string;
}
export declare function bedrockAgentGuardrailConfigurationToTerraform(struct?: BedrockAgentGuardrailConfiguration | cdktn.IResolvable): any;
export declare function bedrockAgentGuardrailConfigurationToHclTerraform(struct?: BedrockAgentGuardrailConfiguration | cdktn.IResolvable): any;
export declare class BedrockAgentGuardrailConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentGuardrailConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentGuardrailConfiguration | cdktn.IResolvable | undefined);
    private _guardrailIdentifier?;
    get guardrailIdentifier(): string;
    set guardrailIdentifier(value: string);
    resetGuardrailIdentifier(): void;
    get guardrailIdentifierInput(): string | undefined;
    private _guardrailVersion?;
    get guardrailVersion(): string;
    set guardrailVersion(value: string);
    resetGuardrailVersion(): void;
    get guardrailVersionInput(): string | undefined;
}
export interface BedrockAgentKnowledgeBases {
    /**
    * Description of the Resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#description BedrockAgent#description}
    */
    readonly description?: string;
    /**
    * Identifier for a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#knowledge_base_id BedrockAgent#knowledge_base_id}
    */
    readonly knowledgeBaseId?: string;
    /**
    * State of the knowledge base; whether it is enabled or disabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#knowledge_base_state BedrockAgent#knowledge_base_state}
    */
    readonly knowledgeBaseState?: string;
}
export declare function bedrockAgentKnowledgeBasesToTerraform(struct?: BedrockAgentKnowledgeBases | cdktn.IResolvable): any;
export declare function bedrockAgentKnowledgeBasesToHclTerraform(struct?: BedrockAgentKnowledgeBases | cdktn.IResolvable): any;
export declare class BedrockAgentKnowledgeBasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAgentKnowledgeBases | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentKnowledgeBases | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _knowledgeBaseId?;
    get knowledgeBaseId(): string;
    set knowledgeBaseId(value: string);
    resetKnowledgeBaseId(): void;
    get knowledgeBaseIdInput(): string | undefined;
    private _knowledgeBaseState?;
    get knowledgeBaseState(): string;
    set knowledgeBaseState(value: string);
    resetKnowledgeBaseState(): void;
    get knowledgeBaseStateInput(): string | undefined;
}
export declare class BedrockAgentKnowledgeBasesList extends cdktn.ComplexList {
    internalValue?: BedrockAgentKnowledgeBases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAgentKnowledgeBasesOutputReference;
}
export interface BedrockAgentMemoryConfigurationSessionSummaryConfiguration {
    /**
    * Maximum number of Sessions to Summarize
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#max_recent_sessions BedrockAgent#max_recent_sessions}
    */
    readonly maxRecentSessions?: number;
}
export declare function bedrockAgentMemoryConfigurationSessionSummaryConfigurationToTerraform(struct?: BedrockAgentMemoryConfigurationSessionSummaryConfiguration | cdktn.IResolvable): any;
export declare function bedrockAgentMemoryConfigurationSessionSummaryConfigurationToHclTerraform(struct?: BedrockAgentMemoryConfigurationSessionSummaryConfiguration | cdktn.IResolvable): any;
export declare class BedrockAgentMemoryConfigurationSessionSummaryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentMemoryConfigurationSessionSummaryConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentMemoryConfigurationSessionSummaryConfiguration | cdktn.IResolvable | undefined);
    private _maxRecentSessions?;
    get maxRecentSessions(): number;
    set maxRecentSessions(value: number);
    resetMaxRecentSessions(): void;
    get maxRecentSessionsInput(): number | undefined;
}
export interface BedrockAgentMemoryConfiguration {
    /**
    * Types of session storage persisted in memory
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#enabled_memory_types BedrockAgent#enabled_memory_types}
    */
    readonly enabledMemoryTypes?: string[];
    /**
    * Configuration for Session Summarization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#session_summary_configuration BedrockAgent#session_summary_configuration}
    */
    readonly sessionSummaryConfiguration?: BedrockAgentMemoryConfigurationSessionSummaryConfiguration;
    /**
    * Maximum number of days to store session details
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#storage_days BedrockAgent#storage_days}
    */
    readonly storageDays?: number;
}
export declare function bedrockAgentMemoryConfigurationToTerraform(struct?: BedrockAgentMemoryConfiguration | cdktn.IResolvable): any;
export declare function bedrockAgentMemoryConfigurationToHclTerraform(struct?: BedrockAgentMemoryConfiguration | cdktn.IResolvable): any;
export declare class BedrockAgentMemoryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentMemoryConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentMemoryConfiguration | cdktn.IResolvable | undefined);
    private _enabledMemoryTypes?;
    get enabledMemoryTypes(): string[];
    set enabledMemoryTypes(value: string[]);
    resetEnabledMemoryTypes(): void;
    get enabledMemoryTypesInput(): string[] | undefined;
    private _sessionSummaryConfiguration;
    get sessionSummaryConfiguration(): BedrockAgentMemoryConfigurationSessionSummaryConfigurationOutputReference;
    putSessionSummaryConfiguration(value: BedrockAgentMemoryConfigurationSessionSummaryConfiguration): void;
    resetSessionSummaryConfiguration(): void;
    get sessionSummaryConfigurationInput(): cdktn.IResolvable | BedrockAgentMemoryConfigurationSessionSummaryConfiguration | undefined;
    private _storageDays?;
    get storageDays(): number;
    set storageDays(value: number);
    resetStorageDays(): void;
    get storageDaysInput(): number | undefined;
}
export interface BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfiguration {
    /**
    * Maximum length of output
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#maximum_length BedrockAgent#maximum_length}
    */
    readonly maximumLength?: number;
    /**
    * List of stop sequences
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#stop_sequences BedrockAgent#stop_sequences}
    */
    readonly stopSequences?: string[];
    /**
    * Controls randomness, higher values increase diversity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#temperature BedrockAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Sample from the k most likely next tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#top_k BedrockAgent#top_k}
    */
    readonly topK?: number;
    /**
    * Cumulative probability cutoff for token selection
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#top_p BedrockAgent#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfigurationToTerraform(struct?: BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfiguration | cdktn.IResolvable): any;
export declare function bedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfigurationToHclTerraform(struct?: BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfiguration | cdktn.IResolvable): any;
export declare class BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfiguration | cdktn.IResolvable | undefined);
    private _maximumLength?;
    get maximumLength(): number;
    set maximumLength(value: number);
    resetMaximumLength(): void;
    get maximumLengthInput(): number | undefined;
    private _stopSequences?;
    get stopSequences(): string[];
    set stopSequences(value: string[]);
    resetStopSequences(): void;
    get stopSequencesInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topK?;
    get topK(): number;
    set topK(value: number);
    resetTopK(): void;
    get topKInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export interface BedrockAgentPromptOverrideConfigurationPromptConfigurations {
    /**
    * Additional Model Request Fields for Prompt Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#additional_model_request_fields BedrockAgent#additional_model_request_fields}
    */
    readonly additionalModelRequestFields?: string;
    /**
    * Base Prompt Template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#base_prompt_template BedrockAgent#base_prompt_template}
    */
    readonly basePromptTemplate?: string;
    /**
    * ARN or name of a Bedrock model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#foundation_model BedrockAgent#foundation_model}
    */
    readonly foundationModel?: string;
    /**
    * Configuration for inference in prompt configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#inference_configuration BedrockAgent#inference_configuration}
    */
    readonly inferenceConfiguration?: BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfiguration;
    /**
    * Creation Mode for Prompt Configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#parser_mode BedrockAgent#parser_mode}
    */
    readonly parserMode?: string;
    /**
    * Creation Mode for Prompt Configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#prompt_creation_mode BedrockAgent#prompt_creation_mode}
    */
    readonly promptCreationMode?: string;
    /**
    * Prompt State.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#prompt_state BedrockAgent#prompt_state}
    */
    readonly promptState?: string;
    /**
    * Prompt Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#prompt_type BedrockAgent#prompt_type}
    */
    readonly promptType?: string;
}
export declare function bedrockAgentPromptOverrideConfigurationPromptConfigurationsToTerraform(struct?: BedrockAgentPromptOverrideConfigurationPromptConfigurations | cdktn.IResolvable): any;
export declare function bedrockAgentPromptOverrideConfigurationPromptConfigurationsToHclTerraform(struct?: BedrockAgentPromptOverrideConfigurationPromptConfigurations | cdktn.IResolvable): any;
export declare class BedrockAgentPromptOverrideConfigurationPromptConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAgentPromptOverrideConfigurationPromptConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentPromptOverrideConfigurationPromptConfigurations | cdktn.IResolvable | undefined);
    private _additionalModelRequestFields?;
    get additionalModelRequestFields(): string;
    set additionalModelRequestFields(value: string);
    resetAdditionalModelRequestFields(): void;
    get additionalModelRequestFieldsInput(): string | undefined;
    private _basePromptTemplate?;
    get basePromptTemplate(): string;
    set basePromptTemplate(value: string);
    resetBasePromptTemplate(): void;
    get basePromptTemplateInput(): string | undefined;
    private _foundationModel?;
    get foundationModel(): string;
    set foundationModel(value: string);
    resetFoundationModel(): void;
    get foundationModelInput(): string | undefined;
    private _inferenceConfiguration;
    get inferenceConfiguration(): BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfigurationOutputReference;
    putInferenceConfiguration(value: BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfiguration): void;
    resetInferenceConfiguration(): void;
    get inferenceConfigurationInput(): cdktn.IResolvable | BedrockAgentPromptOverrideConfigurationPromptConfigurationsInferenceConfiguration | undefined;
    private _parserMode?;
    get parserMode(): string;
    set parserMode(value: string);
    resetParserMode(): void;
    get parserModeInput(): string | undefined;
    private _promptCreationMode?;
    get promptCreationMode(): string;
    set promptCreationMode(value: string);
    resetPromptCreationMode(): void;
    get promptCreationModeInput(): string | undefined;
    private _promptState?;
    get promptState(): string;
    set promptState(value: string);
    resetPromptState(): void;
    get promptStateInput(): string | undefined;
    private _promptType?;
    get promptType(): string;
    set promptType(value: string);
    resetPromptType(): void;
    get promptTypeInput(): string | undefined;
}
export declare class BedrockAgentPromptOverrideConfigurationPromptConfigurationsList extends cdktn.ComplexList {
    internalValue?: BedrockAgentPromptOverrideConfigurationPromptConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAgentPromptOverrideConfigurationPromptConfigurationsOutputReference;
}
export interface BedrockAgentPromptOverrideConfiguration {
    /**
    * ARN of a Lambda.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#override_lambda BedrockAgent#override_lambda}
    */
    readonly overrideLambda?: string;
    /**
    * List of BasePromptConfiguration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#prompt_configurations BedrockAgent#prompt_configurations}
    */
    readonly promptConfigurations?: BedrockAgentPromptOverrideConfigurationPromptConfigurations[] | cdktn.IResolvable;
}
export declare function bedrockAgentPromptOverrideConfigurationToTerraform(struct?: BedrockAgentPromptOverrideConfiguration | cdktn.IResolvable): any;
export declare function bedrockAgentPromptOverrideConfigurationToHclTerraform(struct?: BedrockAgentPromptOverrideConfiguration | cdktn.IResolvable): any;
export declare class BedrockAgentPromptOverrideConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockAgentPromptOverrideConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentPromptOverrideConfiguration | cdktn.IResolvable | undefined);
    private _overrideLambda?;
    get overrideLambda(): string;
    set overrideLambda(value: string);
    resetOverrideLambda(): void;
    get overrideLambdaInput(): string | undefined;
    private _promptConfigurations;
    get promptConfigurations(): BedrockAgentPromptOverrideConfigurationPromptConfigurationsList;
    putPromptConfigurations(value: BedrockAgentPromptOverrideConfigurationPromptConfigurations[] | cdktn.IResolvable): void;
    resetPromptConfigurations(): void;
    get promptConfigurationsInput(): cdktn.IResolvable | BedrockAgentPromptOverrideConfigurationPromptConfigurations[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent awscc_bedrock_agent}
*/
export declare class BedrockAgent extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_agent";
    /**
    * Generates CDKTN code for importing a BedrockAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockAgent to import
    * @param importFromId The id of the existing BedrockAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent awscc_bedrock_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockAgentConfig
    */
    constructor(scope: Construct, id: string, config: BedrockAgentConfig);
    private _actionGroups;
    get actionGroups(): BedrockAgentActionGroupsList;
    putActionGroups(value: BedrockAgentActionGroups[] | cdktn.IResolvable): void;
    resetActionGroups(): void;
    get actionGroupsInput(): cdktn.IResolvable | BedrockAgentActionGroups[] | undefined;
    get agentArn(): string;
    private _agentCollaboration?;
    get agentCollaboration(): string;
    set agentCollaboration(value: string);
    resetAgentCollaboration(): void;
    get agentCollaborationInput(): string | undefined;
    private _agentCollaborators;
    get agentCollaborators(): BedrockAgentAgentCollaboratorsList;
    putAgentCollaborators(value: BedrockAgentAgentCollaborators[] | cdktn.IResolvable): void;
    resetAgentCollaborators(): void;
    get agentCollaboratorsInput(): cdktn.IResolvable | BedrockAgentAgentCollaborators[] | undefined;
    get agentId(): string;
    private _agentName?;
    get agentName(): string;
    set agentName(value: string);
    get agentNameInput(): string | undefined;
    private _agentResourceRoleArn?;
    get agentResourceRoleArn(): string;
    set agentResourceRoleArn(value: string);
    resetAgentResourceRoleArn(): void;
    get agentResourceRoleArnInput(): string | undefined;
    get agentStatus(): string;
    get agentVersion(): string;
    private _autoPrepare?;
    get autoPrepare(): boolean | cdktn.IResolvable;
    set autoPrepare(value: boolean | cdktn.IResolvable);
    resetAutoPrepare(): void;
    get autoPrepareInput(): boolean | cdktn.IResolvable | undefined;
    get createdAt(): string;
    private _customOrchestration;
    get customOrchestration(): BedrockAgentCustomOrchestrationOutputReference;
    putCustomOrchestration(value: BedrockAgentCustomOrchestration): void;
    resetCustomOrchestration(): void;
    get customOrchestrationInput(): cdktn.IResolvable | BedrockAgentCustomOrchestration | undefined;
    private _customerEncryptionKeyArn?;
    get customerEncryptionKeyArn(): string;
    set customerEncryptionKeyArn(value: string);
    resetCustomerEncryptionKeyArn(): void;
    get customerEncryptionKeyArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get failureReasons(): string[];
    private _foundationModel?;
    get foundationModel(): string;
    set foundationModel(value: string);
    resetFoundationModel(): void;
    get foundationModelInput(): string | undefined;
    private _guardrailConfiguration;
    get guardrailConfiguration(): BedrockAgentGuardrailConfigurationOutputReference;
    putGuardrailConfiguration(value: BedrockAgentGuardrailConfiguration): void;
    resetGuardrailConfiguration(): void;
    get guardrailConfigurationInput(): cdktn.IResolvable | BedrockAgentGuardrailConfiguration | undefined;
    get id(): string;
    private _idleSessionTtlInSeconds?;
    get idleSessionTtlInSeconds(): number;
    set idleSessionTtlInSeconds(value: number);
    resetIdleSessionTtlInSeconds(): void;
    get idleSessionTtlInSecondsInput(): number | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _knowledgeBases;
    get knowledgeBases(): BedrockAgentKnowledgeBasesList;
    putKnowledgeBases(value: BedrockAgentKnowledgeBases[] | cdktn.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktn.IResolvable | BedrockAgentKnowledgeBases[] | undefined;
    private _memoryConfiguration;
    get memoryConfiguration(): BedrockAgentMemoryConfigurationOutputReference;
    putMemoryConfiguration(value: BedrockAgentMemoryConfiguration): void;
    resetMemoryConfiguration(): void;
    get memoryConfigurationInput(): cdktn.IResolvable | BedrockAgentMemoryConfiguration | undefined;
    private _orchestrationType?;
    get orchestrationType(): string;
    set orchestrationType(value: string);
    resetOrchestrationType(): void;
    get orchestrationTypeInput(): string | undefined;
    get preparedAt(): string;
    private _promptOverrideConfiguration;
    get promptOverrideConfiguration(): BedrockAgentPromptOverrideConfigurationOutputReference;
    putPromptOverrideConfiguration(value: BedrockAgentPromptOverrideConfiguration): void;
    resetPromptOverrideConfiguration(): void;
    get promptOverrideConfigurationInput(): cdktn.IResolvable | BedrockAgentPromptOverrideConfiguration | undefined;
    get recommendedActions(): string[];
    private _skipResourceInUseCheckOnDelete?;
    get skipResourceInUseCheckOnDelete(): boolean | cdktn.IResolvable;
    set skipResourceInUseCheckOnDelete(value: boolean | cdktn.IResolvable);
    resetSkipResourceInUseCheckOnDelete(): void;
    get skipResourceInUseCheckOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _testAliasTags?;
    get testAliasTags(): {
        [key: string]: string;
    };
    set testAliasTags(value: {
        [key: string]: string;
    });
    resetTestAliasTags(): void;
    get testAliasTagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
