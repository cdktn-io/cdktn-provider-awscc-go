/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CasesRelatedItemConfig extends cdktn.TerraformMetaArguments {
    /**
    * A unique identifier of the case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#case_id CasesRelatedItem#case_id}
    */
    readonly caseId: string;
    /**
    * The content of a related item to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#content CasesRelatedItem#content}
    */
    readonly content: CasesRelatedItemContent;
    /**
    * The unique identifier of the Cases domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#domain_id CasesRelatedItem#domain_id}
    */
    readonly domainId: string;
    /**
    * A list of tags on the related item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#tags CasesRelatedItem#tags}
    */
    readonly tags?: CasesRelatedItemTags[] | cdktn.IResolvable;
    /**
    * The type of a related item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#type CasesRelatedItem#type}
    */
    readonly type: string;
}
export interface CasesRelatedItemContentComment {
    /**
    * Text in the body of a comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#body CasesRelatedItem#body}
    */
    readonly body?: string;
    /**
    * Type of the text in the comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#content_type CasesRelatedItem#content_type}
    */
    readonly contentType?: string;
}
export declare function casesRelatedItemContentCommentToTerraform(struct?: CasesRelatedItemContentComment | cdktn.IResolvable): any;
export declare function casesRelatedItemContentCommentToHclTerraform(struct?: CasesRelatedItemContentComment | cdktn.IResolvable): any;
export declare class CasesRelatedItemContentCommentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesRelatedItemContentComment | cdktn.IResolvable | undefined;
    set internalValue(value: CasesRelatedItemContentComment | cdktn.IResolvable | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
}
export interface CasesRelatedItemContent {
    /**
    * Represents a comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#comment CasesRelatedItem#comment}
    */
    readonly comment?: CasesRelatedItemContentComment;
}
export declare function casesRelatedItemContentToTerraform(struct?: CasesRelatedItemContent | cdktn.IResolvable): any;
export declare function casesRelatedItemContentToHclTerraform(struct?: CasesRelatedItemContent | cdktn.IResolvable): any;
export declare class CasesRelatedItemContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CasesRelatedItemContent | cdktn.IResolvable | undefined;
    set internalValue(value: CasesRelatedItemContent | cdktn.IResolvable | undefined);
    private _comment;
    get comment(): CasesRelatedItemContentCommentOutputReference;
    putComment(value: CasesRelatedItemContentComment): void;
    resetComment(): void;
    get commentInput(): cdktn.IResolvable | CasesRelatedItemContentComment | undefined;
}
export interface CasesRelatedItemTags {
    /**
    * The key of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#key CasesRelatedItem#key}
    */
    readonly key?: string;
    /**
    * The value of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#value CasesRelatedItem#value}
    */
    readonly value?: string;
}
export declare function casesRelatedItemTagsToTerraform(struct?: CasesRelatedItemTags | cdktn.IResolvable): any;
export declare function casesRelatedItemTagsToHclTerraform(struct?: CasesRelatedItemTags | cdktn.IResolvable): any;
export declare class CasesRelatedItemTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CasesRelatedItemTags | cdktn.IResolvable | undefined;
    set internalValue(value: CasesRelatedItemTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CasesRelatedItemTagsList extends cdktn.ComplexList {
    internalValue?: CasesRelatedItemTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CasesRelatedItemTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item awscc_cases_related_item}
*/
export declare class CasesRelatedItem extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cases_related_item";
    /**
    * Generates CDKTN code for importing a CasesRelatedItem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CasesRelatedItem to import
    * @param importFromId The id of the existing CasesRelatedItem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CasesRelatedItem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cases_related_item awscc_cases_related_item} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CasesRelatedItemConfig
    */
    constructor(scope: Construct, id: string, config: CasesRelatedItemConfig);
    private _caseId?;
    get caseId(): string;
    set caseId(value: string);
    get caseIdInput(): string | undefined;
    private _content;
    get content(): CasesRelatedItemContentOutputReference;
    putContent(value: CasesRelatedItemContent): void;
    get contentInput(): cdktn.IResolvable | CasesRelatedItemContent | undefined;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    get id(): string;
    get relatedItemArn(): string;
    get relatedItemId(): string;
    private _tags;
    get tags(): CasesRelatedItemTagsList;
    putTags(value: CasesRelatedItemTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CasesRelatedItemTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
