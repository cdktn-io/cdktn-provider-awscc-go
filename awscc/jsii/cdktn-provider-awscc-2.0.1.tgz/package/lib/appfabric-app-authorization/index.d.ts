/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppfabricAppAuthorizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#app AppfabricAppAuthorization#app}
    */
    readonly app: string;
    /**
    * The Amazon Resource Name (ARN) or Universal Unique Identifier (UUID) of the app bundle to use for the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#app_bundle_identifier AppfabricAppAuthorization#app_bundle_identifier}
    */
    readonly appBundleIdentifier: string;
    /**
    * The authorization type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#auth_type AppfabricAppAuthorization#auth_type}
    */
    readonly authType: string;
    /**
    * Contains credentials for the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#credential AppfabricAppAuthorization#credential}
    */
    readonly credential?: AppfabricAppAuthorizationCredential;
    /**
    * Tags to apply to the app authorization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#tags AppfabricAppAuthorization#tags}
    */
    readonly tags?: AppfabricAppAuthorizationTags[] | cdktn.IResolvable;
    /**
    * Contains information about an application tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#tenant AppfabricAppAuthorization#tenant}
    */
    readonly tenant: AppfabricAppAuthorizationTenant;
}
export interface AppfabricAppAuthorizationCredentialApiKeyCredential {
    /**
    * An API key for an application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#api_key AppfabricAppAuthorization#api_key}
    */
    readonly apiKey?: string;
}
export declare function appfabricAppAuthorizationCredentialApiKeyCredentialToTerraform(struct?: AppfabricAppAuthorizationCredentialApiKeyCredential | cdktn.IResolvable): any;
export declare function appfabricAppAuthorizationCredentialApiKeyCredentialToHclTerraform(struct?: AppfabricAppAuthorizationCredentialApiKeyCredential | cdktn.IResolvable): any;
export declare class AppfabricAppAuthorizationCredentialApiKeyCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricAppAuthorizationCredentialApiKeyCredential | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricAppAuthorizationCredentialApiKeyCredential | cdktn.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export interface AppfabricAppAuthorizationCredentialOauth2Credential {
    /**
    * The client ID of the client application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#client_id AppfabricAppAuthorization#client_id}
    */
    readonly clientId?: string;
    /**
    * The client secret of the client application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#client_secret AppfabricAppAuthorization#client_secret}
    */
    readonly clientSecret?: string;
}
export declare function appfabricAppAuthorizationCredentialOauth2CredentialToTerraform(struct?: AppfabricAppAuthorizationCredentialOauth2Credential | cdktn.IResolvable): any;
export declare function appfabricAppAuthorizationCredentialOauth2CredentialToHclTerraform(struct?: AppfabricAppAuthorizationCredentialOauth2Credential | cdktn.IResolvable): any;
export declare class AppfabricAppAuthorizationCredentialOauth2CredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricAppAuthorizationCredentialOauth2Credential | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricAppAuthorizationCredentialOauth2Credential | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
}
export interface AppfabricAppAuthorizationCredential {
    /**
    * Contains API key credential information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#api_key_credential AppfabricAppAuthorization#api_key_credential}
    */
    readonly apiKeyCredential?: AppfabricAppAuthorizationCredentialApiKeyCredential;
    /**
    * Contains OAuth2 client credential information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#oauth_2_credential AppfabricAppAuthorization#oauth_2_credential}
    */
    readonly oauth2Credential?: AppfabricAppAuthorizationCredentialOauth2Credential;
}
export declare function appfabricAppAuthorizationCredentialToTerraform(struct?: AppfabricAppAuthorizationCredential | cdktn.IResolvable): any;
export declare function appfabricAppAuthorizationCredentialToHclTerraform(struct?: AppfabricAppAuthorizationCredential | cdktn.IResolvable): any;
export declare class AppfabricAppAuthorizationCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricAppAuthorizationCredential | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricAppAuthorizationCredential | cdktn.IResolvable | undefined);
    private _apiKeyCredential;
    get apiKeyCredential(): AppfabricAppAuthorizationCredentialApiKeyCredentialOutputReference;
    putApiKeyCredential(value: AppfabricAppAuthorizationCredentialApiKeyCredential): void;
    resetApiKeyCredential(): void;
    get apiKeyCredentialInput(): cdktn.IResolvable | AppfabricAppAuthorizationCredentialApiKeyCredential | undefined;
    private _oauth2Credential;
    get oauth2Credential(): AppfabricAppAuthorizationCredentialOauth2CredentialOutputReference;
    putOauth2Credential(value: AppfabricAppAuthorizationCredentialOauth2Credential): void;
    resetOauth2Credential(): void;
    get oauth2CredentialInput(): cdktn.IResolvable | AppfabricAppAuthorizationCredentialOauth2Credential | undefined;
}
export interface AppfabricAppAuthorizationTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#key AppfabricAppAuthorization#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#value AppfabricAppAuthorization#value}
    */
    readonly value?: string;
}
export declare function appfabricAppAuthorizationTagsToTerraform(struct?: AppfabricAppAuthorizationTags | cdktn.IResolvable): any;
export declare function appfabricAppAuthorizationTagsToHclTerraform(struct?: AppfabricAppAuthorizationTags | cdktn.IResolvable): any;
export declare class AppfabricAppAuthorizationTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppfabricAppAuthorizationTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricAppAuthorizationTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppfabricAppAuthorizationTagsList extends cdktn.ComplexList {
    internalValue?: AppfabricAppAuthorizationTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppfabricAppAuthorizationTagsOutputReference;
}
export interface AppfabricAppAuthorizationTenant {
    /**
    * The display name of the tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#tenant_display_name AppfabricAppAuthorization#tenant_display_name}
    */
    readonly tenantDisplayName: string;
    /**
    * The ID of the application tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#tenant_identifier AppfabricAppAuthorization#tenant_identifier}
    */
    readonly tenantIdentifier: string;
}
export declare function appfabricAppAuthorizationTenantToTerraform(struct?: AppfabricAppAuthorizationTenant | cdktn.IResolvable): any;
export declare function appfabricAppAuthorizationTenantToHclTerraform(struct?: AppfabricAppAuthorizationTenant | cdktn.IResolvable): any;
export declare class AppfabricAppAuthorizationTenantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppfabricAppAuthorizationTenant | cdktn.IResolvable | undefined;
    set internalValue(value: AppfabricAppAuthorizationTenant | cdktn.IResolvable | undefined);
    private _tenantDisplayName?;
    get tenantDisplayName(): string;
    set tenantDisplayName(value: string);
    get tenantDisplayNameInput(): string | undefined;
    private _tenantIdentifier?;
    get tenantIdentifier(): string;
    set tenantIdentifier(value: string);
    get tenantIdentifierInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization awscc_appfabric_app_authorization}
*/
export declare class AppfabricAppAuthorization extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appfabric_app_authorization";
    /**
    * Generates CDKTN code for importing a AppfabricAppAuthorization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppfabricAppAuthorization to import
    * @param importFromId The id of the existing AppfabricAppAuthorization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppfabricAppAuthorization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appfabric_app_authorization awscc_appfabric_app_authorization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppfabricAppAuthorizationConfig
    */
    constructor(scope: Construct, id: string, config: AppfabricAppAuthorizationConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    get appAuthorizationArn(): string;
    get appAuthorizationIdentifier(): string;
    get appBundleArn(): string;
    private _appBundleIdentifier?;
    get appBundleIdentifier(): string;
    set appBundleIdentifier(value: string);
    get appBundleIdentifierInput(): string | undefined;
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
    get createdAt(): string;
    private _credential;
    get credential(): AppfabricAppAuthorizationCredentialOutputReference;
    putCredential(value: AppfabricAppAuthorizationCredential): void;
    resetCredential(): void;
    get credentialInput(): cdktn.IResolvable | AppfabricAppAuthorizationCredential | undefined;
    get id(): string;
    get persona(): string;
    get status(): string;
    private _tags;
    get tags(): AppfabricAppAuthorizationTagsList;
    putTags(value: AppfabricAppAuthorizationTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppfabricAppAuthorizationTags[] | undefined;
    private _tenant;
    get tenant(): AppfabricAppAuthorizationTenantOutputReference;
    putTenant(value: AppfabricAppAuthorizationTenant): void;
    get tenantInput(): cdktn.IResolvable | AppfabricAppAuthorizationTenant | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
