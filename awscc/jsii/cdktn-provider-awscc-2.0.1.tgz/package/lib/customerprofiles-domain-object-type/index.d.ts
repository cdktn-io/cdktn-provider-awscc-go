/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomerprofilesDomainObjectTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the domain object type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#description CustomerprofilesDomainObjectType#description}
    */
    readonly description?: string;
    /**
    * The unique name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#domain_name CustomerprofilesDomainObjectType#domain_name}
    */
    readonly domainName: string;
    /**
    * The default encryption key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#encryption_key CustomerprofilesDomainObjectType#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * A map of the name and ObjectType field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#fields CustomerprofilesDomainObjectType#fields}
    */
    readonly fields: {
        [key: string]: CustomerprofilesDomainObjectTypeFields;
    } | cdktn.IResolvable;
    /**
    * The name of the domain object type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#object_type_name CustomerprofilesDomainObjectType#object_type_name}
    */
    readonly objectTypeName: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#tags CustomerprofilesDomainObjectType#tags}
    */
    readonly tags?: CustomerprofilesDomainObjectTypeTags[] | cdktn.IResolvable;
}
export interface CustomerprofilesDomainObjectTypeFields {
    /**
    * The content type of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#content_type CustomerprofilesDomainObjectType#content_type}
    */
    readonly contentType?: string;
    /**
    * The feature type of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#feature_type CustomerprofilesDomainObjectType#feature_type}
    */
    readonly featureType?: string;
    /**
    * The source field name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#source CustomerprofilesDomainObjectType#source}
    */
    readonly source?: string;
    /**
    * The target field name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#target CustomerprofilesDomainObjectType#target}
    */
    readonly target?: string;
}
export declare function customerprofilesDomainObjectTypeFieldsToTerraform(struct?: CustomerprofilesDomainObjectTypeFields | cdktn.IResolvable): any;
export declare function customerprofilesDomainObjectTypeFieldsToHclTerraform(struct?: CustomerprofilesDomainObjectTypeFields | cdktn.IResolvable): any;
export declare class CustomerprofilesDomainObjectTypeFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): CustomerprofilesDomainObjectTypeFields | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesDomainObjectTypeFields | cdktn.IResolvable | undefined);
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _featureType?;
    get featureType(): string;
    set featureType(value: string);
    resetFeatureType(): void;
    get featureTypeInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
}
export declare class CustomerprofilesDomainObjectTypeFieldsMap extends cdktn.ComplexMap {
    internalValue?: {
        [key: string]: CustomerprofilesDomainObjectTypeFields;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): CustomerprofilesDomainObjectTypeFieldsOutputReference;
}
export interface CustomerprofilesDomainObjectTypeTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#key CustomerprofilesDomainObjectType#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#value CustomerprofilesDomainObjectType#value}
    */
    readonly value?: string;
}
export declare function customerprofilesDomainObjectTypeTagsToTerraform(struct?: CustomerprofilesDomainObjectTypeTags | cdktn.IResolvable): any;
export declare function customerprofilesDomainObjectTypeTagsToHclTerraform(struct?: CustomerprofilesDomainObjectTypeTags | cdktn.IResolvable): any;
export declare class CustomerprofilesDomainObjectTypeTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomerprofilesDomainObjectTypeTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomerprofilesDomainObjectTypeTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomerprofilesDomainObjectTypeTagsList extends cdktn.ComplexList {
    internalValue?: CustomerprofilesDomainObjectTypeTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomerprofilesDomainObjectTypeTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type awscc_customerprofiles_domain_object_type}
*/
export declare class CustomerprofilesDomainObjectType extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_customerprofiles_domain_object_type";
    /**
    * Generates CDKTN code for importing a CustomerprofilesDomainObjectType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomerprofilesDomainObjectType to import
    * @param importFromId The id of the existing CustomerprofilesDomainObjectType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomerprofilesDomainObjectType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/customerprofiles_domain_object_type awscc_customerprofiles_domain_object_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomerprofilesDomainObjectTypeConfig
    */
    constructor(scope: Construct, id: string, config: CustomerprofilesDomainObjectTypeConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _fields;
    get fields(): CustomerprofilesDomainObjectTypeFieldsMap;
    putFields(value: {
        [key: string]: CustomerprofilesDomainObjectTypeFields;
    } | cdktn.IResolvable): void;
    get fieldsInput(): cdktn.IResolvable | {
        [key: string]: CustomerprofilesDomainObjectTypeFields;
    } | undefined;
    get id(): string;
    get lastUpdatedAt(): string;
    private _objectTypeName?;
    get objectTypeName(): string;
    set objectTypeName(value: string);
    get objectTypeNameInput(): string | undefined;
    private _tags;
    get tags(): CustomerprofilesDomainObjectTypeTagsList;
    putTags(value: CustomerprofilesDomainObjectTypeTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CustomerprofilesDomainObjectTypeTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
