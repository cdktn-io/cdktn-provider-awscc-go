/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AutoscalingplansScalingPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * A CloudFormation stack or a set of tags. You can create one scaling plan per application source. The ApplicationSource property must be present to ensure interoperability with the AWS Auto Scaling console.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#application_source AutoscalingplansScalingPlan#application_source}
    */
    readonly applicationSource: AutoscalingplansScalingPlanApplicationSource;
    /**
    * The scaling instructions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#scaling_instructions AutoscalingplansScalingPlan#scaling_instructions}
    */
    readonly scalingInstructions: AutoscalingplansScalingPlanScalingInstructions[] | cdktn.IResolvable;
}
export interface AutoscalingplansScalingPlanApplicationSourceTagFilters {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#key AutoscalingplansScalingPlan#key}
    */
    readonly key?: string;
    /**
    * The tag values (0 to 20).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#values AutoscalingplansScalingPlan#values}
    */
    readonly values?: string[];
}
export declare function autoscalingplansScalingPlanApplicationSourceTagFiltersToTerraform(struct?: AutoscalingplansScalingPlanApplicationSourceTagFilters | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanApplicationSourceTagFiltersToHclTerraform(struct?: AutoscalingplansScalingPlanApplicationSourceTagFilters | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanApplicationSourceTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingplansScalingPlanApplicationSourceTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanApplicationSourceTagFilters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class AutoscalingplansScalingPlanApplicationSourceTagFiltersList extends cdktn.ComplexList {
    internalValue?: AutoscalingplansScalingPlanApplicationSourceTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingplansScalingPlanApplicationSourceTagFiltersOutputReference;
}
export interface AutoscalingplansScalingPlanApplicationSource {
    /**
    * The Amazon Resource Name (ARN) of a CloudFormation stack. The stack must contain at least one scalable resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#cloudformation_stack_arn AutoscalingplansScalingPlan#cloudformation_stack_arn}
    */
    readonly cloudformationStackArn?: string;
    /**
    * A set of tag filters (keys and values). Each tag filter specified must contain a key with values as optional. Each scaling plan can include up to 50 keys, and each key can include up to 20 values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#tag_filters AutoscalingplansScalingPlan#tag_filters}
    */
    readonly tagFilters?: AutoscalingplansScalingPlanApplicationSourceTagFilters[] | cdktn.IResolvable;
}
export declare function autoscalingplansScalingPlanApplicationSourceToTerraform(struct?: AutoscalingplansScalingPlanApplicationSource | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanApplicationSourceToHclTerraform(struct?: AutoscalingplansScalingPlanApplicationSource | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanApplicationSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingplansScalingPlanApplicationSource | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanApplicationSource | cdktn.IResolvable | undefined);
    private _cloudformationStackArn?;
    get cloudformationStackArn(): string;
    set cloudformationStackArn(value: string);
    resetCloudformationStackArn(): void;
    get cloudformationStackArnInput(): string | undefined;
    private _tagFilters;
    get tagFilters(): AutoscalingplansScalingPlanApplicationSourceTagFiltersList;
    putTagFilters(value: AutoscalingplansScalingPlanApplicationSourceTagFilters[] | cdktn.IResolvable): void;
    resetTagFilters(): void;
    get tagFiltersInput(): cdktn.IResolvable | AutoscalingplansScalingPlanApplicationSourceTagFilters[] | undefined;
}
export interface AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions {
    /**
    * The name of the dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#name AutoscalingplansScalingPlan#name}
    */
    readonly name?: string;
    /**
    * The value of the dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#value AutoscalingplansScalingPlan#value}
    */
    readonly value?: string;
}
export declare function autoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensionsToTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensionsToHclTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensionsList extends cdktn.ComplexList {
    internalValue?: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensionsOutputReference;
}
export interface AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecification {
    /**
    * The dimensions of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#dimensions AutoscalingplansScalingPlan#dimensions}
    */
    readonly dimensions?: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions[] | cdktn.IResolvable;
    /**
    * The name of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#metric_name AutoscalingplansScalingPlan#metric_name}
    */
    readonly metricName?: string;
    /**
    * The namespace of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#namespace AutoscalingplansScalingPlan#namespace}
    */
    readonly namespace?: string;
    /**
    * The statistic of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#statistic AutoscalingplansScalingPlan#statistic}
    */
    readonly statistic?: string;
    /**
    * The unit of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#unit AutoscalingplansScalingPlan#unit}
    */
    readonly unit?: string;
}
export declare function autoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationToTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecification | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationToHclTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecification | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecification | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensionsList;
    putDimensions(value: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _statistic?;
    get statistic(): string;
    set statistic(value: string);
    resetStatistic(): void;
    get statisticInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecification {
    /**
    * The metric type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#predefined_load_metric_type AutoscalingplansScalingPlan#predefined_load_metric_type}
    */
    readonly predefinedLoadMetricType?: string;
    /**
    * Identifies the resource associated with the metric type. You can't specify a resource label unless the metric type is ALBTargetGroupRequestCount and there is a target group for an Application Load Balancer attached to the Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#resource_label AutoscalingplansScalingPlan#resource_label}
    */
    readonly resourceLabel?: string;
}
export declare function autoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecificationToTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecification | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecificationToHclTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecification | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecification | cdktn.IResolvable | undefined);
    private _predefinedLoadMetricType?;
    get predefinedLoadMetricType(): string;
    set predefinedLoadMetricType(value: string);
    resetPredefinedLoadMetricType(): void;
    get predefinedLoadMetricTypeInput(): string | undefined;
    private _resourceLabel?;
    get resourceLabel(): string;
    set resourceLabel(value: string);
    resetResourceLabel(): void;
    get resourceLabelInput(): string | undefined;
}
export interface AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions {
    /**
    * The name of the dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#name AutoscalingplansScalingPlan#name}
    */
    readonly name?: string;
    /**
    * The value of the dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#value AutoscalingplansScalingPlan#value}
    */
    readonly value?: string;
}
export declare function autoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensionsToTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensionsToHclTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensionsList extends cdktn.ComplexList {
    internalValue?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensionsOutputReference;
}
export interface AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecification {
    /**
    * The dimensions of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#dimensions AutoscalingplansScalingPlan#dimensions}
    */
    readonly dimensions?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions[] | cdktn.IResolvable;
    /**
    * The name of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#metric_name AutoscalingplansScalingPlan#metric_name}
    */
    readonly metricName?: string;
    /**
    * The namespace of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#namespace AutoscalingplansScalingPlan#namespace}
    */
    readonly namespace?: string;
    /**
    * The statistic of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#statistic AutoscalingplansScalingPlan#statistic}
    */
    readonly statistic?: string;
    /**
    * The unit of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#unit AutoscalingplansScalingPlan#unit}
    */
    readonly unit?: string;
}
export declare function autoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationToTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecification | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationToHclTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecification | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecification | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensionsList;
    putDimensions(value: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationDimensions[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _statistic?;
    get statistic(): string;
    set statistic(value: string);
    resetStatistic(): void;
    get statisticInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecification {
    /**
    * The metric type. The ALBRequestCountPerTarget metric type applies only to Auto Scaling groups, Spot Fleet requests, and ECS services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#predefined_scaling_metric_type AutoscalingplansScalingPlan#predefined_scaling_metric_type}
    */
    readonly predefinedScalingMetricType?: string;
    /**
    * Identifies the resource associated with the metric type. You can't specify a resource label unless the metric type is ALBRequestCountPerTarget and there is a target group for an Application Load Balancer attached to the Auto Scaling group, Spot Fleet request, or ECS service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#resource_label AutoscalingplansScalingPlan#resource_label}
    */
    readonly resourceLabel?: string;
}
export declare function autoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecificationToTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecification | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecificationToHclTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecification | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecification | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecification | cdktn.IResolvable | undefined);
    private _predefinedScalingMetricType?;
    get predefinedScalingMetricType(): string;
    set predefinedScalingMetricType(value: string);
    resetPredefinedScalingMetricType(): void;
    get predefinedScalingMetricTypeInput(): string | undefined;
    private _resourceLabel?;
    get resourceLabel(): string;
    set resourceLabel(value: string);
    resetResourceLabel(): void;
    get resourceLabelInput(): string | undefined;
}
export interface AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations {
    /**
    * A customized metric. You can specify either a predefined metric or a customized metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#customized_scaling_metric_specification AutoscalingplansScalingPlan#customized_scaling_metric_specification}
    */
    readonly customizedScalingMetricSpecification?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecification;
    /**
    * Indicates whether scale in by the target tracking scaling policy is disabled. If the value is true, scale in is disabled and the target tracking scaling policy doesn't remove capacity from the scalable resource. Otherwise, scale in is enabled and the target tracking scaling policy can remove capacity from the scalable resource. The default value is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#disable_scale_in AutoscalingplansScalingPlan#disable_scale_in}
    */
    readonly disableScaleIn?: boolean | cdktn.IResolvable;
    /**
    * The estimated time, in seconds, until a newly launched instance can contribute to the CloudWatch metrics. This value is used only if the resource is an Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#estimated_instance_warmup AutoscalingplansScalingPlan#estimated_instance_warmup}
    */
    readonly estimatedInstanceWarmup?: number;
    /**
    * A predefined metric. You can specify either a predefined metric or a customized metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#predefined_scaling_metric_specification AutoscalingplansScalingPlan#predefined_scaling_metric_specification}
    */
    readonly predefinedScalingMetricSpecification?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecification;
    /**
    * The amount of time, in seconds, after a scale-in activity completes before another scale in activity can start. This value is not used if the scalable resource is an Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#scale_in_cooldown AutoscalingplansScalingPlan#scale_in_cooldown}
    */
    readonly scaleInCooldown?: number;
    /**
    * The amount of time, in seconds, after a scale-out activity completes before another scale-out activity can start. This value is not used if the scalable resource is an Auto Scaling group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#scale_out_cooldown AutoscalingplansScalingPlan#scale_out_cooldown}
    */
    readonly scaleOutCooldown?: number;
    /**
    * The target value for the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#target_value AutoscalingplansScalingPlan#target_value}
    */
    readonly targetValue: number;
}
export declare function autoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsToTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsToHclTerraform(struct?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations | cdktn.IResolvable | undefined);
    private _customizedScalingMetricSpecification;
    get customizedScalingMetricSpecification(): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecificationOutputReference;
    putCustomizedScalingMetricSpecification(value: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecification): void;
    resetCustomizedScalingMetricSpecification(): void;
    get customizedScalingMetricSpecificationInput(): cdktn.IResolvable | AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsCustomizedScalingMetricSpecification | undefined;
    private _disableScaleIn?;
    get disableScaleIn(): boolean | cdktn.IResolvable;
    set disableScaleIn(value: boolean | cdktn.IResolvable);
    resetDisableScaleIn(): void;
    get disableScaleInInput(): boolean | cdktn.IResolvable | undefined;
    private _estimatedInstanceWarmup?;
    get estimatedInstanceWarmup(): number;
    set estimatedInstanceWarmup(value: number);
    resetEstimatedInstanceWarmup(): void;
    get estimatedInstanceWarmupInput(): number | undefined;
    private _predefinedScalingMetricSpecification;
    get predefinedScalingMetricSpecification(): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecificationOutputReference;
    putPredefinedScalingMetricSpecification(value: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecification): void;
    resetPredefinedScalingMetricSpecification(): void;
    get predefinedScalingMetricSpecificationInput(): cdktn.IResolvable | AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsPredefinedScalingMetricSpecification | undefined;
    private _scaleInCooldown?;
    get scaleInCooldown(): number;
    set scaleInCooldown(value: number);
    resetScaleInCooldown(): void;
    get scaleInCooldownInput(): number | undefined;
    private _scaleOutCooldown?;
    get scaleOutCooldown(): number;
    set scaleOutCooldown(value: number);
    resetScaleOutCooldown(): void;
    get scaleOutCooldownInput(): number | undefined;
    private _targetValue?;
    get targetValue(): number;
    set targetValue(value: number);
    get targetValueInput(): number | undefined;
}
export declare class AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsList extends cdktn.ComplexList {
    internalValue?: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsOutputReference;
}
export interface AutoscalingplansScalingPlanScalingInstructions {
    /**
    * The customized load metric to use for predictive scaling. This property or a PredefinedLoadMetricSpecification is required when configuring predictive scaling, and cannot be used otherwise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#customized_load_metric_specification AutoscalingplansScalingPlan#customized_load_metric_specification}
    */
    readonly customizedLoadMetricSpecification?: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecification;
    /**
    * Controls whether dynamic scaling is disabled. When dynamic scaling is enabled, AWS Auto Scaling creates target tracking scaling policies based on the specified target tracking configurations. The default is enabled (false).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#disable_dynamic_scaling AutoscalingplansScalingPlan#disable_dynamic_scaling}
    */
    readonly disableDynamicScaling?: boolean | cdktn.IResolvable;
    /**
    * The maximum capacity of the resource. The exception to this upper limit is if you specify a non-default setting for PredictiveScalingMaxCapacityBehavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#max_capacity AutoscalingplansScalingPlan#max_capacity}
    */
    readonly maxCapacity: number;
    /**
    * The minimum capacity of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#min_capacity AutoscalingplansScalingPlan#min_capacity}
    */
    readonly minCapacity: number;
    /**
    * The predefined load metric to use for predictive scaling. This property or a CustomizedLoadMetricSpecification is required when configuring predictive scaling, and cannot be used otherwise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#predefined_load_metric_specification AutoscalingplansScalingPlan#predefined_load_metric_specification}
    */
    readonly predefinedLoadMetricSpecification?: AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecification;
    /**
    * Defines the behavior that should be applied if the forecast capacity approaches or exceeds the maximum capacity specified for the resource. The default value is SetForecastCapacityToMaxCapacity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#predictive_scaling_max_capacity_behavior AutoscalingplansScalingPlan#predictive_scaling_max_capacity_behavior}
    */
    readonly predictiveScalingMaxCapacityBehavior?: string;
    /**
    * The size of the capacity buffer to use when the forecast capacity is close to or exceeds the maximum capacity. The value is specified as a percentage relative to the forecast capacity. For example, if the buffer is 10, this means a 10 percent buffer. The range is 1-100. Required if PredictiveScalingMaxCapacityBehavior is set to SetMaxCapacityAboveForecastCapacity, and cannot be used otherwise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#predictive_scaling_max_capacity_buffer AutoscalingplansScalingPlan#predictive_scaling_max_capacity_buffer}
    */
    readonly predictiveScalingMaxCapacityBuffer?: number;
    /**
    * The predictive scaling mode. The default value is ForecastAndScale. Otherwise, AWS Auto Scaling forecasts capacity but does not apply any scheduled scaling actions based on the capacity forecast.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#predictive_scaling_mode AutoscalingplansScalingPlan#predictive_scaling_mode}
    */
    readonly predictiveScalingMode?: string;
    /**
    * The ID of the resource. This string consists of the resource type and unique identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#resource_id AutoscalingplansScalingPlan#resource_id}
    */
    readonly resourceId: string;
    /**
    * The scalable dimension associated with the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#scalable_dimension AutoscalingplansScalingPlan#scalable_dimension}
    */
    readonly scalableDimension: string;
    /**
    * Controls whether a resource's externally created scaling policies are deleted and new target tracking scaling policies created. The default value is KeepExternalPolicies. Valid only when configuring dynamic scaling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#scaling_policy_update_behavior AutoscalingplansScalingPlan#scaling_policy_update_behavior}
    */
    readonly scalingPolicyUpdateBehavior?: string;
    /**
    * The amount of time, in seconds, to buffer the run time of scheduled scaling actions when scaling out. The value must be less than the forecast interval duration of 3600 seconds (60 minutes). The default is 300 seconds. Valid only when configuring predictive scaling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#scheduled_action_buffer_time AutoscalingplansScalingPlan#scheduled_action_buffer_time}
    */
    readonly scheduledActionBufferTime?: number;
    /**
    * The namespace of the AWS service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#service_namespace AutoscalingplansScalingPlan#service_namespace}
    */
    readonly serviceNamespace: string;
    /**
    * The target tracking configurations (up to 10). Each of these structures must specify a unique scaling metric and a target value for the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#target_tracking_configurations AutoscalingplansScalingPlan#target_tracking_configurations}
    */
    readonly targetTrackingConfigurations: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations[] | cdktn.IResolvable;
}
export declare function autoscalingplansScalingPlanScalingInstructionsToTerraform(struct?: AutoscalingplansScalingPlanScalingInstructions | cdktn.IResolvable): any;
export declare function autoscalingplansScalingPlanScalingInstructionsToHclTerraform(struct?: AutoscalingplansScalingPlanScalingInstructions | cdktn.IResolvable): any;
export declare class AutoscalingplansScalingPlanScalingInstructionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingplansScalingPlanScalingInstructions | cdktn.IResolvable | undefined;
    set internalValue(value: AutoscalingplansScalingPlanScalingInstructions | cdktn.IResolvable | undefined);
    private _customizedLoadMetricSpecification;
    get customizedLoadMetricSpecification(): AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecificationOutputReference;
    putCustomizedLoadMetricSpecification(value: AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecification): void;
    resetCustomizedLoadMetricSpecification(): void;
    get customizedLoadMetricSpecificationInput(): cdktn.IResolvable | AutoscalingplansScalingPlanScalingInstructionsCustomizedLoadMetricSpecification | undefined;
    private _disableDynamicScaling?;
    get disableDynamicScaling(): boolean | cdktn.IResolvable;
    set disableDynamicScaling(value: boolean | cdktn.IResolvable);
    resetDisableDynamicScaling(): void;
    get disableDynamicScalingInput(): boolean | cdktn.IResolvable | undefined;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    get maxCapacityInput(): number | undefined;
    private _minCapacity?;
    get minCapacity(): number;
    set minCapacity(value: number);
    get minCapacityInput(): number | undefined;
    private _predefinedLoadMetricSpecification;
    get predefinedLoadMetricSpecification(): AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecificationOutputReference;
    putPredefinedLoadMetricSpecification(value: AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecification): void;
    resetPredefinedLoadMetricSpecification(): void;
    get predefinedLoadMetricSpecificationInput(): cdktn.IResolvable | AutoscalingplansScalingPlanScalingInstructionsPredefinedLoadMetricSpecification | undefined;
    private _predictiveScalingMaxCapacityBehavior?;
    get predictiveScalingMaxCapacityBehavior(): string;
    set predictiveScalingMaxCapacityBehavior(value: string);
    resetPredictiveScalingMaxCapacityBehavior(): void;
    get predictiveScalingMaxCapacityBehaviorInput(): string | undefined;
    private _predictiveScalingMaxCapacityBuffer?;
    get predictiveScalingMaxCapacityBuffer(): number;
    set predictiveScalingMaxCapacityBuffer(value: number);
    resetPredictiveScalingMaxCapacityBuffer(): void;
    get predictiveScalingMaxCapacityBufferInput(): number | undefined;
    private _predictiveScalingMode?;
    get predictiveScalingMode(): string;
    set predictiveScalingMode(value: string);
    resetPredictiveScalingMode(): void;
    get predictiveScalingModeInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _scalableDimension?;
    get scalableDimension(): string;
    set scalableDimension(value: string);
    get scalableDimensionInput(): string | undefined;
    private _scalingPolicyUpdateBehavior?;
    get scalingPolicyUpdateBehavior(): string;
    set scalingPolicyUpdateBehavior(value: string);
    resetScalingPolicyUpdateBehavior(): void;
    get scalingPolicyUpdateBehaviorInput(): string | undefined;
    private _scheduledActionBufferTime?;
    get scheduledActionBufferTime(): number;
    set scheduledActionBufferTime(value: number);
    resetScheduledActionBufferTime(): void;
    get scheduledActionBufferTimeInput(): number | undefined;
    private _serviceNamespace?;
    get serviceNamespace(): string;
    set serviceNamespace(value: string);
    get serviceNamespaceInput(): string | undefined;
    private _targetTrackingConfigurations;
    get targetTrackingConfigurations(): AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurationsList;
    putTargetTrackingConfigurations(value: AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations[] | cdktn.IResolvable): void;
    get targetTrackingConfigurationsInput(): cdktn.IResolvable | AutoscalingplansScalingPlanScalingInstructionsTargetTrackingConfigurations[] | undefined;
}
export declare class AutoscalingplansScalingPlanScalingInstructionsList extends cdktn.ComplexList {
    internalValue?: AutoscalingplansScalingPlanScalingInstructions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingplansScalingPlanScalingInstructionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan awscc_autoscalingplans_scaling_plan}
*/
export declare class AutoscalingplansScalingPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_autoscalingplans_scaling_plan";
    /**
    * Generates CDKTN code for importing a AutoscalingplansScalingPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutoscalingplansScalingPlan to import
    * @param importFromId The id of the existing AutoscalingplansScalingPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutoscalingplansScalingPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/autoscalingplans_scaling_plan awscc_autoscalingplans_scaling_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutoscalingplansScalingPlanConfig
    */
    constructor(scope: Construct, id: string, config: AutoscalingplansScalingPlanConfig);
    private _applicationSource;
    get applicationSource(): AutoscalingplansScalingPlanApplicationSourceOutputReference;
    putApplicationSource(value: AutoscalingplansScalingPlanApplicationSource): void;
    get applicationSourceInput(): cdktn.IResolvable | AutoscalingplansScalingPlanApplicationSource | undefined;
    get id(): string;
    private _scalingInstructions;
    get scalingInstructions(): AutoscalingplansScalingPlanScalingInstructionsList;
    putScalingInstructions(value: AutoscalingplansScalingPlanScalingInstructions[] | cdktn.IResolvable): void;
    get scalingInstructionsInput(): cdktn.IResolvable | AutoscalingplansScalingPlanScalingInstructions[] | undefined;
    get scalingPlanArn(): string;
    get scalingPlanName(): string;
    get scalingPlanVersion(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
