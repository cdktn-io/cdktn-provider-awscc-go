/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectDataTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the Data Table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#description ConnectDataTable#description}
    */
    readonly description?: string;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#instance_arn ConnectDataTable#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the Data Table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#name ConnectDataTable#name}
    */
    readonly name: string;
    /**
    * The status of the Data Table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#status ConnectDataTable#status}
    */
    readonly status: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#tags ConnectDataTable#tags}
    */
    readonly tags?: ConnectDataTableTags[] | cdktn.IResolvable;
    /**
    * The time zone of the Data Table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#time_zone ConnectDataTable#time_zone}
    */
    readonly timeZone: string;
    /**
    * The value lock level of the Data Table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#value_lock_level ConnectDataTable#value_lock_level}
    */
    readonly valueLockLevel: string;
}
export interface ConnectDataTableLockVersion {
}
export declare function connectDataTableLockVersionToTerraform(struct?: ConnectDataTableLockVersion): any;
export declare function connectDataTableLockVersionToHclTerraform(struct?: ConnectDataTableLockVersion): any;
export declare class ConnectDataTableLockVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectDataTableLockVersion | undefined;
    set internalValue(value: ConnectDataTableLockVersion | undefined);
    get dataTable(): string;
}
export interface ConnectDataTableTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#key ConnectDataTable#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#value ConnectDataTable#value}
    */
    readonly value?: string;
}
export declare function connectDataTableTagsToTerraform(struct?: ConnectDataTableTags | cdktn.IResolvable): any;
export declare function connectDataTableTagsToHclTerraform(struct?: ConnectDataTableTags | cdktn.IResolvable): any;
export declare class ConnectDataTableTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectDataTableTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectDataTableTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectDataTableTagsList extends cdktn.ComplexList {
    internalValue?: ConnectDataTableTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectDataTableTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table awscc_connect_data_table}
*/
export declare class ConnectDataTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_data_table";
    /**
    * Generates CDKTN code for importing a ConnectDataTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectDataTable to import
    * @param importFromId The id of the existing ConnectDataTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectDataTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_data_table awscc_connect_data_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectDataTableConfig
    */
    constructor(scope: Construct, id: string, config: ConnectDataTableConfig);
    get arn(): string;
    get createdTime(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    get lastModifiedRegion(): string;
    get lastModifiedTime(): number;
    private _lockVersion;
    get lockVersion(): ConnectDataTableLockVersionOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _tags;
    get tags(): ConnectDataTableTagsList;
    putTags(value: ConnectDataTableTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectDataTableTags[] | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _valueLockLevel?;
    get valueLockLevel(): string;
    set valueLockLevel(value: string);
    get valueLockLevelInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
