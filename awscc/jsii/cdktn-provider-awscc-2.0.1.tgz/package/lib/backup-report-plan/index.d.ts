/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupReportPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * A structure that contains information about where and how to deliver your reports, specifically your Amazon S3 bucket name, S3 key prefix, and the formats of your reports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#report_delivery_channel BackupReportPlan#report_delivery_channel}
    */
    readonly reportDeliveryChannel: BackupReportPlanReportDeliveryChannel;
    /**
    * An optional description of the report plan with a maximum of 1,024 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#report_plan_description BackupReportPlan#report_plan_description}
    */
    readonly reportPlanDescription?: string;
    /**
    * The unique name of the report plan. The name must be between 1 and 256 characters, starting with a letter, and consisting of letters (a-z, A-Z), numbers (0-9), and underscores (_).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#report_plan_name BackupReportPlan#report_plan_name}
    */
    readonly reportPlanName?: string;
    /**
    * Metadata that you can assign to help organize the report plans that you create. Each tag is a key-value pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#report_plan_tags BackupReportPlan#report_plan_tags}
    */
    readonly reportPlanTags?: BackupReportPlanReportPlanTags[] | cdktn.IResolvable;
    /**
    * Identifies the report template for the report. Reports are built using a report template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#report_setting BackupReportPlan#report_setting}
    */
    readonly reportSetting: BackupReportPlanReportSetting;
}
export interface BackupReportPlanReportDeliveryChannel {
    /**
    * A list of the format of your reports: CSV, JSON, or both. If not specified, the default format is CSV.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#formats BackupReportPlan#formats}
    */
    readonly formats?: string[];
    /**
    * The unique name of the S3 bucket that receives your reports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#s3_bucket_name BackupReportPlan#s3_bucket_name}
    */
    readonly s3BucketName: string;
    /**
    * The prefix for where AWS Backup Audit Manager delivers your reports to Amazon S3. The prefix is this part of the following path: s3://your-bucket-name/prefix/Backup/us-west-2/year/month/day/report-name. If not specified, there is no prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#s3_key_prefix BackupReportPlan#s3_key_prefix}
    */
    readonly s3KeyPrefix?: string;
}
export declare function backupReportPlanReportDeliveryChannelToTerraform(struct?: BackupReportPlanReportDeliveryChannel | cdktn.IResolvable): any;
export declare function backupReportPlanReportDeliveryChannelToHclTerraform(struct?: BackupReportPlanReportDeliveryChannel | cdktn.IResolvable): any;
export declare class BackupReportPlanReportDeliveryChannelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupReportPlanReportDeliveryChannel | cdktn.IResolvable | undefined;
    set internalValue(value: BackupReportPlanReportDeliveryChannel | cdktn.IResolvable | undefined);
    private _formats?;
    get formats(): string[];
    set formats(value: string[]);
    resetFormats(): void;
    get formatsInput(): string[] | undefined;
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    get s3BucketNameInput(): string | undefined;
    private _s3KeyPrefix?;
    get s3KeyPrefix(): string;
    set s3KeyPrefix(value: string);
    resetS3KeyPrefix(): void;
    get s3KeyPrefixInput(): string | undefined;
}
export interface BackupReportPlanReportPlanTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#key BackupReportPlan#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#value BackupReportPlan#value}
    */
    readonly value?: string;
}
export declare function backupReportPlanReportPlanTagsToTerraform(struct?: BackupReportPlanReportPlanTags | cdktn.IResolvable): any;
export declare function backupReportPlanReportPlanTagsToHclTerraform(struct?: BackupReportPlanReportPlanTags | cdktn.IResolvable): any;
export declare class BackupReportPlanReportPlanTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupReportPlanReportPlanTags | cdktn.IResolvable | undefined;
    set internalValue(value: BackupReportPlanReportPlanTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BackupReportPlanReportPlanTagsList extends cdktn.ComplexList {
    internalValue?: BackupReportPlanReportPlanTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupReportPlanReportPlanTagsOutputReference;
}
export interface BackupReportPlanReportSetting {
    /**
    * The list of AWS accounts that a report covers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#accounts BackupReportPlan#accounts}
    */
    readonly accounts?: string[];
    /**
    * The Amazon Resource Names (ARNs) of the frameworks a report covers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#framework_arns BackupReportPlan#framework_arns}
    */
    readonly frameworkArns?: string[];
    /**
    * The list of AWS organization units that a report covers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#organization_units BackupReportPlan#organization_units}
    */
    readonly organizationUnits?: string[];
    /**
    * The list of AWS regions that a report covers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#regions BackupReportPlan#regions}
    */
    readonly regions?: string[];
    /**
    * Identifies the report template for the report. Reports are built using a report template. The report templates are: `BACKUP_JOB_REPORT | COPY_JOB_REPORT | RESTORE_JOB_REPORT`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#report_template BackupReportPlan#report_template}
    */
    readonly reportTemplate: string;
}
export declare function backupReportPlanReportSettingToTerraform(struct?: BackupReportPlanReportSetting | cdktn.IResolvable): any;
export declare function backupReportPlanReportSettingToHclTerraform(struct?: BackupReportPlanReportSetting | cdktn.IResolvable): any;
export declare class BackupReportPlanReportSettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupReportPlanReportSetting | cdktn.IResolvable | undefined;
    set internalValue(value: BackupReportPlanReportSetting | cdktn.IResolvable | undefined);
    private _accounts?;
    get accounts(): string[];
    set accounts(value: string[]);
    resetAccounts(): void;
    get accountsInput(): string[] | undefined;
    private _frameworkArns?;
    get frameworkArns(): string[];
    set frameworkArns(value: string[]);
    resetFrameworkArns(): void;
    get frameworkArnsInput(): string[] | undefined;
    private _organizationUnits?;
    get organizationUnits(): string[];
    set organizationUnits(value: string[]);
    resetOrganizationUnits(): void;
    get organizationUnitsInput(): string[] | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
    private _reportTemplate?;
    get reportTemplate(): string;
    set reportTemplate(value: string);
    get reportTemplateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan awscc_backup_report_plan}
*/
export declare class BackupReportPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_report_plan";
    /**
    * Generates CDKTN code for importing a BackupReportPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupReportPlan to import
    * @param importFromId The id of the existing BackupReportPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupReportPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_report_plan awscc_backup_report_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupReportPlanConfig
    */
    constructor(scope: Construct, id: string, config: BackupReportPlanConfig);
    get id(): string;
    private _reportDeliveryChannel;
    get reportDeliveryChannel(): BackupReportPlanReportDeliveryChannelOutputReference;
    putReportDeliveryChannel(value: BackupReportPlanReportDeliveryChannel): void;
    get reportDeliveryChannelInput(): cdktn.IResolvable | BackupReportPlanReportDeliveryChannel | undefined;
    get reportPlanArn(): string;
    private _reportPlanDescription?;
    get reportPlanDescription(): string;
    set reportPlanDescription(value: string);
    resetReportPlanDescription(): void;
    get reportPlanDescriptionInput(): string | undefined;
    private _reportPlanName?;
    get reportPlanName(): string;
    set reportPlanName(value: string);
    resetReportPlanName(): void;
    get reportPlanNameInput(): string | undefined;
    private _reportPlanTags;
    get reportPlanTags(): BackupReportPlanReportPlanTagsList;
    putReportPlanTags(value: BackupReportPlanReportPlanTags[] | cdktn.IResolvable): void;
    resetReportPlanTags(): void;
    get reportPlanTagsInput(): cdktn.IResolvable | BackupReportPlanReportPlanTags[] | undefined;
    private _reportSetting;
    get reportSetting(): BackupReportPlanReportSettingOutputReference;
    putReportSetting(value: BackupReportPlanReportSetting): void;
    get reportSettingInput(): cdktn.IResolvable | BackupReportPlanReportSetting | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
