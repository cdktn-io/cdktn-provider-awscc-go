/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncDataSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unique AWS AppSync GraphQL API identifier where this data source will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#api_id AppsyncDataSource#api_id}
    */
    readonly apiId: string;
    /**
    * The description of the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#description AppsyncDataSource#description}
    */
    readonly description?: string;
    /**
    * AWS Region and TableName for an Amazon DynamoDB table in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#dynamo_db_config AppsyncDataSource#dynamo_db_config}
    */
    readonly dynamoDbConfig?: AppsyncDataSourceDynamoDbConfig;
    /**
    * AWS Region and Endpoints for an Amazon OpenSearch Service domain in your account.
    * As of September 2021, Amazon Elasticsearch Service is Amazon OpenSearch Service. This property is deprecated. For new data sources, use OpenSearchServiceConfig to specify an OpenSearch Service data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#elasticsearch_config AppsyncDataSource#elasticsearch_config}
    */
    readonly elasticsearchConfig?: AppsyncDataSourceElasticsearchConfig;
    /**
    * ARN for the EventBridge bus.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#event_bridge_config AppsyncDataSource#event_bridge_config}
    */
    readonly eventBridgeConfig?: AppsyncDataSourceEventBridgeConfig;
    /**
    * Endpoints for an HTTP data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#http_config AppsyncDataSource#http_config}
    */
    readonly httpConfig?: AppsyncDataSourceHttpConfig;
    /**
    * An ARN of a Lambda function in valid ARN format. This can be the ARN of a Lambda function that exists in the current account or in another account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#lambda_config AppsyncDataSource#lambda_config}
    */
    readonly lambdaConfig?: AppsyncDataSourceLambdaConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#metrics_config AppsyncDataSource#metrics_config}
    */
    readonly metricsConfig?: string;
    /**
    * Friendly name for you to identify your AppSync data source after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#name AppsyncDataSource#name}
    */
    readonly name: string;
    /**
    * AWS Region and Endpoints for an Amazon OpenSearch Service domain in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#open_search_service_config AppsyncDataSource#open_search_service_config}
    */
    readonly openSearchServiceConfig?: AppsyncDataSourceOpenSearchServiceConfig;
    /**
    * Relational Database configuration of the relational database data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#relational_database_config AppsyncDataSource#relational_database_config}
    */
    readonly relationalDatabaseConfig?: AppsyncDataSourceRelationalDatabaseConfig;
    /**
    * The AWS Identity and Access Management service role ARN for the data source. The system assumes this role when accessing the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#service_role_arn AppsyncDataSource#service_role_arn}
    */
    readonly serviceRoleArn?: string;
    /**
    * The type of the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#type AppsyncDataSource#type}
    */
    readonly type: string;
}
export interface AppsyncDataSourceDynamoDbConfigDeltaSyncConfig {
    /**
    * The number of minutes that an Item is stored in the data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#base_table_ttl AppsyncDataSource#base_table_ttl}
    */
    readonly baseTableTtl?: string;
    /**
    * The Delta Sync table name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#delta_sync_table_name AppsyncDataSource#delta_sync_table_name}
    */
    readonly deltaSyncTableName?: string;
    /**
    * The number of minutes that a Delta Sync log entry is stored in the Delta Sync table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#delta_sync_table_ttl AppsyncDataSource#delta_sync_table_ttl}
    */
    readonly deltaSyncTableTtl?: string;
}
export declare function appsyncDataSourceDynamoDbConfigDeltaSyncConfigToTerraform(struct?: AppsyncDataSourceDynamoDbConfigDeltaSyncConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceDynamoDbConfigDeltaSyncConfigToHclTerraform(struct?: AppsyncDataSourceDynamoDbConfigDeltaSyncConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceDynamoDbConfigDeltaSyncConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceDynamoDbConfigDeltaSyncConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceDynamoDbConfigDeltaSyncConfig | cdktn.IResolvable | undefined);
    private _baseTableTtl?;
    get baseTableTtl(): string;
    set baseTableTtl(value: string);
    resetBaseTableTtl(): void;
    get baseTableTtlInput(): string | undefined;
    private _deltaSyncTableName?;
    get deltaSyncTableName(): string;
    set deltaSyncTableName(value: string);
    resetDeltaSyncTableName(): void;
    get deltaSyncTableNameInput(): string | undefined;
    private _deltaSyncTableTtl?;
    get deltaSyncTableTtl(): string;
    set deltaSyncTableTtl(value: string);
    resetDeltaSyncTableTtl(): void;
    get deltaSyncTableTtlInput(): string | undefined;
}
export interface AppsyncDataSourceDynamoDbConfig {
    /**
    * The AWS Region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#aws_region AppsyncDataSource#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * The DeltaSyncConfig for a versioned datasource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#delta_sync_config AppsyncDataSource#delta_sync_config}
    */
    readonly deltaSyncConfig?: AppsyncDataSourceDynamoDbConfigDeltaSyncConfig;
    /**
    * The table name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#table_name AppsyncDataSource#table_name}
    */
    readonly tableName?: string;
    /**
    * Set to TRUE to use AWS Identity and Access Management with this data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#use_caller_credentials AppsyncDataSource#use_caller_credentials}
    */
    readonly useCallerCredentials?: boolean | cdktn.IResolvable;
    /**
    * Set to TRUE to use Conflict Detection and Resolution with this data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#versioned AppsyncDataSource#versioned}
    */
    readonly versioned?: boolean | cdktn.IResolvable;
}
export declare function appsyncDataSourceDynamoDbConfigToTerraform(struct?: AppsyncDataSourceDynamoDbConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceDynamoDbConfigToHclTerraform(struct?: AppsyncDataSourceDynamoDbConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceDynamoDbConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceDynamoDbConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceDynamoDbConfig | cdktn.IResolvable | undefined);
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _deltaSyncConfig;
    get deltaSyncConfig(): AppsyncDataSourceDynamoDbConfigDeltaSyncConfigOutputReference;
    putDeltaSyncConfig(value: AppsyncDataSourceDynamoDbConfigDeltaSyncConfig): void;
    resetDeltaSyncConfig(): void;
    get deltaSyncConfigInput(): cdktn.IResolvable | AppsyncDataSourceDynamoDbConfigDeltaSyncConfig | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
    private _useCallerCredentials?;
    get useCallerCredentials(): boolean | cdktn.IResolvable;
    set useCallerCredentials(value: boolean | cdktn.IResolvable);
    resetUseCallerCredentials(): void;
    get useCallerCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _versioned?;
    get versioned(): boolean | cdktn.IResolvable;
    set versioned(value: boolean | cdktn.IResolvable);
    resetVersioned(): void;
    get versionedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AppsyncDataSourceElasticsearchConfig {
    /**
    * The AWS Region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#aws_region AppsyncDataSource#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * The endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#endpoint AppsyncDataSource#endpoint}
    */
    readonly endpoint?: string;
}
export declare function appsyncDataSourceElasticsearchConfigToTerraform(struct?: AppsyncDataSourceElasticsearchConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceElasticsearchConfigToHclTerraform(struct?: AppsyncDataSourceElasticsearchConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceElasticsearchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceElasticsearchConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceElasticsearchConfig | cdktn.IResolvable | undefined);
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
}
export interface AppsyncDataSourceEventBridgeConfig {
    /**
    * ARN for the EventBridge bus.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#event_bus_arn AppsyncDataSource#event_bus_arn}
    */
    readonly eventBusArn?: string;
}
export declare function appsyncDataSourceEventBridgeConfigToTerraform(struct?: AppsyncDataSourceEventBridgeConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceEventBridgeConfigToHclTerraform(struct?: AppsyncDataSourceEventBridgeConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceEventBridgeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceEventBridgeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceEventBridgeConfig | cdktn.IResolvable | undefined);
    private _eventBusArn?;
    get eventBusArn(): string;
    set eventBusArn(value: string);
    resetEventBusArn(): void;
    get eventBusArnInput(): string | undefined;
}
export interface AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfig {
    /**
    * The signing Region for AWS Identity and Access Management authorization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#signing_region AppsyncDataSource#signing_region}
    */
    readonly signingRegion?: string;
    /**
    * The signing service name for AWS Identity and Access Management authorization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#signing_service_name AppsyncDataSource#signing_service_name}
    */
    readonly signingServiceName?: string;
}
export declare function appsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfigToTerraform(struct?: AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfigToHclTerraform(struct?: AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfig | cdktn.IResolvable | undefined);
    private _signingRegion?;
    get signingRegion(): string;
    set signingRegion(value: string);
    resetSigningRegion(): void;
    get signingRegionInput(): string | undefined;
    private _signingServiceName?;
    get signingServiceName(): string;
    set signingServiceName(value: string);
    resetSigningServiceName(): void;
    get signingServiceNameInput(): string | undefined;
}
export interface AppsyncDataSourceHttpConfigAuthorizationConfig {
    /**
    * The authorization type that the HTTP endpoint requires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#authorization_type AppsyncDataSource#authorization_type}
    */
    readonly authorizationType?: string;
    /**
    * The AWS Identity and Access Management settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#aws_iam_config AppsyncDataSource#aws_iam_config}
    */
    readonly awsIamConfig?: AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfig;
}
export declare function appsyncDataSourceHttpConfigAuthorizationConfigToTerraform(struct?: AppsyncDataSourceHttpConfigAuthorizationConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceHttpConfigAuthorizationConfigToHclTerraform(struct?: AppsyncDataSourceHttpConfigAuthorizationConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceHttpConfigAuthorizationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceHttpConfigAuthorizationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceHttpConfigAuthorizationConfig | cdktn.IResolvable | undefined);
    private _authorizationType?;
    get authorizationType(): string;
    set authorizationType(value: string);
    resetAuthorizationType(): void;
    get authorizationTypeInput(): string | undefined;
    private _awsIamConfig;
    get awsIamConfig(): AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfigOutputReference;
    putAwsIamConfig(value: AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfig): void;
    resetAwsIamConfig(): void;
    get awsIamConfigInput(): cdktn.IResolvable | AppsyncDataSourceHttpConfigAuthorizationConfigAwsIamConfig | undefined;
}
export interface AppsyncDataSourceHttpConfig {
    /**
    * The authorization configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#authorization_config AppsyncDataSource#authorization_config}
    */
    readonly authorizationConfig?: AppsyncDataSourceHttpConfigAuthorizationConfig;
    /**
    * The endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#endpoint AppsyncDataSource#endpoint}
    */
    readonly endpoint?: string;
}
export declare function appsyncDataSourceHttpConfigToTerraform(struct?: AppsyncDataSourceHttpConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceHttpConfigToHclTerraform(struct?: AppsyncDataSourceHttpConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceHttpConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceHttpConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceHttpConfig | cdktn.IResolvable | undefined);
    private _authorizationConfig;
    get authorizationConfig(): AppsyncDataSourceHttpConfigAuthorizationConfigOutputReference;
    putAuthorizationConfig(value: AppsyncDataSourceHttpConfigAuthorizationConfig): void;
    resetAuthorizationConfig(): void;
    get authorizationConfigInput(): cdktn.IResolvable | AppsyncDataSourceHttpConfigAuthorizationConfig | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
}
export interface AppsyncDataSourceLambdaConfig {
    /**
    * The ARN for the Lambda function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#lambda_function_arn AppsyncDataSource#lambda_function_arn}
    */
    readonly lambdaFunctionArn?: string;
}
export declare function appsyncDataSourceLambdaConfigToTerraform(struct?: AppsyncDataSourceLambdaConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceLambdaConfigToHclTerraform(struct?: AppsyncDataSourceLambdaConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceLambdaConfig | cdktn.IResolvable | undefined);
    private _lambdaFunctionArn?;
    get lambdaFunctionArn(): string;
    set lambdaFunctionArn(value: string);
    resetLambdaFunctionArn(): void;
    get lambdaFunctionArnInput(): string | undefined;
}
export interface AppsyncDataSourceOpenSearchServiceConfig {
    /**
    * The AWS Region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#aws_region AppsyncDataSource#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * The endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#endpoint AppsyncDataSource#endpoint}
    */
    readonly endpoint?: string;
}
export declare function appsyncDataSourceOpenSearchServiceConfigToTerraform(struct?: AppsyncDataSourceOpenSearchServiceConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceOpenSearchServiceConfigToHclTerraform(struct?: AppsyncDataSourceOpenSearchServiceConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceOpenSearchServiceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceOpenSearchServiceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceOpenSearchServiceConfig | cdktn.IResolvable | undefined);
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
}
export interface AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfig {
    /**
    * AWS Region for RDS HTTP endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#aws_region AppsyncDataSource#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * The ARN for database credentials stored in AWS Secrets Manager.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#aws_secret_store_arn AppsyncDataSource#aws_secret_store_arn}
    */
    readonly awsSecretStoreArn?: string;
    /**
    * Logical database name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#database_name AppsyncDataSource#database_name}
    */
    readonly databaseName?: string;
    /**
    * Amazon RDS cluster Amazon Resource Name (ARN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#db_cluster_identifier AppsyncDataSource#db_cluster_identifier}
    */
    readonly dbClusterIdentifier?: string;
    /**
    * Logical schema name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#schema AppsyncDataSource#schema}
    */
    readonly schema?: string;
}
export declare function appsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfigToTerraform(struct?: AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfigToHclTerraform(struct?: AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfig | cdktn.IResolvable | undefined);
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _awsSecretStoreArn?;
    get awsSecretStoreArn(): string;
    set awsSecretStoreArn(value: string);
    resetAwsSecretStoreArn(): void;
    get awsSecretStoreArnInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _dbClusterIdentifier?;
    get dbClusterIdentifier(): string;
    set dbClusterIdentifier(value: string);
    resetDbClusterIdentifier(): void;
    get dbClusterIdentifierInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface AppsyncDataSourceRelationalDatabaseConfig {
    /**
    * Information about the Amazon RDS resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#rds_http_endpoint_config AppsyncDataSource#rds_http_endpoint_config}
    */
    readonly rdsHttpEndpointConfig?: AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfig;
    /**
    * The type of relational data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#relational_database_source_type AppsyncDataSource#relational_database_source_type}
    */
    readonly relationalDatabaseSourceType?: string;
}
export declare function appsyncDataSourceRelationalDatabaseConfigToTerraform(struct?: AppsyncDataSourceRelationalDatabaseConfig | cdktn.IResolvable): any;
export declare function appsyncDataSourceRelationalDatabaseConfigToHclTerraform(struct?: AppsyncDataSourceRelationalDatabaseConfig | cdktn.IResolvable): any;
export declare class AppsyncDataSourceRelationalDatabaseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsyncDataSourceRelationalDatabaseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncDataSourceRelationalDatabaseConfig | cdktn.IResolvable | undefined);
    private _rdsHttpEndpointConfig;
    get rdsHttpEndpointConfig(): AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfigOutputReference;
    putRdsHttpEndpointConfig(value: AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfig): void;
    resetRdsHttpEndpointConfig(): void;
    get rdsHttpEndpointConfigInput(): cdktn.IResolvable | AppsyncDataSourceRelationalDatabaseConfigRdsHttpEndpointConfig | undefined;
    private _relationalDatabaseSourceType?;
    get relationalDatabaseSourceType(): string;
    set relationalDatabaseSourceType(value: string);
    resetRelationalDatabaseSourceType(): void;
    get relationalDatabaseSourceTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source awscc_appsync_data_source}
*/
export declare class AppsyncDataSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appsync_data_source";
    /**
    * Generates CDKTN code for importing a AppsyncDataSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncDataSource to import
    * @param importFromId The id of the existing AppsyncDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appsync_data_source awscc_appsync_data_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncDataSourceConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncDataSourceConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get dataSourceArn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dynamoDbConfig;
    get dynamoDbConfig(): AppsyncDataSourceDynamoDbConfigOutputReference;
    putDynamoDbConfig(value: AppsyncDataSourceDynamoDbConfig): void;
    resetDynamoDbConfig(): void;
    get dynamoDbConfigInput(): cdktn.IResolvable | AppsyncDataSourceDynamoDbConfig | undefined;
    private _elasticsearchConfig;
    get elasticsearchConfig(): AppsyncDataSourceElasticsearchConfigOutputReference;
    putElasticsearchConfig(value: AppsyncDataSourceElasticsearchConfig): void;
    resetElasticsearchConfig(): void;
    get elasticsearchConfigInput(): cdktn.IResolvable | AppsyncDataSourceElasticsearchConfig | undefined;
    private _eventBridgeConfig;
    get eventBridgeConfig(): AppsyncDataSourceEventBridgeConfigOutputReference;
    putEventBridgeConfig(value: AppsyncDataSourceEventBridgeConfig): void;
    resetEventBridgeConfig(): void;
    get eventBridgeConfigInput(): cdktn.IResolvable | AppsyncDataSourceEventBridgeConfig | undefined;
    private _httpConfig;
    get httpConfig(): AppsyncDataSourceHttpConfigOutputReference;
    putHttpConfig(value: AppsyncDataSourceHttpConfig): void;
    resetHttpConfig(): void;
    get httpConfigInput(): cdktn.IResolvable | AppsyncDataSourceHttpConfig | undefined;
    get id(): string;
    private _lambdaConfig;
    get lambdaConfig(): AppsyncDataSourceLambdaConfigOutputReference;
    putLambdaConfig(value: AppsyncDataSourceLambdaConfig): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): cdktn.IResolvable | AppsyncDataSourceLambdaConfig | undefined;
    private _metricsConfig?;
    get metricsConfig(): string;
    set metricsConfig(value: string);
    resetMetricsConfig(): void;
    get metricsConfigInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _openSearchServiceConfig;
    get openSearchServiceConfig(): AppsyncDataSourceOpenSearchServiceConfigOutputReference;
    putOpenSearchServiceConfig(value: AppsyncDataSourceOpenSearchServiceConfig): void;
    resetOpenSearchServiceConfig(): void;
    get openSearchServiceConfigInput(): cdktn.IResolvable | AppsyncDataSourceOpenSearchServiceConfig | undefined;
    private _relationalDatabaseConfig;
    get relationalDatabaseConfig(): AppsyncDataSourceRelationalDatabaseConfigOutputReference;
    putRelationalDatabaseConfig(value: AppsyncDataSourceRelationalDatabaseConfig): void;
    resetRelationalDatabaseConfig(): void;
    get relationalDatabaseConfigInput(): cdktn.IResolvable | AppsyncDataSourceRelationalDatabaseConfig | undefined;
    private _serviceRoleArn?;
    get serviceRoleArn(): string;
    set serviceRoleArn(value: string);
    resetServiceRoleArn(): void;
    get serviceRoleArnInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
