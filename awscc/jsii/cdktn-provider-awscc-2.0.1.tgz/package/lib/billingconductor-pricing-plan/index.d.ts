/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BillingconductorPricingPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan#description BillingconductorPricingPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan#name BillingconductorPricingPlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan#pricing_rule_arns BillingconductorPricingPlan#pricing_rule_arns}
    */
    readonly pricingRuleArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan#tags BillingconductorPricingPlan#tags}
    */
    readonly tags?: BillingconductorPricingPlanTags[] | cdktn.IResolvable;
}
export interface BillingconductorPricingPlanTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan#key BillingconductorPricingPlan#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan#value BillingconductorPricingPlan#value}
    */
    readonly value?: string;
}
export declare function billingconductorPricingPlanTagsToTerraform(struct?: BillingconductorPricingPlanTags | cdktn.IResolvable): any;
export declare function billingconductorPricingPlanTagsToHclTerraform(struct?: BillingconductorPricingPlanTags | cdktn.IResolvable): any;
export declare class BillingconductorPricingPlanTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingconductorPricingPlanTags | cdktn.IResolvable | undefined;
    set internalValue(value: BillingconductorPricingPlanTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BillingconductorPricingPlanTagsList extends cdktn.ComplexList {
    internalValue?: BillingconductorPricingPlanTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingconductorPricingPlanTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan awscc_billingconductor_pricing_plan}
*/
export declare class BillingconductorPricingPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_billingconductor_pricing_plan";
    /**
    * Generates CDKTN code for importing a BillingconductorPricingPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BillingconductorPricingPlan to import
    * @param importFromId The id of the existing BillingconductorPricingPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BillingconductorPricingPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/billingconductor_pricing_plan awscc_billingconductor_pricing_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BillingconductorPricingPlanConfig
    */
    constructor(scope: Construct, id: string, config: BillingconductorPricingPlanConfig);
    get arn(): string;
    get creationTime(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pricingRuleArns?;
    get pricingRuleArns(): string[];
    set pricingRuleArns(value: string[]);
    resetPricingRuleArns(): void;
    get pricingRuleArnsInput(): string[] | undefined;
    get size(): number;
    private _tags;
    get tags(): BillingconductorPricingPlanTagsList;
    putTags(value: BillingconductorPricingPlanTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BillingconductorPricingPlanTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
