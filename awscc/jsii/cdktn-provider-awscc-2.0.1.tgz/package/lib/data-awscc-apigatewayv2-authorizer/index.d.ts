/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayv2AuthorizerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigatewayv2_authorizer#id DataAwsccApigatewayv2Authorizer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayv2AuthorizerJwtConfiguration {
}
export declare function dataAwsccApigatewayv2AuthorizerJwtConfigurationToTerraform(struct?: DataAwsccApigatewayv2AuthorizerJwtConfiguration): any;
export declare function dataAwsccApigatewayv2AuthorizerJwtConfigurationToHclTerraform(struct?: DataAwsccApigatewayv2AuthorizerJwtConfiguration): any;
export declare class DataAwsccApigatewayv2AuthorizerJwtConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayv2AuthorizerJwtConfiguration | undefined;
    set internalValue(value: DataAwsccApigatewayv2AuthorizerJwtConfiguration | undefined);
    get audience(): string[];
    get issuer(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigatewayv2_authorizer awscc_apigatewayv2_authorizer}
*/
export declare class DataAwsccApigatewayv2Authorizer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigatewayv2_authorizer";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayv2Authorizer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayv2Authorizer to import
    * @param importFromId The id of the existing DataAwsccApigatewayv2Authorizer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigatewayv2_authorizer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayv2Authorizer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigatewayv2_authorizer awscc_apigatewayv2_authorizer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayv2AuthorizerConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayv2AuthorizerConfig);
    get apiId(): string;
    get authorizerCredentialsArn(): string;
    get authorizerId(): string;
    get authorizerPayloadFormatVersion(): string;
    get authorizerResultTtlInSeconds(): number;
    get authorizerType(): string;
    get authorizerUri(): string;
    get enableSimpleResponses(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get identitySource(): string[];
    get identityValidationExpression(): string;
    private _jwtConfiguration;
    get jwtConfiguration(): DataAwsccApigatewayv2AuthorizerJwtConfigurationOutputReference;
    get name(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
