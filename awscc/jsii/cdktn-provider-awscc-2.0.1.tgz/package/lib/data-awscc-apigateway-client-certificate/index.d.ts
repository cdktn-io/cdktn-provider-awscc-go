/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayClientCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_client_certificate#id DataAwsccApigatewayClientCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayClientCertificateTags {
}
export declare function dataAwsccApigatewayClientCertificateTagsToTerraform(struct?: DataAwsccApigatewayClientCertificateTags): any;
export declare function dataAwsccApigatewayClientCertificateTagsToHclTerraform(struct?: DataAwsccApigatewayClientCertificateTags): any;
export declare class DataAwsccApigatewayClientCertificateTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayClientCertificateTags | undefined;
    set internalValue(value: DataAwsccApigatewayClientCertificateTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayClientCertificateTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayClientCertificateTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_client_certificate awscc_apigateway_client_certificate}
*/
export declare class DataAwsccApigatewayClientCertificate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_client_certificate";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayClientCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayClientCertificate to import
    * @param importFromId The id of the existing DataAwsccApigatewayClientCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_client_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayClientCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_client_certificate awscc_apigateway_client_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayClientCertificateConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayClientCertificateConfig);
    get clientCertificateId(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _tags;
    get tags(): DataAwsccApigatewayClientCertificateTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
