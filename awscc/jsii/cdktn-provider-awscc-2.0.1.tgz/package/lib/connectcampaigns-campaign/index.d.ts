/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectcampaignsCampaignConfig extends cdktn.TerraformMetaArguments {
    /**
    * Amazon Connect Instance Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#connect_instance_arn ConnectcampaignsCampaign#connect_instance_arn}
    */
    readonly connectInstanceArn: string;
    /**
    * The possible types of dialer config parameters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#dialer_config ConnectcampaignsCampaign#dialer_config}
    */
    readonly dialerConfig: ConnectcampaignsCampaignDialerConfig;
    /**
    * Amazon Connect Campaign Name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#name ConnectcampaignsCampaign#name}
    */
    readonly name: string;
    /**
    * The configuration used for outbound calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#outbound_call_config ConnectcampaignsCampaign#outbound_call_config}
    */
    readonly outboundCallConfig: ConnectcampaignsCampaignOutboundCallConfig;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#tags ConnectcampaignsCampaign#tags}
    */
    readonly tags?: ConnectcampaignsCampaignTags[] | cdktn.IResolvable;
}
export interface ConnectcampaignsCampaignDialerConfigAgentlessDialerConfig {
    /**
    * Allocates dialing capacity for this campaign between multiple active campaigns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#dialing_capacity ConnectcampaignsCampaign#dialing_capacity}
    */
    readonly dialingCapacity?: number;
}
export declare function connectcampaignsCampaignDialerConfigAgentlessDialerConfigToTerraform(struct?: ConnectcampaignsCampaignDialerConfigAgentlessDialerConfig | cdktn.IResolvable): any;
export declare function connectcampaignsCampaignDialerConfigAgentlessDialerConfigToHclTerraform(struct?: ConnectcampaignsCampaignDialerConfigAgentlessDialerConfig | cdktn.IResolvable): any;
export declare class ConnectcampaignsCampaignDialerConfigAgentlessDialerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectcampaignsCampaignDialerConfigAgentlessDialerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectcampaignsCampaignDialerConfigAgentlessDialerConfig | cdktn.IResolvable | undefined);
    private _dialingCapacity?;
    get dialingCapacity(): number;
    set dialingCapacity(value: number);
    resetDialingCapacity(): void;
    get dialingCapacityInput(): number | undefined;
}
export interface ConnectcampaignsCampaignDialerConfigPredictiveDialerConfig {
    /**
    * The bandwidth allocation of a queue resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#bandwidth_allocation ConnectcampaignsCampaign#bandwidth_allocation}
    */
    readonly bandwidthAllocation?: number;
    /**
    * Allocates dialing capacity for this campaign between multiple active campaigns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#dialing_capacity ConnectcampaignsCampaign#dialing_capacity}
    */
    readonly dialingCapacity?: number;
}
export declare function connectcampaignsCampaignDialerConfigPredictiveDialerConfigToTerraform(struct?: ConnectcampaignsCampaignDialerConfigPredictiveDialerConfig | cdktn.IResolvable): any;
export declare function connectcampaignsCampaignDialerConfigPredictiveDialerConfigToHclTerraform(struct?: ConnectcampaignsCampaignDialerConfigPredictiveDialerConfig | cdktn.IResolvable): any;
export declare class ConnectcampaignsCampaignDialerConfigPredictiveDialerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectcampaignsCampaignDialerConfigPredictiveDialerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectcampaignsCampaignDialerConfigPredictiveDialerConfig | cdktn.IResolvable | undefined);
    private _bandwidthAllocation?;
    get bandwidthAllocation(): number;
    set bandwidthAllocation(value: number);
    resetBandwidthAllocation(): void;
    get bandwidthAllocationInput(): number | undefined;
    private _dialingCapacity?;
    get dialingCapacity(): number;
    set dialingCapacity(value: number);
    resetDialingCapacity(): void;
    get dialingCapacityInput(): number | undefined;
}
export interface ConnectcampaignsCampaignDialerConfigProgressiveDialerConfig {
    /**
    * The bandwidth allocation of a queue resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#bandwidth_allocation ConnectcampaignsCampaign#bandwidth_allocation}
    */
    readonly bandwidthAllocation?: number;
    /**
    * Allocates dialing capacity for this campaign between multiple active campaigns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#dialing_capacity ConnectcampaignsCampaign#dialing_capacity}
    */
    readonly dialingCapacity?: number;
}
export declare function connectcampaignsCampaignDialerConfigProgressiveDialerConfigToTerraform(struct?: ConnectcampaignsCampaignDialerConfigProgressiveDialerConfig | cdktn.IResolvable): any;
export declare function connectcampaignsCampaignDialerConfigProgressiveDialerConfigToHclTerraform(struct?: ConnectcampaignsCampaignDialerConfigProgressiveDialerConfig | cdktn.IResolvable): any;
export declare class ConnectcampaignsCampaignDialerConfigProgressiveDialerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectcampaignsCampaignDialerConfigProgressiveDialerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectcampaignsCampaignDialerConfigProgressiveDialerConfig | cdktn.IResolvable | undefined);
    private _bandwidthAllocation?;
    get bandwidthAllocation(): number;
    set bandwidthAllocation(value: number);
    resetBandwidthAllocation(): void;
    get bandwidthAllocationInput(): number | undefined;
    private _dialingCapacity?;
    get dialingCapacity(): number;
    set dialingCapacity(value: number);
    resetDialingCapacity(): void;
    get dialingCapacityInput(): number | undefined;
}
export interface ConnectcampaignsCampaignDialerConfig {
    /**
    * Agentless Dialer config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#agentless_dialer_config ConnectcampaignsCampaign#agentless_dialer_config}
    */
    readonly agentlessDialerConfig?: ConnectcampaignsCampaignDialerConfigAgentlessDialerConfig;
    /**
    * Predictive Dialer config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#predictive_dialer_config ConnectcampaignsCampaign#predictive_dialer_config}
    */
    readonly predictiveDialerConfig?: ConnectcampaignsCampaignDialerConfigPredictiveDialerConfig;
    /**
    * Progressive Dialer config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#progressive_dialer_config ConnectcampaignsCampaign#progressive_dialer_config}
    */
    readonly progressiveDialerConfig?: ConnectcampaignsCampaignDialerConfigProgressiveDialerConfig;
}
export declare function connectcampaignsCampaignDialerConfigToTerraform(struct?: ConnectcampaignsCampaignDialerConfig | cdktn.IResolvable): any;
export declare function connectcampaignsCampaignDialerConfigToHclTerraform(struct?: ConnectcampaignsCampaignDialerConfig | cdktn.IResolvable): any;
export declare class ConnectcampaignsCampaignDialerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectcampaignsCampaignDialerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectcampaignsCampaignDialerConfig | cdktn.IResolvable | undefined);
    private _agentlessDialerConfig;
    get agentlessDialerConfig(): ConnectcampaignsCampaignDialerConfigAgentlessDialerConfigOutputReference;
    putAgentlessDialerConfig(value: ConnectcampaignsCampaignDialerConfigAgentlessDialerConfig): void;
    resetAgentlessDialerConfig(): void;
    get agentlessDialerConfigInput(): cdktn.IResolvable | ConnectcampaignsCampaignDialerConfigAgentlessDialerConfig | undefined;
    private _predictiveDialerConfig;
    get predictiveDialerConfig(): ConnectcampaignsCampaignDialerConfigPredictiveDialerConfigOutputReference;
    putPredictiveDialerConfig(value: ConnectcampaignsCampaignDialerConfigPredictiveDialerConfig): void;
    resetPredictiveDialerConfig(): void;
    get predictiveDialerConfigInput(): cdktn.IResolvable | ConnectcampaignsCampaignDialerConfigPredictiveDialerConfig | undefined;
    private _progressiveDialerConfig;
    get progressiveDialerConfig(): ConnectcampaignsCampaignDialerConfigProgressiveDialerConfigOutputReference;
    putProgressiveDialerConfig(value: ConnectcampaignsCampaignDialerConfigProgressiveDialerConfig): void;
    resetProgressiveDialerConfig(): void;
    get progressiveDialerConfigInput(): cdktn.IResolvable | ConnectcampaignsCampaignDialerConfigProgressiveDialerConfig | undefined;
}
export interface ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfig {
    /**
    * Enables detection of prompts (e.g., beep after after a voicemail greeting)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#await_answer_machine_prompt ConnectcampaignsCampaign#await_answer_machine_prompt}
    */
    readonly awaitAnswerMachinePrompt?: boolean | cdktn.IResolvable;
    /**
    * Flag to decided whether outbound calls should have answering machine detection enabled or not
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#enable_answer_machine_detection ConnectcampaignsCampaign#enable_answer_machine_detection}
    */
    readonly enableAnswerMachineDetection?: boolean | cdktn.IResolvable;
}
export declare function connectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfigToTerraform(struct?: ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfig | cdktn.IResolvable): any;
export declare function connectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfigToHclTerraform(struct?: ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfig | cdktn.IResolvable): any;
export declare class ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfig | cdktn.IResolvable | undefined);
    private _awaitAnswerMachinePrompt?;
    get awaitAnswerMachinePrompt(): boolean | cdktn.IResolvable;
    set awaitAnswerMachinePrompt(value: boolean | cdktn.IResolvable);
    resetAwaitAnswerMachinePrompt(): void;
    get awaitAnswerMachinePromptInput(): boolean | cdktn.IResolvable | undefined;
    private _enableAnswerMachineDetection?;
    get enableAnswerMachineDetection(): boolean | cdktn.IResolvable;
    set enableAnswerMachineDetection(value: boolean | cdktn.IResolvable);
    resetEnableAnswerMachineDetection(): void;
    get enableAnswerMachineDetectionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ConnectcampaignsCampaignOutboundCallConfig {
    /**
    * The configuration used for answering machine detection during outbound calls
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#answer_machine_detection_config ConnectcampaignsCampaign#answer_machine_detection_config}
    */
    readonly answerMachineDetectionConfig?: ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfig;
    /**
    * The identifier of the contact flow for the outbound call.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#connect_contact_flow_arn ConnectcampaignsCampaign#connect_contact_flow_arn}
    */
    readonly connectContactFlowArn: string;
    /**
    * The queue for the call. If you specify a queue, the phone displayed for caller ID is the phone number specified in the queue. If you do not specify a queue, the queue defined in the contact flow is used. If you do not specify a queue, you must specify a source phone number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#connect_queue_arn ConnectcampaignsCampaign#connect_queue_arn}
    */
    readonly connectQueueArn?: string;
    /**
    * The phone number associated with the Amazon Connect instance, in E.164 format. If you do not specify a source phone number, you must specify a queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#connect_source_phone_number ConnectcampaignsCampaign#connect_source_phone_number}
    */
    readonly connectSourcePhoneNumber?: string;
}
export declare function connectcampaignsCampaignOutboundCallConfigToTerraform(struct?: ConnectcampaignsCampaignOutboundCallConfig | cdktn.IResolvable): any;
export declare function connectcampaignsCampaignOutboundCallConfigToHclTerraform(struct?: ConnectcampaignsCampaignOutboundCallConfig | cdktn.IResolvable): any;
export declare class ConnectcampaignsCampaignOutboundCallConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectcampaignsCampaignOutboundCallConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectcampaignsCampaignOutboundCallConfig | cdktn.IResolvable | undefined);
    private _answerMachineDetectionConfig;
    get answerMachineDetectionConfig(): ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfigOutputReference;
    putAnswerMachineDetectionConfig(value: ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfig): void;
    resetAnswerMachineDetectionConfig(): void;
    get answerMachineDetectionConfigInput(): cdktn.IResolvable | ConnectcampaignsCampaignOutboundCallConfigAnswerMachineDetectionConfig | undefined;
    private _connectContactFlowArn?;
    get connectContactFlowArn(): string;
    set connectContactFlowArn(value: string);
    get connectContactFlowArnInput(): string | undefined;
    private _connectQueueArn?;
    get connectQueueArn(): string;
    set connectQueueArn(value: string);
    resetConnectQueueArn(): void;
    get connectQueueArnInput(): string | undefined;
    private _connectSourcePhoneNumber?;
    get connectSourcePhoneNumber(): string;
    set connectSourcePhoneNumber(value: string);
    resetConnectSourcePhoneNumber(): void;
    get connectSourcePhoneNumberInput(): string | undefined;
}
export interface ConnectcampaignsCampaignTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#key ConnectcampaignsCampaign#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that's 1 to 256 characters in length.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#value ConnectcampaignsCampaign#value}
    */
    readonly value?: string;
}
export declare function connectcampaignsCampaignTagsToTerraform(struct?: ConnectcampaignsCampaignTags | cdktn.IResolvable): any;
export declare function connectcampaignsCampaignTagsToHclTerraform(struct?: ConnectcampaignsCampaignTags | cdktn.IResolvable): any;
export declare class ConnectcampaignsCampaignTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectcampaignsCampaignTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectcampaignsCampaignTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectcampaignsCampaignTagsList extends cdktn.ComplexList {
    internalValue?: ConnectcampaignsCampaignTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectcampaignsCampaignTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign awscc_connectcampaigns_campaign}
*/
export declare class ConnectcampaignsCampaign extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connectcampaigns_campaign";
    /**
    * Generates CDKTN code for importing a ConnectcampaignsCampaign resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectcampaignsCampaign to import
    * @param importFromId The id of the existing ConnectcampaignsCampaign that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectcampaignsCampaign to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connectcampaigns_campaign awscc_connectcampaigns_campaign} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectcampaignsCampaignConfig
    */
    constructor(scope: Construct, id: string, config: ConnectcampaignsCampaignConfig);
    get arn(): string;
    private _connectInstanceArn?;
    get connectInstanceArn(): string;
    set connectInstanceArn(value: string);
    get connectInstanceArnInput(): string | undefined;
    private _dialerConfig;
    get dialerConfig(): ConnectcampaignsCampaignDialerConfigOutputReference;
    putDialerConfig(value: ConnectcampaignsCampaignDialerConfig): void;
    get dialerConfigInput(): cdktn.IResolvable | ConnectcampaignsCampaignDialerConfig | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outboundCallConfig;
    get outboundCallConfig(): ConnectcampaignsCampaignOutboundCallConfigOutputReference;
    putOutboundCallConfig(value: ConnectcampaignsCampaignOutboundCallConfig): void;
    get outboundCallConfigInput(): cdktn.IResolvable | ConnectcampaignsCampaignOutboundCallConfig | undefined;
    private _tags;
    get tags(): ConnectcampaignsCampaignTagsList;
    putTags(value: ConnectcampaignsCampaignTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectcampaignsCampaignTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
