/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAiopsInvestigationGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/aiops_investigation_group#id DataAwsccAiopsInvestigationGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAiopsInvestigationGroupChatbotNotificationChannels {
}
export declare function dataAwsccAiopsInvestigationGroupChatbotNotificationChannelsToTerraform(struct?: DataAwsccAiopsInvestigationGroupChatbotNotificationChannels): any;
export declare function dataAwsccAiopsInvestigationGroupChatbotNotificationChannelsToHclTerraform(struct?: DataAwsccAiopsInvestigationGroupChatbotNotificationChannels): any;
export declare class DataAwsccAiopsInvestigationGroupChatbotNotificationChannelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAiopsInvestigationGroupChatbotNotificationChannels | undefined;
    set internalValue(value: DataAwsccAiopsInvestigationGroupChatbotNotificationChannels | undefined);
    get chatConfigurationArns(): string[];
    get snsTopicArn(): string;
}
export declare class DataAwsccAiopsInvestigationGroupChatbotNotificationChannelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAiopsInvestigationGroupChatbotNotificationChannelsOutputReference;
}
export interface DataAwsccAiopsInvestigationGroupCrossAccountConfigurations {
}
export declare function dataAwsccAiopsInvestigationGroupCrossAccountConfigurationsToTerraform(struct?: DataAwsccAiopsInvestigationGroupCrossAccountConfigurations): any;
export declare function dataAwsccAiopsInvestigationGroupCrossAccountConfigurationsToHclTerraform(struct?: DataAwsccAiopsInvestigationGroupCrossAccountConfigurations): any;
export declare class DataAwsccAiopsInvestigationGroupCrossAccountConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAiopsInvestigationGroupCrossAccountConfigurations | undefined;
    set internalValue(value: DataAwsccAiopsInvestigationGroupCrossAccountConfigurations | undefined);
    get sourceRoleArn(): string;
}
export declare class DataAwsccAiopsInvestigationGroupCrossAccountConfigurationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAiopsInvestigationGroupCrossAccountConfigurationsOutputReference;
}
export interface DataAwsccAiopsInvestigationGroupEncryptionConfig {
}
export declare function dataAwsccAiopsInvestigationGroupEncryptionConfigToTerraform(struct?: DataAwsccAiopsInvestigationGroupEncryptionConfig): any;
export declare function dataAwsccAiopsInvestigationGroupEncryptionConfigToHclTerraform(struct?: DataAwsccAiopsInvestigationGroupEncryptionConfig): any;
export declare class DataAwsccAiopsInvestigationGroupEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAiopsInvestigationGroupEncryptionConfig | undefined;
    set internalValue(value: DataAwsccAiopsInvestigationGroupEncryptionConfig | undefined);
    get encryptionConfigurationType(): string;
    get kmsKeyId(): string;
}
export interface DataAwsccAiopsInvestigationGroupTags {
}
export declare function dataAwsccAiopsInvestigationGroupTagsToTerraform(struct?: DataAwsccAiopsInvestigationGroupTags): any;
export declare function dataAwsccAiopsInvestigationGroupTagsToHclTerraform(struct?: DataAwsccAiopsInvestigationGroupTags): any;
export declare class DataAwsccAiopsInvestigationGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAiopsInvestigationGroupTags | undefined;
    set internalValue(value: DataAwsccAiopsInvestigationGroupTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAiopsInvestigationGroupTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAiopsInvestigationGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/aiops_investigation_group awscc_aiops_investigation_group}
*/
export declare class DataAwsccAiopsInvestigationGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_aiops_investigation_group";
    /**
    * Generates CDKTN code for importing a DataAwsccAiopsInvestigationGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAiopsInvestigationGroup to import
    * @param importFromId The id of the existing DataAwsccAiopsInvestigationGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/aiops_investigation_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAiopsInvestigationGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/aiops_investigation_group awscc_aiops_investigation_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAiopsInvestigationGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAiopsInvestigationGroupConfig);
    get arn(): string;
    private _chatbotNotificationChannels;
    get chatbotNotificationChannels(): DataAwsccAiopsInvestigationGroupChatbotNotificationChannelsList;
    get createdAt(): string;
    get createdBy(): string;
    private _crossAccountConfigurations;
    get crossAccountConfigurations(): DataAwsccAiopsInvestigationGroupCrossAccountConfigurationsList;
    private _encryptionConfig;
    get encryptionConfig(): DataAwsccAiopsInvestigationGroupEncryptionConfigOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get investigationGroupPolicy(): string;
    get isCloudTrailEventHistoryEnabled(): cdktn.IResolvable;
    get lastModifiedAt(): string;
    get lastModifiedBy(): string;
    get name(): string;
    get retentionInDays(): number;
    get roleArn(): string;
    get tagKeyBoundaries(): string[];
    private _tags;
    get tags(): DataAwsccAiopsInvestigationGroupTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
