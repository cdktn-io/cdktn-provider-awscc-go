/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodeartifactDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codeartifact_domain#domain_name CodeartifactDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * The access control resource policy on the provided domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codeartifact_domain#permissions_policy_document CodeartifactDomain#permissions_policy_document}
    */
    readonly permissionsPolicyDocument?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codeartifact_domain#tags CodeartifactDomain#tags}
    */
    readonly tags?: CodeartifactDomainTags[] | cdktn.IResolvable;
}
export interface CodeartifactDomainTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codeartifact_domain#key CodeartifactDomain#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 1 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codeartifact_domain#value CodeartifactDomain#value}
    */
    readonly value?: string;
}
export declare function codeartifactDomainTagsToTerraform(struct?: CodeartifactDomainTags | cdktn.IResolvable): any;
export declare function codeartifactDomainTagsToHclTerraform(struct?: CodeartifactDomainTags | cdktn.IResolvable): any;
export declare class CodeartifactDomainTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodeartifactDomainTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodeartifactDomainTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodeartifactDomainTagsList extends cdktn.ComplexList {
    internalValue?: CodeartifactDomainTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodeartifactDomainTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codeartifact_domain awscc_codeartifact_domain}
*/
export declare class CodeartifactDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codeartifact_domain";
    /**
    * Generates CDKTN code for importing a CodeartifactDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodeartifactDomain to import
    * @param importFromId The id of the existing CodeartifactDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codeartifact_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodeartifactDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codeartifact_domain awscc_codeartifact_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodeartifactDomainConfig
    */
    constructor(scope: Construct, id: string, config: CodeartifactDomainConfig);
    get arn(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get encryptionKey(): string;
    get id(): string;
    get name(): string;
    get owner(): string;
    private _permissionsPolicyDocument?;
    get permissionsPolicyDocument(): string;
    set permissionsPolicyDocument(value: string);
    resetPermissionsPolicyDocument(): void;
    get permissionsPolicyDocumentInput(): string | undefined;
    private _tags;
    get tags(): CodeartifactDomainTagsList;
    putTags(value: CodeartifactDomainTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodeartifactDomainTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
