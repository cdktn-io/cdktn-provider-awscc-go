/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodebuildReportGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#delete_reports CodebuildReportGroup#delete_reports}
    */
    readonly deleteReports?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#export_config CodebuildReportGroup#export_config}
    */
    readonly exportConfig: CodebuildReportGroupExportConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#name CodebuildReportGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#tags CodebuildReportGroup#tags}
    */
    readonly tags?: CodebuildReportGroupTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#type CodebuildReportGroup#type}
    */
    readonly type: string;
}
export interface CodebuildReportGroupExportConfigS3Destination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#bucket CodebuildReportGroup#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#bucket_owner CodebuildReportGroup#bucket_owner}
    */
    readonly bucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#encryption_disabled CodebuildReportGroup#encryption_disabled}
    */
    readonly encryptionDisabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#encryption_key CodebuildReportGroup#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#packaging CodebuildReportGroup#packaging}
    */
    readonly packaging?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#path CodebuildReportGroup#path}
    */
    readonly path?: string;
}
export declare function codebuildReportGroupExportConfigS3DestinationToTerraform(struct?: CodebuildReportGroupExportConfigS3Destination | cdktn.IResolvable): any;
export declare function codebuildReportGroupExportConfigS3DestinationToHclTerraform(struct?: CodebuildReportGroupExportConfigS3Destination | cdktn.IResolvable): any;
export declare class CodebuildReportGroupExportConfigS3DestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodebuildReportGroupExportConfigS3Destination | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildReportGroupExportConfigS3Destination | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _bucketOwner?;
    get bucketOwner(): string;
    set bucketOwner(value: string);
    resetBucketOwner(): void;
    get bucketOwnerInput(): string | undefined;
    private _encryptionDisabled?;
    get encryptionDisabled(): boolean | cdktn.IResolvable;
    set encryptionDisabled(value: boolean | cdktn.IResolvable);
    resetEncryptionDisabled(): void;
    get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _packaging?;
    get packaging(): string;
    set packaging(value: string);
    resetPackaging(): void;
    get packagingInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface CodebuildReportGroupExportConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#export_config_type CodebuildReportGroup#export_config_type}
    */
    readonly exportConfigType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#s3_destination CodebuildReportGroup#s3_destination}
    */
    readonly s3Destination?: CodebuildReportGroupExportConfigS3Destination;
}
export declare function codebuildReportGroupExportConfigToTerraform(struct?: CodebuildReportGroupExportConfig | cdktn.IResolvable): any;
export declare function codebuildReportGroupExportConfigToHclTerraform(struct?: CodebuildReportGroupExportConfig | cdktn.IResolvable): any;
export declare class CodebuildReportGroupExportConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodebuildReportGroupExportConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildReportGroupExportConfig | cdktn.IResolvable | undefined);
    private _exportConfigType?;
    get exportConfigType(): string;
    set exportConfigType(value: string);
    get exportConfigTypeInput(): string | undefined;
    private _s3Destination;
    get s3Destination(): CodebuildReportGroupExportConfigS3DestinationOutputReference;
    putS3Destination(value: CodebuildReportGroupExportConfigS3Destination): void;
    resetS3Destination(): void;
    get s3DestinationInput(): cdktn.IResolvable | CodebuildReportGroupExportConfigS3Destination | undefined;
}
export interface CodebuildReportGroupTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#key CodebuildReportGroup#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#value CodebuildReportGroup#value}
    */
    readonly value?: string;
}
export declare function codebuildReportGroupTagsToTerraform(struct?: CodebuildReportGroupTags | cdktn.IResolvable): any;
export declare function codebuildReportGroupTagsToHclTerraform(struct?: CodebuildReportGroupTags | cdktn.IResolvable): any;
export declare class CodebuildReportGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodebuildReportGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildReportGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodebuildReportGroupTagsList extends cdktn.ComplexList {
    internalValue?: CodebuildReportGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodebuildReportGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group awscc_codebuild_report_group}
*/
export declare class CodebuildReportGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codebuild_report_group";
    /**
    * Generates CDKTN code for importing a CodebuildReportGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodebuildReportGroup to import
    * @param importFromId The id of the existing CodebuildReportGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodebuildReportGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_report_group awscc_codebuild_report_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodebuildReportGroupConfig
    */
    constructor(scope: Construct, id: string, config: CodebuildReportGroupConfig);
    get arn(): string;
    private _deleteReports?;
    get deleteReports(): boolean | cdktn.IResolvable;
    set deleteReports(value: boolean | cdktn.IResolvable);
    resetDeleteReports(): void;
    get deleteReportsInput(): boolean | cdktn.IResolvable | undefined;
    private _exportConfig;
    get exportConfig(): CodebuildReportGroupExportConfigOutputReference;
    putExportConfig(value: CodebuildReportGroupExportConfig): void;
    get exportConfigInput(): cdktn.IResolvable | CodebuildReportGroupExportConfig | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _tags;
    get tags(): CodebuildReportGroupTagsList;
    putTags(value: CodebuildReportGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodebuildReportGroupTags[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
