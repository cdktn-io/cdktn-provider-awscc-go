/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAccessanalyzerArchiveRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/accessanalyzer_archive_rule#id DataAwsccAccessanalyzerArchiveRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAccessanalyzerArchiveRuleFilter {
}
export declare function dataAwsccAccessanalyzerArchiveRuleFilterToTerraform(struct?: DataAwsccAccessanalyzerArchiveRuleFilter): any;
export declare function dataAwsccAccessanalyzerArchiveRuleFilterToHclTerraform(struct?: DataAwsccAccessanalyzerArchiveRuleFilter): any;
export declare class DataAwsccAccessanalyzerArchiveRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataAwsccAccessanalyzerArchiveRuleFilter | undefined;
    set internalValue(value: DataAwsccAccessanalyzerArchiveRuleFilter | undefined);
    get contains(): string[];
    get eq(): string[];
    get exists(): cdktn.IResolvable;
    get neq(): string[];
}
export declare class DataAwsccAccessanalyzerArchiveRuleFilterMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataAwsccAccessanalyzerArchiveRuleFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/accessanalyzer_archive_rule awscc_accessanalyzer_archive_rule}
*/
export declare class DataAwsccAccessanalyzerArchiveRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_accessanalyzer_archive_rule";
    /**
    * Generates CDKTN code for importing a DataAwsccAccessanalyzerArchiveRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAccessanalyzerArchiveRule to import
    * @param importFromId The id of the existing DataAwsccAccessanalyzerArchiveRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/accessanalyzer_archive_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAccessanalyzerArchiveRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/accessanalyzer_archive_rule awscc_accessanalyzer_archive_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAccessanalyzerArchiveRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAccessanalyzerArchiveRuleConfig);
    get analyzerName(): string;
    get arn(): string;
    get createdAt(): string;
    private _filter;
    get filter(): DataAwsccAccessanalyzerArchiveRuleFilterMap;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get ruleName(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
