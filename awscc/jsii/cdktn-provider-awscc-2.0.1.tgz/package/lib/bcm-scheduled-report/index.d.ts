/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BcmScheduledReportConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ARN of the dashboard associated with the scheduled report. Managed dashboards cannot be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#dashboard_arn BcmScheduledReport#dashboard_arn}
    */
    readonly dashboardArn: string;
    /**
    * A description of the scheduled report's purpose or contents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#description BcmScheduledReport#description}
    */
    readonly description?: string;
    /**
    * The name of the scheduled report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#name BcmScheduledReport#name}
    */
    readonly name: string;
    /**
    * The schedule configuration that defines when and how often the report is generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#schedule_config BcmScheduledReport#schedule_config}
    */
    readonly scheduleConfig: BcmScheduledReportScheduleConfig;
    /**
    * The ARN of the IAM role that the scheduled report uses to execute. AWS Billing and Cost Management Dashboards assumes this IAM role while executing the scheduled report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#scheduled_report_execution_role_arn BcmScheduledReport#scheduled_report_execution_role_arn}
    */
    readonly scheduledReportExecutionRoleArn: string;
    /**
    * The tags applied to the scheduled report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#tags BcmScheduledReport#tags}
    */
    readonly tags?: BcmScheduledReportTags[] | cdktn.IResolvable;
    /**
    * The date range override applied to widgets in the scheduled report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#widget_date_range_override BcmScheduledReport#widget_date_range_override}
    */
    readonly widgetDateRangeOverride?: BcmScheduledReportWidgetDateRangeOverride;
    /**
    * The list of widget identifiers included in the scheduled report. If not specified, all widgets in the dashboard are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#widget_ids BcmScheduledReport#widget_ids}
    */
    readonly widgetIds?: string[];
}
export interface BcmScheduledReportHealthStatus {
}
export declare function bcmScheduledReportHealthStatusToTerraform(struct?: BcmScheduledReportHealthStatus): any;
export declare function bcmScheduledReportHealthStatusToHclTerraform(struct?: BcmScheduledReportHealthStatus): any;
export declare class BcmScheduledReportHealthStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmScheduledReportHealthStatus | undefined;
    set internalValue(value: BcmScheduledReportHealthStatus | undefined);
    get lastRefreshedAt(): string;
    get statusCode(): string;
}
export interface BcmScheduledReportScheduleConfigSchedulePeriod {
    /**
    * The time at which the schedule stops being active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#end_time BcmScheduledReport#end_time}
    */
    readonly endTime?: string;
    /**
    * The time at which the schedule becomes active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#start_time BcmScheduledReport#start_time}
    */
    readonly startTime?: string;
}
export declare function bcmScheduledReportScheduleConfigSchedulePeriodToTerraform(struct?: BcmScheduledReportScheduleConfigSchedulePeriod | cdktn.IResolvable): any;
export declare function bcmScheduledReportScheduleConfigSchedulePeriodToHclTerraform(struct?: BcmScheduledReportScheduleConfigSchedulePeriod | cdktn.IResolvable): any;
export declare class BcmScheduledReportScheduleConfigSchedulePeriodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmScheduledReportScheduleConfigSchedulePeriod | cdktn.IResolvable | undefined;
    set internalValue(value: BcmScheduledReportScheduleConfigSchedulePeriod | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export interface BcmScheduledReportScheduleConfig {
    /**
    * The schedule expression that specifies when to trigger the scheduled report run. This value must be a cron expression consisting of six fields separated by white spaces: cron(minutes hours day_of_month month day_of_week year).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#schedule_expression BcmScheduledReport#schedule_expression}
    */
    readonly scheduleExpression?: string;
    /**
    * The time zone for the schedule expression, for example, UTC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#schedule_expression_time_zone BcmScheduledReport#schedule_expression_time_zone}
    */
    readonly scheduleExpressionTimeZone?: string;
    /**
    * The time period during which the schedule is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#schedule_period BcmScheduledReport#schedule_period}
    */
    readonly schedulePeriod?: BcmScheduledReportScheduleConfigSchedulePeriod;
    /**
    * The state of the schedule. ENABLED means the scheduled report runs according to its schedule expression. DISABLED means the scheduled report is paused and will not run until re-enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#state BcmScheduledReport#state}
    */
    readonly state?: string;
}
export declare function bcmScheduledReportScheduleConfigToTerraform(struct?: BcmScheduledReportScheduleConfig | cdktn.IResolvable): any;
export declare function bcmScheduledReportScheduleConfigToHclTerraform(struct?: BcmScheduledReportScheduleConfig | cdktn.IResolvable): any;
export declare class BcmScheduledReportScheduleConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmScheduledReportScheduleConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BcmScheduledReportScheduleConfig | cdktn.IResolvable | undefined);
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    resetScheduleExpression(): void;
    get scheduleExpressionInput(): string | undefined;
    private _scheduleExpressionTimeZone?;
    get scheduleExpressionTimeZone(): string;
    set scheduleExpressionTimeZone(value: string);
    resetScheduleExpressionTimeZone(): void;
    get scheduleExpressionTimeZoneInput(): string | undefined;
    private _schedulePeriod;
    get schedulePeriod(): BcmScheduledReportScheduleConfigSchedulePeriodOutputReference;
    putSchedulePeriod(value: BcmScheduledReportScheduleConfigSchedulePeriod): void;
    resetSchedulePeriod(): void;
    get schedulePeriodInput(): cdktn.IResolvable | BcmScheduledReportScheduleConfigSchedulePeriod | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface BcmScheduledReportTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#key BcmScheduledReport#key}
    */
    readonly key?: string;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#value BcmScheduledReport#value}
    */
    readonly value?: string;
}
export declare function bcmScheduledReportTagsToTerraform(struct?: BcmScheduledReportTags | cdktn.IResolvable): any;
export declare function bcmScheduledReportTagsToHclTerraform(struct?: BcmScheduledReportTags | cdktn.IResolvable): any;
export declare class BcmScheduledReportTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmScheduledReportTags | cdktn.IResolvable | undefined;
    set internalValue(value: BcmScheduledReportTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BcmScheduledReportTagsList extends cdktn.ComplexList {
    internalValue?: BcmScheduledReportTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmScheduledReportTagsOutputReference;
}
export interface BcmScheduledReportWidgetDateRangeOverrideEndTime {
    /**
    * Whether Value is an absolute date or a duration relative to now.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#type BcmScheduledReport#type}
    */
    readonly type?: string;
    /**
    * The date, or an ISO 8601 duration when Type is RELATIVE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#value BcmScheduledReport#value}
    */
    readonly value?: string;
}
export declare function bcmScheduledReportWidgetDateRangeOverrideEndTimeToTerraform(struct?: BcmScheduledReportWidgetDateRangeOverrideEndTime | cdktn.IResolvable): any;
export declare function bcmScheduledReportWidgetDateRangeOverrideEndTimeToHclTerraform(struct?: BcmScheduledReportWidgetDateRangeOverrideEndTime | cdktn.IResolvable): any;
export declare class BcmScheduledReportWidgetDateRangeOverrideEndTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmScheduledReportWidgetDateRangeOverrideEndTime | cdktn.IResolvable | undefined;
    set internalValue(value: BcmScheduledReportWidgetDateRangeOverrideEndTime | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface BcmScheduledReportWidgetDateRangeOverrideStartTime {
    /**
    * Whether Value is an absolute date or a duration relative to now.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#type BcmScheduledReport#type}
    */
    readonly type?: string;
    /**
    * The date, or an ISO 8601 duration when Type is RELATIVE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#value BcmScheduledReport#value}
    */
    readonly value?: string;
}
export declare function bcmScheduledReportWidgetDateRangeOverrideStartTimeToTerraform(struct?: BcmScheduledReportWidgetDateRangeOverrideStartTime | cdktn.IResolvable): any;
export declare function bcmScheduledReportWidgetDateRangeOverrideStartTimeToHclTerraform(struct?: BcmScheduledReportWidgetDateRangeOverrideStartTime | cdktn.IResolvable): any;
export declare class BcmScheduledReportWidgetDateRangeOverrideStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmScheduledReportWidgetDateRangeOverrideStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: BcmScheduledReportWidgetDateRangeOverrideStartTime | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface BcmScheduledReportWidgetDateRangeOverride {
    /**
    * The end of the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#end_time BcmScheduledReport#end_time}
    */
    readonly endTime?: BcmScheduledReportWidgetDateRangeOverrideEndTime;
    /**
    * The start of the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#start_time BcmScheduledReport#start_time}
    */
    readonly startTime?: BcmScheduledReportWidgetDateRangeOverrideStartTime;
}
export declare function bcmScheduledReportWidgetDateRangeOverrideToTerraform(struct?: BcmScheduledReportWidgetDateRangeOverride | cdktn.IResolvable): any;
export declare function bcmScheduledReportWidgetDateRangeOverrideToHclTerraform(struct?: BcmScheduledReportWidgetDateRangeOverride | cdktn.IResolvable): any;
export declare class BcmScheduledReportWidgetDateRangeOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmScheduledReportWidgetDateRangeOverride | cdktn.IResolvable | undefined;
    set internalValue(value: BcmScheduledReportWidgetDateRangeOverride | cdktn.IResolvable | undefined);
    private _endTime;
    get endTime(): BcmScheduledReportWidgetDateRangeOverrideEndTimeOutputReference;
    putEndTime(value: BcmScheduledReportWidgetDateRangeOverrideEndTime): void;
    resetEndTime(): void;
    get endTimeInput(): cdktn.IResolvable | BcmScheduledReportWidgetDateRangeOverrideEndTime | undefined;
    private _startTime;
    get startTime(): BcmScheduledReportWidgetDateRangeOverrideStartTimeOutputReference;
    putStartTime(value: BcmScheduledReportWidgetDateRangeOverrideStartTime): void;
    resetStartTime(): void;
    get startTimeInput(): cdktn.IResolvable | BcmScheduledReportWidgetDateRangeOverrideStartTime | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report awscc_bcm_scheduled_report}
*/
export declare class BcmScheduledReport extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bcm_scheduled_report";
    /**
    * Generates CDKTN code for importing a BcmScheduledReport resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BcmScheduledReport to import
    * @param importFromId The id of the existing BcmScheduledReport that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BcmScheduledReport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bcm_scheduled_report awscc_bcm_scheduled_report} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BcmScheduledReportConfig
    */
    constructor(scope: Construct, id: string, config: BcmScheduledReportConfig);
    get arn(): string;
    get createdAt(): string;
    private _dashboardArn?;
    get dashboardArn(): string;
    set dashboardArn(value: string);
    get dashboardArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _healthStatus;
    get healthStatus(): BcmScheduledReportHealthStatusOutputReference;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _scheduleConfig;
    get scheduleConfig(): BcmScheduledReportScheduleConfigOutputReference;
    putScheduleConfig(value: BcmScheduledReportScheduleConfig): void;
    get scheduleConfigInput(): cdktn.IResolvable | BcmScheduledReportScheduleConfig | undefined;
    private _scheduledReportExecutionRoleArn?;
    get scheduledReportExecutionRoleArn(): string;
    set scheduledReportExecutionRoleArn(value: string);
    get scheduledReportExecutionRoleArnInput(): string | undefined;
    private _tags;
    get tags(): BcmScheduledReportTagsList;
    putTags(value: BcmScheduledReportTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BcmScheduledReportTags[] | undefined;
    get updatedAt(): string;
    private _widgetDateRangeOverride;
    get widgetDateRangeOverride(): BcmScheduledReportWidgetDateRangeOverrideOutputReference;
    putWidgetDateRangeOverride(value: BcmScheduledReportWidgetDateRangeOverride): void;
    resetWidgetDateRangeOverride(): void;
    get widgetDateRangeOverrideInput(): cdktn.IResolvable | BcmScheduledReportWidgetDateRangeOverride | undefined;
    private _widgetIds?;
    get widgetIds(): string[];
    set widgetIds(value: string[]);
    resetWidgetIds(): void;
    get widgetIdsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
