/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CassandraTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Field definitions of the User-Defined Type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cassandra_type#fields CassandraType#fields}
    */
    readonly fields: CassandraTypeFields[] | cdktn.IResolvable;
    /**
    * Name of the Keyspace which contains the User-Defined Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cassandra_type#keyspace_name CassandraType#keyspace_name}
    */
    readonly keyspaceName: string;
    /**
    * Name of the User-Defined Type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cassandra_type#type_name CassandraType#type_name}
    */
    readonly typeName: string;
}
export interface CassandraTypeFields {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cassandra_type#field_name CassandraType#field_name}
    */
    readonly fieldName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cassandra_type#field_type CassandraType#field_type}
    */
    readonly fieldType: string;
}
export declare function cassandraTypeFieldsToTerraform(struct?: CassandraTypeFields | cdktn.IResolvable): any;
export declare function cassandraTypeFieldsToHclTerraform(struct?: CassandraTypeFields | cdktn.IResolvable): any;
export declare class CassandraTypeFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CassandraTypeFields | cdktn.IResolvable | undefined;
    set internalValue(value: CassandraTypeFields | cdktn.IResolvable | undefined);
    private _fieldName?;
    get fieldName(): string;
    set fieldName(value: string);
    get fieldNameInput(): string | undefined;
    private _fieldType?;
    get fieldType(): string;
    set fieldType(value: string);
    get fieldTypeInput(): string | undefined;
}
export declare class CassandraTypeFieldsList extends cdktn.ComplexList {
    internalValue?: CassandraTypeFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CassandraTypeFieldsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cassandra_type awscc_cassandra_type}
*/
export declare class CassandraType extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cassandra_type";
    /**
    * Generates CDKTN code for importing a CassandraType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CassandraType to import
    * @param importFromId The id of the existing CassandraType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cassandra_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CassandraType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cassandra_type awscc_cassandra_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CassandraTypeConfig
    */
    constructor(scope: Construct, id: string, config: CassandraTypeConfig);
    get directParentTypes(): string[];
    get directReferringTables(): string[];
    private _fields;
    get fields(): CassandraTypeFieldsList;
    putFields(value: CassandraTypeFields[] | cdktn.IResolvable): void;
    get fieldsInput(): cdktn.IResolvable | CassandraTypeFields[] | undefined;
    get id(): string;
    get keyspaceArn(): string;
    private _keyspaceName?;
    get keyspaceName(): string;
    set keyspaceName(value: string);
    get keyspaceNameInput(): string | undefined;
    get lastModifiedTimestamp(): number;
    get maxNestingDepth(): number;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    get typeNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
