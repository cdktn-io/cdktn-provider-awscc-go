/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchSpaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Name (ARN) of the IAM role used for AgentCore evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#agent_core_evaluation_role_arn CloudwatchSpace#agent_core_evaluation_role_arn}
    */
    readonly agentCoreEvaluationRoleArn?: string;
    /**
    * The Amazon Resource Name (ARN) of the IAM role the space uses to access observability data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#data_access_role_arn CloudwatchSpace#data_access_role_arn}
    */
    readonly dataAccessRoleArn: string;
    /**
    * The identifier of the domain the space belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#domain_id CloudwatchSpace#domain_id}
    */
    readonly domainId: string;
    /**
    * The encryption configuration for the space.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#encryption_configuration CloudwatchSpace#encryption_configuration}
    */
    readonly encryptionConfiguration?: CloudwatchSpaceEncryptionConfiguration;
    /**
    * The name of the space.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#name CloudwatchSpace#name}
    */
    readonly name: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#tags CloudwatchSpace#tags}
    */
    readonly tags?: CloudwatchSpaceTags[] | cdktn.IResolvable;
}
export interface CloudwatchSpaceEncryptionConfiguration {
    /**
    * Whether the space is encrypted with an AWS owned key or a customer managed key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#encryption_strategy CloudwatchSpace#encryption_strategy}
    */
    readonly encryptionStrategy?: string;
    /**
    * The Amazon Resource Name (ARN) of the customer managed KMS key. Required when encryptionStrategy is CUSTOMER_MANAGED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#kms_key_arn CloudwatchSpace#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
}
export declare function cloudwatchSpaceEncryptionConfigurationToTerraform(struct?: CloudwatchSpaceEncryptionConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchSpaceEncryptionConfigurationToHclTerraform(struct?: CloudwatchSpaceEncryptionConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchSpaceEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchSpaceEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchSpaceEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _encryptionStrategy?;
    get encryptionStrategy(): string;
    set encryptionStrategy(value: string);
    resetEncryptionStrategy(): void;
    get encryptionStrategyInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
}
export interface CloudwatchSpaceTags {
    /**
    * The key name of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#key CloudwatchSpace#key}
    */
    readonly key?: string;
    /**
    * The value for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#value CloudwatchSpace#value}
    */
    readonly value?: string;
}
export declare function cloudwatchSpaceTagsToTerraform(struct?: CloudwatchSpaceTags | cdktn.IResolvable): any;
export declare function cloudwatchSpaceTagsToHclTerraform(struct?: CloudwatchSpaceTags | cdktn.IResolvable): any;
export declare class CloudwatchSpaceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchSpaceTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchSpaceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchSpaceTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchSpaceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchSpaceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space awscc_cloudwatch_space}
*/
export declare class CloudwatchSpace extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_space";
    /**
    * Generates CDKTN code for importing a CloudwatchSpace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchSpace to import
    * @param importFromId The id of the existing CloudwatchSpace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchSpace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_space awscc_cloudwatch_space} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchSpaceConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchSpaceConfig);
    private _agentCoreEvaluationRoleArn?;
    get agentCoreEvaluationRoleArn(): string;
    set agentCoreEvaluationRoleArn(value: string);
    resetAgentCoreEvaluationRoleArn(): void;
    get agentCoreEvaluationRoleArnInput(): string | undefined;
    get arn(): string;
    get createdAt(): string;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    get dataAccessRoleArnInput(): string | undefined;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): CloudwatchSpaceEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: CloudwatchSpaceEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | CloudwatchSpaceEncryptionConfiguration | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerAccountId(): string;
    get region(): string;
    get spaceId(): string;
    get status(): string;
    private _tags;
    get tags(): CloudwatchSpaceTagsList;
    putTags(value: CloudwatchSpaceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchSpaceTags[] | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
