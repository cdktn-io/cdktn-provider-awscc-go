/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationStackSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Amazon Resource Number (ARN) of the IAM role to use to create this stack set. Specify an IAM role only if you are using customized administrator roles to control which users or groups can manage specific stack sets within the same administrator account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#administration_role_arn CloudformationStackSet#administration_role_arn}
    */
    readonly administrationRoleArn?: string;
    /**
    * Describes whether StackSets automatically deploys to AWS Organizations accounts that are added to the target organization or organizational unit (OU). Specify only if PermissionModel is SERVICE_MANAGED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#auto_deployment CloudformationStackSet#auto_deployment}
    */
    readonly autoDeployment?: CloudformationStackSetAutoDeployment;
    /**
    * Specifies the AWS account that you are acting from. By default, SELF is specified. For self-managed permissions, specify SELF; for service-managed permissions, if you are signed in to the organization's management account, specify SELF. If you are signed in to a delegated administrator account, specify DELEGATED_ADMIN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#call_as CloudformationStackSet#call_as}
    */
    readonly callAs?: string;
    /**
    * In some cases, you must explicitly acknowledge that your stack set template contains certain capabilities in order for AWS CloudFormation to create the stack set and related stack instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#capabilities CloudformationStackSet#capabilities}
    */
    readonly capabilities?: string[];
    /**
    * A description of the stack set. You can use the description to identify the stack set's purpose or other important information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#description CloudformationStackSet#description}
    */
    readonly description?: string;
    /**
    * The name of the IAM execution role to use to create the stack set. If you do not specify an execution role, AWS CloudFormation uses the AWSCloudFormationStackSetExecutionRole role for the stack set operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#execution_role_name CloudformationStackSet#execution_role_name}
    */
    readonly executionRoleName?: string;
    /**
    * Describes whether StackSets performs non-conflicting operations concurrently and queues conflicting operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#managed_execution CloudformationStackSet#managed_execution}
    */
    readonly managedExecution?: CloudformationStackSetManagedExecution;
    /**
    * The user-specified preferences for how AWS CloudFormation performs a stack set operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#operation_preferences CloudformationStackSet#operation_preferences}
    */
    readonly operationPreferences?: CloudformationStackSetOperationPreferences;
    /**
    * The input parameters for the stack set template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#parameters CloudformationStackSet#parameters}
    */
    readonly parameters?: CloudformationStackSetParameters[] | cdktn.IResolvable;
    /**
    * Describes how the IAM roles required for stack set operations are created. By default, SELF-MANAGED is specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#permission_model CloudformationStackSet#permission_model}
    */
    readonly permissionModel: string;
    /**
    * A group of stack instances with parameters in some specific accounts and regions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#stack_instances_group CloudformationStackSet#stack_instances_group}
    */
    readonly stackInstancesGroup?: CloudformationStackSetStackInstancesGroup[] | cdktn.IResolvable;
    /**
    * The name to associate with the stack set. The name must be unique in the Region where you create your stack set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#stack_set_name CloudformationStackSet#stack_set_name}
    */
    readonly stackSetName: string;
    /**
    * The key-value pairs to associate with this stack set and the stacks created from it. AWS CloudFormation also propagates these tags to supported resources that are created in the stacks. A maximum number of 50 tags can be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#tags CloudformationStackSet#tags}
    */
    readonly tags?: CloudformationStackSetTags[] | cdktn.IResolvable;
    /**
    * The structure that contains the template body, with a minimum length of 1 byte and a maximum length of 51,200 bytes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#template_body CloudformationStackSet#template_body}
    */
    readonly templateBody?: string;
    /**
    * Location of file containing the template body. The URL must point to a template (max size: 460,800 bytes) that is located in an Amazon S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#template_url CloudformationStackSet#template_url}
    */
    readonly templateUrl?: string;
}
export interface CloudformationStackSetAutoDeployment {
    /**
    * A list of StackSet ARNs that this StackSet depends on for auto-deployment operations. When auto-deployment is triggered, operations will be sequenced to ensure all dependencies complete successfully before this StackSet's operation begins.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#depends_on CloudformationStackSet#depends_on}
    */
    readonly dependsOn?: string[];
    /**
    * If set to true, StackSets automatically deploys additional stack instances to AWS Organizations accounts that are added to a target organization or organizational unit (OU) in the specified Regions. If an account is removed from a target organization or OU, StackSets deletes stack instances from the account in the specified Regions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#enabled CloudformationStackSet#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * If set to true, stack resources are retained when an account is removed from a target organization or OU. If set to false, stack resources are deleted. Specify only if Enabled is set to True.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#retain_stacks_on_account_removal CloudformationStackSet#retain_stacks_on_account_removal}
    */
    readonly retainStacksOnAccountRemoval?: boolean | cdktn.IResolvable;
}
export declare function cloudformationStackSetAutoDeploymentToTerraform(struct?: CloudformationStackSetAutoDeployment | cdktn.IResolvable): any;
export declare function cloudformationStackSetAutoDeploymentToHclTerraform(struct?: CloudformationStackSetAutoDeployment | cdktn.IResolvable): any;
export declare class CloudformationStackSetAutoDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationStackSetAutoDeployment | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackSetAutoDeployment | cdktn.IResolvable | undefined);
    private _dependsOn?;
    get dependsOn(): string[];
    set dependsOn(value: string[]);
    resetDependsOn(): void;
    get dependsOnInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _retainStacksOnAccountRemoval?;
    get retainStacksOnAccountRemoval(): boolean | cdktn.IResolvable;
    set retainStacksOnAccountRemoval(value: boolean | cdktn.IResolvable);
    resetRetainStacksOnAccountRemoval(): void;
    get retainStacksOnAccountRemovalInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudformationStackSetManagedExecution {
    /**
    * When true, StackSets performs non-conflicting operations concurrently and queues conflicting operations. After conflicting operations finish, StackSets starts queued operations in request order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#active CloudformationStackSet#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
}
export declare function cloudformationStackSetManagedExecutionToTerraform(struct?: CloudformationStackSetManagedExecution | cdktn.IResolvable): any;
export declare function cloudformationStackSetManagedExecutionToHclTerraform(struct?: CloudformationStackSetManagedExecution | cdktn.IResolvable): any;
export declare class CloudformationStackSetManagedExecutionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationStackSetManagedExecution | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackSetManagedExecution | cdktn.IResolvable | undefined);
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
}
export interface CloudformationStackSetOperationPreferences {
    /**
    * Specifies how the concurrency level behaves during the operation execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#concurrency_mode CloudformationStackSet#concurrency_mode}
    */
    readonly concurrencyMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#failure_tolerance_count CloudformationStackSet#failure_tolerance_count}
    */
    readonly failureToleranceCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#failure_tolerance_percentage CloudformationStackSet#failure_tolerance_percentage}
    */
    readonly failureTolerancePercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#max_concurrent_count CloudformationStackSet#max_concurrent_count}
    */
    readonly maxConcurrentCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#max_concurrent_percentage CloudformationStackSet#max_concurrent_percentage}
    */
    readonly maxConcurrentPercentage?: number;
    /**
    * The concurrency type of deploying StackSets operations in regions, could be in parallel or one region at a time
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#region_concurrency_type CloudformationStackSet#region_concurrency_type}
    */
    readonly regionConcurrencyType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#region_order CloudformationStackSet#region_order}
    */
    readonly regionOrder?: string[];
}
export declare function cloudformationStackSetOperationPreferencesToTerraform(struct?: CloudformationStackSetOperationPreferences | cdktn.IResolvable): any;
export declare function cloudformationStackSetOperationPreferencesToHclTerraform(struct?: CloudformationStackSetOperationPreferences | cdktn.IResolvable): any;
export declare class CloudformationStackSetOperationPreferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationStackSetOperationPreferences | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackSetOperationPreferences | cdktn.IResolvable | undefined);
    private _concurrencyMode?;
    get concurrencyMode(): string;
    set concurrencyMode(value: string);
    resetConcurrencyMode(): void;
    get concurrencyModeInput(): string | undefined;
    private _failureToleranceCount?;
    get failureToleranceCount(): number;
    set failureToleranceCount(value: number);
    resetFailureToleranceCount(): void;
    get failureToleranceCountInput(): number | undefined;
    private _failureTolerancePercentage?;
    get failureTolerancePercentage(): number;
    set failureTolerancePercentage(value: number);
    resetFailureTolerancePercentage(): void;
    get failureTolerancePercentageInput(): number | undefined;
    private _maxConcurrentCount?;
    get maxConcurrentCount(): number;
    set maxConcurrentCount(value: number);
    resetMaxConcurrentCount(): void;
    get maxConcurrentCountInput(): number | undefined;
    private _maxConcurrentPercentage?;
    get maxConcurrentPercentage(): number;
    set maxConcurrentPercentage(value: number);
    resetMaxConcurrentPercentage(): void;
    get maxConcurrentPercentageInput(): number | undefined;
    private _regionConcurrencyType?;
    get regionConcurrencyType(): string;
    set regionConcurrencyType(value: string);
    resetRegionConcurrencyType(): void;
    get regionConcurrencyTypeInput(): string | undefined;
    private _regionOrder?;
    get regionOrder(): string[];
    set regionOrder(value: string[]);
    resetRegionOrder(): void;
    get regionOrderInput(): string[] | undefined;
}
export interface CloudformationStackSetParameters {
    /**
    * The key associated with the parameter. If you don't specify a key and value for a particular parameter, AWS CloudFormation uses the default value that is specified in your template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#parameter_key CloudformationStackSet#parameter_key}
    */
    readonly parameterKey?: string;
    /**
    * The input value associated with the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#parameter_value CloudformationStackSet#parameter_value}
    */
    readonly parameterValue?: string;
}
export declare function cloudformationStackSetParametersToTerraform(struct?: CloudformationStackSetParameters | cdktn.IResolvable): any;
export declare function cloudformationStackSetParametersToHclTerraform(struct?: CloudformationStackSetParameters | cdktn.IResolvable): any;
export declare class CloudformationStackSetParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationStackSetParameters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackSetParameters | cdktn.IResolvable | undefined);
    private _parameterKey?;
    get parameterKey(): string;
    set parameterKey(value: string);
    resetParameterKey(): void;
    get parameterKeyInput(): string | undefined;
    private _parameterValue?;
    get parameterValue(): string;
    set parameterValue(value: string);
    resetParameterValue(): void;
    get parameterValueInput(): string | undefined;
}
export declare class CloudformationStackSetParametersList extends cdktn.ComplexList {
    internalValue?: CloudformationStackSetParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationStackSetParametersOutputReference;
}
export interface CloudformationStackSetStackInstancesGroupDeploymentTargets {
    /**
    * The filter type you want to apply on organizational units and accounts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#account_filter_type CloudformationStackSet#account_filter_type}
    */
    readonly accountFilterType?: string;
    /**
    * AWS accounts that you want to create stack instances in the specified Region(s) for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#accounts CloudformationStackSet#accounts}
    */
    readonly accounts?: string[];
    /**
    * Returns the value of the AccountsUrl property. AccountsUrl is currently not supported when using Account Level Targeting (ALT).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#accounts_url CloudformationStackSet#accounts_url}
    */
    readonly accountsUrl?: string;
    /**
    * The organization root ID or organizational unit (OU) IDs to which StackSets deploys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#organizational_unit_ids CloudformationStackSet#organizational_unit_ids}
    */
    readonly organizationalUnitIds?: string[];
}
export declare function cloudformationStackSetStackInstancesGroupDeploymentTargetsToTerraform(struct?: CloudformationStackSetStackInstancesGroupDeploymentTargets | cdktn.IResolvable): any;
export declare function cloudformationStackSetStackInstancesGroupDeploymentTargetsToHclTerraform(struct?: CloudformationStackSetStackInstancesGroupDeploymentTargets | cdktn.IResolvable): any;
export declare class CloudformationStackSetStackInstancesGroupDeploymentTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudformationStackSetStackInstancesGroupDeploymentTargets | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackSetStackInstancesGroupDeploymentTargets | cdktn.IResolvable | undefined);
    private _accountFilterType?;
    get accountFilterType(): string;
    set accountFilterType(value: string);
    resetAccountFilterType(): void;
    get accountFilterTypeInput(): string | undefined;
    private _accounts?;
    get accounts(): string[];
    set accounts(value: string[]);
    resetAccounts(): void;
    get accountsInput(): string[] | undefined;
    private _accountsUrl?;
    get accountsUrl(): string;
    set accountsUrl(value: string);
    resetAccountsUrl(): void;
    get accountsUrlInput(): string | undefined;
    private _organizationalUnitIds?;
    get organizationalUnitIds(): string[];
    set organizationalUnitIds(value: string[]);
    resetOrganizationalUnitIds(): void;
    get organizationalUnitIdsInput(): string[] | undefined;
}
export interface CloudformationStackSetStackInstancesGroupParameterOverrides {
    /**
    * The key associated with the parameter. If you don't specify a key and value for a particular parameter, AWS CloudFormation uses the default value that is specified in your template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#parameter_key CloudformationStackSet#parameter_key}
    */
    readonly parameterKey?: string;
    /**
    * The input value associated with the parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#parameter_value CloudformationStackSet#parameter_value}
    */
    readonly parameterValue?: string;
}
export declare function cloudformationStackSetStackInstancesGroupParameterOverridesToTerraform(struct?: CloudformationStackSetStackInstancesGroupParameterOverrides | cdktn.IResolvable): any;
export declare function cloudformationStackSetStackInstancesGroupParameterOverridesToHclTerraform(struct?: CloudformationStackSetStackInstancesGroupParameterOverrides | cdktn.IResolvable): any;
export declare class CloudformationStackSetStackInstancesGroupParameterOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationStackSetStackInstancesGroupParameterOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackSetStackInstancesGroupParameterOverrides | cdktn.IResolvable | undefined);
    private _parameterKey?;
    get parameterKey(): string;
    set parameterKey(value: string);
    resetParameterKey(): void;
    get parameterKeyInput(): string | undefined;
    private _parameterValue?;
    get parameterValue(): string;
    set parameterValue(value: string);
    resetParameterValue(): void;
    get parameterValueInput(): string | undefined;
}
export declare class CloudformationStackSetStackInstancesGroupParameterOverridesList extends cdktn.ComplexList {
    internalValue?: CloudformationStackSetStackInstancesGroupParameterOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationStackSetStackInstancesGroupParameterOverridesOutputReference;
}
export interface CloudformationStackSetStackInstancesGroup {
    /**
    *  The AWS OrganizationalUnitIds or Accounts for which to create stack instances in the specified Regions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#deployment_targets CloudformationStackSet#deployment_targets}
    */
    readonly deploymentTargets?: CloudformationStackSetStackInstancesGroupDeploymentTargets;
    /**
    * A list of stack set parameters whose values you want to override in the selected stack instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#parameter_overrides CloudformationStackSet#parameter_overrides}
    */
    readonly parameterOverrides?: CloudformationStackSetStackInstancesGroupParameterOverrides[] | cdktn.IResolvable;
    /**
    * The names of one or more Regions where you want to create stack instances using the specified AWS account(s).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#regions CloudformationStackSet#regions}
    */
    readonly regions?: string[];
}
export declare function cloudformationStackSetStackInstancesGroupToTerraform(struct?: CloudformationStackSetStackInstancesGroup | cdktn.IResolvable): any;
export declare function cloudformationStackSetStackInstancesGroupToHclTerraform(struct?: CloudformationStackSetStackInstancesGroup | cdktn.IResolvable): any;
export declare class CloudformationStackSetStackInstancesGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationStackSetStackInstancesGroup | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackSetStackInstancesGroup | cdktn.IResolvable | undefined);
    private _deploymentTargets;
    get deploymentTargets(): CloudformationStackSetStackInstancesGroupDeploymentTargetsOutputReference;
    putDeploymentTargets(value: CloudformationStackSetStackInstancesGroupDeploymentTargets): void;
    resetDeploymentTargets(): void;
    get deploymentTargetsInput(): cdktn.IResolvable | CloudformationStackSetStackInstancesGroupDeploymentTargets | undefined;
    private _parameterOverrides;
    get parameterOverrides(): CloudformationStackSetStackInstancesGroupParameterOverridesList;
    putParameterOverrides(value: CloudformationStackSetStackInstancesGroupParameterOverrides[] | cdktn.IResolvable): void;
    resetParameterOverrides(): void;
    get parameterOverridesInput(): cdktn.IResolvable | CloudformationStackSetStackInstancesGroupParameterOverrides[] | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
}
export declare class CloudformationStackSetStackInstancesGroupList extends cdktn.ComplexList {
    internalValue?: CloudformationStackSetStackInstancesGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationStackSetStackInstancesGroupOutputReference;
}
export interface CloudformationStackSetTags {
    /**
    * A string used to identify this tag. You can specify a maximum of 127 characters for a tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#key CloudformationStackSet#key}
    */
    readonly key?: string;
    /**
    * A string containing the value for this tag. You can specify a maximum of 256 characters for a tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#value CloudformationStackSet#value}
    */
    readonly value?: string;
}
export declare function cloudformationStackSetTagsToTerraform(struct?: CloudformationStackSetTags | cdktn.IResolvable): any;
export declare function cloudformationStackSetTagsToHclTerraform(struct?: CloudformationStackSetTags | cdktn.IResolvable): any;
export declare class CloudformationStackSetTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudformationStackSetTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudformationStackSetTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudformationStackSetTagsList extends cdktn.ComplexList {
    internalValue?: CloudformationStackSetTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudformationStackSetTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set awscc_cloudformation_stack_set}
*/
export declare class CloudformationStackSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_stack_set";
    /**
    * Generates CDKTN code for importing a CloudformationStackSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationStackSet to import
    * @param importFromId The id of the existing CloudformationStackSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationStackSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_stack_set awscc_cloudformation_stack_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationStackSetConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationStackSetConfig);
    private _administrationRoleArn?;
    get administrationRoleArn(): string;
    set administrationRoleArn(value: string);
    resetAdministrationRoleArn(): void;
    get administrationRoleArnInput(): string | undefined;
    private _autoDeployment;
    get autoDeployment(): CloudformationStackSetAutoDeploymentOutputReference;
    putAutoDeployment(value: CloudformationStackSetAutoDeployment): void;
    resetAutoDeployment(): void;
    get autoDeploymentInput(): cdktn.IResolvable | CloudformationStackSetAutoDeployment | undefined;
    private _callAs?;
    get callAs(): string;
    set callAs(value: string);
    resetCallAs(): void;
    get callAsInput(): string | undefined;
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    resetCapabilities(): void;
    get capabilitiesInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleName?;
    get executionRoleName(): string;
    set executionRoleName(value: string);
    resetExecutionRoleName(): void;
    get executionRoleNameInput(): string | undefined;
    get id(): string;
    private _managedExecution;
    get managedExecution(): CloudformationStackSetManagedExecutionOutputReference;
    putManagedExecution(value: CloudformationStackSetManagedExecution): void;
    resetManagedExecution(): void;
    get managedExecutionInput(): cdktn.IResolvable | CloudformationStackSetManagedExecution | undefined;
    private _operationPreferences;
    get operationPreferences(): CloudformationStackSetOperationPreferencesOutputReference;
    putOperationPreferences(value: CloudformationStackSetOperationPreferences): void;
    resetOperationPreferences(): void;
    get operationPreferencesInput(): cdktn.IResolvable | CloudformationStackSetOperationPreferences | undefined;
    private _parameters;
    get parameters(): CloudformationStackSetParametersList;
    putParameters(value: CloudformationStackSetParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | CloudformationStackSetParameters[] | undefined;
    private _permissionModel?;
    get permissionModel(): string;
    set permissionModel(value: string);
    get permissionModelInput(): string | undefined;
    private _stackInstancesGroup;
    get stackInstancesGroup(): CloudformationStackSetStackInstancesGroupList;
    putStackInstancesGroup(value: CloudformationStackSetStackInstancesGroup[] | cdktn.IResolvable): void;
    resetStackInstancesGroup(): void;
    get stackInstancesGroupInput(): cdktn.IResolvable | CloudformationStackSetStackInstancesGroup[] | undefined;
    get stackSetId(): string;
    private _stackSetName?;
    get stackSetName(): string;
    set stackSetName(value: string);
    get stackSetNameInput(): string | undefined;
    private _tags;
    get tags(): CloudformationStackSetTagsList;
    putTags(value: CloudformationStackSetTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudformationStackSetTags[] | undefined;
    private _templateBody?;
    get templateBody(): string;
    set templateBody(value: string);
    resetTemplateBody(): void;
    get templateBodyInput(): string | undefined;
    private _templateUrl?;
    get templateUrl(): string;
    set templateUrl(value: string);
    resetTemplateUrl(): void;
    get templateUrlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
