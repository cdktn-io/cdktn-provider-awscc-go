/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigDeliveryChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * The options for how often AWS Config delivers configuration snapshots to the Amazon S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel#config_snapshot_delivery_properties ConfigDeliveryChannel#config_snapshot_delivery_properties}
    */
    readonly configSnapshotDeliveryProperties?: ConfigDeliveryChannelConfigSnapshotDeliveryProperties;
    /**
    * The name of the delivery channel. By default, AWS Config assigns the name "default" when creating the delivery channel. To change the delivery channel name, you must use the DeleteDeliveryChannel action to delete your current delivery channel, and then you must use the PutDeliveryChannel command to create a delivery channel that has the desired name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel#name ConfigDeliveryChannel#name}
    */
    readonly name?: string;
    /**
    * The name of the Amazon S3 bucket to which AWS Config delivers configuration snapshots and configuration history files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel#s3_bucket_name ConfigDeliveryChannel#s3_bucket_name}
    */
    readonly s3BucketName: string;
    /**
    * The prefix for the specified Amazon S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel#s3_key_prefix ConfigDeliveryChannel#s3_key_prefix}
    */
    readonly s3KeyPrefix?: string;
    /**
    * The Amazon Resource Name (ARN) of the AWS Key Management Service (AWS KMS ) AWS KMS key (KMS key) used to encrypt objects delivered by AWS Config. Must belong to the same Region as the destination S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel#s3_kms_key_arn ConfigDeliveryChannel#s3_kms_key_arn}
    */
    readonly s3KmsKeyArn?: string;
    /**
    * The Amazon Resource Name (ARN) of the Amazon SNS topic to which AWS Config sends notifications about configuration changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel#sns_topic_arn ConfigDeliveryChannel#sns_topic_arn}
    */
    readonly snsTopicArn?: string;
}
export interface ConfigDeliveryChannelConfigSnapshotDeliveryProperties {
    /**
    * The frequency with which AWS Config delivers configuration snapshots.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel#delivery_frequency ConfigDeliveryChannel#delivery_frequency}
    */
    readonly deliveryFrequency?: string;
}
export declare function configDeliveryChannelConfigSnapshotDeliveryPropertiesToTerraform(struct?: ConfigDeliveryChannelConfigSnapshotDeliveryProperties | cdktn.IResolvable): any;
export declare function configDeliveryChannelConfigSnapshotDeliveryPropertiesToHclTerraform(struct?: ConfigDeliveryChannelConfigSnapshotDeliveryProperties | cdktn.IResolvable): any;
export declare class ConfigDeliveryChannelConfigSnapshotDeliveryPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigDeliveryChannelConfigSnapshotDeliveryProperties | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigDeliveryChannelConfigSnapshotDeliveryProperties | cdktn.IResolvable | undefined);
    private _deliveryFrequency?;
    get deliveryFrequency(): string;
    set deliveryFrequency(value: string);
    resetDeliveryFrequency(): void;
    get deliveryFrequencyInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel awscc_config_delivery_channel}
*/
export declare class ConfigDeliveryChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_delivery_channel";
    /**
    * Generates CDKTN code for importing a ConfigDeliveryChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigDeliveryChannel to import
    * @param importFromId The id of the existing ConfigDeliveryChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigDeliveryChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_delivery_channel awscc_config_delivery_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigDeliveryChannelConfig
    */
    constructor(scope: Construct, id: string, config: ConfigDeliveryChannelConfig);
    private _configSnapshotDeliveryProperties;
    get configSnapshotDeliveryProperties(): ConfigDeliveryChannelConfigSnapshotDeliveryPropertiesOutputReference;
    putConfigSnapshotDeliveryProperties(value: ConfigDeliveryChannelConfigSnapshotDeliveryProperties): void;
    resetConfigSnapshotDeliveryProperties(): void;
    get configSnapshotDeliveryPropertiesInput(): cdktn.IResolvable | ConfigDeliveryChannelConfigSnapshotDeliveryProperties | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    get s3BucketNameInput(): string | undefined;
    private _s3KeyPrefix?;
    get s3KeyPrefix(): string;
    set s3KeyPrefix(value: string);
    resetS3KeyPrefix(): void;
    get s3KeyPrefixInput(): string | undefined;
    private _s3KmsKeyArn?;
    get s3KmsKeyArn(): string;
    set s3KmsKeyArn(value: string);
    resetS3KmsKeyArn(): void;
    get s3KmsKeyArnInput(): string | undefined;
    private _snsTopicArn?;
    get snsTopicArn(): string;
    set snsTopicArn(value: string);
    resetSnsTopicArn(): void;
    get snsTopicArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
