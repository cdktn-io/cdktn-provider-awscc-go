/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccApigatewayDomainNameV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_domain_name_v2#id DataAwsccApigatewayDomainNameV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccApigatewayDomainNameV2EndpointConfiguration {
}
export declare function dataAwsccApigatewayDomainNameV2EndpointConfigurationToTerraform(struct?: DataAwsccApigatewayDomainNameV2EndpointConfiguration): any;
export declare function dataAwsccApigatewayDomainNameV2EndpointConfigurationToHclTerraform(struct?: DataAwsccApigatewayDomainNameV2EndpointConfiguration): any;
export declare class DataAwsccApigatewayDomainNameV2EndpointConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccApigatewayDomainNameV2EndpointConfiguration | undefined;
    set internalValue(value: DataAwsccApigatewayDomainNameV2EndpointConfiguration | undefined);
    get ipAddressType(): string;
    get types(): string[];
}
export interface DataAwsccApigatewayDomainNameV2Tags {
}
export declare function dataAwsccApigatewayDomainNameV2TagsToTerraform(struct?: DataAwsccApigatewayDomainNameV2Tags): any;
export declare function dataAwsccApigatewayDomainNameV2TagsToHclTerraform(struct?: DataAwsccApigatewayDomainNameV2Tags): any;
export declare class DataAwsccApigatewayDomainNameV2TagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccApigatewayDomainNameV2Tags | undefined;
    set internalValue(value: DataAwsccApigatewayDomainNameV2Tags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccApigatewayDomainNameV2TagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccApigatewayDomainNameV2TagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_domain_name_v2 awscc_apigateway_domain_name_v2}
*/
export declare class DataAwsccApigatewayDomainNameV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_apigateway_domain_name_v2";
    /**
    * Generates CDKTN code for importing a DataAwsccApigatewayDomainNameV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccApigatewayDomainNameV2 to import
    * @param importFromId The id of the existing DataAwsccApigatewayDomainNameV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_domain_name_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccApigatewayDomainNameV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/apigateway_domain_name_v2 awscc_apigateway_domain_name_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccApigatewayDomainNameV2Config
    */
    constructor(scope: Construct, id: string, config: DataAwsccApigatewayDomainNameV2Config);
    get certificateArn(): string;
    get domainName(): string;
    get domainNameArn(): string;
    get domainNameId(): string;
    get endpointAccessMode(): string;
    private _endpointConfiguration;
    get endpointConfiguration(): DataAwsccApigatewayDomainNameV2EndpointConfigurationOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get policy(): string;
    get routingMode(): string;
    get securityPolicy(): string;
    private _tags;
    get tags(): DataAwsccApigatewayDomainNameV2TagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
