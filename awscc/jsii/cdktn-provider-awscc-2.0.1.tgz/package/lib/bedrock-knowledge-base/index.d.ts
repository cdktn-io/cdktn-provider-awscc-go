/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockKnowledgeBaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the Resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#description BedrockKnowledgeBase#description}
    */
    readonly description?: string;
    /**
    * Contains details about the embeddings model used for the knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#knowledge_base_configuration BedrockKnowledgeBase#knowledge_base_configuration}
    */
    readonly knowledgeBaseConfiguration: BedrockKnowledgeBaseKnowledgeBaseConfiguration;
    /**
    * The name of the knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#name BedrockKnowledgeBase#name}
    */
    readonly name: string;
    /**
    * The ARN of the IAM role with permissions to invoke API operations on the knowledge base. The ARN must begin with AmazonBedrockExecutionRoleForKnowledgeBase_
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#role_arn BedrockKnowledgeBase#role_arn}
    */
    readonly roleArn: string;
    /**
    * The vector store service in which the knowledge base is stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#storage_configuration BedrockKnowledgeBase#storage_configuration}
    */
    readonly storageConfiguration?: BedrockKnowledgeBaseStorageConfiguration;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#tags BedrockKnowledgeBase#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfiguration {
    /**
    * Arn of a Kendra index
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#kendra_index_arn BedrockKnowledgeBase#kendra_index_arn}
    */
    readonly kendraIndexArn?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfiguration | cdktn.IResolvable | undefined);
    private _kendraIndexArn?;
    get kendraIndexArn(): string;
    set kendraIndexArn(value: string);
    resetKendraIndexArn(): void;
    get kendraIndexArnInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration {
    /**
    * Duration in seconds to segment the multi modal media
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#fixed_length_duration BedrockKnowledgeBase#fixed_length_duration}
    */
    readonly fixedLengthDuration?: number;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | cdktn.IResolvable | undefined);
    private _fixedLengthDuration?;
    get fixedLengthDuration(): number;
    set fixedLengthDuration(value: number);
    resetFixedLengthDuration(): void;
    get fixedLengthDurationInput(): number | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio {
    /**
    * Configure the audio segmentation configuration for multi modal ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#segmentation_configuration BedrockKnowledgeBase#segmentation_configuration}
    */
    readonly segmentationConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio | cdktn.IResolvable | undefined);
    private _segmentationConfiguration;
    get segmentationConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationOutputReference;
    putSegmentationConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration): void;
    resetSegmentationConfiguration(): void;
    get segmentationConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration {
    /**
    * Duration in seconds to segment the multi modal media
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#fixed_length_duration BedrockKnowledgeBase#fixed_length_duration}
    */
    readonly fixedLengthDuration?: number;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | cdktn.IResolvable | undefined);
    private _fixedLengthDuration?;
    get fixedLengthDuration(): number;
    set fixedLengthDuration(value: number);
    resetFixedLengthDuration(): void;
    get fixedLengthDurationInput(): number | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo {
    /**
    * Configure the video segmentation configuration for multi modal ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#segmentation_configuration BedrockKnowledgeBase#segmentation_configuration}
    */
    readonly segmentationConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo | cdktn.IResolvable | undefined);
    private _segmentationConfiguration;
    get segmentationConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationOutputReference;
    putSegmentationConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration): void;
    resetSegmentationConfiguration(): void;
    get segmentationConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration {
    /**
    * List of audio configurations for multi modal ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#audio BedrockKnowledgeBase#audio}
    */
    readonly audio?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio[] | cdktn.IResolvable;
    /**
    * The dimensions details for the vector configuration used on the Bedrock embeddings model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#dimensions BedrockKnowledgeBase#dimensions}
    */
    readonly dimensions?: number;
    /**
    * The data type for the vectors when using a model to convert text into vector embeddings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#embedding_data_type BedrockKnowledgeBase#embedding_data_type}
    */
    readonly embeddingDataType?: string;
    /**
    * Model-specific configuration for the embedding model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#model_configuration BedrockKnowledgeBase#model_configuration}
    */
    readonly modelConfiguration?: string;
    /**
    * List of video configurations for multi modal ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#video BedrockKnowledgeBase#video}
    */
    readonly video?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo[] | cdktn.IResolvable;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | cdktn.IResolvable | undefined);
    private _audio;
    get audio(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioList;
    putAudio(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio[] | cdktn.IResolvable): void;
    resetAudio(): void;
    get audioInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio[] | undefined;
    private _dimensions?;
    get dimensions(): number;
    set dimensions(value: number);
    resetDimensions(): void;
    get dimensionsInput(): number | undefined;
    private _embeddingDataType?;
    get embeddingDataType(): string;
    set embeddingDataType(value: string);
    resetEmbeddingDataType(): void;
    get embeddingDataTypeInput(): string | undefined;
    private _modelConfiguration?;
    get modelConfiguration(): string;
    set modelConfiguration(value: string);
    resetModelConfiguration(): void;
    get modelConfigurationInput(): string | undefined;
    private _video;
    get video(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoList;
    putVideo(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo[] | cdktn.IResolvable): void;
    resetVideo(): void;
    get videoInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo[] | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfiguration {
    /**
    * The vector configuration details for the Bedrock embeddings model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#bedrock_embedding_model_configuration BedrockKnowledgeBase#bedrock_embedding_model_configuration}
    */
    readonly bedrockEmbeddingModelConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfiguration | cdktn.IResolvable | undefined);
    private _bedrockEmbeddingModelConfiguration;
    get bedrockEmbeddingModelConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationOutputReference;
    putBedrockEmbeddingModelConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration): void;
    resetBedrockEmbeddingModelConfiguration(): void;
    get bedrockEmbeddingModelConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfiguration {
    /**
    * The ARN of the AWS KMS key used to encrypt the managed knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#kms_key_arn BedrockKnowledgeBase#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location {
    /**
    * The location's URI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#uri BedrockKnowledgeBase#uri}
    */
    readonly uri?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3LocationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3LocationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | cdktn.IResolvable | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations {
    /**
    * An Amazon S3 location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#s3_location BedrockKnowledgeBase#s3_location}
    */
    readonly s3Location?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location;
    /**
    * Supplemental data storage location type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#supplemental_data_storage_location_type BedrockKnowledgeBase#supplemental_data_storage_location_type}
    */
    readonly supplementalDataStorageLocationType?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations | cdktn.IResolvable | undefined);
    private _s3Location;
    get s3Location(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3LocationOutputReference;
    putS3Location(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location): void;
    resetS3Location(): void;
    get s3LocationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | undefined;
    private _supplementalDataStorageLocationType?;
    get supplementalDataStorageLocationType(): string;
    set supplementalDataStorageLocationType(value: string);
    resetSupplementalDataStorageLocationType(): void;
    get supplementalDataStorageLocationTypeInput(): string | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfiguration {
    /**
    * List of supplemental data storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#supplemental_data_storage_locations BedrockKnowledgeBase#supplemental_data_storage_locations}
    */
    readonly supplementalDataStorageLocations?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations[] | cdktn.IResolvable;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | cdktn.IResolvable | undefined);
    private _supplementalDataStorageLocations;
    get supplementalDataStorageLocations(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsList;
    putSupplementalDataStorageLocations(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations[] | cdktn.IResolvable): void;
    resetSupplementalDataStorageLocations(): void;
    get supplementalDataStorageLocationsInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations[] | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfiguration {
    /**
    * The ARN of the model used to create vector embeddings for the knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#embedding_model_arn BedrockKnowledgeBase#embedding_model_arn}
    */
    readonly embeddingModelArn?: string;
    /**
    * The embeddings model configuration details for the vector model used in Knowledge Base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#embedding_model_configuration BedrockKnowledgeBase#embedding_model_configuration}
    */
    readonly embeddingModelConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfiguration;
    /**
    * The type of embedding model to use for the managed knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#embedding_model_type BedrockKnowledgeBase#embedding_model_type}
    */
    readonly embeddingModelType?: string;
    /**
    * Contains details about the server-side encryption for the managed knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#server_side_encryption_configuration BedrockKnowledgeBase#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfiguration;
    /**
    * Configurations for supplemental data storage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#supplemental_data_storage_configuration BedrockKnowledgeBase#supplemental_data_storage_configuration}
    */
    readonly supplementalDataStorageConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfiguration | cdktn.IResolvable | undefined);
    private _embeddingModelArn?;
    get embeddingModelArn(): string;
    set embeddingModelArn(value: string);
    resetEmbeddingModelArn(): void;
    get embeddingModelArnInput(): string | undefined;
    private _embeddingModelConfiguration;
    get embeddingModelConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationOutputReference;
    putEmbeddingModelConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfiguration): void;
    resetEmbeddingModelConfiguration(): void;
    get embeddingModelConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfiguration | undefined;
    private _embeddingModelType?;
    get embeddingModelType(): string;
    set embeddingModelType(value: string);
    resetEmbeddingModelType(): void;
    get embeddingModelTypeInput(): string | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfigurationOutputReference;
    putServerSideEncryptionConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfiguration): void;
    resetServerSideEncryptionConfiguration(): void;
    get serverSideEncryptionConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationServerSideEncryptionConfiguration | undefined;
    private _supplementalDataStorageConfiguration;
    get supplementalDataStorageConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfigurationOutputReference;
    putSupplementalDataStorageConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfiguration): void;
    resetSupplementalDataStorageConfiguration(): void;
    get supplementalDataStorageConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfiguration {
    /**
    * Redshift database user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#database_user BedrockKnowledgeBase#database_user}
    */
    readonly databaseUser?: string;
    /**
    * Provisioned Redshift auth type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#type BedrockKnowledgeBase#type}
    */
    readonly type?: string;
    /**
    * Arn of a SecretsManager Secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#username_password_secret_arn BedrockKnowledgeBase#username_password_secret_arn}
    */
    readonly usernamePasswordSecretArn?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfiguration | cdktn.IResolvable | undefined);
    private _databaseUser?;
    get databaseUser(): string;
    set databaseUser(value: string);
    resetDatabaseUser(): void;
    get databaseUserInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _usernamePasswordSecretArn?;
    get usernamePasswordSecretArn(): string;
    set usernamePasswordSecretArn(value: string);
    resetUsernamePasswordSecretArn(): void;
    get usernamePasswordSecretArnInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfiguration {
    /**
    * Configurations for Redshift query engine provisioned auth setup
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#auth_configuration BedrockKnowledgeBase#auth_configuration}
    */
    readonly authConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfiguration;
    /**
    * Redshift cluster identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#cluster_identifier BedrockKnowledgeBase#cluster_identifier}
    */
    readonly clusterIdentifier?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfiguration | cdktn.IResolvable | undefined);
    private _authConfiguration;
    get authConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationOutputReference;
    putAuthConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfiguration): void;
    resetAuthConfiguration(): void;
    get authConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfiguration | undefined;
    private _clusterIdentifier?;
    get clusterIdentifier(): string;
    set clusterIdentifier(value: string);
    resetClusterIdentifier(): void;
    get clusterIdentifierInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfiguration {
    /**
    * Serverless Redshift auth type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#type BedrockKnowledgeBase#type}
    */
    readonly type?: string;
    /**
    * Arn of a SecretsManager Secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#username_password_secret_arn BedrockKnowledgeBase#username_password_secret_arn}
    */
    readonly usernamePasswordSecretArn?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfiguration | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _usernamePasswordSecretArn?;
    get usernamePasswordSecretArn(): string;
    set usernamePasswordSecretArn(value: string);
    resetUsernamePasswordSecretArn(): void;
    get usernamePasswordSecretArnInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfiguration {
    /**
    * Configurations for Redshift query engine serverless auth setup
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#auth_configuration BedrockKnowledgeBase#auth_configuration}
    */
    readonly authConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfiguration;
    /**
    * Workgroup arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#workgroup_arn BedrockKnowledgeBase#workgroup_arn}
    */
    readonly workgroupArn?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfiguration | cdktn.IResolvable | undefined);
    private _authConfiguration;
    get authConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationOutputReference;
    putAuthConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfiguration): void;
    resetAuthConfiguration(): void;
    get authConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfiguration | undefined;
    private _workgroupArn?;
    get workgroupArn(): string;
    set workgroupArn(value: string);
    resetWorkgroupArn(): void;
    get workgroupArnInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfiguration {
    /**
    * Configurations for provisioned Redshift query engine
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#provisioned_configuration BedrockKnowledgeBase#provisioned_configuration}
    */
    readonly provisionedConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfiguration;
    /**
    * Configurations for serverless Redshift query engine
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#serverless_configuration BedrockKnowledgeBase#serverless_configuration}
    */
    readonly serverlessConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfiguration;
    /**
    * Redshift query engine type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#type BedrockKnowledgeBase#type}
    */
    readonly type?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfiguration | cdktn.IResolvable | undefined);
    private _provisionedConfiguration;
    get provisionedConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationOutputReference;
    putProvisionedConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfiguration): void;
    resetProvisionedConfiguration(): void;
    get provisionedConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfiguration | undefined;
    private _serverlessConfiguration;
    get serverlessConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationOutputReference;
    putServerlessConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfiguration): void;
    resetServerlessConfiguration(): void;
    get serverlessConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries {
    /**
    * Question for the curated query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#natural_language BedrockKnowledgeBase#natural_language}
    */
    readonly naturalLanguage?: string;
    /**
    * Answer for the curated query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#sql BedrockKnowledgeBase#sql}
    */
    readonly sql?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueriesToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueriesToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries | cdktn.IResolvable | undefined);
    private _naturalLanguage?;
    get naturalLanguage(): string;
    set naturalLanguage(value: string);
    resetNaturalLanguage(): void;
    get naturalLanguageInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    resetSql(): void;
    get sqlInput(): string | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueriesList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueriesOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns {
    /**
    * Description for the attached entity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#description BedrockKnowledgeBase#description}
    */
    readonly description?: string;
    /**
    * Include or Exclude status for an entity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#inclusion BedrockKnowledgeBase#inclusion}
    */
    readonly inclusion?: string;
    /**
    * Query generation column name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#name BedrockKnowledgeBase#name}
    */
    readonly name?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumnsToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumnsToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inclusion?;
    get inclusion(): string;
    set inclusion(value: string);
    resetInclusion(): void;
    get inclusionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumnsList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumnsOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables {
    /**
    * List of Redshift query generation columns
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#columns BedrockKnowledgeBase#columns}
    */
    readonly columns?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns[] | cdktn.IResolvable;
    /**
    * Description for the attached entity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#description BedrockKnowledgeBase#description}
    */
    readonly description?: string;
    /**
    * Include or Exclude status for an entity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#inclusion BedrockKnowledgeBase#inclusion}
    */
    readonly inclusion?: string;
    /**
    * Query generation table name. Must follow three-part notation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#name BedrockKnowledgeBase#name}
    */
    readonly name?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables | cdktn.IResolvable | undefined);
    private _columns;
    get columns(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumnsList;
    putColumns(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns[] | cdktn.IResolvable): void;
    resetColumns(): void;
    get columnsInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesColumns[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inclusion?;
    get inclusion(): string;
    set inclusion(value: string);
    resetInclusion(): void;
    get inclusionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContext {
    /**
    * List of example queries and results
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#curated_queries BedrockKnowledgeBase#curated_queries}
    */
    readonly curatedQueries?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries[] | cdktn.IResolvable;
    /**
    * List of tables used for Redshift query generation context
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#tables BedrockKnowledgeBase#tables}
    */
    readonly tables?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables[] | cdktn.IResolvable;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContext | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContext | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContext | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContext | cdktn.IResolvable | undefined);
    private _curatedQueries;
    get curatedQueries(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueriesList;
    putCuratedQueries(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries[] | cdktn.IResolvable): void;
    resetCuratedQueries(): void;
    get curatedQueriesInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextCuratedQueries[] | undefined;
    private _tables;
    get tables(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTablesList;
    putTables(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextTables[] | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfiguration {
    /**
    * Max query execution timeout
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#execution_timeout_seconds BedrockKnowledgeBase#execution_timeout_seconds}
    */
    readonly executionTimeoutSeconds?: number;
    /**
    * Context used to improve query generation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#generation_context BedrockKnowledgeBase#generation_context}
    */
    readonly generationContext?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContext;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfiguration | cdktn.IResolvable | undefined);
    private _executionTimeoutSeconds?;
    get executionTimeoutSeconds(): number;
    set executionTimeoutSeconds(value: number);
    resetExecutionTimeoutSeconds(): void;
    get executionTimeoutSecondsInput(): number | undefined;
    private _generationContext;
    get generationContext(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContextOutputReference;
    putGenerationContext(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContext): void;
    resetGenerationContext(): void;
    get generationContextInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationGenerationContext | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfiguration {
    /**
    * List of table names in AWS Data Catalog. Must follow two part notation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#table_names BedrockKnowledgeBase#table_names}
    */
    readonly tableNames?: string[];
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfiguration | cdktn.IResolvable | undefined);
    private _tableNames?;
    get tableNames(): string[];
    set tableNames(value: string[]);
    resetTableNames(): void;
    get tableNamesInput(): string[] | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfiguration {
    /**
    * Redshift database name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#database_name BedrockKnowledgeBase#database_name}
    */
    readonly databaseName?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfiguration | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations {
    /**
    * Configurations for Redshift query engine AWS Data Catalog backed storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#aws_data_catalog_configuration BedrockKnowledgeBase#aws_data_catalog_configuration}
    */
    readonly awsDataCatalogConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfiguration;
    /**
    * Configurations for Redshift query engine Redshift backed storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#redshift_configuration BedrockKnowledgeBase#redshift_configuration}
    */
    readonly redshiftConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfiguration;
    /**
    * Redshift query engine storage type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#type BedrockKnowledgeBase#type}
    */
    readonly type?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations | cdktn.IResolvable | undefined);
    private _awsDataCatalogConfiguration;
    get awsDataCatalogConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfigurationOutputReference;
    putAwsDataCatalogConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfiguration): void;
    resetAwsDataCatalogConfiguration(): void;
    get awsDataCatalogConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsAwsDataCatalogConfiguration | undefined;
    private _redshiftConfiguration;
    get redshiftConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfigurationOutputReference;
    putRedshiftConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfiguration): void;
    resetRedshiftConfiguration(): void;
    get redshiftConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsRedshiftConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfiguration {
    /**
    * Configurations for Redshift query engine
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#query_engine_configuration BedrockKnowledgeBase#query_engine_configuration}
    */
    readonly queryEngineConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfiguration;
    /**
    * Configurations for generating Redshift engine queries
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#query_generation_configuration BedrockKnowledgeBase#query_generation_configuration}
    */
    readonly queryGenerationConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfiguration;
    /**
    * List of configurations for available Redshift query engine storage types
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#storage_configurations BedrockKnowledgeBase#storage_configurations}
    */
    readonly storageConfigurations?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations[] | cdktn.IResolvable;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfiguration | cdktn.IResolvable | undefined);
    private _queryEngineConfiguration;
    get queryEngineConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationOutputReference;
    putQueryEngineConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfiguration): void;
    resetQueryEngineConfiguration(): void;
    get queryEngineConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfiguration | undefined;
    private _queryGenerationConfiguration;
    get queryGenerationConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfigurationOutputReference;
    putQueryGenerationConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfiguration): void;
    resetQueryGenerationConfiguration(): void;
    get queryGenerationConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryGenerationConfiguration | undefined;
    private _storageConfigurations;
    get storageConfigurations(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationsList;
    putStorageConfigurations(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations[] | cdktn.IResolvable): void;
    resetStorageConfigurations(): void;
    get storageConfigurationsInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurations[] | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfiguration {
    /**
    * Configurations for a Redshift knowledge base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#redshift_configuration BedrockKnowledgeBase#redshift_configuration}
    */
    readonly redshiftConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfiguration;
    /**
    * SQL query engine type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#type BedrockKnowledgeBase#type}
    */
    readonly type?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfiguration | cdktn.IResolvable | undefined);
    private _redshiftConfiguration;
    get redshiftConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationOutputReference;
    putRedshiftConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfiguration): void;
    resetRedshiftConfiguration(): void;
    get redshiftConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration {
    /**
    * Duration in seconds to segment the multi modal media
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#fixed_length_duration BedrockKnowledgeBase#fixed_length_duration}
    */
    readonly fixedLengthDuration?: number;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | cdktn.IResolvable | undefined);
    private _fixedLengthDuration?;
    get fixedLengthDuration(): number;
    set fixedLengthDuration(value: number);
    resetFixedLengthDuration(): void;
    get fixedLengthDurationInput(): number | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio {
    /**
    * Configure the audio segmentation configuration for multi modal ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#segmentation_configuration BedrockKnowledgeBase#segmentation_configuration}
    */
    readonly segmentationConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio | cdktn.IResolvable | undefined);
    private _segmentationConfiguration;
    get segmentationConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationOutputReference;
    putSegmentationConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration): void;
    resetSegmentationConfiguration(): void;
    get segmentationConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfiguration | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration {
    /**
    * Duration in seconds to segment the multi modal media
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#fixed_length_duration BedrockKnowledgeBase#fixed_length_duration}
    */
    readonly fixedLengthDuration?: number;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | cdktn.IResolvable | undefined);
    private _fixedLengthDuration?;
    get fixedLengthDuration(): number;
    set fixedLengthDuration(value: number);
    resetFixedLengthDuration(): void;
    get fixedLengthDurationInput(): number | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo {
    /**
    * Configure the video segmentation configuration for multi modal ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#segmentation_configuration BedrockKnowledgeBase#segmentation_configuration}
    */
    readonly segmentationConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo | cdktn.IResolvable | undefined);
    private _segmentationConfiguration;
    get segmentationConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationOutputReference;
    putSegmentationConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration): void;
    resetSegmentationConfiguration(): void;
    get segmentationConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfiguration | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration {
    /**
    * List of audio configurations for multi modal ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#audio BedrockKnowledgeBase#audio}
    */
    readonly audio?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio[] | cdktn.IResolvable;
    /**
    * The dimensions details for the vector configuration used on the Bedrock embeddings model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#dimensions BedrockKnowledgeBase#dimensions}
    */
    readonly dimensions?: number;
    /**
    * The data type for the vectors when using a model to convert text into vector embeddings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#embedding_data_type BedrockKnowledgeBase#embedding_data_type}
    */
    readonly embeddingDataType?: string;
    /**
    * Model-specific configuration for the embedding model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#model_configuration BedrockKnowledgeBase#model_configuration}
    */
    readonly modelConfiguration?: string;
    /**
    * List of video configurations for multi modal ingestion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#video BedrockKnowledgeBase#video}
    */
    readonly video?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo[] | cdktn.IResolvable;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | cdktn.IResolvable | undefined);
    private _audio;
    get audio(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioList;
    putAudio(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio[] | cdktn.IResolvable): void;
    resetAudio(): void;
    get audioInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudio[] | undefined;
    private _dimensions?;
    get dimensions(): number;
    set dimensions(value: number);
    resetDimensions(): void;
    get dimensionsInput(): number | undefined;
    private _embeddingDataType?;
    get embeddingDataType(): string;
    set embeddingDataType(value: string);
    resetEmbeddingDataType(): void;
    get embeddingDataTypeInput(): string | undefined;
    private _modelConfiguration?;
    get modelConfiguration(): string;
    set modelConfiguration(value: string);
    resetModelConfiguration(): void;
    get modelConfigurationInput(): string | undefined;
    private _video;
    get video(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoList;
    putVideo(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo[] | cdktn.IResolvable): void;
    resetVideo(): void;
    get videoInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideo[] | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfiguration {
    /**
    * The vector configuration details for the Bedrock embeddings model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#bedrock_embedding_model_configuration BedrockKnowledgeBase#bedrock_embedding_model_configuration}
    */
    readonly bedrockEmbeddingModelConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfiguration | cdktn.IResolvable | undefined);
    private _bedrockEmbeddingModelConfiguration;
    get bedrockEmbeddingModelConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationOutputReference;
    putBedrockEmbeddingModelConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration): void;
    resetBedrockEmbeddingModelConfiguration(): void;
    get bedrockEmbeddingModelConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfiguration | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location {
    /**
    * The location's URI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#uri BedrockKnowledgeBase#uri}
    */
    readonly uri?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3LocationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3LocationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | cdktn.IResolvable | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations {
    /**
    * An Amazon S3 location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#s3_location BedrockKnowledgeBase#s3_location}
    */
    readonly s3Location?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location;
    /**
    * Supplemental data storage location type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#supplemental_data_storage_location_type BedrockKnowledgeBase#supplemental_data_storage_location_type}
    */
    readonly supplementalDataStorageLocationType?: string;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations | cdktn.IResolvable | undefined);
    private _s3Location;
    get s3Location(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3LocationOutputReference;
    putS3Location(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location): void;
    resetS3Location(): void;
    get s3LocationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsS3Location | undefined;
    private _supplementalDataStorageLocationType?;
    get supplementalDataStorageLocationType(): string;
    set supplementalDataStorageLocationType(value: string);
    resetSupplementalDataStorageLocationType(): void;
    get supplementalDataStorageLocationTypeInput(): string | undefined;
}
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsList extends cdktn.ComplexList {
    internalValue?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsOutputReference;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfiguration {
    /**
    * List of supplemental data storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#supplemental_data_storage_locations BedrockKnowledgeBase#supplemental_data_storage_locations}
    */
    readonly supplementalDataStorageLocations?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations[] | cdktn.IResolvable;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | cdktn.IResolvable | undefined);
    private _supplementalDataStorageLocations;
    get supplementalDataStorageLocations(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocationsList;
    putSupplementalDataStorageLocations(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations[] | cdktn.IResolvable): void;
    resetSupplementalDataStorageLocations(): void;
    get supplementalDataStorageLocationsInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationSupplementalDataStorageLocations[] | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfiguration {
    /**
    * The ARN of the model used to create vector embeddings for the knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#embedding_model_arn BedrockKnowledgeBase#embedding_model_arn}
    */
    readonly embeddingModelArn?: string;
    /**
    * The embeddings model configuration details for the vector model used in Knowledge Base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#embedding_model_configuration BedrockKnowledgeBase#embedding_model_configuration}
    */
    readonly embeddingModelConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfiguration;
    /**
    * Configurations for supplemental data storage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#supplemental_data_storage_configuration BedrockKnowledgeBase#supplemental_data_storage_configuration}
    */
    readonly supplementalDataStorageConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfiguration | cdktn.IResolvable | undefined);
    private _embeddingModelArn?;
    get embeddingModelArn(): string;
    set embeddingModelArn(value: string);
    resetEmbeddingModelArn(): void;
    get embeddingModelArnInput(): string | undefined;
    private _embeddingModelConfiguration;
    get embeddingModelConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationOutputReference;
    putEmbeddingModelConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfiguration): void;
    resetEmbeddingModelConfiguration(): void;
    get embeddingModelConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfiguration | undefined;
    private _supplementalDataStorageConfiguration;
    get supplementalDataStorageConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfigurationOutputReference;
    putSupplementalDataStorageConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfiguration): void;
    resetSupplementalDataStorageConfiguration(): void;
    get supplementalDataStorageConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationSupplementalDataStorageConfiguration | undefined;
}
export interface BedrockKnowledgeBaseKnowledgeBaseConfiguration {
    /**
    * Configurations for a Kendra knowledge base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#kendra_knowledge_base_configuration BedrockKnowledgeBase#kendra_knowledge_base_configuration}
    */
    readonly kendraKnowledgeBaseConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfiguration;
    /**
    * Contains details about the model used to create vector embeddings for a managed knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#managed_knowledge_base_configuration BedrockKnowledgeBase#managed_knowledge_base_configuration}
    */
    readonly managedKnowledgeBaseConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfiguration;
    /**
    * Configurations for a SQL knowledge base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#sql_knowledge_base_configuration BedrockKnowledgeBase#sql_knowledge_base_configuration}
    */
    readonly sqlKnowledgeBaseConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfiguration;
    /**
    * The type of a knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#type BedrockKnowledgeBase#type}
    */
    readonly type: string;
    /**
    * Contains details about the model used to create vector embeddings for the knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_knowledge_base_configuration BedrockKnowledgeBase#vector_knowledge_base_configuration}
    */
    readonly vectorKnowledgeBaseConfiguration?: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfiguration;
}
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationToTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseKnowledgeBaseConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseKnowledgeBaseConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseKnowledgeBaseConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseKnowledgeBaseConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseKnowledgeBaseConfiguration | cdktn.IResolvable | undefined);
    private _kendraKnowledgeBaseConfiguration;
    get kendraKnowledgeBaseConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfigurationOutputReference;
    putKendraKnowledgeBaseConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfiguration): void;
    resetKendraKnowledgeBaseConfiguration(): void;
    get kendraKnowledgeBaseConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationKendraKnowledgeBaseConfiguration | undefined;
    private _managedKnowledgeBaseConfiguration;
    get managedKnowledgeBaseConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationOutputReference;
    putManagedKnowledgeBaseConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfiguration): void;
    resetManagedKnowledgeBaseConfiguration(): void;
    get managedKnowledgeBaseConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfiguration | undefined;
    private _sqlKnowledgeBaseConfiguration;
    get sqlKnowledgeBaseConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationOutputReference;
    putSqlKnowledgeBaseConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfiguration): void;
    resetSqlKnowledgeBaseConfiguration(): void;
    get sqlKnowledgeBaseConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _vectorKnowledgeBaseConfiguration;
    get vectorKnowledgeBaseConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationOutputReference;
    putVectorKnowledgeBaseConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfiguration): void;
    resetVectorKnowledgeBaseConfiguration(): void;
    get vectorKnowledgeBaseConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfiguration | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMapping {
    /**
    * The name of the field in which Amazon Bedrock stores metadata about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#metadata_field BedrockKnowledgeBase#metadata_field}
    */
    readonly metadataField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the raw text from your data. The text is split according to the chunking strategy you choose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#text_field BedrockKnowledgeBase#text_field}
    */
    readonly textField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the vector embeddings for your data sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_field BedrockKnowledgeBase#vector_field}
    */
    readonly vectorField?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMappingToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMapping | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMappingToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMapping | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMapping | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMapping | cdktn.IResolvable | undefined);
    private _metadataField?;
    get metadataField(): string;
    set metadataField(value: string);
    resetMetadataField(): void;
    get metadataFieldInput(): string | undefined;
    private _textField?;
    get textField(): string;
    set textField(value: string);
    resetTextField(): void;
    get textFieldInput(): string | undefined;
    private _vectorField?;
    get vectorField(): string;
    set vectorField(value: string);
    resetVectorField(): void;
    get vectorFieldInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfiguration {
    /**
    * Name of the collection within MongoDB Atlas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#collection_name BedrockKnowledgeBase#collection_name}
    */
    readonly collectionName?: string;
    /**
    * The ARN of the secret that you created in AWS Secrets Manager that is linked to your Amazon Mongo database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#credentials_secret_arn BedrockKnowledgeBase#credentials_secret_arn}
    */
    readonly credentialsSecretArn?: string;
    /**
    * Name of the database within MongoDB Atlas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#database_name BedrockKnowledgeBase#database_name}
    */
    readonly databaseName?: string;
    /**
    * MongoDB Atlas endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#endpoint BedrockKnowledgeBase#endpoint}
    */
    readonly endpoint?: string;
    /**
    * MongoDB Atlas endpoint service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#endpoint_service_name BedrockKnowledgeBase#endpoint_service_name}
    */
    readonly endpointServiceName?: string;
    /**
    * Contains the names of the fields to which to map information about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#field_mapping BedrockKnowledgeBase#field_mapping}
    */
    readonly fieldMapping?: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMapping;
    /**
    * Name of a MongoDB Atlas text index.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#text_index_name BedrockKnowledgeBase#text_index_name}
    */
    readonly textIndexName?: string;
    /**
    * Name of a MongoDB Atlas index.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_index_name BedrockKnowledgeBase#vector_index_name}
    */
    readonly vectorIndexName?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfiguration | cdktn.IResolvable | undefined);
    private _collectionName?;
    get collectionName(): string;
    set collectionName(value: string);
    resetCollectionName(): void;
    get collectionNameInput(): string | undefined;
    private _credentialsSecretArn?;
    get credentialsSecretArn(): string;
    set credentialsSecretArn(value: string);
    resetCredentialsSecretArn(): void;
    get credentialsSecretArnInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _endpointServiceName?;
    get endpointServiceName(): string;
    set endpointServiceName(value: string);
    resetEndpointServiceName(): void;
    get endpointServiceNameInput(): string | undefined;
    private _fieldMapping;
    get fieldMapping(): BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMappingOutputReference;
    putFieldMapping(value: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMapping): void;
    resetFieldMapping(): void;
    get fieldMappingInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMapping | undefined;
    private _textIndexName?;
    get textIndexName(): string;
    set textIndexName(value: string);
    resetTextIndexName(): void;
    get textIndexNameInput(): string | undefined;
    private _vectorIndexName?;
    get vectorIndexName(): string;
    set vectorIndexName(value: string);
    resetVectorIndexName(): void;
    get vectorIndexNameInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMapping {
    /**
    * The name of the field in which Amazon Bedrock stores metadata about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#metadata_field BedrockKnowledgeBase#metadata_field}
    */
    readonly metadataField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the raw text from your data. The text is split according to the chunking strategy you choose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#text_field BedrockKnowledgeBase#text_field}
    */
    readonly textField?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMappingToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMapping | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMappingToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMapping | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMapping | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMapping | cdktn.IResolvable | undefined);
    private _metadataField?;
    get metadataField(): string;
    set metadataField(value: string);
    resetMetadataField(): void;
    get metadataFieldInput(): string | undefined;
    private _textField?;
    get textField(): string;
    set textField(value: string);
    resetTextField(): void;
    get textFieldInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfiguration {
    /**
    * A mapping of Bedrock Knowledge Base fields to Neptune Analytics fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#field_mapping BedrockKnowledgeBase#field_mapping}
    */
    readonly fieldMapping?: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMapping;
    /**
    * ARN for Neptune Analytics graph database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#graph_arn BedrockKnowledgeBase#graph_arn}
    */
    readonly graphArn?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfiguration | cdktn.IResolvable | undefined);
    private _fieldMapping;
    get fieldMapping(): BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMappingOutputReference;
    putFieldMapping(value: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMapping): void;
    resetFieldMapping(): void;
    get fieldMappingInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMapping | undefined;
    private _graphArn?;
    get graphArn(): string;
    set graphArn(value: string);
    resetGraphArn(): void;
    get graphArnInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMapping {
    /**
    * The name of the field in which Amazon Bedrock stores metadata about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#metadata_field BedrockKnowledgeBase#metadata_field}
    */
    readonly metadataField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the raw text from your data. The text is split according to the chunking strategy you choose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#text_field BedrockKnowledgeBase#text_field}
    */
    readonly textField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the vector embeddings for your data sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_field BedrockKnowledgeBase#vector_field}
    */
    readonly vectorField?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMappingToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMapping | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMappingToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMapping | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMapping | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMapping | cdktn.IResolvable | undefined);
    private _metadataField?;
    get metadataField(): string;
    set metadataField(value: string);
    resetMetadataField(): void;
    get metadataFieldInput(): string | undefined;
    private _textField?;
    get textField(): string;
    set textField(value: string);
    resetTextField(): void;
    get textFieldInput(): string | undefined;
    private _vectorField?;
    get vectorField(): string;
    set vectorField(value: string);
    resetVectorField(): void;
    get vectorFieldInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfiguration {
    /**
    * The Amazon Resource Name (ARN) of the OpenSearch domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#domain_arn BedrockKnowledgeBase#domain_arn}
    */
    readonly domainArn?: string;
    /**
    * The endpoint URL the OpenSearch domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#domain_endpoint BedrockKnowledgeBase#domain_endpoint}
    */
    readonly domainEndpoint?: string;
    /**
    * A mapping of Bedrock Knowledge Base fields to OpenSearch Managed Cluster field names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#field_mapping BedrockKnowledgeBase#field_mapping}
    */
    readonly fieldMapping?: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMapping;
    /**
    * The name of the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_index_name BedrockKnowledgeBase#vector_index_name}
    */
    readonly vectorIndexName?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfiguration | cdktn.IResolvable | undefined);
    private _domainArn?;
    get domainArn(): string;
    set domainArn(value: string);
    resetDomainArn(): void;
    get domainArnInput(): string | undefined;
    private _domainEndpoint?;
    get domainEndpoint(): string;
    set domainEndpoint(value: string);
    resetDomainEndpoint(): void;
    get domainEndpointInput(): string | undefined;
    private _fieldMapping;
    get fieldMapping(): BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMappingOutputReference;
    putFieldMapping(value: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMapping): void;
    resetFieldMapping(): void;
    get fieldMappingInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMapping | undefined;
    private _vectorIndexName?;
    get vectorIndexName(): string;
    set vectorIndexName(value: string);
    resetVectorIndexName(): void;
    get vectorIndexNameInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMapping {
    /**
    * The name of the field in which Amazon Bedrock stores metadata about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#metadata_field BedrockKnowledgeBase#metadata_field}
    */
    readonly metadataField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the raw text from your data. The text is split according to the chunking strategy you choose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#text_field BedrockKnowledgeBase#text_field}
    */
    readonly textField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the vector embeddings for your data sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_field BedrockKnowledgeBase#vector_field}
    */
    readonly vectorField?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMappingToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMapping | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMappingToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMapping | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMapping | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMapping | cdktn.IResolvable | undefined);
    private _metadataField?;
    get metadataField(): string;
    set metadataField(value: string);
    resetMetadataField(): void;
    get metadataFieldInput(): string | undefined;
    private _textField?;
    get textField(): string;
    set textField(value: string);
    resetTextField(): void;
    get textFieldInput(): string | undefined;
    private _vectorField?;
    get vectorField(): string;
    set vectorField(value: string);
    resetVectorField(): void;
    get vectorFieldInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfiguration {
    /**
    * The ARN of the OpenSearch Service vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#collection_arn BedrockKnowledgeBase#collection_arn}
    */
    readonly collectionArn?: string;
    /**
    * A mapping of Bedrock Knowledge Base fields to OpenSearch Serverless field names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#field_mapping BedrockKnowledgeBase#field_mapping}
    */
    readonly fieldMapping?: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMapping;
    /**
    * The name of the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_index_name BedrockKnowledgeBase#vector_index_name}
    */
    readonly vectorIndexName?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfiguration | cdktn.IResolvable | undefined);
    private _collectionArn?;
    get collectionArn(): string;
    set collectionArn(value: string);
    resetCollectionArn(): void;
    get collectionArnInput(): string | undefined;
    private _fieldMapping;
    get fieldMapping(): BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMappingOutputReference;
    putFieldMapping(value: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMapping): void;
    resetFieldMapping(): void;
    get fieldMappingInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMapping | undefined;
    private _vectorIndexName?;
    get vectorIndexName(): string;
    set vectorIndexName(value: string);
    resetVectorIndexName(): void;
    get vectorIndexNameInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMapping {
    /**
    * The name of the field in which Amazon Bedrock stores metadata about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#metadata_field BedrockKnowledgeBase#metadata_field}
    */
    readonly metadataField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the raw text from your data. The text is split according to the chunking strategy you choose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#text_field BedrockKnowledgeBase#text_field}
    */
    readonly textField?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMappingToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMapping | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMappingToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMapping | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMapping | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMapping | cdktn.IResolvable | undefined);
    private _metadataField?;
    get metadataField(): string;
    set metadataField(value: string);
    resetMetadataField(): void;
    get metadataFieldInput(): string | undefined;
    private _textField?;
    get textField(): string;
    set textField(value: string);
    resetTextField(): void;
    get textFieldInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationPineconeConfiguration {
    /**
    * The endpoint URL for your index management page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#connection_string BedrockKnowledgeBase#connection_string}
    */
    readonly connectionString?: string;
    /**
    * The ARN of the secret that you created in AWS Secrets Manager that is linked to your Pinecone API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#credentials_secret_arn BedrockKnowledgeBase#credentials_secret_arn}
    */
    readonly credentialsSecretArn?: string;
    /**
    * Contains the names of the fields to which to map information about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#field_mapping BedrockKnowledgeBase#field_mapping}
    */
    readonly fieldMapping?: BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMapping;
    /**
    * The namespace to be used to write new data to your database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#namespace BedrockKnowledgeBase#namespace}
    */
    readonly namespace?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationPineconeConfigurationToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationPineconeConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationPineconeConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationPineconeConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationPineconeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationPineconeConfiguration | cdktn.IResolvable | undefined);
    private _connectionString?;
    get connectionString(): string;
    set connectionString(value: string);
    resetConnectionString(): void;
    get connectionStringInput(): string | undefined;
    private _credentialsSecretArn?;
    get credentialsSecretArn(): string;
    set credentialsSecretArn(value: string);
    resetCredentialsSecretArn(): void;
    get credentialsSecretArnInput(): string | undefined;
    private _fieldMapping;
    get fieldMapping(): BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMappingOutputReference;
    putFieldMapping(value: BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMapping): void;
    resetFieldMapping(): void;
    get fieldMappingInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMapping | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMapping {
    /**
    * The name of the field in which Amazon Bedrock stores custom metadata about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#custom_metadata_field BedrockKnowledgeBase#custom_metadata_field}
    */
    readonly customMetadataField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores metadata about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#metadata_field BedrockKnowledgeBase#metadata_field}
    */
    readonly metadataField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the ID for each entry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#primary_key_field BedrockKnowledgeBase#primary_key_field}
    */
    readonly primaryKeyField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the raw text from your data. The text is split according to the chunking strategy you choose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#text_field BedrockKnowledgeBase#text_field}
    */
    readonly textField?: string;
    /**
    * The name of the field in which Amazon Bedrock stores the vector embeddings for your data sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_field BedrockKnowledgeBase#vector_field}
    */
    readonly vectorField?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMappingToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMapping | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMappingToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMapping | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMapping | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMapping | cdktn.IResolvable | undefined);
    private _customMetadataField?;
    get customMetadataField(): string;
    set customMetadataField(value: string);
    resetCustomMetadataField(): void;
    get customMetadataFieldInput(): string | undefined;
    private _metadataField?;
    get metadataField(): string;
    set metadataField(value: string);
    resetMetadataField(): void;
    get metadataFieldInput(): string | undefined;
    private _primaryKeyField?;
    get primaryKeyField(): string;
    set primaryKeyField(value: string);
    resetPrimaryKeyField(): void;
    get primaryKeyFieldInput(): string | undefined;
    private _textField?;
    get textField(): string;
    set textField(value: string);
    resetTextField(): void;
    get textFieldInput(): string | undefined;
    private _vectorField?;
    get vectorField(): string;
    set vectorField(value: string);
    resetVectorField(): void;
    get vectorFieldInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationRdsConfiguration {
    /**
    * The ARN of the secret that you created in AWS Secrets Manager that is linked to your Amazon RDS database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#credentials_secret_arn BedrockKnowledgeBase#credentials_secret_arn}
    */
    readonly credentialsSecretArn?: string;
    /**
    * The name of your Amazon RDS database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#database_name BedrockKnowledgeBase#database_name}
    */
    readonly databaseName?: string;
    /**
    * Contains the names of the fields to which to map information about the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#field_mapping BedrockKnowledgeBase#field_mapping}
    */
    readonly fieldMapping?: BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMapping;
    /**
    * The ARN of the vector store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#resource_arn BedrockKnowledgeBase#resource_arn}
    */
    readonly resourceArn?: string;
    /**
    * The name of the table in the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#table_name BedrockKnowledgeBase#table_name}
    */
    readonly tableName?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationRdsConfigurationToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationRdsConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationRdsConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationRdsConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationRdsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationRdsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationRdsConfiguration | cdktn.IResolvable | undefined);
    private _credentialsSecretArn?;
    get credentialsSecretArn(): string;
    set credentialsSecretArn(value: string);
    resetCredentialsSecretArn(): void;
    get credentialsSecretArnInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _fieldMapping;
    get fieldMapping(): BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMappingOutputReference;
    putFieldMapping(value: BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMapping): void;
    resetFieldMapping(): void;
    get fieldMappingInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationRdsConfigurationFieldMapping | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    resetResourceArn(): void;
    get resourceArnInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfigurationS3VectorsConfiguration {
    /**
    * The Amazon Resource Name (ARN) of the vector index used for the knowledge base. This ARN identifies the specific vector index resource within Amazon Bedrock.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#index_arn BedrockKnowledgeBase#index_arn}
    */
    readonly indexArn?: string;
    /**
    * The name of the vector index used for the knowledge base. This name identifies the vector index within the Amazon Bedrock service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#index_name BedrockKnowledgeBase#index_name}
    */
    readonly indexName?: string;
    /**
    * The Amazon Resource Name (ARN) of the S3 bucket where vector embeddings are stored. This bucket contains the vector data used by the knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#vector_bucket_arn BedrockKnowledgeBase#vector_bucket_arn}
    */
    readonly vectorBucketArn?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationS3VectorsConfigurationToTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationS3VectorsConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationS3VectorsConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfigurationS3VectorsConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationS3VectorsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfigurationS3VectorsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfigurationS3VectorsConfiguration | cdktn.IResolvable | undefined);
    private _indexArn?;
    get indexArn(): string;
    set indexArn(value: string);
    resetIndexArn(): void;
    get indexArnInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    resetIndexName(): void;
    get indexNameInput(): string | undefined;
    private _vectorBucketArn?;
    get vectorBucketArn(): string;
    set vectorBucketArn(value: string);
    resetVectorBucketArn(): void;
    get vectorBucketArnInput(): string | undefined;
}
export interface BedrockKnowledgeBaseStorageConfiguration {
    /**
    * Contains the storage configuration of the knowledge base in MongoDb Atlas Cloud.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#mongo_db_atlas_configuration BedrockKnowledgeBase#mongo_db_atlas_configuration}
    */
    readonly mongoDbAtlasConfiguration?: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfiguration;
    /**
    * Contains the configurations to use Neptune Analytics as Vector Store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#neptune_analytics_configuration BedrockKnowledgeBase#neptune_analytics_configuration}
    */
    readonly neptuneAnalyticsConfiguration?: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfiguration;
    /**
    * Contains the storage configuration of the knowledge base in Amazon OpenSearch Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#opensearch_managed_cluster_configuration BedrockKnowledgeBase#opensearch_managed_cluster_configuration}
    */
    readonly opensearchManagedClusterConfiguration?: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfiguration;
    /**
    * Contains the storage configuration of the knowledge base in Amazon OpenSearch Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#opensearch_serverless_configuration BedrockKnowledgeBase#opensearch_serverless_configuration}
    */
    readonly opensearchServerlessConfiguration?: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfiguration;
    /**
    * Contains the storage configuration of the knowledge base in Pinecone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#pinecone_configuration BedrockKnowledgeBase#pinecone_configuration}
    */
    readonly pineconeConfiguration?: BedrockKnowledgeBaseStorageConfigurationPineconeConfiguration;
    /**
    * Contains details about the storage configuration of the knowledge base in Amazon RDS. For more information, see Create a vector index in Amazon RDS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#rds_configuration BedrockKnowledgeBase#rds_configuration}
    */
    readonly rdsConfiguration?: BedrockKnowledgeBaseStorageConfigurationRdsConfiguration;
    /**
    * Contains the storage configuration of the knowledge base for S3 vectors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#s3_vectors_configuration BedrockKnowledgeBase#s3_vectors_configuration}
    */
    readonly s3VectorsConfiguration?: BedrockKnowledgeBaseStorageConfigurationS3VectorsConfiguration;
    /**
    * The storage type of a knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#type BedrockKnowledgeBase#type}
    */
    readonly type?: string;
}
export declare function bedrockKnowledgeBaseStorageConfigurationToTerraform(struct?: BedrockKnowledgeBaseStorageConfiguration | cdktn.IResolvable): any;
export declare function bedrockKnowledgeBaseStorageConfigurationToHclTerraform(struct?: BedrockKnowledgeBaseStorageConfiguration | cdktn.IResolvable): any;
export declare class BedrockKnowledgeBaseStorageConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockKnowledgeBaseStorageConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockKnowledgeBaseStorageConfiguration | cdktn.IResolvable | undefined);
    private _mongoDbAtlasConfiguration;
    get mongoDbAtlasConfiguration(): BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationOutputReference;
    putMongoDbAtlasConfiguration(value: BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfiguration): void;
    resetMongoDbAtlasConfiguration(): void;
    get mongoDbAtlasConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationMongoDbAtlasConfiguration | undefined;
    private _neptuneAnalyticsConfiguration;
    get neptuneAnalyticsConfiguration(): BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationOutputReference;
    putNeptuneAnalyticsConfiguration(value: BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfiguration): void;
    resetNeptuneAnalyticsConfiguration(): void;
    get neptuneAnalyticsConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfiguration | undefined;
    private _opensearchManagedClusterConfiguration;
    get opensearchManagedClusterConfiguration(): BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationOutputReference;
    putOpensearchManagedClusterConfiguration(value: BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfiguration): void;
    resetOpensearchManagedClusterConfiguration(): void;
    get opensearchManagedClusterConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfiguration | undefined;
    private _opensearchServerlessConfiguration;
    get opensearchServerlessConfiguration(): BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationOutputReference;
    putOpensearchServerlessConfiguration(value: BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfiguration): void;
    resetOpensearchServerlessConfiguration(): void;
    get opensearchServerlessConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationOpensearchServerlessConfiguration | undefined;
    private _pineconeConfiguration;
    get pineconeConfiguration(): BedrockKnowledgeBaseStorageConfigurationPineconeConfigurationOutputReference;
    putPineconeConfiguration(value: BedrockKnowledgeBaseStorageConfigurationPineconeConfiguration): void;
    resetPineconeConfiguration(): void;
    get pineconeConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationPineconeConfiguration | undefined;
    private _rdsConfiguration;
    get rdsConfiguration(): BedrockKnowledgeBaseStorageConfigurationRdsConfigurationOutputReference;
    putRdsConfiguration(value: BedrockKnowledgeBaseStorageConfigurationRdsConfiguration): void;
    resetRdsConfiguration(): void;
    get rdsConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationRdsConfiguration | undefined;
    private _s3VectorsConfiguration;
    get s3VectorsConfiguration(): BedrockKnowledgeBaseStorageConfigurationS3VectorsConfigurationOutputReference;
    putS3VectorsConfiguration(value: BedrockKnowledgeBaseStorageConfigurationS3VectorsConfiguration): void;
    resetS3VectorsConfiguration(): void;
    get s3VectorsConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfigurationS3VectorsConfiguration | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base awscc_bedrock_knowledge_base}
*/
export declare class BedrockKnowledgeBase extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_knowledge_base";
    /**
    * Generates CDKTN code for importing a BedrockKnowledgeBase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockKnowledgeBase to import
    * @param importFromId The id of the existing BedrockKnowledgeBase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockKnowledgeBase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_knowledge_base awscc_bedrock_knowledge_base} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockKnowledgeBaseConfig
    */
    constructor(scope: Construct, id: string, config: BedrockKnowledgeBaseConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get failureReasons(): string[];
    get id(): string;
    get knowledgeBaseArn(): string;
    private _knowledgeBaseConfiguration;
    get knowledgeBaseConfiguration(): BedrockKnowledgeBaseKnowledgeBaseConfigurationOutputReference;
    putKnowledgeBaseConfiguration(value: BedrockKnowledgeBaseKnowledgeBaseConfiguration): void;
    get knowledgeBaseConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseKnowledgeBaseConfiguration | undefined;
    get knowledgeBaseId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _storageConfiguration;
    get storageConfiguration(): BedrockKnowledgeBaseStorageConfigurationOutputReference;
    putStorageConfiguration(value: BedrockKnowledgeBaseStorageConfiguration): void;
    resetStorageConfiguration(): void;
    get storageConfigurationInput(): cdktn.IResolvable | BedrockKnowledgeBaseStorageConfiguration | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
