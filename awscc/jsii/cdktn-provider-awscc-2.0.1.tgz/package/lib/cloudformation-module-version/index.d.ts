/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudformationModuleVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the module being registered.
    *
    * Recommended module naming pattern: company_or_organization::service::type::MODULE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_module_version#module_name CloudformationModuleVersion#module_name}
    */
    readonly moduleName: string;
    /**
    * The url to the S3 bucket containing the schema and template fragment for the module you want to register.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_module_version#module_package CloudformationModuleVersion#module_package}
    */
    readonly modulePackage: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_module_version awscc_cloudformation_module_version}
*/
export declare class CloudformationModuleVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudformation_module_version";
    /**
    * Generates CDKTN code for importing a CloudformationModuleVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudformationModuleVersion to import
    * @param importFromId The id of the existing CloudformationModuleVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_module_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudformationModuleVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudformation_module_version awscc_cloudformation_module_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudformationModuleVersionConfig
    */
    constructor(scope: Construct, id: string, config: CloudformationModuleVersionConfig);
    get arn(): string;
    get description(): string;
    get documentationUrl(): string;
    get id(): string;
    get isDefaultVersion(): cdktn.IResolvable;
    private _moduleName?;
    get moduleName(): string;
    set moduleName(value: string);
    get moduleNameInput(): string | undefined;
    private _modulePackage?;
    get modulePackage(): string;
    set modulePackage(value: string);
    get modulePackageInput(): string | undefined;
    get schema(): string;
    get timeCreated(): string;
    get versionId(): string;
    get visibility(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
