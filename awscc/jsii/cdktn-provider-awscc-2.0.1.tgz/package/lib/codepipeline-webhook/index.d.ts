/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodepipelineWebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Supported options are GITHUB_HMAC, IP, and UNAUTHENTICATED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#authentication CodepipelineWebhook#authentication}
    */
    readonly authentication: string;
    /**
    * Properties that configure the authentication applied to incoming webhook trigger requests
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#authentication_configuration CodepipelineWebhook#authentication_configuration}
    */
    readonly authenticationConfiguration: CodepipelineWebhookAuthenticationConfiguration;
    /**
    * A list of rules applied to the body/payload sent in the POST request to a webhook URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#filters CodepipelineWebhook#filters}
    */
    readonly filters: CodepipelineWebhookFilters[] | cdktn.IResolvable;
    /**
    * The name of the webhook
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#name CodepipelineWebhook#name}
    */
    readonly name?: string;
    /**
    * Configures a connection between the webhook that was created and the external tool with events to be detected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#register_with_third_party CodepipelineWebhook#register_with_third_party}
    */
    readonly registerWithThirdParty?: boolean | cdktn.IResolvable;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#tags CodepipelineWebhook#tags}
    */
    readonly tags?: CodepipelineWebhookTags[] | cdktn.IResolvable;
    /**
    * The name of the action in a pipeline you want to connect to the webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#target_action CodepipelineWebhook#target_action}
    */
    readonly targetAction: string;
    /**
    * The name of the pipeline you want to connect to the webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#target_pipeline CodepipelineWebhook#target_pipeline}
    */
    readonly targetPipeline: string;
    /**
    * The version number of the pipeline to be connected to the trigger request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#target_pipeline_version CodepipelineWebhook#target_pipeline_version}
    */
    readonly targetPipelineVersion?: number;
}
export interface CodepipelineWebhookAuthenticationConfiguration {
    /**
    * The property used to configure acceptance of webhooks in an IP address range. For IP, only the AllowedIPRange property must be set. This property must be set to a valid CIDR range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#allowed_ip_range CodepipelineWebhook#allowed_ip_range}
    */
    readonly allowedIpRange?: string;
    /**
    * The property used to configure GitHub authentication. For GITHUB_HMAC, only the SecretToken property must be set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#secret_token CodepipelineWebhook#secret_token}
    */
    readonly secretToken?: string;
}
export declare function codepipelineWebhookAuthenticationConfigurationToTerraform(struct?: CodepipelineWebhookAuthenticationConfiguration | cdktn.IResolvable): any;
export declare function codepipelineWebhookAuthenticationConfigurationToHclTerraform(struct?: CodepipelineWebhookAuthenticationConfiguration | cdktn.IResolvable): any;
export declare class CodepipelineWebhookAuthenticationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodepipelineWebhookAuthenticationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelineWebhookAuthenticationConfiguration | cdktn.IResolvable | undefined);
    private _allowedIpRange?;
    get allowedIpRange(): string;
    set allowedIpRange(value: string);
    resetAllowedIpRange(): void;
    get allowedIpRangeInput(): string | undefined;
    private _secretToken?;
    get secretToken(): string;
    set secretToken(value: string);
    resetSecretToken(): void;
    get secretTokenInput(): string | undefined;
}
export interface CodepipelineWebhookFilters {
    /**
    * A JsonPath expression that is applied to the body/payload of the webhook. The value selected by the JsonPath expression must match the value specified in the MatchEquals field. Otherwise, the request is ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#json_path CodepipelineWebhook#json_path}
    */
    readonly jsonPath: string;
    /**
    * The value selected by the JsonPath expression must match what is supplied in the MatchEquals field. Otherwise, the request is ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#match_equals CodepipelineWebhook#match_equals}
    */
    readonly matchEquals?: string;
}
export declare function codepipelineWebhookFiltersToTerraform(struct?: CodepipelineWebhookFilters | cdktn.IResolvable): any;
export declare function codepipelineWebhookFiltersToHclTerraform(struct?: CodepipelineWebhookFilters | cdktn.IResolvable): any;
export declare class CodepipelineWebhookFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelineWebhookFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelineWebhookFilters | cdktn.IResolvable | undefined);
    private _jsonPath?;
    get jsonPath(): string;
    set jsonPath(value: string);
    get jsonPathInput(): string | undefined;
    private _matchEquals?;
    get matchEquals(): string;
    set matchEquals(value: string);
    resetMatchEquals(): void;
    get matchEqualsInput(): string | undefined;
}
export declare class CodepipelineWebhookFiltersList extends cdktn.ComplexList {
    internalValue?: CodepipelineWebhookFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelineWebhookFiltersOutputReference;
}
export interface CodepipelineWebhookTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#key CodepipelineWebhook#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#value CodepipelineWebhook#value}
    */
    readonly value?: string;
}
export declare function codepipelineWebhookTagsToTerraform(struct?: CodepipelineWebhookTags | cdktn.IResolvable): any;
export declare function codepipelineWebhookTagsToHclTerraform(struct?: CodepipelineWebhookTags | cdktn.IResolvable): any;
export declare class CodepipelineWebhookTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodepipelineWebhookTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodepipelineWebhookTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodepipelineWebhookTagsList extends cdktn.ComplexList {
    internalValue?: CodepipelineWebhookTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodepipelineWebhookTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook awscc_codepipeline_webhook}
*/
export declare class CodepipelineWebhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codepipeline_webhook";
    /**
    * Generates CDKTN code for importing a CodepipelineWebhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodepipelineWebhook to import
    * @param importFromId The id of the existing CodepipelineWebhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodepipelineWebhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codepipeline_webhook awscc_codepipeline_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodepipelineWebhookConfig
    */
    constructor(scope: Construct, id: string, config: CodepipelineWebhookConfig);
    private _authentication?;
    get authentication(): string;
    set authentication(value: string);
    get authenticationInput(): string | undefined;
    private _authenticationConfiguration;
    get authenticationConfiguration(): CodepipelineWebhookAuthenticationConfigurationOutputReference;
    putAuthenticationConfiguration(value: CodepipelineWebhookAuthenticationConfiguration): void;
    get authenticationConfigurationInput(): cdktn.IResolvable | CodepipelineWebhookAuthenticationConfiguration | undefined;
    private _filters;
    get filters(): CodepipelineWebhookFiltersList;
    putFilters(value: CodepipelineWebhookFilters[] | cdktn.IResolvable): void;
    get filtersInput(): cdktn.IResolvable | CodepipelineWebhookFilters[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _registerWithThirdParty?;
    get registerWithThirdParty(): boolean | cdktn.IResolvable;
    set registerWithThirdParty(value: boolean | cdktn.IResolvable);
    resetRegisterWithThirdParty(): void;
    get registerWithThirdPartyInput(): boolean | cdktn.IResolvable | undefined;
    private _tags;
    get tags(): CodepipelineWebhookTagsList;
    putTags(value: CodepipelineWebhookTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodepipelineWebhookTags[] | undefined;
    private _targetAction?;
    get targetAction(): string;
    set targetAction(value: string);
    get targetActionInput(): string | undefined;
    private _targetPipeline?;
    get targetPipeline(): string;
    set targetPipeline(value: string);
    get targetPipelineInput(): string | undefined;
    private _targetPipelineVersion?;
    get targetPipelineVersion(): number;
    set targetPipelineVersion(value: number);
    resetTargetPipelineVersion(): void;
    get targetPipelineVersionInput(): number | undefined;
    get url(): string;
    get webhookId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
