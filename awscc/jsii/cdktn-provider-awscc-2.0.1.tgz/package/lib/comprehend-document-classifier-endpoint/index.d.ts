/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComprehendDocumentClassifierEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * The desired number of inference units to be used by the model. Each inference unit represents throughput of 100 characters per second.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint#desired_inference_units ComprehendDocumentClassifierEndpoint#desired_inference_units}
    */
    readonly desiredInferenceUnits: number;
    /**
    * The name of the endpoint. The name must be unique within the AWS Region and account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint#endpoint_name ComprehendDocumentClassifierEndpoint#endpoint_name}
    */
    readonly endpointName: string;
    /**
    * The Amazon Resource Name (ARN) of the document classifier model to which the endpoint is attached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint#model_arn ComprehendDocumentClassifierEndpoint#model_arn}
    */
    readonly modelArn: string;
    /**
    * Tags associated with the endpoint being created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint#tags ComprehendDocumentClassifierEndpoint#tags}
    */
    readonly tags?: ComprehendDocumentClassifierEndpointTags[] | cdktn.IResolvable;
}
export interface ComprehendDocumentClassifierEndpointTags {
    /**
    * The initial part of a key-value pair that forms a tag associated with a given resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint#key ComprehendDocumentClassifierEndpoint#key}
    */
    readonly key?: string;
    /**
    * The second part of a key-value pair that forms a tag associated with a given resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint#value ComprehendDocumentClassifierEndpoint#value}
    */
    readonly value?: string;
}
export declare function comprehendDocumentClassifierEndpointTagsToTerraform(struct?: ComprehendDocumentClassifierEndpointTags | cdktn.IResolvable): any;
export declare function comprehendDocumentClassifierEndpointTagsToHclTerraform(struct?: ComprehendDocumentClassifierEndpointTags | cdktn.IResolvable): any;
export declare class ComprehendDocumentClassifierEndpointTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComprehendDocumentClassifierEndpointTags | cdktn.IResolvable | undefined;
    set internalValue(value: ComprehendDocumentClassifierEndpointTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ComprehendDocumentClassifierEndpointTagsList extends cdktn.ComplexList {
    internalValue?: ComprehendDocumentClassifierEndpointTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComprehendDocumentClassifierEndpointTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint awscc_comprehend_document_classifier_endpoint}
*/
export declare class ComprehendDocumentClassifierEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_comprehend_document_classifier_endpoint";
    /**
    * Generates CDKTN code for importing a ComprehendDocumentClassifierEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComprehendDocumentClassifierEndpoint to import
    * @param importFromId The id of the existing ComprehendDocumentClassifierEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComprehendDocumentClassifierEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/comprehend_document_classifier_endpoint awscc_comprehend_document_classifier_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComprehendDocumentClassifierEndpointConfig
    */
    constructor(scope: Construct, id: string, config: ComprehendDocumentClassifierEndpointConfig);
    get arn(): string;
    get creationTime(): string;
    get currentInferenceUnits(): number;
    private _desiredInferenceUnits?;
    get desiredInferenceUnits(): number;
    set desiredInferenceUnits(value: number);
    get desiredInferenceUnitsInput(): number | undefined;
    private _endpointName?;
    get endpointName(): string;
    set endpointName(value: string);
    get endpointNameInput(): string | undefined;
    get id(): string;
    get lastModifiedTime(): string;
    private _modelArn?;
    get modelArn(): string;
    set modelArn(value: string);
    get modelArnInput(): string | undefined;
    private _tags;
    get tags(): ComprehendDocumentClassifierEndpointTagsList;
    putTags(value: ComprehendDocumentClassifierEndpointTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ComprehendDocumentClassifierEndpointTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
