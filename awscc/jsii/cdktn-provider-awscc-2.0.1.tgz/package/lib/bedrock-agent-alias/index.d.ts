/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockAgentAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name for a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias#agent_alias_name BedrockAgentAlias#agent_alias_name}
    */
    readonly agentAliasName: string;
    /**
    * Identifier for a resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias#agent_id BedrockAgentAlias#agent_id}
    */
    readonly agentId: string;
    /**
    * Description of the Resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias#description BedrockAgentAlias#description}
    */
    readonly description?: string;
    /**
    * Routing configuration for an Agent alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias#routing_configuration BedrockAgentAlias#routing_configuration}
    */
    readonly routingConfiguration?: BedrockAgentAliasRoutingConfiguration[] | cdktn.IResolvable;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias#tags BedrockAgentAlias#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BedrockAgentAliasAgentAliasHistoryEventsRoutingConfiguration {
}
export declare function bedrockAgentAliasAgentAliasHistoryEventsRoutingConfigurationToTerraform(struct?: BedrockAgentAliasAgentAliasHistoryEventsRoutingConfiguration): any;
export declare function bedrockAgentAliasAgentAliasHistoryEventsRoutingConfigurationToHclTerraform(struct?: BedrockAgentAliasAgentAliasHistoryEventsRoutingConfiguration): any;
export declare class BedrockAgentAliasAgentAliasHistoryEventsRoutingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAgentAliasAgentAliasHistoryEventsRoutingConfiguration | undefined;
    set internalValue(value: BedrockAgentAliasAgentAliasHistoryEventsRoutingConfiguration | undefined);
    get agentVersion(): string;
}
export declare class BedrockAgentAliasAgentAliasHistoryEventsRoutingConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAgentAliasAgentAliasHistoryEventsRoutingConfigurationOutputReference;
}
export interface BedrockAgentAliasAgentAliasHistoryEvents {
}
export declare function bedrockAgentAliasAgentAliasHistoryEventsToTerraform(struct?: BedrockAgentAliasAgentAliasHistoryEvents): any;
export declare function bedrockAgentAliasAgentAliasHistoryEventsToHclTerraform(struct?: BedrockAgentAliasAgentAliasHistoryEvents): any;
export declare class BedrockAgentAliasAgentAliasHistoryEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAgentAliasAgentAliasHistoryEvents | undefined;
    set internalValue(value: BedrockAgentAliasAgentAliasHistoryEvents | undefined);
    get endDate(): string;
    private _routingConfiguration;
    get routingConfiguration(): BedrockAgentAliasAgentAliasHistoryEventsRoutingConfigurationList;
    get startDate(): string;
}
export declare class BedrockAgentAliasAgentAliasHistoryEventsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAgentAliasAgentAliasHistoryEventsOutputReference;
}
export interface BedrockAgentAliasRoutingConfiguration {
    /**
    * Agent Version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias#agent_version BedrockAgentAlias#agent_version}
    */
    readonly agentVersion?: string;
}
export declare function bedrockAgentAliasRoutingConfigurationToTerraform(struct?: BedrockAgentAliasRoutingConfiguration | cdktn.IResolvable): any;
export declare function bedrockAgentAliasRoutingConfigurationToHclTerraform(struct?: BedrockAgentAliasRoutingConfiguration | cdktn.IResolvable): any;
export declare class BedrockAgentAliasRoutingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockAgentAliasRoutingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockAgentAliasRoutingConfiguration | cdktn.IResolvable | undefined);
    private _agentVersion?;
    get agentVersion(): string;
    set agentVersion(value: string);
    resetAgentVersion(): void;
    get agentVersionInput(): string | undefined;
}
export declare class BedrockAgentAliasRoutingConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockAgentAliasRoutingConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockAgentAliasRoutingConfigurationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias awscc_bedrock_agent_alias}
*/
export declare class BedrockAgentAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_agent_alias";
    /**
    * Generates CDKTN code for importing a BedrockAgentAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockAgentAlias to import
    * @param importFromId The id of the existing BedrockAgentAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockAgentAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_agent_alias awscc_bedrock_agent_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockAgentAliasConfig
    */
    constructor(scope: Construct, id: string, config: BedrockAgentAliasConfig);
    get agentAliasArn(): string;
    private _agentAliasHistoryEvents;
    get agentAliasHistoryEvents(): BedrockAgentAliasAgentAliasHistoryEventsList;
    get agentAliasId(): string;
    private _agentAliasName?;
    get agentAliasName(): string;
    set agentAliasName(value: string);
    get agentAliasNameInput(): string | undefined;
    get agentAliasStatus(): string;
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _routingConfiguration;
    get routingConfiguration(): BedrockAgentAliasRoutingConfigurationList;
    putRoutingConfiguration(value: BedrockAgentAliasRoutingConfiguration[] | cdktn.IResolvable): void;
    resetRoutingConfiguration(): void;
    get routingConfigurationInput(): cdktn.IResolvable | BedrockAgentAliasRoutingConfiguration[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
