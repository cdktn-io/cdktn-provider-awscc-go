/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoIdentityPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#allow_classic_flow CognitoIdentityPool#allow_classic_flow}
    */
    readonly allowClassicFlow?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#allow_unauthenticated_identities CognitoIdentityPool#allow_unauthenticated_identities}
    */
    readonly allowUnauthenticatedIdentities: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#cognito_events CognitoIdentityPool#cognito_events}
    */
    readonly cognitoEvents?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#cognito_identity_providers CognitoIdentityPool#cognito_identity_providers}
    */
    readonly cognitoIdentityProviders?: CognitoIdentityPoolCognitoIdentityProviders[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#cognito_streams CognitoIdentityPool#cognito_streams}
    */
    readonly cognitoStreams?: CognitoIdentityPoolCognitoStreams;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#developer_provider_name CognitoIdentityPool#developer_provider_name}
    */
    readonly developerProviderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#identity_pool_name CognitoIdentityPool#identity_pool_name}
    */
    readonly identityPoolName?: string;
    /**
    * An array of key-value pairs to apply to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#identity_pool_tags CognitoIdentityPool#identity_pool_tags}
    */
    readonly identityPoolTags?: CognitoIdentityPoolIdentityPoolTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#open_id_connect_provider_ar_ns CognitoIdentityPool#open_id_connect_provider_ar_ns}
    */
    readonly openIdConnectProviderArNs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#push_sync CognitoIdentityPool#push_sync}
    */
    readonly pushSync?: CognitoIdentityPoolPushSync;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#saml_provider_ar_ns CognitoIdentityPool#saml_provider_ar_ns}
    */
    readonly samlProviderArNs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#supported_login_providers CognitoIdentityPool#supported_login_providers}
    */
    readonly supportedLoginProviders?: string;
}
export interface CognitoIdentityPoolCognitoIdentityProviders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#client_id CognitoIdentityPool#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#provider_name CognitoIdentityPool#provider_name}
    */
    readonly providerName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#server_side_token_check CognitoIdentityPool#server_side_token_check}
    */
    readonly serverSideTokenCheck?: boolean | cdktn.IResolvable;
}
export declare function cognitoIdentityPoolCognitoIdentityProvidersToTerraform(struct?: CognitoIdentityPoolCognitoIdentityProviders | cdktn.IResolvable): any;
export declare function cognitoIdentityPoolCognitoIdentityProvidersToHclTerraform(struct?: CognitoIdentityPoolCognitoIdentityProviders | cdktn.IResolvable): any;
export declare class CognitoIdentityPoolCognitoIdentityProvidersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoIdentityPoolCognitoIdentityProviders | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoIdentityPoolCognitoIdentityProviders | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _providerName?;
    get providerName(): string;
    set providerName(value: string);
    resetProviderName(): void;
    get providerNameInput(): string | undefined;
    private _serverSideTokenCheck?;
    get serverSideTokenCheck(): boolean | cdktn.IResolvable;
    set serverSideTokenCheck(value: boolean | cdktn.IResolvable);
    resetServerSideTokenCheck(): void;
    get serverSideTokenCheckInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class CognitoIdentityPoolCognitoIdentityProvidersList extends cdktn.ComplexList {
    internalValue?: CognitoIdentityPoolCognitoIdentityProviders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoIdentityPoolCognitoIdentityProvidersOutputReference;
}
export interface CognitoIdentityPoolCognitoStreams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#role_arn CognitoIdentityPool#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#stream_name CognitoIdentityPool#stream_name}
    */
    readonly streamName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#streaming_status CognitoIdentityPool#streaming_status}
    */
    readonly streamingStatus?: string;
}
export declare function cognitoIdentityPoolCognitoStreamsToTerraform(struct?: CognitoIdentityPoolCognitoStreams | cdktn.IResolvable): any;
export declare function cognitoIdentityPoolCognitoStreamsToHclTerraform(struct?: CognitoIdentityPoolCognitoStreams | cdktn.IResolvable): any;
export declare class CognitoIdentityPoolCognitoStreamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoIdentityPoolCognitoStreams | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoIdentityPoolCognitoStreams | cdktn.IResolvable | undefined);
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _streamName?;
    get streamName(): string;
    set streamName(value: string);
    resetStreamName(): void;
    get streamNameInput(): string | undefined;
    private _streamingStatus?;
    get streamingStatus(): string;
    set streamingStatus(value: string);
    resetStreamingStatus(): void;
    get streamingStatusInput(): string | undefined;
}
export interface CognitoIdentityPoolIdentityPoolTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#key CognitoIdentityPool#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#value CognitoIdentityPool#value}
    */
    readonly value?: string;
}
export declare function cognitoIdentityPoolIdentityPoolTagsToTerraform(struct?: CognitoIdentityPoolIdentityPoolTags | cdktn.IResolvable): any;
export declare function cognitoIdentityPoolIdentityPoolTagsToHclTerraform(struct?: CognitoIdentityPoolIdentityPoolTags | cdktn.IResolvable): any;
export declare class CognitoIdentityPoolIdentityPoolTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoIdentityPoolIdentityPoolTags | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoIdentityPoolIdentityPoolTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CognitoIdentityPoolIdentityPoolTagsList extends cdktn.ComplexList {
    internalValue?: CognitoIdentityPoolIdentityPoolTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoIdentityPoolIdentityPoolTagsOutputReference;
}
export interface CognitoIdentityPoolPushSync {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#application_arns CognitoIdentityPool#application_arns}
    */
    readonly applicationArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#role_arn CognitoIdentityPool#role_arn}
    */
    readonly roleArn?: string;
}
export declare function cognitoIdentityPoolPushSyncToTerraform(struct?: CognitoIdentityPoolPushSync | cdktn.IResolvable): any;
export declare function cognitoIdentityPoolPushSyncToHclTerraform(struct?: CognitoIdentityPoolPushSync | cdktn.IResolvable): any;
export declare class CognitoIdentityPoolPushSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoIdentityPoolPushSync | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoIdentityPoolPushSync | cdktn.IResolvable | undefined);
    private _applicationArns?;
    get applicationArns(): string[];
    set applicationArns(value: string[]);
    resetApplicationArns(): void;
    get applicationArnsInput(): string[] | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool awscc_cognito_identity_pool}
*/
export declare class CognitoIdentityPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_identity_pool";
    /**
    * Generates CDKTN code for importing a CognitoIdentityPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoIdentityPool to import
    * @param importFromId The id of the existing CognitoIdentityPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoIdentityPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_identity_pool awscc_cognito_identity_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoIdentityPoolConfig
    */
    constructor(scope: Construct, id: string, config: CognitoIdentityPoolConfig);
    private _allowClassicFlow?;
    get allowClassicFlow(): boolean | cdktn.IResolvable;
    set allowClassicFlow(value: boolean | cdktn.IResolvable);
    resetAllowClassicFlow(): void;
    get allowClassicFlowInput(): boolean | cdktn.IResolvable | undefined;
    private _allowUnauthenticatedIdentities?;
    get allowUnauthenticatedIdentities(): boolean | cdktn.IResolvable;
    set allowUnauthenticatedIdentities(value: boolean | cdktn.IResolvable);
    get allowUnauthenticatedIdentitiesInput(): boolean | cdktn.IResolvable | undefined;
    private _cognitoEvents?;
    get cognitoEvents(): string;
    set cognitoEvents(value: string);
    resetCognitoEvents(): void;
    get cognitoEventsInput(): string | undefined;
    private _cognitoIdentityProviders;
    get cognitoIdentityProviders(): CognitoIdentityPoolCognitoIdentityProvidersList;
    putCognitoIdentityProviders(value: CognitoIdentityPoolCognitoIdentityProviders[] | cdktn.IResolvable): void;
    resetCognitoIdentityProviders(): void;
    get cognitoIdentityProvidersInput(): cdktn.IResolvable | CognitoIdentityPoolCognitoIdentityProviders[] | undefined;
    private _cognitoStreams;
    get cognitoStreams(): CognitoIdentityPoolCognitoStreamsOutputReference;
    putCognitoStreams(value: CognitoIdentityPoolCognitoStreams): void;
    resetCognitoStreams(): void;
    get cognitoStreamsInput(): cdktn.IResolvable | CognitoIdentityPoolCognitoStreams | undefined;
    private _developerProviderName?;
    get developerProviderName(): string;
    set developerProviderName(value: string);
    resetDeveloperProviderName(): void;
    get developerProviderNameInput(): string | undefined;
    get id(): string;
    get identityPoolId(): string;
    private _identityPoolName?;
    get identityPoolName(): string;
    set identityPoolName(value: string);
    resetIdentityPoolName(): void;
    get identityPoolNameInput(): string | undefined;
    private _identityPoolTags;
    get identityPoolTags(): CognitoIdentityPoolIdentityPoolTagsList;
    putIdentityPoolTags(value: CognitoIdentityPoolIdentityPoolTags[] | cdktn.IResolvable): void;
    resetIdentityPoolTags(): void;
    get identityPoolTagsInput(): cdktn.IResolvable | CognitoIdentityPoolIdentityPoolTags[] | undefined;
    get name(): string;
    private _openIdConnectProviderArNs?;
    get openIdConnectProviderArNs(): string[];
    set openIdConnectProviderArNs(value: string[]);
    resetOpenIdConnectProviderArNs(): void;
    get openIdConnectProviderArNsInput(): string[] | undefined;
    private _pushSync;
    get pushSync(): CognitoIdentityPoolPushSyncOutputReference;
    putPushSync(value: CognitoIdentityPoolPushSync): void;
    resetPushSync(): void;
    get pushSyncInput(): cdktn.IResolvable | CognitoIdentityPoolPushSync | undefined;
    private _samlProviderArNs?;
    get samlProviderArNs(): string[];
    set samlProviderArNs(value: string[]);
    resetSamlProviderArNs(): void;
    get samlProviderArNsInput(): string[] | undefined;
    private _supportedLoginProviders?;
    get supportedLoginProviders(): string;
    set supportedLoginProviders(value: string);
    resetSupportedLoginProviders(): void;
    get supportedLoginProvidersInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
