/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAcmpcaCertificateAuthorityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/acmpca_certificate_authority#id DataAwsccAcmpcaCertificateAuthority#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsage {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsageToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsage): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsageToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsage): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsage | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsage | undefined);
    get crlSign(): cdktn.IResolvable;
    get dataEncipherment(): cdktn.IResolvable;
    get decipherOnly(): cdktn.IResolvable;
    get digitalSignature(): cdktn.IResolvable;
    get encipherOnly(): cdktn.IResolvable;
    get keyAgreement(): cdktn.IResolvable;
    get keyCertSign(): cdktn.IResolvable;
    get keyEncipherment(): cdktn.IResolvable;
    get nonRepudiation(): cdktn.IResolvable;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributes | undefined);
    get objectIdentifier(): string;
    get value(): string;
}
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesOutputReference;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryName | undefined);
    get commonName(): string;
    get country(): string;
    private _customAttributes;
    get customAttributes(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameCustomAttributesList;
    get distinguishedNameQualifier(): string;
    get generationQualifier(): string;
    get givenName(): string;
    get initials(): string;
    get locality(): string;
    get organization(): string;
    get organizationalUnit(): string;
    get pseudonym(): string;
    get serialNumber(): string;
    get state(): string;
    get surname(): string;
    get title(): string;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyNameToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyNameToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyName | undefined);
    get nameAssigner(): string;
    get partyName(): string;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherNameToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherNameToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherName | undefined);
    get typeId(): string;
    get value(): string;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocation | undefined);
    private _directoryName;
    get directoryName(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationDirectoryNameOutputReference;
    get dnsName(): string;
    private _ediPartyName;
    get ediPartyName(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationEdiPartyNameOutputReference;
    get ipAddress(): string;
    private _otherName;
    get otherName(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOtherNameOutputReference;
    get registeredId(): string;
    get rfc822Name(): string;
    get uniformResourceIdentifier(): string;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethodToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethodToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethod | undefined);
    get accessMethodType(): string;
    get customObjectIdentifier(): string;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccess | undefined);
    private _accessLocation;
    get accessLocation(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessLocationOutputReference;
    private _accessMethod;
    get accessMethod(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessAccessMethodOutputReference;
}
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessOutputReference;
}
export interface DataAwsccAcmpcaCertificateAuthorityCsrExtensions {
}
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensions): any;
export declare function dataAwsccAcmpcaCertificateAuthorityCsrExtensionsToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityCsrExtensions): any;
export declare class DataAwsccAcmpcaCertificateAuthorityCsrExtensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityCsrExtensions | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityCsrExtensions | undefined);
    private _keyUsage;
    get keyUsage(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsKeyUsageOutputReference;
    private _subjectInformationAccess;
    get subjectInformationAccess(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsSubjectInformationAccessList;
}
export interface DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration {
}
export declare function dataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfigurationToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration): any;
export declare function dataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfigurationToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration): any;
export declare class DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfiguration | undefined);
    get omitExtension(): cdktn.IResolvable;
}
export interface DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration {
}
export declare function dataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration): any;
export declare function dataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration): any;
export declare class DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfiguration | undefined);
    private _crlDistributionPointExtensionConfiguration;
    get crlDistributionPointExtensionConfiguration(): DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationCrlDistributionPointExtensionConfigurationOutputReference;
    get crlType(): string;
    get customCname(): string;
    get customPath(): string;
    get enabled(): cdktn.IResolvable;
    get expirationInDays(): number;
    get s3BucketName(): string;
    get s3ObjectAcl(): string;
}
export interface DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration {
}
export declare function dataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfigurationToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration): any;
export declare function dataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfigurationToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration): any;
export declare class DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfiguration | undefined);
    get enabled(): cdktn.IResolvable;
    get ocspCustomCname(): string;
}
export interface DataAwsccAcmpcaCertificateAuthorityRevocationConfiguration {
}
export declare function dataAwsccAcmpcaCertificateAuthorityRevocationConfigurationToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityRevocationConfiguration): any;
export declare function dataAwsccAcmpcaCertificateAuthorityRevocationConfigurationToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityRevocationConfiguration): any;
export declare class DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityRevocationConfiguration | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityRevocationConfiguration | undefined);
    private _crlConfiguration;
    get crlConfiguration(): DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationCrlConfigurationOutputReference;
    private _ocspConfiguration;
    get ocspConfiguration(): DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOcspConfigurationOutputReference;
}
export interface DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributes {
}
export declare function dataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributesToTerraform(struct?: DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributes): any;
export declare function dataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributesToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributes): any;
export declare class DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributes | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributes | undefined);
    get objectIdentifier(): string;
    get value(): string;
}
export declare class DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributesOutputReference;
}
export interface DataAwsccAcmpcaCertificateAuthoritySubject {
}
export declare function dataAwsccAcmpcaCertificateAuthoritySubjectToTerraform(struct?: DataAwsccAcmpcaCertificateAuthoritySubject): any;
export declare function dataAwsccAcmpcaCertificateAuthoritySubjectToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthoritySubject): any;
export declare class DataAwsccAcmpcaCertificateAuthoritySubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAcmpcaCertificateAuthoritySubject | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthoritySubject | undefined);
    get commonName(): string;
    get country(): string;
    private _customAttributes;
    get customAttributes(): DataAwsccAcmpcaCertificateAuthoritySubjectCustomAttributesList;
    get distinguishedNameQualifier(): string;
    get generationQualifier(): string;
    get givenName(): string;
    get initials(): string;
    get locality(): string;
    get organization(): string;
    get organizationalUnit(): string;
    get pseudonym(): string;
    get serialNumber(): string;
    get state(): string;
    get surname(): string;
    get title(): string;
}
export interface DataAwsccAcmpcaCertificateAuthorityTags {
}
export declare function dataAwsccAcmpcaCertificateAuthorityTagsToTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityTags): any;
export declare function dataAwsccAcmpcaCertificateAuthorityTagsToHclTerraform(struct?: DataAwsccAcmpcaCertificateAuthorityTags): any;
export declare class DataAwsccAcmpcaCertificateAuthorityTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAcmpcaCertificateAuthorityTags | undefined;
    set internalValue(value: DataAwsccAcmpcaCertificateAuthorityTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAcmpcaCertificateAuthorityTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAcmpcaCertificateAuthorityTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/acmpca_certificate_authority awscc_acmpca_certificate_authority}
*/
export declare class DataAwsccAcmpcaCertificateAuthority extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_acmpca_certificate_authority";
    /**
    * Generates CDKTN code for importing a DataAwsccAcmpcaCertificateAuthority resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAcmpcaCertificateAuthority to import
    * @param importFromId The id of the existing DataAwsccAcmpcaCertificateAuthority that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/acmpca_certificate_authority#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAcmpcaCertificateAuthority to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/acmpca_certificate_authority awscc_acmpca_certificate_authority} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAcmpcaCertificateAuthorityConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAcmpcaCertificateAuthorityConfig);
    get arn(): string;
    get certificateSigningRequest(): string;
    private _csrExtensions;
    get csrExtensions(): DataAwsccAcmpcaCertificateAuthorityCsrExtensionsOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get keyAlgorithm(): string;
    get keyStorageSecurityStandard(): string;
    private _revocationConfiguration;
    get revocationConfiguration(): DataAwsccAcmpcaCertificateAuthorityRevocationConfigurationOutputReference;
    get signingAlgorithm(): string;
    private _subject;
    get subject(): DataAwsccAcmpcaCertificateAuthoritySubjectOutputReference;
    private _tags;
    get tags(): DataAwsccAcmpcaCertificateAuthorityTagsList;
    get type(): string;
    get usageMode(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
