/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#application_id AppconfigEnvironment#application_id}
    */
    readonly applicationId: string;
    /**
    * On resource deletion this controls whether the Deletion Protection check should be applied, bypassed, or (the default) whether the behavior should be controlled by the account-level Deletion Protection setting. See https://docs.aws.amazon.com/appconfig/latest/userguide/deletion-protection.html
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#deletion_protection_check AppconfigEnvironment#deletion_protection_check}
    */
    readonly deletionProtectionCheck?: string;
    /**
    * A description of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#description AppconfigEnvironment#description}
    */
    readonly description?: string;
    /**
    * Amazon CloudWatch alarms to monitor during the deployment process.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#monitors AppconfigEnvironment#monitors}
    */
    readonly monitors?: AppconfigEnvironmentMonitors[] | cdktn.IResolvable;
    /**
    * A name for the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#name AppconfigEnvironment#name}
    */
    readonly name: string;
    /**
    * Metadata to assign to the environment. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#tags AppconfigEnvironment#tags}
    */
    readonly tags?: AppconfigEnvironmentTags[] | cdktn.IResolvable;
}
export interface AppconfigEnvironmentMonitors {
    /**
    * Amazon Resource Name (ARN) of the Amazon CloudWatch alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#alarm_arn AppconfigEnvironment#alarm_arn}
    */
    readonly alarmArn?: string;
    /**
    * ARN of an AWS Identity and Access Management (IAM) role for AWS AppConfig to monitor AlarmArn.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#alarm_role_arn AppconfigEnvironment#alarm_role_arn}
    */
    readonly alarmRoleArn?: string;
}
export declare function appconfigEnvironmentMonitorsToTerraform(struct?: AppconfigEnvironmentMonitors | cdktn.IResolvable): any;
export declare function appconfigEnvironmentMonitorsToHclTerraform(struct?: AppconfigEnvironmentMonitors | cdktn.IResolvable): any;
export declare class AppconfigEnvironmentMonitorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigEnvironmentMonitors | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigEnvironmentMonitors | cdktn.IResolvable | undefined);
    private _alarmArn?;
    get alarmArn(): string;
    set alarmArn(value: string);
    resetAlarmArn(): void;
    get alarmArnInput(): string | undefined;
    private _alarmRoleArn?;
    get alarmRoleArn(): string;
    set alarmRoleArn(value: string);
    resetAlarmRoleArn(): void;
    get alarmRoleArnInput(): string | undefined;
}
export declare class AppconfigEnvironmentMonitorsList extends cdktn.ComplexList {
    internalValue?: AppconfigEnvironmentMonitors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigEnvironmentMonitorsOutputReference;
}
export interface AppconfigEnvironmentTags {
    /**
    * The key-value string map. The valid character set is [a-zA-Z1-9+-=._:/]. The tag key can be up to 128 characters and must not start with aws:.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#key AppconfigEnvironment#key}
    */
    readonly key?: string;
    /**
    * The tag value can be up to 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#value AppconfigEnvironment#value}
    */
    readonly value?: string;
}
export declare function appconfigEnvironmentTagsToTerraform(struct?: AppconfigEnvironmentTags | cdktn.IResolvable): any;
export declare function appconfigEnvironmentTagsToHclTerraform(struct?: AppconfigEnvironmentTags | cdktn.IResolvable): any;
export declare class AppconfigEnvironmentTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigEnvironmentTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigEnvironmentTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AppconfigEnvironmentTagsList extends cdktn.ComplexList {
    internalValue?: AppconfigEnvironmentTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigEnvironmentTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment awscc_appconfig_environment}
*/
export declare class AppconfigEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appconfig_environment";
    /**
    * Generates CDKTN code for importing a AppconfigEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigEnvironment to import
    * @param importFromId The id of the existing AppconfigEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appconfig_environment awscc_appconfig_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: AppconfigEnvironmentConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _deletionProtectionCheck?;
    get deletionProtectionCheck(): string;
    set deletionProtectionCheck(value: string);
    resetDeletionProtectionCheck(): void;
    get deletionProtectionCheckInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get environmentId(): string;
    get id(): string;
    private _monitors;
    get monitors(): AppconfigEnvironmentMonitorsList;
    putMonitors(value: AppconfigEnvironmentMonitors[] | cdktn.IResolvable): void;
    resetMonitors(): void;
    get monitorsInput(): cdktn.IResolvable | AppconfigEnvironmentMonitors[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags;
    get tags(): AppconfigEnvironmentTagsList;
    putTags(value: AppconfigEnvironmentTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppconfigEnvironmentTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
