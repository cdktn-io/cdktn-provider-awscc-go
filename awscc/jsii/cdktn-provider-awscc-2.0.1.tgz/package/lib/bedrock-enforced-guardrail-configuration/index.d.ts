/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockEnforcedGuardrailConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier for the guardrail, could be the ID or the ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#guardrail_identifier BedrockEnforcedGuardrailConfiguration#guardrail_identifier}
    */
    readonly guardrailIdentifier: string;
    /**
    * Numerical guardrail version (not DRAFT)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#guardrail_version BedrockEnforcedGuardrailConfiguration#guardrail_version}
    */
    readonly guardrailVersion: string;
    /**
    * Model-specific information for the enforced guardrail configuration. If not present, the configuration is enforced on all models
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#model_enforcement BedrockEnforcedGuardrailConfiguration#model_enforcement}
    */
    readonly modelEnforcement?: BedrockEnforcedGuardrailConfigurationModelEnforcement;
    /**
    * Selective content guarding controls for enforced guardrails
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#selective_content_guarding BedrockEnforcedGuardrailConfiguration#selective_content_guarding}
    */
    readonly selectiveContentGuarding?: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding;
}
export interface BedrockEnforcedGuardrailConfigurationModelEnforcement {
    /**
    * Models to exclude from enforcement. If a model is in both lists, it is excluded
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#excluded_models BedrockEnforcedGuardrailConfiguration#excluded_models}
    */
    readonly excludedModels?: string[];
    /**
    * Models to enforce the guardrail on
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#included_models BedrockEnforcedGuardrailConfiguration#included_models}
    */
    readonly includedModels?: string[];
}
export declare function bedrockEnforcedGuardrailConfigurationModelEnforcementToTerraform(struct?: BedrockEnforcedGuardrailConfigurationModelEnforcement | cdktn.IResolvable): any;
export declare function bedrockEnforcedGuardrailConfigurationModelEnforcementToHclTerraform(struct?: BedrockEnforcedGuardrailConfigurationModelEnforcement | cdktn.IResolvable): any;
export declare class BedrockEnforcedGuardrailConfigurationModelEnforcementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockEnforcedGuardrailConfigurationModelEnforcement | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEnforcedGuardrailConfigurationModelEnforcement | cdktn.IResolvable | undefined);
    private _excludedModels?;
    get excludedModels(): string[];
    set excludedModels(value: string[]);
    resetExcludedModels(): void;
    get excludedModelsInput(): string[] | undefined;
    private _includedModels?;
    get includedModels(): string[];
    set includedModels(value: string[]);
    resetIncludedModels(): void;
    get includedModelsInput(): string[] | undefined;
}
export interface BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding {
    /**
    * Selective guarding mode for user messages
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#messages BedrockEnforcedGuardrailConfiguration#messages}
    */
    readonly messages?: string;
    /**
    * Selective guarding mode for system prompts
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#system BedrockEnforcedGuardrailConfiguration#system}
    */
    readonly systemAttribute?: string;
}
export declare function bedrockEnforcedGuardrailConfigurationSelectiveContentGuardingToTerraform(struct?: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | cdktn.IResolvable): any;
export declare function bedrockEnforcedGuardrailConfigurationSelectiveContentGuardingToHclTerraform(struct?: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | cdktn.IResolvable): any;
export declare class BedrockEnforcedGuardrailConfigurationSelectiveContentGuardingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | cdktn.IResolvable | undefined);
    private _messages?;
    get messages(): string;
    set messages(value: string);
    resetMessages(): void;
    get messagesInput(): string | undefined;
    private _system?;
    get systemAttribute(): string;
    set systemAttribute(value: string);
    resetSystemAttribute(): void;
    get systemAttributeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration awscc_bedrock_enforced_guardrail_configuration}
*/
export declare class BedrockEnforcedGuardrailConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrock_enforced_guardrail_configuration";
    /**
    * Generates CDKTN code for importing a BedrockEnforcedGuardrailConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockEnforcedGuardrailConfiguration to import
    * @param importFromId The id of the existing BedrockEnforcedGuardrailConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockEnforcedGuardrailConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrock_enforced_guardrail_configuration awscc_bedrock_enforced_guardrail_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockEnforcedGuardrailConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: BedrockEnforcedGuardrailConfigurationConfig);
    get configId(): string;
    get createdAt(): string;
    get createdBy(): string;
    get guardrailArn(): string;
    get guardrailId(): string;
    private _guardrailIdentifier?;
    get guardrailIdentifier(): string;
    set guardrailIdentifier(value: string);
    get guardrailIdentifierInput(): string | undefined;
    private _guardrailVersion?;
    get guardrailVersion(): string;
    set guardrailVersion(value: string);
    get guardrailVersionInput(): string | undefined;
    get id(): string;
    private _modelEnforcement;
    get modelEnforcement(): BedrockEnforcedGuardrailConfigurationModelEnforcementOutputReference;
    putModelEnforcement(value: BedrockEnforcedGuardrailConfigurationModelEnforcement): void;
    resetModelEnforcement(): void;
    get modelEnforcementInput(): cdktn.IResolvable | BedrockEnforcedGuardrailConfigurationModelEnforcement | undefined;
    get owner(): string;
    private _selectiveContentGuarding;
    get selectiveContentGuarding(): BedrockEnforcedGuardrailConfigurationSelectiveContentGuardingOutputReference;
    putSelectiveContentGuarding(value: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding): void;
    resetSelectiveContentGuarding(): void;
    get selectiveContentGuardingInput(): cdktn.IResolvable | BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | undefined;
    get updatedAt(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
