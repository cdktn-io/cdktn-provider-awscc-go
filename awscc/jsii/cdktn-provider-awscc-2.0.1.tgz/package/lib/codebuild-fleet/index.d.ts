/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodebuildFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#base_capacity CodebuildFleet#base_capacity}
    */
    readonly baseCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#compute_configuration CodebuildFleet#compute_configuration}
    */
    readonly computeConfiguration?: CodebuildFleetComputeConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#compute_type CodebuildFleet#compute_type}
    */
    readonly computeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#environment_type CodebuildFleet#environment_type}
    */
    readonly environmentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#fleet_proxy_configuration CodebuildFleet#fleet_proxy_configuration}
    */
    readonly fleetProxyConfiguration?: CodebuildFleetFleetProxyConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#fleet_service_role CodebuildFleet#fleet_service_role}
    */
    readonly fleetServiceRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#fleet_vpc_config CodebuildFleet#fleet_vpc_config}
    */
    readonly fleetVpcConfig?: CodebuildFleetFleetVpcConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#image_id CodebuildFleet#image_id}
    */
    readonly imageId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#name CodebuildFleet#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#overflow_behavior CodebuildFleet#overflow_behavior}
    */
    readonly overflowBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#scaling_configuration CodebuildFleet#scaling_configuration}
    */
    readonly scalingConfiguration?: CodebuildFleetScalingConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#tags CodebuildFleet#tags}
    */
    readonly tags?: CodebuildFleetTags[] | cdktn.IResolvable;
}
export interface CodebuildFleetComputeConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#disk CodebuildFleet#disk}
    */
    readonly disk?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#instance_type CodebuildFleet#instance_type}
    */
    readonly instanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#machine_type CodebuildFleet#machine_type}
    */
    readonly machineType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#memory CodebuildFleet#memory}
    */
    readonly memory?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#v_cpu CodebuildFleet#v_cpu}
    */
    readonly vCpu?: number;
}
export declare function codebuildFleetComputeConfigurationToTerraform(struct?: CodebuildFleetComputeConfiguration | cdktn.IResolvable): any;
export declare function codebuildFleetComputeConfigurationToHclTerraform(struct?: CodebuildFleetComputeConfiguration | cdktn.IResolvable): any;
export declare class CodebuildFleetComputeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodebuildFleetComputeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildFleetComputeConfiguration | cdktn.IResolvable | undefined);
    private _disk?;
    get disk(): number;
    set disk(value: number);
    resetDisk(): void;
    get diskInput(): number | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    resetMachineType(): void;
    get machineTypeInput(): string | undefined;
    private _memory?;
    get memory(): number;
    set memory(value: number);
    resetMemory(): void;
    get memoryInput(): number | undefined;
    private _vCpu?;
    get vCpu(): number;
    set vCpu(value: number);
    resetVCpu(): void;
    get vCpuInput(): number | undefined;
}
export interface CodebuildFleetFleetProxyConfigurationOrderedProxyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#effect CodebuildFleet#effect}
    */
    readonly effect?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#entities CodebuildFleet#entities}
    */
    readonly entities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#type CodebuildFleet#type}
    */
    readonly type?: string;
}
export declare function codebuildFleetFleetProxyConfigurationOrderedProxyRulesToTerraform(struct?: CodebuildFleetFleetProxyConfigurationOrderedProxyRules | cdktn.IResolvable): any;
export declare function codebuildFleetFleetProxyConfigurationOrderedProxyRulesToHclTerraform(struct?: CodebuildFleetFleetProxyConfigurationOrderedProxyRules | cdktn.IResolvable): any;
export declare class CodebuildFleetFleetProxyConfigurationOrderedProxyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodebuildFleetFleetProxyConfigurationOrderedProxyRules | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildFleetFleetProxyConfigurationOrderedProxyRules | cdktn.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    resetEffect(): void;
    get effectInput(): string | undefined;
    private _entities?;
    get entities(): string[];
    set entities(value: string[]);
    resetEntities(): void;
    get entitiesInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class CodebuildFleetFleetProxyConfigurationOrderedProxyRulesList extends cdktn.ComplexList {
    internalValue?: CodebuildFleetFleetProxyConfigurationOrderedProxyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodebuildFleetFleetProxyConfigurationOrderedProxyRulesOutputReference;
}
export interface CodebuildFleetFleetProxyConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#default_behavior CodebuildFleet#default_behavior}
    */
    readonly defaultBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#ordered_proxy_rules CodebuildFleet#ordered_proxy_rules}
    */
    readonly orderedProxyRules?: CodebuildFleetFleetProxyConfigurationOrderedProxyRules[] | cdktn.IResolvable;
}
export declare function codebuildFleetFleetProxyConfigurationToTerraform(struct?: CodebuildFleetFleetProxyConfiguration | cdktn.IResolvable): any;
export declare function codebuildFleetFleetProxyConfigurationToHclTerraform(struct?: CodebuildFleetFleetProxyConfiguration | cdktn.IResolvable): any;
export declare class CodebuildFleetFleetProxyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodebuildFleetFleetProxyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildFleetFleetProxyConfiguration | cdktn.IResolvable | undefined);
    private _defaultBehavior?;
    get defaultBehavior(): string;
    set defaultBehavior(value: string);
    resetDefaultBehavior(): void;
    get defaultBehaviorInput(): string | undefined;
    private _orderedProxyRules;
    get orderedProxyRules(): CodebuildFleetFleetProxyConfigurationOrderedProxyRulesList;
    putOrderedProxyRules(value: CodebuildFleetFleetProxyConfigurationOrderedProxyRules[] | cdktn.IResolvable): void;
    resetOrderedProxyRules(): void;
    get orderedProxyRulesInput(): cdktn.IResolvable | CodebuildFleetFleetProxyConfigurationOrderedProxyRules[] | undefined;
}
export interface CodebuildFleetFleetVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#security_group_ids CodebuildFleet#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#subnets CodebuildFleet#subnets}
    */
    readonly subnets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#vpc_id CodebuildFleet#vpc_id}
    */
    readonly vpcId?: string;
}
export declare function codebuildFleetFleetVpcConfigToTerraform(struct?: CodebuildFleetFleetVpcConfig | cdktn.IResolvable): any;
export declare function codebuildFleetFleetVpcConfigToHclTerraform(struct?: CodebuildFleetFleetVpcConfig | cdktn.IResolvable): any;
export declare class CodebuildFleetFleetVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodebuildFleetFleetVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildFleetFleetVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
}
export interface CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#metric_type CodebuildFleet#metric_type}
    */
    readonly metricType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#target_value CodebuildFleet#target_value}
    */
    readonly targetValue?: number;
}
export declare function codebuildFleetScalingConfigurationTargetTrackingScalingConfigsToTerraform(struct?: CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs | cdktn.IResolvable): any;
export declare function codebuildFleetScalingConfigurationTargetTrackingScalingConfigsToHclTerraform(struct?: CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs | cdktn.IResolvable): any;
export declare class CodebuildFleetScalingConfigurationTargetTrackingScalingConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs | cdktn.IResolvable | undefined);
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    resetMetricType(): void;
    get metricTypeInput(): string | undefined;
    private _targetValue?;
    get targetValue(): number;
    set targetValue(value: number);
    resetTargetValue(): void;
    get targetValueInput(): number | undefined;
}
export declare class CodebuildFleetScalingConfigurationTargetTrackingScalingConfigsList extends cdktn.ComplexList {
    internalValue?: CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodebuildFleetScalingConfigurationTargetTrackingScalingConfigsOutputReference;
}
export interface CodebuildFleetScalingConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#max_capacity CodebuildFleet#max_capacity}
    */
    readonly maxCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#scaling_type CodebuildFleet#scaling_type}
    */
    readonly scalingType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#target_tracking_scaling_configs CodebuildFleet#target_tracking_scaling_configs}
    */
    readonly targetTrackingScalingConfigs?: CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs[] | cdktn.IResolvable;
}
export declare function codebuildFleetScalingConfigurationToTerraform(struct?: CodebuildFleetScalingConfiguration | cdktn.IResolvable): any;
export declare function codebuildFleetScalingConfigurationToHclTerraform(struct?: CodebuildFleetScalingConfiguration | cdktn.IResolvable): any;
export declare class CodebuildFleetScalingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CodebuildFleetScalingConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildFleetScalingConfiguration | cdktn.IResolvable | undefined);
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    resetMaxCapacity(): void;
    get maxCapacityInput(): number | undefined;
    private _scalingType?;
    get scalingType(): string;
    set scalingType(value: string);
    resetScalingType(): void;
    get scalingTypeInput(): string | undefined;
    private _targetTrackingScalingConfigs;
    get targetTrackingScalingConfigs(): CodebuildFleetScalingConfigurationTargetTrackingScalingConfigsList;
    putTargetTrackingScalingConfigs(value: CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs[] | cdktn.IResolvable): void;
    resetTargetTrackingScalingConfigs(): void;
    get targetTrackingScalingConfigsInput(): cdktn.IResolvable | CodebuildFleetScalingConfigurationTargetTrackingScalingConfigs[] | undefined;
}
export interface CodebuildFleetTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 127 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#key CodebuildFleet#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is 0 to 255 Unicode characters in length. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#value CodebuildFleet#value}
    */
    readonly value?: string;
}
export declare function codebuildFleetTagsToTerraform(struct?: CodebuildFleetTags | cdktn.IResolvable): any;
export declare function codebuildFleetTagsToHclTerraform(struct?: CodebuildFleetTags | cdktn.IResolvable): any;
export declare class CodebuildFleetTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CodebuildFleetTags | cdktn.IResolvable | undefined;
    set internalValue(value: CodebuildFleetTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CodebuildFleetTagsList extends cdktn.ComplexList {
    internalValue?: CodebuildFleetTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CodebuildFleetTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet awscc_codebuild_fleet}
*/
export declare class CodebuildFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_codebuild_fleet";
    /**
    * Generates CDKTN code for importing a CodebuildFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodebuildFleet to import
    * @param importFromId The id of the existing CodebuildFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodebuildFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/codebuild_fleet awscc_codebuild_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodebuildFleetConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CodebuildFleetConfig);
    get arn(): string;
    private _baseCapacity?;
    get baseCapacity(): number;
    set baseCapacity(value: number);
    resetBaseCapacity(): void;
    get baseCapacityInput(): number | undefined;
    private _computeConfiguration;
    get computeConfiguration(): CodebuildFleetComputeConfigurationOutputReference;
    putComputeConfiguration(value: CodebuildFleetComputeConfiguration): void;
    resetComputeConfiguration(): void;
    get computeConfigurationInput(): cdktn.IResolvable | CodebuildFleetComputeConfiguration | undefined;
    private _computeType?;
    get computeType(): string;
    set computeType(value: string);
    resetComputeType(): void;
    get computeTypeInput(): string | undefined;
    private _environmentType?;
    get environmentType(): string;
    set environmentType(value: string);
    resetEnvironmentType(): void;
    get environmentTypeInput(): string | undefined;
    private _fleetProxyConfiguration;
    get fleetProxyConfiguration(): CodebuildFleetFleetProxyConfigurationOutputReference;
    putFleetProxyConfiguration(value: CodebuildFleetFleetProxyConfiguration): void;
    resetFleetProxyConfiguration(): void;
    get fleetProxyConfigurationInput(): cdktn.IResolvable | CodebuildFleetFleetProxyConfiguration | undefined;
    private _fleetServiceRole?;
    get fleetServiceRole(): string;
    set fleetServiceRole(value: string);
    resetFleetServiceRole(): void;
    get fleetServiceRoleInput(): string | undefined;
    private _fleetVpcConfig;
    get fleetVpcConfig(): CodebuildFleetFleetVpcConfigOutputReference;
    putFleetVpcConfig(value: CodebuildFleetFleetVpcConfig): void;
    resetFleetVpcConfig(): void;
    get fleetVpcConfigInput(): cdktn.IResolvable | CodebuildFleetFleetVpcConfig | undefined;
    get id(): string;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _overflowBehavior?;
    get overflowBehavior(): string;
    set overflowBehavior(value: string);
    resetOverflowBehavior(): void;
    get overflowBehaviorInput(): string | undefined;
    private _scalingConfiguration;
    get scalingConfiguration(): CodebuildFleetScalingConfigurationOutputReference;
    putScalingConfiguration(value: CodebuildFleetScalingConfiguration): void;
    resetScalingConfiguration(): void;
    get scalingConfigurationInput(): cdktn.IResolvable | CodebuildFleetScalingConfiguration | undefined;
    private _tags;
    get tags(): CodebuildFleetTagsList;
    putTags(value: CodebuildFleetTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CodebuildFleetTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
