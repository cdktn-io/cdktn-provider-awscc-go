/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamDirectoryConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#certificate_based_auth_properties AppstreamDirectoryConfig#certificate_based_auth_properties}
    */
    readonly certificateBasedAuthProperties?: AppstreamDirectoryConfigCertificateBasedAuthProperties;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#directory_name AppstreamDirectoryConfig#directory_name}
    */
    readonly directoryName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#organizational_unit_distinguished_names AppstreamDirectoryConfig#organizational_unit_distinguished_names}
    */
    readonly organizationalUnitDistinguishedNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#service_account_credentials AppstreamDirectoryConfig#service_account_credentials}
    */
    readonly serviceAccountCredentials: AppstreamDirectoryConfigServiceAccountCredentials;
}
export interface AppstreamDirectoryConfigCertificateBasedAuthProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#certificate_authority_arn AppstreamDirectoryConfig#certificate_authority_arn}
    */
    readonly certificateAuthorityArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#status AppstreamDirectoryConfig#status}
    */
    readonly status?: string;
}
export declare function appstreamDirectoryConfigCertificateBasedAuthPropertiesToTerraform(struct?: AppstreamDirectoryConfigCertificateBasedAuthProperties | cdktn.IResolvable): any;
export declare function appstreamDirectoryConfigCertificateBasedAuthPropertiesToHclTerraform(struct?: AppstreamDirectoryConfigCertificateBasedAuthProperties | cdktn.IResolvable): any;
export declare class AppstreamDirectoryConfigCertificateBasedAuthPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamDirectoryConfigCertificateBasedAuthProperties | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamDirectoryConfigCertificateBasedAuthProperties | cdktn.IResolvable | undefined);
    private _certificateAuthorityArn?;
    get certificateAuthorityArn(): string;
    set certificateAuthorityArn(value: string);
    resetCertificateAuthorityArn(): void;
    get certificateAuthorityArnInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
export interface AppstreamDirectoryConfigServiceAccountCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#account_name AppstreamDirectoryConfig#account_name}
    */
    readonly accountName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#account_password AppstreamDirectoryConfig#account_password}
    */
    readonly accountPassword: string;
}
export declare function appstreamDirectoryConfigServiceAccountCredentialsToTerraform(struct?: AppstreamDirectoryConfigServiceAccountCredentials | cdktn.IResolvable): any;
export declare function appstreamDirectoryConfigServiceAccountCredentialsToHclTerraform(struct?: AppstreamDirectoryConfigServiceAccountCredentials | cdktn.IResolvable): any;
export declare class AppstreamDirectoryConfigServiceAccountCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppstreamDirectoryConfigServiceAccountCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: AppstreamDirectoryConfigServiceAccountCredentials | cdktn.IResolvable | undefined);
    private _accountName?;
    get accountName(): string;
    set accountName(value: string);
    get accountNameInput(): string | undefined;
    private _accountPassword?;
    get accountPassword(): string;
    set accountPassword(value: string);
    get accountPasswordInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config awscc_appstream_directory_config}
*/
export declare class AppstreamDirectoryConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_directory_config";
    /**
    * Generates CDKTN code for importing a AppstreamDirectoryConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamDirectoryConfig to import
    * @param importFromId The id of the existing AppstreamDirectoryConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamDirectoryConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_directory_config awscc_appstream_directory_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamDirectoryConfigConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamDirectoryConfigConfig);
    private _certificateBasedAuthProperties;
    get certificateBasedAuthProperties(): AppstreamDirectoryConfigCertificateBasedAuthPropertiesOutputReference;
    putCertificateBasedAuthProperties(value: AppstreamDirectoryConfigCertificateBasedAuthProperties): void;
    resetCertificateBasedAuthProperties(): void;
    get certificateBasedAuthPropertiesInput(): cdktn.IResolvable | AppstreamDirectoryConfigCertificateBasedAuthProperties | undefined;
    private _directoryName?;
    get directoryName(): string;
    set directoryName(value: string);
    get directoryNameInput(): string | undefined;
    get id(): string;
    private _organizationalUnitDistinguishedNames?;
    get organizationalUnitDistinguishedNames(): string[];
    set organizationalUnitDistinguishedNames(value: string[]);
    get organizationalUnitDistinguishedNamesInput(): string[] | undefined;
    private _serviceAccountCredentials;
    get serviceAccountCredentials(): AppstreamDirectoryConfigServiceAccountCredentialsOutputReference;
    putServiceAccountCredentials(value: AppstreamDirectoryConfigServiceAccountCredentials): void;
    get serviceAccountCredentialsInput(): cdktn.IResolvable | AppstreamDirectoryConfigServiceAccountCredentials | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
