/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoUserPoolDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#custom_domain_config CognitoUserPoolDomain#custom_domain_config}
    */
    readonly customDomainConfig?: CognitoUserPoolDomainCustomDomainConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#domain CognitoUserPoolDomain#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#managed_login_version CognitoUserPoolDomain#managed_login_version}
    */
    readonly managedLoginVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#routing CognitoUserPoolDomain#routing}
    */
    readonly routing?: CognitoUserPoolDomainRouting;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#user_pool_id CognitoUserPoolDomain#user_pool_id}
    */
    readonly userPoolId: string;
}
export interface CognitoUserPoolDomainCustomDomainConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#certificate_arn CognitoUserPoolDomain#certificate_arn}
    */
    readonly certificateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#security_policy CognitoUserPoolDomain#security_policy}
    */
    readonly securityPolicy?: string;
}
export declare function cognitoUserPoolDomainCustomDomainConfigToTerraform(struct?: CognitoUserPoolDomainCustomDomainConfig | cdktn.IResolvable): any;
export declare function cognitoUserPoolDomainCustomDomainConfigToHclTerraform(struct?: CognitoUserPoolDomainCustomDomainConfig | cdktn.IResolvable): any;
export declare class CognitoUserPoolDomainCustomDomainConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolDomainCustomDomainConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolDomainCustomDomainConfig | cdktn.IResolvable | undefined);
    private _certificateArn?;
    get certificateArn(): string;
    set certificateArn(value: string);
    resetCertificateArn(): void;
    get certificateArnInput(): string | undefined;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    resetSecurityPolicy(): void;
    get securityPolicyInput(): string | undefined;
}
export interface CognitoUserPoolDomainRoutingFailover {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#primary_route_53_health_check_id CognitoUserPoolDomain#primary_route_53_health_check_id}
    */
    readonly primaryRoute53HealthCheckId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#secondary_region CognitoUserPoolDomain#secondary_region}
    */
    readonly secondaryRegion?: string;
}
export declare function cognitoUserPoolDomainRoutingFailoverToTerraform(struct?: CognitoUserPoolDomainRoutingFailover | cdktn.IResolvable): any;
export declare function cognitoUserPoolDomainRoutingFailoverToHclTerraform(struct?: CognitoUserPoolDomainRoutingFailover | cdktn.IResolvable): any;
export declare class CognitoUserPoolDomainRoutingFailoverOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolDomainRoutingFailover | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolDomainRoutingFailover | cdktn.IResolvable | undefined);
    private _primaryRoute53HealthCheckId?;
    get primaryRoute53HealthCheckId(): string;
    set primaryRoute53HealthCheckId(value: string);
    resetPrimaryRoute53HealthCheckId(): void;
    get primaryRoute53HealthCheckIdInput(): string | undefined;
    private _secondaryRegion?;
    get secondaryRegion(): string;
    set secondaryRegion(value: string);
    resetSecondaryRegion(): void;
    get secondaryRegionInput(): string | undefined;
}
export interface CognitoUserPoolDomainRouting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#failover CognitoUserPoolDomain#failover}
    */
    readonly failover?: CognitoUserPoolDomainRoutingFailover;
}
export declare function cognitoUserPoolDomainRoutingToTerraform(struct?: CognitoUserPoolDomainRouting | cdktn.IResolvable): any;
export declare function cognitoUserPoolDomainRoutingToHclTerraform(struct?: CognitoUserPoolDomainRouting | cdktn.IResolvable): any;
export declare class CognitoUserPoolDomainRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolDomainRouting | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolDomainRouting | cdktn.IResolvable | undefined);
    private _failover;
    get failover(): CognitoUserPoolDomainRoutingFailoverOutputReference;
    putFailover(value: CognitoUserPoolDomainRoutingFailover): void;
    resetFailover(): void;
    get failoverInput(): cdktn.IResolvable | CognitoUserPoolDomainRoutingFailover | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain awscc_cognito_user_pool_domain}
*/
export declare class CognitoUserPoolDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_user_pool_domain";
    /**
    * Generates CDKTN code for importing a CognitoUserPoolDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoUserPoolDomain to import
    * @param importFromId The id of the existing CognitoUserPoolDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoUserPoolDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_domain awscc_cognito_user_pool_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoUserPoolDomainConfig
    */
    constructor(scope: Construct, id: string, config: CognitoUserPoolDomainConfig);
    get cloudfrontDistribution(): string;
    private _customDomainConfig;
    get customDomainConfig(): CognitoUserPoolDomainCustomDomainConfigOutputReference;
    putCustomDomainConfig(value: CognitoUserPoolDomainCustomDomainConfig): void;
    resetCustomDomainConfig(): void;
    get customDomainConfigInput(): cdktn.IResolvable | CognitoUserPoolDomainCustomDomainConfig | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    get id(): string;
    private _managedLoginVersion?;
    get managedLoginVersion(): number;
    set managedLoginVersion(value: number);
    resetManagedLoginVersion(): void;
    get managedLoginVersionInput(): number | undefined;
    private _routing;
    get routing(): CognitoUserPoolDomainRoutingOutputReference;
    putRouting(value: CognitoUserPoolDomainRouting): void;
    resetRouting(): void;
    get routingInput(): cdktn.IResolvable | CognitoUserPoolDomainRouting | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
