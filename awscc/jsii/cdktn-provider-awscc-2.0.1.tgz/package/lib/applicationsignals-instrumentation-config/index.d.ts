/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationsignalsInstrumentationConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Client-side filters that target specific instances. Each object is AND-matched on keys, multiple objects are OR-matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#attribute_filters ApplicationsignalsInstrumentationConfig#attribute_filters}
    */
    readonly attributeFilters?: {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    /**
    * Specifies what to capture when the instrumentation point is hit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#capture_configuration ApplicationsignalsInstrumentationConfig#capture_configuration}
    */
    readonly captureConfiguration: ApplicationsignalsInstrumentationConfigCaptureConfiguration;
    /**
    * An optional short description that explains the purpose of this instrumentation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#description ApplicationsignalsInstrumentationConfig#description}
    */
    readonly description?: string;
    /**
    * The environment that the service is running in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#environment ApplicationsignalsInstrumentationConfig#environment}
    */
    readonly environment: string;
    /**
    * The timestamp after which this configuration is no longer served. For BREAKPOINT only; defaults to 24 hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#expires_at ApplicationsignalsInstrumentationConfig#expires_at}
    */
    readonly expiresAt?: string;
    /**
    * Type of instrumentation: BREAKPOINT (temporary, expires after 24 hours) or PROBE (permanent, persists until deleted).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#instrumentation_type ApplicationsignalsInstrumentationConfig#instrumentation_type}
    */
    readonly instrumentationType: string;
    /**
    * The location where instrumentation should be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#location ApplicationsignalsInstrumentationConfig#location}
    */
    readonly location: ApplicationsignalsInstrumentationConfigLocation;
    /**
    * The name of the service to instrument. This should match the service.name resource attribute reported by the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#service ApplicationsignalsInstrumentationConfig#service}
    */
    readonly service: string;
    /**
    * The telemetry signal type to emit for this instrumentation. The supported value is SNAPSHOT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#signal_type ApplicationsignalsInstrumentationConfig#signal_type}
    */
    readonly signalType: string;
    /**
    * An optional list of key-value pairs to associate with the instrumentation configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#tags ApplicationsignalsInstrumentationConfig#tags}
    */
    readonly tags?: ApplicationsignalsInstrumentationConfigTags[] | cdktn.IResolvable;
}
export interface ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimits {
    /**
    * Maximum nesting depth to traverse inside collections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#max_collection_depth ApplicationsignalsInstrumentationConfig#max_collection_depth}
    */
    readonly maxCollectionDepth?: number;
    /**
    * Maximum number of items to capture from any collection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#max_collection_width ApplicationsignalsInstrumentationConfig#max_collection_width}
    */
    readonly maxCollectionWidth?: number;
    /**
    * Maximum number of fields to capture for any object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#max_fields_per_object ApplicationsignalsInstrumentationConfig#max_fields_per_object}
    */
    readonly maxFieldsPerObject?: number;
    /**
    * Maximum number of times the instrumentation point can be hit before disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#max_hits ApplicationsignalsInstrumentationConfig#max_hits}
    */
    readonly maxHits?: number;
    /**
    * Maximum depth for nested object traversal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#max_object_depth ApplicationsignalsInstrumentationConfig#max_object_depth}
    */
    readonly maxObjectDepth?: number;
    /**
    * Maximum number of stack frames to capture.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#max_stack_frames ApplicationsignalsInstrumentationConfig#max_stack_frames}
    */
    readonly maxStackFrames?: number;
    /**
    * Maximum total size in bytes of a captured stack trace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#max_stack_trace_size ApplicationsignalsInstrumentationConfig#max_stack_trace_size}
    */
    readonly maxStackTraceSize?: number;
    /**
    * Maximum length of captured string values in characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#max_string_length ApplicationsignalsInstrumentationConfig#max_string_length}
    */
    readonly maxStringLength?: number;
}
export declare function applicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimitsToTerraform(struct?: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimits | cdktn.IResolvable): any;
export declare function applicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimitsToHclTerraform(struct?: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimits | cdktn.IResolvable): any;
export declare class ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimits | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimits | cdktn.IResolvable | undefined);
    private _maxCollectionDepth?;
    get maxCollectionDepth(): number;
    set maxCollectionDepth(value: number);
    resetMaxCollectionDepth(): void;
    get maxCollectionDepthInput(): number | undefined;
    private _maxCollectionWidth?;
    get maxCollectionWidth(): number;
    set maxCollectionWidth(value: number);
    resetMaxCollectionWidth(): void;
    get maxCollectionWidthInput(): number | undefined;
    private _maxFieldsPerObject?;
    get maxFieldsPerObject(): number;
    set maxFieldsPerObject(value: number);
    resetMaxFieldsPerObject(): void;
    get maxFieldsPerObjectInput(): number | undefined;
    private _maxHits?;
    get maxHits(): number;
    set maxHits(value: number);
    resetMaxHits(): void;
    get maxHitsInput(): number | undefined;
    private _maxObjectDepth?;
    get maxObjectDepth(): number;
    set maxObjectDepth(value: number);
    resetMaxObjectDepth(): void;
    get maxObjectDepthInput(): number | undefined;
    private _maxStackFrames?;
    get maxStackFrames(): number;
    set maxStackFrames(value: number);
    resetMaxStackFrames(): void;
    get maxStackFramesInput(): number | undefined;
    private _maxStackTraceSize?;
    get maxStackTraceSize(): number;
    set maxStackTraceSize(value: number);
    resetMaxStackTraceSize(): void;
    get maxStackTraceSizeInput(): number | undefined;
    private _maxStringLength?;
    get maxStringLength(): number;
    set maxStringLength(value: number);
    resetMaxStringLength(): void;
    get maxStringLengthInput(): number | undefined;
}
export interface ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCapture {
    /**
    * The function arguments to capture.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#capture_arguments ApplicationsignalsInstrumentationConfig#capture_arguments}
    */
    readonly captureArguments?: string[];
    /**
    * Safety limits that bound what is captured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#capture_limits ApplicationsignalsInstrumentationConfig#capture_limits}
    */
    readonly captureLimits: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimits;
    /**
    * The local variables to capture by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#capture_locals ApplicationsignalsInstrumentationConfig#capture_locals}
    */
    readonly captureLocals?: string[];
    /**
    * Whether to capture the return value. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#capture_return ApplicationsignalsInstrumentationConfig#capture_return}
    */
    readonly captureReturn?: boolean | cdktn.IResolvable;
    /**
    * Whether to capture a stack trace. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#capture_stack_trace ApplicationsignalsInstrumentationConfig#capture_stack_trace}
    */
    readonly captureStackTrace?: boolean | cdktn.IResolvable;
}
export declare function applicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureToTerraform(struct?: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCapture | cdktn.IResolvable): any;
export declare function applicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureToHclTerraform(struct?: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCapture | cdktn.IResolvable): any;
export declare class ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCapture | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCapture | cdktn.IResolvable | undefined);
    private _captureArguments?;
    get captureArguments(): string[];
    set captureArguments(value: string[]);
    resetCaptureArguments(): void;
    get captureArgumentsInput(): string[] | undefined;
    private _captureLimits;
    get captureLimits(): ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimitsOutputReference;
    putCaptureLimits(value: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimits): void;
    get captureLimitsInput(): cdktn.IResolvable | ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureCaptureLimits | undefined;
    private _captureLocals?;
    get captureLocals(): string[];
    set captureLocals(value: string[]);
    resetCaptureLocals(): void;
    get captureLocalsInput(): string[] | undefined;
    private _captureReturn?;
    get captureReturn(): boolean | cdktn.IResolvable;
    set captureReturn(value: boolean | cdktn.IResolvable);
    resetCaptureReturn(): void;
    get captureReturnInput(): boolean | cdktn.IResolvable | undefined;
    private _captureStackTrace?;
    get captureStackTrace(): boolean | cdktn.IResolvable;
    set captureStackTrace(value: boolean | cdktn.IResolvable);
    resetCaptureStackTrace(): void;
    get captureStackTraceInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApplicationsignalsInstrumentationConfigCaptureConfiguration {
    /**
    * Defines what data to capture for code-level instrumentation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#code_capture ApplicationsignalsInstrumentationConfig#code_capture}
    */
    readonly codeCapture: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCapture;
}
export declare function applicationsignalsInstrumentationConfigCaptureConfigurationToTerraform(struct?: ApplicationsignalsInstrumentationConfigCaptureConfiguration | cdktn.IResolvable): any;
export declare function applicationsignalsInstrumentationConfigCaptureConfigurationToHclTerraform(struct?: ApplicationsignalsInstrumentationConfigCaptureConfiguration | cdktn.IResolvable): any;
export declare class ApplicationsignalsInstrumentationConfigCaptureConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsInstrumentationConfigCaptureConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsInstrumentationConfigCaptureConfiguration | cdktn.IResolvable | undefined);
    private _codeCapture;
    get codeCapture(): ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCaptureOutputReference;
    putCodeCapture(value: ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCapture): void;
    get codeCaptureInput(): cdktn.IResolvable | ApplicationsignalsInstrumentationConfigCaptureConfigurationCodeCapture | undefined;
}
export interface ApplicationsignalsInstrumentationConfigLocationCodeLocation {
    /**
    * The class or type name that contains the method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#class_name ApplicationsignalsInstrumentationConfig#class_name}
    */
    readonly className?: string;
    /**
    * The package, module, or namespace that contains the target code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#code_unit ApplicationsignalsInstrumentationConfig#code_unit}
    */
    readonly codeUnit?: string;
    /**
    * The source file path relative to the project or source root.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#file_path ApplicationsignalsInstrumentationConfig#file_path}
    */
    readonly filePath: string;
    /**
    * The programming language for this instrumentation point.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#language ApplicationsignalsInstrumentationConfig#language}
    */
    readonly language: string;
    /**
    * The line number to instrument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#line_number ApplicationsignalsInstrumentationConfig#line_number}
    */
    readonly lineNumber?: number;
    /**
    * The method or function name to instrument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#method_name ApplicationsignalsInstrumentationConfig#method_name}
    */
    readonly methodName?: string;
}
export declare function applicationsignalsInstrumentationConfigLocationCodeLocationToTerraform(struct?: ApplicationsignalsInstrumentationConfigLocationCodeLocation | cdktn.IResolvable): any;
export declare function applicationsignalsInstrumentationConfigLocationCodeLocationToHclTerraform(struct?: ApplicationsignalsInstrumentationConfigLocationCodeLocation | cdktn.IResolvable): any;
export declare class ApplicationsignalsInstrumentationConfigLocationCodeLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsInstrumentationConfigLocationCodeLocation | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsInstrumentationConfigLocationCodeLocation | cdktn.IResolvable | undefined);
    private _className?;
    get className(): string;
    set className(value: string);
    resetClassName(): void;
    get classNameInput(): string | undefined;
    private _codeUnit?;
    get codeUnit(): string;
    set codeUnit(value: string);
    resetCodeUnit(): void;
    get codeUnitInput(): string | undefined;
    private _filePath?;
    get filePath(): string;
    set filePath(value: string);
    get filePathInput(): string | undefined;
    private _language?;
    get language(): string;
    set language(value: string);
    get languageInput(): string | undefined;
    private _lineNumber?;
    get lineNumber(): number;
    set lineNumber(value: number);
    resetLineNumber(): void;
    get lineNumberInput(): number | undefined;
    private _methodName?;
    get methodName(): string;
    set methodName(value: string);
    resetMethodName(): void;
    get methodNameInput(): string | undefined;
}
export interface ApplicationsignalsInstrumentationConfigLocation {
    /**
    * Identifies a code location to instrument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#code_location ApplicationsignalsInstrumentationConfig#code_location}
    */
    readonly codeLocation: ApplicationsignalsInstrumentationConfigLocationCodeLocation;
}
export declare function applicationsignalsInstrumentationConfigLocationToTerraform(struct?: ApplicationsignalsInstrumentationConfigLocation | cdktn.IResolvable): any;
export declare function applicationsignalsInstrumentationConfigLocationToHclTerraform(struct?: ApplicationsignalsInstrumentationConfigLocation | cdktn.IResolvable): any;
export declare class ApplicationsignalsInstrumentationConfigLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationsignalsInstrumentationConfigLocation | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsInstrumentationConfigLocation | cdktn.IResolvable | undefined);
    private _codeLocation;
    get codeLocation(): ApplicationsignalsInstrumentationConfigLocationCodeLocationOutputReference;
    putCodeLocation(value: ApplicationsignalsInstrumentationConfigLocationCodeLocation): void;
    get codeLocationInput(): cdktn.IResolvable | ApplicationsignalsInstrumentationConfigLocationCodeLocation | undefined;
}
export interface ApplicationsignalsInstrumentationConfigTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#key ApplicationsignalsInstrumentationConfig#key}
    */
    readonly key?: string;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#value ApplicationsignalsInstrumentationConfig#value}
    */
    readonly value?: string;
}
export declare function applicationsignalsInstrumentationConfigTagsToTerraform(struct?: ApplicationsignalsInstrumentationConfigTags | cdktn.IResolvable): any;
export declare function applicationsignalsInstrumentationConfigTagsToHclTerraform(struct?: ApplicationsignalsInstrumentationConfigTags | cdktn.IResolvable): any;
export declare class ApplicationsignalsInstrumentationConfigTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationsignalsInstrumentationConfigTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationsignalsInstrumentationConfigTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApplicationsignalsInstrumentationConfigTagsList extends cdktn.ComplexList {
    internalValue?: ApplicationsignalsInstrumentationConfigTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationsignalsInstrumentationConfigTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config awscc_applicationsignals_instrumentation_config}
*/
export declare class ApplicationsignalsInstrumentationConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_applicationsignals_instrumentation_config";
    /**
    * Generates CDKTN code for importing a ApplicationsignalsInstrumentationConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationsignalsInstrumentationConfig to import
    * @param importFromId The id of the existing ApplicationsignalsInstrumentationConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationsignalsInstrumentationConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/applicationsignals_instrumentation_config awscc_applicationsignals_instrumentation_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationsignalsInstrumentationConfigConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationsignalsInstrumentationConfigConfig);
    get arn(): string;
    private _attributeFilters?;
    get attributeFilters(): {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    set attributeFilters(value: {
        [key: string]: string;
    }[] | cdktn.IResolvable);
    resetAttributeFilters(): void;
    get attributeFiltersInput(): cdktn.IResolvable | {
        [key: string]: string;
    }[] | undefined;
    private _captureConfiguration;
    get captureConfiguration(): ApplicationsignalsInstrumentationConfigCaptureConfigurationOutputReference;
    putCaptureConfiguration(value: ApplicationsignalsInstrumentationConfigCaptureConfiguration): void;
    get captureConfigurationInput(): cdktn.IResolvable | ApplicationsignalsInstrumentationConfigCaptureConfiguration | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _expiresAt?;
    get expiresAt(): string;
    set expiresAt(value: string);
    resetExpiresAt(): void;
    get expiresAtInput(): string | undefined;
    get id(): string;
    private _instrumentationType?;
    get instrumentationType(): string;
    set instrumentationType(value: string);
    get instrumentationTypeInput(): string | undefined;
    private _location;
    get location(): ApplicationsignalsInstrumentationConfigLocationOutputReference;
    putLocation(value: ApplicationsignalsInstrumentationConfigLocation): void;
    get locationInput(): cdktn.IResolvable | ApplicationsignalsInstrumentationConfigLocation | undefined;
    get locationHash(): string;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _signalType?;
    get signalType(): string;
    set signalType(value: string);
    get signalTypeInput(): string | undefined;
    private _tags;
    get tags(): ApplicationsignalsInstrumentationConfigTagsList;
    putTags(value: ApplicationsignalsInstrumentationConfigTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApplicationsignalsInstrumentationConfigTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
