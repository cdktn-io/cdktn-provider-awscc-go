/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectContactFlowModuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The content of the contact flow module in JSON format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#content ConnectContactFlowModule#content}
    */
    readonly content: string;
    /**
    * The description of the contact flow module.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#description ConnectContactFlowModule#description}
    */
    readonly description?: string;
    /**
    * Defines the external invocation configuration of the flow module resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#external_invocation_configuration ConnectContactFlowModule#external_invocation_configuration}
    */
    readonly externalInvocationConfiguration?: ConnectContactFlowModuleExternalInvocationConfiguration;
    /**
    * The identifier of the Amazon Connect instance (ARN).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#instance_arn ConnectContactFlowModule#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The name of the contact flow module.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#name ConnectContactFlowModule#name}
    */
    readonly name: string;
    /**
    * The schema of the settings for contact flow module in JSON Schema V4 format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#settings ConnectContactFlowModule#settings}
    */
    readonly settings?: string;
    /**
    * The state of the contact flow module.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#state ConnectContactFlowModule#state}
    */
    readonly state?: string;
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#tags ConnectContactFlowModule#tags}
    */
    readonly tags?: ConnectContactFlowModuleTags[] | cdktn.IResolvable;
}
export interface ConnectContactFlowModuleExternalInvocationConfiguration {
    /**
    * Specifies whether the flow module resource is enabled for external invocation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#enabled ConnectContactFlowModule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function connectContactFlowModuleExternalInvocationConfigurationToTerraform(struct?: ConnectContactFlowModuleExternalInvocationConfiguration | cdktn.IResolvable): any;
export declare function connectContactFlowModuleExternalInvocationConfigurationToHclTerraform(struct?: ConnectContactFlowModuleExternalInvocationConfiguration | cdktn.IResolvable): any;
export declare class ConnectContactFlowModuleExternalInvocationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectContactFlowModuleExternalInvocationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectContactFlowModuleExternalInvocationConfiguration | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ConnectContactFlowModuleTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#key ConnectContactFlowModule#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#value ConnectContactFlowModule#value}
    */
    readonly value?: string;
}
export declare function connectContactFlowModuleTagsToTerraform(struct?: ConnectContactFlowModuleTags | cdktn.IResolvable): any;
export declare function connectContactFlowModuleTagsToHclTerraform(struct?: ConnectContactFlowModuleTags | cdktn.IResolvable): any;
export declare class ConnectContactFlowModuleTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectContactFlowModuleTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectContactFlowModuleTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectContactFlowModuleTagsList extends cdktn.ComplexList {
    internalValue?: ConnectContactFlowModuleTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectContactFlowModuleTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module awscc_connect_contact_flow_module}
*/
export declare class ConnectContactFlowModule extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_contact_flow_module";
    /**
    * Generates CDKTN code for importing a ConnectContactFlowModule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectContactFlowModule to import
    * @param importFromId The id of the existing ConnectContactFlowModule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectContactFlowModule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_contact_flow_module awscc_connect_contact_flow_module} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectContactFlowModuleConfig
    */
    constructor(scope: Construct, id: string, config: ConnectContactFlowModuleConfig);
    get contactFlowModuleArn(): string;
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _externalInvocationConfiguration;
    get externalInvocationConfiguration(): ConnectContactFlowModuleExternalInvocationConfigurationOutputReference;
    putExternalInvocationConfiguration(value: ConnectContactFlowModuleExternalInvocationConfiguration): void;
    resetExternalInvocationConfiguration(): void;
    get externalInvocationConfigurationInput(): cdktn.IResolvable | ConnectContactFlowModuleExternalInvocationConfiguration | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _settings?;
    get settings(): string;
    set settings(value: string);
    resetSettings(): void;
    get settingsInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): ConnectContactFlowModuleTagsList;
    putTags(value: ConnectContactFlowModuleTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectContactFlowModuleTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
