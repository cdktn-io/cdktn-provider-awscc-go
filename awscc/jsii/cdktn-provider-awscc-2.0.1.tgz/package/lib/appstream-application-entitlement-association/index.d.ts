/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppstreamApplicationEntitlementAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_application_entitlement_association#application_identifier AppstreamApplicationEntitlementAssociation#application_identifier}
    */
    readonly applicationIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_application_entitlement_association#entitlement_name AppstreamApplicationEntitlementAssociation#entitlement_name}
    */
    readonly entitlementName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_application_entitlement_association#stack_name AppstreamApplicationEntitlementAssociation#stack_name}
    */
    readonly stackName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_application_entitlement_association awscc_appstream_application_entitlement_association}
*/
export declare class AppstreamApplicationEntitlementAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_appstream_application_entitlement_association";
    /**
    * Generates CDKTN code for importing a AppstreamApplicationEntitlementAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppstreamApplicationEntitlementAssociation to import
    * @param importFromId The id of the existing AppstreamApplicationEntitlementAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_application_entitlement_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppstreamApplicationEntitlementAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/appstream_application_entitlement_association awscc_appstream_application_entitlement_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppstreamApplicationEntitlementAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AppstreamApplicationEntitlementAssociationConfig);
    private _applicationIdentifier?;
    get applicationIdentifier(): string;
    set applicationIdentifier(value: string);
    get applicationIdentifierInput(): string | undefined;
    private _entitlementName?;
    get entitlementName(): string;
    set entitlementName(value: string);
    get entitlementNameInput(): string | undefined;
    get id(): string;
    private _stackName?;
    get stackName(): string;
    set stackName(value: string);
    get stackNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
