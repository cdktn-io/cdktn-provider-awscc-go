/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudhsmClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * A policy that defines how the service retains backups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#backup_retention_policy CloudhsmCluster#backup_retention_policy}
    */
    readonly backupRetentionPolicy?: CloudhsmClusterBackupRetentionPolicy;
    /**
    * The type of HSM to use in the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#hsm_type CloudhsmCluster#hsm_type}
    */
    readonly hsmType: string;
    /**
    * The mode to use in the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#mode CloudhsmCluster#mode}
    */
    readonly mode?: string;
    /**
    * The NetworkType to create a cluster with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#network_type CloudhsmCluster#network_type}
    */
    readonly networkType?: string;
    /**
    * The identifiers (IDs) of the subnets where the cluster is created. You must specify at least one subnet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#subnet_ids CloudhsmCluster#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Tags to apply to the CloudHSM cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#tags CloudhsmCluster#tags}
    */
    readonly tags?: CloudhsmClusterTags[] | cdktn.IResolvable;
}
export interface CloudhsmClusterBackupRetentionPolicy {
    /**
    * The type of backup retention policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#type CloudhsmCluster#type}
    */
    readonly type?: string;
    /**
    * Use a value between 7 - 379.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#value CloudhsmCluster#value}
    */
    readonly value?: string;
}
export declare function cloudhsmClusterBackupRetentionPolicyToTerraform(struct?: CloudhsmClusterBackupRetentionPolicy | cdktn.IResolvable): any;
export declare function cloudhsmClusterBackupRetentionPolicyToHclTerraform(struct?: CloudhsmClusterBackupRetentionPolicy | cdktn.IResolvable): any;
export declare class CloudhsmClusterBackupRetentionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudhsmClusterBackupRetentionPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: CloudhsmClusterBackupRetentionPolicy | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface CloudhsmClusterTags {
    /**
    * The key of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#key CloudhsmCluster#key}
    */
    readonly key?: string;
    /**
    * The value of the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#value CloudhsmCluster#value}
    */
    readonly value?: string;
}
export declare function cloudhsmClusterTagsToTerraform(struct?: CloudhsmClusterTags | cdktn.IResolvable): any;
export declare function cloudhsmClusterTagsToHclTerraform(struct?: CloudhsmClusterTags | cdktn.IResolvable): any;
export declare class CloudhsmClusterTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudhsmClusterTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudhsmClusterTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudhsmClusterTagsList extends cdktn.ComplexList {
    internalValue?: CloudhsmClusterTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudhsmClusterTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster awscc_cloudhsm_cluster}
*/
export declare class CloudhsmCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudhsm_cluster";
    /**
    * Generates CDKTN code for importing a CloudhsmCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudhsmCluster to import
    * @param importFromId The id of the existing CloudhsmCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudhsmCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudhsm_cluster awscc_cloudhsm_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudhsmClusterConfig
    */
    constructor(scope: Construct, id: string, config: CloudhsmClusterConfig);
    get arn(): string;
    get backupPolicy(): string;
    private _backupRetentionPolicy;
    get backupRetentionPolicy(): CloudhsmClusterBackupRetentionPolicyOutputReference;
    putBackupRetentionPolicy(value: CloudhsmClusterBackupRetentionPolicy): void;
    resetBackupRetentionPolicy(): void;
    get backupRetentionPolicyInput(): cdktn.IResolvable | CloudhsmClusterBackupRetentionPolicy | undefined;
    get clusterId(): string;
    private _hsmType?;
    get hsmType(): string;
    set hsmType(value: string);
    get hsmTypeInput(): string | undefined;
    get id(): string;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    get securityGroup(): string;
    get state(): string;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _subnetMapping;
    get subnetMapping(): cdktn.StringMap;
    private _tags;
    get tags(): CloudhsmClusterTagsList;
    putTags(value: CloudhsmClusterTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudhsmClusterTags[] | undefined;
    get vpcId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
