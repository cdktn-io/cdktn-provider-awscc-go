/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoUserPoolRegionalConfigurationAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#email_configuration CognitoUserPoolRegionalConfigurationAttachment#email_configuration}
    */
    readonly emailConfiguration?: CognitoUserPoolRegionalConfigurationAttachmentEmailConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_config CognitoUserPoolRegionalConfigurationAttachment#lambda_config}
    */
    readonly lambdaConfig?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#sms_configuration CognitoUserPoolRegionalConfigurationAttachment#sms_configuration}
    */
    readonly smsConfiguration?: CognitoUserPoolRegionalConfigurationAttachmentSmsConfiguration;
    /**
    * The status of the replica. Set to ACTIVE or INACTIVE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#status CognitoUserPoolRegionalConfigurationAttachment#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#user_pool_id CognitoUserPoolRegionalConfigurationAttachment#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#user_pool_tags CognitoUserPoolRegionalConfigurationAttachment#user_pool_tags}
    */
    readonly userPoolTags?: {
        [key: string]: string;
    };
}
export interface CognitoUserPoolRegionalConfigurationAttachmentEmailConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#configuration_set CognitoUserPoolRegionalConfigurationAttachment#configuration_set}
    */
    readonly configurationSet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#email_sending_account CognitoUserPoolRegionalConfigurationAttachment#email_sending_account}
    */
    readonly emailSendingAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#from CognitoUserPoolRegionalConfigurationAttachment#from}
    */
    readonly from?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#reply_to_email_address CognitoUserPoolRegionalConfigurationAttachment#reply_to_email_address}
    */
    readonly replyToEmailAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#source_arn CognitoUserPoolRegionalConfigurationAttachment#source_arn}
    */
    readonly sourceArn?: string;
}
export declare function cognitoUserPoolRegionalConfigurationAttachmentEmailConfigurationToTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentEmailConfiguration | cdktn.IResolvable): any;
export declare function cognitoUserPoolRegionalConfigurationAttachmentEmailConfigurationToHclTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentEmailConfiguration | cdktn.IResolvable): any;
export declare class CognitoUserPoolRegionalConfigurationAttachmentEmailConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRegionalConfigurationAttachmentEmailConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRegionalConfigurationAttachmentEmailConfiguration | cdktn.IResolvable | undefined);
    private _configurationSet?;
    get configurationSet(): string;
    set configurationSet(value: string);
    resetConfigurationSet(): void;
    get configurationSetInput(): string | undefined;
    private _emailSendingAccount?;
    get emailSendingAccount(): string;
    set emailSendingAccount(value: string);
    resetEmailSendingAccount(): void;
    get emailSendingAccountInput(): string | undefined;
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _replyToEmailAddress?;
    get replyToEmailAddress(): string;
    set replyToEmailAddress(value: string);
    resetReplyToEmailAddress(): void;
    get replyToEmailAddressInput(): string | undefined;
    private _sourceArn?;
    get sourceArn(): string;
    set sourceArn(value: string);
    resetSourceArn(): void;
    get sourceArnInput(): string | undefined;
}
export interface CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSender {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_arn CognitoUserPoolRegionalConfigurationAttachment#lambda_arn}
    */
    readonly lambdaArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_version CognitoUserPoolRegionalConfigurationAttachment#lambda_version}
    */
    readonly lambdaVersion?: string;
}
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSenderToTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSender | cdktn.IResolvable): any;
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSenderToHclTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSender | cdktn.IResolvable): any;
export declare class CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSenderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSender | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSender | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    resetLambdaArn(): void;
    get lambdaArnInput(): string | undefined;
    private _lambdaVersion?;
    get lambdaVersion(): string;
    set lambdaVersion(value: string);
    resetLambdaVersion(): void;
    get lambdaVersionInput(): string | undefined;
}
export interface CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSender {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_arn CognitoUserPoolRegionalConfigurationAttachment#lambda_arn}
    */
    readonly lambdaArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_version CognitoUserPoolRegionalConfigurationAttachment#lambda_version}
    */
    readonly lambdaVersion?: string;
}
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSenderToTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSender | cdktn.IResolvable): any;
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSenderToHclTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSender | cdktn.IResolvable): any;
export declare class CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSenderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSender | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSender | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    resetLambdaArn(): void;
    get lambdaArnInput(): string | undefined;
    private _lambdaVersion?;
    get lambdaVersion(): string;
    set lambdaVersion(value: string);
    resetLambdaVersion(): void;
    get lambdaVersionInput(): string | undefined;
}
export interface CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_arn CognitoUserPoolRegionalConfigurationAttachment#lambda_arn}
    */
    readonly lambdaArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_version CognitoUserPoolRegionalConfigurationAttachment#lambda_version}
    */
    readonly lambdaVersion?: string;
}
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederationToTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederation | cdktn.IResolvable): any;
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederationToHclTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederation | cdktn.IResolvable): any;
export declare class CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederation | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederation | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    resetLambdaArn(): void;
    get lambdaArnInput(): string | undefined;
    private _lambdaVersion?;
    get lambdaVersion(): string;
    set lambdaVersion(value: string);
    resetLambdaVersion(): void;
    get lambdaVersionInput(): string | undefined;
}
export interface CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_arn CognitoUserPoolRegionalConfigurationAttachment#lambda_arn}
    */
    readonly lambdaArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#lambda_version CognitoUserPoolRegionalConfigurationAttachment#lambda_version}
    */
    readonly lambdaVersion?: string;
}
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfigToTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfig | cdktn.IResolvable): any;
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfigToHclTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfig | cdktn.IResolvable): any;
export declare class CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfig | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    resetLambdaArn(): void;
    get lambdaArnInput(): string | undefined;
    private _lambdaVersion?;
    get lambdaVersion(): string;
    set lambdaVersion(value: string);
    resetLambdaVersion(): void;
    get lambdaVersionInput(): string | undefined;
}
export interface CognitoUserPoolRegionalConfigurationAttachmentLambdaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#create_auth_challenge CognitoUserPoolRegionalConfigurationAttachment#create_auth_challenge}
    */
    readonly createAuthChallenge?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#custom_email_sender CognitoUserPoolRegionalConfigurationAttachment#custom_email_sender}
    */
    readonly customEmailSender?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSender;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#custom_message CognitoUserPoolRegionalConfigurationAttachment#custom_message}
    */
    readonly customMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#custom_sms_sender CognitoUserPoolRegionalConfigurationAttachment#custom_sms_sender}
    */
    readonly customSmsSender?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSender;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#define_auth_challenge CognitoUserPoolRegionalConfigurationAttachment#define_auth_challenge}
    */
    readonly defineAuthChallenge?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#inbound_federation CognitoUserPoolRegionalConfigurationAttachment#inbound_federation}
    */
    readonly inboundFederation?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#kms_key_id CognitoUserPoolRegionalConfigurationAttachment#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#post_authentication CognitoUserPoolRegionalConfigurationAttachment#post_authentication}
    */
    readonly postAuthentication?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#post_confirmation CognitoUserPoolRegionalConfigurationAttachment#post_confirmation}
    */
    readonly postConfirmation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#pre_authentication CognitoUserPoolRegionalConfigurationAttachment#pre_authentication}
    */
    readonly preAuthentication?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#pre_sign_up CognitoUserPoolRegionalConfigurationAttachment#pre_sign_up}
    */
    readonly preSignUp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#pre_token_generation CognitoUserPoolRegionalConfigurationAttachment#pre_token_generation}
    */
    readonly preTokenGeneration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#pre_token_generation_config CognitoUserPoolRegionalConfigurationAttachment#pre_token_generation_config}
    */
    readonly preTokenGenerationConfig?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#user_migration CognitoUserPoolRegionalConfigurationAttachment#user_migration}
    */
    readonly userMigration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#verify_auth_challenge_response CognitoUserPoolRegionalConfigurationAttachment#verify_auth_challenge_response}
    */
    readonly verifyAuthChallengeResponse?: string;
}
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigToTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfig | cdktn.IResolvable): any;
export declare function cognitoUserPoolRegionalConfigurationAttachmentLambdaConfigToHclTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfig | cdktn.IResolvable): any;
export declare class CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfig | cdktn.IResolvable | undefined);
    private _createAuthChallenge?;
    get createAuthChallenge(): string;
    set createAuthChallenge(value: string);
    resetCreateAuthChallenge(): void;
    get createAuthChallengeInput(): string | undefined;
    private _customEmailSender;
    get customEmailSender(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSenderOutputReference;
    putCustomEmailSender(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSender): void;
    resetCustomEmailSender(): void;
    get customEmailSenderInput(): cdktn.IResolvable | CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomEmailSender | undefined;
    private _customMessage?;
    get customMessage(): string;
    set customMessage(value: string);
    resetCustomMessage(): void;
    get customMessageInput(): string | undefined;
    private _customSmsSender;
    get customSmsSender(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSenderOutputReference;
    putCustomSmsSender(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSender): void;
    resetCustomSmsSender(): void;
    get customSmsSenderInput(): cdktn.IResolvable | CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigCustomSmsSender | undefined;
    private _defineAuthChallenge?;
    get defineAuthChallenge(): string;
    set defineAuthChallenge(value: string);
    resetDefineAuthChallenge(): void;
    get defineAuthChallengeInput(): string | undefined;
    private _inboundFederation;
    get inboundFederation(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederationOutputReference;
    putInboundFederation(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederation): void;
    resetInboundFederation(): void;
    get inboundFederationInput(): cdktn.IResolvable | CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigInboundFederation | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _postAuthentication?;
    get postAuthentication(): string;
    set postAuthentication(value: string);
    resetPostAuthentication(): void;
    get postAuthenticationInput(): string | undefined;
    private _postConfirmation?;
    get postConfirmation(): string;
    set postConfirmation(value: string);
    resetPostConfirmation(): void;
    get postConfirmationInput(): string | undefined;
    private _preAuthentication?;
    get preAuthentication(): string;
    set preAuthentication(value: string);
    resetPreAuthentication(): void;
    get preAuthenticationInput(): string | undefined;
    private _preSignUp?;
    get preSignUp(): string;
    set preSignUp(value: string);
    resetPreSignUp(): void;
    get preSignUpInput(): string | undefined;
    private _preTokenGeneration?;
    get preTokenGeneration(): string;
    set preTokenGeneration(value: string);
    resetPreTokenGeneration(): void;
    get preTokenGenerationInput(): string | undefined;
    private _preTokenGenerationConfig;
    get preTokenGenerationConfig(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfigOutputReference;
    putPreTokenGenerationConfig(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfig): void;
    resetPreTokenGenerationConfig(): void;
    get preTokenGenerationConfigInput(): cdktn.IResolvable | CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigPreTokenGenerationConfig | undefined;
    private _userMigration?;
    get userMigration(): string;
    set userMigration(value: string);
    resetUserMigration(): void;
    get userMigrationInput(): string | undefined;
    private _verifyAuthChallengeResponse?;
    get verifyAuthChallengeResponse(): string;
    set verifyAuthChallengeResponse(value: string);
    resetVerifyAuthChallengeResponse(): void;
    get verifyAuthChallengeResponseInput(): string | undefined;
}
export interface CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSms {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#caller_arn CognitoUserPoolRegionalConfigurationAttachment#caller_arn}
    */
    readonly callerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#configuration_set_name CognitoUserPoolRegionalConfigurationAttachment#configuration_set_name}
    */
    readonly configurationSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#external_id CognitoUserPoolRegionalConfigurationAttachment#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#in_entity_id CognitoUserPoolRegionalConfigurationAttachment#in_entity_id}
    */
    readonly inEntityId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#in_template_id CognitoUserPoolRegionalConfigurationAttachment#in_template_id}
    */
    readonly inTemplateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#origination_identity CognitoUserPoolRegionalConfigurationAttachment#origination_identity}
    */
    readonly originationIdentity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#region CognitoUserPoolRegionalConfigurationAttachment#region}
    */
    readonly region?: string;
}
export declare function cognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSmsToTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSms | cdktn.IResolvable): any;
export declare function cognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSmsToHclTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSms | cdktn.IResolvable): any;
export declare class CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSms | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSms | cdktn.IResolvable | undefined);
    private _callerArn?;
    get callerArn(): string;
    set callerArn(value: string);
    resetCallerArn(): void;
    get callerArnInput(): string | undefined;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    resetConfigurationSetName(): void;
    get configurationSetNameInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _inEntityId?;
    get inEntityId(): string;
    set inEntityId(value: string);
    resetInEntityId(): void;
    get inEntityIdInput(): string | undefined;
    private _inTemplateId?;
    get inTemplateId(): string;
    set inTemplateId(value: string);
    resetInTemplateId(): void;
    get inTemplateIdInput(): string | undefined;
    private _originationIdentity?;
    get originationIdentity(): string;
    set originationIdentity(value: string);
    resetOriginationIdentity(): void;
    get originationIdentityInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface CognitoUserPoolRegionalConfigurationAttachmentSmsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#eums_sms CognitoUserPoolRegionalConfigurationAttachment#eums_sms}
    */
    readonly eumsSms?: CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSms;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#external_id CognitoUserPoolRegionalConfigurationAttachment#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#sns_caller_arn CognitoUserPoolRegionalConfigurationAttachment#sns_caller_arn}
    */
    readonly snsCallerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#sns_region CognitoUserPoolRegionalConfigurationAttachment#sns_region}
    */
    readonly snsRegion?: string;
}
export declare function cognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationToTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentSmsConfiguration | cdktn.IResolvable): any;
export declare function cognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationToHclTerraform(struct?: CognitoUserPoolRegionalConfigurationAttachmentSmsConfiguration | cdktn.IResolvable): any;
export declare class CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CognitoUserPoolRegionalConfigurationAttachmentSmsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoUserPoolRegionalConfigurationAttachmentSmsConfiguration | cdktn.IResolvable | undefined);
    private _eumsSms;
    get eumsSms(): CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSmsOutputReference;
    putEumsSms(value: CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSms): void;
    resetEumsSms(): void;
    get eumsSmsInput(): cdktn.IResolvable | CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationEumsSms | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _snsCallerArn?;
    get snsCallerArn(): string;
    set snsCallerArn(value: string);
    resetSnsCallerArn(): void;
    get snsCallerArnInput(): string | undefined;
    private _snsRegion?;
    get snsRegion(): string;
    set snsRegion(value: string);
    resetSnsRegion(): void;
    get snsRegionInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment awscc_cognito_user_pool_regional_configuration_attachment}
*/
export declare class CognitoUserPoolRegionalConfigurationAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cognito_user_pool_regional_configuration_attachment";
    /**
    * Generates CDKTN code for importing a CognitoUserPoolRegionalConfigurationAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoUserPoolRegionalConfigurationAttachment to import
    * @param importFromId The id of the existing CognitoUserPoolRegionalConfigurationAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoUserPoolRegionalConfigurationAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cognito_user_pool_regional_configuration_attachment awscc_cognito_user_pool_regional_configuration_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoUserPoolRegionalConfigurationAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: CognitoUserPoolRegionalConfigurationAttachmentConfig);
    private _emailConfiguration;
    get emailConfiguration(): CognitoUserPoolRegionalConfigurationAttachmentEmailConfigurationOutputReference;
    putEmailConfiguration(value: CognitoUserPoolRegionalConfigurationAttachmentEmailConfiguration): void;
    resetEmailConfiguration(): void;
    get emailConfigurationInput(): cdktn.IResolvable | CognitoUserPoolRegionalConfigurationAttachmentEmailConfiguration | undefined;
    get id(): string;
    private _lambdaConfig;
    get lambdaConfig(): CognitoUserPoolRegionalConfigurationAttachmentLambdaConfigOutputReference;
    putLambdaConfig(value: CognitoUserPoolRegionalConfigurationAttachmentLambdaConfig): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): cdktn.IResolvable | CognitoUserPoolRegionalConfigurationAttachmentLambdaConfig | undefined;
    private _smsConfiguration;
    get smsConfiguration(): CognitoUserPoolRegionalConfigurationAttachmentSmsConfigurationOutputReference;
    putSmsConfiguration(value: CognitoUserPoolRegionalConfigurationAttachmentSmsConfiguration): void;
    resetSmsConfiguration(): void;
    get smsConfigurationInput(): cdktn.IResolvable | CognitoUserPoolRegionalConfigurationAttachmentSmsConfiguration | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _userPoolTags?;
    get userPoolTags(): {
        [key: string]: string;
    };
    set userPoolTags(value: {
        [key: string]: string;
    });
    resetUserPoolTags(): void;
    get userPoolTagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
