/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreCodeInterpreterCustomConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of root CA certificates in PEM format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#certificates BedrockagentcoreCodeInterpreterCustom#certificates}
    */
    readonly certificates?: BedrockagentcoreCodeInterpreterCustomCertificates[] | cdktn.IResolvable;
    /**
    * The description of the code interpreter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#description BedrockagentcoreCodeInterpreterCustom#description}
    */
    readonly description?: string;
    /**
    * The ARN of the IAM role that the code interpreter uses to access resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#execution_role_arn BedrockagentcoreCodeInterpreterCustom#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * The name of the code interpreter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#name BedrockagentcoreCodeInterpreterCustom#name}
    */
    readonly name: string;
    /**
    * Network configuration for code interpreter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#network_configuration BedrockagentcoreCodeInterpreterCustom#network_configuration}
    */
    readonly networkConfiguration: BedrockagentcoreCodeInterpreterCustomNetworkConfiguration;
    /**
    * A map of tag keys and values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#tags BedrockagentcoreCodeInterpreterCustom#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocation {
    /**
    * Secrets Manager secret ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#secret_arn BedrockagentcoreCodeInterpreterCustom#secret_arn}
    */
    readonly secretArn?: string;
}
export declare function bedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocationToTerraform(struct?: BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocation | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocationToHclTerraform(struct?: BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocation | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocation | cdktn.IResolvable | undefined);
    private _secretArn?;
    get secretArn(): string;
    set secretArn(value: string);
    resetSecretArn(): void;
    get secretArnInput(): string | undefined;
}
export interface BedrockagentcoreCodeInterpreterCustomCertificates {
    /**
    * Certificate location in Secrets Manager.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#certificate_location BedrockagentcoreCodeInterpreterCustom#certificate_location}
    */
    readonly certificateLocation?: BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocation;
}
export declare function bedrockagentcoreCodeInterpreterCustomCertificatesToTerraform(struct?: BedrockagentcoreCodeInterpreterCustomCertificates | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterCustomCertificatesToHclTerraform(struct?: BedrockagentcoreCodeInterpreterCustomCertificates | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterCustomCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCodeInterpreterCustomCertificates | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterCustomCertificates | cdktn.IResolvable | undefined);
    private _certificateLocation;
    get certificateLocation(): BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocationOutputReference;
    putCertificateLocation(value: BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocation): void;
    resetCertificateLocation(): void;
    get certificateLocationInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterCustomCertificatesCertificateLocation | undefined;
}
export declare class BedrockagentcoreCodeInterpreterCustomCertificatesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCodeInterpreterCustomCertificates[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCodeInterpreterCustomCertificatesOutputReference;
}
export interface BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfig {
    /**
    * Security groups for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#security_groups BedrockagentcoreCodeInterpreterCustom#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Subnets for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#subnets BedrockagentcoreCodeInterpreterCustom#subnets}
    */
    readonly subnets?: string[];
}
export declare function bedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfigToTerraform(struct?: BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfigToHclTerraform(struct?: BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
export interface BedrockagentcoreCodeInterpreterCustomNetworkConfiguration {
    /**
    * Network modes supported by code interpreter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#network_mode BedrockagentcoreCodeInterpreterCustom#network_mode}
    */
    readonly networkMode?: string;
    /**
    * Network mode configuration for VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#vpc_config BedrockagentcoreCodeInterpreterCustom#vpc_config}
    */
    readonly vpcConfig?: BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfig;
}
export declare function bedrockagentcoreCodeInterpreterCustomNetworkConfigurationToTerraform(struct?: BedrockagentcoreCodeInterpreterCustomNetworkConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterCustomNetworkConfigurationToHclTerraform(struct?: BedrockagentcoreCodeInterpreterCustomNetworkConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterCustomNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCodeInterpreterCustomNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterCustomNetworkConfiguration | cdktn.IResolvable | undefined);
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    resetNetworkMode(): void;
    get networkModeInput(): string | undefined;
    private _vpcConfig;
    get vpcConfig(): BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfigOutputReference;
    putVpcConfig(value: BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfig): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterCustomNetworkConfigurationVpcConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom awscc_bedrockagentcore_code_interpreter_custom}
*/
export declare class BedrockagentcoreCodeInterpreterCustom extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_bedrockagentcore_code_interpreter_custom";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreCodeInterpreterCustom resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreCodeInterpreterCustom to import
    * @param importFromId The id of the existing BedrockagentcoreCodeInterpreterCustom that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreCodeInterpreterCustom to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/bedrockagentcore_code_interpreter_custom awscc_bedrockagentcore_code_interpreter_custom} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreCodeInterpreterCustomConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreCodeInterpreterCustomConfig);
    private _certificates;
    get certificates(): BedrockagentcoreCodeInterpreterCustomCertificatesList;
    putCertificates(value: BedrockagentcoreCodeInterpreterCustomCertificates[] | cdktn.IResolvable): void;
    resetCertificates(): void;
    get certificatesInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterCustomCertificates[] | undefined;
    get codeInterpreterArn(): string;
    get codeInterpreterId(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    get failureReason(): string;
    get id(): string;
    get lastUpdatedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BedrockagentcoreCodeInterpreterCustomNetworkConfigurationOutputReference;
    putNetworkConfiguration(value: BedrockagentcoreCodeInterpreterCustomNetworkConfiguration): void;
    get networkConfigurationInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterCustomNetworkConfiguration | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
