/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * After Contact Work configurations of a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#after_contact_work_configs ConnectUser#after_contact_work_configs}
    */
    readonly afterContactWorkConfigs?: ConnectUserAfterContactWorkConfigs[] | cdktn.IResolvable;
    /**
    * Auto-accept configurations of a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#auto_accept_configs ConnectUser#auto_accept_configs}
    */
    readonly autoAcceptConfigs?: ConnectUserAutoAcceptConfigs[] | cdktn.IResolvable;
    /**
    * The identifier of the user account in the directory used for identity management.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#directory_user_id ConnectUser#directory_user_id}
    */
    readonly directoryUserId?: string;
    /**
    * The identifier of the hierarchy group for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#hierarchy_group_arn ConnectUser#hierarchy_group_arn}
    */
    readonly hierarchyGroupArn?: string;
    /**
    * The information about the identity of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#identity_info ConnectUser#identity_info}
    */
    readonly identityInfo?: ConnectUserIdentityInfo;
    /**
    * The identifier of the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#instance_arn ConnectUser#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * The password for the user account. A password is required if you are using Amazon Connect for identity management. Otherwise, it is an error to include a password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#password ConnectUser#password}
    */
    readonly password?: string;
    /**
    * Persistent Connection configurations of a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#persistent_connection_configs ConnectUser#persistent_connection_configs}
    */
    readonly persistentConnectionConfigs?: ConnectUserPersistentConnectionConfigs[] | cdktn.IResolvable;
    /**
    * The phone settings for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#phone_config ConnectUser#phone_config}
    */
    readonly phoneConfig?: ConnectUserPhoneConfig;
    /**
    * Phone Number configurations of a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#phone_number_configs ConnectUser#phone_number_configs}
    */
    readonly phoneNumberConfigs?: ConnectUserPhoneNumberConfigs[] | cdktn.IResolvable;
    /**
    * The identifier of the routing profile for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#routing_profile_arn ConnectUser#routing_profile_arn}
    */
    readonly routingProfileArn: string;
    /**
    * One or more security profile arns for the user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#security_profile_arns ConnectUser#security_profile_arns}
    */
    readonly securityProfileArns: string[];
    /**
    * One or more tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#tags ConnectUser#tags}
    */
    readonly tags?: ConnectUserTags[] | cdktn.IResolvable;
    /**
    * One or more predefined attributes assigned to a user, with a level that indicates how skilled they are.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#user_proficiencies ConnectUser#user_proficiencies}
    */
    readonly userProficiencies?: ConnectUserUserProficiencies[] | cdktn.IResolvable;
    /**
    * The user name for the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#username ConnectUser#username}
    */
    readonly username: string;
    /**
    * Voice Enhancement configurations of a user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#voice_enhancement_configs ConnectUser#voice_enhancement_configs}
    */
    readonly voiceEnhancementConfigs?: ConnectUserVoiceEnhancementConfigs[] | cdktn.IResolvable;
}
export interface ConnectUserAfterContactWorkConfigsAfterContactWorkConfig {
    /**
    * The after contact work (ACW) mode for the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#after_contact_work_mode ConnectUser#after_contact_work_mode}
    */
    readonly afterContactWorkMode?: string;
    /**
    * The After Call Work (ACW) timeout setting, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#after_contact_work_time_limit ConnectUser#after_contact_work_time_limit}
    */
    readonly afterContactWorkTimeLimit?: number;
}
export declare function connectUserAfterContactWorkConfigsAfterContactWorkConfigToTerraform(struct?: ConnectUserAfterContactWorkConfigsAfterContactWorkConfig | cdktn.IResolvable): any;
export declare function connectUserAfterContactWorkConfigsAfterContactWorkConfigToHclTerraform(struct?: ConnectUserAfterContactWorkConfigsAfterContactWorkConfig | cdktn.IResolvable): any;
export declare class ConnectUserAfterContactWorkConfigsAfterContactWorkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserAfterContactWorkConfigsAfterContactWorkConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserAfterContactWorkConfigsAfterContactWorkConfig | cdktn.IResolvable | undefined);
    private _afterContactWorkMode?;
    get afterContactWorkMode(): string;
    set afterContactWorkMode(value: string);
    resetAfterContactWorkMode(): void;
    get afterContactWorkModeInput(): string | undefined;
    private _afterContactWorkTimeLimit?;
    get afterContactWorkTimeLimit(): number;
    set afterContactWorkTimeLimit(value: number);
    resetAfterContactWorkTimeLimit(): void;
    get afterContactWorkTimeLimitInput(): number | undefined;
}
export interface ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfig {
    /**
    * The after contact work (ACW) mode for the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#after_contact_work_mode ConnectUser#after_contact_work_mode}
    */
    readonly afterContactWorkMode?: string;
    /**
    * The After Call Work (ACW) timeout setting, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#after_contact_work_time_limit ConnectUser#after_contact_work_time_limit}
    */
    readonly afterContactWorkTimeLimit?: number;
}
export declare function connectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfigToTerraform(struct?: ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfig | cdktn.IResolvable): any;
export declare function connectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfigToHclTerraform(struct?: ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfig | cdktn.IResolvable): any;
export declare class ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfig | cdktn.IResolvable | undefined);
    private _afterContactWorkMode?;
    get afterContactWorkMode(): string;
    set afterContactWorkMode(value: string);
    resetAfterContactWorkMode(): void;
    get afterContactWorkModeInput(): string | undefined;
    private _afterContactWorkTimeLimit?;
    get afterContactWorkTimeLimit(): number;
    set afterContactWorkTimeLimit(value: number);
    resetAfterContactWorkTimeLimit(): void;
    get afterContactWorkTimeLimitInput(): number | undefined;
}
export interface ConnectUserAfterContactWorkConfigs {
    /**
    * After Contact Work configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#after_contact_work_config ConnectUser#after_contact_work_config}
    */
    readonly afterContactWorkConfig?: ConnectUserAfterContactWorkConfigsAfterContactWorkConfig;
    /**
    * After Contact Work configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#agent_first_callback_after_contact_work_config ConnectUser#agent_first_callback_after_contact_work_config}
    */
    readonly agentFirstCallbackAfterContactWorkConfig?: ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfig;
    /**
    * The channels that agents can handle in the Contact Control Panel (CCP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#channel ConnectUser#channel}
    */
    readonly channel?: string;
}
export declare function connectUserAfterContactWorkConfigsToTerraform(struct?: ConnectUserAfterContactWorkConfigs | cdktn.IResolvable): any;
export declare function connectUserAfterContactWorkConfigsToHclTerraform(struct?: ConnectUserAfterContactWorkConfigs | cdktn.IResolvable): any;
export declare class ConnectUserAfterContactWorkConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUserAfterContactWorkConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserAfterContactWorkConfigs | cdktn.IResolvable | undefined);
    private _afterContactWorkConfig;
    get afterContactWorkConfig(): ConnectUserAfterContactWorkConfigsAfterContactWorkConfigOutputReference;
    putAfterContactWorkConfig(value: ConnectUserAfterContactWorkConfigsAfterContactWorkConfig): void;
    resetAfterContactWorkConfig(): void;
    get afterContactWorkConfigInput(): cdktn.IResolvable | ConnectUserAfterContactWorkConfigsAfterContactWorkConfig | undefined;
    private _agentFirstCallbackAfterContactWorkConfig;
    get agentFirstCallbackAfterContactWorkConfig(): ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfigOutputReference;
    putAgentFirstCallbackAfterContactWorkConfig(value: ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfig): void;
    resetAgentFirstCallbackAfterContactWorkConfig(): void;
    get agentFirstCallbackAfterContactWorkConfigInput(): cdktn.IResolvable | ConnectUserAfterContactWorkConfigsAgentFirstCallbackAfterContactWorkConfig | undefined;
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
}
export declare class ConnectUserAfterContactWorkConfigsList extends cdktn.ComplexList {
    internalValue?: ConnectUserAfterContactWorkConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUserAfterContactWorkConfigsOutputReference;
}
export interface ConnectUserAutoAcceptConfigs {
    /**
    * The agent first callback auto accept setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#agent_first_callback_auto_accept ConnectUser#agent_first_callback_auto_accept}
    */
    readonly agentFirstCallbackAutoAccept?: boolean | cdktn.IResolvable;
    /**
    * The Auto accept setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#auto_accept ConnectUser#auto_accept}
    */
    readonly autoAccept?: boolean | cdktn.IResolvable;
    /**
    * The channels that agents can handle in the Contact Control Panel (CCP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#channel ConnectUser#channel}
    */
    readonly channel?: string;
}
export declare function connectUserAutoAcceptConfigsToTerraform(struct?: ConnectUserAutoAcceptConfigs | cdktn.IResolvable): any;
export declare function connectUserAutoAcceptConfigsToHclTerraform(struct?: ConnectUserAutoAcceptConfigs | cdktn.IResolvable): any;
export declare class ConnectUserAutoAcceptConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUserAutoAcceptConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserAutoAcceptConfigs | cdktn.IResolvable | undefined);
    private _agentFirstCallbackAutoAccept?;
    get agentFirstCallbackAutoAccept(): boolean | cdktn.IResolvable;
    set agentFirstCallbackAutoAccept(value: boolean | cdktn.IResolvable);
    resetAgentFirstCallbackAutoAccept(): void;
    get agentFirstCallbackAutoAcceptInput(): boolean | cdktn.IResolvable | undefined;
    private _autoAccept?;
    get autoAccept(): boolean | cdktn.IResolvable;
    set autoAccept(value: boolean | cdktn.IResolvable);
    resetAutoAccept(): void;
    get autoAcceptInput(): boolean | cdktn.IResolvable | undefined;
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
}
export declare class ConnectUserAutoAcceptConfigsList extends cdktn.ComplexList {
    internalValue?: ConnectUserAutoAcceptConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUserAutoAcceptConfigsOutputReference;
}
export interface ConnectUserIdentityInfo {
    /**
    * The email address. If you are using SAML for identity management and include this parameter, an error is returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#email ConnectUser#email}
    */
    readonly email?: string;
    /**
    * The first name. This is required if you are using Amazon Connect or SAML for identity management.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#first_name ConnectUser#first_name}
    */
    readonly firstName?: string;
    /**
    * The last name. This is required if you are using Amazon Connect or SAML for identity management.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#last_name ConnectUser#last_name}
    */
    readonly lastName?: string;
    /**
    * The mobile phone number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#mobile ConnectUser#mobile}
    */
    readonly mobile?: string;
    /**
    * The secondary email address. If you provide a secondary email, the user receives email notifications -- other than password reset notifications -- to this email address instead of to their primary email address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#secondary_email ConnectUser#secondary_email}
    */
    readonly secondaryEmail?: string;
}
export declare function connectUserIdentityInfoToTerraform(struct?: ConnectUserIdentityInfo | cdktn.IResolvable): any;
export declare function connectUserIdentityInfoToHclTerraform(struct?: ConnectUserIdentityInfo | cdktn.IResolvable): any;
export declare class ConnectUserIdentityInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserIdentityInfo | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserIdentityInfo | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _firstName?;
    get firstName(): string;
    set firstName(value: string);
    resetFirstName(): void;
    get firstNameInput(): string | undefined;
    private _lastName?;
    get lastName(): string;
    set lastName(value: string);
    resetLastName(): void;
    get lastNameInput(): string | undefined;
    private _mobile?;
    get mobile(): string;
    set mobile(value: string);
    resetMobile(): void;
    get mobileInput(): string | undefined;
    private _secondaryEmail?;
    get secondaryEmail(): string;
    set secondaryEmail(value: string);
    resetSecondaryEmail(): void;
    get secondaryEmailInput(): string | undefined;
}
export interface ConnectUserPersistentConnectionConfigs {
    /**
    * The channels that agents can handle in the Contact Control Panel (CCP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#channel ConnectUser#channel}
    */
    readonly channel?: string;
    /**
    * The Persistent Connection setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#persistent_connection ConnectUser#persistent_connection}
    */
    readonly persistentConnection?: boolean | cdktn.IResolvable;
}
export declare function connectUserPersistentConnectionConfigsToTerraform(struct?: ConnectUserPersistentConnectionConfigs | cdktn.IResolvable): any;
export declare function connectUserPersistentConnectionConfigsToHclTerraform(struct?: ConnectUserPersistentConnectionConfigs | cdktn.IResolvable): any;
export declare class ConnectUserPersistentConnectionConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUserPersistentConnectionConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserPersistentConnectionConfigs | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _persistentConnection?;
    get persistentConnection(): boolean | cdktn.IResolvable;
    set persistentConnection(value: boolean | cdktn.IResolvable);
    resetPersistentConnection(): void;
    get persistentConnectionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ConnectUserPersistentConnectionConfigsList extends cdktn.ComplexList {
    internalValue?: ConnectUserPersistentConnectionConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUserPersistentConnectionConfigsOutputReference;
}
export interface ConnectUserPhoneConfig {
    /**
    * The After Call Work (ACW) timeout setting, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#after_contact_work_time_limit ConnectUser#after_contact_work_time_limit}
    */
    readonly afterContactWorkTimeLimit?: number;
    /**
    * The Auto accept setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#auto_accept ConnectUser#auto_accept}
    */
    readonly autoAccept?: boolean | cdktn.IResolvable;
    /**
    * The phone number for the user's desk phone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#desk_phone_number ConnectUser#desk_phone_number}
    */
    readonly deskPhoneNumber?: string;
    /**
    * The Persistent Connection setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#persistent_connection ConnectUser#persistent_connection}
    */
    readonly persistentConnection?: boolean | cdktn.IResolvable;
    /**
    * The phone type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#phone_type ConnectUser#phone_type}
    */
    readonly phoneType?: string;
}
export declare function connectUserPhoneConfigToTerraform(struct?: ConnectUserPhoneConfig | cdktn.IResolvable): any;
export declare function connectUserPhoneConfigToHclTerraform(struct?: ConnectUserPhoneConfig | cdktn.IResolvable): any;
export declare class ConnectUserPhoneConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectUserPhoneConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserPhoneConfig | cdktn.IResolvable | undefined);
    private _afterContactWorkTimeLimit?;
    get afterContactWorkTimeLimit(): number;
    set afterContactWorkTimeLimit(value: number);
    resetAfterContactWorkTimeLimit(): void;
    get afterContactWorkTimeLimitInput(): number | undefined;
    private _autoAccept?;
    get autoAccept(): boolean | cdktn.IResolvable;
    set autoAccept(value: boolean | cdktn.IResolvable);
    resetAutoAccept(): void;
    get autoAcceptInput(): boolean | cdktn.IResolvable | undefined;
    private _deskPhoneNumber?;
    get deskPhoneNumber(): string;
    set deskPhoneNumber(value: string);
    resetDeskPhoneNumber(): void;
    get deskPhoneNumberInput(): string | undefined;
    private _persistentConnection?;
    get persistentConnection(): boolean | cdktn.IResolvable;
    set persistentConnection(value: boolean | cdktn.IResolvable);
    resetPersistentConnection(): void;
    get persistentConnectionInput(): boolean | cdktn.IResolvable | undefined;
    private _phoneType?;
    get phoneType(): string;
    set phoneType(value: string);
    resetPhoneType(): void;
    get phoneTypeInput(): string | undefined;
}
export interface ConnectUserPhoneNumberConfigs {
    /**
    * The channels that agents can handle in the Contact Control Panel (CCP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#channel ConnectUser#channel}
    */
    readonly channel?: string;
    /**
    * The phone number for the user's desk phone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#phone_number ConnectUser#phone_number}
    */
    readonly phoneNumber?: string;
    /**
    * The phone type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#phone_type ConnectUser#phone_type}
    */
    readonly phoneType?: string;
}
export declare function connectUserPhoneNumberConfigsToTerraform(struct?: ConnectUserPhoneNumberConfigs | cdktn.IResolvable): any;
export declare function connectUserPhoneNumberConfigsToHclTerraform(struct?: ConnectUserPhoneNumberConfigs | cdktn.IResolvable): any;
export declare class ConnectUserPhoneNumberConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUserPhoneNumberConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserPhoneNumberConfigs | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    resetPhoneNumber(): void;
    get phoneNumberInput(): string | undefined;
    private _phoneType?;
    get phoneType(): string;
    set phoneType(value: string);
    resetPhoneType(): void;
    get phoneTypeInput(): string | undefined;
}
export declare class ConnectUserPhoneNumberConfigsList extends cdktn.ComplexList {
    internalValue?: ConnectUserPhoneNumberConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUserPhoneNumberConfigsOutputReference;
}
export interface ConnectUserTags {
    /**
    * The key name of the tag. You can specify a value that is 1 to 128 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#key ConnectUser#key}
    */
    readonly key?: string;
    /**
    * The value for the tag. You can specify a value that is maximum of 256 Unicode characters in length and cannot be prefixed with aws:. You can use any of the following characters: the set of Unicode letters, digits, whitespace, _, ., /, =, +, and -.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#value ConnectUser#value}
    */
    readonly value?: string;
}
export declare function connectUserTagsToTerraform(struct?: ConnectUserTags | cdktn.IResolvable): any;
export declare function connectUserTagsToHclTerraform(struct?: ConnectUserTags | cdktn.IResolvable): any;
export declare class ConnectUserTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUserTags | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ConnectUserTagsList extends cdktn.ComplexList {
    internalValue?: ConnectUserTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUserTagsOutputReference;
}
export interface ConnectUserUserProficiencies {
    /**
    * The name of user's proficiency. You must use name of predefined attribute present in the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#attribute_name ConnectUser#attribute_name}
    */
    readonly attributeName?: string;
    /**
    * The value of user's proficiency. You must use value of predefined attribute present in the Amazon Connect instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#attribute_value ConnectUser#attribute_value}
    */
    readonly attributeValue?: string;
    /**
    * The level of the proficiency. The valid values are 0 to 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#level ConnectUser#level}
    */
    readonly level?: number;
}
export declare function connectUserUserProficienciesToTerraform(struct?: ConnectUserUserProficiencies | cdktn.IResolvable): any;
export declare function connectUserUserProficienciesToHclTerraform(struct?: ConnectUserUserProficiencies | cdktn.IResolvable): any;
export declare class ConnectUserUserProficienciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUserUserProficiencies | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserUserProficiencies | cdktn.IResolvable | undefined);
    private _attributeName?;
    get attributeName(): string;
    set attributeName(value: string);
    resetAttributeName(): void;
    get attributeNameInput(): string | undefined;
    private _attributeValue?;
    get attributeValue(): string;
    set attributeValue(value: string);
    resetAttributeValue(): void;
    get attributeValueInput(): string | undefined;
    private _level?;
    get level(): number;
    set level(value: number);
    resetLevel(): void;
    get levelInput(): number | undefined;
}
export declare class ConnectUserUserProficienciesList extends cdktn.ComplexList {
    internalValue?: ConnectUserUserProficiencies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUserUserProficienciesOutputReference;
}
export interface ConnectUserVoiceEnhancementConfigs {
    /**
    * The channels that agents can handle in the Contact Control Panel (CCP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#channel ConnectUser#channel}
    */
    readonly channel?: string;
    /**
    * The Voice Enhancement Mode setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#voice_enhancement_mode ConnectUser#voice_enhancement_mode}
    */
    readonly voiceEnhancementMode?: string;
}
export declare function connectUserVoiceEnhancementConfigsToTerraform(struct?: ConnectUserVoiceEnhancementConfigs | cdktn.IResolvable): any;
export declare function connectUserVoiceEnhancementConfigsToHclTerraform(struct?: ConnectUserVoiceEnhancementConfigs | cdktn.IResolvable): any;
export declare class ConnectUserVoiceEnhancementConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectUserVoiceEnhancementConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectUserVoiceEnhancementConfigs | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _voiceEnhancementMode?;
    get voiceEnhancementMode(): string;
    set voiceEnhancementMode(value: string);
    resetVoiceEnhancementMode(): void;
    get voiceEnhancementModeInput(): string | undefined;
}
export declare class ConnectUserVoiceEnhancementConfigsList extends cdktn.ComplexList {
    internalValue?: ConnectUserVoiceEnhancementConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectUserVoiceEnhancementConfigsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user awscc_connect_user}
*/
export declare class ConnectUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_user";
    /**
    * Generates CDKTN code for importing a ConnectUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectUser to import
    * @param importFromId The id of the existing ConnectUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_user awscc_connect_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectUserConfig
    */
    constructor(scope: Construct, id: string, config: ConnectUserConfig);
    private _afterContactWorkConfigs;
    get afterContactWorkConfigs(): ConnectUserAfterContactWorkConfigsList;
    putAfterContactWorkConfigs(value: ConnectUserAfterContactWorkConfigs[] | cdktn.IResolvable): void;
    resetAfterContactWorkConfigs(): void;
    get afterContactWorkConfigsInput(): cdktn.IResolvable | ConnectUserAfterContactWorkConfigs[] | undefined;
    private _autoAcceptConfigs;
    get autoAcceptConfigs(): ConnectUserAutoAcceptConfigsList;
    putAutoAcceptConfigs(value: ConnectUserAutoAcceptConfigs[] | cdktn.IResolvable): void;
    resetAutoAcceptConfigs(): void;
    get autoAcceptConfigsInput(): cdktn.IResolvable | ConnectUserAutoAcceptConfigs[] | undefined;
    private _directoryUserId?;
    get directoryUserId(): string;
    set directoryUserId(value: string);
    resetDirectoryUserId(): void;
    get directoryUserIdInput(): string | undefined;
    private _hierarchyGroupArn?;
    get hierarchyGroupArn(): string;
    set hierarchyGroupArn(value: string);
    resetHierarchyGroupArn(): void;
    get hierarchyGroupArnInput(): string | undefined;
    get id(): string;
    private _identityInfo;
    get identityInfo(): ConnectUserIdentityInfoOutputReference;
    putIdentityInfo(value: ConnectUserIdentityInfo): void;
    resetIdentityInfo(): void;
    get identityInfoInput(): cdktn.IResolvable | ConnectUserIdentityInfo | undefined;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _persistentConnectionConfigs;
    get persistentConnectionConfigs(): ConnectUserPersistentConnectionConfigsList;
    putPersistentConnectionConfigs(value: ConnectUserPersistentConnectionConfigs[] | cdktn.IResolvable): void;
    resetPersistentConnectionConfigs(): void;
    get persistentConnectionConfigsInput(): cdktn.IResolvable | ConnectUserPersistentConnectionConfigs[] | undefined;
    private _phoneConfig;
    get phoneConfig(): ConnectUserPhoneConfigOutputReference;
    putPhoneConfig(value: ConnectUserPhoneConfig): void;
    resetPhoneConfig(): void;
    get phoneConfigInput(): cdktn.IResolvable | ConnectUserPhoneConfig | undefined;
    private _phoneNumberConfigs;
    get phoneNumberConfigs(): ConnectUserPhoneNumberConfigsList;
    putPhoneNumberConfigs(value: ConnectUserPhoneNumberConfigs[] | cdktn.IResolvable): void;
    resetPhoneNumberConfigs(): void;
    get phoneNumberConfigsInput(): cdktn.IResolvable | ConnectUserPhoneNumberConfigs[] | undefined;
    private _routingProfileArn?;
    get routingProfileArn(): string;
    set routingProfileArn(value: string);
    get routingProfileArnInput(): string | undefined;
    private _securityProfileArns?;
    get securityProfileArns(): string[];
    set securityProfileArns(value: string[]);
    get securityProfileArnsInput(): string[] | undefined;
    private _tags;
    get tags(): ConnectUserTagsList;
    putTags(value: ConnectUserTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ConnectUserTags[] | undefined;
    get userArn(): string;
    private _userProficiencies;
    get userProficiencies(): ConnectUserUserProficienciesList;
    putUserProficiencies(value: ConnectUserUserProficiencies[] | cdktn.IResolvable): void;
    resetUserProficiencies(): void;
    get userProficienciesInput(): cdktn.IResolvable | ConnectUserUserProficiencies[] | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _voiceEnhancementConfigs;
    get voiceEnhancementConfigs(): ConnectUserVoiceEnhancementConfigsList;
    putVoiceEnhancementConfigs(value: ConnectUserVoiceEnhancementConfigs[] | cdktn.IResolvable): void;
    resetVoiceEnhancementConfigs(): void;
    get voiceEnhancementConfigsInput(): cdktn.IResolvable | ConnectUserVoiceEnhancementConfigs[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
