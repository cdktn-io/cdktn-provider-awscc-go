/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontOriginAccessControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * The origin access control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control#origin_access_control_config CloudfrontOriginAccessControl#origin_access_control_config}
    */
    readonly originAccessControlConfig: CloudfrontOriginAccessControlOriginAccessControlConfig;
}
export interface CloudfrontOriginAccessControlOriginAccessControlConfig {
    /**
    * A description of the origin access control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control#description CloudfrontOriginAccessControl#description}
    */
    readonly description?: string;
    /**
    * A name to identify the origin access control. You can specify up to 64 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control#name CloudfrontOriginAccessControl#name}
    */
    readonly name: string;
    /**
    * The type of origin that this origin access control is for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control#origin_access_control_origin_type CloudfrontOriginAccessControl#origin_access_control_origin_type}
    */
    readonly originAccessControlOriginType: string;
    /**
    * Specifies which requests CloudFront signs (adds authentication information to). Specify ``always`` for the most common use case. For more information, see [origin access control advanced settings](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/private-content-restricting-access-to-s3.html#oac-advanced-settings) in the *Amazon CloudFront Developer Guide*.
    *  This field can have one of the following values:
    *   +  ``always`` ? CloudFront signs all origin requests, overwriting the ``Authorization`` header from the viewer request if one exists.
    *   +  ``never`` ? CloudFront doesn't sign any origin requests. This value turns off origin access control for all origins in all distributions that use this origin access control.
    *   +  ``no-override`` ? If the viewer request doesn't contain the ``Authorization`` header, then CloudFront signs the origin request. If the viewer request contains the ``Authorization`` header, then CloudFront doesn't sign the origin request and instead passes along the ``Authorization`` header from the viewer request. *WARNING: To pass along the Authorization header from the viewer request, you must add the Authorization header to a cache policy for all cache behaviors that use origins associated with this origin access control.*
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control#signing_behavior CloudfrontOriginAccessControl#signing_behavior}
    */
    readonly signingBehavior: string;
    /**
    * The signing protocol of the origin access control, which determines how CloudFront signs (authenticates) requests. The only valid value is ``sigv4``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control#signing_protocol CloudfrontOriginAccessControl#signing_protocol}
    */
    readonly signingProtocol: string;
}
export declare function cloudfrontOriginAccessControlOriginAccessControlConfigToTerraform(struct?: CloudfrontOriginAccessControlOriginAccessControlConfig | cdktn.IResolvable): any;
export declare function cloudfrontOriginAccessControlOriginAccessControlConfigToHclTerraform(struct?: CloudfrontOriginAccessControlOriginAccessControlConfig | cdktn.IResolvable): any;
export declare class CloudfrontOriginAccessControlOriginAccessControlConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontOriginAccessControlOriginAccessControlConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontOriginAccessControlOriginAccessControlConfig | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _originAccessControlOriginType?;
    get originAccessControlOriginType(): string;
    set originAccessControlOriginType(value: string);
    get originAccessControlOriginTypeInput(): string | undefined;
    private _signingBehavior?;
    get signingBehavior(): string;
    set signingBehavior(value: string);
    get signingBehaviorInput(): string | undefined;
    private _signingProtocol?;
    get signingProtocol(): string;
    set signingProtocol(value: string);
    get signingProtocolInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control awscc_cloudfront_origin_access_control}
*/
export declare class CloudfrontOriginAccessControl extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_origin_access_control";
    /**
    * Generates CDKTN code for importing a CloudfrontOriginAccessControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontOriginAccessControl to import
    * @param importFromId The id of the existing CloudfrontOriginAccessControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontOriginAccessControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_origin_access_control awscc_cloudfront_origin_access_control} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontOriginAccessControlConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontOriginAccessControlConfig);
    get id(): string;
    private _originAccessControlConfig;
    get originAccessControlConfig(): CloudfrontOriginAccessControlOriginAccessControlConfigOutputReference;
    putOriginAccessControlConfig(value: CloudfrontOriginAccessControlOriginAccessControlConfig): void;
    get originAccessControlConfigInput(): cdktn.IResolvable | CloudfrontOriginAccessControlOriginAccessControlConfig | undefined;
    get originAccessControlId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
