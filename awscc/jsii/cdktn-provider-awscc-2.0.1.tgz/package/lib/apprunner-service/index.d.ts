/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApprunnerServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Autoscaling configuration ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#auto_scaling_configuration_arn ApprunnerService#auto_scaling_configuration_arn}
    */
    readonly autoScalingConfigurationArn?: string;
    /**
    * Encryption configuration (KMS key)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#encryption_configuration ApprunnerService#encryption_configuration}
    */
    readonly encryptionConfiguration?: ApprunnerServiceEncryptionConfiguration;
    /**
    * Health check configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#health_check_configuration ApprunnerService#health_check_configuration}
    */
    readonly healthCheckConfiguration?: ApprunnerServiceHealthCheckConfiguration;
    /**
    * Instance Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#instance_configuration ApprunnerService#instance_configuration}
    */
    readonly instanceConfiguration?: ApprunnerServiceInstanceConfiguration;
    /**
    * Network configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#network_configuration ApprunnerService#network_configuration}
    */
    readonly networkConfiguration?: ApprunnerServiceNetworkConfiguration;
    /**
    * Service observability configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#observability_configuration ApprunnerService#observability_configuration}
    */
    readonly observabilityConfiguration?: ApprunnerServiceObservabilityConfiguration;
    /**
    * The AppRunner Service Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#service_name ApprunnerService#service_name}
    */
    readonly serviceName?: string;
    /**
    * Source Code configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#source_configuration ApprunnerService#source_configuration}
    */
    readonly sourceConfiguration: ApprunnerServiceSourceConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#tags ApprunnerService#tags}
    */
    readonly tags?: ApprunnerServiceTags[] | cdktn.IResolvable;
}
export interface ApprunnerServiceEncryptionConfiguration {
    /**
    * The KMS Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#kms_key ApprunnerService#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function apprunnerServiceEncryptionConfigurationToTerraform(struct?: ApprunnerServiceEncryptionConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceEncryptionConfigurationToHclTerraform(struct?: ApprunnerServiceEncryptionConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface ApprunnerServiceHealthCheckConfiguration {
    /**
    * Health check Healthy Threshold
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#healthy_threshold ApprunnerService#healthy_threshold}
    */
    readonly healthyThreshold?: number;
    /**
    * Health check Interval
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#interval ApprunnerService#interval}
    */
    readonly interval?: number;
    /**
    * Health check Path
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#path ApprunnerService#path}
    */
    readonly path?: string;
    /**
    * Health Check Protocol
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#protocol ApprunnerService#protocol}
    */
    readonly protocol?: string;
    /**
    * Health check Timeout
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#timeout ApprunnerService#timeout}
    */
    readonly timeout?: number;
    /**
    * Health check Unhealthy Threshold
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#unhealthy_threshold ApprunnerService#unhealthy_threshold}
    */
    readonly unhealthyThreshold?: number;
}
export declare function apprunnerServiceHealthCheckConfigurationToTerraform(struct?: ApprunnerServiceHealthCheckConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceHealthCheckConfigurationToHclTerraform(struct?: ApprunnerServiceHealthCheckConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceHealthCheckConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceHealthCheckConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceHealthCheckConfiguration | cdktn.IResolvable | undefined);
    private _healthyThreshold?;
    get healthyThreshold(): number;
    set healthyThreshold(value: number);
    resetHealthyThreshold(): void;
    get healthyThresholdInput(): number | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _unhealthyThreshold?;
    get unhealthyThreshold(): number;
    set unhealthyThreshold(value: number);
    resetUnhealthyThreshold(): void;
    get unhealthyThresholdInput(): number | undefined;
}
export interface ApprunnerServiceInstanceConfiguration {
    /**
    * CPU
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#cpu ApprunnerService#cpu}
    */
    readonly cpu?: string;
    /**
    * Instance Role Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#instance_role_arn ApprunnerService#instance_role_arn}
    */
    readonly instanceRoleArn?: string;
    /**
    * Memory
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#memory ApprunnerService#memory}
    */
    readonly memory?: string;
}
export declare function apprunnerServiceInstanceConfigurationToTerraform(struct?: ApprunnerServiceInstanceConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceInstanceConfigurationToHclTerraform(struct?: ApprunnerServiceInstanceConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceInstanceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceInstanceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceInstanceConfiguration | cdktn.IResolvable | undefined);
    private _cpu?;
    get cpu(): string;
    set cpu(value: string);
    resetCpu(): void;
    get cpuInput(): string | undefined;
    private _instanceRoleArn?;
    get instanceRoleArn(): string;
    set instanceRoleArn(value: string);
    resetInstanceRoleArn(): void;
    get instanceRoleArnInput(): string | undefined;
    private _memory?;
    get memory(): string;
    set memory(value: string);
    resetMemory(): void;
    get memoryInput(): string | undefined;
}
export interface ApprunnerServiceNetworkConfigurationEgressConfiguration {
    /**
    * Network egress type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#egress_type ApprunnerService#egress_type}
    */
    readonly egressType?: string;
    /**
    * The Amazon Resource Name (ARN) of the App Runner VpcConnector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#vpc_connector_arn ApprunnerService#vpc_connector_arn}
    */
    readonly vpcConnectorArn?: string;
}
export declare function apprunnerServiceNetworkConfigurationEgressConfigurationToTerraform(struct?: ApprunnerServiceNetworkConfigurationEgressConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceNetworkConfigurationEgressConfigurationToHclTerraform(struct?: ApprunnerServiceNetworkConfigurationEgressConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceNetworkConfigurationEgressConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceNetworkConfigurationEgressConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceNetworkConfigurationEgressConfiguration | cdktn.IResolvable | undefined);
    private _egressType?;
    get egressType(): string;
    set egressType(value: string);
    resetEgressType(): void;
    get egressTypeInput(): string | undefined;
    private _vpcConnectorArn?;
    get vpcConnectorArn(): string;
    set vpcConnectorArn(value: string);
    resetVpcConnectorArn(): void;
    get vpcConnectorArnInput(): string | undefined;
}
export interface ApprunnerServiceNetworkConfigurationIngressConfiguration {
    /**
    * It's set to true if the Apprunner service is publicly accessible. It's set to false otherwise.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#is_publicly_accessible ApprunnerService#is_publicly_accessible}
    */
    readonly isPubliclyAccessible?: boolean | cdktn.IResolvable;
}
export declare function apprunnerServiceNetworkConfigurationIngressConfigurationToTerraform(struct?: ApprunnerServiceNetworkConfigurationIngressConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceNetworkConfigurationIngressConfigurationToHclTerraform(struct?: ApprunnerServiceNetworkConfigurationIngressConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceNetworkConfigurationIngressConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceNetworkConfigurationIngressConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceNetworkConfigurationIngressConfiguration | cdktn.IResolvable | undefined);
    private _isPubliclyAccessible?;
    get isPubliclyAccessible(): boolean | cdktn.IResolvable;
    set isPubliclyAccessible(value: boolean | cdktn.IResolvable);
    resetIsPubliclyAccessible(): void;
    get isPubliclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApprunnerServiceNetworkConfiguration {
    /**
    * Network egress configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#egress_configuration ApprunnerService#egress_configuration}
    */
    readonly egressConfiguration?: ApprunnerServiceNetworkConfigurationEgressConfiguration;
    /**
    * Network ingress configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#ingress_configuration ApprunnerService#ingress_configuration}
    */
    readonly ingressConfiguration?: ApprunnerServiceNetworkConfigurationIngressConfiguration;
    /**
    * App Runner service endpoint IP address type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#ip_address_type ApprunnerService#ip_address_type}
    */
    readonly ipAddressType?: string;
}
export declare function apprunnerServiceNetworkConfigurationToTerraform(struct?: ApprunnerServiceNetworkConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceNetworkConfigurationToHclTerraform(struct?: ApprunnerServiceNetworkConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceNetworkConfiguration | cdktn.IResolvable | undefined);
    private _egressConfiguration;
    get egressConfiguration(): ApprunnerServiceNetworkConfigurationEgressConfigurationOutputReference;
    putEgressConfiguration(value: ApprunnerServiceNetworkConfigurationEgressConfiguration): void;
    resetEgressConfiguration(): void;
    get egressConfigurationInput(): cdktn.IResolvable | ApprunnerServiceNetworkConfigurationEgressConfiguration | undefined;
    private _ingressConfiguration;
    get ingressConfiguration(): ApprunnerServiceNetworkConfigurationIngressConfigurationOutputReference;
    putIngressConfiguration(value: ApprunnerServiceNetworkConfigurationIngressConfiguration): void;
    resetIngressConfiguration(): void;
    get ingressConfigurationInput(): cdktn.IResolvable | ApprunnerServiceNetworkConfigurationIngressConfiguration | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
}
export interface ApprunnerServiceObservabilityConfiguration {
    /**
    * The Amazon Resource Name (ARN) of the App Runner ObservabilityConfiguration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#observability_configuration_arn ApprunnerService#observability_configuration_arn}
    */
    readonly observabilityConfigurationArn?: string;
    /**
    * Observability enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#observability_enabled ApprunnerService#observability_enabled}
    */
    readonly observabilityEnabled?: boolean | cdktn.IResolvable;
}
export declare function apprunnerServiceObservabilityConfigurationToTerraform(struct?: ApprunnerServiceObservabilityConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceObservabilityConfigurationToHclTerraform(struct?: ApprunnerServiceObservabilityConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceObservabilityConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceObservabilityConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceObservabilityConfiguration | cdktn.IResolvable | undefined);
    private _observabilityConfigurationArn?;
    get observabilityConfigurationArn(): string;
    set observabilityConfigurationArn(value: string);
    resetObservabilityConfigurationArn(): void;
    get observabilityConfigurationArnInput(): string | undefined;
    private _observabilityEnabled?;
    get observabilityEnabled(): boolean | cdktn.IResolvable;
    set observabilityEnabled(value: boolean | cdktn.IResolvable);
    resetObservabilityEnabled(): void;
    get observabilityEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApprunnerServiceSourceConfigurationAuthenticationConfiguration {
    /**
    * Access Role Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#access_role_arn ApprunnerService#access_role_arn}
    */
    readonly accessRoleArn?: string;
    /**
    * Connection Arn
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#connection_arn ApprunnerService#connection_arn}
    */
    readonly connectionArn?: string;
}
export declare function apprunnerServiceSourceConfigurationAuthenticationConfigurationToTerraform(struct?: ApprunnerServiceSourceConfigurationAuthenticationConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationAuthenticationConfigurationToHclTerraform(struct?: ApprunnerServiceSourceConfigurationAuthenticationConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationAuthenticationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceSourceConfigurationAuthenticationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationAuthenticationConfiguration | cdktn.IResolvable | undefined);
    private _accessRoleArn?;
    get accessRoleArn(): string;
    set accessRoleArn(value: string);
    resetAccessRoleArn(): void;
    get accessRoleArnInput(): string | undefined;
    private _connectionArn?;
    get connectionArn(): string;
    set connectionArn(value: string);
    resetConnectionArn(): void;
    get connectionArnInput(): string | undefined;
}
export interface ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#name ApprunnerService#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#value ApprunnerService#value}
    */
    readonly value?: string;
}
export declare function apprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecretsToTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecretsToHclTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecretsList extends cdktn.ComplexList {
    internalValue?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecretsOutputReference;
}
export interface ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#name ApprunnerService#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#value ApprunnerService#value}
    */
    readonly value?: string;
}
export declare function apprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariablesToTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariablesToHclTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariablesList extends cdktn.ComplexList {
    internalValue?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariablesOutputReference;
}
export interface ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValues {
    /**
    * Build Command
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#build_command ApprunnerService#build_command}
    */
    readonly buildCommand?: string;
    /**
    * Port
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#port ApprunnerService#port}
    */
    readonly port?: string;
    /**
    * Runtime
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#runtime ApprunnerService#runtime}
    */
    readonly runtime?: string;
    /**
    * The secrets and parameters that get referenced by your service as environment variables
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#runtime_environment_secrets ApprunnerService#runtime_environment_secrets}
    */
    readonly runtimeEnvironmentSecrets?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#runtime_environment_variables ApprunnerService#runtime_environment_variables}
    */
    readonly runtimeEnvironmentVariables?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * Start Command
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#start_command ApprunnerService#start_command}
    */
    readonly startCommand?: string;
}
export declare function apprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesToTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValues | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesToHclTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValues | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValues | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValues | cdktn.IResolvable | undefined);
    private _buildCommand?;
    get buildCommand(): string;
    set buildCommand(value: string);
    resetBuildCommand(): void;
    get buildCommandInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    resetRuntime(): void;
    get runtimeInput(): string | undefined;
    private _runtimeEnvironmentSecrets;
    get runtimeEnvironmentSecrets(): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecretsList;
    putRuntimeEnvironmentSecrets(value: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets[] | cdktn.IResolvable): void;
    resetRuntimeEnvironmentSecrets(): void;
    get runtimeEnvironmentSecretsInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentSecrets[] | undefined;
    private _runtimeEnvironmentVariables;
    get runtimeEnvironmentVariables(): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariablesList;
    putRuntimeEnvironmentVariables(value: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables[] | cdktn.IResolvable): void;
    resetRuntimeEnvironmentVariables(): void;
    get runtimeEnvironmentVariablesInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesRuntimeEnvironmentVariables[] | undefined;
    private _startCommand?;
    get startCommand(): string;
    set startCommand(value: string);
    resetStartCommand(): void;
    get startCommandInput(): string | undefined;
}
export interface ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfiguration {
    /**
    * Code Configuration Values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#code_configuration_values ApprunnerService#code_configuration_values}
    */
    readonly codeConfigurationValues?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValues;
    /**
    * Configuration Source
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#configuration_source ApprunnerService#configuration_source}
    */
    readonly configurationSource?: string;
}
export declare function apprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationToTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationToHclTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfiguration | cdktn.IResolvable | undefined);
    private _codeConfigurationValues;
    get codeConfigurationValues(): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValuesOutputReference;
    putCodeConfigurationValues(value: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValues): void;
    resetCodeConfigurationValues(): void;
    get codeConfigurationValuesInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationCodeConfigurationValues | undefined;
    private _configurationSource?;
    get configurationSource(): string;
    set configurationSource(value: string);
    resetConfigurationSource(): void;
    get configurationSourceInput(): string | undefined;
}
export interface ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersion {
    /**
    * Source Code Version Type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#type ApprunnerService#type}
    */
    readonly type?: string;
    /**
    * Source Code Version Value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#value ApprunnerService#value}
    */
    readonly value?: string;
}
export declare function apprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersionToTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersion | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersionToHclTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersion | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersion | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersion | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface ApprunnerServiceSourceConfigurationCodeRepository {
    /**
    * Code Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#code_configuration ApprunnerService#code_configuration}
    */
    readonly codeConfiguration?: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfiguration;
    /**
    * Repository Url
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#repository_url ApprunnerService#repository_url}
    */
    readonly repositoryUrl?: string;
    /**
    * Source Code Version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#source_code_version ApprunnerService#source_code_version}
    */
    readonly sourceCodeVersion?: ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersion;
    /**
    * Source Directory
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#source_directory ApprunnerService#source_directory}
    */
    readonly sourceDirectory?: string;
}
export declare function apprunnerServiceSourceConfigurationCodeRepositoryToTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepository | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationCodeRepositoryToHclTerraform(struct?: ApprunnerServiceSourceConfigurationCodeRepository | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationCodeRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceSourceConfigurationCodeRepository | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationCodeRepository | cdktn.IResolvable | undefined);
    private _codeConfiguration;
    get codeConfiguration(): ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfigurationOutputReference;
    putCodeConfiguration(value: ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfiguration): void;
    resetCodeConfiguration(): void;
    get codeConfigurationInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationCodeRepositoryCodeConfiguration | undefined;
    private _repositoryUrl?;
    get repositoryUrl(): string;
    set repositoryUrl(value: string);
    resetRepositoryUrl(): void;
    get repositoryUrlInput(): string | undefined;
    private _sourceCodeVersion;
    get sourceCodeVersion(): ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersionOutputReference;
    putSourceCodeVersion(value: ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersion): void;
    resetSourceCodeVersion(): void;
    get sourceCodeVersionInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationCodeRepositorySourceCodeVersion | undefined;
    private _sourceDirectory?;
    get sourceDirectory(): string;
    set sourceDirectory(value: string);
    resetSourceDirectory(): void;
    get sourceDirectoryInput(): string | undefined;
}
export interface ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#name ApprunnerService#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#value ApprunnerService#value}
    */
    readonly value?: string;
}
export declare function apprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecretsToTerraform(struct?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecretsToHclTerraform(struct?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecretsList extends cdktn.ComplexList {
    internalValue?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecretsOutputReference;
}
export interface ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#name ApprunnerService#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#value ApprunnerService#value}
    */
    readonly value?: string;
}
export declare function apprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariablesToTerraform(struct?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariablesToHclTerraform(struct?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariablesList extends cdktn.ComplexList {
    internalValue?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariablesOutputReference;
}
export interface ApprunnerServiceSourceConfigurationImageRepositoryImageConfiguration {
    /**
    * Port
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#port ApprunnerService#port}
    */
    readonly port?: string;
    /**
    * The secrets and parameters that get referenced by your service as environment variables
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#runtime_environment_secrets ApprunnerService#runtime_environment_secrets}
    */
    readonly runtimeEnvironmentSecrets?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#runtime_environment_variables ApprunnerService#runtime_environment_variables}
    */
    readonly runtimeEnvironmentVariables?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables[] | cdktn.IResolvable;
    /**
    * Start Command
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#start_command ApprunnerService#start_command}
    */
    readonly startCommand?: string;
}
export declare function apprunnerServiceSourceConfigurationImageRepositoryImageConfigurationToTerraform(struct?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationImageRepositoryImageConfigurationToHclTerraform(struct?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceSourceConfigurationImageRepositoryImageConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationImageRepositoryImageConfiguration | cdktn.IResolvable | undefined);
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _runtimeEnvironmentSecrets;
    get runtimeEnvironmentSecrets(): ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecretsList;
    putRuntimeEnvironmentSecrets(value: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets[] | cdktn.IResolvable): void;
    resetRuntimeEnvironmentSecrets(): void;
    get runtimeEnvironmentSecretsInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentSecrets[] | undefined;
    private _runtimeEnvironmentVariables;
    get runtimeEnvironmentVariables(): ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariablesList;
    putRuntimeEnvironmentVariables(value: ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables[] | cdktn.IResolvable): void;
    resetRuntimeEnvironmentVariables(): void;
    get runtimeEnvironmentVariablesInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationRuntimeEnvironmentVariables[] | undefined;
    private _startCommand?;
    get startCommand(): string;
    set startCommand(value: string);
    resetStartCommand(): void;
    get startCommandInput(): string | undefined;
}
export interface ApprunnerServiceSourceConfigurationImageRepository {
    /**
    * Image Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#image_configuration ApprunnerService#image_configuration}
    */
    readonly imageConfiguration?: ApprunnerServiceSourceConfigurationImageRepositoryImageConfiguration;
    /**
    * Image Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#image_identifier ApprunnerService#image_identifier}
    */
    readonly imageIdentifier?: string;
    /**
    * Image Repository Type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#image_repository_type ApprunnerService#image_repository_type}
    */
    readonly imageRepositoryType?: string;
}
export declare function apprunnerServiceSourceConfigurationImageRepositoryToTerraform(struct?: ApprunnerServiceSourceConfigurationImageRepository | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationImageRepositoryToHclTerraform(struct?: ApprunnerServiceSourceConfigurationImageRepository | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationImageRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceSourceConfigurationImageRepository | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfigurationImageRepository | cdktn.IResolvable | undefined);
    private _imageConfiguration;
    get imageConfiguration(): ApprunnerServiceSourceConfigurationImageRepositoryImageConfigurationOutputReference;
    putImageConfiguration(value: ApprunnerServiceSourceConfigurationImageRepositoryImageConfiguration): void;
    resetImageConfiguration(): void;
    get imageConfigurationInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationImageRepositoryImageConfiguration | undefined;
    private _imageIdentifier?;
    get imageIdentifier(): string;
    set imageIdentifier(value: string);
    resetImageIdentifier(): void;
    get imageIdentifierInput(): string | undefined;
    private _imageRepositoryType?;
    get imageRepositoryType(): string;
    set imageRepositoryType(value: string);
    resetImageRepositoryType(): void;
    get imageRepositoryTypeInput(): string | undefined;
}
export interface ApprunnerServiceSourceConfiguration {
    /**
    * Authentication Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#authentication_configuration ApprunnerService#authentication_configuration}
    */
    readonly authenticationConfiguration?: ApprunnerServiceSourceConfigurationAuthenticationConfiguration;
    /**
    * Auto Deployment enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#auto_deployments_enabled ApprunnerService#auto_deployments_enabled}
    */
    readonly autoDeploymentsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Source Code Repository
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#code_repository ApprunnerService#code_repository}
    */
    readonly codeRepository?: ApprunnerServiceSourceConfigurationCodeRepository;
    /**
    * Image Repository
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#image_repository ApprunnerService#image_repository}
    */
    readonly imageRepository?: ApprunnerServiceSourceConfigurationImageRepository;
}
export declare function apprunnerServiceSourceConfigurationToTerraform(struct?: ApprunnerServiceSourceConfiguration | cdktn.IResolvable): any;
export declare function apprunnerServiceSourceConfigurationToHclTerraform(struct?: ApprunnerServiceSourceConfiguration | cdktn.IResolvable): any;
export declare class ApprunnerServiceSourceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerServiceSourceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceSourceConfiguration | cdktn.IResolvable | undefined);
    private _authenticationConfiguration;
    get authenticationConfiguration(): ApprunnerServiceSourceConfigurationAuthenticationConfigurationOutputReference;
    putAuthenticationConfiguration(value: ApprunnerServiceSourceConfigurationAuthenticationConfiguration): void;
    resetAuthenticationConfiguration(): void;
    get authenticationConfigurationInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationAuthenticationConfiguration | undefined;
    private _autoDeploymentsEnabled?;
    get autoDeploymentsEnabled(): boolean | cdktn.IResolvable;
    set autoDeploymentsEnabled(value: boolean | cdktn.IResolvable);
    resetAutoDeploymentsEnabled(): void;
    get autoDeploymentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _codeRepository;
    get codeRepository(): ApprunnerServiceSourceConfigurationCodeRepositoryOutputReference;
    putCodeRepository(value: ApprunnerServiceSourceConfigurationCodeRepository): void;
    resetCodeRepository(): void;
    get codeRepositoryInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationCodeRepository | undefined;
    private _imageRepository;
    get imageRepository(): ApprunnerServiceSourceConfigurationImageRepositoryOutputReference;
    putImageRepository(value: ApprunnerServiceSourceConfigurationImageRepository): void;
    resetImageRepository(): void;
    get imageRepositoryInput(): cdktn.IResolvable | ApprunnerServiceSourceConfigurationImageRepository | undefined;
}
export interface ApprunnerServiceTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#key ApprunnerService#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#value ApprunnerService#value}
    */
    readonly value?: string;
}
export declare function apprunnerServiceTagsToTerraform(struct?: ApprunnerServiceTags | cdktn.IResolvable): any;
export declare function apprunnerServiceTagsToHclTerraform(struct?: ApprunnerServiceTags | cdktn.IResolvable): any;
export declare class ApprunnerServiceTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApprunnerServiceTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerServiceTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApprunnerServiceTagsList extends cdktn.ComplexList {
    internalValue?: ApprunnerServiceTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApprunnerServiceTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service awscc_apprunner_service}
*/
export declare class ApprunnerService extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apprunner_service";
    /**
    * Generates CDKTN code for importing a ApprunnerService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApprunnerService to import
    * @param importFromId The id of the existing ApprunnerService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApprunnerService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apprunner_service awscc_apprunner_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApprunnerServiceConfig
    */
    constructor(scope: Construct, id: string, config: ApprunnerServiceConfig);
    private _autoScalingConfigurationArn?;
    get autoScalingConfigurationArn(): string;
    set autoScalingConfigurationArn(value: string);
    resetAutoScalingConfigurationArn(): void;
    get autoScalingConfigurationArnInput(): string | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): ApprunnerServiceEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: ApprunnerServiceEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | ApprunnerServiceEncryptionConfiguration | undefined;
    private _healthCheckConfiguration;
    get healthCheckConfiguration(): ApprunnerServiceHealthCheckConfigurationOutputReference;
    putHealthCheckConfiguration(value: ApprunnerServiceHealthCheckConfiguration): void;
    resetHealthCheckConfiguration(): void;
    get healthCheckConfigurationInput(): cdktn.IResolvable | ApprunnerServiceHealthCheckConfiguration | undefined;
    get id(): string;
    private _instanceConfiguration;
    get instanceConfiguration(): ApprunnerServiceInstanceConfigurationOutputReference;
    putInstanceConfiguration(value: ApprunnerServiceInstanceConfiguration): void;
    resetInstanceConfiguration(): void;
    get instanceConfigurationInput(): cdktn.IResolvable | ApprunnerServiceInstanceConfiguration | undefined;
    private _networkConfiguration;
    get networkConfiguration(): ApprunnerServiceNetworkConfigurationOutputReference;
    putNetworkConfiguration(value: ApprunnerServiceNetworkConfiguration): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | ApprunnerServiceNetworkConfiguration | undefined;
    private _observabilityConfiguration;
    get observabilityConfiguration(): ApprunnerServiceObservabilityConfigurationOutputReference;
    putObservabilityConfiguration(value: ApprunnerServiceObservabilityConfiguration): void;
    resetObservabilityConfiguration(): void;
    get observabilityConfigurationInput(): cdktn.IResolvable | ApprunnerServiceObservabilityConfiguration | undefined;
    get serviceArn(): string;
    get serviceId(): string;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    get serviceUrl(): string;
    private _sourceConfiguration;
    get sourceConfiguration(): ApprunnerServiceSourceConfigurationOutputReference;
    putSourceConfiguration(value: ApprunnerServiceSourceConfiguration): void;
    get sourceConfigurationInput(): cdktn.IResolvable | ApprunnerServiceSourceConfiguration | undefined;
    get status(): string;
    private _tags;
    get tags(): ApprunnerServiceTagsList;
    putTags(value: ApprunnerServiceTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApprunnerServiceTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
