/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontConnectionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Anycast static IP list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group#anycast_ip_list_id CloudfrontConnectionGroup#anycast_ip_list_id}
    */
    readonly anycastIpListId?: string;
    /**
    * Whether the connection group is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group#enabled CloudfrontConnectionGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * IPv6 is enabled for the connection group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group#ipv_6_enabled CloudfrontConnectionGroup#ipv_6_enabled}
    */
    readonly ipv6Enabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the connection group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group#name CloudfrontConnectionGroup#name}
    */
    readonly name: string;
    /**
    * A complex type that contains zero or more ``Tag`` elements.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group#tags CloudfrontConnectionGroup#tags}
    */
    readonly tags?: CloudfrontConnectionGroupTags[] | cdktn.IResolvable;
}
export interface CloudfrontConnectionGroupTags {
    /**
    * A string that contains ``Tag`` key.
    *  The string length should be between 1 and 128 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group#key CloudfrontConnectionGroup#key}
    */
    readonly key?: string;
    /**
    * A string that contains an optional ``Tag`` value.
    *  The string length should be between 0 and 256 characters. Valid characters include ``a-z``, ``A-Z``, ``0-9``, space, and the special characters ``_ - . : / = + @``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group#value CloudfrontConnectionGroup#value}
    */
    readonly value?: string;
}
export declare function cloudfrontConnectionGroupTagsToTerraform(struct?: CloudfrontConnectionGroupTags | cdktn.IResolvable): any;
export declare function cloudfrontConnectionGroupTagsToHclTerraform(struct?: CloudfrontConnectionGroupTags | cdktn.IResolvable): any;
export declare class CloudfrontConnectionGroupTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontConnectionGroupTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontConnectionGroupTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudfrontConnectionGroupTagsList extends cdktn.ComplexList {
    internalValue?: CloudfrontConnectionGroupTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontConnectionGroupTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group awscc_cloudfront_connection_group}
*/
export declare class CloudfrontConnectionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_connection_group";
    /**
    * Generates CDKTN code for importing a CloudfrontConnectionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontConnectionGroup to import
    * @param importFromId The id of the existing CloudfrontConnectionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontConnectionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_connection_group awscc_cloudfront_connection_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontConnectionGroupConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontConnectionGroupConfig);
    private _anycastIpListId?;
    get anycastIpListId(): string;
    set anycastIpListId(value: string);
    resetAnycastIpListId(): void;
    get anycastIpListIdInput(): string | undefined;
    get arn(): string;
    get connectionGroupId(): string;
    get createdTime(): string;
    get eTag(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _ipv6Enabled?;
    get ipv6Enabled(): boolean | cdktn.IResolvable;
    set ipv6Enabled(value: boolean | cdktn.IResolvable);
    resetIpv6Enabled(): void;
    get ipv6EnabledInput(): boolean | cdktn.IResolvable | undefined;
    get isDefault(): cdktn.IResolvable;
    get lastModifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get routingEndpoint(): string;
    get status(): string;
    private _tags;
    get tags(): CloudfrontConnectionGroupTagsList;
    putTags(value: CloudfrontConnectionGroupTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudfrontConnectionGroupTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
