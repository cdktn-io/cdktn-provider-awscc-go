/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsccAmplifyBranchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Uniquely identifies the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/amplify_branch#id DataAwsccAmplifyBranch#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataAwsccAmplifyBranchBackend {
}
export declare function dataAwsccAmplifyBranchBackendToTerraform(struct?: DataAwsccAmplifyBranchBackend): any;
export declare function dataAwsccAmplifyBranchBackendToHclTerraform(struct?: DataAwsccAmplifyBranchBackend): any;
export declare class DataAwsccAmplifyBranchBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyBranchBackend | undefined;
    set internalValue(value: DataAwsccAmplifyBranchBackend | undefined);
    get stackArn(): string;
}
export interface DataAwsccAmplifyBranchBasicAuthConfig {
}
export declare function dataAwsccAmplifyBranchBasicAuthConfigToTerraform(struct?: DataAwsccAmplifyBranchBasicAuthConfig): any;
export declare function dataAwsccAmplifyBranchBasicAuthConfigToHclTerraform(struct?: DataAwsccAmplifyBranchBasicAuthConfig): any;
export declare class DataAwsccAmplifyBranchBasicAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsccAmplifyBranchBasicAuthConfig | undefined;
    set internalValue(value: DataAwsccAmplifyBranchBasicAuthConfig | undefined);
    get enableBasicAuth(): cdktn.IResolvable;
    get password(): string;
    get username(): string;
}
export interface DataAwsccAmplifyBranchEnvironmentVariables {
}
export declare function dataAwsccAmplifyBranchEnvironmentVariablesToTerraform(struct?: DataAwsccAmplifyBranchEnvironmentVariables): any;
export declare function dataAwsccAmplifyBranchEnvironmentVariablesToHclTerraform(struct?: DataAwsccAmplifyBranchEnvironmentVariables): any;
export declare class DataAwsccAmplifyBranchEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAmplifyBranchEnvironmentVariables | undefined;
    set internalValue(value: DataAwsccAmplifyBranchEnvironmentVariables | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataAwsccAmplifyBranchEnvironmentVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAmplifyBranchEnvironmentVariablesOutputReference;
}
export interface DataAwsccAmplifyBranchTags {
}
export declare function dataAwsccAmplifyBranchTagsToTerraform(struct?: DataAwsccAmplifyBranchTags): any;
export declare function dataAwsccAmplifyBranchTagsToHclTerraform(struct?: DataAwsccAmplifyBranchTags): any;
export declare class DataAwsccAmplifyBranchTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsccAmplifyBranchTags | undefined;
    set internalValue(value: DataAwsccAmplifyBranchTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataAwsccAmplifyBranchTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsccAmplifyBranchTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/amplify_branch awscc_amplify_branch}
*/
export declare class DataAwsccAmplifyBranch extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "awscc_amplify_branch";
    /**
    * Generates CDKTN code for importing a DataAwsccAmplifyBranch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsccAmplifyBranch to import
    * @param importFromId The id of the existing DataAwsccAmplifyBranch that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/amplify_branch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsccAmplifyBranch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/data-sources/amplify_branch awscc_amplify_branch} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsccAmplifyBranchConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsccAmplifyBranchConfig);
    get appId(): string;
    get arn(): string;
    private _backend;
    get backend(): DataAwsccAmplifyBranchBackendOutputReference;
    private _basicAuthConfig;
    get basicAuthConfig(): DataAwsccAmplifyBranchBasicAuthConfigOutputReference;
    get branchName(): string;
    get buildSpec(): string;
    get computeRoleArn(): string;
    get description(): string;
    get enableAutoBuild(): cdktn.IResolvable;
    get enablePerformanceMode(): cdktn.IResolvable;
    get enablePullRequestPreview(): cdktn.IResolvable;
    get enableSkewProtection(): cdktn.IResolvable;
    private _environmentVariables;
    get environmentVariables(): DataAwsccAmplifyBranchEnvironmentVariablesList;
    get framework(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get pullRequestEnvironmentName(): string;
    get stage(): string;
    private _tags;
    get tags(): DataAwsccAmplifyBranchTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
