/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectInstanceStorageConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Connect Instance ID with which the storage config will be associated
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#instance_arn ConnectInstanceStorageConfig#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#kinesis_firehose_config ConnectInstanceStorageConfig#kinesis_firehose_config}
    */
    readonly kinesisFirehoseConfig?: ConnectInstanceStorageConfigKinesisFirehoseConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#kinesis_stream_config ConnectInstanceStorageConfig#kinesis_stream_config}
    */
    readonly kinesisStreamConfig?: ConnectInstanceStorageConfigKinesisStreamConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#kinesis_video_stream_config ConnectInstanceStorageConfig#kinesis_video_stream_config}
    */
    readonly kinesisVideoStreamConfig?: ConnectInstanceStorageConfigKinesisVideoStreamConfig;
    /**
    * Specifies the type of storage resource available for the instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#resource_type ConnectInstanceStorageConfig#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#s3_config ConnectInstanceStorageConfig#s3_config}
    */
    readonly s3Config?: ConnectInstanceStorageConfigS3Config;
    /**
    * Specifies the storage type to be associated with the instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#storage_type ConnectInstanceStorageConfig#storage_type}
    */
    readonly storageType: string;
}
export interface ConnectInstanceStorageConfigKinesisFirehoseConfig {
    /**
    * An ARN is a unique AWS resource identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#firehose_arn ConnectInstanceStorageConfig#firehose_arn}
    */
    readonly firehoseArn?: string;
}
export declare function connectInstanceStorageConfigKinesisFirehoseConfigToTerraform(struct?: ConnectInstanceStorageConfigKinesisFirehoseConfig | cdktn.IResolvable): any;
export declare function connectInstanceStorageConfigKinesisFirehoseConfigToHclTerraform(struct?: ConnectInstanceStorageConfigKinesisFirehoseConfig | cdktn.IResolvable): any;
export declare class ConnectInstanceStorageConfigKinesisFirehoseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectInstanceStorageConfigKinesisFirehoseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectInstanceStorageConfigKinesisFirehoseConfig | cdktn.IResolvable | undefined);
    private _firehoseArn?;
    get firehoseArn(): string;
    set firehoseArn(value: string);
    resetFirehoseArn(): void;
    get firehoseArnInput(): string | undefined;
}
export interface ConnectInstanceStorageConfigKinesisStreamConfig {
    /**
    * An ARN is a unique AWS resource identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#stream_arn ConnectInstanceStorageConfig#stream_arn}
    */
    readonly streamArn?: string;
}
export declare function connectInstanceStorageConfigKinesisStreamConfigToTerraform(struct?: ConnectInstanceStorageConfigKinesisStreamConfig | cdktn.IResolvable): any;
export declare function connectInstanceStorageConfigKinesisStreamConfigToHclTerraform(struct?: ConnectInstanceStorageConfigKinesisStreamConfig | cdktn.IResolvable): any;
export declare class ConnectInstanceStorageConfigKinesisStreamConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectInstanceStorageConfigKinesisStreamConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectInstanceStorageConfigKinesisStreamConfig | cdktn.IResolvable | undefined);
    private _streamArn?;
    get streamArn(): string;
    set streamArn(value: string);
    resetStreamArn(): void;
    get streamArnInput(): string | undefined;
}
export interface ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfig {
    /**
    * Specifies default encryption using AWS KMS-Managed Keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#encryption_type ConnectInstanceStorageConfig#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Specifies the encryption key id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#key_id ConnectInstanceStorageConfig#key_id}
    */
    readonly keyId?: string;
}
export declare function connectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfigToTerraform(struct?: ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfig | cdktn.IResolvable): any;
export declare function connectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfigToHclTerraform(struct?: ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfig | cdktn.IResolvable): any;
export declare class ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfig | cdktn.IResolvable | undefined);
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    resetKeyId(): void;
    get keyIdInput(): string | undefined;
}
export interface ConnectInstanceStorageConfigKinesisVideoStreamConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#encryption_config ConnectInstanceStorageConfig#encryption_config}
    */
    readonly encryptionConfig?: ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfig;
    /**
    * Prefixes are used to infer logical hierarchy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#prefix ConnectInstanceStorageConfig#prefix}
    */
    readonly prefix?: string;
    /**
    * Number of hours
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#retention_period_hours ConnectInstanceStorageConfig#retention_period_hours}
    */
    readonly retentionPeriodHours?: number;
}
export declare function connectInstanceStorageConfigKinesisVideoStreamConfigToTerraform(struct?: ConnectInstanceStorageConfigKinesisVideoStreamConfig | cdktn.IResolvable): any;
export declare function connectInstanceStorageConfigKinesisVideoStreamConfigToHclTerraform(struct?: ConnectInstanceStorageConfigKinesisVideoStreamConfig | cdktn.IResolvable): any;
export declare class ConnectInstanceStorageConfigKinesisVideoStreamConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectInstanceStorageConfigKinesisVideoStreamConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectInstanceStorageConfigKinesisVideoStreamConfig | cdktn.IResolvable | undefined);
    private _encryptionConfig;
    get encryptionConfig(): ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfigOutputReference;
    putEncryptionConfig(value: ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfig): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): cdktn.IResolvable | ConnectInstanceStorageConfigKinesisVideoStreamConfigEncryptionConfig | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _retentionPeriodHours?;
    get retentionPeriodHours(): number;
    set retentionPeriodHours(value: number);
    resetRetentionPeriodHours(): void;
    get retentionPeriodHoursInput(): number | undefined;
}
export interface ConnectInstanceStorageConfigS3ConfigEncryptionConfig {
    /**
    * Specifies default encryption using AWS KMS-Managed Keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#encryption_type ConnectInstanceStorageConfig#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Specifies the encryption key id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#key_id ConnectInstanceStorageConfig#key_id}
    */
    readonly keyId?: string;
}
export declare function connectInstanceStorageConfigS3ConfigEncryptionConfigToTerraform(struct?: ConnectInstanceStorageConfigS3ConfigEncryptionConfig | cdktn.IResolvable): any;
export declare function connectInstanceStorageConfigS3ConfigEncryptionConfigToHclTerraform(struct?: ConnectInstanceStorageConfigS3ConfigEncryptionConfig | cdktn.IResolvable): any;
export declare class ConnectInstanceStorageConfigS3ConfigEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectInstanceStorageConfigS3ConfigEncryptionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectInstanceStorageConfigS3ConfigEncryptionConfig | cdktn.IResolvable | undefined);
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    resetKeyId(): void;
    get keyIdInput(): string | undefined;
}
export interface ConnectInstanceStorageConfigS3Config {
    /**
    * A name for the S3 Bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#bucket_name ConnectInstanceStorageConfig#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Prefixes are used to infer logical hierarchy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#bucket_prefix ConnectInstanceStorageConfig#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#encryption_config ConnectInstanceStorageConfig#encryption_config}
    */
    readonly encryptionConfig?: ConnectInstanceStorageConfigS3ConfigEncryptionConfig;
}
export declare function connectInstanceStorageConfigS3ConfigToTerraform(struct?: ConnectInstanceStorageConfigS3Config | cdktn.IResolvable): any;
export declare function connectInstanceStorageConfigS3ConfigToHclTerraform(struct?: ConnectInstanceStorageConfigS3Config | cdktn.IResolvable): any;
export declare class ConnectInstanceStorageConfigS3ConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectInstanceStorageConfigS3Config | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectInstanceStorageConfigS3Config | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    private _encryptionConfig;
    get encryptionConfig(): ConnectInstanceStorageConfigS3ConfigEncryptionConfigOutputReference;
    putEncryptionConfig(value: ConnectInstanceStorageConfigS3ConfigEncryptionConfig): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): cdktn.IResolvable | ConnectInstanceStorageConfigS3ConfigEncryptionConfig | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config awscc_connect_instance_storage_config}
*/
export declare class ConnectInstanceStorageConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_connect_instance_storage_config";
    /**
    * Generates CDKTN code for importing a ConnectInstanceStorageConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectInstanceStorageConfig to import
    * @param importFromId The id of the existing ConnectInstanceStorageConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectInstanceStorageConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/connect_instance_storage_config awscc_connect_instance_storage_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectInstanceStorageConfigConfig
    */
    constructor(scope: Construct, id: string, config: ConnectInstanceStorageConfigConfig);
    get associationId(): string;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _kinesisFirehoseConfig;
    get kinesisFirehoseConfig(): ConnectInstanceStorageConfigKinesisFirehoseConfigOutputReference;
    putKinesisFirehoseConfig(value: ConnectInstanceStorageConfigKinesisFirehoseConfig): void;
    resetKinesisFirehoseConfig(): void;
    get kinesisFirehoseConfigInput(): cdktn.IResolvable | ConnectInstanceStorageConfigKinesisFirehoseConfig | undefined;
    private _kinesisStreamConfig;
    get kinesisStreamConfig(): ConnectInstanceStorageConfigKinesisStreamConfigOutputReference;
    putKinesisStreamConfig(value: ConnectInstanceStorageConfigKinesisStreamConfig): void;
    resetKinesisStreamConfig(): void;
    get kinesisStreamConfigInput(): cdktn.IResolvable | ConnectInstanceStorageConfigKinesisStreamConfig | undefined;
    private _kinesisVideoStreamConfig;
    get kinesisVideoStreamConfig(): ConnectInstanceStorageConfigKinesisVideoStreamConfigOutputReference;
    putKinesisVideoStreamConfig(value: ConnectInstanceStorageConfigKinesisVideoStreamConfig): void;
    resetKinesisVideoStreamConfig(): void;
    get kinesisVideoStreamConfigInput(): cdktn.IResolvable | ConnectInstanceStorageConfigKinesisVideoStreamConfig | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _s3Config;
    get s3Config(): ConnectInstanceStorageConfigS3ConfigOutputReference;
    putS3Config(value: ConnectInstanceStorageConfigS3Config): void;
    resetS3Config(): void;
    get s3ConfigInput(): cdktn.IResolvable | ConnectInstanceStorageConfigS3Config | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    get storageTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
