/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ControltowerEnabledControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Arn of the control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/controltower_enabled_control#control_identifier ControltowerEnabledControl#control_identifier}
    */
    readonly controlIdentifier: string;
    /**
    * Arn for Organizational unit to which the control needs to be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/controltower_enabled_control#target_identifier ControltowerEnabledControl#target_identifier}
    */
    readonly targetIdentifier: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/controltower_enabled_control awscc_controltower_enabled_control}
*/
export declare class ControltowerEnabledControl extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_controltower_enabled_control";
    /**
    * Generates CDKTN code for importing a ControltowerEnabledControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ControltowerEnabledControl to import
    * @param importFromId The id of the existing ControltowerEnabledControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/controltower_enabled_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ControltowerEnabledControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/controltower_enabled_control awscc_controltower_enabled_control} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ControltowerEnabledControlConfig
    */
    constructor(scope: Construct, id: string, config: ControltowerEnabledControlConfig);
    private _controlIdentifier?;
    get controlIdentifier(): string;
    set controlIdentifier(value: string);
    get controlIdentifierInput(): string | undefined;
    get id(): string;
    private _targetIdentifier?;
    get targetIdentifier(): string;
    set targetIdentifier(value: string);
    get targetIdentifierInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
