/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigRemediationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#automatic ConfigRemediationConfiguration#automatic}
    */
    readonly automatic?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#config_rule_name ConfigRemediationConfiguration#config_rule_name}
    */
    readonly configRuleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#execution_controls ConfigRemediationConfiguration#execution_controls}
    */
    readonly executionControls?: ConfigRemediationConfigurationExecutionControls;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#maximum_automatic_attempts ConfigRemediationConfiguration#maximum_automatic_attempts}
    */
    readonly maximumAutomaticAttempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#parameters ConfigRemediationConfiguration#parameters}
    */
    readonly parameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#resource_type ConfigRemediationConfiguration#resource_type}
    */
    readonly resourceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#retry_attempt_seconds ConfigRemediationConfiguration#retry_attempt_seconds}
    */
    readonly retryAttemptSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#target_id ConfigRemediationConfiguration#target_id}
    */
    readonly targetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#target_type ConfigRemediationConfiguration#target_type}
    */
    readonly targetType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#target_version ConfigRemediationConfiguration#target_version}
    */
    readonly targetVersion?: string;
}
export interface ConfigRemediationConfigurationExecutionControlsSsmControls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#concurrent_execution_rate_percentage ConfigRemediationConfiguration#concurrent_execution_rate_percentage}
    */
    readonly concurrentExecutionRatePercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#error_percentage ConfigRemediationConfiguration#error_percentage}
    */
    readonly errorPercentage?: number;
}
export declare function configRemediationConfigurationExecutionControlsSsmControlsToTerraform(struct?: ConfigRemediationConfigurationExecutionControlsSsmControls | cdktn.IResolvable): any;
export declare function configRemediationConfigurationExecutionControlsSsmControlsToHclTerraform(struct?: ConfigRemediationConfigurationExecutionControlsSsmControls | cdktn.IResolvable): any;
export declare class ConfigRemediationConfigurationExecutionControlsSsmControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigRemediationConfigurationExecutionControlsSsmControls | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigRemediationConfigurationExecutionControlsSsmControls | cdktn.IResolvable | undefined);
    private _concurrentExecutionRatePercentage?;
    get concurrentExecutionRatePercentage(): number;
    set concurrentExecutionRatePercentage(value: number);
    resetConcurrentExecutionRatePercentage(): void;
    get concurrentExecutionRatePercentageInput(): number | undefined;
    private _errorPercentage?;
    get errorPercentage(): number;
    set errorPercentage(value: number);
    resetErrorPercentage(): void;
    get errorPercentageInput(): number | undefined;
}
export interface ConfigRemediationConfigurationExecutionControls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#ssm_controls ConfigRemediationConfiguration#ssm_controls}
    */
    readonly ssmControls?: ConfigRemediationConfigurationExecutionControlsSsmControls;
}
export declare function configRemediationConfigurationExecutionControlsToTerraform(struct?: ConfigRemediationConfigurationExecutionControls | cdktn.IResolvable): any;
export declare function configRemediationConfigurationExecutionControlsToHclTerraform(struct?: ConfigRemediationConfigurationExecutionControls | cdktn.IResolvable): any;
export declare class ConfigRemediationConfigurationExecutionControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConfigRemediationConfigurationExecutionControls | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigRemediationConfigurationExecutionControls | cdktn.IResolvable | undefined);
    private _ssmControls;
    get ssmControls(): ConfigRemediationConfigurationExecutionControlsSsmControlsOutputReference;
    putSsmControls(value: ConfigRemediationConfigurationExecutionControlsSsmControls): void;
    resetSsmControls(): void;
    get ssmControlsInput(): cdktn.IResolvable | ConfigRemediationConfigurationExecutionControlsSsmControls | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration awscc_config_remediation_configuration}
*/
export declare class ConfigRemediationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_config_remediation_configuration";
    /**
    * Generates CDKTN code for importing a ConfigRemediationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConfigRemediationConfiguration to import
    * @param importFromId The id of the existing ConfigRemediationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConfigRemediationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/config_remediation_configuration awscc_config_remediation_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigRemediationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: ConfigRemediationConfigurationConfig);
    private _automatic?;
    get automatic(): boolean | cdktn.IResolvable;
    set automatic(value: boolean | cdktn.IResolvable);
    resetAutomatic(): void;
    get automaticInput(): boolean | cdktn.IResolvable | undefined;
    private _configRuleName?;
    get configRuleName(): string;
    set configRuleName(value: string);
    get configRuleNameInput(): string | undefined;
    private _executionControls;
    get executionControls(): ConfigRemediationConfigurationExecutionControlsOutputReference;
    putExecutionControls(value: ConfigRemediationConfigurationExecutionControls): void;
    resetExecutionControls(): void;
    get executionControlsInput(): cdktn.IResolvable | ConfigRemediationConfigurationExecutionControls | undefined;
    get id(): string;
    private _maximumAutomaticAttempts?;
    get maximumAutomaticAttempts(): number;
    set maximumAutomaticAttempts(value: number);
    resetMaximumAutomaticAttempts(): void;
    get maximumAutomaticAttemptsInput(): number | undefined;
    private _parameters?;
    get parameters(): string;
    set parameters(value: string);
    resetParameters(): void;
    get parametersInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _retryAttemptSeconds?;
    get retryAttemptSeconds(): number;
    set retryAttemptSeconds(value: number);
    resetRetryAttemptSeconds(): void;
    get retryAttemptSecondsInput(): number | undefined;
    private _targetId?;
    get targetId(): string;
    set targetId(value: string);
    get targetIdInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
    private _targetVersion?;
    get targetVersion(): string;
    set targetVersion(value: string);
    resetTargetVersion(): void;
    get targetVersionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
