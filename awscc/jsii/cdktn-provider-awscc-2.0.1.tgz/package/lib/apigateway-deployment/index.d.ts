/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApigatewayDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ``DeploymentCanarySettings`` property type specifies settings for the canary deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#deployment_canary_settings ApigatewayDeployment#deployment_canary_settings}
    */
    readonly deploymentCanarySettings?: ApigatewayDeploymentDeploymentCanarySettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#description ApigatewayDeployment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#rest_api_id ApigatewayDeployment#rest_api_id}
    */
    readonly restApiId: string;
    /**
    * The description of the Stage resource for the Deployment resource to create. To specify a stage description, you must also provide a stage name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#stage_description ApigatewayDeployment#stage_description}
    */
    readonly stageDescription?: ApigatewayDeploymentStageDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#stage_name ApigatewayDeployment#stage_name}
    */
    readonly stageName?: string;
}
export interface ApigatewayDeploymentDeploymentCanarySettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#percent_traffic ApigatewayDeployment#percent_traffic}
    */
    readonly percentTraffic?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#stage_variable_overrides ApigatewayDeployment#stage_variable_overrides}
    */
    readonly stageVariableOverrides?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#use_stage_cache ApigatewayDeployment#use_stage_cache}
    */
    readonly useStageCache?: boolean | cdktn.IResolvable;
}
export declare function apigatewayDeploymentDeploymentCanarySettingsToTerraform(struct?: ApigatewayDeploymentDeploymentCanarySettings | cdktn.IResolvable): any;
export declare function apigatewayDeploymentDeploymentCanarySettingsToHclTerraform(struct?: ApigatewayDeploymentDeploymentCanarySettings | cdktn.IResolvable): any;
export declare class ApigatewayDeploymentDeploymentCanarySettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayDeploymentDeploymentCanarySettings | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDeploymentDeploymentCanarySettings | cdktn.IResolvable | undefined);
    private _percentTraffic?;
    get percentTraffic(): number;
    set percentTraffic(value: number);
    resetPercentTraffic(): void;
    get percentTrafficInput(): number | undefined;
    private _stageVariableOverrides?;
    get stageVariableOverrides(): {
        [key: string]: string;
    };
    set stageVariableOverrides(value: {
        [key: string]: string;
    });
    resetStageVariableOverrides(): void;
    get stageVariableOverridesInput(): {
        [key: string]: string;
    } | undefined;
    private _useStageCache?;
    get useStageCache(): boolean | cdktn.IResolvable;
    set useStageCache(value: boolean | cdktn.IResolvable);
    resetUseStageCache(): void;
    get useStageCacheInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApigatewayDeploymentStageDescriptionAccessLogSetting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#destination_arn ApigatewayDeployment#destination_arn}
    */
    readonly destinationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#format ApigatewayDeployment#format}
    */
    readonly format?: string;
}
export declare function apigatewayDeploymentStageDescriptionAccessLogSettingToTerraform(struct?: ApigatewayDeploymentStageDescriptionAccessLogSetting | cdktn.IResolvable): any;
export declare function apigatewayDeploymentStageDescriptionAccessLogSettingToHclTerraform(struct?: ApigatewayDeploymentStageDescriptionAccessLogSetting | cdktn.IResolvable): any;
export declare class ApigatewayDeploymentStageDescriptionAccessLogSettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayDeploymentStageDescriptionAccessLogSetting | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDeploymentStageDescriptionAccessLogSetting | cdktn.IResolvable | undefined);
    private _destinationArn?;
    get destinationArn(): string;
    set destinationArn(value: string);
    resetDestinationArn(): void;
    get destinationArnInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
}
export interface ApigatewayDeploymentStageDescriptionCanarySetting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#percent_traffic ApigatewayDeployment#percent_traffic}
    */
    readonly percentTraffic?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#stage_variable_overrides ApigatewayDeployment#stage_variable_overrides}
    */
    readonly stageVariableOverrides?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#use_stage_cache ApigatewayDeployment#use_stage_cache}
    */
    readonly useStageCache?: boolean | cdktn.IResolvable;
}
export declare function apigatewayDeploymentStageDescriptionCanarySettingToTerraform(struct?: ApigatewayDeploymentStageDescriptionCanarySetting | cdktn.IResolvable): any;
export declare function apigatewayDeploymentStageDescriptionCanarySettingToHclTerraform(struct?: ApigatewayDeploymentStageDescriptionCanarySetting | cdktn.IResolvable): any;
export declare class ApigatewayDeploymentStageDescriptionCanarySettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayDeploymentStageDescriptionCanarySetting | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDeploymentStageDescriptionCanarySetting | cdktn.IResolvable | undefined);
    private _percentTraffic?;
    get percentTraffic(): number;
    set percentTraffic(value: number);
    resetPercentTraffic(): void;
    get percentTrafficInput(): number | undefined;
    private _stageVariableOverrides?;
    get stageVariableOverrides(): {
        [key: string]: string;
    };
    set stageVariableOverrides(value: {
        [key: string]: string;
    });
    resetStageVariableOverrides(): void;
    get stageVariableOverridesInput(): {
        [key: string]: string;
    } | undefined;
    private _useStageCache?;
    get useStageCache(): boolean | cdktn.IResolvable;
    set useStageCache(value: boolean | cdktn.IResolvable);
    resetUseStageCache(): void;
    get useStageCacheInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApigatewayDeploymentStageDescriptionMethodSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#cache_data_encrypted ApigatewayDeployment#cache_data_encrypted}
    */
    readonly cacheDataEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#cache_ttl_in_seconds ApigatewayDeployment#cache_ttl_in_seconds}
    */
    readonly cacheTtlInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#caching_enabled ApigatewayDeployment#caching_enabled}
    */
    readonly cachingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#data_trace_enabled ApigatewayDeployment#data_trace_enabled}
    */
    readonly dataTraceEnabled?: boolean | cdktn.IResolvable;
    /**
    * The HTTP method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#http_method ApigatewayDeployment#http_method}
    */
    readonly httpMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#logging_level ApigatewayDeployment#logging_level}
    */
    readonly loggingLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#metrics_enabled ApigatewayDeployment#metrics_enabled}
    */
    readonly metricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * The resource path for this method. Forward slashes (``/``) are encoded as ``~1`` and the initial slash must include a forward slash. For example, the path value ``/resource/subresource`` must be encoded as ``/~1resource~1subresource``. To specify the root path, use only a slash (``/``).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#resource_path ApigatewayDeployment#resource_path}
    */
    readonly resourcePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#throttling_burst_limit ApigatewayDeployment#throttling_burst_limit}
    */
    readonly throttlingBurstLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#throttling_rate_limit ApigatewayDeployment#throttling_rate_limit}
    */
    readonly throttlingRateLimit?: number;
}
export declare function apigatewayDeploymentStageDescriptionMethodSettingsToTerraform(struct?: ApigatewayDeploymentStageDescriptionMethodSettings | cdktn.IResolvable): any;
export declare function apigatewayDeploymentStageDescriptionMethodSettingsToHclTerraform(struct?: ApigatewayDeploymentStageDescriptionMethodSettings | cdktn.IResolvable): any;
export declare class ApigatewayDeploymentStageDescriptionMethodSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayDeploymentStageDescriptionMethodSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDeploymentStageDescriptionMethodSettings | cdktn.IResolvable | undefined);
    private _cacheDataEncrypted?;
    get cacheDataEncrypted(): boolean | cdktn.IResolvable;
    set cacheDataEncrypted(value: boolean | cdktn.IResolvable);
    resetCacheDataEncrypted(): void;
    get cacheDataEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheTtlInSeconds?;
    get cacheTtlInSeconds(): number;
    set cacheTtlInSeconds(value: number);
    resetCacheTtlInSeconds(): void;
    get cacheTtlInSecondsInput(): number | undefined;
    private _cachingEnabled?;
    get cachingEnabled(): boolean | cdktn.IResolvable;
    set cachingEnabled(value: boolean | cdktn.IResolvable);
    resetCachingEnabled(): void;
    get cachingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _dataTraceEnabled?;
    get dataTraceEnabled(): boolean | cdktn.IResolvable;
    set dataTraceEnabled(value: boolean | cdktn.IResolvable);
    resetDataTraceEnabled(): void;
    get dataTraceEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _httpMethod?;
    get httpMethod(): string;
    set httpMethod(value: string);
    resetHttpMethod(): void;
    get httpMethodInput(): string | undefined;
    private _loggingLevel?;
    get loggingLevel(): string;
    set loggingLevel(value: string);
    resetLoggingLevel(): void;
    get loggingLevelInput(): string | undefined;
    private _metricsEnabled?;
    get metricsEnabled(): boolean | cdktn.IResolvable;
    set metricsEnabled(value: boolean | cdktn.IResolvable);
    resetMetricsEnabled(): void;
    get metricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _resourcePath?;
    get resourcePath(): string;
    set resourcePath(value: string);
    resetResourcePath(): void;
    get resourcePathInput(): string | undefined;
    private _throttlingBurstLimit?;
    get throttlingBurstLimit(): number;
    set throttlingBurstLimit(value: number);
    resetThrottlingBurstLimit(): void;
    get throttlingBurstLimitInput(): number | undefined;
    private _throttlingRateLimit?;
    get throttlingRateLimit(): number;
    set throttlingRateLimit(value: number);
    resetThrottlingRateLimit(): void;
    get throttlingRateLimitInput(): number | undefined;
}
export declare class ApigatewayDeploymentStageDescriptionMethodSettingsList extends cdktn.ComplexList {
    internalValue?: ApigatewayDeploymentStageDescriptionMethodSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayDeploymentStageDescriptionMethodSettingsOutputReference;
}
export interface ApigatewayDeploymentStageDescriptionTags {
    /**
    * A string you can use to assign a value. The combination of tag keys and values can help you organize and categorize your resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#key ApigatewayDeployment#key}
    */
    readonly key?: string;
    /**
    * The value for the specified tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#value ApigatewayDeployment#value}
    */
    readonly value?: string;
}
export declare function apigatewayDeploymentStageDescriptionTagsToTerraform(struct?: ApigatewayDeploymentStageDescriptionTags | cdktn.IResolvable): any;
export declare function apigatewayDeploymentStageDescriptionTagsToHclTerraform(struct?: ApigatewayDeploymentStageDescriptionTags | cdktn.IResolvable): any;
export declare class ApigatewayDeploymentStageDescriptionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayDeploymentStageDescriptionTags | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDeploymentStageDescriptionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ApigatewayDeploymentStageDescriptionTagsList extends cdktn.ComplexList {
    internalValue?: ApigatewayDeploymentStageDescriptionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayDeploymentStageDescriptionTagsOutputReference;
}
export interface ApigatewayDeploymentStageDescription {
    /**
    * Specifies settings for logging access in this stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#access_log_setting ApigatewayDeployment#access_log_setting}
    */
    readonly accessLogSetting?: ApigatewayDeploymentStageDescriptionAccessLogSetting;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#cache_cluster_enabled ApigatewayDeployment#cache_cluster_enabled}
    */
    readonly cacheClusterEnabled?: boolean | cdktn.IResolvable;
    /**
    * The size of the stage's cache cluster. For more information, see [cacheClusterSize](https://docs.aws.amazon.com/apigateway/latest/api/API_CreateStage.html#apigw-CreateStage-request-cacheClusterSize) in the *API Gateway API Reference*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#cache_cluster_size ApigatewayDeployment#cache_cluster_size}
    */
    readonly cacheClusterSize?: string;
    /**
    * Indicates whether the cached responses are encrypted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#cache_data_encrypted ApigatewayDeployment#cache_data_encrypted}
    */
    readonly cacheDataEncrypted?: boolean | cdktn.IResolvable;
    /**
    * The time-to-live (TTL) period, in seconds, that specifies how long API Gateway caches responses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#cache_ttl_in_seconds ApigatewayDeployment#cache_ttl_in_seconds}
    */
    readonly cacheTtlInSeconds?: number;
    /**
    * Indicates whether responses are cached and returned for requests. You must enable a cache cluster on the stage to cache responses. For more information, see [Enable API Gateway Caching in a Stage to Enhance API Performance](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-caching.html) in the *API Gateway Developer Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#caching_enabled ApigatewayDeployment#caching_enabled}
    */
    readonly cachingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Specifies settings for the canary deployment in this stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#canary_setting ApigatewayDeployment#canary_setting}
    */
    readonly canarySetting?: ApigatewayDeploymentStageDescriptionCanarySetting;
    /**
    * The identifier of the client certificate that API Gateway uses to call your integration endpoints in the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#client_certificate_id ApigatewayDeployment#client_certificate_id}
    */
    readonly clientCertificateId?: string;
    /**
    * Indicates whether data trace logging is enabled for methods in the stage. API Gateway pushes these logs to Amazon CloudWatch Logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#data_trace_enabled ApigatewayDeployment#data_trace_enabled}
    */
    readonly dataTraceEnabled?: boolean | cdktn.IResolvable;
    /**
    * A description of the purpose of the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#description ApigatewayDeployment#description}
    */
    readonly description?: string;
    /**
    * The version identifier of the API documentation snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#documentation_version ApigatewayDeployment#documentation_version}
    */
    readonly documentationVersion?: string;
    /**
    * The logging level for this method. For valid values, see the ``loggingLevel`` property of the [MethodSetting](https://docs.aws.amazon.com/apigateway/latest/api/API_MethodSetting.html) resource in the *Amazon API Gateway API Reference*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#logging_level ApigatewayDeployment#logging_level}
    */
    readonly loggingLevel?: string;
    /**
    * Configures settings for all of the stage's methods.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#method_settings ApigatewayDeployment#method_settings}
    */
    readonly methodSettings?: ApigatewayDeploymentStageDescriptionMethodSettings[] | cdktn.IResolvable;
    /**
    * Indicates whether Amazon CloudWatch metrics are enabled for methods in the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#metrics_enabled ApigatewayDeployment#metrics_enabled}
    */
    readonly metricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * An array of arbitrary tags (key-value pairs) to associate with the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#tags ApigatewayDeployment#tags}
    */
    readonly tags?: ApigatewayDeploymentStageDescriptionTags[] | cdktn.IResolvable;
    /**
    * The target request burst rate limit. This allows more requests through for a period of time than the target rate limit. For more information, see [Manage API Request Throttling](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-request-throttling.html) in the *API Gateway Developer Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#throttling_burst_limit ApigatewayDeployment#throttling_burst_limit}
    */
    readonly throttlingBurstLimit?: number;
    /**
    * The target request steady-state rate limit. For more information, see [Manage API Request Throttling](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-request-throttling.html) in the *API Gateway Developer Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#throttling_rate_limit ApigatewayDeployment#throttling_rate_limit}
    */
    readonly throttlingRateLimit?: number;
    /**
    * Specifies whether active tracing with X-ray is enabled for this stage.
    *  For more information, see [Trace API Gateway API Execution with X-Ray](https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-xray.html) in the *API Gateway Developer Guide*.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#tracing_enabled ApigatewayDeployment#tracing_enabled}
    */
    readonly tracingEnabled?: boolean | cdktn.IResolvable;
    /**
    * A map that defines the stage variables. Variable names must consist of alphanumeric characters, and the values must match the following regular expression: ``[A-Za-z0-9-._~:/?#&=,]+``.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#variables ApigatewayDeployment#variables}
    */
    readonly variables?: {
        [key: string]: string;
    };
}
export declare function apigatewayDeploymentStageDescriptionToTerraform(struct?: ApigatewayDeploymentStageDescription | cdktn.IResolvable): any;
export declare function apigatewayDeploymentStageDescriptionToHclTerraform(struct?: ApigatewayDeploymentStageDescription | cdktn.IResolvable): any;
export declare class ApigatewayDeploymentStageDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayDeploymentStageDescription | cdktn.IResolvable | undefined;
    set internalValue(value: ApigatewayDeploymentStageDescription | cdktn.IResolvable | undefined);
    private _accessLogSetting;
    get accessLogSetting(): ApigatewayDeploymentStageDescriptionAccessLogSettingOutputReference;
    putAccessLogSetting(value: ApigatewayDeploymentStageDescriptionAccessLogSetting): void;
    resetAccessLogSetting(): void;
    get accessLogSettingInput(): cdktn.IResolvable | ApigatewayDeploymentStageDescriptionAccessLogSetting | undefined;
    private _cacheClusterEnabled?;
    get cacheClusterEnabled(): boolean | cdktn.IResolvable;
    set cacheClusterEnabled(value: boolean | cdktn.IResolvable);
    resetCacheClusterEnabled(): void;
    get cacheClusterEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheClusterSize?;
    get cacheClusterSize(): string;
    set cacheClusterSize(value: string);
    resetCacheClusterSize(): void;
    get cacheClusterSizeInput(): string | undefined;
    private _cacheDataEncrypted?;
    get cacheDataEncrypted(): boolean | cdktn.IResolvable;
    set cacheDataEncrypted(value: boolean | cdktn.IResolvable);
    resetCacheDataEncrypted(): void;
    get cacheDataEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheTtlInSeconds?;
    get cacheTtlInSeconds(): number;
    set cacheTtlInSeconds(value: number);
    resetCacheTtlInSeconds(): void;
    get cacheTtlInSecondsInput(): number | undefined;
    private _cachingEnabled?;
    get cachingEnabled(): boolean | cdktn.IResolvable;
    set cachingEnabled(value: boolean | cdktn.IResolvable);
    resetCachingEnabled(): void;
    get cachingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _canarySetting;
    get canarySetting(): ApigatewayDeploymentStageDescriptionCanarySettingOutputReference;
    putCanarySetting(value: ApigatewayDeploymentStageDescriptionCanarySetting): void;
    resetCanarySetting(): void;
    get canarySettingInput(): cdktn.IResolvable | ApigatewayDeploymentStageDescriptionCanarySetting | undefined;
    private _clientCertificateId?;
    get clientCertificateId(): string;
    set clientCertificateId(value: string);
    resetClientCertificateId(): void;
    get clientCertificateIdInput(): string | undefined;
    private _dataTraceEnabled?;
    get dataTraceEnabled(): boolean | cdktn.IResolvable;
    set dataTraceEnabled(value: boolean | cdktn.IResolvable);
    resetDataTraceEnabled(): void;
    get dataTraceEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _documentationVersion?;
    get documentationVersion(): string;
    set documentationVersion(value: string);
    resetDocumentationVersion(): void;
    get documentationVersionInput(): string | undefined;
    private _loggingLevel?;
    get loggingLevel(): string;
    set loggingLevel(value: string);
    resetLoggingLevel(): void;
    get loggingLevelInput(): string | undefined;
    private _methodSettings;
    get methodSettings(): ApigatewayDeploymentStageDescriptionMethodSettingsList;
    putMethodSettings(value: ApigatewayDeploymentStageDescriptionMethodSettings[] | cdktn.IResolvable): void;
    resetMethodSettings(): void;
    get methodSettingsInput(): cdktn.IResolvable | ApigatewayDeploymentStageDescriptionMethodSettings[] | undefined;
    private _metricsEnabled?;
    get metricsEnabled(): boolean | cdktn.IResolvable;
    set metricsEnabled(value: boolean | cdktn.IResolvable);
    resetMetricsEnabled(): void;
    get metricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tags;
    get tags(): ApigatewayDeploymentStageDescriptionTagsList;
    putTags(value: ApigatewayDeploymentStageDescriptionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ApigatewayDeploymentStageDescriptionTags[] | undefined;
    private _throttlingBurstLimit?;
    get throttlingBurstLimit(): number;
    set throttlingBurstLimit(value: number);
    resetThrottlingBurstLimit(): void;
    get throttlingBurstLimitInput(): number | undefined;
    private _throttlingRateLimit?;
    get throttlingRateLimit(): number;
    set throttlingRateLimit(value: number);
    resetThrottlingRateLimit(): void;
    get throttlingRateLimitInput(): number | undefined;
    private _tracingEnabled?;
    get tracingEnabled(): boolean | cdktn.IResolvable;
    set tracingEnabled(value: boolean | cdktn.IResolvable);
    resetTracingEnabled(): void;
    get tracingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _variables?;
    get variables(): {
        [key: string]: string;
    };
    set variables(value: {
        [key: string]: string;
    });
    resetVariables(): void;
    get variablesInput(): {
        [key: string]: string;
    } | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment awscc_apigateway_deployment}
*/
export declare class ApigatewayDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_apigateway_deployment";
    /**
    * Generates CDKTN code for importing a ApigatewayDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayDeployment to import
    * @param importFromId The id of the existing ApigatewayDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/apigateway_deployment awscc_apigateway_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: ApigatewayDeploymentConfig);
    private _deploymentCanarySettings;
    get deploymentCanarySettings(): ApigatewayDeploymentDeploymentCanarySettingsOutputReference;
    putDeploymentCanarySettings(value: ApigatewayDeploymentDeploymentCanarySettings): void;
    resetDeploymentCanarySettings(): void;
    get deploymentCanarySettingsInput(): cdktn.IResolvable | ApigatewayDeploymentDeploymentCanarySettings | undefined;
    get deploymentId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _restApiId?;
    get restApiId(): string;
    set restApiId(value: string);
    get restApiIdInput(): string | undefined;
    private _stageDescription;
    get stageDescription(): ApigatewayDeploymentStageDescriptionOutputReference;
    putStageDescription(value: ApigatewayDeploymentStageDescription): void;
    resetStageDescription(): void;
    get stageDescriptionInput(): cdktn.IResolvable | ApigatewayDeploymentStageDescription | undefined;
    private _stageName?;
    get stageName(): string;
    set stageName(value: string);
    resetStageName(): void;
    get stageNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
