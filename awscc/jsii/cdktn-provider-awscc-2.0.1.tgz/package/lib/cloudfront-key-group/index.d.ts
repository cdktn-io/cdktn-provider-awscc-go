/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontKeyGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The key group configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_key_group#key_group_config CloudfrontKeyGroup#key_group_config}
    */
    readonly keyGroupConfig: CloudfrontKeyGroupKeyGroupConfig;
}
export interface CloudfrontKeyGroupKeyGroupConfig {
    /**
    * A comment to describe the key group. The comment cannot be longer than 128 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_key_group#comment CloudfrontKeyGroup#comment}
    */
    readonly comment?: string;
    /**
    * A list of the identifiers of the public keys in the key group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_key_group#items CloudfrontKeyGroup#items}
    */
    readonly items: string[];
    /**
    * A name to identify the key group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_key_group#name CloudfrontKeyGroup#name}
    */
    readonly name: string;
}
export declare function cloudfrontKeyGroupKeyGroupConfigToTerraform(struct?: CloudfrontKeyGroupKeyGroupConfig | cdktn.IResolvable): any;
export declare function cloudfrontKeyGroupKeyGroupConfigToHclTerraform(struct?: CloudfrontKeyGroupKeyGroupConfig | cdktn.IResolvable): any;
export declare class CloudfrontKeyGroupKeyGroupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontKeyGroupKeyGroupConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontKeyGroupKeyGroupConfig | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _items?;
    get items(): string[];
    set items(value: string[]);
    get itemsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_key_group awscc_cloudfront_key_group}
*/
export declare class CloudfrontKeyGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudfront_key_group";
    /**
    * Generates CDKTN code for importing a CloudfrontKeyGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontKeyGroup to import
    * @param importFromId The id of the existing CloudfrontKeyGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_key_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontKeyGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudfront_key_group awscc_cloudfront_key_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontKeyGroupConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontKeyGroupConfig);
    get id(): string;
    private _keyGroupConfig;
    get keyGroupConfig(): CloudfrontKeyGroupKeyGroupConfigOutputReference;
    putKeyGroupConfig(value: CloudfrontKeyGroupKeyGroupConfig): void;
    get keyGroupConfigInput(): cdktn.IResolvable | CloudfrontKeyGroupKeyGroupConfig | undefined;
    get keyGroupId(): string;
    get lastModifiedTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
