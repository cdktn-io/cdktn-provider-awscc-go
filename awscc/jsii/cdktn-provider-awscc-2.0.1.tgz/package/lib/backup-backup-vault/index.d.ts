/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupBackupVaultConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#access_policy BackupBackupVault#access_policy}
    */
    readonly accessPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#backup_vault_name BackupBackupVault#backup_vault_name}
    */
    readonly backupVaultName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#backup_vault_tags BackupBackupVault#backup_vault_tags}
    */
    readonly backupVaultTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#encryption_key_arn BackupBackupVault#encryption_key_arn}
    */
    readonly encryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#lock_configuration BackupBackupVault#lock_configuration}
    */
    readonly lockConfiguration?: BackupBackupVaultLockConfiguration;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#notifications BackupBackupVault#notifications}
    */
    readonly notifications?: BackupBackupVaultNotifications;
}
export interface BackupBackupVaultLockConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#changeable_for_days BackupBackupVault#changeable_for_days}
    */
    readonly changeableForDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#max_retention_days BackupBackupVault#max_retention_days}
    */
    readonly maxRetentionDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#min_retention_days BackupBackupVault#min_retention_days}
    */
    readonly minRetentionDays?: number;
}
export declare function backupBackupVaultLockConfigurationToTerraform(struct?: BackupBackupVaultLockConfiguration | cdktn.IResolvable): any;
export declare function backupBackupVaultLockConfigurationToHclTerraform(struct?: BackupBackupVaultLockConfiguration | cdktn.IResolvable): any;
export declare class BackupBackupVaultLockConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupBackupVaultLockConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupVaultLockConfiguration | cdktn.IResolvable | undefined);
    private _changeableForDays?;
    get changeableForDays(): number;
    set changeableForDays(value: number);
    resetChangeableForDays(): void;
    get changeableForDaysInput(): number | undefined;
    private _maxRetentionDays?;
    get maxRetentionDays(): number;
    set maxRetentionDays(value: number);
    resetMaxRetentionDays(): void;
    get maxRetentionDaysInput(): number | undefined;
    private _minRetentionDays?;
    get minRetentionDays(): number;
    set minRetentionDays(value: number);
    resetMinRetentionDays(): void;
    get minRetentionDaysInput(): number | undefined;
}
export interface BackupBackupVaultNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#backup_vault_events BackupBackupVault#backup_vault_events}
    */
    readonly backupVaultEvents?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#sns_topic_arn BackupBackupVault#sns_topic_arn}
    */
    readonly snsTopicArn?: string;
}
export declare function backupBackupVaultNotificationsToTerraform(struct?: BackupBackupVaultNotifications | cdktn.IResolvable): any;
export declare function backupBackupVaultNotificationsToHclTerraform(struct?: BackupBackupVaultNotifications | cdktn.IResolvable): any;
export declare class BackupBackupVaultNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupBackupVaultNotifications | cdktn.IResolvable | undefined;
    set internalValue(value: BackupBackupVaultNotifications | cdktn.IResolvable | undefined);
    private _backupVaultEvents?;
    get backupVaultEvents(): string[];
    set backupVaultEvents(value: string[]);
    resetBackupVaultEvents(): void;
    get backupVaultEventsInput(): string[] | undefined;
    private _snsTopicArn?;
    get snsTopicArn(): string;
    set snsTopicArn(value: string);
    resetSnsTopicArn(): void;
    get snsTopicArnInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault awscc_backup_backup_vault}
*/
export declare class BackupBackupVault extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_backup_backup_vault";
    /**
    * Generates CDKTN code for importing a BackupBackupVault resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupBackupVault to import
    * @param importFromId The id of the existing BackupBackupVault that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupBackupVault to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/backup_backup_vault awscc_backup_backup_vault} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupBackupVaultConfig
    */
    constructor(scope: Construct, id: string, config: BackupBackupVaultConfig);
    private _accessPolicy?;
    get accessPolicy(): string;
    set accessPolicy(value: string);
    resetAccessPolicy(): void;
    get accessPolicyInput(): string | undefined;
    get backupVaultArn(): string;
    private _backupVaultName?;
    get backupVaultName(): string;
    set backupVaultName(value: string);
    get backupVaultNameInput(): string | undefined;
    private _backupVaultTags?;
    get backupVaultTags(): {
        [key: string]: string;
    };
    set backupVaultTags(value: {
        [key: string]: string;
    });
    resetBackupVaultTags(): void;
    get backupVaultTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _encryptionKeyArn?;
    get encryptionKeyArn(): string;
    set encryptionKeyArn(value: string);
    resetEncryptionKeyArn(): void;
    get encryptionKeyArnInput(): string | undefined;
    get id(): string;
    private _lockConfiguration;
    get lockConfiguration(): BackupBackupVaultLockConfigurationOutputReference;
    putLockConfiguration(value: BackupBackupVaultLockConfiguration): void;
    resetLockConfiguration(): void;
    get lockConfigurationInput(): cdktn.IResolvable | BackupBackupVaultLockConfiguration | undefined;
    private _notifications;
    get notifications(): BackupBackupVaultNotificationsOutputReference;
    putNotifications(value: BackupBackupVaultNotifications): void;
    resetNotifications(): void;
    get notificationsInput(): cdktn.IResolvable | BackupBackupVaultNotifications | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
