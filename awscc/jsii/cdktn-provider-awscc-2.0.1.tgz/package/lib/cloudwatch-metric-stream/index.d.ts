/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchMetricStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Define which metrics will be not streamed. Metrics matched by multiple instances of MetricStreamFilter are joined with an OR operation by default. If both IncludeFilters and ExcludeFilters are omitted, all metrics in the account will be streamed. IncludeFilters and ExcludeFilters are mutually exclusive. Default to null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#exclude_filters CloudwatchMetricStream#exclude_filters}
    */
    readonly excludeFilters?: CloudwatchMetricStreamExcludeFilters[] | cdktn.IResolvable;
    /**
    * The ARN of the Kinesis Firehose where to stream the data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#firehose_arn CloudwatchMetricStream#firehose_arn}
    */
    readonly firehoseArn?: string;
    /**
    * Define which metrics will be streamed. Metrics matched by multiple instances of MetricStreamFilter are joined with an OR operation by default. If both IncludeFilters and ExcludeFilters are omitted, all metrics in the account will be streamed. IncludeFilters and ExcludeFilters are mutually exclusive. Default to null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#include_filters CloudwatchMetricStream#include_filters}
    */
    readonly includeFilters?: CloudwatchMetricStreamIncludeFilters[] | cdktn.IResolvable;
    /**
    * If you are creating a metric stream in a monitoring account, specify true to include metrics from source accounts that are linked to this monitoring account, in the metric stream. The default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#include_linked_accounts_metrics CloudwatchMetricStream#include_linked_accounts_metrics}
    */
    readonly includeLinkedAccountsMetrics?: boolean | cdktn.IResolvable;
    /**
    * Name of the metric stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#name CloudwatchMetricStream#name}
    */
    readonly name?: string;
    /**
    * The output format of the data streamed to the Kinesis Firehose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#output_format CloudwatchMetricStream#output_format}
    */
    readonly outputFormat?: string;
    /**
    * The ARN of the role that provides access to the Kinesis Firehose.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#role_arn CloudwatchMetricStream#role_arn}
    */
    readonly roleArn?: string;
    /**
    * By default, a metric stream always sends the MAX, MIN, SUM, and SAMPLECOUNT statistics for each metric that is streamed. You can use this parameter to have the metric stream also send additional statistics in the stream. This array can have up to 100 members.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#statistics_configurations CloudwatchMetricStream#statistics_configurations}
    */
    readonly statisticsConfigurations?: CloudwatchMetricStreamStatisticsConfigurations[] | cdktn.IResolvable;
    /**
    * A set of tags to assign to the delivery stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#tags CloudwatchMetricStream#tags}
    */
    readonly tags?: CloudwatchMetricStreamTags[] | cdktn.IResolvable;
}
export interface CloudwatchMetricStreamExcludeFilters {
    /**
    * Only metrics with MetricNames matching these values will be streamed. Must be set together with Namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#metric_names CloudwatchMetricStream#metric_names}
    */
    readonly metricNames?: string[];
    /**
    * Only metrics with Namespace matching this value will be streamed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#namespace CloudwatchMetricStream#namespace}
    */
    readonly namespace?: string;
}
export declare function cloudwatchMetricStreamExcludeFiltersToTerraform(struct?: CloudwatchMetricStreamExcludeFilters | cdktn.IResolvable): any;
export declare function cloudwatchMetricStreamExcludeFiltersToHclTerraform(struct?: CloudwatchMetricStreamExcludeFilters | cdktn.IResolvable): any;
export declare class CloudwatchMetricStreamExcludeFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchMetricStreamExcludeFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchMetricStreamExcludeFilters | cdktn.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    resetMetricNames(): void;
    get metricNamesInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class CloudwatchMetricStreamExcludeFiltersList extends cdktn.ComplexList {
    internalValue?: CloudwatchMetricStreamExcludeFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchMetricStreamExcludeFiltersOutputReference;
}
export interface CloudwatchMetricStreamIncludeFilters {
    /**
    * Only metrics with MetricNames matching these values will be streamed. Must be set together with Namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#metric_names CloudwatchMetricStream#metric_names}
    */
    readonly metricNames?: string[];
    /**
    * Only metrics with Namespace matching this value will be streamed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#namespace CloudwatchMetricStream#namespace}
    */
    readonly namespace?: string;
}
export declare function cloudwatchMetricStreamIncludeFiltersToTerraform(struct?: CloudwatchMetricStreamIncludeFilters | cdktn.IResolvable): any;
export declare function cloudwatchMetricStreamIncludeFiltersToHclTerraform(struct?: CloudwatchMetricStreamIncludeFilters | cdktn.IResolvable): any;
export declare class CloudwatchMetricStreamIncludeFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchMetricStreamIncludeFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchMetricStreamIncludeFilters | cdktn.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    resetMetricNames(): void;
    get metricNamesInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class CloudwatchMetricStreamIncludeFiltersList extends cdktn.ComplexList {
    internalValue?: CloudwatchMetricStreamIncludeFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchMetricStreamIncludeFiltersOutputReference;
}
export interface CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics {
    /**
    * The name of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#metric_name CloudwatchMetricStream#metric_name}
    */
    readonly metricName?: string;
    /**
    * The namespace of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#namespace CloudwatchMetricStream#namespace}
    */
    readonly namespace?: string;
}
export declare function cloudwatchMetricStreamStatisticsConfigurationsIncludeMetricsToTerraform(struct?: CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics | cdktn.IResolvable): any;
export declare function cloudwatchMetricStreamStatisticsConfigurationsIncludeMetricsToHclTerraform(struct?: CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics | cdktn.IResolvable): any;
export declare class CloudwatchMetricStreamStatisticsConfigurationsIncludeMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics | cdktn.IResolvable | undefined);
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class CloudwatchMetricStreamStatisticsConfigurationsIncludeMetricsList extends cdktn.ComplexList {
    internalValue?: CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchMetricStreamStatisticsConfigurationsIncludeMetricsOutputReference;
}
export interface CloudwatchMetricStreamStatisticsConfigurations {
    /**
    * The additional statistics to stream for the metrics listed in IncludeMetrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#additional_statistics CloudwatchMetricStream#additional_statistics}
    */
    readonly additionalStatistics?: string[];
    /**
    * An array that defines the metrics that are to have additional statistics streamed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#include_metrics CloudwatchMetricStream#include_metrics}
    */
    readonly includeMetrics?: CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics[] | cdktn.IResolvable;
}
export declare function cloudwatchMetricStreamStatisticsConfigurationsToTerraform(struct?: CloudwatchMetricStreamStatisticsConfigurations | cdktn.IResolvable): any;
export declare function cloudwatchMetricStreamStatisticsConfigurationsToHclTerraform(struct?: CloudwatchMetricStreamStatisticsConfigurations | cdktn.IResolvable): any;
export declare class CloudwatchMetricStreamStatisticsConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchMetricStreamStatisticsConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchMetricStreamStatisticsConfigurations | cdktn.IResolvable | undefined);
    private _additionalStatistics?;
    get additionalStatistics(): string[];
    set additionalStatistics(value: string[]);
    resetAdditionalStatistics(): void;
    get additionalStatisticsInput(): string[] | undefined;
    private _includeMetrics;
    get includeMetrics(): CloudwatchMetricStreamStatisticsConfigurationsIncludeMetricsList;
    putIncludeMetrics(value: CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics[] | cdktn.IResolvable): void;
    resetIncludeMetrics(): void;
    get includeMetricsInput(): cdktn.IResolvable | CloudwatchMetricStreamStatisticsConfigurationsIncludeMetrics[] | undefined;
}
export declare class CloudwatchMetricStreamStatisticsConfigurationsList extends cdktn.ComplexList {
    internalValue?: CloudwatchMetricStreamStatisticsConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchMetricStreamStatisticsConfigurationsOutputReference;
}
export interface CloudwatchMetricStreamTags {
    /**
    * A unique identifier for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#key CloudwatchMetricStream#key}
    */
    readonly key?: string;
    /**
    * String which you can use to describe or define the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#value CloudwatchMetricStream#value}
    */
    readonly value?: string;
}
export declare function cloudwatchMetricStreamTagsToTerraform(struct?: CloudwatchMetricStreamTags | cdktn.IResolvable): any;
export declare function cloudwatchMetricStreamTagsToHclTerraform(struct?: CloudwatchMetricStreamTags | cdktn.IResolvable): any;
export declare class CloudwatchMetricStreamTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchMetricStreamTags | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchMetricStreamTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CloudwatchMetricStreamTagsList extends cdktn.ComplexList {
    internalValue?: CloudwatchMetricStreamTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchMetricStreamTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream awscc_cloudwatch_metric_stream}
*/
export declare class CloudwatchMetricStream extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_cloudwatch_metric_stream";
    /**
    * Generates CDKTN code for importing a CloudwatchMetricStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchMetricStream to import
    * @param importFromId The id of the existing CloudwatchMetricStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchMetricStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/cloudwatch_metric_stream awscc_cloudwatch_metric_stream} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchMetricStreamConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudwatchMetricStreamConfig);
    get arn(): string;
    get creationDate(): string;
    private _excludeFilters;
    get excludeFilters(): CloudwatchMetricStreamExcludeFiltersList;
    putExcludeFilters(value: CloudwatchMetricStreamExcludeFilters[] | cdktn.IResolvable): void;
    resetExcludeFilters(): void;
    get excludeFiltersInput(): cdktn.IResolvable | CloudwatchMetricStreamExcludeFilters[] | undefined;
    private _firehoseArn?;
    get firehoseArn(): string;
    set firehoseArn(value: string);
    resetFirehoseArn(): void;
    get firehoseArnInput(): string | undefined;
    get id(): string;
    private _includeFilters;
    get includeFilters(): CloudwatchMetricStreamIncludeFiltersList;
    putIncludeFilters(value: CloudwatchMetricStreamIncludeFilters[] | cdktn.IResolvable): void;
    resetIncludeFilters(): void;
    get includeFiltersInput(): cdktn.IResolvable | CloudwatchMetricStreamIncludeFilters[] | undefined;
    private _includeLinkedAccountsMetrics?;
    get includeLinkedAccountsMetrics(): boolean | cdktn.IResolvable;
    set includeLinkedAccountsMetrics(value: boolean | cdktn.IResolvable);
    resetIncludeLinkedAccountsMetrics(): void;
    get includeLinkedAccountsMetricsInput(): boolean | cdktn.IResolvable | undefined;
    get lastUpdateDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _outputFormat?;
    get outputFormat(): string;
    set outputFormat(value: string);
    resetOutputFormat(): void;
    get outputFormatInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    get state(): string;
    private _statisticsConfigurations;
    get statisticsConfigurations(): CloudwatchMetricStreamStatisticsConfigurationsList;
    putStatisticsConfigurations(value: CloudwatchMetricStreamStatisticsConfigurations[] | cdktn.IResolvable): void;
    resetStatisticsConfigurations(): void;
    get statisticsConfigurationsInput(): cdktn.IResolvable | CloudwatchMetricStreamStatisticsConfigurations[] | undefined;
    private _tags;
    get tags(): CloudwatchMetricStreamTagsList;
    putTags(value: CloudwatchMetricStreamTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | CloudwatchMetricStreamTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
