/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChimeMediaPipelineKinesisVideoStreamPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Kinesis Video Stream Pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool#pool_name ChimeMediaPipelineKinesisVideoStreamPool#pool_name}
    */
    readonly poolName: string;
    /**
    * The configuration settings for the Kinesis video stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool#stream_configuration ChimeMediaPipelineKinesisVideoStreamPool#stream_configuration}
    */
    readonly streamConfiguration: ChimeMediaPipelineKinesisVideoStreamPoolStreamConfiguration;
    /**
    * The tags associated with the Kinesis Video Stream Pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool#tags ChimeMediaPipelineKinesisVideoStreamPool#tags}
    */
    readonly tags?: ChimeMediaPipelineKinesisVideoStreamPoolTags[] | cdktn.IResolvable;
}
export interface ChimeMediaPipelineKinesisVideoStreamPoolStreamConfiguration {
    /**
    * The amount of time that data is retained, in hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool#data_retention_in_hours ChimeMediaPipelineKinesisVideoStreamPool#data_retention_in_hours}
    */
    readonly dataRetentionInHours?: number;
    /**
    * The AWS Region of the video stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool#region ChimeMediaPipelineKinesisVideoStreamPool#region}
    */
    readonly region: string;
}
export declare function chimeMediaPipelineKinesisVideoStreamPoolStreamConfigurationToTerraform(struct?: ChimeMediaPipelineKinesisVideoStreamPoolStreamConfiguration | cdktn.IResolvable): any;
export declare function chimeMediaPipelineKinesisVideoStreamPoolStreamConfigurationToHclTerraform(struct?: ChimeMediaPipelineKinesisVideoStreamPoolStreamConfiguration | cdktn.IResolvable): any;
export declare class ChimeMediaPipelineKinesisVideoStreamPoolStreamConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ChimeMediaPipelineKinesisVideoStreamPoolStreamConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaPipelineKinesisVideoStreamPoolStreamConfiguration | cdktn.IResolvable | undefined);
    private _dataRetentionInHours?;
    get dataRetentionInHours(): number;
    set dataRetentionInHours(value: number);
    resetDataRetentionInHours(): void;
    get dataRetentionInHoursInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export interface ChimeMediaPipelineKinesisVideoStreamPoolTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool#key ChimeMediaPipelineKinesisVideoStreamPool#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool#value ChimeMediaPipelineKinesisVideoStreamPool#value}
    */
    readonly value?: string;
}
export declare function chimeMediaPipelineKinesisVideoStreamPoolTagsToTerraform(struct?: ChimeMediaPipelineKinesisVideoStreamPoolTags | cdktn.IResolvable): any;
export declare function chimeMediaPipelineKinesisVideoStreamPoolTagsToHclTerraform(struct?: ChimeMediaPipelineKinesisVideoStreamPoolTags | cdktn.IResolvable): any;
export declare class ChimeMediaPipelineKinesisVideoStreamPoolTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChimeMediaPipelineKinesisVideoStreamPoolTags | cdktn.IResolvable | undefined;
    set internalValue(value: ChimeMediaPipelineKinesisVideoStreamPoolTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ChimeMediaPipelineKinesisVideoStreamPoolTagsList extends cdktn.ComplexList {
    internalValue?: ChimeMediaPipelineKinesisVideoStreamPoolTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChimeMediaPipelineKinesisVideoStreamPoolTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool awscc_chime_media_pipeline_kinesis_video_stream_pool}
*/
export declare class ChimeMediaPipelineKinesisVideoStreamPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "awscc_chime_media_pipeline_kinesis_video_stream_pool";
    /**
    * Generates CDKTN code for importing a ChimeMediaPipelineKinesisVideoStreamPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChimeMediaPipelineKinesisVideoStreamPool to import
    * @param importFromId The id of the existing ChimeMediaPipelineKinesisVideoStreamPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChimeMediaPipelineKinesisVideoStreamPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/awscc/1.108.0/docs/resources/chime_media_pipeline_kinesis_video_stream_pool awscc_chime_media_pipeline_kinesis_video_stream_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChimeMediaPipelineKinesisVideoStreamPoolConfig
    */
    constructor(scope: Construct, id: string, config: ChimeMediaPipelineKinesisVideoStreamPoolConfig);
    get arn(): string;
    get createdTimestamp(): string;
    get id(): string;
    get poolId(): string;
    private _poolName?;
    get poolName(): string;
    set poolName(value: string);
    get poolNameInput(): string | undefined;
    get poolStatus(): string;
    private _streamConfiguration;
    get streamConfiguration(): ChimeMediaPipelineKinesisVideoStreamPoolStreamConfigurationOutputReference;
    putStreamConfiguration(value: ChimeMediaPipelineKinesisVideoStreamPoolStreamConfiguration): void;
    get streamConfigurationInput(): cdktn.IResolvable | ChimeMediaPipelineKinesisVideoStreamPoolStreamConfiguration | undefined;
    private _tags;
    get tags(): ChimeMediaPipelineKinesisVideoStreamPoolTagsList;
    putTags(value: ChimeMediaPipelineKinesisVideoStreamPoolTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ChimeMediaPipelineKinesisVideoStreamPoolTags[] | undefined;
    get updatedTimestamp(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
